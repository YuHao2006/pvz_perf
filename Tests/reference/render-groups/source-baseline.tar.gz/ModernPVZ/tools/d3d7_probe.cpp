#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <d3d.h>
#include <ddraw.h>

#include <iomanip>
#include <iostream>

namespace {

using DirectDrawCreateExFunction = HRESULT(WINAPI*)(GUID*, void**, REFIID, IUnknown*);

void print_result(const char* operation, HRESULT result)
{
    std::cout << operation << "=0x" << std::hex << std::uppercase
              << std::setw(8) << std::setfill('0')
              << static_cast<unsigned long>(result) << std::dec << '\n';
}

} // namespace

int main()
{
    std::cout << "pointer_bits=" << (sizeof(void*) * 8) << '\n';

    HMODULE ddraw_module = LoadLibraryW(L"ddraw.dll");
    if (ddraw_module == nullptr) {
        std::cerr << "LoadLibraryW(ddraw.dll) failed with " << GetLastError() << '\n';
        return 1;
    }

    const auto direct_draw_create_ex = reinterpret_cast<DirectDrawCreateExFunction>(
        GetProcAddress(ddraw_module, "DirectDrawCreateEx"));
    if (direct_draw_create_ex == nullptr) {
        std::cerr << "DirectDrawCreateEx export is unavailable\n";
        FreeLibrary(ddraw_module);
        return 1;
    }

    IDirectDraw7* direct_draw = nullptr;
    HRESULT result = direct_draw_create_ex(
        nullptr,
        reinterpret_cast<void**>(&direct_draw),
        IID_IDirectDraw7,
        nullptr);
    print_result("DirectDrawCreateEx", result);

    IDirect3D7* direct_3d = nullptr;
    if (SUCCEEDED(result)) {
        result = direct_draw->QueryInterface(
            IID_IDirect3D7,
            reinterpret_cast<void**>(&direct_3d));
        print_result("QueryInterface(IDirect3D7)", result);
    }

    if (direct_3d != nullptr) {
        direct_3d->Release();
    }
    if (direct_draw != nullptr) {
        direct_draw->Release();
    }
    FreeLibrary(ddraw_module);

    return SUCCEEDED(result) ? 0 : 2;
}
