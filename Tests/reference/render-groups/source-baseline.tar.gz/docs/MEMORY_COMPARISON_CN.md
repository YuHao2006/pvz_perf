# Legacy 与官方 32 位版本的内存差异调查

本文记录调查结果以及 Legacy 当前采用的 CPU 内存回收策略。用户侧的任务管理器
统计不包含显存，因此这里把 CPU 工作集/Private Bytes 与 GPU 纹理分开讨论。

## 结论排序

当前 Legacy 内存明显高于官方版本，最可能的来源按影响排序如下：

1. Legacy 的 D3D11 路径把纹理统一上传为 32 位。
2. Legacy 的 D3D11 路径不会释放资源的 CPU 像素副本。
3. 当前发行目录的 `settings.xml` 使用了 `customScale=1`，三段 Anime4K
   管线会建立并缓存额外的 GPU 中间纹理。
4. x64 原生结构体、指针和容器确实会膨胀，但通常只解释对象/定义数据的
   一部分，不足以单独解释“整体翻倍”。
5. 当前旧版 `main.pak64` 文件本身比官方 `main.pak` 大很多；ZIP/PAK 映射
   会让被访问的压缩包页面进入进程工作集，尤其是启动阶段读取大量 compiled
   定义时更明显。

## 确定的源码证据

### 1. 纹理格式被固定为 32 位

`D3DInterface::TextureData::CreateTextures` 明确设置：

```cpp
PixelFormat aFormat = PixelFormat_A8R8G8B8;
```

随后 `D3D11Renderer::CreateTextureSRV` 只使用：

```cpp
DXGI_FORMAT_B8G8R8A8_UNORM
DXGI_FORMAT_B8G8R8X8_UNORM
```

即使资源 XML 声明了 `a4r4g4b4`，当前 D3D11 路径也只把这个标志保留在
兼容字段中，并没有创建 16 位纹理。官方旧 D3D7 路径可以使用 A4R4G4B4、
R5G6B5 等格式；相同像素数下，32 位纹理约为 16 位纹理的两倍显存占用。

这也是为什么“把无透明图片改成 24 位”不能直接解决：D3D11 没有通用的
24 位纹理格式，当前实现只能选择 32 位 X8/A8 格式。

### 2. CPU 像素副本曾被刻意保留，现已释放

历史代码中，`ResourceManager` 会根据资源 XML 的 `nobits`、`nobits3d` 和
`nobits2d` 设置 `mPurgeBits`，而 `D3DInterface::CreateImageTexture` 又有
专门的 D3D11 分支：

```cpp
// D3D11 owns the atlas SRVs ... Never purge the bits
if (wantPurge && gD3D11Renderer == NULL)
    theImage->PurgeBits();
```

因此，很多已经上传到 GPU 的图片仍然保留 `MemoryImage::mBits`。对于一张
`width × height` 图片，这一份 CPU 副本至少是 `width * height * 4` 字节；
GPU 侧又有一份 32 位纹理。官方 3D 路径通常可以在上传后释放被标记为
`nobits3d` 的 CPU 副本，所以这里很容易形成接近一倍的额外资源内存。

现在 Legacy 的 `ResourceManager::DoLoadImage` 会把来自资源清单的普通静态图片
标记为可 purge，上传到 D3D11 后释放其 CPU 像素副本。用于 ReanimAtlas 的
`reanim\` 图片例外保留 CPU 源像素，避免之后的懒构建图集得到空白贴图。运行时
用 `MemoryImage` 创建的图片（例如 Zombatar 导出图、滤镜和效果缓冲）不经过这个
入口，也仍保留 CPU 缓冲。
这是基于当前“不重新创建窗口/交换链”的运行约束做的取舍：不再为普通缩放切换
保留一份完整 CPU 贴图。

`D3DInterface::Cleanup` 仍保留设备销毁时补回 CPU bits 的保护代码。若未来重新启用
设备重建，已 purge 的资源不能依赖这条路径恢复原图；应从 `pak64` 重新解码，或
在重建期间禁止该路径。当前 Legacy 不把设备重建作为正常设置切换操作。

### 3. 自定义缩放会缓存额外纹理

当前发行目录的设置是：

```xml
<customScale>1</customScale>
```

窗口管线包含三段 Anime4K，运行时使用 `ScaleEffectRuntime::mEffectTextures`
缓存各效果的中间 `ID3D11Texture2D`，每个纹理同时拥有 SRV 和 UAV。管线还
保留场景纹理、交换链后台缓冲，以及可能的全屏管线纹理。缩放目标越大，
中间纹理的内存按像素数增长；例如 1600×1200 的 32 位纹理单张约 7.3 MiB，
三到数张就会产生明显差异。

关闭 `customScale` 后，这一组中间纹理才会在 `DestroyDevice()` 中释放；仅
切换页面不会释放它们。

### 4. x64 结构体膨胀是真实存在的，但不是唯一主因

Reanim/Particle 定义包含大量指针和“指针+数量”数组。x86→x64 后：

- 指针从 4 字节变成 8 字节；
- 数组描述符需要更多对齐填充；
- `std::map`、`std::vector`、引用计数对象和 Widget 的节点也会增大。

这会增加定义缓存、动画轨道、粒子发射器和 UI 对象的 Private Bytes。但这些
对象的总量通常远小于所有图片的 CPU/GPU 像素缓冲，因此不能单独解释整体
翻倍。

### 5. PAK 映射大小也不同

本机观察到：

| 文件 | 大小 |
|---|---:|
| 官方 1073 `main.pak` | 约 42.8 MiB |
| 旧 Legacy `main.pak64` | 约 104.6 MiB |
| 旧的 `main-new.pak64` | 约 73.7 MiB |

Legacy 的 ZIP/PAK 装载器使用 `MapViewOfFile` 映射整个包。映射本身主要增加
虚拟地址空间，但被读取的页面会进入工作集；旧 PAK64 中更大的 compiled 定义
和重复资源会提高启动后的工作集。它不是所有 Private Bytes 的来源，但会让
任务管理器里的“内存”看起来更大。

## 不是主要原因的项目

- BASS 音乐：当前音乐压缩文件会常驻内存并由 BASS 解码，但官方同样采用
  这套设计，通常不是两倍差异的主因。
- DirectSound 短音效：两边都会创建 PCM 缓冲；Legacy 没有 `cached` 写盘
  行为，不会因为缓存目录无限增长。
- PAK 是否 XOR：XOR 只改变读取时的字节内容，不会让解码后的图片变大；
  当前 PAK64 输出也没有加密。

## 正确的对比方法

不能只看任务管理器一个“内存”列。应在相同关卡、相同窗口大小、相同音量和
相同加载完成状态下分别记录：

- `Private Bytes`：进程私有提交内存；
- `Working Set`：当前驻留物理内存；
- GPU Dedicated Usage：显卡专用显存；
- GPU Shared Usage：系统内存作为显存的部分。

建议先用 `customScale=0` 对比，再用 `customScale=1` 对比。若关闭缩放后差距
大幅缩小，主因就是缩放中间纹理；若仍接近翻倍，则主要是“CPU 像素副本 +
32 位纹理格式”。

## 可以牺牲内存换 CPU 性能的含义

用户允许用内存换性能时，最安全的方向是保留 GPU 纹理并释放可重建的 CPU
像素副本；这不会增加每帧解码工作，只会让设备重建时重新从 PAK 解码。相反，
把纹理降成 16 位会明显省显存，但可能改变颜色/透明度并增加格式转换成本，
需要逐资源验证，不能直接全局替换。

## 当前采用的范围

资源清单加载的普通图片在首次 D3D11 上传后释放 CPU 像素；ReanimAtlas 源图和
运行时生成/修改的 `MemoryImage` 仍保留 CPU 缓冲，避免懒加载图集、Zombatar、
滤镜、截图和软件合成路径得到空白图像。设备销毁恢复代码仅作异常保护，不代表
正常流程会重建窗口。
