// r3_common.h — 段表性能对拍第三轮（收尾轮）公共桩框架
// 基准目录: _shared/bench35/r3/（不触碰仓库文件；仓库头只读 include）
// 枚举/轨道真值直接 include 仓库 ConstEnums.h / ReanimTrackId.h（只读），
// 保证表下标与枚举序与仓库完全一致。单 TU 使用（每 bench.cpp 独立编译）。
#pragma once

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <algorithm>
#define NOMINMAX
#include <windows.h>
#include "C:/Users/Administrator/CLionProjects/codex/PlantsVsZombiesModern/ConstEnums.h"
#include "C:/Users/Administrator/CLionProjects/codex/PlantsVsZombiesModern/Sexy.TodLib/ReanimTrackId.h"

// ============================ Music 枚举（仓库 System/Music.h 真值） ============================
enum MusicTune
{
    MUSIC_TUNE_NONE = -1,
    MUSIC_TUNE_DAY_GRASSWALK = 1,
    MUSIC_TUNE_NIGHT_MOONGRAINS,
    MUSIC_TUNE_POOL_WATERYGRAVES,
    MUSIC_TUNE_FOG_RIGORMORMIST,
    MUSIC_TUNE_ROOF_GRAZETHEROOF,
    MUSIC_TUNE_CHOOSE_YOUR_SEEDS,
    MUSIC_TUNE_TITLE_CRAZY_DAVE_MAIN_THEME,
    MUSIC_TUNE_ZEN_GARDEN,
    MUSIC_TUNE_PUZZLE_CEREBRAWL,
    MUSIC_TUNE_MINIGAME_LOONBOON,
    MUSIC_TUNE_CONVEYER,
    MUSIC_TUNE_FINAL_BOSS_BRAINIAC_MANIAC,
    MUSIC_TUNE_CREDITS_ZOMBIES_ON_YOUR_LAWN,
    NUM_MUSIC_TUNES
};
enum MusicFile
{
    MUSIC_FILE_NONE = -1,
    MUSIC_FILE_MAIN_MUSIC = 1,
    MUSIC_FILE_DRUMS,
    MUSIC_FILE_HIHATS,
    MUSIC_FILE_CREDITS_ZOMBIES_ON_YOUR_LAWN,
    NUM_MUSIC_FILES
};
// PlantState（仓库 Plant.h 真值段；完整序 0..）
enum PlantState
{
    STATE_NOTREADY,
    STATE_READY,
    STATE_DOINGSPECIAL,
    STATE_SQUASH_LOOK,
    STATE_SQUASH_PRE_LAUNCH,
    STATE_SQUASH_RISING,
    STATE_SQUASH_FALLING,
    STATE_SQUASH_DONE_FALLING,
    STATE_GRAVEBUSTER_LANDING,
    STATE_GRAVEBUSTER_EATING,
    STATE_CHOMPER_BITING,
    STATE_CHOMPER_BITING_GOT_ONE,
    STATE_CHOMPER_BITING_MISSED,
    STATE_CHOMPER_DIGESTING,
    STATE_CHOMPER_SWALLOWING,
    STATE_POTATO_RISING,
    STATE_POTATO_ARMED,
    STATE_POTATO_MASHED,
    STATE_SPIKEWEED_ATTACKING,
    STATE_SPIKEWEED_ATTACKING_2,
    STATE_SCAREDYSHROOM_LOWERING,
    STATE_SCAREDYSHROOM_SCARED,
    STATE_SCAREDYSHROOM_RAISING,
    STATE_SUNSHROOM_SMALL,
    STATE_SUNSHROOM_GROWING,
    STATE_SUNSHROOM_BIG,
    STATE_MAGNETSHROOM_SUCKING,
    STATE_MAGNETSHROOM_CHARGING,
    STATE_BOWLING_UP,
    STATE_BOWLING_DOWN,
    STATE_CACTUS_LOW,
    STATE_CACTUS_RISING,
    STATE_CACTUS_HIGH,
    STATE_CACTUS_LOWERING,
    STATE_TANGLEKELP_GRABBING,
    STATE_COBCANNON_ARMING,
    STATE_COBCANNON_LOADING,
    STATE_COBCANNON_READY,
    STATE_COBCANNON_FIRING,
    STATE_FLOWERPOT_INVULNERABLE,
    STATE_LILYPAD_INVULNERABLE,
};

// ============================ 常量（照抄仓库） ============================
constexpr const int BUNGEE_ZOMBIE_HEIGHT = 3000;
constexpr const int POGO_BOUNCE_TIME = 80;
constexpr const int DOLPHIN_JUMP_TIME = 120;
constexpr const int BOSS_FLASH_HEALTH_FRACTION = 10;
constexpr const int RENDER_GROUP_HIDDEN = -1;
constexpr const int RENDER_GROUP_NORMAL = 0;
constexpr const int RENDER_GROUP_ARMS = 1;
constexpr const int ZOMBIE_START_RANDOM_OFFSET = 400;
constexpr const int ZOMBIE_LIMP_SPEED_FACTOR = 15;
constexpr const int MAX_ZOMBIE_FOLLOWERS = 4;
constexpr const int NUM_BOBSLED_FOLLOWERS = 3;
constexpr const int MAX_GRID_SIZE_X = 9;
constexpr const int MAX_GRID_SIZE_Y = 6;
constexpr const int BOARD_WIDTH = 800;
constexpr const int BOARD_HEIGHT = 600;
constexpr const int BOARD_OFFSET = 40;
constexpr const int WIDE_BOARD_WIDTH = 700;
constexpr const int MAX_PAGE_SPOTS = 27;
constexpr const int NUM_ALMANAC_ZOMBIES = 26;
constexpr const int PURCHASE_COUNT_OFFSET = 0;
#define LENGTH(a) (sizeof(a) / sizeof((a)[0]))
#define M(f) (f)
#define TOD_ASSERT(x) ((void)0)

inline bool TestBit(unsigned int theNum, int theIdx) { return theNum & (1u << theIdx); }
inline int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline int FloatRoundToInt(float f) { return (int)(f + 0.5f); }

// ============================ Sink（编号桩统一入 checksum） ============================
inline uint64_t g_sink = 0;
inline void ZSink(uint32_t theId, uint32_t a = 0, uint32_t b = 0, uint32_t c = 0)
{
    g_sink = g_sink * 1000003ull + (theId * 97ull + a * 31ull + b * 7ull + c);
}
inline uint64_t ZBMixU64(uint64_t h, uint64_t v) { return h * 1000003ull + v; }

// ============================ 颜色 / 矩形 / 贴图 ============================
struct Color
{
    int mRed, mGreen, mBlue, mAlpha;
    constexpr Color() : mRed(0), mGreen(0), mBlue(0), mAlpha(255) {}
    constexpr Color(int r, int g, int b, int a = 255) : mRed(r), mGreen(g), mBlue(b), mAlpha(a) {}
    static const Color Black;   // 定义紧随 struct 后
};
inline constexpr Color kColorBlackImpl(0, 0, 0, 255);
inline const Color Color::Black = kColorBlackImpl;

struct Rect
{
    int mX, mY, mWidth, mHeight;
    constexpr Rect() : mX(0), mY(0), mWidth(0), mHeight(0) {}
    constexpr Rect(int x, int y, int w, int h) : mX(x), mY(y), mWidth(w), mHeight(h) {}
    bool Contains(int x, int y) const { return x >= mX && x < mX + mWidth && y >= mY && y < mY + mHeight; }
};

struct Image
{
    int mId = 0;
    int mCelW = 0, mCelH = 0;
    int GetCelWidth() const { return mCelW; }
    int GetCelHeight() const { return mCelH; }
    int GetWidth() const { return mCelW; }
    int GetHeight() const { return mCelH; }
};
inline Image g_images[192];
inline Image* ZBImg(int i) { return &g_images[i]; }
inline void ZBInitImages()
{
    for (int i = 0; i < 192; i++) { g_images[i].mId = i; g_images[i].mCelW = 40 + (i * 7) % 80; g_images[i].mCelH = 30 + (i * 11) % 70; }
}

// ============================ 桩编号（全局唯一，跨 bench 稳定） ============================
enum R3StubId
{
    RID_G_DrawImage = 1, RID_G_DrawImageRect, RID_G_DrawImageCel, RID_G_SetColorizeImages,
    RID_G_SetColor, RID_G_SetDrawMode, RID_G_SetClipRect, RID_G_ClipRect, RID_G_FillRect,
    RID_G_Translate, RID_G_TranslateF, RID_G_PushState, RID_G_PopState, RID_GraphicsCtor,
    RID_TodDrawImageScaledF, RID_TodDrawImageAnim, RID_TodDrawString, RID_TodDrawStringWrapped,
    RID_TodDrawStringMatrix,
    RID_Rean_TrackExists, RID_Rean_SetImageOverride, RID_Rean_GetImageOverride,
    RID_Rean_PlayReanim, RID_Rean_SetFramesForLayer, RID_Rean_AssignRange,
    RID_Rean_AssignTrack, RID_Rean_ShouldTriggerTimedEvent, RID_Rean_OverrideScale,
    RID_Rean_ReanimationDie, RID_Rean_AttachParticleToTrack, RID_Rean_Draw,
    RID_Rean_DrawRenderGroup, RID_Rean_Update, RID_Rean_SetTruncateAll,
    RID_Rean_AttachToAnother, RID_Rean_GetCurrentTransform, RID_Rean_SetPosition,
    RID_Rean_GetTrackInstance,
    RID_Particle_OverrideImage, RID_Particle_OverrideFrame, RID_Particle_Draw,
    RID_App_PlayFoley, RID_App_ReanimationGetID, RID_App_RemoveReanimation,
    RID_App_AddReanimation, RID_App_AddTodParticle, RID_App_PlaySample,
    RID_App_MusicInterface, RID_App_SetCursor, RID_App_Pluralize, RID_App_DoNewOptions,
    RID_App_DoCheatDialog, RID_App_CrazyDaveEnter, RID_App_UpdateCrazyDave,
    RID_Z_DropShield, RID_Z_DropHelm, RID_Z_ApplyChill, RID_Z_UpdateAnimSpeed,
    RID_Z_SetupReanimForLostHead, RID_Z_GetTrackPosition, RID_Z_ReanimShowRange,
    RID_Z_ReanimShowTrack, RID_Z_OverrideParticleScale, RID_Z_OverrideParticleColor,
    RID_Z_PogoBreak, RID_Z_DropPole, RID_Z_DropFlag, RID_Z_BobsledCrash, RID_Z_DieNoLoot,
    RID_Z_BungeeLanding, RID_Z_BungeeStealTarget, RID_Z_BungeeLiftTarget,
    RID_Z_StartWalkAnim, RID_Z_PlayZombieReanim, RID_Z_PickRandomSpeed, RID_Z_PoolSplash,
    RID_Z_TakeDamage, RID_Z_StopZombieSound, RID_Z_AddAttachedReanim, RID_Z_AddAttachedParticle,
    RID_Z_AttachmentReanimTypeDie, RID_Z_StopEating, RID_Z_ZamboniDeath, RID_Z_CatapultDeath,
    RID_Z_ApplyBossSmokeParticles, RID_Z_BossDie, RID_Z_UpdateDamageStates, RID_Z_PlayDeathAnim,
    RID_Z_DropLoot, RID_Z_DieWithLoot, RID_Z_DropHead, RID_Z_DropArm, RID_Z_RemoveIceTrap,
    RID_Z_ShowYuckyFace, RID_Z_SetupDoorArms, RID_Z_ReanimIgnoreClipRect, RID_Z_GetDrawPos,
    RID_Z_LoadReanim, RID_Z_LoadPlain, RID_Z_AttachShield, RID_Z_PickBungeeTarget,
    RID_Z_PlayAppearSound, RID_Z_StartZombieSound, RID_Z_UpdateReanim, RID_Z_BossSetupReanim,
    RID_Z_ResetZombatarHead, RID_Z_ApplyZombatarHead, RID_Z_SetAnimRate,
    RID_Z_RemoveColdEffects, RID_Z_Collect, RID_Z_GetPosYBasedOnRow,
    RID_Rand, RID_RandRangeFloat, RID_RandRangeInt, RID_TodPickFrom,
    RID_ReanimatorEnsureLoaded, RID_TodLoadResources, RID_AttachReanim, RID_AttachEffectDetach,
    RID_TodScaleRotate, RID_Bass_Set, RID_Bass_Get, RID_GetBassHandle,
    RID_Board_TutorialArrowShow, RID_Board_TutorialArrowRemove, RID_Board_DisplayAdvice,
    RID_Board_ClearAdvice, RID_Board_GetShovelButtonRect, RID_Board_RefreshSeedPacket,
    RID_Board_SetTutorialStateInner,
    RID_Board_MouseHitTest, RID_Board_IteratePlants,
    RID_Board_CountPlantByType, RID_Board_CountEmptyPots, RID_Board_HasValidCobSpot,
    RID_Board_GetTopPlantAt, RID_Board_IsFlagWave, RID_Board_ZombieGetID,
    RID_Board_PickRowForNewZombie, RID_Board_AddZombieInRow,
    RID_Board_CanPlantAt, RID_Board_PlantingPixelToGridX, RID_Board_PlantingPixelToGridY,
    RID_Board_GetSeedTypeInCursor,
    RID_Plant_IsFlying, RID_Plant_DrawSeedType, RID_Plant_DrawHeightOffset, RID_Plant_GetNameString,
    RID_Zen_DrawPottedPlant, RID_Zen_GetWheelbarrow, RID_Zen_PickRandomSeedType,
    RID_Music_PlayFromOffset, RID_Music_IsMusicDisabled, RID_Music_MakeSurePlaying,
    RID_Store_SetBubbleText, RID_Store_CanInteract, RID_Store_GetItemType,
    RID_Store_IsUnavailable, RID_Store_GetPosition, RID_Store_IsFullVersionOnly,
    RID_Store_IsSoldOut, RID_Store_IsComingSoon, RID_WidgetButton_IsOver,
    RID_Almanac_ZombieHitTest, RID_Almanac_GetZombieType, RID_Almanac_GetZombiePosition,
    RID_Almanac_ZombieIsShown, RID_Almanac_ZombieHasSilhouette, RID_Almanac_DrawCachedZombie,
    RID_Msg_CopyLabel, RID_Msg_ClearLabel, RID_Msg_ClearReanim, RID_Msg_LayoutReanim,
    RID_Msg_EntityTranslate, RID_Msg_TodReplaceString, RID_Msg_GetFont,
    RID_Font_StringWidth, RID_Cursor_MouseHitTest,
    RID_CutScene_ShowZombieWalking, RID_CutScene_IsInShovelTutorial,
    RID_GetFlashingColor, RID_PottedPlant_Init, RID_Challenge_TreeCanFeed,
    RID_Challenge_TreeFertilize, RID_Challenge_TreeGrow, RID_App_GetCurrentChallengeIndex,
    RID_App_IsFirstTimeAdventure, RID_App_IsIZombie, RID_Challenge_GetArtSeed,
    RID_Coin_IsSun, RID_Coin_BeginDraw, RID_Coin_Draw, RID_Coin_EndDraw,
    RID_Coin_PickRandomSeed, RID_SeedPacket_CanTakeSunMoney, RID_MAX
};

// ============================ Graphics / TodDraw* 桩 ============================
struct Graphics
{
    float mScaleX = 1.0f, mScaleY = 1.0f;
    int mTransX = 0, mTransY = 0;
    enum DrawMode { DRAWMODE_NORMAL, DRAWMODE_ADDITIVE };
    Graphics() = default;
    Graphics(const Graphics&) { ZSink(RID_GraphicsCtor); }
    __declspec(noinline) void DrawImage(Image* i, int x, int y) { ZSink(RID_G_DrawImage, i ? (uint32_t)i->mId : 0u, (uint32_t)x, (uint32_t)y); }
    __declspec(noinline) void DrawImage(Image* i, int x, int y, const Rect& r) { ZSink(RID_G_DrawImageRect, i ? (uint32_t)i->mId : 0u, (uint32_t)(x * 31 + r.mWidth), (uint32_t)r.mHeight); }
    __declspec(noinline) void DrawImageF(Image* i, float x, float y) { ZSink(RID_G_DrawImage, i ? (uint32_t)i->mId : 0u, (uint32_t)(int)(x * 4.0f), (uint32_t)(int)(y * 4.0f)); }
    __declspec(noinline) void DrawImageCel(Image* i, int x, int y, int cel) { ZSink(RID_G_DrawImageCel, i ? (uint32_t)i->mId : 0u, (uint32_t)(x * 7 + cel), (uint32_t)y); }
    __declspec(noinline) void SetColorizeImages(bool b) { ZSink(RID_G_SetColorizeImages, b); }
    __declspec(noinline) void SetColor(const Color& c) { ZSink(RID_G_SetColor, (uint32_t)(c.mRed * 31 + c.mGreen), (uint32_t)(c.mBlue * 7 + c.mAlpha)); }
    __declspec(noinline) void SetDrawMode(int m) { ZSink(RID_G_SetDrawMode, (uint32_t)m); }
    __declspec(noinline) void SetClipRect(int x, int y, int w, int h) { ZSink(RID_G_SetClipRect, (uint32_t)x, (uint32_t)y, (uint32_t)(w * 31 + h)); }
    __declspec(noinline) void ClipRect(int x, int y, int w, int h) { ZSink(RID_G_ClipRect, (uint32_t)x, (uint32_t)y, (uint32_t)(w * 31 + h)); }
    __declspec(noinline) void FillRect(const Rect& r) { ZSink(RID_G_FillRect, (uint32_t)(r.mX * 31 + r.mWidth), (uint32_t)(r.mY * 31 + r.mHeight)); }
    __declspec(noinline) void Translate(int x, int y) { mTransX += x; mTransY += y; ZSink(RID_G_Translate, (uint32_t)x, (uint32_t)y); }
    __declspec(noinline) void TranslateF(float x, float y) { ZSink(RID_G_TranslateF, (uint32_t)(int)(x * 16.0f), (uint32_t)(int)(y * 16.0f)); }
    __declspec(noinline) void PushState() { ZSink(RID_G_PushState); }
    __declspec(noinline) void PopState() { ZSink(RID_G_PopState); }
};
inline void TodDrawImageScaledF(Graphics* g, Image* i, float x, float y, float sx, float sy)
{
    ZSink(RID_TodDrawImageScaledF, i ? (uint32_t)i->mId : 0u, (uint32_t)(int)(x * 8.0f + sx * 3.0f), (uint32_t)(int)(y * 8.0f + sy * 5.0f));
}
inline void TodDrawImageAnim(Graphics* g, Image* i, float x, float y, int a, int b, float c)
{
    ZSink(RID_TodDrawImageAnim, i ? (uint32_t)i->mId : 0u, (uint32_t)(int)(x + y), (uint32_t)(a * 31 + b));
}
using SexyString = std::string;
struct _Font
{
    int mAscent = 10;
    int StringWidth(const SexyString&) { ZSink(RID_Font_StringWidth); return 40; }
    int CharWidth(char c) { return 8 + c % 5; }
    int GetLineSpacing() { return 18; }
};
inline void TodDrawString(Graphics* g, const SexyString& s, int x, int y, _Font* f, const Color& c, int just)
{
    ZSink(RID_TodDrawString, (uint32_t)(x * 7 + y), (uint32_t)(c.mRed + c.mGreen * 3), (uint32_t)s.size());
}
inline void TodDrawStringWrapped(Graphics* g, const SexyString& s, const Rect& r, _Font* f, const Color& c, int just)
{
    ZSink(RID_TodDrawStringWrapped, (uint32_t)(r.mX * 31 + r.mWidth), (uint32_t)(c.mRed * 3 + c.mBlue), (uint32_t)s.size());
}
inline void TodDrawStringMatrix(Graphics* g, _Font* f, const float m[9], const SexyString& s, const Color& c)
{
    ZSink(RID_TodDrawStringMatrix, (uint32_t)c.mRed, (uint32_t)s.size());
}

// ============================ 曲线（真实数学，两形态共用） ============================
namespace Curves
{
    inline float EaseInW(float t) { return t * t; }
    inline float EaseOutW(float t) { return 1.0f - (1.0f - t) * (1.0f - t); }
    inline float Linear(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); return a + (b - a) * EaseInW(x); }
    inline float Bounce(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); return a + (b - a) * (1.0f - x * x); }
    inline float BounceSlowMiddle(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); float d = 2.0f * x - 1.0f; return a + (b - a) * (1.0f - d * d); }
}
inline float TodCurveEvaluateClamped(float t, float a, float b, float (*curve)(float, float, float)) { return curve(t, a, b); }
inline float TodAnimateCurveFloat(int theTimeStart, int theTimeEnd, int theTimeAge, float thePositionStart, float thePositionEnd, float (*theCurve)(float, float, float))
{
    float aWarpedAge = (theTimeAge - theTimeStart) / (float)(theTimeEnd - theTimeStart);
    return TodCurveEvaluateClamped(aWarpedAge, thePositionStart, thePositionEnd, theCurve);
}
inline int TodAnimateCurve(int theTimeStart, int theTimeEnd, int theTimeAge, int thePositionStart, int thePositionEnd, float (*theCurve)(float, float, float))
{
    return (int)TodAnimateCurveFloat(theTimeStart, theTimeEnd, theTimeAge, (float)thePositionStart, (float)thePositionEnd, theCurve);
}
inline Color GetFlashingColor(int theCounter, int theOffset)
{
    ZSink(RID_GetFlashingColor, (uint32_t)theCounter, (uint32_t)theOffset);
    return Color(255, 255, 255, 128);
}

// ============================ 随机数桩（全局序列，跑前重置；两形态序列一致） ============================
inline uint32_t g_rng = 0x9E3779B9u;
inline void ZBRngReset(uint32_t s = 0x9E3779B9u) { g_rng = s; }
inline uint32_t ZBRngNext() { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5; return g_rng; }
__declspec(noinline) int Rand(int theMax)
{
    uint32_t raw = ZBRngNext();
    int v = (int)(raw % (uint32_t)(theMax > 0 ? theMax : 1));
    ZSink(RID_Rand, raw);   // sink 原始抽签值：跨形态取值域平移（0 基化）仍对拍相等
    return v;
}
__declspec(noinline) float RandRangeFloat(float theMin, float theMax)
{
    uint32_t raw = ZBRngNext();
    float v = theMin + (raw % 1000u) / 1000.0f * (theMax - theMin);
    ZSink(RID_RandRangeFloat, raw);
    return v;
}
__declspec(noinline) int RandRangeInt(int theMin, int theMax)
{
    uint32_t raw = ZBRngNext();
    int span = theMax - theMin + 1;
    int v = theMin + (int)(raw % (uint32_t)(span > 0 ? span : 1));
    ZSink(RID_RandRangeInt, raw);
    return v;
}
namespace Sexy { inline int Rand(int theMax) { return ::Rand(theMax); } }
template <class T>
__declspec(noinline) T TodPickFromList(const T* theList, int theCount)
{
    T v = theList[Rand(theCount)];
    ZSink(RID_TodPickFrom);
    return v;
}
template <class T>
__declspec(noinline) T TodPickFromArray(const T* theArray, int theCount)
{
    T v = theArray[Rand(theCount)];
    ZSink(RID_TodPickFrom);
    return v;
}
inline void TodLoadResources(const char* theRes) { ZSink(RID_TodLoadResources, (uint32_t)(theRes ? (unsigned char)theRes[0] : 0u), (uint32_t)(theRes ? (unsigned char)theRes[7] : 0u)); }
__declspec(noinline) void ReanimatorEnsureDefinitionLoaded(ReanimationType theReanimType, bool theIsPreloading)
{
    ZSink(RID_ReanimatorEnsureLoaded, (uint32_t)theReanimType, theIsPreloading);
}

// ============================ 附着 / 变换 ============================
struct SexyMatrix3 { float m[9]; };
struct ReanimatorTransform { float mAlpha = 1.0f; float mTransX = 0, mTransY = 0; };
struct AttachEffect
{
    SexyMatrix3 mOffset{};
    bool mDontDrawIfParentHidden = false;
    bool mDontPropogateColor = false;
};
inline void TodScaleRotateTransformMatrix(SexyMatrix3& theMatrix, float a, float b, float c, float d, float e)
{
    ZSink(RID_TodScaleRotate, (uint32_t)(int)(a * 4.0f), (uint32_t)(int)(b * 4.0f), (uint32_t)(int)(c * 8.0f + d + e * 3.0f));
}
struct TodParticleSystem
{
    __declspec(noinline) void OverrideImage(Image* theOld, Image* theNew)
    {
        ZSink(RID_Particle_OverrideImage, theNew ? (uint32_t)theNew->mId : 0u);
    }
    __declspec(noinline) void OverrideFrame(Image* theOld, int theFrame)
    {
        ZSink(RID_Particle_OverrideFrame, (uint32_t)theFrame);
    }
    __declspec(noinline) void Draw(Graphics* g) { ZSink(RID_Particle_Draw); }
};
inline TodParticleSystem g_particle;

// ============================ Reanimation 桩 ============================
struct ReanimatorTrackInstance
{
    AttachmentID mAttachmentID = ATTACHMENTID_NULL;
    Image* mImageOverride = nullptr;
    bool mIgnoreExtraAdditiveColor = false;
    bool mIgnoreColorOverride = false;
    bool mIgnoreClipRect = false;
};
struct Reanimation
{
    int mLoopCount = 0;
    float mAnimTime = 0.0f;
    float mAnimRate = 0.0f;
    bool mIsAttachment = false;
    ReanimLoopType mLoopType = REANIM_LOOP;
    int mFrameBasePose = 0;
    ReanimationType mReanimationType = ReanimationType::REANIM_NONE;
    struct OverlayMatrix { float m02 = 0, m12 = 0; } mOverlayMatrix;
    Color mColorOverride{255, 255, 255, 255};
    bool mColorOverrideEnable = false;
    bool mVisible = true;

    __declspec(noinline) bool TrackExists(ReanimTrackId theTrackId) { ZSink(RID_Rean_TrackExists, (uint32_t)theTrackId); return ((uint32_t)theTrackId % 4) != 3; }
    __declspec(noinline) void SetImageOverride(ReanimTrackId theTrackId, Image* theImage) { ZSink(RID_Rean_SetImageOverride, (uint32_t)theTrackId, theImage ? (uint32_t)theImage->mId : 0u); }
    __declspec(noinline) Image* GetImageOverride(ReanimTrackId theTrackId) { ZSink(RID_Rean_GetImageOverride, (uint32_t)theTrackId); return ((uint32_t)theTrackId % 3 == 0) ? nullptr : ZBImg(60 + ((uint32_t)theTrackId % 10)); }
    __declspec(noinline) void PlayReanim(ReanimTrackId theTrackId, ReanimLoopType theLoopType, int theAnimStartPct, float theAnimRate) { ZSink(RID_Rean_PlayReanim, (uint32_t)theTrackId, (uint32_t)theLoopType, (uint32_t)(int)theAnimRate); }
    __declspec(noinline) void SetFramesForLayer(ReanimTrackId theTrackId) { ZSink(RID_Rean_SetFramesForLayer, (uint32_t)theTrackId); }
    __declspec(noinline) void AssignRenderGroupToRange(const ReanimTrackIdRange& theRange, int theGroup) { ZSink(RID_Rean_AssignRange, (uint32_t)theRange.mLo, (uint32_t)theRange.mHi, (uint32_t)theGroup); }
    __declspec(noinline) void AssignRenderGroupToTrack(ReanimTrackId theTrackId, int theGroup) { ZSink(RID_Rean_AssignTrack, (uint32_t)theTrackId, (uint32_t)theGroup); }
    __declspec(noinline) bool ShouldTriggerTimedEvent(float theTime) { return mAnimTime > theTime; }
    __declspec(noinline) void OverrideScale(float x, float y) { ZSink(RID_Rean_OverrideScale, (uint32_t)(int)(x * 10.0f), (uint32_t)(int)(y * 10.0f)); }
    __declspec(noinline) void ReanimationDie() { ZSink(RID_Rean_ReanimationDie); }
    __declspec(noinline) AttachEffect* AttachParticleToTrack(ReanimTrackId theTrackId, TodParticleSystem* theParticle, float x, float y)
    {
        ZSink(RID_Rean_AttachParticleToTrack, (uint32_t)theTrackId, (uint32_t)(int)x);
        static AttachEffect sEffect;
        return &sEffect;
    }
    __declspec(noinline) void Draw(Graphics* g) { ZSink(RID_Rean_Draw); }
    __declspec(noinline) void DrawRenderGroup(Graphics* g, int theGroup) { ZSink(RID_Rean_DrawRenderGroup, (uint32_t)theGroup); }
    __declspec(noinline) void Update() { ZSink(RID_Rean_Update); mAnimTime += 0.01f; }
    __declspec(noinline) void SetTruncateDisappearingFramesAll(bool b) { ZSink(RID_Rean_SetTruncateAll, b); }
    __declspec(noinline) void AttachToAnotherReanimation(Reanimation* theOther, ReanimTrackId theTrackId) { ZSink(RID_Rean_AttachToAnother, (uint32_t)theTrackId); }
    __declspec(noinline) void GetCurrentTransform(int a, ReanimatorTransform* t) { ZSink(RID_Rean_GetCurrentTransform, (uint32_t)a); t->mAlpha = 1.0f; t->mTransX = 1.0f; t->mTransY = 2.0f; }
    __declspec(noinline) void SetPosition(float x, float y) { ZSink(RID_Rean_SetPosition, (uint32_t)(int)(x * 8.0f), (uint32_t)(int)(y * 8.0f)); }
    __declspec(noinline) ReanimatorTrackInstance* GetTrackInstanceByName(ReanimTrackId theTrackId)
    {
        ZSink(RID_Rean_GetTrackInstance, (uint32_t)theTrackId);
        static ReanimatorTrackInstance sInstances[8];
        return &sInstances[(uint32_t)theTrackId % 8];
    }
    static void MatrixFromTransform(const ReanimatorTransform& t, SexyMatrix3& m) {}
};
inline Reanimation g_reanimA, g_reanimB, g_reanimC, g_reanimScratch;
inline AttachEffect* AttachReanim(AttachmentID theAttachment, Reanimation* theReanim, float x = 0.0f, float y = 0.0f)
{
    ZSink(RID_AttachReanim, (uint32_t)theAttachment, (uint32_t)(int)(x * 4.0f), (uint32_t)(int)(y * 4.0f));
    static AttachEffect sEffect;
    return &sEffect;
}
inline void AttachmentDetachCrossFadeParticleType(AttachmentID theID, ParticleEffect theEffect, void* theUserData)
{
    ZSink(RID_AttachEffectDetach, (uint32_t)theEffect);
}

// ============================ Foley / 音效 ============================
enum FoleyType
{
    FOLEY_GRASSSTEP = 0, FOLEY_SHIELD_HIT, FOLEY_DIRT_RISE, FOLEY_WAKEUP,
    FOLEY_GARGANTUDEATH, FOLEY_EXPLOSION, FOLEY_BONK, FOLEY_DOLPHIN_BEFORE_JUMPING,
    FOLEY_PLANT_WATER, FOLEY_ZOMBIE_ENTERING_WATER, FOLEY_LIMBS_POP, FOLEY_BOSS_EXPLOSION_SMALL,
    FOLEY_HYDRAULIC_SHORT, FOLEY_SHOVEL, FOLEY_DROP, FOLEY_REVERSE_EXPLOSION, FOLEY_BUZZER,
    FOLEY_GRAVEBUSTERCHOMP
};
enum WidgetCursor { CURSOR_POINTER = 0, CURSOR_HAND };
typedef unsigned long HMUSIC;
constexpr int BASS_ATTRIB_MUSIC_VOL_CHAN = 0x100, BASS_ATTRIB_MUSIC_BPM = 0x101, BASS_ATTRIB_MUSIC_SPEED = 0x102;
struct BassIf
{
    __declspec(noinline) bool BASS_ChannelSetAttribute(HMUSIC h, int a, float v) { ZSink(RID_Bass_Set, (uint32_t)a, (uint32_t)(int)v); return true; }
    __declspec(noinline) bool BASS_ChannelGetAttribute(HMUSIC h, int a, float* v) { ZSink(RID_Bass_Get, (uint32_t)a); *v = 3.0f; return true; }
};
inline BassIf gBassImpl;
inline BassIf* gBass = &gBassImpl;
inline HMUSIC GetBassMusicHandle(MusicFile f) { ZSink(RID_GetBassHandle, (uint32_t)f); return (HMUSIC)((int)f + 100); }
