#include "ScaleEffectCompiler.h"
#include "../LogPath.h"

#include <d3dcompiler.h>

#include <cctype>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <limits>
#include <locale>
#include <set>
#include <sstream>

#pragma comment(lib, "d3dcompiler.lib")

namespace Sexy
{

namespace
{

struct FormatInfo
{
	const char*	mName;
	const char*	mSrvType;
	const char*	mUavType;
};

const FormatInfo kFormatInfos[] =
{
	{ "R32G32B32A32_FLOAT", "float4", "float4" },
	{ "R16G16B16A16_FLOAT", "MF4", "MF4" },
	{ "R16G16B16A16_UNORM", "MF4", "unorm MF4" },
	{ "R16G16B16A16_SNORM", "MF4", "snorm MF4" },
	{ "R32G32_FLOAT", "float2", "float2" },
	{ "R10G10B10A2_UNORM", "MF4", "unorm MF4" },
	{ "R11G11B10_FLOAT", "MF3", "MF3" },
	{ "R8G8B8A8_UNORM", "MF4", "unorm MF4" },
	{ "R8G8B8A8_SNORM", "MF4", "snorm MF4" },
	{ "R16G16_FLOAT", "MF2", "MF2" },
	{ "R16G16_UNORM", "MF2", "unorm MF2" },
	{ "R16G16_SNORM", "MF2", "snorm MF2" },
	{ "R32_FLOAT", "float", "float" },
	{ "R8G8_UNORM", "MF2", "unorm MF2" },
	{ "R8G8_SNORM", "MF2", "snorm MF2" },
	{ "R16_FLOAT", "MF", "MF" },
	{ "R16_UNORM", "MF", "unorm MF" },
	{ "R16_SNORM", "MF", "snorm MF" },
	{ "R8_UNORM", "MF", "unorm MF" },
	{ "R8_SNORM", "MF", "snorm MF" },
};

const FormatInfo* FindFormat(const std::string& theName)
{
	for (const FormatInfo& aInfo : kFormatInfos)
	{
		if (aInfo.mName == theName)
			return &aInfo;
	}
	return nullptr;
}

std::string Trim(const std::string& theText)
{
	size_t aStart = theText.find_first_not_of(" \t\r\n");
	if (aStart == std::string::npos)
		return "";
	size_t anEnd = theText.find_last_not_of(" \t\r\n");
	return theText.substr(aStart, anEnd - aStart + 1);
}

std::string Lower(const std::string& theText)
{
	std::string aResult = theText;
	for (size_t i = 0; i < aResult.size(); i++)
		aResult[i] = (char)tolower((unsigned char)aResult[i]);
	return aResult;
}

std::string MakeHlslFloatLiteral(float theValue)
{
	std::ostringstream aStream;
	aStream.imbue(std::locale::classic());
	aStream << std::setprecision((std::numeric_limits<float>::max_digits10)) << theValue;
	std::string aResult = aStream.str();
	if (aResult.find_first_of(".eE") == std::string::npos)
		aResult += ".0";
	aResult += "f";
	return aResult;
}

bool ParseIntList(const std::string& theText, std::vector<int>& outValues)
{
	std::string aText = theText;
	size_t aPos = 0;
	while (aPos <= aText.size())
	{
		size_t aComma = aText.find_first_of("xX,", aPos);
		std::string aPart = Trim(aText.substr(aPos, aComma == std::string::npos ? std::string::npos : aComma - aPos));
		if (aPart.empty())
			return false;
		char* anEnd = nullptr;
		long aValue = strtol(aPart.c_str(), &anEnd, 10);
		if (anEnd == aPart.c_str() || aValue <= 0)
			return false;
		outValues.push_back((int)aValue);
		if (aComma == std::string::npos)
			break;
		aPos = aComma + 1;
	}
	return !outValues.empty();
}

// Removes // and /* */ comments while preserving //! metadata lines.
std::string StripComments(const std::string& theSource)
{
	std::istringstream aStream(theSource);
	std::string aResult;
	std::string aLine;
	bool aInBlockComment = false;
	while (std::getline(aStream, aLine))
	{
		bool aKeptMeta = false;
		if (!aInBlockComment)
		{
			size_t aPos = 0;
			while (aPos < aLine.size())
			{
				if (aLine[aPos] == '/' && aPos + 1 < aLine.size() && aLine[aPos + 1] == '*')
				{
					aInBlockComment = true;
					aPos += 2;
				}
				else if (aLine[aPos] == '/' && aPos + 1 < aLine.size() && aLine[aPos + 1] == '/')
				{
					// Keep metadata lines; drop other line comments.
					if (aPos + 2 < aLine.size() && aLine[aPos + 2] == '!')
					{
						aResult += aLine.substr(aPos);
						aKeptMeta = true;
						aPos = aLine.size();
					}
					else
					{
						aLine.erase(aPos);
					}
					break;
				}
				else
				{
					++aPos;
				}
			}
			if (!aInBlockComment && !aKeptMeta)
				aResult += aLine;
		}
		else
		{
			size_t aEnd = aLine.find("*/");
			if (aEnd != std::string::npos)
			{
				aInBlockComment = false;
				aResult += aLine.substr(aEnd + 2);
			}
		}
		aResult += '\n';
	}
	return aResult;
}

std::string GetOption(const std::string& theLine, const char* theKey)
{
	std::string aTrimmed = Trim(theLine);
	std::string aKey = Lower(theKey);
	if (aTrimmed.size() > 3 && aTrimmed.compare(0, 3, "//!") == 0)
		aTrimmed = Trim(aTrimmed.substr(3));
	if (Lower(aTrimmed).compare(0, aKey.size(), aKey) != 0)
		return "";
	return Trim(aTrimmed.substr(aKey.size()));
}

bool IsBlockStart(const std::string& theLine, std::string& outKeyword)
{
	std::string aTrimmed = Trim(theLine);
	if (aTrimmed.size() <= 3 || aTrimmed.compare(0, 3, "//!") != 0)
		return false;
	std::string aBody = Trim(aTrimmed.substr(3));
	static const char* kKeywords[] = { "PARAMETER", "TEXTURE", "SAMPLER", "COMMON", "PASS" };
	for (const char* aKeyword : kKeywords)
	{
		if (Lower(aBody).compare(0, strlen(aKeyword), Lower(aKeyword)) == 0)
		{
			outKeyword = Lower(aKeyword);
			return true;
		}
	}
	return false;
}

} // namespace

class PassInclude : public ID3DInclude
{
public:
	explicit PassInclude(const std::string& theBaseDir) : mBaseDir(theBaseDir) {}

	HRESULT STDMETHODCALLTYPE Open(
		D3D_INCLUDE_TYPE,
		LPCSTR pFileName,
		LPCVOID,
		LPCVOID* ppData,
		UINT* pBytes) override
	{
		std::string aPath = mBaseDir + "/" + pFileName;
		std::ifstream aFile(aPath, std::ios::binary);
		if (!aFile)
			return E_FAIL;
		std::string aData((std::istreambuf_iterator<char>(aFile)), std::istreambuf_iterator<char>());
		char* aCopy = new char[aData.size()];
		std::memcpy(aCopy, aData.data(), aData.size());
		*ppData = aCopy;
		*pBytes = (UINT)aData.size();
		return S_OK;
	}

	HRESULT STDMETHODCALLTYPE Close(LPCVOID pData) override
	{
		delete[] (char*)pData;
		return S_OK;
	}

private:
	std::string mBaseDir;
};

bool ScaleEffectCompiler::CompileEffect(const std::string& thePath, ScaleEffectDesc& outDesc)

{
	return CompileEffect(thePath, ScaleEffectParams(), outDesc);
}

bool ScaleEffectCompiler::CompileEffect(
	const std::string& thePath,
	const ScaleEffectParams& theInlineParams,
	ScaleEffectDesc& outDesc)
{
	outDesc = ScaleEffectDesc();
	outDesc.mName = thePath;
	outDesc.mSourcePath = thePath;
	if (outDesc.mName.size() > 5 &&
		Lower(outDesc.mName.substr(outDesc.mName.size() - 5)) == ".hlsl")
		outDesc.mName.erase(outDesc.mName.size() - 5);
	// Strip a leading "effects/" prefix from the display name.
	if (Lower(outDesc.mName).compare(0, 8, "effects/") == 0)
		outDesc.mName.erase(0, 8);

	if (!ParseEffect(thePath, outDesc))
		return false;
	if (!ResolveInlineParams(outDesc, theInlineParams, outDesc.mInlineParams, outDesc.mError))
		return false;
	outDesc.mInlineParamsEnabled = true;
	return GenerateAndCompilePasses(outDesc);
}

bool ScaleEffectCompiler::ResolveInlineParams(
	const ScaleEffectDesc& theDesc,
	const ScaleEffectParams& theOverrides,
	ScaleEffectParams& outResolved,
	std::string& outError)
{
	outResolved.clear();
	outError.clear();
	std::set<std::string> aUsedOverrideNames;
	std::set<std::string> aDeclaredNames;

	for (const ScaleEffectParamDesc& aParam : theDesc.mParams)
	{
		const std::string aLowerName = Lower(aParam.mName);
		if (!aDeclaredNames.insert(aLowerName).second)
		{
			outError = "duplicate PARAMETER name: " + aParam.mName;
			return false;
		}

		float aValue = aParam.mDefault;
		bool aFound = false;
		for (const auto& anOverride : theOverrides)
		{
			if (Lower(anOverride.first) != aLowerName)
				continue;
			if (aFound)
			{
				outError = "duplicate case-insensitive parameter override: " + aParam.mName;
				return false;
			}
			aValue = anOverride.second;
			aUsedOverrideNames.insert(Lower(anOverride.first));
			aFound = true;
		}

		if (!std::isfinite(aValue))
		{
			outError = "non-finite parameter value: " + aParam.mName;
			return false;
		}

		if (aParam.mIsInt)
		{
			const double aRounded = std::round((double)aValue);
			if (aRounded < (double)(std::numeric_limits<int>::min)() ||
				aRounded > (double)(std::numeric_limits<int>::max)())
			{
				outError = "integer parameter is outside int range: " + aParam.mName;
				return false;
			}
			aValue = (float)(int)aRounded;
		}

		if (aValue < aParam.mMin || aValue > aParam.mMax)
		{
			std::ostringstream aMessage;
			aMessage << "parameter out of range: " << aParam.mName << "=" << aValue
				<< " expected [" << aParam.mMin << ", " << aParam.mMax << "]";
			outError = aMessage.str();
			return false;
		}

		outResolved[aParam.mName] = aValue;
	}

	for (const auto& anOverride : theOverrides)
	{
		if (aUsedOverrideNames.find(Lower(anOverride.first)) == aUsedOverrideNames.end())
		{
			outError = "unknown parameter: " + anOverride.first;
			return false;
		}
	}
	return true;
}

bool ScaleEffectCompiler::CompileAll(const std::string& theEffectsDir, std::vector<ScaleEffectDesc>& outEffects)
{
	outEffects.clear();

	// Enumerate *.hlsl recursively (Anime4K lives in a subdirectory).
	std::vector<std::string> aFiles;
	std::string aFindCmd = "cmd /c dir /s /b \"" + theEffectsDir + "\\*.hlsl\"";
	FILE* aPipe = _popen(aFindCmd.c_str(), "r");
	if (aPipe != nullptr)
	{
		char aBuffer[1024];
		while (fgets(aBuffer, sizeof(aBuffer), aPipe) != nullptr)
		{
			std::string aLine = aBuffer;
			while (!aLine.empty() && (aLine.back() == '\n' || aLine.back() == '\r'))
				aLine.pop_back();
			if (!aLine.empty())
			{
				// Normalize to a path relative to the effects dir with
				// forward slashes so it matches scale.xml effect entries.
				size_t aPos = aLine.rfind("\\effects\\");
				if (aPos == std::string::npos)
					aPos = aLine.rfind("/effects/");
				if (aPos != std::string::npos)
					aLine.erase(0, aPos + 9); // "\effects\" = 9 chars
				for (char& aChar : aLine)
					if (aChar == '\\')
						aChar = '/';
				aFiles.push_back(aLine);
			}
		}
		_pclose(aPipe);
	}

	FILE* aLog = fopen(GetLogFilePathC("effects-compile.log"), "w");
	if (aLog != nullptr)
		fprintf(aLog, "effects dir: %s\n", theEffectsDir.c_str());

	bool aAllOk = true;
	for (const std::string& aFile : aFiles)
	{
		ScaleEffectDesc aDesc;
		std::string aOpenPath = theEffectsDir + "/" + aFile;
		if (CompileEffect(aOpenPath, aDesc))
		{
			outEffects.push_back(std::move(aDesc));
			if (aLog != nullptr)
			{
				ScaleEffectDesc& aRef = outEffects.back();
				fprintf(aLog, "OK %s passes=%d\n", aRef.mName.c_str(), (int)aRef.mPasses.size());
			}
		}
		else
		{
			aAllOk = false;
			if (aLog != nullptr)
			{
				fprintf(aLog, "FAIL %s: %s\n", aFile.c_str(), aDesc.mError.c_str());
				fprintf(aLog, "  textures=%d passes=%d\n",
					(int)aDesc.mTextures.size(), (int)aDesc.mPasses.size());
				if (!aDesc.mPasses.empty() && !aDesc.mPasses[0].mInputs.empty())
					fprintf(aLog, "  pass1 inputs: [%s]\n", aDesc.mPasses[0].mInputs[0].c_str());
				if (!aDesc.mPasses.empty())
					fprintf(aLog, "  pass1 style=%d block=%dx%d threads=%dx%dx%d\n",
						aDesc.mPasses[0].mPSStyle ? 1 : 0,
						aDesc.mPasses[0].mBlockWidth,
						aDesc.mPasses[0].mBlockHeight,
						aDesc.mPasses[0].mNumThreadsX,
						aDesc.mPasses[0].mNumThreadsY,
						aDesc.mPasses[0].mNumThreadsZ);
			}
		}
	}

	if (aLog != nullptr)
		fclose(aLog);
	return aAllOk;
}

bool ScaleEffectCompiler::ParseEffect(const std::string& thePath, ScaleEffectDesc& ioDesc)
{
	std::ifstream aFile(thePath, std::ios::binary);
	if (!aFile)
	{
		ioDesc.mError = "cannot open " + thePath;
		return false;
	}
	std::string aSource((std::istreambuf_iterator<char>(aFile)), std::istreambuf_iterator<char>());
	std::string aStripped = StripComments(aSource);
	std::istringstream aStream(aStripped);

	std::string aLine;
	std::vector<std::string> aLines;
	while (std::getline(aStream, aLine))
		aLines.push_back(aLine);

	// Collect blocks: header + PARAMETER/TEXTURE/SAMPLER/COMMON/PASS.
	struct Block
	{
		std::string				mKeyword;
		std::vector<std::string> mOptionLines;
		std::vector<std::string> mCodeLines;
	};
	std::vector<Block> aBlocks;
	Block* aCurrent = nullptr;
	bool aSawMagic = false;

	for (const std::string& aRawLine : aLines)
	{
		std::string aTrimmed = Trim(aRawLine);
		if (aTrimmed.empty())
		{
			if (aCurrent != nullptr)
				aCurrent->mCodeLines.push_back(aRawLine);
			continue;
		}

		std::string aKeyword;
		if (IsBlockStart(aTrimmed, aKeyword))
		{
			aBlocks.push_back(Block());
			aCurrent = &aBlocks.back();
			aCurrent->mKeyword = aKeyword;
			continue;
		}

		if (aTrimmed.compare(0, 3, "//!") == 0)
		{
			if (aCurrent != nullptr)
				aCurrent->mOptionLines.push_back(aTrimmed);
			else
			{
				// Header options.
				std::string aBody = Trim(aTrimmed.substr(3));
				if (Lower(aBody).compare(0, 13, "magpie effect") == 0)
					aSawMagic = true;
				// VERSION/SORT_NAME/USE/CAPABILITY are validated loosely below.
				aBlocks.push_back(Block());
				aCurrent = &aBlocks.back();
				aCurrent->mKeyword = "header";
				aCurrent->mOptionLines.push_back(aTrimmed);
			}
			continue;
		}

		if (aCurrent != nullptr)
			aCurrent->mCodeLines.push_back(aRawLine);
		else if (aTrimmed.compare(0, 8, "#include") != 0)
		{
			ioDesc.mError = "code before any block";
			return false;
		}
	}

	if (!aSawMagic && !aBlocks.empty() && aBlocks[0].mKeyword == "header")
	{
		// Fall back: first header block counts as magic if it has VERSION.
		for (const std::string& aLine2 : aBlocks[0].mOptionLines)
			if (Lower(GetOption(aLine2, "version")) == "4")
				aSawMagic = true;
	}
	if (!aSawMagic)
	{
		ioDesc.mError = "missing //!MAGPIE EFFECT";
		return false;
	}

	for (const Block& aBlock : aBlocks)
	{
		if (aBlock.mKeyword == "header")
			continue;

		if (aBlock.mKeyword == "parameter")
		{
			ScaleEffectParamDesc aParam;
			bool aHasDefault = false;
			bool aHasMin = false;
			bool aHasMax = false;
			bool aHasStep = false;
			for (const std::string& aOpt : aBlock.mOptionLines)
			{
				std::string aValue = GetOption(aOpt, "default");
				if (!aValue.empty()) { aParam.mDefault = (float)atof(aValue.c_str()); aHasDefault = true; }
				aValue = GetOption(aOpt, "min");
				if (!aValue.empty()) { aParam.mMin = (float)atof(aValue.c_str()); aHasMin = true; }
				aValue = GetOption(aOpt, "max");
				if (!aValue.empty()) { aParam.mMax = (float)atof(aValue.c_str()); aHasMax = true; }
				aValue = GetOption(aOpt, "step");
				if (!aValue.empty()) { aParam.mStep = (float)atof(aValue.c_str()); aHasStep = true; }
			}
			if (!aHasDefault || !aHasMin || !aHasMax || !aHasStep ||
				!std::isfinite(aParam.mDefault) || !std::isfinite(aParam.mMin) ||
				!std::isfinite(aParam.mMax) || !std::isfinite(aParam.mStep) ||
				aParam.mMin > aParam.mMax || aParam.mStep <= 0.0f)
			{
				ioDesc.mError = "bad PARAMETER metadata";
				return false;
			}
			std::string aCode = "";
			for (const std::string& aCodeLine : aBlock.mCodeLines)
				aCode += Trim(aCodeLine) + " ";
			aCode = Trim(aCode);
			if (aCode.compare(0, 5, "float") == 0 && aCode.find(';') != std::string::npos)
				aParam.mIsInt = false;
			else if (aCode.compare(0, 3, "int") == 0 && aCode.find(';') != std::string::npos)
				aParam.mIsInt = true;
			else
			{
				ioDesc.mError = "bad PARAMETER block";
				return false;
			}
			// Name is the token before ';'.
			size_t aSemi = aCode.find(';');
			std::string aDecl = Trim(aCode.substr(0, aSemi));
			size_t aSpace = aDecl.find_last_of(' ');
			aParam.mName = aSpace == std::string::npos ? aDecl : aDecl.substr(aSpace + 1);
			ioDesc.mParams.push_back(aParam);
		}
		else if (aBlock.mKeyword == "texture")
		{
			ScaleEffectTextureDesc aTex;
			for (const std::string& aOpt : aBlock.mOptionLines)
			{
				std::string aValue = GetOption(aOpt, "width");
				if (!aValue.empty()) aTex.mWidthExpr = aValue;
				aValue = GetOption(aOpt, "height");
				if (!aValue.empty()) aTex.mHeightExpr = aValue;
				aValue = GetOption(aOpt, "format");
				if (!aValue.empty()) aTex.mFormat = aValue;
			}
			std::string aCode = "";
			for (const std::string& aCodeLine : aBlock.mCodeLines)
				aCode += Trim(aCodeLine) + " ";
			aCode = Trim(aCode);
			size_t aSemi = aCode.find(';');
			if (aCode.compare(0, 9, "Texture2D") != 0 || aSemi == std::string::npos)
			{
				ioDesc.mError = "bad TEXTURE block";
				return false;
			}
			std::string aDecl = Trim(aCode.substr(9, aSemi - 9));
			aTex.mName = Trim(aDecl);
			ioDesc.mTextures.push_back(aTex);
		}
		else if (aBlock.mKeyword == "sampler")
		{
			ScaleEffectSamplerDesc aSam;
			for (const std::string& aOpt : aBlock.mOptionLines)
			{
				std::string aValue = GetOption(aOpt, "filter");
				if (!aValue.empty()) aSam.mFilter = Lower(aValue);
				aValue = GetOption(aOpt, "address");
				if (!aValue.empty()) aSam.mAddress = Lower(aValue);
			}
			std::string aCode = "";
			for (const std::string& aCodeLine : aBlock.mCodeLines)
				aCode += Trim(aCodeLine) + " ";
			aCode = Trim(aCode);
			size_t aSemi = aCode.find(';');
			if (aCode.compare(0, 12, "SamplerState") != 0 || aSemi == std::string::npos)
			{
				ioDesc.mError = "bad SAMPLER block";
				return false;
			}
			std::string aDecl = Trim(aCode.substr(12, aSemi - 12));
			aSam.mName = Trim(aDecl);
			ioDesc.mSamplers.push_back(aSam);
		}
		else if (aBlock.mKeyword == "common")
		{
			std::string aCommon;
			for (const std::string& aCodeLine : aBlock.mCodeLines)
				aCommon += aCodeLine + "\n";
			ioDesc.mCommonBlocks.push_back(aCommon);
		}
		else if (aBlock.mKeyword == "pass")
		{
			ScaleEffectPassDesc aPass;
			aPass.mPSStyle = false;
			aPass.mBlockWidth = 8;
			aPass.mBlockHeight = 8;
			aPass.mNumThreadsX = 8;
			aPass.mNumThreadsY = 8;
			aPass.mNumThreadsZ = 1;

			{
				FILE* aDump = fopen(GetLogFilePathC("parse-debug.log"), "a");
				if (aDump != NULL)
				{
					fprintf(aDump, "=== pass block, options=%d ===\n", (int)aBlock.mOptionLines.size());
					for (const std::string& aOpt : aBlock.mOptionLines)
						fprintf(aDump, "  opt=[%s]\n", aOpt.c_str());
					fclose(aDump);
				}
			}

			for (const std::string& aOpt : aBlock.mOptionLines)
			{
				std::string aValue = GetOption(aOpt, "in");
				if (!aValue.empty())
				{
					std::string aName;
					std::istringstream aList(aValue);
					while (std::getline(aList, aName, ','))
						aPass.mInputs.push_back(Trim(aName));
				}
				aValue = GetOption(aOpt, "out");
				if (!aValue.empty())
				{
					std::string aName;
					std::istringstream aList(aValue);
					while (std::getline(aList, aName, ','))
						aPass.mOutputs.push_back(Trim(aName));
				}
				aValue = GetOption(aOpt, "style");
				if (!aValue.empty())
					aPass.mPSStyle = Lower(aValue) == "ps";
				aValue = GetOption(aOpt, "desc");
				if (!aValue.empty())
					aPass.mDesc = aValue;
				aValue = GetOption(aOpt, "block_size");
				if (!aValue.empty())
				{
					std::vector<int> aSizes;
					if (ParseIntList(aValue, aSizes) && aSizes.size() <= 2)
					{
						aPass.mBlockWidth = aSizes[0];
						aPass.mBlockHeight = aSizes.size() == 2 ? aSizes[1] : aSizes[0];
					}
				}
				aValue = GetOption(aOpt, "num_threads");
				if (!aValue.empty())
				{
					std::vector<int> aSizes;
					if (ParseIntList(aValue, aSizes) && aSizes.size() <= 3)
					{
						aPass.mNumThreadsX = aSizes[0];
						aPass.mNumThreadsY = aSizes.size() >= 2 ? aSizes[1] : 1;
						aPass.mNumThreadsZ = aSizes.size() == 3 ? aSizes[2] : 1;
					}
				}
			}

			for (const std::string& aCodeLine : aBlock.mCodeLines)
				aPass.mCode += aCodeLine + "\n";

			aPass.mIndex = (int)ioDesc.mPasses.size() + 1;
			ioDesc.mPasses.push_back(aPass);
		}
	}

	if (ioDesc.mPasses.empty())
	{
		ioDesc.mError = "no PASS blocks";
		return false;
	}
	return true;
}

const ScaleEffectTextureDesc* FindTexture(const ScaleEffectDesc& theDesc, const std::string& theName)
{
	for (const ScaleEffectTextureDesc& aTex : theDesc.mTextures)
		if (aTex.mName == theName)
			return &aTex;
	return nullptr;
}

bool ScaleEffectCompiler::GenerateAndCompilePasses(ScaleEffectDesc& ioDesc)
{
	ioDesc.mCompiledCSOs.clear();
	ioDesc.mCompiledCSOs.resize(ioDesc.mPasses.size());

	const size_t aPassCount = ioDesc.mPasses.size();
	for (size_t i = 0; i < aPassCount; i++)
	{
		const ScaleEffectPassDesc& aPass = ioDesc.mPasses[i];

		std::string aSource;
		aSource.reserve(4096 + aPass.mCode.size());

		// Constant buffer.
		aSource += "cbuffer __CB1 : register(b0) {\n";
		aSource += "\tuint2 __inputSize;\n";
		aSource += "\tuint2 __outputSize;\n";
		aSource += "\tfloat2 __inputPt;\n";
		aSource += "\tfloat2 __outputPt;\n";
		aSource += "\tfloat2 __scale;\n";
		for (size_t j = 0; j < aPassCount - 1; j++)
		{
			if (ioDesc.mPasses[j].mPSStyle)
			{
				char aBuf[128];
				snprintf(aBuf, sizeof(aBuf), "\tuint2 __pass%zuOutputSize;\n\tfloat2 __pass%zuOutputPt;\n", j + 1, j + 1);
				aSource += aBuf;
			}
		}
		aSource += "};\n\n";

		// Magpie InlineParams: user PARAMETER values are shader constants rather
		// than members of __CB1.  This lets D3DCompile fold branches and unroll
		// loops whose limits come from scale.xml while keeping size builtins
		// dynamic for window/fullscreen targets.
		for (const ScaleEffectParamDesc& aParam : ioDesc.mParams)
		{
			auto anItr = ioDesc.mInlineParams.find(aParam.mName);
			if (anItr == ioDesc.mInlineParams.end())
			{
				ioDesc.mError = "resolved inline parameter missing: " + aParam.mName;
				return false;
			}
			aSource += "static const ";
			aSource += aParam.mIsInt ? "int " : "float ";
			aSource += aParam.mName;
			aSource += " = ";
			aSource += aParam.mIsInt
				? std::to_string((int)anItr->second)
				: MakeHlslFloatLiteral(anItr->second);
			aSource += ";\n";
		}
		if (!ioDesc.mParams.empty())
			aSource += "\n";

		// SRV inputs.
		int aSrvSlot = 0;
		for (const std::string& aInput : aPass.mInputs)
		{
			const ScaleEffectTextureDesc* aTex = FindTexture(ioDesc, aInput);
			if (aTex == nullptr)
			{
				ioDesc.mError = "pass input not declared: " + aInput;
				return false;
			}
			std::string aFormat = aTex->mFormat.empty() ? "R8G8B8A8_UNORM" : aTex->mFormat;
			const FormatInfo* aInfo = FindFormat(aFormat);
			if (aInfo == nullptr)
			{
				ioDesc.mError = "unknown texture format: " + aFormat;
				return false;
			}
			char aBuf[256];
			snprintf(aBuf, sizeof(aBuf), "Texture2D<%s> %s : register(t%d);\n", aInfo->mSrvType, aInput.c_str(), aSrvSlot++);
			aSource += aBuf;
		}

		// UAV outputs.
		int aUavSlot = 0;
		for (const std::string& aOutput : aPass.mOutputs)
		{
			const ScaleEffectTextureDesc* aTex = FindTexture(ioDesc, aOutput);
			if (aTex == nullptr)
			{
				ioDesc.mError = "pass output not declared: " + aOutput;
				return false;
			}
			std::string aFormat = aTex->mFormat.empty() ? "R8G8B8A8_UNORM" : aTex->mFormat;
			const FormatInfo* aInfo = FindFormat(aFormat);
			if (aInfo == nullptr)
			{
				ioDesc.mError = "unknown texture format: " + aFormat;
				return false;
			}
			char aBuf[256];
			snprintf(aBuf, sizeof(aBuf), "RWTexture2D<%s> %s : register(u%d);\n", aInfo->mUavType, aOutput.c_str(), aUavSlot++);
			aSource += aBuf;
		}

		// Samplers.
		int aSamplerSlot = 0;
		for (const ScaleEffectSamplerDesc& aSam : ioDesc.mSamplers)
		{
			char aBuf[256];
			snprintf(aBuf, sizeof(aBuf), "SamplerState %s : register(s%d);\n", aSam.mName.c_str(), aSamplerSlot++);
			aSource += aBuf;
		}
		aSource += "\n";

		// Builtins.
		aSource +=
			"uint __Bfe(uint src, uint off, uint bits) { uint mask = (1u << bits) - 1; return (src >> off) & mask; }\n"
			"uint __BfiM(uint src, uint ins, uint bits) { uint mask = (1u << bits) - 1; return (ins & mask) | (src & (~mask)); }\n"
			"uint2 Rmp8x8(uint a) { return uint2(__Bfe(a, 1u, 3u), __BfiM(__Bfe(a, 3u, 3u), a, 1u)); }\n"
			"uint2 GetInputSize() { return __inputSize; }\n"
			"float2 GetInputPt() { return __inputPt; }\n"
			"uint2 GetOutputSize() { return __outputSize; }\n"
			"float2 GetOutputPt() { return __outputPt; }\n"
			"float2 GetScale() { return __scale; }\n"
			"MF2 MulAdd(MF2 x, MF2x2 y, MF2 a) { return mul(x, y) + a; }\n"
			"MF3 MulAdd(MF2 x, MF2x3 y, MF3 a) { return mul(x, y) + a; }\n"
			"MF4 MulAdd(MF2 x, MF2x4 y, MF4 a) { return mul(x, y) + a; }\n"
			"MF2 MulAdd(MF3 x, MF3x2 y, MF2 a) { return mul(x, y) + a; }\n"
			"MF3 MulAdd(MF3 x, MF3x3 y, MF3 a) { return mul(x, y) + a; }\n"
			"MF4 MulAdd(MF3 x, MF3x4 y, MF4 a) { return mul(x, y) + a; }\n"
			"MF2 MulAdd(MF4 x, MF4x2 y, MF2 a) { return mul(x, y) + a; }\n"
			"MF3 MulAdd(MF4 x, MF4x3 y, MF3 a) { return mul(x, y) + a; }\n"
			"MF4 MulAdd(MF4 x, MF4x4 y, MF4 a) { return mul(x, y) + a; }\n"
			"\n";

		// COMMON blocks.
		for (const std::string& aCommon : ioDesc.mCommonBlocks)
			aSource += aCommon + "\n";

		// Pass code.
		aSource += aPass.mCode;
		aSource += "\n";

		// Entry.
		if (aPass.mPSStyle)
		{
			std::string aOutputSize = i + 1 == aPassCount ? "__outputSize" : (std::string) "__pass" + std::to_string(i + 1) + "OutputSize";
			std::string aOutputPt = i + 1 == aPassCount ? "__outputPt" : (std::string) "__pass" + std::to_string(i + 1) + "OutputPt";
			if (aPass.mOutputs.empty())
			{
				ioDesc.mError = "PS pass has no output";
				return false;
			}
			char aBuf[1024];
			snprintf(
				aBuf,
				sizeof(aBuf),
				"[numthreads(64, 1, 1)]\n"
				"void __M(uint3 tid : SV_GroupThreadID, uint3 gid : SV_GroupID) {\n"
				"\tuint2 gxy = (gid.xy << 4u) + Rmp8x8(tid.x);\n"
				"\tif (gxy.x >= %s.x || gxy.y >= %s.y) return;\n"
				"\tfloat2 pos = (gxy + 0.5f) * %s;\n"
				"\tfloat2 step = 8 * %s;\n"
				"\t%s[gxy] = Pass%d(pos);\n"
				"\tgxy.x += 8u; pos.x += step.x;\n"
				"\tif (gxy.x < %s.x && gxy.y < %s.y) %s[gxy] = Pass%d(pos);\n"
				"\tgxy.y += 8u; pos.y += step.y;\n"
				"\tif (gxy.x < %s.x && gxy.y < %s.y) %s[gxy] = Pass%d(pos);\n"
				"\tgxy.x -= 8u; pos.x -= step.x;\n"
				"\tif (gxy.x < %s.x && gxy.y < %s.y) %s[gxy] = Pass%d(pos);\n"
				"}\n",
				aOutputSize.c_str(), aOutputSize.c_str(), aOutputPt.c_str(), aOutputPt.c_str(),
				aPass.mOutputs[0].c_str(), aPass.mIndex,
				aOutputSize.c_str(), aOutputSize.c_str(), aPass.mOutputs[0].c_str(), aPass.mIndex,
				aOutputSize.c_str(), aOutputSize.c_str(), aPass.mOutputs[0].c_str(), aPass.mIndex,
				aOutputSize.c_str(), aOutputSize.c_str(), aPass.mOutputs[0].c_str(), aPass.mIndex);
			aSource += aBuf;
		}
		else
		{
			char aBuf[512];
			snprintf(
				aBuf,
				sizeof(aBuf),
				"[numthreads(%d, %d, %d)]\n"
				"void __M(uint3 tid : SV_GroupThreadID, uint3 gid : SV_GroupID) {\n"
				"\tPass%d(gid.xy * uint2(%d, %d), tid);\n"
				"}\n",
				aPass.mNumThreadsX, aPass.mNumThreadsY, aPass.mNumThreadsZ,
				aPass.mIndex, aPass.mBlockWidth, aPass.mBlockHeight);
			aSource += aBuf;
		}

		// Compile.
		std::vector<std::pair<std::string, std::string>> aMacroPairs;
		auto AddMacro = [&](const std::string& theName, const std::string& theValue)
		{
			aMacroPairs.emplace_back(theName, theValue);
		};
		AddMacro("MP_BLOCK_WIDTH", std::to_string(aPass.mBlockWidth));
		AddMacro("MP_BLOCK_HEIGHT", std::to_string(aPass.mBlockHeight));
		AddMacro("MP_NUM_THREADS_X", std::to_string(aPass.mNumThreadsX));
		AddMacro("MP_NUM_THREADS_Y", std::to_string(aPass.mNumThreadsY));
		AddMacro("MP_NUM_THREADS_Z", std::to_string(aPass.mNumThreadsZ));
		if (aPass.mPSStyle)
			AddMacro("MP_PS_STYLE", "");
		AddMacro("MP_INLINE_PARAMS", "");
		AddMacro("MF", "float");
		const char* aDigits[] = { "1", "2", "3", "4" };
		for (int k = 0; k < 4; k++)
		{
			AddMacro(std::string("MF") + aDigits[k], std::string("float") + aDigits[k]);
			for (int m = 0; m < 4; m++)
			{
				AddMacro(
					std::string("MF") + aDigits[k] + "x" + aDigits[m],
					std::string("float") + aDigits[k] + "x" + aDigits[m]);
			}
		}

		std::vector<D3D_SHADER_MACRO> aMacros;
		for (const auto& aPair : aMacroPairs)
			aMacros.push_back(D3D_SHADER_MACRO{ aPair.first.c_str(), aPair.second.c_str() });
		aMacros.push_back(D3D_SHADER_MACRO{ nullptr, nullptr });

		UINT aFlags = D3DCOMPILE_ENABLE_STRICTNESS | D3DCOMPILE_ALL_RESOURCES_BOUND;
#ifdef _DEBUG
		aFlags |= D3DCOMPILE_SKIP_OPTIMIZATION | D3DCOMPILE_DEBUG;
#else
		aFlags |= D3DCOMPILE_OPTIMIZATION_LEVEL3;
#endif

		std::string aBaseDir = "effects";
		size_t aSlash = ioDesc.mSourcePath.find_last_of("/\\");
		if (aSlash != std::string::npos)
			aBaseDir = ioDesc.mSourcePath.substr(0, aSlash);
		PassInclude aInclude(aBaseDir);

		ID3DBlob* aBlob = nullptr;
		ID3DBlob* anError = nullptr;
		std::string aSourceName = ioDesc.mName + "_Pass" + std::to_string(i + 1) + ".hlsl";
		HRESULT aResult = D3DCompile(
			aSource.data(),
			aSource.size(),
			aSourceName.c_str(),
			aMacros.data(),
			&aInclude,
			"__M",
			"cs_5_0",
			aFlags,
			0,
			&aBlob,
			&anError);
		if (FAILED(aResult))
		{
			{
				// Save the generated source for debugging failed passes.
				FILE* aFail = fopen(GetLogFilePathC("effect-fail.hlsl"), "w");
				if (aFail != NULL)
				{
					fwrite(aSource.data(), 1, aSource.size(), aFail);
					fclose(aFail);
				}
			}
			if (anError != nullptr)
			{
				ioDesc.mError = "D3DCompile failed: ";
				ioDesc.mError += (const char*)anError->GetBufferPointer();
				anError->Release();
			}
			else
				ioDesc.mError = "D3DCompile failed";
			return false;
		}
		if (anError != nullptr)
			anError->Release();

		ioDesc.mCompiledCSOs[i].assign(
			(const uint8_t*)aBlob->GetBufferPointer(),
			(const uint8_t*)aBlob->GetBufferPointer() + aBlob->GetBufferSize());
		aBlob->Release();
	}

	ioDesc.mCompiled = true;
	return true;
}

}
