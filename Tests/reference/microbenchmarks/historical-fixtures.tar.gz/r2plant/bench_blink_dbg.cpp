// 调试 kBlinkCases checksum 分歧：逐迭代对比 g_ck / g_rng
#define NIN_DBG 4096
#include "r2_stub.h"
inline unsigned Rand(unsigned n) { MixCk(0x1090ULL, n); return n ? RngNext() % n : 0u; }
#include "bench_blink_bodies.h"

int main()
{
    InitZombiePool();
    gSexyAppBase = &g_app;

    static FA::Plant pA; static FB::Plant pB;
    static In in[NIN_DBG];
    GenInputs(in, NIN_DBG, 0x8888, 53, 8, 8, 5);

    for (int i = 0; i < NIN_DBG; i++)
    {
        pA.mSeedType = (SeedType)in[i].a; pA.mHeadReanimID = in[i].b; pA.mHeadReanimID2 = in[i].c; pA.mBodyReanimID = in[i].d;
        pB.mSeedType = (SeedType)in[i].a; pB.mHeadReanimID = in[i].b; pB.mHeadReanimID2 = in[i].c; pB.mBodyReanimID = in[i].d;

        g_ck = 1000; RngReset();
        Reanimation* rA = pA.AttachBlinkAnim(&g_reanimPool[pA.mBodyReanimID & 7]);
        uint64_t ckA = g_ck, rngA = g_rng; uintptr_t rpa = (uintptr_t)rA;

        g_ck = 1000; RngReset();
        Reanimation* rB = pB.AttachBlinkAnim(&g_reanimPool[pB.mBodyReanimID & 7]);
        uint64_t ckB = g_ck, rngB = g_rng; uintptr_t rpb = (uintptr_t)rB;

        if (ckA != ckB || rngA != rngB || rpa != rpb)
        {
            printf("iter %d seed=%d b=%d c=%d d=%d  ckA=%016llx ckB=%016llx rngA=%016llx rngB=%016llx retA=%llx retB=%llx\n",
                i, in[i].a, in[i].b, in[i].c, in[i].d,
                (unsigned long long)ckA, (unsigned long long)ckB,
                (unsigned long long)rngA, (unsigned long long)rngB,
                (unsigned long long)rpa, (unsigned long long)rpb);
            if (i > 40) break;
        }
    }
    printf("done\n");
    return 0;
}
