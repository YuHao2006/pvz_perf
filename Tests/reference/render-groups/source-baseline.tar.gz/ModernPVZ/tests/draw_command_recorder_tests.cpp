#include "pvz/render/draw_command_recorder.hpp"

#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <stdexcept>

namespace {

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void require_near(const float actual, const float expected, const char* message)
{
    require(std::abs(actual - expected) < 0.00001F, message);
}

pvz::render::DrawCommandRecorder make_recorder()
{
    return {17, {800.0, 600.0}, {{0.0, 0.0}, {1600.0, 1200.0}}, 0.25};
}

void test_consecutive_draws_with_matching_state_are_batched()
{
    auto recorder = make_recorder();
    recorder.fill_rect({{10.0, 20.0}, {30.0, 40.0}}, pvz::render::pack_rgba8(1, 2, 3, 255));
    recorder.fill_rect({{50.0, 60.0}, {70.0, 80.0}}, pvz::render::pack_rgba8(4, 5, 6, 255));
    recorder.fill_rect(
        {{100.0, 110.0}, {20.0, 30.0}},
        pvz::render::pack_rgba8(7, 8, 9, 128),
        pvz::render::BlendMode::additive);

    const auto frame = recorder.frame();
    require(frame.frame_index == 17, "frame metadata must be preserved");
    require(frame.vertices.size() == 12, "three rectangles must emit twelve vertices");
    require(frame.indices.size() == 18, "three rectangles must emit eighteen indices");
    require(frame.batches.size() == 2, "matching consecutive states must merge into one batch");
    require(frame.batches[0].index_count == 12, "merged batch must cover both normal rectangles");
    require(frame.batches[1].first_index == 12, "additive batch must preserve draw ordering");
    require(frame.batches[1].blend_mode == pvz::render::BlendMode::additive,
            "additive state must be retained");
}

void test_sprite_pixels_are_normalized_and_can_be_mirrored()
{
    auto recorder = make_recorder();
    const pvz::render::TextureRegion source{
        {9},
        {100.0, 50.0},
        {{10.0, 5.0}, {20.0, 10.0}},
    };
    constexpr pvz::render::SamplingState sampling{
        pvz::render::TextureFilter::linear,
        pvz::render::TextureAddressMode::repeat,
        pvz::render::TextureAddressMode::clamp,
    };
    recorder.draw_sprite(
        source,
        {{30.0, 40.0}, {60.0, 20.0}},
        pvz::render::pack_rgba8(255, 128, 64, 200),
        pvz::render::BlendMode::alpha,
        {},
        sampling,
        true,
        false);

    const auto frame = recorder.frame();
    require(frame.batches.size() == 1, "one sprite must emit one batch");
    require(frame.batches[0].texture.value == 9, "sprite texture handle must be retained");
    require(frame.batches[0].sampling == sampling, "Vulkan sampler state must follow the draw call");
    require_near(frame.vertices[0].x, 30.0F, "sprite left edge must be retained");
    require_near(frame.vertices[2].y, 60.0F, "sprite bottom edge must be retained");
    require_near(frame.vertices[0].u, 0.3F, "horizontal mirror must swap the left UV");
    require_near(frame.vertices[1].u, 0.1F, "horizontal mirror must swap the right UV");
    require_near(frame.vertices[0].v, 0.1F, "source top pixel must normalize to V");
    require_near(frame.vertices[2].v, 0.3F, "source bottom pixel must normalize to V");
}

void test_transformed_quad_and_triangle_list_preserve_geometry()
{
    auto recorder = make_recorder();
    const pvz::render::TextureRegion source{
        {3},
        {64.0, 64.0},
        {{0.0, 0.0}, {64.0, 64.0}},
    };
    const std::array<pvz::render::Point2D, 4> rotated{
        pvz::render::Point2D{20.0, 10.0},
        pvz::render::Point2D{60.0, 20.0},
        pvz::render::Point2D{50.0, 70.0},
        pvz::render::Point2D{10.0, 60.0},
    };
    recorder.draw_sprite_quad(source, rotated);

    const std::array triangle{
        pvz::render::Vertex2D{100.0F, 100.0F, 0.0F, 0.0F, 0xFFFFFFFF},
        pvz::render::Vertex2D{120.0F, 100.0F, 1.0F, 0.0F, 0xFFFFFFFF},
        pvz::render::Vertex2D{110.0F, 130.0F, 0.5F, 1.0F, 0xFFFFFFFF},
    };
    recorder.draw_triangle_list({3}, triangle);

    const auto frame = recorder.frame();
    require(frame.vertices.size() == 7, "quad and triangle geometry must share one frame buffer");
    require(frame.indices.size() == 9, "quad and triangle indices must be appended");
    require(frame.batches.size() == 1, "matching textured geometry must share a batch");
    require_near(frame.vertices[3].x, 10.0F, "arbitrary quad positions must not be axis-aligned again");
    require(frame.indices[6] == 4 && frame.indices[8] == 6,
            "triangle indices must be rebased after existing geometry");
}

void test_invalid_draw_inputs_are_rejected()
{
    auto recorder = make_recorder();
    bool rejected = false;
    try {
        const std::array invalid{
            pvz::render::Vertex2D{},
            pvz::render::Vertex2D{},
        };
        recorder.draw_triangle_list({}, invalid);
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "partial triangle lists must be rejected");

    rejected = false;
    try {
        recorder.fill_rect(
            {{0.0, 0.0}, {1.0, 1.0}},
            0xFFFFFFFF,
            pvz::render::BlendMode::alpha,
            {{799.0, 0.0}, {2.0, 1.0}});
    } catch (const std::out_of_range&) {
        rejected = true;
    }
    require(rejected, "scissors outside the logical frame must be rejected");
}

} // namespace

int main()
{
    test_consecutive_draws_with_matching_state_are_batched();
    test_sprite_pixels_are_normalized_and_can_be_mirrored();
    test_transformed_quad_and_triangle_list_preserve_geometry();
    test_invalid_draw_inputs_are_rejected();
    return EXIT_SUCCESS;
}
