#pragma once

#include "ScaleEffectCompiler.h"

#include <d3d11.h>

#include <map>
#include <tuple>
#include <vector>

namespace Sexy
{

struct ScaleEffectRuntimeOptions
{
	int	mSrcWidth;
	int	mSrcHeight;
	int	mTargetWidth;
	int	mTargetHeight;
	bool	mFill;		// true = stretch to target, false = fit (letterbox handled by caller)
};

// Mirrors Magpie's ScalingType: how an effect sizes its output when it has no
// OUTPUT size expression in its metadata.
enum ScaleScalingType
{
	SCALE_SCALING_NORMAL = 0,	// 倍数: output = input * scale(x,y)
	SCALE_SCALING_FIT = 1,		// 适应: output = input * fitRatio * scale
	SCALE_SCALING_ABSOLUTE = 2,	// 绝对: scale(x,y) is the pixel size
	SCALE_SCALING_FILL = 3		// 充满: output = target (screen/window)
};

struct ScaleEffectScaling
{
	int		mScalingType = SCALE_SCALING_NORMAL;
	float	mScaleX = 1.0f;
	float	mScaleY = 1.0f;
};

// D3D11 executor for the MagpieFX pipeline: owns the device and a texture
// cache, resolves per-effect texture sizes, updates the shared constant
// buffer and dispatches every compiled pass. No CPU readback anywhere.
class ScaleEffectRuntime
{
public:
	ScaleEffectRuntime();
	~ScaleEffectRuntime();

	// Runs one pipeline (ordered effects, already compiled) on a source
	// texture. outTexture receives the final target-sized texture (addref'd);
	// caller must Release it. Returns false on any failure.
	bool RunPipeline(
		const std::vector<ScaleEffectDesc*>& theEffects,
		const std::vector<ScaleEffectScaling>& theScalings,
		size_t thePipelineInstance,
		ID3D11Texture2D* theSource,
		const ScaleEffectRuntimeOptions& theOptions,
		ID3D11Texture2D** outTexture,
		ID3D11ShaderResourceView* theSourceSRV = nullptr);

	// Diagnostic: builds an 800x600 checkerboard source, runs the pipeline and
	// writes the output as a 32-bit BMP (CPU readback only in this test path).
	bool RunSelfTest(
		const std::vector<ScaleEffectDesc*>& theEffects,
		size_t thePipelineInstance,
		int theTargetW,
		int theTargetH,
		const char* theOutFile,
		const std::vector<ScaleEffectScaling>& theScalings = {});

	static int EvalSizeExpr(
		const std::string& theExpr,
		int theInputW,
		int theInputH,
		int theOutputW,
		int theOutputH,
		bool& ok);

	bool CreateDevice();
	// Reuse an existing D3D11 device/context (the renderer's), so the scene
	// texture can be fed into the pipeline without cross-device copies. The
	// runtime does not release a device it does not own.
	bool CreateDevice(ID3D11Device* theDevice, ID3D11DeviceContext* theContext);
	// Materialize every immutable shader/sampler object for the compiled effect
	// set without running a pipeline or allocating size-dependent textures.
	// These objects then remain resident until the renderer's device is replaced.
	bool PreparePipelineObjects(const std::vector<ScaleEffectDesc*>& theEffects);
	// Releases all D3D11 resources and resets the runtime so it can be
	// re-pointed at a new device after a renderer rebuild.
	void DestroyDevice();

	ID3D11Device* GetDevice() const { return mDevice; }
	ID3D11DeviceContext* GetContext() const { return mContext; }

private:
	struct TexKey
	{
		int			mWidth;
		int			mHeight;
		DXGI_FORMAT	mFormat;
		bool operator<(const TexKey& theOther) const
		{
			if (mWidth != theOther.mWidth) return mWidth < theOther.mWidth;
			if (mHeight != theOther.mHeight) return mHeight < theOther.mHeight;
			return mFormat < theOther.mFormat;
		}
	};

	struct TexEntry
	{
		ID3D11Texture2D*	mTexture;
		ID3D11ShaderResourceView* mSRV;
		ID3D11UnorderedAccessView* mUAV;
	};

	TexEntry CreateTexture(int theWidth, int theHeight, DXGI_FORMAT theFormat);
	bool RunEffect(
		const ScaleEffectDesc& theEffect,
		size_t thePipelineInstance,
		size_t theEffectInstance,
		TexEntry* theInput,
		int theInputW,
		int theInputH,
		int theEffectOutputW,
		int theEffectOutputH,
		TexEntry** outEntry);
	bool UpdateConstantBuffer(
		const ScaleEffectDesc& theEffect,
		size_t thePassIndex,
		int theInputW,
		int theInputH,
		int theOutputW,
		int theOutputH);
	ID3D11SamplerState* GetSampler(const std::string& theFilter, const std::string& theAddress);
	ID3D11ComputeShader* GetShader(const ScaleEffectDesc& theEffect, size_t thePassIndex);

	ID3D11Device*			mDevice;
	ID3D11DeviceContext*	mContext;
	bool					mOwnsDevice;
	// Per-mode/per-pipeline-instance intermediate textures. A pipeline may intentionally
	// contain the same compiled effect more than once (for example two
	// Anime4K upscale stages), and window/fullscreen pipelines may share the same
	// effect descriptor at the same index. Both identities are part of the key:
	// compiled shaders may be shared, but live intermediate textures stay resident
	// independently for each mode.
	std::map<std::tuple<const ScaleEffectDesc*, size_t, size_t, std::string>, TexEntry> mEffectTextures;
	ID3D11Buffer*			mConstantBuffer;
	size_t					mConstantBufferSize;
	std::map<std::string, ID3D11SamplerState*> mSamplerMap;
	std::map<std::pair<const ScaleEffectDesc*, size_t>, ID3D11ComputeShader*> mShaderMap;
	// Reused per-dispatch pointer/constant staging. These are CPU-side binding
	// arrays, not image copies; retaining capacity avoids heap churn every pass.
	std::vector<ID3D11ShaderResourceView*> mSRVScratch;
	std::vector<ID3D11UnorderedAccessView*> mUAVScratch;
	std::vector<ID3D11ShaderResourceView*> mNullSRVScratch;
	std::vector<uint8_t> mConstantData;
};

}
