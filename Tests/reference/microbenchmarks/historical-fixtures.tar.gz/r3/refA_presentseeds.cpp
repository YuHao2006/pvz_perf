        mHeight = IMAGE_SCARY_POT->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_WATERING_CAN)
    {
        mWidth = IMAGE_WATERINGCAN->GetCelWidth();
        mHeight = IMAGE_WATERINGCAN->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_TACO)
    {
        mWidth = IMAGE_TACO->GetCelWidth();
        mHeight = IMAGE_TACO->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_NOTE)
    {
        mWidth = IMAGE_ZOMBIE_NOTE_SMALL->GetCelWidth();
        mHeight = IMAGE_ZOMBIE_NOTE_SMALL->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_USABLE_SEED_PACKET)
    {
        mWidth = IMAGE_SEEDS->GetCelWidth();
        mHeight = IMAGE_SEEDS->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_FOG, 0, 2);
    }
    else if (mType == CoinType::COIN_PRESENT_PLANT || mType == CoinType::COIN_AWARD_PRESENT)
    {
        TOD_ASSERT(mBoard);

        mWidth = IMAGE_PRESENT->GetCelWidth();
        mHeight = IMAGE_PRESENT->GetCelHeight();
        if (mApp->IsSurvivalEndless(mApp->mGameMode) || mApp->IsEndlessIZombie(mApp->mGameMode) || mApp->IsEndlessScaryPotter(mApp->mGameMode))
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_1_DAY)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_PEASHOOTER,
                SeedType::SEED_SUNFLOWER,
                SeedType::SEED_CHERRYBOMB,
                SeedType::SEED_WALLNUT,
                SeedType::SEED_REPEATER,
                SeedType::SEED_POTATOMINE,
                SeedType::SEED_SNOWPEA,
                SeedType::SEED_CHOMPER
            };
            
            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_2_NIGHT)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_PUFFSHROOM,
                SeedType::SEED_SUNSHROOM,
                SeedType::SEED_FUMESHROOM,
                SeedType::SEED_GRAVEBUSTER,
                SeedType::SEED_HYPNOSHROOM,
                SeedType::SEED_SCAREDYSHROOM,
                SeedType::SEED_ICESHROOM,
                SeedType::SEED_DOOMSHROOM
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_3_POOL)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_LILYPAD,
                SeedType::SEED_SQUASH,
                SeedType::SEED_THREEPEATER,
                SeedType::SEED_TANGLEKELP,
                SeedType::SEED_JALAPENO,
                SeedType::SEED_SPIKEWEED,
                SeedType::SEED_TORCHWOOD,
                SeedType::SEED_TALLNUT
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
