
void __thiscall FUN_00547bf0(int *param_1,int *param_2)

{
  undefined1 local_24 [16];
  undefined1 local_14 [16];
  
  (**(code **)(*param_2 + 4))(local_24);
  (**(code **)(*param_1 + 4))(local_14);
  FUN_00474ea0();
  return;
}

