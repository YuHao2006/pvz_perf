# PvZ 1.2.0.1073 关卡中断存档完整布局与 dat64 格式

## 1. 范围与结论

本文只描述进行中的单局快照：

```text
game<用户ID>_<GameMode>.dat
```

它不描述 `users.dat` 和 `user<ID>.dat`。后两者的 1073 字段同步方式本来就能
在 64 位 Legacy 中保持语义，因此继续直接使用官方 `.dat`，不经过 dat64
转换器。只有 `game*.dat` 含有大量 MSVC x86 对象内存布局，必须转换成：

```text
game<用户ID>_<GameMode>.dat64
```

最重要的音乐结论如下。

1. 官方泳池生存无尽样本保存的是 `mCurMusicTune = 3`，即
   `MUSIC_TUNE_POOL_WATERYGRAVES`，不是 Grasswalk。
2. 当前 x64 BASS 2.4.17 能原样设置并读回官方的
   `mPauseOffset = 0x0025005F`（order 95、row 37）。不存在“BASS 2.2 与 2.4
   音轨编号不同，3 被解释成 Grasswalk”的证据。
3. 已确认的真实布局错误是：1073/BASS 2.2 把 `mBaseBPM` 和
   `mBaseModSpeed` 保存成两个 `i32`；旧移植代码却把成员改成 `float` 并整段
   `memcpy`。官方的整数 `71`、`2` 因而分别被解释成约 `9.95e-44`、
   `2.80e-45`。Legacy 已恢复 `i32` 成员，只在调用 BASS 2.4 的 float API 时
   使用局部 `float`。

证据来源：1073 可执行文件反汇编、MSVC x86 类布局报告、官方二进制样本、
BASS 2.4 实际位置探针和 dat/dat64 双向逐字段复验。本文的偏移均相对于所在
磁盘块开头，不使用当前 x64 C++ 对象的绝对地址。

## 2. 两个不同的 `mPaused`

存档中有两个同名但职责不同的字段。

| 所在块 | 偏移 | 含义 |
| --- | ---: | --- |
| `Board` | `0x0000` | 棋盘逻辑是否暂停。为真时停止普通棋盘更新。 |
| `Music` | `0x0040` | 音乐通道是否已经停下，且 `mPauseOffset` / `mPauseOffsetDrums` 是否有效。 |

日志中 `musicTune=3 paused=1` 的 `paused` 指第二个，即 `Music::mPaused`。

1073 保存正常中断档前会执行 `GameMusicPause(true)`：读取 BASS 当前 order/row，
停止对应通道，把 `Music::mPaused` 置为 1。载入流程是：

```text
TryLoadGame
  -> StopAllMusic
  -> 反序列化 Board 与 Music
  -> 显示 Continue 对话框
  -> 关闭对话框
  -> ModalClose
  -> Board::Pause(false)
  -> Music::GameMusicPause(false)
  -> PlayMusic(保存的 tune, 保存的 offset, 保存的 drumsOffset)
```

因此 `Music::mPaused = 1` 是正常且必要的恢复状态，不是异常卡死标志。

## 3. 公共编码规则

- 所有整数和 IEEE-754 单精度浮点均为小端序。
- `bool` 是 1 字节，只允许 0 或 1。
- 枚举和各种 `ZombieID`、`PlantID`、`ReanimationID` 均为 4 字节。
- `SyncBytes(data, N)` 在数据前写一个 `u32 N`；读取时长度必须完全相等。
- 原版直接保存的 32 位指针没有持久意义。读取后由对象 ID、资源 ID或定义 ID
  重建，转换器不会把它们带入 dat64。
- 表中的“padding”是 ABI 对齐字节，不是隐藏字段。

## 4. 1073 文件总顺序

```text
SyncBytes(12 字节文件头)
SyncBytes(22108 字节 Board 持久区)
12 个 DataArray
每个存活 ParticleSystem 的补充数据
每个存活 Reanimation 的补充数据
每个存活 Trail 的定义 ID
SyncBytes(CursorObject)
SyncBytes(CursorPreview)
SyncBytes(MessageWidget)
SyncBytes(SeedBank)
SyncBytes(Challenge)
SyncBytes(Music)
u32 结束标记 0xFEEDDEAD
```

12 字节文件头本身也由 `SyncBytes` 包裹，因此文件开头实际为 16 字节：

| 文件偏移 | 类型 | 值/作用 |
| ---: | --- | --- |
| `0x00` | `u32` | 块长 12。 |
| `0x04` | `u32` | `0xFEEDDEAD`。 |
| `0x08` | `u32` | 存档版本 2。 |
| `0x0C` | `u32` | `0xAC9B80AC`，字符串 `Jul  2 201011:47:03` 的 CRC32。 |

## 5. Board 持久区：22108 字节

1073 从 `Board::mPaused` 开始一直写到对象末尾。窗口、Widget、按钮、对象池指针
等位于 `mPaused` 之前，所以不在此块。数组维度：棋盘 9×6；最多 100 波、每波
50 个僵尸类型。

| 相对偏移 | 类型/数量 | 字段 | 作用 |
| ---: | --- | --- | --- |
| `0x0000` | `bool` | `mPaused` | 棋盘逻辑暂停。 |
| `0x0004` | `i32[9][6]` | `mGridSquareType` | 每格地形：空、草、土、水、高台。 |
| `0x00DC` | `i32[9][6]` | `mGridCelLook` | 每格随机外观编号。 |
| `0x01B4` | `i32[9][6][2]` | `mGridCelOffset` | 每格绘制 X/Y 偏移。 |
| `0x0364` | `i32[9][7]` | `mGridCelFog` | 雾格状态，多一列供雾边界过渡。 |
| `0x0460` | `bool` | `mEnableGraveStones` | 是否允许墓碑。 |
| `0x0464` | `i32` | `mSpecialGraveStoneX` | 特殊墓碑列。 |
| `0x0468` | `i32` | `mSpecialGraveStoneY` | 特殊墓碑行。 |
| `0x046C` | `f32` | `mFogOffset` | 雾层水平偏移。 |
| `0x0470` | `i32` | `mFogBlownCountDown` | 三叶草吹雾倒计时。 |
| `0x0474` | `i32[6]` | `mPlantRow` | 每行的陆地/水池等行类型。 |
| `0x048C` | `i32[6]` | `mWaveRowGotLawnMowered` | 每行最近被小推车清理的波次。 |
| `0x04A4` | `i32` | `mBonusLawnMowersRemaining` | 剩余奖励小推车数。 |
| `0x04A8` | `i32[6]` | `mIceMinX` | 每行冰道最左位置。 |
| `0x04C0` | `i32[6]` | `mIceTimer` | 每行冰道剩余时间。 |
| `0x04D8` | `ID[6]` | `mIceParticleID` | 每行冰道粒子系统。 |
| `0x04F0` | `TodSmoothArray[6]` | `mRowPickingArray` | 选行平滑权重；每项为 `i32 item + f32 weight + f32 last + f32 secondLast`。 |
| `0x0550` | `i32[100][50]` | `mZombiesInWave` | 各波预排的僵尸类型，未用位置为 `ZOMBIE_INVALID` 或初始化值。 |
| `0x5370` | `bool[100]` | `mZombieAllowed` | 本关允许出现的僵尸类型表。 |
| `0x53D4` | `i32` | `mSunCountDown` | 下一个自然阳光倒计时。 |
| `0x53D8` | `i32` | `mNumSunsFallen` | 已自然落下的阳光数。 |
| `0x53DC` | `i32` | `mShakeCounter` | 画面震动剩余 tick。 |
| `0x53E0` | `i32` | `mShakeAmountX` | 水平震幅。 |
| `0x53E4` | `i32` | `mShakeAmountY` | 垂直震幅。 |
| `0x53E8` | `i32` | `mBackground` | 地图背景；泳池为 2。 |
| `0x53EC` | `i32` | `mLevel` | 本局冒险关卡号/内部关卡号。 |
| `0x53F0` | `i32` | `mSodPosition` | 草卷铺设位置。 |
| `0x53F4` | `i32` | `mPrevMouseX` | 上一逻辑帧鼠标 X。 |
| `0x53F8` | `i32` | `mPrevMouseY` | 上一逻辑帧鼠标 Y。 |
| `0x53FC` | `i32` | `mSunMoney` | 当前阳光。 |
| `0x5400` | `i32` | `mNumWaves` | 当前阶段总波数。 |
| `0x5404` | `i32` | `mMainCounter` | 棋盘主 tick 计数。 |
| `0x5408` | `i32` | `mEffectCounter` | 通用效果计数。 |
| `0x540C` | `i32` | `mDrawCount` | 绘制计数。 |
| `0x5410` | `i32` | `mRiseFromGraveCounter` | 墓碑出怪计数。 |
| `0x5414` | `i32` | `mOutOfMoneyCounter` | 阳光不足提示计数。 |
| `0x5418` | `i32` | `mCurrentWave` | 当前波。 |
| `0x541C` | `i32` | `mTotalSpawnedWaves` | 已生成波数。 |
| `0x5420` | `i32` | `mTutorialState` | 教程状态。 |
| `0x5424` | `ID` | `mTutorialParticleID` | 教程箭头等粒子。 |
| `0x5428` | `i32` | `mTutorialTimer` | 教程计时。 |
| `0x542C` | `i32` | `mLastBungeeWave` | 最近蹦极波。 |
| `0x5430` | `i32` | `mZombieHealthToNextWave` | 提前出下一波所需剩余血量。 |
| `0x5434` | `i32` | `mZombieHealthWaveStart` | 本波开始时僵尸总血量。 |
| `0x5438` | `i32` | `mZombieCountDown` | 下一波倒计时。 |
| `0x543C` | `i32` | `mZombieCountDownStart` | 本次波倒计时初值。 |
| `0x5440` | `i32` | `mHugeWaveCountDown` | 大波提示倒计时。 |
| `0x5444` | `bool[68]` | `mHelpDisplayed` | 每类 Advice 是否已显示。 |
| `0x5488` | `i32` | `mHelpIndex` | 当前 Advice 类型。 |
| `0x548C` | `bool` | `mFinalBossKilled` | 僵王是否已击杀。 |
| `0x548D` | `bool` | `mShowShovel` | 是否显示铲子。 |
| `0x5490` | `i32` | `mCoinBankFadeCount` | 钱包显示淡出计数。 |
| `0x5494` | `i32` | `mDebugTextMode` | 调试文字模式。 |
| `0x5498` | `bool` | `mLevelComplete` | 本关是否完成。 |
| `0x549C` | `i32` | `mBoardFadeOutCounter` | 关卡结束淡出。 |
| `0x54A0` | `i32` | `mNextSurvivalStageCounter` | 生存下一轮阶段过渡。 |
| `0x54A4` | `i32` | `mScoreNextMowerCounter` | 结算下一辆小推车计数。 |
| `0x54A8` | `bool` | `mLevelAwardSpawned` | 本关奖励是否已生成。 |
| `0x54AC` | `i32` | `mProgressMeterWidth` | 进度条宽度。 |
| `0x54B0` | `i32` | `mFlagRaiseCounter` | 旗帜抬升动画计数。 |
| `0x54B4` | `i32` | `mIceTrapCounter` | 全局冰冻计数。 |
| `0x54B8` | `i32` | `mBoardRandSeed` | 棋盘随机种子。 |
| `0x54BC` | `ID` | `mPoolSparklyParticleID` | 水池闪光粒子。 |
| `0x54C0` | `ID[6][12]` | `mFwooshID` | 各行屋顶/僵王喷射效果动画 ID。 |
| `0x55E0` | `i32` | `mFwooshCountDown` | 喷射效果倒计时。 |
| `0x55E4` | `i32` | `mTimeStopCounter` | 时间停止计数。 |
| `0x55E8` | `bool` | `mDroppedFirstCoin` | 是否已掉落首枚硬币。 |
| `0x55EC` | `i32` | `mFinalWaveSoundCounter` | 最后一波音效计数。 |
| `0x55F0` | `i32` | `mCobCannonCursorDelayCounter` | 玉米炮准星延迟。 |
| `0x55F4` | `i32` | `mCobCannonMouseX` | 玉米炮目标鼠标 X。 |
| `0x55F8` | `i32` | `mCobCannonMouseY` | 玉米炮目标鼠标 Y。 |
| `0x55FC` | `bool` | `mKilledYeti` | 本局是否击杀雪人。 |
| `0x55FD..0x5603` | `bool×7` | `mMustacheMode`…`mSukhbirMode` | 胡子、超级车、未来、彩罐、舞蹈、雏菊、Sukhbir 模式。 |
| `0x5604` | `i32` | `mPrevBoardResult` | 上一个棋盘结果。 |
| `0x5608` | `bool` | `mPeaShooterUsed` | 成就统计：使用过豌豆射手。 |
| `0x5609` | `bool` | `mCatapultPlantsUsed` | 成就统计：使用过投掷类植物。 |
| `0x560C` | `i32` | `mLevelCoinsCollected` | 本局收集硬币数。 |
| `0x5610` | `i32` | `mGargantuarsKillsByCornCob` | 玉米炮击杀巨人数。 |
| `0x5614` | `bool` | `mMushroomAndCoffeeBeansOnly` | 是否仅使用蘑菇和咖啡豆。 |
| `0x5615` | `bool` | `mMushroomsUsed` | 是否使用过蘑菇。 |
| `0x5618` | `i32` | `mTriggeredLawnMowers` | 已触发小推车数。 |
| `0x561C` | `i32` | `mPlayTimeActiveLevel` | 本局前台活跃 tick。 |
| `0x5620` | `i32` | `mPlayTimeInactiveLevel` | 本局后台/非活跃 tick。 |
| `0x5624` | `i32` | `mMaxSunPlants` | 本局最大产阳光植物统计。 |
| `0x5628` | `u32` | `mStartDrawTime` | 绘制性能统计起点。 |
| `0x562C` | `u32` | `mIntervalDrawTime` | 绘制统计区间时间。 |
| `0x5630` | `i32` | `mIntervalDrawCountStart` | 绘制统计区间起始帧数。 |
| `0x5634` | `f32` | `mMinFPS` | 本局最低 FPS 统计。 |
| `0x5638` | `i32` | `mPreloadTime` | 预加载耗时统计。 |
| `0x563C` | `i32` | `mGameID` | 1073 的单局 ID；dat64 扩为 `i64`。 |
| `0x5640` | `i32` | `mGravesCleared` | 清除墓碑数。 |
| `0x5644` | `i32` | `mPlantsEaten` | 被吃植物数。 |
| `0x5648` | `i32` | `mPlantsShoveled` | 铲除植物数。 |
| `0x564C` | `i32` | `mCoinsCollected` | 收集普通硬币数。 |
| `0x5650` | `i32` | `mDiamondsCollected` | 收集钻石数。 |
| `0x5654` | `i32` | `mPottedPlantsCollected` | 收集盆栽数。 |
| `0x5658` | `i32` | `mChocolateCollected` | 收集巧克力数。 |

## 6. DataArray 公共布局

每个数组先保存三个裸 `u32`：

| 顺序 | 字段 | 作用 |
| ---: | --- | --- |
| 1 | `mFreeListHead` | 第一个空闲槽索引；等于 `mMaxUsedCount` 表示链尾。 |
| 2 | `mMaxUsedCount` | 已进入槽区的最高范围，不等于存活数量。 |
| 3 | `mSize` | 存活对象数。 |

随后 `SyncBytes(mMaxUsedCount × slotSize)`。每槽为对象记录、4 字节 `mID` 和必要
尾部 padding。存活 ID 的高 16 位是 generation key，低 16 位必须等于槽索引；
空闲槽的 `mID` 是自由链的下一个索引。`mMaxSize`、`mNextKey`、数组名和内存指针
不写盘。

| 数组 | x86 对象 | x86 槽 | 最大容量 | dat64 对象 | dat64 槽 |
| --- | ---: | ---: | ---: | ---: | ---: |
| Zombie | 356 | 360 | 1024 | 368 | 376 |
| Plant | 328 | 332 | 1024 | 344 | 352 |
| Projectile | 144 | 148 | 1024 | 160 | 168 |
| Coin | 208 | 216 | 1024 | 216 | 224 |
| LawnMower | 68 | 72 | 32 | 80 | 88 |
| GridItem | 232 | 236 | 128 | 240 | 248 |
| ParticleSystem | 40 | 44 | 1024 | 72 | 80 |
| ParticleEmitter | 172 | 176 | 1024 | 208 | 216 |
| Particle | 156 | 160 | 1024 | 160 | 168 |
| Reanimation | 156 | 160 | 1024 | 176 | 184 |
| Trail | 232 | 236 | 1024 | 248 | 256 |
| Attachment | 776 | 780 | 1024 | 776 | 780 |

Coin 的 x86 对象需要 8 字节对齐：`mID` 位于 `+208`，槽尾另有 4 字节 padding，
所以不是简单的 `208+4=212`。

## 7. GameObject 公共前缀

Zombie、Plant、Projectile、Coin、CursorObject、CursorPreview、SeedPacket 共用：

| x86 偏移 | 类型 | 字段 | 作用 |
| ---: | --- | --- | --- |
| `0x00` | `ptr32` | `mApp` | 不可持久化；载入后重建。 |
| `0x04` | `ptr32` | `mBoard` | 不可持久化；载入后重建。 |
| `0x08` | `i32` | `mX` | 逻辑矩形 X。 |
| `0x0C` | `i32` | `mY` | 逻辑矩形 Y。 |
| `0x10` | `i32` | `mWidth` | 宽。 |
| `0x14` | `i32` | `mHeight` | 高。 |
| `0x18` | `bool` | `mVisible` | 可见性。 |
| `0x1C` | `i32` | `mRow` | 所在行。 |
| `0x20` | `i32` | `mRenderOrder` | 绘制层级。 |

## 8. 游戏对象逐字段布局

以下偏移仍是完整 x86 对象记录偏移，包含上面的公共前缀。

### 8.1 Zombie：356 字节

| 偏移 | 字段组 | 作用 |
| ---: | --- | --- |
| `0x24` | `mZombieType` | 僵尸类型。 |
| `0x28` | `mZombiePhase` | 当前状态机阶段。 |
| `0x2C,0x30,0x34` | `mPosX,mPosY,mVelX` | 浮点位置与水平速度。 |
| `0x38..0x4C` | `mAnimCounter,mGroanCounter,mAnimTicksPerFrame,mAnimFrames,mFrame,mPrevFrame` | 旧帧动画计数。 |
| `0x50,0x51` | `mVariant,mIsEating` | 变体与进食标志。 |
| `0x54,0x58,0x5C` | `mJustGotShotCounter,mShieldJustGotShotCounter,mShieldRecoilCounter` | 受击/盾牌反馈。 |
| `0x60` | `mZombieAge` | 存活 tick。 |
| `0x64` | `mZombieHeight` | 高度状态。 |
| `0x68,0x6C` | `mPhaseCounter,mFromWave` | 状态计数与来源波次。 |
| `0x70` | `mDroppedLoot` | 是否已掉落战利品。 |
| `0x74` | `mZombieFade` | 淡出计数。 |
| `0x78` | `mFlatTires` | 轮胎是否被扎。 |
| `0x7C,0x80` | `mUseLadderCol,mTargetCol` | 梯子/目标列。 |
| `0x84` | `mAltitude` | 垂直高度。 |
| `0x88` | `mHitUmbrella` | 是否被叶子保护伞命中。 |
| `0x8C,0x9C` | `mZombieRect,mZombieAttackRect` | 16 字节身体与攻击矩形。 |
| `0xAC,0xB0,0xB4` | `mChilledCounter,mButteredCounter,mIceTrapCounter` | 减速、黄油、冰冻。 |
| `0xB8..0xBF` | `mMindControlled,mBlowingAway,mHasHead,mHasArm,mHasObject,mInPool,mOnHighGround,mYuckyFace` | 八个状态 bool。 |
| `0xC0` | `mYuckyFaceCounter` | 嫌弃表情计数。 |
| `0xC4` | `mHelmType` | 头部防具类型。 |
| `0xC8..0xD4` | `mBodyHealth,mBodyMaxHealth,mHelmHealth,mHelmMaxHealth` | 本体/头盔血量。 |
| `0xD8` | `mShieldType` | 盾牌类型。 |
| `0xDC,0xE0` | `mShieldHealth,mShieldMaxHealth` | 盾牌血量。 |
| `0xE4,0xE8` | `mFlyingHealth,mFlyingMaxHealth` | 飞行部分血量。 |
| `0xEC` | `mDead` | 死亡标志。 |
| `0xF0` | `mRelatedZombieID` | 关联僵尸。 |
| `0xF4` | `mFollowerZombieID[4]` | 跟随僵尸。 |
| `0x104` | `mPlayingSong` | 是否正在唱歌。 |
| `0x108,0x10C` | `mParticleOffsetX,mParticleOffsetY` | 附着粒子偏移。 |
| `0x110` | `mAttachmentID` | 附件集合。 |
| `0x114` | `mSummonCounter` | 召唤计数。 |
| `0x118` | `mBodyReanimID` | 主体动画。 |
| `0x11C,0x120,0x124` | `mScaleZombie,mVelZ,mOriginalAnimRate` | 缩放、Z 速度、原动画速率。 |
| `0x128` | `mTargetPlantID` | 目标植物。 |
| `0x12C..0x13C` | `mBossMode,mTargetRow,mBossBungeeCounter,mBossStompCounter,mBossHeadCounter` | 僵王状态。 |
| `0x140,0x144,0x148` | `mBossFireBallReanimID,mSpecialHeadReanimID,mZombatarHeadReanimID` | 火球、特殊头、大头贴头动画。 |
| `0x14C` | `mFireballRow` | 火球行。 |
| `0x150` | `mIsFireBall` | 是否为火球对象。 |
| `0x154` | `mMoweredReanimID` | 被推车碾压动画。 |
| `0x158` | `mLastPortalX` | 最近传送门 X。 |
| `0x15C` | `mHasZombatar` | 是否使用大头贴。 |
| `0x160` | `mZombatarIndex` | 大头贴索引。 |

### 8.2 Plant：328 字节

| 偏移 | 字段组 | 作用 |
| ---: | --- | --- |
| `0x24..0x3C` | `mSeedType,mPlantCol,mAnimCounter,mFrame,mFrameLength,mNumFrames,mState` | 类型、列、旧动画与状态。 |
| `0x40,0x44` | `mPlantHealth,mPlantMaxHealth` | 当前/最大血量。 |
| `0x48` | `mSubclass` | 植物子类。 |
| `0x4C..0x5C` | `mDisappearCountdown,mDoSpecialCountdown,mStateCountdown,mLaunchCounter,mLaunchRate` | 消失、特殊、状态和发射计时。 |
| `0x60,0x70` | `mPlantRect,mPlantAttackRect` | 身体/攻击矩形。 |
| `0x80,0x84,0x88` | `mTargetX,mTargetY,mStartRow` | 目标与起始行。 |
| `0x8C` | `mParticleID` | 主粒子。 |
| `0x90` | `mShootingCounter` | 射击计数。 |
| `0x94..0xAC` | `mBodyReanimID,mHeadReanimID,mHeadReanimID2,mHeadReanimID3,mBlinkReanimID,mLightReanimID,mSleepingReanimID` | 七个动画 ID。 |
| `0xB0..0xBC` | `mBlinkCountdown,mRecentlyEatenCountdown,mEatenFlashCountdown,mBeghouledFlashCountdown` | 闪烁/受食/宝石迷阵反馈。 |
| `0xC0,0xC4` | `mShakeOffsetX,mShakeOffsetY` | 摇晃偏移。 |
| `0xC8` | `MagnetItem[5]` | 每项 20 字节：位置 X/Y、目标偏移 X/Y、物品类型。 |
| `0x12C` | `mTargetZombieID` | 目标僵尸。 |
| `0x130` | `mWakeUpCounter` | 唤醒计时。 |
| `0x134` | `mOnBungeeState` | 被蹦极抓取状态。 |
| `0x138` | `mImitaterType` | 模仿者原型。 |
| `0x13C` | `mPottedPlantIndex` | 禅境盆栽索引。 |
| `0x140..0x145` | `mAnimPing,mDead,mSquished,mIsAsleep,mIsOnBoard,mHighlighted` | 六个 bool。 |

### 8.3 Projectile：144 字节

| 偏移 | 字段组 | 作用 |
| ---: | --- | --- |
| `0x24..0x2C` | `mFrame,mNumFrames,mAnimCounter` | 帧动画。 |
| `0x30..0x4C` | `mPosX,mPosY,mPosZ,mVelX,mVelY,mVelZ,mAccZ,mShadowY` | 三维运动与影子高度。 |
| `0x50` | `mDead` | 死亡。 |
| `0x54` | `mAnimTicksPerFrame` | 每帧 tick。 |
| `0x58,0x5C` | `mMotionType,mProjectileType` | 运动/投射物类型。 |
| `0x60,0x64` | `mProjectileAge,mClickBackoffCounter` | 年龄与点击退让计数。 |
| `0x68,0x6C` | `mRotation,mRotationSpeed` | 旋转。 |
| `0x70` | `mOnHighGround` | 是否在高台。 |
| `0x74` | `mDamageRangeFlags` | 伤害范围 flags。 |
| `0x78` | `mHitTorchwoodGridX` | 命中过的火炬列。 |
| `0x7C` | `mAttachmentID` | 附件。 |
| `0x80,0x84` | `mCobTargetX,mCobTargetRow` | 玉米炮目标。 |
| `0x88` | `mTargetZombieID` | 目标僵尸。 |
| `0x8C` | `mLastPortalX` | 最近传送门 X。 |

### 8.4 Coin：208 字节

| 偏移 | 字段组 | 作用 |
| ---: | --- | --- |
| `0x24..0x34` | `mPosX,mPosY,mVelX,mVelY,mScale` | 位置、速度、缩放。 |
| `0x38` | `mDead` | 死亡。 |
| `0x3C` | `mFadeCount` | 淡出。 |
| `0x40,0x44` | `mCollectX,mCollectY` | 收集飞行动画目标。 |
| `0x48,0x4C` | `mGroundY,mCoinAge` | 地面 Y、年龄。 |
| `0x50` | `mIsBeingCollected` | 正在收集。 |
| `0x54` | `mDisappearCounter` | 消失计时。 |
| `0x58,0x5C` | `mType,mCoinMotion` | 掉落物类型与运动方式。 |
| `0x60` | `mAttachmentID` | 附件。 |
| `0x64` | `mCollectionDistance` | 收集飞行距离。 |
| `0x68` | `mUsableSeedType` | 可拾取卡片类型。 |
| `0x70` | `mPottedPlantSpec` | 88 字节盆栽规格，见下表。 |
| `0xC8..0xCA` | `mNeedsBouncyArrow,mHasBouncyArrow,mHitGround` | 弹跳箭头与落地标志。 |
| `0xCC` | `mTimesDropped` | 掉落次数。 |

`PottedPlant` 的 88 字节为：`mSeedType +0x00`、`mWhichZenGarden +0x04`、
`mX +0x08`、`mY +0x0C`、`mFacing +0x10`、padding 4、
`mLastWateredTime i64 +0x18`、`mDrawVariation +0x20`、`mPlantAge +0x24`、
`mTimesFed +0x28`、`mFeedingsPerGrow +0x2C`、`mPlantNeed +0x30`、padding 4、
`mLastNeedFulfilledTime i64 +0x38`、`mLastFertilizedTime i64 +0x40`、
`mLastChocolateTime i64 +0x48`、`mFutureAttribute i64 +0x50`。

### 8.5 LawnMower：68 字节

`mApp ptr32 +0x00`、`mBoard ptr32 +0x04`、`mPosX +0x08`、`mPosY +0x0C`、
`mRenderOrder +0x10`、`mRow +0x14`、`mAnimTicksPerFrame +0x18`、
`mReanimID +0x1C`、`mChompCounter +0x20`、`mRollingInCounter +0x24`、
`mSquishedCounter +0x28`、`mMowerState +0x2C`、`mDead +0x30`、
`mVisible +0x31`、`mMowerType +0x34`、`mAltitude +0x38`、
`mMowerHeight +0x3C`、`mLastPortalX +0x40`。

### 8.6 GridItem：232 字节

`mApp/mBoard ptr32 +0x00/+0x04`；`mGridItemType +0x08`；
`mGridItemState +0x0C`；`mGridX/mGridY +0x10/+0x14`；
`mGridItemCounter +0x18`；`mRenderOrder +0x1C`；`mDead +0x20`；
`mPosX/mPosY/mGoalX/mGoalY +0x24..+0x30`；
`mGridItemReanimID +0x34`；`mGridItemParticleID +0x38`；
`mZombieType +0x3C`；`mSeedType +0x40`；`mScaryPotType +0x44`；
`mHighlighted +0x48`；`mTransparentCounter +0x4C`；`mSunCount +0x50`；
`mMotionTrailFrames[12] +0x54`，每项为三个 `f32`：X、Y、动画时间；
`mMotionTrailCount +0xE4`。

## 9. 特效对象逐字段布局

### 9.1 TodParticleSystem：40 字节

| 偏移 | 字段 | 处理 |
| ---: | --- | --- |
| `0x00` | `mEffectType` | 粒子定义类型。 |
| `0x04` | `mParticleDef ptr32` | 由后续定义 ID 重建。 |
| `0x08` | `mParticleHolder ptr32` | 指向当前全局 holder，重建。 |
| `0x0C` | `mEmitterList` 16 字节 | 链表指针不可持久化；后续 ID 列表重建。 |
| `0x1C` | `mDead` | 死亡。 |
| `0x1D` | `mIsAttachment` | 是否为附件。 |
| `0x20` | `mRenderOrder` | 绘制层。 |
| `0x24` | `mDontUpdate` | 是否停止更新。 |

### 9.2 TodParticleEmitter：172 字节

`mEmitterDef ptr32 +0x00`、`mParticleSystem ptr32 +0x04`、
`mParticleList 16字节 +0x08` 均由补充数据重建；
`mSpawnAccum f32 +0x18`；`mSystemCenter f32×2 +0x1C`；
`mParticlesSpawned +0x24`；`mSystemAge +0x28`；`mSystemDuration +0x2C`；
`mSystemTimeValue/mSystemLastTimeValue +0x30/+0x34`；`mDead +0x38`；
`mColorOverride i32×4 +0x3C`；`mExtraAdditiveDrawOverride +0x4C`；
`mScaleOverride +0x50`；`mImageOverride ptr32 +0x54`，由资源 ID 重建；
`mCrossFadeEmitterID +0x58`；`mEmitterCrossFadeCountDown +0x5C`；
`mFrameOverride +0x60`；`mTrackInterp f32[10] +0x64`；
`mSystemFieldInterp f32[4][2] +0x8C`。

### 9.3 TodParticle：156 字节

`mParticleEmitter ptr32 +0x00` 由所属列表重建；`mParticleDuration +0x04`；
`mParticleAge +0x08`；`mParticleTimeValue +0x0C`；
`mParticleLastTimeValue +0x10`；`mAnimationTimeValue +0x14`；
`mVelocity f32×2 +0x18`；`mPosition f32×2 +0x20`；`mImageFrame +0x28`；
`mSpinPosition +0x2C`；`mSpinVelocity +0x30`；`mCrossFadeParticleID +0x34`；
`mCrossFadeDuration +0x38`；`mParticleInterp f32[16] +0x3C`；
`mParticleFieldInterp f32[4][2] +0x7C`。

### 9.4 Reanimation：156 字节

`mReanimationType +0x00`；`mAnimTime +0x04`；`mAnimRate +0x08`；
`mDefinition ptr32 +0x0C` 由定义 ID 重建；`mLoopType +0x10`；`mDead +0x14`；
`mFrameStart +0x18`；`mFrameCount +0x1C`；`mFrameBasePose +0x20`；
`mOverlayMatrix f32[9] +0x24`；`mColorOverride i32[4] +0x48`；
`mTrackInstances ptr32 +0x58` 由后续轨道块重建；`mLoopCount +0x5C`；
`mReanimationHolder ptr32 +0x60` 重建；`mIsAttachment +0x64`；
`mRenderOrder +0x68`；`mExtraAdditiveColor i32[4] +0x6C`；
`mEnableExtraAdditiveDraw +0x7C`；`mExtraOverlayColor i32[4] +0x80`；
`mEnableExtraOverlayDraw +0x90`；`mLastFrameTime +0x94`；
`mFilterEffect +0x98`。

### 9.5 ReanimatorTrackInstance：96 字节

每个 Reanimation 的轨道实例不在 DataArray 槽内，而在定义 ID 后的动态块中：

| 偏移 | 字段 | 作用 |
| ---: | --- | --- |
| `0x00,0x04` | `mBlendCounter,mBlendTime` | 混合计时。 |
| `0x08..0x27` | `ReanimatorTransform` 八个 `f32` | 平移、skew、缩放、帧、alpha。 |
| `0x28,0x2C,0x30` | `mImage,mFont,mText ptr32` | 不持久化；应为空/由定义恢复。 |
| `0x34,0x38,0x3C` | `mShakeOverride,mShakeX,mShakeY` | 轨道摇晃。 |
| `0x40` | `mAttachmentID` | 附件。 |
| `0x44` | `mImageOverride ptr32` | 后续单独保存资源 ID。 |
| `0x48` | `mRenderGroup` | 绘制组。 |
| `0x4C` | `mTrackColor i32[4]` | 轨道颜色。 |
| `0x5C..0x5F` | 四个 bool | 忽略裁剪、截断消失帧、忽略颜色、忽略额外加色。 |

### 9.6 Trail：232 字节

`mTrailPoints f32[20][2] +0x00`；`mNumTrailPoints +0xA0`；`mDead +0xA4`；
`mRenderOrder +0xA8`；`mTrailAge +0xAC`；`mTrailDuration +0xB0`；
`mDefinition ptr32 +0xB4` 和 `mTrailHolder ptr32 +0xB8` 重建；
`mTrailInterp f32[4] +0xBC`；`mTrailCenter f32×2 +0xCC`；
`mIsAttachment +0xD4`；`mColorOverride i32[4] +0xD8`。

### 9.7 Attachment：776 字节

`mEffectArray[16] +0x000`，每个 `AttachEffect` 48 字节：

```text
+0x00 u32 mEffectID
+0x04 i32 mEffectType       // particle/trail/reanim/attachment/other
+0x08 f32[9] mOffset        // 3×3 变换矩阵
+0x2C bool mDontDrawIfParentHidden
+0x2D bool mDontPropogateColor
```

尾部 `mNumEffects +0x300`、`mDead +0x304`。此类没有本机指针，所以 x86 与 x64
均为 776 字节。

## 10. 粒子、Reanim 和 Trail 补充数据

### 10.1 ParticleSystem

对每个存活系统，按 DataArray 槽顺序：

```text
i32 ParticleEffect 定义 ID
i32 emitterCount
repeat emitterCount:
    SyncBytes(4 字节 ParticleEmitterID)
repeat emitterCount:
    i32 emitterDefIndex
    i32 imageOverride ResourceId       // RESOURCE_ID_MAX 表示 null
    i32 particleCount
    repeat particleCount:
        SyncBytes(4 字节 ParticleID)
```

读取后据此恢复系统→发射器→粒子的所有父指针和链表。

### 10.2 Reanimation

对每个存活动画：

```text
i32 ReanimationType 定义 ID
如果该定义轨道数 N > 0:
    SyncBytes(N × 96 字节 ReanimatorTrackInstance)
    repeat N:
        i32 imageOverride ResourceId
```

1073 没把 N 另写一次，因为运行时从定义表取得轨道数。转换器不加载 PAK：它用
块长必须整除 96、每轨四个 bool、资源 ID 范围、存活动画总数和固定尾块边界做
记忆化语法求解；只有唯一完整解析能走到固定尾块时才允许输出。dat64 中每轨为
112 字节，规则相同。

### 10.3 Trail

每个存活 Trail 仅追加一个 `i32 TrailType`；holder 和 definition 指针重建。

## 11. 固定尾对象

### 11.1 CursorObject：76 字节

公共 GameObject 前缀后：`mSeedBankIndex +0x24`、`mType +0x28`、
`mImitaterType +0x2C`、`mCursorType +0x30`、`mCoinID +0x34`、
`mGlovePlantID +0x38`、`mDuplicatorPlantID +0x3C`、
`mCobCannonPlantID +0x40`、`mHammerDownCounter +0x44`、
`mReanimCursorID +0x48`。

### 11.2 CursorPreview：44 字节

公共 GameObject 前缀后仅有 `mGridX +0x24`、`mGridY +0x28`。

### 11.3 MessageWidget：796 字节

`mApp ptr32 +0x00`；`mLabel SexyChar[128] +0x04`；`mDisplayTime +0x84`；
`mDuration +0x88`；`mMessageStyle +0x8C`；
`mTextReanimID[128] +0x90`；`mReanimType +0x290`；
`mSlideOffTime +0x294`；`mLabelNext[128] +0x298`；
`mMessageStyleNext +0x318`。

### 11.4 SeedPacket：80 字节；SeedBank：848 字节

SeedPacket 公共前缀后：`mRefreshCounter +0x24`、`mRefreshTime +0x28`、
`mIndex +0x2C`、`mOffsetX +0x30`、`mPacketType +0x34`、
`mImitaterType +0x38`、`mSlotMachineCountDown +0x3C`、
`mSlotMachiningNextSeed +0x40`、`mSlotMachiningPosition f32 +0x44`、
`mActive +0x48`、`mRefreshing +0x49`、`mTimesUsed +0x4C`。

SeedBank 为公共前缀、`mNumPackets +0x24`、10 个 SeedPacket `+0x28`、
`mCutSceneDarken +0x348`、`mConveyorBeltCounter +0x34C`。

### 11.5 Challenge：188 字节

`mApp/mBoard ptr32 +0x00/+0x04`；`mBeghouledMouseCapture +0x08`；
`mBeghouledMouseDownX/Y +0x0C/+0x10`；`mBeghouledEated bool[9][6] +0x14`；
`mBeghouledPurcasedUpgrade bool[3] +0x4A`；`mBeghouledMatchesThisMove +0x50`；
`mChallengeState +0x54`；`mChallengeStateCounter +0x58`；
`mConveyorBeltCounter +0x5C`；`mChallengeScore +0x60`；
`mShowBowlingLine +0x64`；`mLastConveyorSeedType +0x68`；
`mSurvivalStage +0x6C`；`mSlotMachineRollCount +0x70`；
`mReanimChallenge +0x74`；`mReanimClouds[6] +0x78`；
`mCloudsCounter[6] +0x90`；`mChallengeGridX/Y +0xA8/+0xAC`；
`mScaryPotterPots +0xB0`；`mRainCounter +0xB4`；
`mTreeOfWisdomTalkIndex +0xB8`。

这里两个 Beghouled 数组确实是 bool；若错误声明成 `int`，Challenge 会被误算成
356 字节，后续 Music 块整体错位。

### 11.6 Music：76 字节

| 偏移 | 类型 | 字段 | 作用 |
| ---: | --- | --- | --- |
| `0x00` | `ptr32` | `mApp` | 重建。 |
| `0x04` | `ptr32` | `mMusicInterface` | 重建。 |
| `0x08` | `i32` | `mCurMusicTune` | 曲目语义编号；3=Watery Graves。 |
| `0x0C` | `i32` | `mCurMusicFileMain` | 主模块通道编号。 |
| `0x10` | `i32` | `mCurMusicFileDrums` | 鼓轨通道编号。 |
| `0x14` | `i32` | `mCurMusicFileHihats` | hi-hat 通道编号。 |
| `0x18` | `i32` | `mBurstOverride` | 强制音乐爆发状态。 |
| `0x1C` | `i32` | `mBaseBPM` | BASS 2.2 模块 BPM 整数属性。 |
| `0x20` | `i32` | `mBaseModSpeed` | BASS 2.2 模块速度整数属性。 |
| `0x24` | `i32` | `mMusicBurstState` | off/starting/on/finishing。 |
| `0x28` | `i32` | `mBurstStateCounter` | 爆发状态计数。 |
| `0x2C` | `i32` | `mMusicDrumsState` | 鼓轨关闭、排队、开启、淡出等。 |
| `0x30` | `i32` | `mQueuedDrumTrackPackedOrder` | 排队切入鼓轨的 packed order。 |
| `0x34` | `i32` | `mDrumsStateCounter` | 鼓轨状态计数。 |
| `0x38` | `i32` | `mPauseOffset` | 主轨 packed order/row。低 16 位 order，高 16 位 row。 |
| `0x3C` | `i32` | `mPauseOffsetDrums` | 夜间鼓轨 packed order/row。 |
| `0x40` | `bool` | `mPaused` | 通道已停且暂停位置有效。 |
| `0x41` | `bool` | `mMusicDisabled` | 音乐是否禁用。 |
| `0x44` | `i32` | `mFadeOutCounter` | 淡出剩余 tick。 |
| `0x48` | `i32` | `mFadeOutDuration` | 淡出总时长。 |

官方样本尾块的实测值：

```text
tune=3, main=1, drums=2, hihats=3
burstOverride=-1, baseBPM=71, baseModSpeed=2
burstState=1, burstCounter=228
drumsState=0, queuedDrums=-1, drumsCounter=0
pauseOffset=0x0025005F, pauseDrums=0
paused=1, musicDisabled=0, fadeCounter=0, fadeDuration=150
```

## 12. dat64 v1

dat64 只替换关卡中断档。文件头固定 48 字节：

| 偏移 | 类型 | 值/作用 |
| ---: | --- | --- |
| `0x00` | `char[8]` | ASCII `PVZDAT64`。 |
| `0x08` | `u32` | 格式版本 1。 |
| `0x0C` | `u32` | 头长 48。 |
| `0x10` | `u32` | 权威版本 1073。 |
| `0x14` | `u32` | flags；v1 为 1，表示小端。 |
| `0x18` | `u64` | payload 长度。 |
| `0x20` | `u32` | payload CRC32。 |
| `0x24` | `u32` | schema ID `0x00010731`。 |
| `0x28` | `u64` | 保留，必须为 0。 |

payload 仍保持官方对象图顺序和 `SyncBytes` 边界，但对象/槽使用上文 dat64 列的
x64 大小。所有本机指针槽和 x64 padding 固定写零；定义、图片和对象关系仍由
显式 ID 重建。Board 块为 22120 字节：

```text
旧 0x0000..0x563B -> 新 0x0000..0x563B
新 0x563C..0x563F -> 4 字节 x64 对齐 padding，必须为 0
旧 i32 mGameID       -> 新 i64 mGameID，偏移 0x5640
旧 0x5640..0x565B -> 新 0x5648..0x5663
```

dat64 尾部使用 `SyncBytes(8)` 保存 64 位结束标记。游戏本体只查找
`game<ID>_<mode>.dat64`，不会把同名 `.dat` 当回退格式。

## 13. 双向转换器

源码：`dat64/`。发行时构建系统把
`pvz_dat64_converter.exe` 放到游戏的 `./data` 存档目录。

单文件：

```text
pvz_dat64_converter.exe game3_13.dat
pvz_dat64_converter.exe game3_13.dat64
pvz_dat64_converter.exe 输入文件 显式输出文件
```

无参数批量模式只靠文件名决定方向：

1. 转换器目录中只要存在一个 `game数字_数字.dat`，就处理全部这种 `.dat`，
   方向为 dat→dat64。
2. 一个这种 `.dat` 都没有时，才处理全部 `game数字_数字.dat64`，方向反转。
3. `users.dat`、`user<ID>.dat` 不匹配，不读取、不删除。
4. 每个输入先完整解析到内存并验证；生成目标后，再用目标语法完整解析并逐字段
   比较。两次都成功后才原子写目标并删除源。
5. 任一文件失败会用红字给出文件偏移、字段和原因；该源文件不删除，继续处理
   其他文件。

验证项包括：头部、版本、CRC、所有 `SyncBytes` 长度、全部字段消费、bool 和浮点
合法性、枚举范围、12 个 DataArray 容量/存活计数/ID/自由链、粒子引用归属、
Reanim 轨道边界、资源 ID、固定尾对象、结束标记和双向语义相等。

dat→dat64→dat 不保证文件 SHA-256 相同：原版落盘的进程指针、ABI padding 和空闲
槽旧内容没有持久语义，转换器会规范化为零。所有有效游戏字段、对象 ID、定义 ID、
资源 ID 和播放位置必须逐字段相同。

## 14. 复核样本

官方泳池生存无尽：

```text
C:\ProgramData\PopCap Games\PlantsVsZombies\userdata\game3_13.dat
size   = 457628
SHA256 = CE27B03C06ADD14D54C3D773FD2C2D756AF13160FEDC4F2F794C1F6D2D812910
```

实测转换结果：

```text
1073 dat 457628 字节 -> dat64 513888 字节
dat64 -> 1073 dat 457628 字节
两次目标均通过完整解析与逐字段语义比较
```

