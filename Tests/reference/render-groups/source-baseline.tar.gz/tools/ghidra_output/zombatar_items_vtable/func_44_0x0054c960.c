
void __thiscall FUN_0054c960(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  if (param_4 == 3) {
    (**(code **)(*param_1 + 0xd4))(param_2,param_3,2,1);
  }
  else if (param_4 < 0) {
    (**(code **)(*param_1 + 0xd4))(param_2,param_3,1,-param_4);
  }
  else {
    (**(code **)(*param_1 + 0xd4))(param_2,param_3,0,param_4);
  }
  return;
}

