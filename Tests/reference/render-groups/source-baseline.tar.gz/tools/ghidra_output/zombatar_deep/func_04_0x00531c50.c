
void __thiscall FUN_00531c50(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int local_bc;
  int local_b8;
  undefined4 local_b4;
  undefined4 local_b0;
  undefined4 local_ac;
  int local_a8;
  int local_a4;
  int local_a0;
  int local_9c;
  undefined4 local_98;
  undefined4 local_94;
  float local_88;
  float local_84;
  void *local_14;
  undefined1 *puStack_10;
  undefined4 local_c;
  
  local_c = 0xffffffff;
  puStack_10 = &LAB_006ca96b;
  local_14 = ExceptionList;
  ExceptionList = &local_14;
  FUN_00598a60(DAT_007268d0,0,0);
  if (*(int *)(param_1 + 0x188) != 0) {
    iVar1 = FUN_0059abc0();
    local_a8 = FUN_0059aba0();
    local_a8 = local_a8 + -0x28;
    local_b0 = 600;
    local_ac = 0x136;
    local_a4 = iVar1 + -0x14;
    SetBorders(&local_b0);
    FUN_00598a60(DAT_00726ec4,600,300);
    FUN_005993a0();
    FUN_00597fa0(param_2);
    local_c = 0;
    local_88 = (float)*(int *)(*(int *)(param_1 + 0x188) + 8) + local_88;
    local_84 = (float)*(int *)(*(int *)(param_1 + 0x188) + 0xc) + local_84;
    FUN_0053ec70();
    local_c = 0xffffffff;
    FUN_005981a0();
  }
  if (*(int *)(param_1 + 0x194) != 0) {
    iVar1 = *(int *)(*(int *)(param_1 + 0x194) + 0x48);
    local_bc = iVar1 + 0x20;
    iVar2 = *(int *)(*(int *)(param_1 + 0x194) + 0x44) + 0x5a;
    local_b8 = iVar2;
    local_b4 = FUN_0059abc0();
    local_98 = FUN_0059aba0();
    local_a0 = iVar1 + 0x25;
    local_94 = local_b4;
    local_9c = iVar2;
    SetBorders(&local_a0);
    FUN_00530970(param_2,*(int *)(param_1 + 0x194) + 0xf14,&local_bc,&local_b8);
    FUN_005993a0();
    FUN_00598a60(DAT_00726760,5,0);
  }
  ExceptionList = local_14;
  return;
}

