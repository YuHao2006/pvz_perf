
undefined1 FUN_0054c200(void)

{
  return 1;
}

