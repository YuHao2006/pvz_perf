
void __fastcall FUN_0052e480(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  *(undefined1 *)(param_1 + 0xf6d) = *(undefined1 *)(param_1 + 0xf6c);
  *(undefined1 *)(param_1 + 0xf6c) = 0;
  switch(*(undefined4 *)(param_1 + 0xf5c)) {
  case 0:
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    FUN_0044af50();
    (**(code **)(**(int **)(param_1 + 0xec) + 0x58))();
    FUN_0044af50();
    FUN_0044af50();
    *(undefined4 *)(param_1 + 0xf14 + *(int *)(param_1 + 0xf10) * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0xec) + 0xd4);
    FUN_0044af50();
    return;
  case 1:
    *(int *)(param_1 + 0xf60) = *(int *)(param_1 + 0xf60) + -1;
    uVar2 = FUN_0051bea0(0x1a4,0x82,1);
    uVar3 = FUN_0051bea0(0x1bd,0x140,1);
    uVar4 = FUN_0059abc0();
    uVar5 = FUN_0059aba0();
    iVar1 = *(int *)(param_1 + 0xd4);
    *(undefined4 *)(iVar1 + 8) = uVar2;
    *(undefined4 *)(iVar1 + 0xc) = uVar3;
    *(undefined4 *)(iVar1 + 0x10) = uVar5;
    *(undefined4 *)(iVar1 + 0x14) = uVar4;
    if (*(int *)(param_1 + 0xf60) < 1) {
      *(undefined4 *)(param_1 + 0xf60) = 0;
      *(undefined4 *)(param_1 + 0xf5c) = 3;
      FUN_00530550();
      FUN_0044af50();
      return;
    }
    break;
  case 2:
    *(int *)(param_1 + 0xf60) = *(int *)(param_1 + 0xf60) + -1;
    uVar2 = FUN_0051bea0(0x82,0x1a4,1);
    uVar3 = FUN_0051bea0(0x140,0x1bd,1);
    uVar4 = FUN_0059abc0();
    uVar5 = FUN_0059aba0();
    iVar1 = *(int *)(param_1 + 0xd4);
    *(undefined4 *)(iVar1 + 0x10) = uVar5;
    *(undefined4 *)(iVar1 + 8) = uVar2;
    *(undefined4 *)(iVar1 + 0xc) = uVar3;
    *(undefined4 *)(iVar1 + 0x14) = uVar4;
    if (*(int *)(param_1 + 0xf60) < 1) {
      *(undefined4 *)(param_1 + 0xf60) = 0;
      *(undefined4 *)(param_1 + 0xf5c) = 0;
      FUN_0044af50();
      return;
    }
    break;
  case 3:
    FUN_0044af50();
    goto LAB_0052e6e4;
  case 4:
    FUN_0044af50();
    FUN_0044af50();
LAB_0052e6e4:
    FUN_0044af50();
  }
  FUN_0044af50();
  return;
}

