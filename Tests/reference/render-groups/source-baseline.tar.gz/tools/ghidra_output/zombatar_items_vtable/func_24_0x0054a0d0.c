
void __fastcall FUN_0054a0d0(int *param_1)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined1 local_18 [4];
  int local_14;
  int *local_10;
  undefined1 local_c [8];
  
  (**(code **)(*param_1 + 0x74))();
  if (param_1[7] != 0) {
    DAT_007db5b4 = DAT_007db5b4 + 1;
  }
  FUN_005b75d0(local_c);
  while( true ) {
    iVar1 = param_1[6];
    FUN_00420ae0();
    local_14 = iVar1;
    if (param_1 == (int *)0xfffffffc) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    cVar2 = FUN_006143c0(local_18);
    if (cVar2 != '\0') break;
    puVar3 = (undefined4 *)FUN_005e2150();
    local_10 = (int *)*puVar3;
    (**(code **)(*local_10 + 0x70))();
    FUN_00614350();
  }
  return;
}

