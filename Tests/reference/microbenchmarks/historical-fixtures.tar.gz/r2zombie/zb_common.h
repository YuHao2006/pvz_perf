// zb_common.h — Zombie.cpp 段表性能对拍（第二轮补测）公共桩框架
// 基准目录: _shared/bench35/r2zombie/（不触碰仓库文件）
// 枚举/轨道真值直接 include 仓库 ConstEnums.h / ReanimTrackId.h（只读），
// 保证表下标与枚举序与仓库完全一致。单 TU 使用（每 bench.cpp 独立编译）。
#pragma once

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#define NOMINMAX
#include <windows.h>
// 仓库只读头（枚举/轨道真值）：MSVC 预处理器不支持 include 宏拼接，直接写全路径
#include "C:/Users/Administrator/CLionProjects/codex/PlantsVsZombiesModern/ConstEnums.h"
#include "C:/Users/Administrator/CLionProjects/codex/PlantsVsZombiesModern/Sexy.TodLib/ReanimTrackId.h"
#include <algorithm>

// ============================ 常量（照抄仓库 Lawn/Zombie.h / Reanimator.h） ============================
constexpr const int BUNGEE_ZOMBIE_HEIGHT = 3000;
constexpr const int POGO_BOUNCE_TIME = 80;
constexpr const int DOLPHIN_JUMP_TIME = 120;
constexpr const int BOSS_FLASH_HEALTH_FRACTION = 10;
constexpr const int RENDER_GROUP_HIDDEN = -1;
constexpr const int RENDER_GROUP_NORMAL = 0;
constexpr const int RENDER_GROUP_OVER_SHIELD = 3;  // Lawn/Zombie.h:15

#define LENGTH(a) (sizeof(a) / sizeof((a)[0]))

inline bool TestBit(unsigned int theNum, int theIdx) { return theNum & (1u << theIdx); }

// ============================ 极小补充枚举（仓库中位于未引入的大头文件，仅取所需成员） ============================
enum ZombieAttackType { ATTACKTYPE_VAULT = 0, ATTACKTYPE_CHEW = 1 };
enum FoleyType
{
    FOLEY_GRASSSTEP = 0, FOLEY_SHIELD_HIT, FOLEY_DIRT_RISE, FOLEY_WAKEUP,
    FOLEY_GARGANTUDEATH, FOLEY_EXPLOSION, FOLEY_BONK, FOLEY_DOLPHIN_BEFORE_JUMPING,
    FOLEY_PLANT_WATER, FOLEY_ZOMBIE_ENTERING_WATER, FOLEY_LIMBS_POP, FOLEY_BOSS_EXPLOSION_SMALL
};

// ============================ Sink（编号桩统一入 checksum） ============================
inline uint64_t g_zb_sink = 0;
inline void ZSink(uint32_t theId, uint32_t a = 0, uint32_t b = 0, uint32_t c = 0)
{
    g_zb_sink = g_zb_sink * 1000003ull + (theId * 97ull + a * 31ull + b * 7ull + c);
}
inline uint64_t ZBMixU64(uint64_t h, uint64_t v) { return h * 1000003ull + v; }

// 桩编号（全局唯一）
enum ZStubId
{
    ZID_Reanimation_TrackExists = 1, ZID_Reanimation_SetImageOverride, ZID_Reanimation_GetImageOverride,
    ZID_Reanimation_PlayReanim, ZID_Reanimation_SetFramesForLayer, ZID_Reanimation_AssignRange,
    ZID_Reanimation_AssignTrack, ZID_Reanimation_ShouldTriggerTimedEvent, ZID_Reanimation_OverrideScale,
    ZID_Reanimation_ReanimationDie, ZID_Reanimation_AttachParticleToTrack,
    ZID_Particle_OverrideImage, ZID_Particle_OverrideFrame,
    ZID_App_PlayFoley, ZID_App_ReanimationGetID, ZID_App_RemoveReanimation,
    ZID_App_AddReanimation, ZID_App_AddTodParticle,
    ZID_Z_DropShield, ZID_Z_DropHelm, ZID_Z_ApplyChill, ZID_Z_UpdateAnimSpeed,
    ZID_Z_SetupReanimForLostHead, ZID_Z_GetTrackPosition, ZID_Z_ReanimShowRange,
    ZID_Z_ReanimShowTrack, ZID_Z_OverrideParticleScale, ZID_Z_OverrideParticleColor,
    ZID_Z_PogoBreak, ZID_Z_DropPole, ZID_Z_DropFlag, ZID_Z_BobsledCrash, ZID_Z_DieNoLoot,
    ZID_Z_BungeeLanding, ZID_Z_BungeeStealTarget, ZID_Z_BungeeLiftTarget,
    ZID_Z_StartWalkAnim, ZID_Z_PlayZombieReanim, ZID_Z_PickRandomSpeed, ZID_Z_PoolSplash,
    ZID_Z_TakeDamage, ZID_Z_StopZombieSound, ZID_Z_AddAttachedReanim, ZID_Z_AddAttachedParticle,
    ZID_Z_AttachmentReanimTypeDie, ZID_Z_StopEating, ZID_Z_ZamboniDeath, ZID_Z_CatapultDeath,
    ZID_Z_ApplyBossSmokeParticles, ZID_Z_BossDie, ZID_Z_UpdateDamageStates, ZID_Z_PlayDeathAnim,
    ZID_Z_DropLoot, ZID_Z_DieWithLoot, ZID_Z_DropHead, ZID_Z_DropArm, ZID_Z_RemoveIceTrap,
    ZID_Z_ShowYuckyFace, ZID_Z_SetupDoorArms, ZID_Z_ReanimIgnoreClipRect, ZID_Z_GetDrawPos,
    ZID_Rand, ZID_RandRangeFloat, ZID_ReanimatorEnsureDefinitionLoaded,
    ZID_AttachmentDetachCrossFadeParticleType,
};

// ============================ 贴图全局桩（运行期装载语义：Image* 全局，表存 &全局） ============================
struct Image { int mId; };
inline Image g_zb_images[80];
inline Image* ZBImg(int i) { return &g_zb_images[i]; }

// TakeHelmDamage
inline Image* IMAGE_REANIM_ZOMBIE_CONE2 = ZBImg(1);
inline Image* IMAGE_REANIM_ZOMBIE_CONE3 = ZBImg(2);
inline Image* IMAGE_REANIM_ZOMBIE_BUCKET2 = ZBImg(3);
inline Image* IMAGE_REANIM_ZOMBIE_BUCKET3 = ZBImg(4);
inline Image* IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2 = ZBImg(5);
inline Image* IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3 = ZBImg(6);
inline Image* IMAGE_REANIM_ZOMBIE_DIGGER_HARDHAT2 = ZBImg(7);
inline Image* IMAGE_REANIM_ZOMBIE_DIGGER_HARDHAT3 = ZBImg(8);
inline Image* IMAGE_REANIM_WALLNUT_CRACKED1 = ZBImg(9);
inline Image* IMAGE_REANIM_WALLNUT_CRACKED2 = ZBImg(10);
inline Image* IMAGE_REANIM_TALLNUT_CRACKED1 = ZBImg(11);
inline Image* IMAGE_REANIM_TALLNUT_CRACKED2 = ZBImg(12);
// TakeShieldDamage
inline Image* IMAGE_REANIM_ZOMBIE_SCREENDOOR2 = ZBImg(13);
inline Image* IMAGE_REANIM_ZOMBIE_SCREENDOOR3 = ZBImg(14);
inline Image* IMAGE_REANIM_ZOMBIE_PAPER_PAPER2 = ZBImg(15);
inline Image* IMAGE_REANIM_ZOMBIE_PAPER_PAPER3 = ZBImg(16);
inline Image* IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1 = ZBImg(17);
inline Image* IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2 = ZBImg(18);
// DropHead
inline Image* IMAGE_ZOMBIEDANCERHEAD = ZBImg(19);
inline Image* IMAGE_ZOMBIEBACKUPDANCERHEAD = ZBImg(20);
inline Image* IMAGE_ZOMBIEBOBSLEDHEAD = ZBImg(21);
inline Image* IMAGE_ZOMBIELADDERHEAD = ZBImg(22);
inline Image* IMAGE_ZOMBIEIMPHEAD = ZBImg(23);
inline Image* IMAGE_ZOMBIEFOOTBALLHEAD = ZBImg(24);
inline Image* IMAGE_ZOMBIEPOLEVAULTERHEAD = ZBImg(25);
inline Image* IMAGE_REANIM_ZOMBIE_SNORKLE_HEAD = ZBImg(26);
inline Image* IMAGE_ZOMBIEDIGGERHEAD = ZBImg(27);
inline Image* IMAGE_ZOMBIEDOLPHINRIDERHEAD = ZBImg(28);
inline Image* IMAGE_ZOMBIEYETIHEAD = ZBImg(29);
inline Image* IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES1 = ZBImg(30);
inline Image* IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES2 = ZBImg(31);
inline Image* IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES3 = ZBImg(32);
inline Image* IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES4 = ZBImg(33);
// TakeBodyDamage
inline Image* IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE1 = ZBImg(34);
inline Image* IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE2 = ZBImg(35);
inline Image* IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE1 = ZBImg(36);
inline Image* IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE2 = ZBImg(37);
inline Image* IMAGE_REANIM_ZOMBIE_CATAPULT_SIDING_DAMAGE = ZBImg(38);
inline Image* IMAGE_REANIM_ZOMBIE_GARGANTUAR_BODY1_2 = ZBImg(39);
inline Image* IMAGE_REANIM_ZOMBIE_GARGANTUAR_BODY1_3 = ZBImg(40);
inline Image* IMAGE_REANIM_ZOMBIE_GARGANTUAR_OUTERARM_LOWER2 = ZBImg(41);
inline Image* IMAGE_REANIM_ZOMBIE_GARGANTUAR_FOOT2 = ZBImg(42);
inline Image* IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD2 = ZBImg(43);
inline Image* IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD2_REDEYE = ZBImg(44);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_HEAD_DAMAGE1 = ZBImg(45);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_HEAD_DAMAGE2 = ZBImg(46);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_JAW_DAMAGE1 = ZBImg(47);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_JAW_DAMAGE2 = ZBImg(48);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_HAND_DAMAGE1 = ZBImg(49);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_HAND_DAMAGE2 = ZBImg(50);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_THUMB_DAMAGE1 = ZBImg(51);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_THUMB_DAMAGE2 = ZBImg(52);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_FOOT_DAMAGE1 = ZBImg(53);
inline Image* IMAGE_REANIM_ZOMBIE_BOSS_FOOT_DAMAGE2 = ZBImg(54);

// ============================ 支撑小类型 ============================
struct Rect
{
    int mX, mY, mWidth, mHeight;
    Rect() : mX(0), mY(0), mWidth(0), mHeight(0) {}
    Rect(int x, int y, int w, int h) : mX(x), mY(y), mWidth(w), mHeight(h) {}
};

struct ZombieDrawPosition
{
    float mImageOffsetX, mImageOffsetY, mHeadX, mHeadY, mBodyY;
    ZombieDrawPosition() : mImageOffsetX(0), mImageOffsetY(0), mHeadX(0), mHeadY(0), mBodyY(0) {}
};

struct AttachEffect { bool mDontDrawIfParentHidden; bool mDontPropogateColor; };

struct TodParticleSystem
{
    __declspec(noinline) void OverrideImage(Image* theOld, Image* theNew)
    {
        ZSink(ZID_Particle_OverrideImage, theNew ? (uint32_t)theNew->mId : 0u);
    }
    __declspec(noinline) void OverrideFrame(Image* theOld, int theFrame)
    {
        ZSink(ZID_Particle_OverrideFrame, (uint32_t)theFrame);
    }
};
inline TodParticleSystem g_zb_particle;

// ============================ Reanimation 桩（读写字段保留；方法=编号桩） ============================
struct Reanimation
{
    int mLoopCount = 0;
    float mAnimTime = 0.0f;
    float mAnimRate = 0.0f;
    bool mIsAttachment = false;
    ReanimLoopType mLoopType = REANIM_LOOP;

    __declspec(noinline) bool TrackExists(ReanimTrackId theTrackId)
    {
        // 确定性混频：~75% true，让水亡/超长死/anim_death2 支都有命中
        return ((uint32_t)theTrackId % 4) != 3;
    }
    __declspec(noinline) void SetImageOverride(ReanimTrackId theTrackId, Image* theImage)
    {
        ZSink(ZID_Reanimation_SetImageOverride, (uint32_t)theTrackId, theImage ? (uint32_t)theImage->mId : 0u);
    }
    __declspec(noinline) Image* GetImageOverride(ReanimTrackId theTrackId)
    {
        switch ((uint32_t)theTrackId % 9)
        {
        case 0: return nullptr;
        case 1: return IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES1;
        case 2: return IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES2;
        case 3: return IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES3;
        case 4: return IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES4;
        default: return ZBImg(60 + ((uint32_t)theTrackId % 10));
        }
    }
    __declspec(noinline) void PlayReanim(ReanimTrackId theTrackId, ReanimLoopType theLoopType, int theAnimStartPct, float theAnimRate)
    {
        ZSink(ZID_Reanimation_PlayReanim, (uint32_t)theTrackId, (uint32_t)theLoopType, (uint32_t)(int)theAnimRate);
    }
    __declspec(noinline) void SetFramesForLayer(ReanimTrackId theTrackId)
    {
        ZSink(ZID_Reanimation_SetFramesForLayer, (uint32_t)theTrackId);
    }
    __declspec(noinline) void AssignRenderGroupToRange(const ReanimTrackIdRange& theRange, int theGroup)
    {
        ZSink(ZID_Reanimation_AssignRange, (uint32_t)theRange.mLo, (uint32_t)theRange.mHi, (uint32_t)theGroup);
    }
    __declspec(noinline) void AssignRenderGroupToTrack(ReanimTrackId theTrackId, int theGroup)
    {
        // 与 AssignRenderGroupToRange([t, t+1)) 同义归一（HEAD kZombieLayerOps 将单轨
        // 操作编码为单元素区间——Reanimator.cpp 两实现等价），sink 语义等价校验
        ZSink(ZID_Reanimation_AssignRange, (uint32_t)theTrackId, (uint32_t)theTrackId + 1, (uint32_t)theGroup);
    }
    __declspec(noinline) bool ShouldTriggerTimedEvent(float theTime)
    {
        // 纯状态确定：两形态同状态同结果
        return mAnimTime > theTime;
    }
    __declspec(noinline) void OverrideScale(float x, float y)
    {
        ZSink(ZID_Reanimation_OverrideScale, (uint32_t)(int)(x * 10.0f), (uint32_t)(int)(y * 10.0f));
    }
    __declspec(noinline) void ReanimationDie()
    {
        ZSink(ZID_Reanimation_ReanimationDie);
    }
    __declspec(noinline) AttachEffect* AttachParticleToTrack(ReanimTrackId theTrackId, TodParticleSystem* theParticle, float x, float y)
    {
        ZSink(ZID_Reanimation_AttachParticleToTrack, (uint32_t)theTrackId, (uint32_t)(int)x);
        static AttachEffect sEffect;
        return &sEffect;
    }
};
inline Reanimation g_zb_reanimA, g_zb_reanimB, g_zb_scratchReanim;

// ============================ 随机数桩（全局序列，跑前重置；两形态序列一致） ============================
inline uint32_t g_zb_rng = 0x9E3779B9u;
inline void ZBRngReset(uint32_t s = 0x9E3779B9u) { g_zb_rng = s; }
__declspec(noinline) int Rand(int theMax)
{
    g_zb_rng ^= g_zb_rng << 13; g_zb_rng ^= g_zb_rng >> 17; g_zb_rng ^= g_zb_rng << 5;
    int v = (int)(g_zb_rng % (uint32_t)(theMax > 0 ? theMax : 1));
    ZSink(ZID_Rand, (uint32_t)v);
    return v;
}
__declspec(noinline) float RandRangeFloat(float theMin, float theMax)
{
    g_zb_rng ^= g_zb_rng << 13; g_zb_rng ^= g_zb_rng >> 17; g_zb_rng ^= g_zb_rng << 5;
    float v = theMin + (g_zb_rng % 1000u) / 1000.0f * (theMax - theMin);
    ZSink(ZID_RandRangeFloat, (uint32_t)(int)(v * 10.0f));
    return v;
}

// ============================ 曲线（真实数学，两形态共用） ============================
namespace Curves
{
    inline float EaseInW(float t) { return t * t; }
    inline float EaseOutW(float t) { return 1.0f - (1.0f - t) * (1.0f - t); }
    inline float Linear(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); return a + (b - a) * EaseInW(x); }
    inline float EaseIn(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); return a + (b - a) * EaseInW(x); }
    inline float EaseOut(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); return a + (b - a) * EaseOutW(x); }
    inline float SinWave(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); return a + (b - a) * (0.5f - 0.5f * cosf(3.14159265f * x)); }
    inline float BounceSlowMiddle(float t, float a, float b) { float x = t < 0 ? 0 : (t > 1 ? 1 : t); float d = 2.0f * x - 1.0f; return a + (b - a) * (1.0f - d * d); }
}
inline float TodCurveEvaluateClamped(float t, float a, float b, float (*curve)(float, float, float)) { return curve(t, a, b); }
inline float TodAnimateCurveFloat(int theTimeStart, int theTimeEnd, int theTimeAge, float thePositionStart, float thePositionEnd, float (*theCurve)(float, float, float))
{
    float aWarpedAge = (theTimeAge - theTimeStart) / (float)(theTimeEnd - theTimeStart);
    return TodCurveEvaluateClamped(aWarpedAge, thePositionStart, thePositionEnd, theCurve);
}
inline int TodAnimateCurve(int theTimeStart, int theTimeEnd, int theTimeAge, int thePositionStart, int thePositionEnd, float (*theCurve)(float, float, float))
{
    return (int)TodAnimateCurveFloat(theTimeStart, theTimeEnd, theTimeAge, (float)thePositionStart, (float)thePositionEnd, theCurve);
}

// ============================ ZombieDefinition / 装载桩 ============================
class ZombieDefinition
{
public:
    ZombieType mZombieType = ZOMBIE_NORMAL;
    ReanimationType mReanimationType = ReanimationType::REANIM_NONE;
    int mZombieValue = 0, mStartingLevel = 0, mFirstAllowedWave = 0, mPickWeight = 0;
    const char* mZombieName = "";
};
inline ZombieDefinition g_zb_zombieDefs[NUM_ZOMBIE_TYPES];
inline ZombieDefinition& GetZombieDefinition(ZombieType theZombieType) { return g_zb_zombieDefs[(int)theZombieType]; }
inline ZombieType g_zb_bossZombieList[4] = { ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_ZAMBONI, ZOMBIE_GARGANTUAR };
#define gBossZombieList g_zb_bossZombieList
__declspec(noinline) void ReanimatorEnsureDefinitionLoaded(ReanimationType theReanimType, bool theIsPreloading)
{
    ZSink(ZID_ReanimatorEnsureDefinitionLoaded, (uint32_t)theReanimType);
}
__declspec(noinline) void AttachmentDetachCrossFadeParticleType(AttachmentID theID, ParticleEffect theEffect, void* theUserData)
{
    ZSink(ZID_AttachmentDetachCrossFadeParticleType, (uint32_t)theEffect);
}

// ============================ Board / LawnApp / Plant 桩 ============================
struct Plant { SeedType mSeedType = SeedType::SEED_TALLNUT; int mX = 300, mY = 400; };
inline Plant g_zb_plant;

struct Board
{
    bool mMustacheMode = false, mFutureMode = false, mPinataMode = false;
    int mLevel = 7;
    PlantRowType mPlantRow[6] = { PLANTROW_NORMAL, PLANTROW_NORMAL, PLANTROW_POOL, PLANTROW_NORMAL, PLANTROW_HIGH_GROUND, PLANTROW_DIRT };
    __declspec(noinline) int CountZombiesOnScreen() { return mLevel % 9; }
    static int MakeRenderOrder(RenderLayer theLayer, int theRow, int theOffset) { return (int)theLayer + theRow * 100 + theOffset; }
};
inline Board g_zb_board;

struct LawnApp
{
    Board* mBoard = &g_zb_board;
    __declspec(noinline) void PlayFoley(FoleyType theFoleyType) { ZSink(ZID_App_PlayFoley, (uint32_t)theFoleyType); }
    __declspec(noinline) Reanimation* ReanimationTryToGet(ReanimationID theID)
    {
        return (unsigned)theID == 0u ? nullptr : ((unsigned)theID == 2u ? &g_zb_reanimB : &g_zb_reanimA);
    }
    __declspec(noinline) Reanimation* ReanimationGet(ReanimationID theID)
    {
        return (unsigned)theID == 2u ? &g_zb_reanimB : &g_zb_reanimA;
    }
    __declspec(noinline) ReanimationID ReanimationGetID(Reanimation* theReanimation)
    {
        ZSink(ZID_App_ReanimationGetID, (uint32_t)(theReanimation ? 7 : 0));
        return (ReanimationID)7;
    }
    __declspec(noinline) void RemoveReanimation(ReanimationID theID) { ZSink(ZID_App_RemoveReanimation, (uint32_t)theID); }
    __declspec(noinline) Reanimation* AddReanimation(float theX, float theY, int theRenderOrder, ReanimationType theType)
    {
        ZSink(ZID_App_AddReanimation, (uint32_t)theType, (uint32_t)(int)theX, (uint32_t)theRenderOrder);
        g_zb_scratchReanim.mAnimRate = 0.0f;
        g_zb_scratchReanim.mIsAttachment = false;
        g_zb_scratchReanim.mLoopType = REANIM_LOOP;
        return &g_zb_scratchReanim;
    }
    __declspec(noinline) TodParticleSystem* AddTodParticle(float theX, float theY, int theRenderOrder, ParticleEffect theEffect)
    {
        ZSink(ZID_App_AddTodParticle, (uint32_t)theEffect, (uint32_t)(int)theX, (uint32_t)theRenderOrder);
        return ((uint32_t)theEffect % 3 == 0) ? nullptr : &g_zb_particle;
    }
    __declspec(noinline) bool HasFinishedAdventure() { return mBoard && mBoard->mLevel > 10; }
};
inline LawnApp g_zb_app;

// ============================ Zombie 桩（字段照抄名；成员函数=编号桩；查询=纯状态函数） ============================
struct Zombie
{
    // 字段（目标函数读写集）
    LawnApp* mApp;
    Board* mBoard;
    ZombieType mZombieType;
    ZombiePhase mZombiePhase;
    ZombieHeight mZombieHeight;
    int mX, mY;
    float mPosX, mPosY;
    float mVelX;
    float mAltitude;
    bool mInPool, mIsEating, mHasHead, mHasArm, mHasObject, mDead, mMindControlled;
    int mFrame, mRow, mRenderOrder, mFromWave, mPhaseCounter;
    ReanimationID mBodyReanimID, mSpecialHeadReanimID, mMoweredReanimID;
    AttachmentID mAttachmentID;
    ZombieID mRelatedZombieID;
    HelmType mHelmType;
    int mHelmHealth, mHelmMaxHealth;
    ShieldType mShieldType;
    int mShieldHealth, mShieldMaxHealth;
    int mBodyHealth, mBodyMaxHealth;
    int mFlyingHealth;
    int mJustGotShotCounter, mShieldJustGotShotCounter, mShieldRecoilCounter;
    int mIceTrapCounter, mButteredCounter, mChilledCounter, mYuckyFaceCounter;
    bool mYuckyFace;
    Rect mZombieRect, mZombieAttackRect;
    float mScaleZombie;

    // ---- 对拍形态函数声明（各 bench.cpp 提供定义；_A=403c1968^ 原链 / _B=HEAD 表形态；
    //      noinline 两侧一致，防循环级 FP 优化假阴性） ----
    __declspec(noinline) int TakeHelmDamage_A(int theDamage, unsigned int theDamageFlags);
    __declspec(noinline) int TakeHelmDamage_B(int theDamage, unsigned int theDamageFlags);
    __declspec(noinline) int TakeShieldDamage_A(int theDamage, unsigned int theDamageFlags);
    __declspec(noinline) int TakeShieldDamage_B(int theDamage, unsigned int theDamageFlags);
    __declspec(noinline) void TakeBodyDamage_A(int theDamage, unsigned int theDamageFlags);
    __declspec(noinline) void TakeBodyDamage_B(int theDamage, unsigned int theDamageFlags);
    __declspec(noinline) void PlayDeathAnim_A(unsigned int theDamageFlags);
    __declspec(noinline) void PlayDeathAnim_B(unsigned int theDamageFlags);
    __declspec(noinline) void DropHead_A(unsigned int theDamageFlags);
    __declspec(noinline) void DropHead_B(unsigned int theDamageFlags);
    __declspec(noinline) void MowDown_A();
    __declspec(noinline) void MowDown_B();
    __declspec(noinline) void SetupReanimLayers_A(Reanimation* aReanim, ZombieType theZombieType);
    __declspec(noinline) void SetupReanimLayers_B(Reanimation* aReanim, ZombieType theZombieType);
    __declspec(noinline) void PreloadZombieResources_A(ZombieType theZombieType);
    __declspec(noinline) void PreloadZombieResources_B(ZombieType theZombieType);
    __declspec(noinline) void UpdateZombieSnorkel_A();
    __declspec(noinline) void UpdateZombieSnorkel_B();
    __declspec(noinline) void UpdateZombieBungee_A();
    __declspec(noinline) void UpdateZombieBungee_B();
    __declspec(noinline) void UpdateZombieDolphinRider_A();
    __declspec(noinline) void UpdateZombieDolphinRider_B();
    __declspec(noinline) void UpdateZombieDigger_A();
    __declspec(noinline) void UpdateZombieDigger_B();

    // ---- 残迹清零（两形态每迭代起点全字段一致；早退迭代不残留上一迭代写值） ----
    __declspec(noinline) void ZBClearResidue()
    {
        mX = 0; mY = 0;
        mPosX = 0.0f; mPosY = 0.0f; mVelX = 0.0f; mAltitude = 0.0f; mScaleZombie = 1.0f;
        mFrame = 0; mPhaseCounter = 0; mRenderOrder = 0; mRow = 0; mFromWave = 0;
        mZombieType = ZOMBIE_NORMAL; mZombiePhase = PHASE_ZOMBIE_NORMAL; mZombieHeight = HEIGHT_ZOMBIE_NORMAL;
        mZombieRect = Rect(); mZombieAttackRect = Rect();
        mJustGotShotCounter = 0; mShieldJustGotShotCounter = 0; mShieldRecoilCounter = 0;
        mIceTrapCounter = 0; mButteredCounter = 0; mChilledCounter = 0; mYuckyFaceCounter = 0;
        mBodyHealth = 200; mBodyMaxHealth = 270; mHelmHealth = 200; mHelmMaxHealth = 270;
        mShieldHealth = 100; mShieldMaxHealth = 180; mFlyingHealth = 0;
        mDead = false; mHasHead = true; mHasArm = true; mHasObject = false;
        mInPool = false; mIsEating = false; mYuckyFace = false; mMindControlled = false;
        mBodyReanimID = (ReanimationID)1; mSpecialHeadReanimID = (ReanimationID)1;
        mMoweredReanimID = (ReanimationID)0; mAttachmentID = ATTACHMENTID_NULL;
        mRelatedZombieID = ZOMBIEID_NULL;
        mApp = &g_zb_app; mBoard = &g_zb_board;
    }

    // ---- 纯查询（决定分支走向，两形态共享，无桩开销） ----
    __declspec(noinline) bool IsDeadOrDying()
    {
        return mDead || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_DYING ||
            mZombiePhase == ZombiePhase::PHASE_ZOMBIE_BURNED || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED;
    }
    __declspec(noinline) bool IsImmobilizied() { return mIceTrapCounter > 0 || mButteredCounter > 0; }
    __declspec(noinline) bool IsWalkingBackwards() { return mVelX < 0.0f; }
    __declspec(noinline) bool IsTangleKelpTarget() { return mInPool && mZombieHeight == ZombieHeight::HEIGHT_DRAGGED_UNDER; }
    __declspec(noinline) bool IsTanglekelpTarget() { return mInPool && mZombieHeight == ZombieHeight::HEIGHT_DRAGGED_UNDER; }
    __declspec(noinline) bool IsFlying()
    {
        return mZombieType == ZombieType::ZOMBIE_BALLOON && mZombiePhase == ZombiePhase::PHASE_BALLOON_FLYING;
    }
    __declspec(noinline) bool IsOnBoard() { return mBoard != nullptr; }
    __declspec(noinline) bool IsBobsledTeamWithSled() { return mHasObject; }
    __declspec(noinline) bool CanLoseBodyParts()
    {
        return mZombieType != ZombieType::ZOMBIE_GARGANTUAR && mZombieType != ZombieType::ZOMBIE_REDEYE_GARGANTUAR &&
            mZombieType != ZombieType::ZOMBIE_BOSS;
    }
    static bool IsZombotany(ZombieType theZombieType)
    {
        return theZombieType >= ZombieType::ZOMBIE_PEA_HEAD && theZombieType <= ZombieType::ZOMBIE_TALLNUT_HEAD;
    }
    // 损伤档（真实逻辑，纯计算）
    __declspec(noinline) int GetHelmDamageIndex()
    {
        if (mHelmHealth < mHelmMaxHealth / 3) return 2;
        if (mHelmHealth < mHelmMaxHealth * 2 / 3) return 1;
        return 0;
    }
    __declspec(noinline) int GetBodyDamageIndex()
    {
        if (mZombieType == ZombieType::ZOMBIE_BOSS)
        {
            if (mBodyHealth < mBodyMaxHealth / 2) return 2;
            if (mBodyHealth < mBodyMaxHealth * 4 / 5) return 1;
            return 0;
        }
        if (mBodyHealth < mBodyMaxHealth / 3) return 2;
        if (mBodyHealth < mBodyMaxHealth * 2 / 3) return 1;
        return 0;
    }
    __declspec(noinline) int GetShieldDamageIndex()
    {
        if (mShieldHealth < mShieldMaxHealth / 3) return 2;
        if (mShieldHealth < mShieldMaxHealth * 2 / 3) return 1;
        return 0;
    }

    // ---- 动作桩（编号入 checksum） ----
    __declspec(noinline) void DropShield(unsigned int f) { ZSink(ZID_Z_DropShield, f); }
    __declspec(noinline) void DropHelm(unsigned int f) { ZSink(ZID_Z_DropHelm, f); }
    __declspec(noinline) void ApplyChill(bool b) { ZSink(ZID_Z_ApplyChill, b); }
    __declspec(noinline) void UpdateAnimSpeed() { ZSink(ZID_Z_UpdateAnimSpeed); }
    __declspec(noinline) void SetupReanimForLostHead() { ZSink(ZID_Z_SetupReanimForLostHead); }
    __declspec(noinline) void GetTrackPosition(ReanimTrackId t, float& x, float& y)
    {
        ZSink(ZID_Z_GetTrackPosition, (uint32_t)t);
        x += (float)(int)t; y += 2.0f;
    }
    __declspec(noinline) void ReanimShowRange(const ReanimTrackIdRange& r, int theGroup)
    {
        ZSink(ZID_Z_ReanimShowRange, (uint32_t)r.mLo, (uint32_t)r.mHi, (uint32_t)theGroup);
    }
    __declspec(noinline) void ReanimShowTrack(ReanimTrackId t, int theGroup)
    {
        ZSink(ZID_Z_ReanimShowTrack, (uint32_t)t, (uint32_t)theGroup);
    }
    __declspec(noinline) void OverrideParticleScale(TodParticleSystem* p) { ZSink(ZID_Z_OverrideParticleScale, p ? 1u : 0u); }
    __declspec(noinline) void OverrideParticleColor(TodParticleSystem* p) { ZSink(ZID_Z_OverrideParticleColor, p ? 1u : 0u); }
    __declspec(noinline) void PogoBreak(unsigned int f) { ZSink(ZID_Z_PogoBreak, f); }
    __declspec(noinline) void DropPole() { ZSink(ZID_Z_DropPole); }
    __declspec(noinline) void DropFlag() { ZSink(ZID_Z_DropFlag); }
    __declspec(noinline) void BobsledCrash() { ZSink(ZID_Z_BobsledCrash); }
    __declspec(noinline) void DieNoLoot() { ZSink(ZID_Z_DieNoLoot); }
    __declspec(noinline) void BungeeLanding() { ZSink(ZID_Z_BungeeLanding); }
    __declspec(noinline) void BungeeStealTarget() { ZSink(ZID_Z_BungeeStealTarget); }
    __declspec(noinline) void BungeeLiftTarget() { ZSink(ZID_Z_BungeeLiftTarget); }
    __declspec(noinline) void StartWalkAnim(int i) { ZSink(ZID_Z_StartWalkAnim, (uint32_t)i); }
    __declspec(noinline) void PlayZombieReanim(ReanimTrackId t, ReanimLoopType l, int i, float r)
    {
        ZSink(ZID_Z_PlayZombieReanim, (uint32_t)t, (uint32_t)l, (uint32_t)(int)r);
    }
    __declspec(noinline) void PickRandomSpeed() { ZSink(ZID_Z_PickRandomSpeed); }
    __declspec(noinline) void PoolSplash(bool b) { ZSink(ZID_Z_PoolSplash, b); }
    __declspec(noinline) void TakeDamage(int d, unsigned int f) { ZSink(ZID_Z_TakeDamage, (uint32_t)d, f); }
    __declspec(noinline) void StopZombieSound() { ZSink(ZID_Z_StopZombieSound); }
    __declspec(noinline) void AddAttachedReanim(int x, int y, ReanimationType t) { ZSink(ZID_Z_AddAttachedReanim, (uint32_t)x, (uint32_t)y, (uint32_t)t); }
    __declspec(noinline) void AddAttachedParticle(int x, int y, ParticleEffect e) { ZSink(ZID_Z_AddAttachedParticle, (uint32_t)x, (uint32_t)y, (uint32_t)e); }
    __declspec(noinline) void AttachmentReanimTypeDie(AttachmentID id, ReanimationType t) { ZSink(ZID_Z_AttachmentReanimTypeDie, (uint32_t)t); }
    __declspec(noinline) void StopEating() { ZSink(ZID_Z_StopEating); }
    __declspec(noinline) void ZamboniDeath(unsigned int f) { ZSink(ZID_Z_ZamboniDeath, f); }
    __declspec(noinline) void CatapultDeath(unsigned int f) { ZSink(ZID_Z_CatapultDeath, f); }
    __declspec(noinline) void ApplyBossSmokeParticles(bool b) { ZSink(ZID_Z_ApplyBossSmokeParticles, b); }
    __declspec(noinline) void BossDie() { ZSink(ZID_Z_BossDie); }
    __declspec(noinline) void UpdateDamageStates(unsigned int f) { ZSink(ZID_Z_UpdateDamageStates, f); }
    __declspec(noinline) void PlayDeathAnim(unsigned int f) { ZSink(ZID_Z_PlayDeathAnim, f); }
    __declspec(noinline) void DropLoot() { ZSink(ZID_Z_DropLoot); }
    __declspec(noinline) void DieWithLoot() { ZSink(ZID_Z_DieWithLoot); }
    __declspec(noinline) void DropHead(unsigned int f) { ZSink(ZID_Z_DropHead, f); }
    __declspec(noinline) void DropArm(unsigned int f) { ZSink(ZID_Z_DropArm, f); }
    __declspec(noinline) void RemoveIceTrap() { ZSink(ZID_Z_RemoveIceTrap); }
    __declspec(noinline) void ShowYuckyFace(bool b) { ZSink(ZID_Z_ShowYuckyFace, b); }
    __declspec(noinline) void SetupDoorArms(Reanimation* aReanim, bool theShow) { ZSink(ZID_Z_SetupDoorArms, theShow); }
    __declspec(noinline) void ReanimIgnoreClipRect(ReanimTrackId t, bool b) { ZSink(ZID_Z_ReanimIgnoreClipRect, (uint32_t)t, b); }
    __declspec(noinline) void GetDrawPos(ZombieDrawPosition& theDrawPos)
    {
        ZSink(ZID_Z_GetDrawPos);
        theDrawPos.mImageOffsetX = 3.0f; theDrawPos.mImageOffsetY = 4.0f;
        theDrawPos.mHeadX = 5.0f; theDrawPos.mHeadY = 6.0f; theDrawPos.mBodyY = 7.0f;
    }
    __declspec(noinline) Plant* FindPlantTarget(ZombieAttackType theAttackType)
    {
        // 纯状态：返回值影响后续分支，两形态一致
        if (((int)mZombiePhase & 1) == 0) return nullptr;
        g_zb_plant.mSeedType = (mRow & 1) ? SeedType::SEED_TALLNUT : SeedType::SEED_PEASHOOTER;
        return &g_zb_plant;
    }

    // ---- 状态哈希（每次调用后折叠被写字段，两形态等价校验） ----
    __declspec(noinline) void HashFold(uint64_t& h) const
    {
        h = ZBMixU64(h, (uint64_t)(uint64_t)(int64_t)mZombieType);
        h = ZBMixU64(h, (uint64_t)(int64_t)mZombiePhase);
        h = ZBMixU64(h, (uint64_t)(int64_t)mZombieHeight);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mX);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mY);
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mPosX));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mPosY));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mVelX));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mAltitude));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mScaleZombie));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mFrame);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mPhaseCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mBodyHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mHelmHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mShieldHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mJustGotShotCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mShieldJustGotShotCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mShieldRecoilCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mIceTrapCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(int32_t)mButteredCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mZombieAttackRect.mX * 31 + mZombieAttackRect.mWidth));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mZombieRect.mX * 31 + mZombieRect.mWidth));
    }
};

// ============================ 输入数组 / 计时 ============================
struct ZBInput { uint32_t a, b, c, d; };
constexpr uint32_t ZB_N = 2u * 1024u * 1024u;
inline ZBInput g_zb_inputs[ZB_N];
inline void ZBInitInputs(uint32_t theSeed = 20260918u)
{
    uint32_t s = theSeed;
    for (uint32_t i = 0; i < ZB_N; i++)
    {
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t a = s;
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t b = s;
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t c = s;
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t d = s;
        g_zb_inputs[i] = { a, b, c, d };
    }
}

inline double ZBNowSec()
{
    static LARGE_INTEGER freq = {};
    LARGE_INTEGER c;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)freq.QuadPart;
}

// 输出行：目标|before ns|after ns|差%(正=表快)|checksumA/checksumB
template <class PassA, class PassB>
int ZBenchMain(const char* theName, PassA passA, PassB passB)
{
    ZBInitInputs();

    // ---- checksum 对拍 ----
    g_zb_sink = 0; ZBRngReset();
    uint64_t ckA = 0; passA(ckA); ckA = ZBMixU64(ckA, g_zb_sink);
    g_zb_sink = 0; ZBRngReset();
    uint64_t ckB = 0; passB(ckB); ckB = ZBMixU64(ckB, g_zb_sink);

    // ---- 计时：1 warmup + min-of-5，两形态交错 ----
    double bestA = 1e18, bestB = 1e18;
    for (int rep = 0; rep < 6; rep++)
    {
        uint64_t dummy = 0;
        g_zb_sink = 0; ZBRngReset();
        double t0 = ZBNowSec(); passA(dummy); double t1 = ZBNowSec();
        double dA = t1 - t0;
        g_zb_sink = 0; ZBRngReset();
        double t2 = ZBNowSec(); passB(dummy); double t3 = ZBNowSec();
        double dB = t3 - t2;
        if (rep > 0)
        {
            if (dA < bestA) bestA = dA;
            if (dB < bestB) bestB = dB;
        }
    }

    printf("%s|%.1f|%.1f|%+06.2f%%|%016llx/%016llx%s\n",
        theName, bestA * 1e9, bestB * 1e9,
        (bestA - bestB) / bestA * 100.0,
        (unsigned long long)ckA, (unsigned long long)ckB,
        ckA == ckB ? "" : "  <<<< CHECKSUM MISMATCH");
    return ckA == ckB ? 0 : 1;
}
