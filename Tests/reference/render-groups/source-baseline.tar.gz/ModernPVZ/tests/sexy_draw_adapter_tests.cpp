#include "pvz/render/sexy_draw_adapter.hpp"

#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>

namespace {

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void require_near(const float actual, const float expected, const char* message)
{
    require(std::abs(actual - expected) < 0.00001F, message);
}

pvz::render::DrawCommandRecorder make_recorder()
{
    return {1, {800.0, 600.0}, {{0.0, 0.0}, {800.0, 600.0}}};
}

pvz::render::TextureRegion make_source()
{
    return {{4}, {128.0, 64.0}, {{16.0, 8.0}, {32.0, 16.0}}};
}

void test_blt_and_stretch_mapping()
{
    auto recorder = make_recorder();
    pvz::render::SexyDrawCommandAdapter adapter{recorder};
    adapter.set_texture_address_modes(
        pvz::render::TextureAddressMode::repeat,
        pvz::render::TextureAddressMode::repeat);
    adapter.blt(make_source(), {10.0, 20.0});
    adapter.stretch_blt(
        make_source(),
        {{100.0, 120.0}, {80.0, 40.0}},
        {{32.0, 4.0}, {16.0, 8.0}},
        0x80402010,
        pvz::render::BlendMode::alpha,
        {},
        true,
        true);

    const auto frame = recorder.frame();
    require(frame.batches.size() == 1, "matching Blt and StretchBlt state may be batched");
    require_near(frame.vertices[0].x, 10.0F, "Blt must use the source-sized destination");
    require_near(frame.vertices[0].y, 20.0F, "Blt must preserve top-left placement");
    require(frame.batches[0].sampling.filter == pvz::render::TextureFilter::nearest,
            "Blt defaults to point sampling");
    require(frame.batches[0].sampling.filter == pvz::render::TextureFilter::nearest,
            "fast StretchBlt must use point sampling");
    require(frame.batches[0].sampling.address_u == pvz::render::TextureAddressMode::repeat &&
                frame.batches[0].sampling.address_v == pvz::render::TextureAddressMode::repeat,
            "texture-stage U/V addressing must carry into the Vulkan batch");
    require_near(frame.vertices[4].u, 0.375F, "mirrored StretchBlt must reverse source U");
    require_near(frame.vertices[5].u, 0.25F, "mirrored StretchBlt must reverse source U");
}

void test_rotated_mapping_uses_relative_center()
{
    auto recorder = make_recorder();
    pvz::render::SexyDrawCommandAdapter adapter{recorder};
    adapter.blt_rotated(make_source(), {100.0, 100.0}, 3.141592653589793 / 2.0, {16.0, 8.0});

    const auto frame = recorder.frame();
    require(frame.vertices.size() == 4, "BltRotated must emit one transformed quad");
    require_near(frame.vertices[0].x, 124.0F, "rotation must be around the relative center");
    require_near(frame.vertices[0].y, 92.0F, "rotation must be around the relative center");
    require_near(frame.vertices[1].x, 124.0F, "rotation must preserve the transformed edge");
    require_near(frame.vertices[1].y, 124.0F, "rotation must preserve the transformed edge");
    require(frame.batches[0].sampling.filter == pvz::render::TextureFilter::linear,
            "rotated draws must use linear sampling");
}

void test_triangle_draw_color_modulation()
{
    auto recorder = make_recorder();
    pvz::render::SexyDrawCommandAdapter adapter{recorder};
    const std::array vertices{
        pvz::render::Vertex2D{0.0F, 0.0F, 0.0F, 0.0F, 0xFF804020},
        pvz::render::Vertex2D{10.0F, 0.0F, 1.0F, 0.0F, 0xFFFFFFFF},
        pvz::render::Vertex2D{0.0F, 10.0F, 0.0F, 1.0F, 0xFFFFFFFF},
    };
    adapter.draw_triangles_tex({4}, vertices, 0x80808080, pvz::render::BlendMode::alpha, {}, true);

    const auto frame = recorder.frame();
    require(frame.vertices[0].rgba == 0x80402010, "current draw color must modulate vertex color");
    require(frame.batches[0].sampling.filter == pvz::render::TextureFilter::linear,
            "triangle blend filtering must map to linear sampling");
}

} // namespace

int main()
{
    test_blt_and_stretch_mapping();
    test_rotated_mapping_uses_relative_center();
    test_triangle_draw_color_modulation();
    return EXIT_SUCCESS;
}
