#include "pvz/time/fixed_step_clock.hpp"

#include <GLFW/glfw3.h>

#include <chrono>
#include <cstdio>

int main()
{
    if (glfwInit() != GLFW_TRUE)
    {
        std::fprintf(stderr, "glfwInit failed\n");
        return 1;
    }

    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    GLFWwindow* window = glfwCreateWindow(800, 600, "Modern PvZ GLFW Shell", nullptr, nullptr);
    if (window == nullptr)
    {
        std::fprintf(stderr, "glfwCreateWindow failed\n");
        glfwTerminate();
        return 1;
    }

    pvz::time::FixedStepClock clock(
        pvz::time::ClockConfig{
            .simulation_hz = 100,
            .semantic_hz = 100,
            .max_steps_per_advance = 64,
            .max_frame_delta = std::chrono::milliseconds{250},
        });

    auto previous = std::chrono::steady_clock::now();
    std::uint64_t last_ticks = 0;
    auto last_report = std::chrono::steady_clock::now();

    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        const auto now = std::chrono::steady_clock::now();
        const auto elapsed = now - previous;
        previous = now;

        const pvz::time::StepBatch batch = clock.advance(elapsed);
        for (std::uint32_t offset = 0; offset < batch.tick_count; ++offset)
        {
            // Game logic for this tick will go here.
        }

        if (now - last_report >= std::chrono::seconds{1})
        {
            const std::uint64_t ticks_this_second = clock.total_ticks() - last_ticks;
            std::printf("ticks=%llu\n", static_cast<unsigned long long>(ticks_this_second));
            std::fflush(stdout);
            last_ticks = clock.total_ticks();
            last_report = now;
        }
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
