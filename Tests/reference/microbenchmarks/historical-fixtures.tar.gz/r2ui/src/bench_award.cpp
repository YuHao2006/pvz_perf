// bench_award.cpp -- 目标16 kAwardDrawRows(10)    AwardScreen::Draw（结算每帧，热）
//                   目标17 kAwardNoteResources(5) AwardScreen 构造（一次，冷）
//                   目标18 kAwardStoreIntro(3)    AwardScreen::StartButtonPressed（事件，冷）
// FormA = 403c1968^ 逐字；FormB = HEAD 逐字。表声明照抄当前源码形式
// （kAwardDrawRows=函数内 bare constexpr；kAwardNoteResources/kAwardStoreIntro=函数内 static constexpr）。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

#define BOARD_WIDTH 800
#define BOARD_HEIGHT 600
enum AwardType { AWARD_NONE = 0, AWARD_CREDITS_ZOMBIENOTE, AWARD_HELP_ZOMBIENOTE, AWARD_ACHIEVEMENTONLY };

struct Image { int id; int mWidth; int mHeight; };
static Image g_imgA[32];
static Image* const IMAGE_TROPHY_HI_RES = &g_imgA[1];
static Image* const IMAGE_SHOVEL_HI_RES = &g_imgA[2];
static Image* const IMAGE_ZOMBIE_NOTE1 = &g_imgA[3];
static Image* const IMAGE_BACKGROUND1 = &g_imgA[4];
static Image* const IMAGE_ALMANAC = &g_imgA[5];
static Image* const IMAGE_ZOMBIE_NOTE2 = &g_imgA[6];
static Image* const IMAGE_BACKGROUND2 = &g_imgA[7];
static Image* const IMAGE_CARKEYS = &g_imgA[8];
static Image* const IMAGE_ZOMBIE_NOTE3 = &g_imgA[9];
static Image* const IMAGE_TACO = &g_imgA[10];
static Image* const IMAGE_ZOMBIE_NOTE4 = &g_imgA[11];
static Image* const IMAGE_WATERINGCAN = &g_imgA[12];
static Image* const IMAGE_ZOMBIE_FINAL_NOTE = &g_imgA[13];
static Image* const IMAGE_SUNFLOWER_TROPHY = &g_imgA[14];
static Image* const IMAGE_BACKGROUND6BOSS = &g_imgA[15];
static Image* const IMAGE_ZOMBIE_NOTE = &g_imgA[16];
static Image* const IMAGE_CREDITS_ZOMBIENOTE = &g_imgA[17];
static Image* const IMAGE_ZOMBIE_NOTE_HELP = &g_imgA[18];

static uint64_t StrId(const char* s) { uint64_t h = 0; for (int i = 0; s[i] && i < 6; i++) h = h * 256 + (unsigned char)s[i]; return h; }

// 桩号按“调用形”编号（两形态同形同号；参数含图 id/坐标已足够区分分支）
struct GraphicsA { void SetLinearBlend(bool) {} void SetColorizeImages(bool) {} };
static void S_DrawImage(Image* img, int x, int y) { CS(40); CS((uint64_t)img->id); CS((uint64_t)(int64_t)x); CS((uint64_t)(int64_t)y); }
static void S_DrawImageScaled(Image* img, int x, int y, int w, int h) { CS(41); CS((uint64_t)img->id); CS((uint64_t)(int64_t)x); CS((uint64_t)(int64_t)y); CS((uint64_t)w); CS((uint64_t)h); }
static void S_DrawImageCentered(Image* img, int y) { CS(42); CS((uint64_t)img->id); CS((uint64_t)BOARD_WIDTH / 2 - (uint64_t)img->mWidth / 2); CS((uint64_t)(int64_t)y); }
static void S_TodDrawString(const char* s, int x, int y, int font, int align) { CS(43); CS(StrId(s)); CS((uint64_t)x); CS((uint64_t)y); CS((uint64_t)font); CS((uint64_t)align); }
static void S_TodDrawImageCel(Image* img, int x, int y, int cel, float sx, float sy) { CS(44); CS((uint64_t)img->id); CS((uint64_t)(int64_t)sx); CS((uint64_t)cel); }
static void S_FillRect(int x, int y, int w, int h) { CS(45); CS((uint64_t)x); CS((uint64_t)w); }
static void S_TodLoadResources(const char* s) { CS(46); CS(StrId(s)); }

static void DrawBottom(const char* t1, const char* t2, const char* t3) { CS(47); CS(StrId(t1)); CS(StrId(t2)); CS(StrId(t3)); }
static void DrawAwardSeed() { CS(48); }
static void DrawAchievements() { CS(49); }

struct StoreScreenStubA {
    bool mPurchasedFullVersion;
    void SetupForIntro(int intro) { CS(50); CS((uint64_t)intro); }
    void WaitForResult(bool modal) { CS(51); CS(modal); }
};
static StoreScreenStubA g_store;
struct ZenGardenStub { void SetupForZenTutorial() { CS(52); } };
static ZenGardenStub g_zen;
struct AlmanacDialogStub { void WaitForResult(bool) { CS(53); } };
static AlmanacDialogStub g_almanac;

struct AppStubA {
    bool mAdventure, mSurvival, mPuzzle, mChallenge, mFinishedAdventure, mGoldTrophy;
    int mLevel;
    int mNumTrophiesSurvival, mNumTrophiesChallenge;
    bool mHasDialogStore;
    int GetLevel() { return mLevel; }
    bool IsAdventureMode() { return mAdventure; }
    bool IsSurvivalMode() { return mSurvival; }
    bool IsPuzzleMode() { return mPuzzle; }
    bool IsChallengeMode() { return mChallenge; }
    bool HasFinishedAdventure() { return mFinishedAdventure; }
    bool EarnedGoldTrophy() { return mGoldTrophy; }
    int GetNumTrophies(int page) { return page == 0 ? mNumTrophiesSurvival : mNumTrophiesChallenge; }
    bool GetDialog(int) { return mHasDialogStore; }
    void KillAwardScreen() { CS(54); }
    void ShowCreditScreen() { CS(55); }
    void ShowGameSelector() { CS(56); }
    void ShowChallengeScreen(int page) { CS(57); CS((uint64_t)page); }
    void PreNewGame(int mode, bool restart) { CS(58); CS((uint64_t)mode); CS(restart); }
    AlmanacDialogStub* DoAlmanacDialog() { CS(59); return &g_almanac; }
    StoreScreenStubA* ShowStoreScreen() { CS(60); return &g_store; }
    ZenGardenStub* mZenGarden = &g_zen;
};
struct AwardScreenStubA {
    AppStubA* mApp;
    AwardType mAwardType;
    bool mShowingAchievements;
};

// ================= FormA (403c1968^) =================
namespace FormA {
__declspec(noinline) void Draw(AwardScreenStubA& s)
{
    int aLevel = s.mApp->GetLevel();
    if (s.mShowingAchievements)
        DrawAchievements();
    else if (s.mAwardType == AWARD_CREDITS_ZOMBIENOTE)
    {
        S_DrawImageScaled(IMAGE_BACKGROUND6BOSS, -900, -400, 2800, 1200);
        S_DrawImage(IMAGE_ZOMBIE_NOTE, 75, 60);
        S_DrawImageScaled(IMAGE_CREDITS_ZOMBIENOTE, 149, 103, 475, 325);
        S_FillRect(0, 525, BOARD_WIDTH, BOARD_HEIGHT);
    }
    else if (s.mAwardType == AWARD_HELP_ZOMBIENOTE)
    {
        S_DrawImageScaled(IMAGE_BACKGROUND1, -700, -300, 2800, 1200);
        S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
        S_DrawImage(IMAGE_ZOMBIE_NOTE_HELP, 131, 132);
    }
    else if (s.mAwardType != AWARD_ACHIEVEMENTONLY)
    {
        if (!s.mApp->IsAdventureMode())
        {
            if (s.mApp->EarnedGoldTrophy())
            {
                DrawBottom("BEAT_GAME_MESSAGE1", "GOLD_SUNFLOWER_TROPHY", "BEAT_GAME_MESSAGE2");
                S_TodDrawImageCel(IMAGE_SUNFLOWER_TROPHY, 325, 65, 1, 0.6f, 0.6f);
            }
            else
            {
                const char* aMsgChar;
                if (s.mApp->IsSurvivalMode())
                {
                    int aNumTrophies = s.mApp->GetNumTrophies(0);
                    aMsgChar = aNumTrophies <= 7 ? "YOU_UNLOCKED_A_SURVIVAL" :
                        aNumTrophies == 10 ? "YOU_UNLOCKED_ENDLESS_SURVIVAL" : "EARN_MORE_TROPHIES_FOR_ENDLESS_SURVIVAL";
                }
                else if (s.mApp->IsPuzzleMode())
                    aMsgChar = "UNLOCKED_VASEBREAKER_LEVEL";
                else if (s.mApp->IsChallengeMode())
                    aMsgChar = "UNLOCKED_I_ZOMBIE_LEVEL";
                else
                    aMsgChar = s.mApp->GetNumTrophies(1) <= 17 ? "CHALLENGE_UNLOCKED" : "GET_MORE_TROPHIES";
                DrawBottom("GOT_TROPHY", "TROPHY", aMsgChar);
                S_DrawImageCentered(IMAGE_TROPHY_HI_RES, 137);
            }
        }
        else if (aLevel == 5)
        {
            DrawBottom("GOT_SHOVEL", "SHOVEL", "SHOVEL_DESCRIPTION");
            S_DrawImageCentered(IMAGE_SHOVEL_HI_RES, 137);
        }
        else if (aLevel == 10)
        {
            S_DrawImageScaled(IMAGE_BACKGROUND1, -700, -300, 2800, 1200);
            S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
            S_DrawImage(IMAGE_ZOMBIE_NOTE1, 131, 132);
            S_TodDrawString("FOUND_NOTE", BOARD_WIDTH / 2, 70, 24, 1);
        }
        else if (aLevel == 15)
        {
            DrawBottom("FOUND_SUBURBAN_ALMANAC", "SUBURBAN_ALMANAC", "SUBURBAN_ALMANAC_DESCRIPTION");
            S_DrawImageCentered(IMAGE_ALMANAC, 160);
        }
        else if (aLevel == 20)
        {
            S_DrawImageScaled(IMAGE_BACKGROUND2, -700, -300, 2800, 1200);
            S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
            S_DrawImage(IMAGE_ZOMBIE_NOTE2, 133, 127);
            S_TodDrawString("FOUND_NOTE", BOARD_WIDTH / 2, 70, 24, 1);
        }
        else if (aLevel == 25)
        {
            DrawBottom("FOUND_KEYS", "KEYS", "KEYS_DESCRIPTION");
            S_DrawImageCentered(IMAGE_CARKEYS, 160);
        }
        else if (aLevel == 30)
        {
            S_DrawImageScaled(IMAGE_BACKGROUND1, -700, -300, 2800, 1200);
            S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
            S_DrawImage(IMAGE_ZOMBIE_NOTE3, 120, 117);
            S_TodDrawString("FOUND_NOTE", BOARD_WIDTH / 2, 70, 24, 1);
        }
        else if (aLevel == 35)
        {
            DrawBottom("FOUND_TACO", "TACO", "TACO_DESCRIPTION");
            S_DrawImageCentered(IMAGE_TACO, 160);
        }
        else if (aLevel == 40)
        {
            S_DrawImageScaled(IMAGE_BACKGROUND2, -700, -300, 2800, 1200);
            S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
            S_DrawImage(IMAGE_ZOMBIE_NOTE4, 102, 117);
            S_TodDrawString("FOUND_NOTE", BOARD_WIDTH / 2, 70, 24, 1);
        }
        else if (aLevel == 45)
        {
            DrawBottom("FOUND_WATERING_CAN", "WATERING_CAN", "WATERING_CAN_DESCRIPTION");
            S_DrawImageCentered(IMAGE_WATERINGCAN, 160);
        }
        else if (aLevel == 50)
        {
            S_DrawImageScaled(IMAGE_BACKGROUND1, -700, -300, 2800, 1200);
            S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
            S_DrawImage(IMAGE_ZOMBIE_FINAL_NOTE, 114, 138);
            S_TodDrawString("FOUND_NOTE", BOARD_WIDTH / 2, 70, 24, 1);
        }
        else if (aLevel == 1 && s.mApp->HasFinishedAdventure())
        {
            DrawBottom("WIN_MESSAGE1", "SILVER_SUNFLOWER_TROPHY", "WIN_MESSAGE2");
            S_TodDrawImageCel(IMAGE_SUNFLOWER_TROPHY, 325, 65, 0, 0.7f, 0.7f);
        }
        else
        {
            DrawAwardSeed();
        }
    }
    CS(61); // 三按钮 Draw
}

__declspec(noinline) void CtorNoteResources(AwardScreenStubA& s)
{
    int aLevel = s.mApp->GetLevel();
    if (s.mAwardType == AWARD_CREDITS_ZOMBIENOTE)
    {
        S_TodLoadResources("DelayLoad_Background6");
        S_TodLoadResources("DelayLoad_ZombieNote");
        S_TodLoadResources("DelayLoad_Credits");
    }
    else if (s.mAwardType == AWARD_HELP_ZOMBIENOTE)
    {
        S_TodLoadResources("DelayLoad_Background1");
        S_TodLoadResources("DelayLoad_ZombieNote");
        S_TodLoadResources("DelayLoad_ZombieNoteHelp");
    }
    else if (s.mApp->IsAdventureMode())
    {
        if (aLevel == 10)
        {
            S_TodLoadResources("DelayLoad_Background1");
            S_TodLoadResources("DelayLoad_ZombieNote");
            S_TodLoadResources("DelayLoad_ZombieNote1");
        }
        else if (aLevel == 20)
        {
            S_TodLoadResources("DelayLoad_Background2");
            S_TodLoadResources("DelayLoad_ZombieNote");
            S_TodLoadResources("DelayLoad_ZombieNote2");
        }
        else if (aLevel == 30)
        {
            S_TodLoadResources("DelayLoad_Background1");
            S_TodLoadResources("DelayLoad_ZombieNote");
            S_TodLoadResources("DelayLoad_ZombieNote3");
        }
        else if (aLevel == 40)
        {
            S_TodLoadResources("DelayLoad_Background2");
            S_TodLoadResources("DelayLoad_ZombieNote");
            S_TodLoadResources("DelayLoad_ZombieNote4");
        }
        else if (aLevel == 50)
        {
            S_TodLoadResources("DelayLoad_Background1");
            S_TodLoadResources("DelayLoad_ZombieNote");
            S_TodLoadResources("DelayLoad_ZombieFinalNote");
        }
    }
}

__declspec(noinline) void StartButtonPressed(AwardScreenStubA& s)
{
    if (s.mApp->GetDialog(0))
        return;

    if (s.mAwardType == AWARD_CREDITS_ZOMBIENOTE)
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowCreditScreen();
    }
    else if (s.mAwardType == AWARD_HELP_ZOMBIENOTE)
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowGameSelector();
    }
    else if (s.mApp->IsSurvivalMode())
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowChallengeScreen(0);
    }
    else if (s.mApp->IsPuzzleMode())
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowChallengeScreen(1);
    }
    else if (s.mApp->IsChallengeMode())
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowChallengeScreen(2);
    }
    else
    {
        int aLevel = s.mApp->GetLevel();
        if (aLevel == 1)
        {
            s.mApp->KillAwardScreen();
            if (s.mApp->HasFinishedAdventure())
            {
                s.mApp->KillAwardScreen(); // ShowAwardScreen(AWARD_CREDITS_ZOMBIENOTE) 桩
                CS(62);
            }
            else
            {
                s.mApp->PreNewGame(0, false);
            }
        }
        else
        {
            if (aLevel == 15)
            {
                s.mApp->DoAlmanacDialog()->WaitForResult(true);
            }
            else if (aLevel == 25)
            {
                StoreScreenStubA* aStore = s.mApp->ShowStoreScreen();
                aStore->SetupForIntro(301);
                aStore->WaitForResult(true);

                if (aStore->mPurchasedFullVersion)
                {
                    s.mApp->KillAwardScreen();
                    s.mApp->ShowGameSelector();
                    return;
                }
            }
            else if (aLevel == 35)
            {
                StoreScreenStubA* aStore = s.mApp->ShowStoreScreen();
                aStore->SetupForIntro(601);
                aStore->WaitForResult(true);
            }
            else if (aLevel == 42)
            {
                StoreScreenStubA* aStore = s.mApp->ShowStoreScreen();
                aStore->SetupForIntro(3100);
                aStore->WaitForResult(true);
            }
            else if (aLevel == 45)
            {
                s.mApp->KillAwardScreen();
                s.mApp->PreNewGame(51, false);
                s.mApp->mZenGarden->SetupForZenTutorial();
                return;
            }

            s.mApp->KillAwardScreen();
            s.mApp->PreNewGame(0, false);
        }
    }
}
} // namespace FormA

// ================= FormB (HEAD) =================
namespace FormB {
__declspec(noinline) void Draw(AwardScreenStubA& s)
{
    int aLevel = s.mApp->GetLevel();
    if (s.mShowingAchievements)
        DrawAchievements();
    else if (s.mAwardType == AWARD_CREDITS_ZOMBIENOTE)
    {
        S_DrawImageScaled(IMAGE_BACKGROUND6BOSS, -900, -400, 2800, 1200);
        S_DrawImage(IMAGE_ZOMBIE_NOTE, 75, 60);
        S_DrawImageScaled(IMAGE_CREDITS_ZOMBIENOTE, 149, 103, 475, 325);
        S_FillRect(0, 525, BOARD_WIDTH, BOARD_HEIGHT);
    }
    else if (s.mAwardType == AWARD_HELP_ZOMBIENOTE)
    {
        S_DrawImageScaled(IMAGE_BACKGROUND1, -700, -300, 2800, 1200);
        S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
        S_DrawImage(IMAGE_ZOMBIE_NOTE_HELP, 131, 132);
    }
    else if (s.mAwardType != AWARD_ACHIEVEMENTONLY)
    {
        if (!s.mApp->IsAdventureMode())
        {
            if (s.mApp->EarnedGoldTrophy())
            {
                DrawBottom("BEAT_GAME_MESSAGE1", "GOLD_SUNFLOWER_TROPHY", "BEAT_GAME_MESSAGE2");
                S_TodDrawImageCel(IMAGE_SUNFLOWER_TROPHY, 325, 65, 1, 0.6f, 0.6f);
            }
            else
            {
                const char* aMsgChar;
                if (s.mApp->IsSurvivalMode())
                {
                    int aNumTrophies = s.mApp->GetNumTrophies(0);
                    aMsgChar = aNumTrophies <= 7 ? "YOU_UNLOCKED_A_SURVIVAL" :
                        aNumTrophies == 10 ? "YOU_UNLOCKED_ENDLESS_SURVIVAL" : "EARN_MORE_TROPHIES_FOR_ENDLESS_SURVIVAL";
                }
                else if (s.mApp->IsPuzzleMode())
                    aMsgChar = "UNLOCKED_VASEBREAKER_LEVEL";
                else if (s.mApp->IsChallengeMode())
                    aMsgChar = "UNLOCKED_I_ZOMBIE_LEVEL";
                else
                    aMsgChar = s.mApp->GetNumTrophies(1) <= 17 ? "CHALLENGE_UNLOCKED" : "GET_MORE_TROPHIES";
                DrawBottom("GOT_TROPHY", "TROPHY", aMsgChar);
                S_DrawImageCentered(IMAGE_TROPHY_HI_RES, 137);
            }
        }
        else
        {
            // B 形态 -> 常量表 kAwardDrawRows（原 11 支关卡链合并；下标平移 aLevel/5-1）
            constexpr struct {
                bool mIsNote;
                const char* mStr1;
                const char* mStr2;
                const char* mStr3;
                Image* const* mImage;
                Image* const* mBg;
                int mX;
                int mY;
            } kAwardDrawRows[] = {
                { false, "GOT_SHOVEL", "SHOVEL", "SHOVEL_DESCRIPTION", &IMAGE_SHOVEL_HI_RES, nullptr, 0, 137 },
                { true,  "FOUND_NOTE", nullptr, nullptr, &IMAGE_ZOMBIE_NOTE1, &IMAGE_BACKGROUND1, 131, 132 },
                { false, "FOUND_SUBURBAN_ALMANAC", "SUBURBAN_ALMANAC", "SUBURBAN_ALMANAC_DESCRIPTION", &IMAGE_ALMANAC, nullptr, 0, 160 },
                { true,  "FOUND_NOTE", nullptr, nullptr, &IMAGE_ZOMBIE_NOTE2, &IMAGE_BACKGROUND2, 133, 127 },
                { false, "FOUND_KEYS", "KEYS", "KEYS_DESCRIPTION", &IMAGE_CARKEYS, nullptr, 0, 160 },
                { true,  "FOUND_NOTE", nullptr, nullptr, &IMAGE_ZOMBIE_NOTE3, &IMAGE_BACKGROUND1, 120, 117 },
                { false, "FOUND_TACO", "TACO", "TACO_DESCRIPTION", &IMAGE_TACO, nullptr, 0, 160 },
                { true,  "FOUND_NOTE", nullptr, nullptr, &IMAGE_ZOMBIE_NOTE4, &IMAGE_BACKGROUND2, 102, 117 },
                { false, "FOUND_WATERING_CAN", "WATERING_CAN", "WATERING_CAN_DESCRIPTION", &IMAGE_WATERINGCAN, nullptr, 0, 160 },
                { true,  "FOUND_NOTE", nullptr, nullptr, &IMAGE_ZOMBIE_FINAL_NOTE, &IMAGE_BACKGROUND1, 114, 138 },
            };

            const int anAwardIndex = aLevel / 5 - 1;
            if (aLevel % 5 == 0 && (unsigned)anAwardIndex < sizeof(kAwardDrawRows) / sizeof(kAwardDrawRows[0]))
            {
                const auto& aRow = kAwardDrawRows[anAwardIndex];
                if (aRow.mIsNote)
                {
                    S_DrawImageScaled(*aRow.mBg, -700, -300, 2800, 1200);
                    S_DrawImage(IMAGE_ZOMBIE_NOTE, 80, 80);
                    S_DrawImage(*aRow.mImage, aRow.mX, aRow.mY);
                    S_TodDrawString("FOUND_NOTE", BOARD_WIDTH / 2, 70, 24, 1);
                }
                else
                {
                    DrawBottom(aRow.mStr1, aRow.mStr2, aRow.mStr3);
                    S_DrawImageCentered(*aRow.mImage, aRow.mY);
                }
            }
            else if (aLevel == 1 && s.mApp->HasFinishedAdventure())
            {
                DrawBottom("WIN_MESSAGE1", "SILVER_SUNFLOWER_TROPHY", "WIN_MESSAGE2");
                S_TodDrawImageCel(IMAGE_SUNFLOWER_TROPHY, 325, 65, 0, 0.7f, 0.7f);
            }
            else
            {
                DrawAwardSeed();
            }
        }
    }
    CS(61);
}

__declspec(noinline) void CtorNoteResources(AwardScreenStubA& s)
{
    int aLevel = s.mApp->GetLevel();
    if (s.mAwardType == AWARD_CREDITS_ZOMBIENOTE)
    {
        S_TodLoadResources("DelayLoad_Background6");
        S_TodLoadResources("DelayLoad_ZombieNote");
        S_TodLoadResources("DelayLoad_Credits");
    }
    else if (s.mAwardType == AWARD_HELP_ZOMBIENOTE)
    {
        S_TodLoadResources("DelayLoad_Background1");
        S_TodLoadResources("DelayLoad_ZombieNote");
        S_TodLoadResources("DelayLoad_ZombieNoteHelp");
    }
    else if (s.mApp->IsAdventureMode())
    {
        // B 形态 -> 常量表 kAwardNoteResources（原 5 支链合并；下标平移 aLevel/10-1）
        static constexpr struct { const char* mBg; const char* mNote; const char* mNoteVariant; } kAwardNoteResources[] = {
            { "DelayLoad_Background1", "DelayLoad_ZombieNote", "DelayLoad_ZombieNote1" },
            { "DelayLoad_Background2", "DelayLoad_ZombieNote", "DelayLoad_ZombieNote2" },
            { "DelayLoad_Background1", "DelayLoad_ZombieNote", "DelayLoad_ZombieNote3" },
            { "DelayLoad_Background2", "DelayLoad_ZombieNote", "DelayLoad_ZombieNote4" },
            { "DelayLoad_Background1", "DelayLoad_ZombieNote", "DelayLoad_ZombieFinalNote" },
        };

        const int aNoteIndex = aLevel / 10 - 1;
        if (aLevel % 10 == 0 && (unsigned)aNoteIndex < sizeof(kAwardNoteResources) / sizeof(kAwardNoteResources[0]))
        {
            S_TodLoadResources(kAwardNoteResources[aNoteIndex].mBg);
            S_TodLoadResources(kAwardNoteResources[aNoteIndex].mNote);
            S_TodLoadResources(kAwardNoteResources[aNoteIndex].mNoteVariant);
        }
    }
}

__declspec(noinline) void StartButtonPressed(AwardScreenStubA& s)
{
    if (s.mApp->GetDialog(0))
        return;

    if (s.mAwardType == AWARD_CREDITS_ZOMBIENOTE)
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowCreditScreen();
    }
    else if (s.mAwardType == AWARD_HELP_ZOMBIENOTE)
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowGameSelector();
    }
    else if (s.mApp->IsSurvivalMode())
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowChallengeScreen(0);
    }
    else if (s.mApp->IsPuzzleMode())
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowChallengeScreen(1);
    }
    else if (s.mApp->IsChallengeMode())
    {
        s.mApp->KillAwardScreen();
        s.mApp->ShowChallengeScreen(2);
    }
    else
    {
        int aLevel = s.mApp->GetLevel();
        if (aLevel == 1)
        {
            s.mApp->KillAwardScreen();
            if (s.mApp->HasFinishedAdventure())
            {
                s.mApp->KillAwardScreen();
                CS(62);
            }
            else
            {
                s.mApp->PreNewGame(0, false);
            }
        }
        else
        {
            if (aLevel == 15)
            {
                s.mApp->DoAlmanacDialog()->WaitForResult(true);
            }
            else
            {
                // B 形态 -> 常量表 kAwardStoreIntro（原 25/35/42 三支共体合并）
                static constexpr struct { int mLevel; int mIntro; } kAwardStoreIntro[] = {
                    { 25, 301 },
                    { 35, 601 },
                    { 42, 3100 },
                };

                for (const auto& aRow : kAwardStoreIntro)
                {
                    if (aRow.mLevel != aLevel)
                        continue;

                    StoreScreenStubA* aStore = s.mApp->ShowStoreScreen();
                    aStore->SetupForIntro(aRow.mIntro);
                    aStore->WaitForResult(true);

                    if (aLevel == 25 && aStore->mPurchasedFullVersion)
                    {
                        s.mApp->KillAwardScreen();
                        s.mApp->ShowGameSelector();
                        return;
                    }
                    break;
                }
            }

            if (aLevel == 45)
            {
                s.mApp->KillAwardScreen();
                s.mApp->PreNewGame(51, false);
                s.mApp->mZenGarden->SetupForZenTutorial();
                return;
            }

            s.mApp->KillAwardScreen();
            s.mApp->PreNewGame(0, false);
        }
    }
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];
static AppStubA g_app;
static AwardScreenStubA g_aw;

typedef void (*DrawFn)(AwardScreenStubA&);
typedef void (*NoteFn)(AwardScreenStubA&);
typedef void (*PressFn)(AwardScreenStubA&);

static void SetCommon(uint32_t v)
{
    g_app.mAdventure = ((v >> 0) & 1) != 0;
    g_app.mSurvival = ((v >> 1) & 1) != 0;
    g_app.mPuzzle = ((v >> 2) & 1) != 0;
    g_app.mChallenge = ((v >> 3) & 1) != 0 && !g_app.mSurvival && !g_app.mPuzzle;
    g_app.mFinishedAdventure = ((v >> 4) & 1) != 0;
    g_app.mGoldTrophy = ((v >> 5) & 1) != 0;
    g_app.mLevel = (int)((v >> 6) % 52);
    g_app.mNumTrophiesSurvival = (int)((v >> 13) % 12);
    g_app.mNumTrophiesChallenge = (int)((v >> 17) % 20);
    g_aw.mAwardType = (AwardType)((v >> 22) % 4);
    g_aw.mShowingAchievements = ((v >> 24) & 1) != 0;
}

static uint64_t RunDraw(DrawFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++) { SetCommon(g_in[i]); fn(g_aw); }
    return g_cs;
}
static uint64_t RunNote(NoteFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++) { SetCommon(g_in[i]); fn(g_aw); }
    return g_cs;
}
static uint64_t RunPress(PressFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++)
    {
        SetCommon(g_in[i]);
        g_app.mHasDialogStore = ((g_in[i] >> 25) & 1) != 0;
        g_store.mPurchasedFullVersion = ((g_in[i] >> 26) & 1) != 0;
        fn(g_aw);
    }
    return g_cs;
}

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    for (int k = 0; k < 32; k++) { g_imgA[k].id = k; g_imgA[k].mWidth = 120; g_imgA[k].mHeight = 100; }
    LCG rng{ 0x082EFA98EC4E6C89ULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();
    g_aw.mApp = &g_app;

    {
        uint64_t csA = RunDraw(FormA::Draw), csB = RunDraw(FormB::Draw);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunDraw(FormA::Draw); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunDraw(FormB::Draw); }) / N * 1e9;
        }
        Report("t16 kAwardDrawRows(10) AwardScreen::Draw", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    {
        uint64_t csA = RunNote(FormA::CtorNoteResources), csB = RunNote(FormB::CtorNoteResources);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunNote(FormA::CtorNoteResources); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunNote(FormB::CtorNoteResources); }) / N * 1e9;
        }
        Report("t17 kAwardNoteResources(5) AwardScreen ctor", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    {
        uint64_t csA = RunPress(FormA::StartButtonPressed), csB = RunPress(FormB::StartButtonPressed);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunPress(FormA::StartButtonPressed); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunPress(FormB::StartButtonPressed); }) / N * 1e9;
        }
        Report("t18 kAwardStoreIntro(3) AwardScreen::StartButtonPressed", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
