// bench03 | Zombie::UpdateZombieBackupDancer | 6 case switch -> kDancerPhaseCases (96-slot, shared with Dancer)
// FormA = ac447d19^, FormB = HEAD.
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

static const int kN = 2000000;
static uint32_t g_raw[kN];

enum ZombiePhase {
    PHASE_ZOMBIE_NORMAL = 0, PHASE_ZOMBIE_DYING = 1, PHASE_ZOMBIE_BURNED = 2, PHASE_ZOMBIE_MOWERED = 3,
    PHASE_DANCER_DANCING_IN = 40, PHASE_DANCER_SNAPPING_FINGERS = 41, PHASE_DANCER_SNAPPING_FINGERS_WITH_LIGHT = 42,
    PHASE_DANCER_SNAPPING_FINGERS_HOLD = 43, PHASE_DANCER_DANCING_LEFT = 44, PHASE_DANCER_WALK_TO_RAISE = 45,
    PHASE_DANCER_RAISE_LEFT_1 = 46, PHASE_DANCER_RAISE_RIGHT_1 = 47, PHASE_DANCER_RAISE_LEFT_2 = 48,
    PHASE_DANCER_RAISE_RIGHT_2 = 49, PHASE_DANCER_RISING = 50,
    PHASE_SQUASH_DONE_FALLING = 95
};
enum ReanimTrackId { anim_walk = 0, anim_armraise = 1, anim_point = 2 };
enum ReanimLoopType { REANIM_LOOP = 0, REANIM_PLAY_ONCE_AND_HOLD = 1 };
namespace Curves { enum CurveFn { Linear = 0 }; }

const int ZOMBIE_BACKUP_DANCER_RISE_HEIGHT = 80;
const int HIGH_GROUND_HEIGHT = 20;

static int TodAnimateCurve(int a, int b, int c, int d, int e, Curves::CurveFn f) { Mix(20); return a + b + c + d + e + (int)f; }

struct ReanimationStub { float mAnimTime; int mLoopCount; };
static ReanimationStub g_reanim;
struct AppStub {
    ReanimationStub* ReanimationTryToGet(int id) { Mix(21); return &g_reanim; }
};
static AppStub g_app;

static ZombiePhase g_inputPhase;
struct Zombie {
    bool mIsEating;
    ZombiePhase mZombiePhase;
    int mPhaseCounter;
    int mAltitude;
    int mBodyReanimID;
    AppStub* mApp;

    bool IsOnHighGround() { Mix(22); return false; }
    ZombiePhase GetDancerPhase() { Mix(23); return g_inputPhase; }
    void PlayZombieReanim(ReanimTrackId t, ReanimLoopType l, int blend, float rate) { Mix(24); Mix((uint64_t)t + (int)l + blend + (int)rate * 1000); }
};
static Zombie g_zombie;

// ================= FormA: verbatim switch (ac447d19^) =================
static void UpdateZombieBackupDancerA()
{
    if (g_zombie.mIsEating)
        return;

    if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_RISING)
    {
        g_zombie.mAltitude = TodAnimateCurve(150, 0, g_zombie.mPhaseCounter, ZOMBIE_BACKUP_DANCER_RISE_HEIGHT, 0, Curves::Linear);

        if (g_zombie.mPhaseCounter != 0)
            return;

        if (g_zombie.IsOnHighGround())
        {
            g_zombie.mAltitude = HIGH_GROUND_HEIGHT;
        }
    }

    ZombiePhase aDancerPhase = g_zombie.GetDancerPhase();
    if (aDancerPhase != g_zombie.mZombiePhase)
    {
        switch (aDancerPhase)
        {
        case ZombiePhase::PHASE_DANCER_DANCING_LEFT:
            g_zombie.mZombiePhase = aDancerPhase;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 10, 0.0f);
            break;

        case ZombiePhase::PHASE_DANCER_WALK_TO_RAISE:
            g_zombie.mZombiePhase = aDancerPhase;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
            g_zombie.mApp->ReanimationTryToGet(g_zombie.mBodyReanimID)->mAnimTime = 0.6f;
            break;

        case ZombiePhase::PHASE_DANCER_RAISE_LEFT_1:
        case ZombiePhase::PHASE_DANCER_RAISE_RIGHT_1:
        case ZombiePhase::PHASE_DANCER_RAISE_LEFT_2:
        case ZombiePhase::PHASE_DANCER_RAISE_RIGHT_2:
            g_zombie.mZombiePhase = aDancerPhase;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
            break;
        default:
            break;
        }
    }
}

// ================= FormB: HEAD 96-slot shared table =================
namespace {
using DancerPhaseCaseFn = void (*)(Zombie&, ZombiePhase);

void DancerPhaseDancerRaiseLeft1(Zombie& z, ZombiePhase aDancerPhase)
{
    z.mZombiePhase = aDancerPhase;
    z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
}

void DancerDefault(Zombie& z, ZombiePhase aDancerPhase) { (void)z; (void)aDancerPhase; }

constexpr DancerPhaseCaseFn kDancerPhaseCases[(int)ZombiePhase::PHASE_SQUASH_DONE_FALLING + 1] = {
    &DancerDefault,  // 0
    &DancerDefault,  // 1
    &DancerDefault,  // 2
    &DancerDefault,  // 3
    &DancerDefault,  // 4
    &DancerDefault,  // 5
    &DancerDefault,  // 6
    &DancerDefault,  // 7
    &DancerDefault,  // 8
    &DancerDefault,  // 9
    &DancerDefault,  // 10
    &DancerDefault,  // 11
    &DancerDefault,  // 12
    &DancerDefault,  // 13
    &DancerDefault,  // 14
    &DancerDefault,  // 15
    &DancerDefault,  // 16
    &DancerDefault,  // 17
    &DancerDefault,  // 18
    &DancerDefault,  // 19
    &DancerDefault,  // 20
    &DancerDefault,  // 21
    &DancerDefault,  // 22
    &DancerDefault,  // 23
    &DancerDefault,  // 24
    &DancerDefault,  // 25
    &DancerDefault,  // 26
    &DancerDefault,  // 27
    &DancerDefault,  // 28
    &DancerDefault,  // 29
    &DancerDefault,  // 30
    &DancerDefault,  // 31
    &DancerDefault,  // 32
    &DancerDefault,  // 33
    &DancerDefault,  // 34
    &DancerDefault,  // 35
    &DancerDefault,  // 36
    &DancerDefault,  // 37
    &DancerDefault,  // 38
    &DancerDefault,  // 39
    &DancerDefault,  // 40
    &DancerDefault,  // 41
    &DancerDefault,  // 42
    &DancerDefault,  // 43
    [](Zombie& z, ZombiePhase aDancerPhase)
    {
        z.mZombiePhase = aDancerPhase;
        z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 10, 0.0f);
    },  // 44 PHASE_DANCER_DANCING_LEFT
    [](Zombie& z, ZombiePhase aDancerPhase)
    {
        z.mZombiePhase = aDancerPhase;
        z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
        z.mApp->ReanimationTryToGet(z.mBodyReanimID)->mAnimTime = 0.6f;
    },  // 45 PHASE_DANCER_WALK_TO_RAISE
    &DancerPhaseDancerRaiseLeft1,  // 46（共体）
    &DancerPhaseDancerRaiseLeft1,  // 47（共体）
    &DancerPhaseDancerRaiseLeft1,  // 48（共体）
    &DancerPhaseDancerRaiseLeft1,  // 49（共体）
    &DancerDefault,  // 50
    &DancerDefault,  // 51
    &DancerDefault,  // 52
    &DancerDefault,  // 53
    &DancerDefault,  // 54
    &DancerDefault,  // 55
    &DancerDefault,  // 56
    &DancerDefault,  // 57
    &DancerDefault,  // 58
    &DancerDefault,  // 59
    &DancerDefault,  // 60
    &DancerDefault,  // 61
    &DancerDefault,  // 62
    &DancerDefault,  // 63
    &DancerDefault,  // 64
    &DancerDefault,  // 65
    &DancerDefault,  // 66
    &DancerDefault,  // 67
    &DancerDefault,  // 68
    &DancerDefault,  // 69
    &DancerDefault,  // 70
    &DancerDefault,  // 71
    &DancerDefault,  // 72
    &DancerDefault,  // 73
    &DancerDefault,  // 74
    &DancerDefault,  // 75
    &DancerDefault,  // 76
    &DancerDefault,  // 77
    &DancerDefault,  // 78
    &DancerDefault,  // 79
    &DancerDefault,  // 80
    &DancerDefault,  // 81
    &DancerDefault,  // 82
    &DancerDefault,  // 83
    &DancerDefault,  // 84
    &DancerDefault,  // 85
    &DancerDefault,  // 86
    &DancerDefault,  // 87
    &DancerDefault,  // 88
    &DancerDefault,  // 89
    &DancerDefault,  // 90
    &DancerDefault,  // 91
    &DancerDefault,  // 92
    &DancerDefault,  // 93
    &DancerDefault,  // 94
    &DancerDefault,  // 95
};
static_assert(sizeof(kDancerPhaseCases) / sizeof(kDancerPhaseCases[0]) ==
    (int)ZombiePhase::PHASE_SQUASH_DONE_FALLING + 1, "slot count");
}  // namespace

static void UpdateZombieBackupDancerB()
{
    if (g_zombie.mIsEating)
        return;

    if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_RISING)
    {
        g_zombie.mAltitude = TodAnimateCurve(150, 0, g_zombie.mPhaseCounter, ZOMBIE_BACKUP_DANCER_RISE_HEIGHT, 0, Curves::Linear);

        if (g_zombie.mPhaseCounter != 0)
            return;

        if (g_zombie.IsOnHighGround())
        {
            g_zombie.mAltitude = HIGH_GROUND_HEIGHT;
        }
    }

    ZombiePhase aDancerPhase = g_zombie.GetDancerPhase();
    if (aDancerPhase != g_zombie.mZombiePhase)
    {
        const unsigned aPhaseIndex = static_cast<unsigned>(aDancerPhase);
        if (aPhaseIndex <= static_cast<unsigned>(ZombiePhase::PHASE_SQUASH_DONE_FALLING))
        {
            kDancerPhaseCases[aPhaseIndex](g_zombie, aDancerPhase);
        }
    }
}

// ---------------- harness ----------------
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    uint32_t v = g_raw[i];
    g_inputPhase = (ZombiePhase)(v % 96);
    g_zombie.mIsEating = false;
    g_zombie.mZombiePhase = (ZombiePhase)95;  // != aDancerPhase except when input==95
    g_zombie.mPhaseCounter = 0;               // RISING pre-branch completes when hit
    g_zombie.mAltitude = 0;
    g_zombie.mBodyReanimID = 7;
    g_zombie.mApp = &g_app;
    g_reanim.mAnimTime = 0.0f;
    g_reanim.mLoopCount = 1;
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); UpdateZombieBackupDancerA(); Mix(g_zombie.mZombiePhase); Mix(g_zombie.mAltitude); Mix((uint64_t)(g_reanim.mAnimTime * 1000)); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum; g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); UpdateZombieBackupDancerB(); Mix(g_zombie.mZombiePhase); Mix(g_zombie.mAltitude); Mix((uint64_t)(g_reanim.mAnimTime * 1000)); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("Zombie::UpdateZombieBackupDancer | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
