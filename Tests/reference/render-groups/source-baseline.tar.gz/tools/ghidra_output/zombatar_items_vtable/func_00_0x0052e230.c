
undefined4 __thiscall FUN_0052e230(undefined4 param_1,byte param_2)

{
  FUN_0052e250();
  if ((param_2 & 1) != 0) {
    FUN_00699e4a(param_1);
  }
  return param_1;
}

