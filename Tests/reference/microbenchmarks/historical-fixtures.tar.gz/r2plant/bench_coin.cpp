// bench_coin.cpp — Coin.cpp 3 目标段表性能对拍（第二轮补测）
//   #9  kCoinSizeRows 28     -> Coin::CoinInitialize（static constexpr，照抄 HEAD）
//   #10 kCoinArrowOffsets 28 -> Coin::UpdateFall 落地箭头（static constexpr，照抄）
//   #11 kCoinValueRows 28    -> Coin::GetCoinValue（static constexpr，照抄）
// FormA = 403c1968^ 原函数。kCoinInitCases 为 403c1968 前已存在的两形态同体
// 表（CoinMotion 分发），在 FA/FB 各放一份相同实现（不在对拍对象内）。
#include "r2_stub.h"

constexpr int BOARD_WIDTH = 801;

inline unsigned Rand(unsigned n) { MixCk(0x1090ULL, n); return n ? RngNext() % n : 0u; }

// ================================================================= FormA
namespace FA {

struct Coin
{
    float mPosX = 0, mPosY = 0, mVelX = 0, mVelY = 0, mGroundY = 0, mScale = 1;
    int mWidth = 60, mHeight = 60;
    CoinType mType = COIN_NONE;
    CoinMotion mCoinMotion = COIN_MOTION_FROM_SKY;
    float mCollectionDistance = 0;
    bool mDead = false;
    int mDisappearCounter = 0;
    bool mIsBeingCollected = false;
    int mFadeCount = 0;
    int mCoinAge = 0;
    AttachmentID mAttachmentID = ATTACHMENTID_NULL;
    int mRenderOrder = 0;
    SeedType mUsableSeedType = SEED_NONE;
    bool mNeedsBouncyArrow = false, mHasBouncyArrow = false, mHitGround = false;
    int mTimesDropped = 0;
    PottedPlantSpec mPottedPlantSpec;
    LawnApp* mApp = &g_app;
    Board* mBoard = &g_board;

    // 谓词不入 checksum：FormA 链式 else-if 每级调用谓词、FormB 表直查不再调用——
    // 调用次数差是转换本身消除冗余谓词的正当差异，语义结果由对象终态+动作桩保证。
    bool IsSun() { return mType == CoinType::COIN_SUN || mType == CoinType::COIN_SMALLSUN || mType == CoinType::COIN_LARGESUN; }
    bool IsMoney() { return mType == CoinType::COIN_SILVER || mType == CoinType::COIN_GOLD || mType == CoinType::COIN_DIAMOND; }
    bool IsPresentWithAdvice() { return mType >= CoinType::COIN_PRESENT_MINIGAMES; }
    bool IsLevelAward() { return mType >= CoinType::COIN_AWARD_MONEY_BAG && mType <= CoinType::COIN_AWARD_GOLD_SUNFLOWER; }
    bool CoinGetsBouncyArrow()
    {
        if (IsLevelAward()) return true;
        if (mType == CoinType::COIN_SILVER || mType == CoinType::COIN_GOLD)
            if (mApp->IsFirstTimeAdventureMode() && mBoard && mBoard->mLevel == 11 && !mBoard->mDroppedFirstCoin)
                return true;
        return IsPresentWithAdvice();
    }
    void Collect() { MixCk(0x4004ULL); }
    void PlayGroundSound() { MixCk(0x4005ULL, mType); }
    void PlayLaunchSound() { MixCk(0x4006ULL, mType); }
    void StartFade() { MixCk(0x4007ULL); }
    int  GetDisappearTime() { MixCk(0x4008ULL); return 50; }
    float GetSunScale() { MixCk(0x4009ULL); return 0.5f + (mType & 1) * 0.25f; }
    void AttachReanim(AttachmentID& id, Reanimation* r, float x, float y) { MixCk(0x400AULL, (uint64_t)(int)(x + y)); (void)id; (void)r; }
    void AttachParticle(AttachmentID& id, TodParticleSystem* p, float x, float y) { MixCk(0x400BULL, (uint64_t)(int)(x + y)); (void)id; (void)p; }
    static int GetCoinValue(CoinType theCoinType);

    __declspec(noinline) void CoinInitialize(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion);
    __declspec(noinline) void UpdateFall();
};

namespace
{
using CoinInitCaseFn = void (*)(Coin&);
void CoinInitDefault(Coin& c) { (void)c; TOD_ASSERT(false); }
constexpr CoinInitCaseFn kCoinInitCases[(int)CoinMotion::COIN_MOTION_FROM_BOSS + 1] = {
    [](Coin& c) { c.mVelY = 0.67f; c.mVelX = 0.0f; c.mGroundY = Rand(250) + 300; },
    [](Coin& c) { c.mVelY = 0.33f; c.mVelX = 0.0f; c.mGroundY = Rand(250) + 300; },
    [](Coin& c) { c.mVelY = -1.7f - RandRangeFloat(0.0f, 1.7f); c.mVelX = -0.4f + RandRangeFloat(0.0f, 0.8f);
                  c.mGroundY = c.mPosY + 15 + Rand(20); c.mScale = 0.4f; },
    [](Coin& c) { c.mVelY = -3.0f - RandRangeFloat(0.0f, 2.0f); c.mVelX = -0.5f + RandRangeFloat(0.0f, 1.0f);
                  c.mGroundY = c.mPosY + 45 + Rand(20);
                  if (c.mGroundY > 521) c.mGroundY = 521;
                  if (c.mGroundY < 80) c.mGroundY = 80;
                  if (c.mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || c.mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
                  { c.mPosY -= 100.0f; c.mGroundY = c.mPosY + 45.0f; if (c.mGroundY > 400) c.mGroundY = 400; }
                  if (c.mType == CoinType::COIN_FINAL_SEED_PACKET || c.mType == CoinType::COIN_USABLE_SEED_PACKET ||
                      c.mType == CoinType::COIN_TROPHY || c.mType == CoinType::COIN_SHOVEL ||
                      c.mType == CoinType::COIN_CARKEYS || c.mType == CoinType::COIN_ALMANAC ||
                      c.mType == CoinType::COIN_VASE || c.mType == CoinType::COIN_WATERING_CAN ||
                      c.mType == CoinType::COIN_TACO || c.mType == CoinType::COIN_NOTE)
                  { c.mGroundY -= 30; } },
    [](Coin& c) { c.mVelY = 0.0f; c.mVelX = 0.0f; c.mGroundY = 600; c.Collect(); },
    [](Coin& c) { c.mVelY = 0.0f; c.mVelX = 0.0f; c.mGroundY = 600;
                  c.mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 1); },
    [](Coin& c) { c.mVelY = -5.0f; c.mVelX = -3.0f; c.mPosX = 750.0f;
                  c.mPosY = c.mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER ? 130.0f : 245.0f;
                  c.mGroundY = c.mPosY + 40; },
};
}

int Coin::GetCoinValue(CoinType theCoinType)
{
    return theCoinType == CoinType::COIN_SILVER ? 1 : theCoinType == CoinType::COIN_GOLD ? 5 : theCoinType == CoinType::COIN_DIAMOND ? 100 : 0;
}

// ---- #9 CoinInitialize（A：15 支尺寸链）
void Coin::CoinInitialize(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion)
{
    mPosX = theX;
    mPosY = theY;
    mType = theCoinType;
    mCollectionDistance = 0.0f;
    mDead = false;
    mWidth = 60;
    mHeight = 60;
    mDisappearCounter = 0;
    mIsBeingCollected = false;
    mFadeCount = 0;
    mCoinMotion = theCoinMotion;
    mCoinAge = 0;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_COIN_BANK, 0, 1);
    mScale = 1.0f;
    mUsableSeedType = SeedType::SEED_NONE;
    mNeedsBouncyArrow = false;
    mHasBouncyArrow = false;
    mHitGround = false;
    mTimesDropped = 0;
    mPottedPlantSpec.InitializePottedPlant(SeedType::SEED_NONE);

    if (IsSun())
    {
        float aPosX = mWidth * 0.5f;
        float aPosY = mHeight * 0.5f;
        Reanimation* aSunReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SUN);
        aSunReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aSunReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aSunReanim->mAnimRate = 6.0f;
        AttachReanim(mAttachmentID, aSunReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_SILVER)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_SILVER);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_GOLD)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_GOLD);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_DIAMOND)
    {
        mPosX -= 15.0f;
        mPosY -= 15.0f;

        float aPosX = -3.0f;
        float aPosY = 4.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_DIAMOND);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate = RandRangeFloat(50.0f, 80.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }

    if (mApp->IsStormyNightLevel())
    {
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    if (mType == CoinType::COIN_FINAL_SEED_PACKET)
    {
        mWidth = IMAGE_SEEDS->GetCelWidth();
        mHeight = IMAGE_SEEDS->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_TROPHY)
    {
        mWidth = IMAGE_TROPHY->GetCelWidth();
        mHeight = IMAGE_TROPHY->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
    {
        mWidth = IMAGE_SUNFLOWER_TROPHY->GetCelWidth();
        mHeight = IMAGE_SUNFLOWER_TROPHY->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_SHOVEL)
    {
        mWidth = IMAGE_SHOVEL->GetCelWidth();
        mHeight = IMAGE_SHOVEL->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_CARKEYS)
    {
        mWidth = IMAGE_CARKEYS->GetCelWidth();
        mHeight = IMAGE_CARKEYS->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_ALMANAC)
    {
        mWidth = IMAGE_ALMANAC->GetCelWidth();
        mHeight = IMAGE_ALMANAC->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_VASE)
    {
        mWidth = IMAGE_SCARY_POT->GetCelWidth();
        mHeight = IMAGE_SCARY_POT->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_WATERING_CAN)
    {
        mWidth = IMAGE_WATERINGCAN->GetCelWidth();
        mHeight = IMAGE_WATERINGCAN->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_TACO)
    {
        mWidth = IMAGE_TACO->GetCelWidth();
        mHeight = IMAGE_TACO->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_NOTE)
    {
        mWidth = IMAGE_ZOMBIE_NOTE_SMALL->GetCelWidth();
        mHeight = IMAGE_ZOMBIE_NOTE_SMALL->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_USABLE_SEED_PACKET)
    {
        mWidth = IMAGE_SEEDS->GetCelWidth();
        mHeight = IMAGE_SEEDS->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_FOG, 0, 2);
    }
    else if (mType == CoinType::COIN_PRESENT_PLANT || mType == CoinType::COIN_AWARD_PRESENT)
    {
        TOD_ASSERT(mBoard);

        mWidth = IMAGE_PRESENT->GetCelWidth();
        mHeight = IMAGE_PRESENT->GetCelHeight();
        if (mApp->IsSurvivalEndless(mApp->mGameMode) || mApp->IsEndlessIZombie(mApp->mGameMode) || mApp->IsEndlessScaryPotter(mApp->mGameMode))
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else
        {
            const int aBackground = (int)mBoard->mBackground;
            if ((unsigned)aBackground < (unsigned)(sizeof(kPresentSeeds) / sizeof(kPresentSeeds[0])) &&
                kPresentSeeds[aBackground].mSeedList != nullptr)
            {
                mPottedPlantSpec.InitializePottedPlant(
                    TodPickFromList(kPresentSeeds[aBackground].mSeedList, kPresentSeeds[aBackground].mCount));
            }
            else
            {
                SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
                mPottedPlantSpec.InitializePottedPlant(aSeedType);
            }
        }

    }
    else if (mType == CoinType::COIN_AWARD_MONEY_BAG || mType == CoinType::COIN_AWARD_BAG_DIAMOND)
    {
        mWidth = IMAGE_MONEYBAG->GetCelWidth();
        mHeight = IMAGE_MONEYBAG->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (mType == CoinType::COIN_CHOCOLATE || mType == CoinType::COIN_AWARD_CHOCOLATE)
    {
        mWidth = IMAGE_CHOCOLATE->GetCelWidth();
        mHeight = IMAGE_CHOCOLATE->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }
    else if (IsPresentWithAdvice())
    {
        mWidth = IMAGE_PRESENT->GetCelWidth();
        mHeight = IMAGE_PRESENT->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    const unsigned aMotionIndex = static_cast<unsigned>(mCoinMotion);
    if (aMotionIndex <= static_cast<unsigned>(CoinMotion::COIN_MOTION_FROM_BOSS))
    {
        kCoinInitCases[aMotionIndex](*this);
    }
    else
    {
        CoinInitDefault(*this);
    }

    float aScale;
    if (mType == CoinType::COIN_SMALLSUN)
    {
        aScale = 0.5f;
    }
    else if (mType == CoinType::COIN_LARGESUN)
    {
        aScale = 2.0f;
    }
    else
    {
        aScale = 1.0f;
    }
    mScale *= aScale;

    if (CoinGetsBouncyArrow())
    {
        mNeedsBouncyArrow = true;
    }

    if (mCoinMotion != CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        PlayLaunchSound();
    }
}

// ---- #10 UpdateFall（A：5 支箭头偏移链）
void Coin::UpdateFall()
{
    if (mCoinMotion == CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        mPosX += mVelX;
        mPosY += mVelY;
        mVelX *= 0.95f;
        mVelY *= 0.95f;
        if (mCoinAge >= 80)
        {
            Collect();
        }
    }
    else if (mPosY + mVelY < mGroundY)
    {
        mPosY += mVelY;
        if (mCoinMotion == CoinMotion::COIN_MOTION_FROM_PLANT)
        {
            mVelY += 0.09f;
        }
        else if (mCoinMotion == CoinMotion::COIN_MOTION_COIN || mCoinMotion == CoinMotion::COIN_MOTION_FROM_BOSS)
        {
            mVelY += 0.15f;
        }

        mPosX += mVelX;
        if (mPosX > BOARD_WIDTH - mWidth && mCoinMotion != CoinMotion::COIN_MOTION_FROM_BOSS)
        {
            mPosX = BOARD_WIDTH - mWidth;
            mVelX = -0.4f - RandRangeFloat(0.0f, 0.4f);
        }
        else if (mPosX < 0.0f)
        {
            mPosX = 0.0f;
            mVelX = 0.4f + RandRangeFloat(0.0f, 0.4f);
        }
    }
    else
    {
        if (mNeedsBouncyArrow && !mHasBouncyArrow)
        {
            float aParticleOffsetX = mWidth / 2;
            float aParticleOffsetY = mHeight / 2 - 60;
            if (mType == CoinType::COIN_TROPHY)
            {
                aParticleOffsetX += 2.0f;
            }
            else if (mType == CoinType::COIN_AWARD_MONEY_BAG || mType == CoinType::COIN_AWARD_BAG_DIAMOND)
            {
                aParticleOffsetX += 2.0f;
                aParticleOffsetY -= 2.0f;
            }
            else if (mType == CoinType::COIN_AWARD_PRESENT || IsPresentWithAdvice())
            {
                aParticleOffsetY -= 20.0f;
            }
            else if (mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
            {
                aParticleOffsetX -= 6.0f;
                aParticleOffsetY -= 40.0f;
            }
            else if (IsMoney())
            {
                aParticleOffsetX += 12.0f;
                aParticleOffsetY += 21.0f;
            }

            ParticleEffect aEffect;
            if (mType == CoinType::COIN_FINAL_SEED_PACKET)
            {
                aEffect = ParticleEffect::PARTICLE_SEED_PACKET;
            }
            else if (IsMoney())
            {
                aEffect = ParticleEffect::PARTICLE_COIN_PICKUP_ARROW;
            }
            else
            {
                aEffect = ParticleEffect::PARTICLE_AWARD_PICKUP_ARROW;
            }

            TodParticleSystem* aParticle = mApp->AddTodParticle(mPosX + aParticleOffsetX, mPosY + aParticleOffsetY, 0, aEffect);
            AttachParticle(mAttachmentID, aParticle, aParticleOffsetX, aParticleOffsetY);
            mHasBouncyArrow = true;
        }

        if (!mHitGround)
        {
            mHitGround = true;
            PlayGroundSound();
        }

        mPosY = mGroundY;
        mPosX = FloatRoundToInt(mPosX);


        if (mApp->mGameMode != GameMode::GAMEMODE_CHALLENGE_LAST_STAND || mBoard == nullptr ||
            mBoard->mChallenge->mChallengeState == ChallengeState::STATECHALLENGE_LAST_STAND_ONSLAUGHT)
        {
            if (!IsLevelAward() && !IsPresentWithAdvice())
            {
                mDisappearCounter++;
                if (mDisappearCounter >= GetDisappearTime())
                {
                    StartFade();
                }
            }
        }
    }

    if (mCoinMotion == CoinMotion::COIN_MOTION_FROM_PLANT)
    {
        float aFinalScale = GetSunScale();
        if (mScale < aFinalScale)
        {
            mScale += 0.02f;
        }
        else
        {
            mScale = aFinalScale;
        }
    }
}

} // namespace FA

// ================================================================= FormB
namespace FB {

struct Coin
{
    float mPosX = 0, mPosY = 0, mVelX = 0, mVelY = 0, mGroundY = 0, mScale = 1;
    int mWidth = 60, mHeight = 60;
    CoinType mType = COIN_NONE;
    CoinMotion mCoinMotion = COIN_MOTION_FROM_SKY;
    float mCollectionDistance = 0;
    bool mDead = false;
    int mDisappearCounter = 0;
    bool mIsBeingCollected = false;
    int mFadeCount = 0;
    int mCoinAge = 0;
    AttachmentID mAttachmentID = ATTACHMENTID_NULL;
    int mRenderOrder = 0;
    SeedType mUsableSeedType = SEED_NONE;
    bool mNeedsBouncyArrow = false, mHasBouncyArrow = false, mHitGround = false;
    int mTimesDropped = 0;
    PottedPlantSpec mPottedPlantSpec;
    LawnApp* mApp = &g_app;
    Board* mBoard = &g_board;

    // 谓词不入 checksum：FormA 链式 else-if 每级调用谓词、FormB 表直查不再调用——
    // 调用次数差是转换本身消除冗余谓词的正当差异，语义结果由对象终态+动作桩保证。
    bool IsSun() { return mType == CoinType::COIN_SUN || mType == CoinType::COIN_SMALLSUN || mType == CoinType::COIN_LARGESUN; }
    bool IsMoney() { return mType == CoinType::COIN_SILVER || mType == CoinType::COIN_GOLD || mType == CoinType::COIN_DIAMOND; }
    bool IsPresentWithAdvice() { return mType >= CoinType::COIN_PRESENT_MINIGAMES; }
    bool IsLevelAward() { return mType >= CoinType::COIN_AWARD_MONEY_BAG && mType <= CoinType::COIN_AWARD_GOLD_SUNFLOWER; }
    bool CoinGetsBouncyArrow()
    {
        if (IsLevelAward()) return true;
        if (mType == CoinType::COIN_SILVER || mType == CoinType::COIN_GOLD)
            if (mApp->IsFirstTimeAdventureMode() && mBoard && mBoard->mLevel == 11 && !mBoard->mDroppedFirstCoin)
                return true;
        return IsPresentWithAdvice();
    }
    void Collect() { MixCk(0x4004ULL); }
    void PlayGroundSound() { MixCk(0x4005ULL, mType); }
    void PlayLaunchSound() { MixCk(0x4006ULL, mType); }
    void StartFade() { MixCk(0x4007ULL); }
    int  GetDisappearTime() { MixCk(0x4008ULL); return 50; }
    float GetSunScale() { MixCk(0x4009ULL); return 0.5f + (mType & 1) * 0.25f; }
    void AttachReanim(AttachmentID& id, Reanimation* r, float x, float y) { MixCk(0x400AULL, (uint64_t)(int)(x + y)); (void)id; (void)r; }
    void AttachParticle(AttachmentID& id, TodParticleSystem* p, float x, float y) { MixCk(0x400BULL, (uint64_t)(int)(x + y)); (void)id; (void)p; }
    static int GetCoinValue(CoinType theCoinType);

    __declspec(noinline) void CoinInitialize(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion);
    __declspec(noinline) void UpdateFall();
};

namespace
{
using CoinInitCaseFn = void (*)(Coin&);
void CoinInitDefault(Coin& c) { (void)c; TOD_ASSERT(false); }
constexpr CoinInitCaseFn kCoinInitCases[(int)CoinMotion::COIN_MOTION_FROM_BOSS + 1] = {
    [](Coin& c) { c.mVelY = 0.67f; c.mVelX = 0.0f; c.mGroundY = Rand(250) + 300; },
    [](Coin& c) { c.mVelY = 0.33f; c.mVelX = 0.0f; c.mGroundY = Rand(250) + 300; },
    [](Coin& c) { c.mVelY = -1.7f - RandRangeFloat(0.0f, 1.7f); c.mVelX = -0.4f + RandRangeFloat(0.0f, 0.8f);
                  c.mGroundY = c.mPosY + 15 + Rand(20); c.mScale = 0.4f; },
    [](Coin& c) { c.mVelY = -3.0f - RandRangeFloat(0.0f, 2.0f); c.mVelX = -0.5f + RandRangeFloat(0.0f, 1.0f);
                  c.mGroundY = c.mPosY + 45 + Rand(20);
                  if (c.mGroundY > 521) c.mGroundY = 521;
                  if (c.mGroundY < 80) c.mGroundY = 80;
                  if (c.mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || c.mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
                  { c.mPosY -= 100.0f; c.mGroundY = c.mPosY + 45.0f; if (c.mGroundY > 400) c.mGroundY = 400; }
                  if (c.mType == CoinType::COIN_FINAL_SEED_PACKET || c.mType == CoinType::COIN_USABLE_SEED_PACKET ||
                      c.mType == CoinType::COIN_TROPHY || c.mType == CoinType::COIN_SHOVEL ||
                      c.mType == CoinType::COIN_CARKEYS || c.mType == CoinType::COIN_ALMANAC ||
                      c.mType == CoinType::COIN_VASE || c.mType == CoinType::COIN_WATERING_CAN ||
                      c.mType == CoinType::COIN_TACO || c.mType == CoinType::COIN_NOTE)
                  { c.mGroundY -= 30; } },
    [](Coin& c) { c.mVelY = 0.0f; c.mVelX = 0.0f; c.mGroundY = 600; c.Collect(); },
    [](Coin& c) { c.mVelY = 0.0f; c.mVelX = 0.0f; c.mGroundY = 600;
                  c.mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 1); },
    [](Coin& c) { c.mVelY = -5.0f; c.mVelX = -3.0f; c.mPosX = 750.0f;
                  c.mPosY = c.mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER ? 130.0f : 245.0f;
                  c.mGroundY = c.mPosY + 40; },
};
}

// ---- #11 GetCoinValue（B：kCoinValueRows 28 槽 static constexpr——照抄）
int Coin::GetCoinValue(CoinType theCoinType)
{
    // B 形态 -> 常量表 kCoinValueRows（原 4 支三目链合并；行序 = CoinType 枚举序
    // 0..27，count_last=末值 PRESENT_SURVIVAL_MODE 锚定；0 槽 = 原默认支）
    static constexpr int kCoinValueRows[(int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1] = {
        0,    // 0 COIN_NONE（原默认支）
        1,    // 1 COIN_SILVER
        5,    // 2 COIN_GOLD
        100,  // 3 COIN_DIAMOND
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 4..27 其余（原默认支）
    };
    static_assert(sizeof(kCoinValueRows) / sizeof(kCoinValueRows[0]) == (int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1,
        "kCoinValueRows 槽位须与 CoinType 枚举同步");

    return (unsigned)theCoinType < sizeof(kCoinValueRows) / sizeof(kCoinValueRows[0]) ?
        kCoinValueRows[(int)theCoinType] : 0;
}

// ---- #9 CoinInitialize（B：kCoinSizeRows 28 槽 static constexpr——照抄）
void Coin::CoinInitialize(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion)
{
    mPosX = theX;
    mPosY = theY;
    mType = theCoinType;
    mCollectionDistance = 0.0f;
    mDead = false;
    mWidth = 60;
    mHeight = 60;
    mDisappearCounter = 0;
    mIsBeingCollected = false;
    mFadeCount = 0;
    mCoinMotion = theCoinMotion;
    mCoinAge = 0;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_COIN_BANK, 0, 1);
    mScale = 1.0f;
    mUsableSeedType = SeedType::SEED_NONE;
    mNeedsBouncyArrow = false;
    mHasBouncyArrow = false;
    mHitGround = false;
    mTimesDropped = 0;
    mPottedPlantSpec.InitializePottedPlant(SeedType::SEED_NONE);

    if (IsSun())
    {
        float aPosX = mWidth * 0.5f;
        float aPosY = mHeight * 0.5f;
        Reanimation* aSunReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SUN);
        aSunReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aSunReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aSunReanim->mAnimRate = 6.0f;
        AttachReanim(mAttachmentID, aSunReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_SILVER)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_SILVER);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_GOLD)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_GOLD);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_DIAMOND)
    {
        mPosX -= 15.0f;
        mPosY -= 15.0f;

        float aPosX = -3.0f;
        float aPosY = 4.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_DIAMOND);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate = RandRangeFloat(50.0f, 80.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }

    if (mApp->IsStormyNightLevel())
    {
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    // B 形态 -> 常量表 kCoinSizeRows（原 15 支链合并；行序 = CoinType 枚举序
    // 0..27，count_last=末值 PRESENT_SURVIVAL_MODE 锚定）。
    static constexpr struct { Image* const* mImage; RenderLayer mLayer; uint8_t mRow; uint8_t mLayerOffset; bool mSetOrder; } kCoinSizeRows[] = {
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 0 COIN_NONE（原链不匹配）
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 1 COIN_SILVER（原链不匹配）
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 2 COIN_GOLD（原链不匹配）
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 3 COIN_DIAMOND（原链不匹配）
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 4 COIN_SUN（原链不匹配）
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 5 COIN_SMALLSUN（原链不匹配）
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 6 COIN_LARGESUN（原链不匹配）
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 7 COIN_FINAL_SEED_PACKET
        { &IMAGE_TROPHY,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 8 COIN_TROPHY
        { &IMAGE_SHOVEL,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 9 COIN_SHOVEL
        { &IMAGE_ALMANAC,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 10 COIN_ALMANAC
        { &IMAGE_CARKEYS,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 11 COIN_CARKEYS
        { &IMAGE_SCARY_POT,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 12 COIN_VASE
        { &IMAGE_WATERINGCAN,        RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 13 COIN_WATERING_CAN
        { &IMAGE_TACO,               RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 14 COIN_TACO
        { &IMAGE_ZOMBIE_NOTE_SMALL,  RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 15 COIN_NOTE
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_FOG,      0, 2, true  },  // 16 COIN_USABLE_SEED_PACKET
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 17 COIN_PRESENT_PLANT（不改 renderOrder）
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 18 COIN_AWARD_MONEY_BAG
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },  // 19 COIN_AWARD_PRESENT（不改 renderOrder）
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 20 COIN_AWARD_BAG_DIAMOND（共体）
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 21 COIN_AWARD_SILVER_SUNFLOWER
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 22 COIN_AWARD_GOLD_SUNFLOWER（共体）
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 23 COIN_CHOCOLATE
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 24 COIN_AWARD_CHOCOLATE（共体）
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 25 COIN_PRESENT_MINIGAMES
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 26 COIN_PRESENT_PUZZLE_MODE
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },  // 27 COIN_PRESENT_SURVIVAL_MODE
    };
    static_assert(sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) == (int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1,
        "kCoinSizeRows 槽位须与 CoinType 枚举同步");

    if ((unsigned)mType < sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) && kCoinSizeRows[(int)mType].mImage != nullptr)
    {
        const auto& aRow = kCoinSizeRows[(int)mType];
        mWidth = (*aRow.mImage)->GetCelWidth();
        mHeight = (*aRow.mImage)->GetCelHeight();
        if (aRow.mSetOrder)
        {
            mRenderOrder = Board::MakeRenderOrder(aRow.mLayer, aRow.mRow, aRow.mLayerOffset);
        }
    }

    // 表外特例：礼物内容挑选（原 COIN_PRESENT_PLANT/COIN_AWARD_PRESENT 分支体）
    if (mType == CoinType::COIN_PRESENT_PLANT || mType == CoinType::COIN_AWARD_PRESENT)
    {
        TOD_ASSERT(mBoard);

        if (mApp->IsSurvivalEndless(mApp->mGameMode) || mApp->IsEndlessIZombie(mApp->mGameMode) || mApp->IsEndlessScaryPotter(mApp->mGameMode))
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else
        {
            const int aBackground = (int)mBoard->mBackground;
            if ((unsigned)aBackground < (unsigned)(sizeof(kPresentSeeds) / sizeof(kPresentSeeds[0])) &&
                kPresentSeeds[aBackground].mSeedList != nullptr)
            {
                mPottedPlantSpec.InitializePottedPlant(
                    TodPickFromList(kPresentSeeds[aBackground].mSeedList, kPresentSeeds[aBackground].mCount));
            }
            else
            {
                SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
                mPottedPlantSpec.InitializePottedPlant(aSeedType);
            }
        }
    }

    const unsigned aMotionIndex = static_cast<unsigned>(mCoinMotion);
    if (aMotionIndex <= static_cast<unsigned>(CoinMotion::COIN_MOTION_FROM_BOSS))
    {
        kCoinInitCases[aMotionIndex](*this);
    }
    else
    {
        CoinInitDefault(*this);
    }

    float aScale;
    if (mType == CoinType::COIN_SMALLSUN)
    {
        aScale = 0.5f;
    }
    else if (mType == CoinType::COIN_LARGESUN)
    {
        aScale = 2.0f;
    }
    else
    {
        aScale = 1.0f;
    }
    mScale *= aScale;

    if (CoinGetsBouncyArrow())
    {
        mNeedsBouncyArrow = true;
    }

    if (mCoinMotion != CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        PlayLaunchSound();
    }
}

// ---- #10 UpdateFall（B：kCoinArrowOffsets 28 槽 static constexpr——照抄）
void Coin::UpdateFall()
{
    if (mCoinMotion == CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        mPosX += mVelX;
        mPosY += mVelY;
        mVelX *= 0.95f;
        mVelY *= 0.95f;
        if (mCoinAge >= 80)
        {
            Collect();
        }
    }
    else if (mPosY + mVelY < mGroundY)
    {
        mPosY += mVelY;
        if (mCoinMotion == CoinMotion::COIN_MOTION_FROM_PLANT)
        {
            mVelY += 0.09f;
        }
        else if (mCoinMotion == CoinMotion::COIN_MOTION_COIN || mCoinMotion == CoinMotion::COIN_MOTION_FROM_BOSS)
        {
            mVelY += 0.15f;
        }

        mPosX += mVelX;
        if (mPosX > BOARD_WIDTH - mWidth && mCoinMotion != CoinMotion::COIN_MOTION_FROM_BOSS)
        {
            mPosX = BOARD_WIDTH - mWidth;
            mVelX = -0.4f - RandRangeFloat(0.0f, 0.4f);
        }
        else if (mPosX < 0.0f)
        {
            mPosX = 0.0f;
            mVelX = 0.4f + RandRangeFloat(0.0f, 0.4f);
        }
    }
    else
    {
        if (mNeedsBouncyArrow && !mHasBouncyArrow)
        {
            float aParticleOffsetX = mWidth / 2;
            float aParticleOffsetY = mHeight / 2 - 60;

            // B 形态 -> 常量表 kCoinArrowOffsets（原 5 支链合并；行序 = CoinType 枚举序 0..27）
            static constexpr struct { float mOffX; float mOffY; } kCoinArrowOffsets[] = {
                {  0.0f,   0.0f },  // 0 COIN_NONE（原链不匹配）
                { 12.0f,  21.0f },  // 1 COIN_SILVER（原 IsMoney 支）
                { 12.0f,  21.0f },  // 2 COIN_GOLD（原 IsMoney 支）
                { 12.0f,  21.0f },  // 3 COIN_DIAMOND（原 IsMoney 支）
                {  0.0f,   0.0f },  // 4 COIN_SUN（原链不匹配）
                {  0.0f,   0.0f },  // 5 COIN_SMALLSUN（原链不匹配）
                {  0.0f,   0.0f },  // 6 COIN_LARGESUN（原链不匹配）
                {  0.0f,   0.0f },  // 7 COIN_FINAL_SEED_PACKET（原链不匹配）
                {  2.0f,   0.0f },  // 8 COIN_TROPHY
                {  0.0f,   0.0f },  // 9 COIN_SHOVEL（原链不匹配）
                {  0.0f,   0.0f },  // 10 COIN_ALMANAC（原链不匹配）
                {  0.0f,   0.0f },  // 11 COIN_CARKEYS（原链不匹配）
                {  0.0f,   0.0f },  // 12 COIN_VASE（原链不匹配）
                {  0.0f,   0.0f },  // 13 COIN_WATERING_CAN（原链不匹配）
                {  0.0f,   0.0f },  // 14 COIN_TACO（原链不匹配）
                {  0.0f,   0.0f },  // 15 COIN_NOTE（原链不匹配）
                {  0.0f,   0.0f },  // 16 COIN_USABLE_SEED_PACKET（原链不匹配）
                {  0.0f,   0.0f },  // 17 COIN_PRESENT_PLANT（原链不匹配）
                {  2.0f,  -2.0f },  // 18 COIN_AWARD_MONEY_BAG
                {  0.0f, -20.0f },  // 19 COIN_AWARD_PRESENT
                {  2.0f,  -2.0f },  // 20 COIN_AWARD_BAG_DIAMOND（共体）
                { -6.0f, -40.0f },  // 21 COIN_AWARD_SILVER_SUNFLOWER
                { -6.0f, -40.0f },  // 22 COIN_AWARD_GOLD_SUNFLOWER（共体）
                {  0.0f,   0.0f },  // 23 COIN_CHOCOLATE（原链不匹配）
                {  0.0f,   0.0f },  // 24 COIN_AWARD_CHOCOLATE（原链不匹配）
                {  0.0f, -20.0f },  // 25 COIN_PRESENT_MINIGAMES（原 IsPresentWithAdvice 支）
                {  0.0f, -20.0f },  // 26 COIN_PRESENT_PUZZLE_MODE（共体）
                {  0.0f, -20.0f },  // 27 COIN_PRESENT_SURVIVAL_MODE（共体）
            };
            static_assert(sizeof(kCoinArrowOffsets) / sizeof(kCoinArrowOffsets[0]) == (int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1,
                "kCoinArrowOffsets 槽位须与 CoinType 枚举同步");

            if ((unsigned)mType < sizeof(kCoinArrowOffsets) / sizeof(kCoinArrowOffsets[0]))
            {
                aParticleOffsetX += kCoinArrowOffsets[(int)mType].mOffX;
                aParticleOffsetY += kCoinArrowOffsets[(int)mType].mOffY;
            }

            ParticleEffect aEffect;
            if (mType == CoinType::COIN_FINAL_SEED_PACKET)
            {
                aEffect = ParticleEffect::PARTICLE_SEED_PACKET;
            }
            else if (IsMoney())
            {
                aEffect = ParticleEffect::PARTICLE_COIN_PICKUP_ARROW;
            }
            else
            {
                aEffect = ParticleEffect::PARTICLE_AWARD_PICKUP_ARROW;
            }

            TodParticleSystem* aParticle = mApp->AddTodParticle(mPosX + aParticleOffsetX, mPosY + aParticleOffsetY, 0, aEffect);
            AttachParticle(mAttachmentID, aParticle, aParticleOffsetX, aParticleOffsetY);
            mHasBouncyArrow = true;
        }

        if (!mHitGround)
        {
            mHitGround = true;
            PlayGroundSound();
        }

        mPosY = mGroundY;
        mPosX = FloatRoundToInt(mPosX);


        if (mApp->mGameMode != GameMode::GAMEMODE_CHALLENGE_LAST_STAND || mBoard == nullptr ||
            mBoard->mChallenge->mChallengeState == ChallengeState::STATECHALLENGE_LAST_STAND_ONSLAUGHT)
        {
            if (!IsLevelAward() && !IsPresentWithAdvice())
            {
                mDisappearCounter++;
                if (mDisappearCounter >= GetDisappearTime())
                {
                    StartFade();
                }
            }
        }
    }

    if (mCoinMotion == CoinMotion::COIN_MOTION_FROM_PLANT)
    {
        float aFinalScale = GetSunScale();
        if (mScale < aFinalScale)
        {
            mScale += 0.02f;
        }
        else
        {
            mScale = aFinalScale;
        }
    }
}

} // namespace FB

// ================================================================= 驱动
static FA::Coin g_objA[NOBJ], g_pristineA[NOBJ];
static FB::Coin g_objB[NOBJ], g_pristineB[NOBJ];
static In g_in[NIN];

void A_Init(FA::Coin* c) { c->CoinInitialize(300, 300, c->mType, c->mCoinMotion); }
void B_Init(FB::Coin* c) { c->CoinInitialize(300, 300, c->mType, c->mCoinMotion); }
void A_Fall(FA::Coin* c) { c->UpdateFall(); }
void B_Fall(FB::Coin* c) { c->UpdateFall(); }
void A_Value(FA::Coin* c) { MixCk(0x4F00ULL, (uint64_t)(unsigned)FA::Coin::GetCoinValue(c->mType)); }
void B_Value(FB::Coin* c) { MixCk(0x4F00ULL, (uint64_t)(unsigned)FB::Coin::GetCoinValue(c->mType)); }

int main()
{
    InitZombiePool();
    gSexyAppBase = &g_app;
    g_app.mGameMode = GAMEMODE_ADVENTURE;

    printf("%-28s | %19s | %19s | %8s | %s\n", "target(Coin)", "A ns r1/r2", "B ns r1/r2", "diff%", "checksum A/B");

    // ---- #9 CoinInitialize：mType 0..27 均匀 + CoinMotion 0..6 均匀
    GenInputs(g_in, NIN, 0x9001, 28, 7, 8, 5);
    {
        auto prepA = [](FA::Coin& c, const In& in) {
            c.mType = (CoinType)in.a; c.mCoinMotion = (CoinMotion)in.b;
            c.mPosX = 300.0f + in.c; c.mPosY = 300.0f + in.d;
        };
        auto prepB = [](FB::Coin& c, const In& in) {
            c.mType = (CoinType)in.a; c.mCoinMotion = (CoinMotion)in.b;
            c.mPosX = 300.0f + in.c; c.mPosY = 300.0f + in.d;
        };
        RunTarget("9 kCoinSizeRows 28", A_Init, B_Init,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #10 UpdateFall：mType 0..27 + 落地/下落混合（箭头支链主压力）
    GenInputs(g_in, NIN, 0x9002, 28, 7, 8, 8);
    {
        auto prepA = [](FA::Coin& c, const In& in) {
            c.mType = (CoinType)in.a; c.mCoinMotion = (CoinMotion)in.b;
            c.mWidth = 60; c.mHeight = 60; c.mGroundY = 300.0f; c.mScale = 0.5f;
            c.mVelX = (float)(in.d % 5) - 2.0f; c.mVelY = 0.5f; c.mPosX = (float)(in.c % 780);
            c.mPosY = (in.d & 1) ? (c.mGroundY - c.mVelY) : (c.mGroundY - 50.0f);
            c.mCoinAge = in.c; c.mHitGround = false;
            c.mNeedsBouncyArrow = (in.c & 7) != 0; c.mHasBouncyArrow = false; c.mDisappearCounter = 0;
            g_app.mGameMode = GAMEMODE_ADVENTURE;
        };
        auto prepB = [](FB::Coin& c, const In& in) {
            c.mType = (CoinType)in.a; c.mCoinMotion = (CoinMotion)in.b;
            c.mWidth = 60; c.mHeight = 60; c.mGroundY = 300.0f; c.mScale = 0.5f;
            c.mVelX = (float)(in.d % 5) - 2.0f; c.mVelY = 0.5f; c.mPosX = (float)(in.c % 780);
            c.mPosY = (in.d & 1) ? (c.mGroundY - c.mVelY) : (c.mGroundY - 50.0f);
            c.mCoinAge = in.c; c.mHitGround = false;
            c.mNeedsBouncyArrow = (in.c & 7) != 0; c.mHasBouncyArrow = false; c.mDisappearCounter = 0;
            g_app.mGameMode = GAMEMODE_ADVENTURE;
        };
        RunTarget("10 kCoinArrowOffsets 28", A_Fall, B_Fall,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #11 GetCoinValue：0..29（含越界 28/29 两值走兜底）
    GenInputs(g_in, NIN, 0x9003, 30, 1, 1, 1);
    {
        auto prepA = [](FA::Coin& c, const In& in) { c.mType = (CoinType)in.a; };
        auto prepB = [](FB::Coin& c, const In& in) { c.mType = (CoinType)in.a; };
        RunTarget("11 kCoinValueRows 28", A_Value, B_Value,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    return 0;
}
