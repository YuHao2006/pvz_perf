// b23_b24_coin.cpp — kCoinInitCases -> Coin::CoinInitialize 运动分发（生成一次）
//                  + kPresentSeeds 族（5+1 张）-> 礼物内容选择（事件）
// 同一 HEAD 函数体为基座，逐段换装原形态（隔离对拍：其余段两侧完全一致）：
//   _Amotion  = 运动段换回 d6f36d20^ 原 switch
//   _Apresent = 礼物内容段换回 13c77bf3^ 原五连 else-if（宽高已由 kCoinSizeRows
//               覆盖——原链该段宽高赋值与表行同图同值，等价，只换选择逻辑）
#include "r3_entities.h"

// ==================== kPresentSeeds 族（HEAD 逐字） ====================
namespace
{
constexpr SeedType kPresentSeedsDay[] = {
    SeedType::SEED_PEASHOOTER, SeedType::SEED_SUNFLOWER, SeedType::SEED_CHERRYBOMB, SeedType::SEED_WALLNUT,
    SeedType::SEED_REPEATER, SeedType::SEED_POTATOMINE, SeedType::SEED_SNOWPEA, SeedType::SEED_CHOMPER };
constexpr SeedType kPresentSeedsNight[] = {
    SeedType::SEED_PUFFSHROOM, SeedType::SEED_SUNSHROOM, SeedType::SEED_FUMESHROOM, SeedType::SEED_GRAVEBUSTER,
    SeedType::SEED_HYPNOSHROOM, SeedType::SEED_SCAREDYSHROOM, SeedType::SEED_ICESHROOM, SeedType::SEED_DOOMSHROOM };
constexpr SeedType kPresentSeedsPool[] = {
    SeedType::SEED_LILYPAD, SeedType::SEED_SQUASH, SeedType::SEED_THREEPEATER, SeedType::SEED_TANGLEKELP,
    SeedType::SEED_JALAPENO, SeedType::SEED_SPIKEWEED, SeedType::SEED_TORCHWOOD, SeedType::SEED_TALLNUT };
constexpr SeedType kPresentSeedsFog[] = {
    SeedType::SEED_SEASHROOM, SeedType::SEED_PLANTERN, SeedType::SEED_CACTUS, SeedType::SEED_BLOVER,
    SeedType::SEED_SPLITPEA, SeedType::SEED_STARFRUIT, SeedType::SEED_PUMPKINSHELL, SeedType::SEED_MAGNETSHROOM };
constexpr SeedType kPresentSeedsRoof[] = {
    SeedType::SEED_CABBAGEPULT, SeedType::SEED_KERNELPULT, SeedType::SEED_INSTANT_COFFEE,
    SeedType::SEED_GARLIC, SeedType::SEED_UMBRELLA, SeedType::SEED_MELONPULT };

constexpr struct
{
    const SeedType* mSeedList;
    int mCount;
} kPresentSeeds[] = {
    /* BACKGROUND_1_DAY           */ { kPresentSeedsDay,   LENGTH(kPresentSeedsDay) },
    /* BACKGROUND_2_NIGHT         */ { kPresentSeedsNight, LENGTH(kPresentSeedsNight) },
    /* BACKGROUND_3_POOL          */ { kPresentSeedsPool,  LENGTH(kPresentSeedsPool) },
    /* BACKGROUND_4_FOG           */ { kPresentSeedsFog,   LENGTH(kPresentSeedsFog) },
    /* BACKGROUND_5_ROOF          */ { kPresentSeedsRoof,  LENGTH(kPresentSeedsRoof) },
    /* BACKGROUND_6_BOSS          */ { nullptr, 0 },
    /* BACKGROUND_MUSHROOM_GARDEN */ { nullptr, 0 },
    /* BACKGROUND_GREENHOUSE      */ { nullptr, 0 },
    /* BACKGROUND_ZOMBIQUARIUM    */ { nullptr, 0 },
    /* BACKGROUND_TREEOFWISDOM    */ { nullptr, 0 },
};
static_assert(sizeof(kPresentSeeds) / sizeof(kPresentSeeds[0]) == (int)BackgroundType::BACKGROUND_TREEOFWISDOM + 1,
    "礼物种子槽位须与 BackgroundType 枚举尾同步");
}  // namespace

// ==================== kCoinInitCases（HEAD 逐字） ====================
namespace
{
using CoinInitCaseFn = void (*)(Coin&);

// 原 default（无 case 的 0 型与表外哨兵共用）
void CoinInitDefault(Coin& c)
{
            TOD_ASSERT(false);
}

constexpr CoinInitCaseFn kCoinInitCases[(int)CoinMotion::COIN_MOTION_FROM_BOSS + 1] = {
    // 原 case COIN_MOTION_FROM_SKY
    [](Coin& c)
    {
            c.mVelY = 0.67f;
            c.mVelX = 0.0f;
            c.mGroundY = Rand(250) + 300;
    },  // 0 COIN_MOTION_FROM_SKY
    // 原 case COIN_MOTION_FROM_SKY_SLOW
    [](Coin& c)
    {
            c.mVelY = 0.33f;
            c.mVelX = 0.0f;
            c.mGroundY = Rand(250) + 300;
    },  // 1 COIN_MOTION_FROM_SKY_SLOW
    // 原 case COIN_MOTION_FROM_PLANT
    [](Coin& c)
    {
            c.mVelY = -1.7f - RandRangeFloat(0.0f, 1.7f);
            c.mVelX = -0.4f + RandRangeFloat(0.0f, 0.8f);
            c.mGroundY = c.mPosY + 15 + Rand(20);
            c.mScale = 0.4f;
    },  // 2 COIN_MOTION_FROM_PLANT
    // 原 case COIN_MOTION_COIN
    [](Coin& c)
    {
            c.mVelY = -3.0f - RandRangeFloat(0.0f, 2.0f);
            c.mVelX = -0.5f + RandRangeFloat(0.0f, 1.0f);
            c.mGroundY = c.mPosY + 45 + Rand(20);
            if (c.mGroundY > 521)
            {
                c.mGroundY = 521;
            }
            if (c.mGroundY < 80)
            {
                c.mGroundY = 80;
            }
            if (c.mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || c.mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
            {
                c.mPosY -= 100.0f;
                c.mGroundY = c.mPosY + 45.0f;
                if (c.mGroundY > 400)
                {
                    c.mGroundY = 400;
                }
            }
            if (c.mType == CoinType::COIN_FINAL_SEED_PACKET ||
                c.mType == CoinType::COIN_USABLE_SEED_PACKET ||
                c.mType == CoinType::COIN_TROPHY ||
                c.mType == CoinType::COIN_SHOVEL ||
                c.mType == CoinType::COIN_CARKEYS ||
                c.mType == CoinType::COIN_ALMANAC ||
                c.mType == CoinType::COIN_VASE ||
                c.mType == CoinType::COIN_WATERING_CAN ||
                c.mType == CoinType::COIN_TACO ||
                c.mType == CoinType::COIN_NOTE)
            {
                c.mGroundY -= 30;
            }
    },  // 3 COIN_MOTION_COIN
    // 原 case COIN_MOTION_LAWNMOWER_COIN
    [](Coin& c)
    {
            c.mVelY = 0.0f;
            c.mVelX = 0.0f;
            c.mGroundY = 600;
            c.Collect();
    },  // 4 COIN_MOTION_LAWNMOWER_COIN
    // 原 case COIN_MOTION_FROM_PRESENT
    [](Coin& c)
    {
            c.mVelY = 0.0f;
            c.mVelX = 0.0f;
            c.mGroundY = 600;
            c.mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 1);
    },  // 5 COIN_MOTION_FROM_PRESENT
    // 原 case COIN_MOTION_FROM_BOSS
    [](Coin& c)
    {
            c.mVelY = -5.0f;
            c.mVelX = -3.0f;
            c.mPosX = 750.0f;
            c.mPosY = c.mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER ? 130.0f : 245.0f;
            c.mGroundY = c.mPosY + 40;
    },  // 6 COIN_MOTION_FROM_BOSS
};
static_assert(sizeof(kCoinInitCases) / sizeof(kCoinInitCases[0]) ==
    (int)CoinMotion::COIN_MOTION_FROM_BOSS + 1, "kCoinInitCases 槽位数须与 CoinMotion 枚举同步");
}  // namespace

// ==================== 公共桩（Coin 尾段消费；两形态同参） ====================
__declspec(noinline) bool CoinGetsBouncyArrowStub(Coin& c) { ZSink(RID_Coin_Draw, 61); return false; }
__declspec(noinline) void PlayLaunchSoundStub(Coin& c) { ZSink(RID_Coin_Draw, 62); }

// ==================== FormB：HEAD CoinInitialize（逐字） ====================
__declspec(noinline) void Coin::CoinInitialize_B(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion)
{
    mPosX = theX;
    mPosY = theY;
    mType = theCoinType;
    mCollectionDistance = 0.0f;
    mDead = false;
    mWidth = 60;
    mHeight = 60;
    mDisappearCounter = 0;
    mIsBeingCollected = false;
    mFadeCount = 0;
    mCoinMotion = theCoinMotion;
    mCoinAge = 0;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_COIN_BANK, 0, 1);
    mScale = 1.0f;
    mUsableSeedType = SeedType::SEED_NONE;
    mNeedsBouncyArrow = false;
    mHasBouncyArrow = false;
    mHitGround = false;
    mTimesDropped = 0;
    mPottedPlantSpec.InitializePottedPlant(SeedType::SEED_NONE);

    if (IsSun())
    {
        float aPosX = mWidth * 0.5f;
        float aPosY = mHeight * 0.5f;
        Reanimation* aSunReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SUN);
        aSunReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aSunReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aSunReanim->mAnimRate = 6.0f;
        AttachReanim(mAttachmentID, aSunReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_SILVER)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_SILVER);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_GOLD)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_GOLD);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_DIAMOND)
    {
        mPosX -= 15.0f;
        mPosY -= 15.0f;

        float aPosX = -3.0f;
        float aPosY = 4.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_DIAMOND);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate = RandRangeFloat(50.0f, 80.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }

    if (mApp->IsStormyNightLevel())
    {
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    static constexpr struct { Image* const* mImage; RenderLayer mLayer; uint8_t mRow; uint8_t mLayerOffset; bool mSetOrder; } kCoinSizeRows[] = {
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_TROPHY,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SHOVEL,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_ALMANAC,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CARKEYS,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SCARY_POT,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_WATERINGCAN,        RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_TACO,               RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_ZOMBIE_NOTE_SMALL,  RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_FOG,      0, 2, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
    };
    static_assert(sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) == (int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1,
        "kCoinSizeRows 槽位须与 CoinType 枚举同步");

    if ((unsigned)mType < sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) && kCoinSizeRows[(int)mType].mImage != nullptr)
    {
        const auto& aRow = kCoinSizeRows[(int)mType];
        mWidth = (*aRow.mImage)->GetCelWidth();
        mHeight = (*aRow.mImage)->GetCelHeight();
        if (aRow.mSetOrder)
        {
            mRenderOrder = Board::MakeRenderOrder(aRow.mLayer, aRow.mRow, aRow.mLayerOffset);
        }
    }

    // 表外特例：礼物内容挑选（原 COIN_PRESENT_PLANT/COIN_AWARD_PRESENT 分支体）
    if (mType == CoinType::COIN_PRESENT_PLANT || mType == CoinType::COIN_AWARD_PRESENT)
    {
        TOD_ASSERT(mBoard);

        if (mApp->IsSurvivalEndless(mApp->mGameMode) || mApp->IsEndlessIZombie(mApp->mGameMode) || mApp->IsEndlessScaryPotter(mApp->mGameMode))
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else
        {
            // 背景直下标礼物候选表；未列背景走禅意花园随机（等价原 else 链）
            const int aBackground = (int)mBoard->mBackground;
            if ((unsigned)aBackground < (unsigned)(sizeof(kPresentSeeds) / sizeof(kPresentSeeds[0])) &&
                kPresentSeeds[aBackground].mSeedList != nullptr)
            {
                mPottedPlantSpec.InitializePottedPlant(
                    TodPickFromList(kPresentSeeds[aBackground].mSeedList, kPresentSeeds[aBackground].mCount));
            }
            else
            {
                SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
                mPottedPlantSpec.InitializePottedPlant(aSeedType);
            }
        }
    }

    // C 形态 -> 匿名 lambda 表：行序 = CoinMotion 枚举序（0..6，无 NUM
    // 哨兵=末值 FROM_BOSS 锚定）；default（TOD_ASSERT）具名并被缺槽/越界复用。
    const unsigned aMotionIndex = static_cast<unsigned>(mCoinMotion);
    if (aMotionIndex <= static_cast<unsigned>(CoinMotion::COIN_MOTION_FROM_BOSS))
    {
        kCoinInitCases[aMotionIndex](*this);
    }
    else
    {
        CoinInitDefault(*this);
    }


    float aScale;
    if (mType == CoinType::COIN_SMALLSUN)
    {
        aScale = 0.5f;
    }
    else if (mType == CoinType::COIN_LARGESUN)
    {
        aScale = 2.0f;
    }
    else
    {
        aScale = 1.0f;
    }
    mScale *= aScale;

    if (CoinGetsBouncyArrowStub(*this))
    {
        mNeedsBouncyArrow = true;
    }

    if (mCoinMotion != CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        PlayLaunchSoundStub(*this);
    }
}

// ==================== FormA-motion：运动段换回 d6f36d20^ switch（其余同 HEAD） ====================
__declspec(noinline) void Coin::CoinInitialize_Amotion(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion)
{
    mPosX = theX;
    mPosY = theY;
    mType = theCoinType;
    mCollectionDistance = 0.0f;
    mDead = false;
    mWidth = 60;
    mHeight = 60;
    mDisappearCounter = 0;
    mIsBeingCollected = false;
    mFadeCount = 0;
    mCoinMotion = theCoinMotion;
    mCoinAge = 0;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_COIN_BANK, 0, 1);
    mScale = 1.0f;
    mUsableSeedType = SeedType::SEED_NONE;
    mNeedsBouncyArrow = false;
    mHasBouncyArrow = false;
    mHitGround = false;
    mTimesDropped = 0;
    mPottedPlantSpec.InitializePottedPlant(SeedType::SEED_NONE);

    if (IsSun())
    {
        float aPosX = mWidth * 0.5f;
        float aPosY = mHeight * 0.5f;
        Reanimation* aSunReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SUN);
        aSunReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aSunReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aSunReanim->mAnimRate = 6.0f;
        AttachReanim(mAttachmentID, aSunReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_SILVER)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_SILVER);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_GOLD)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_GOLD);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_DIAMOND)
    {
        mPosX -= 15.0f;
        mPosY -= 15.0f;

        float aPosX = -3.0f;
        float aPosY = 4.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_DIAMOND);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate = RandRangeFloat(50.0f, 80.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }

    if (mApp->IsStormyNightLevel())
    {
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    static constexpr struct { Image* const* mImage; RenderLayer mLayer; uint8_t mRow; uint8_t mLayerOffset; bool mSetOrder; } kCoinSizeRows[] = {
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_TROPHY,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SHOVEL,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_ALMANAC,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CARKEYS,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SCARY_POT,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_WATERINGCAN,        RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_TACO,               RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_ZOMBIE_NOTE_SMALL,  RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_FOG,      0, 2, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
    };
    static_assert(sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) == (int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1,
        "kCoinSizeRows 槽位须与 CoinType 枚举同步");

    if ((unsigned)mType < sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) && kCoinSizeRows[(int)mType].mImage != nullptr)
    {
        const auto& aRow = kCoinSizeRows[(int)mType];
        mWidth = (*aRow.mImage)->GetCelWidth();
        mHeight = (*aRow.mImage)->GetCelHeight();
        if (aRow.mSetOrder)
        {
            mRenderOrder = Board::MakeRenderOrder(aRow.mLayer, aRow.mRow, aRow.mLayerOffset);
        }
    }

    if (mType == CoinType::COIN_PRESENT_PLANT || mType == CoinType::COIN_AWARD_PRESENT)
    {
        TOD_ASSERT(mBoard);

        if (mApp->IsSurvivalEndless(mApp->mGameMode) || mApp->IsEndlessIZombie(mApp->mGameMode) || mApp->IsEndlessScaryPotter(mApp->mGameMode))
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else
        {
            const int aBackground = (int)mBoard->mBackground;
            if ((unsigned)aBackground < (unsigned)(sizeof(kPresentSeeds) / sizeof(kPresentSeeds[0])) &&
                kPresentSeeds[aBackground].mSeedList != nullptr)
            {
                mPottedPlantSpec.InitializePottedPlant(
                    TodPickFromList(kPresentSeeds[aBackground].mSeedList, kPresentSeeds[aBackground].mCount));
            }
            else
            {
                SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
                mPottedPlantSpec.InitializePottedPlant(aSeedType);
            }
        }
    }

    // ===== 原运动段（d6f36d20^ switch 逐字） =====
    switch (mCoinMotion)
    {
    case CoinMotion::COIN_MOTION_FROM_SKY:
        mVelY = 0.67f;
        mVelX = 0.0f;
        mGroundY = Rand(250) + 300;
        break;

    case CoinMotion::COIN_MOTION_FROM_SKY_SLOW:
        mVelY = 0.33f;
        mVelX = 0.0f;
        mGroundY = Rand(250) + 300;
        break;

    case CoinMotion::COIN_MOTION_FROM_PLANT:
        mVelY = -1.7f - RandRangeFloat(0.0f, 1.7f);
        mVelX = -0.4f + RandRangeFloat(0.0f, 0.8f);
        mGroundY = mPosY + 15 + Rand(20);
        mScale = 0.4f;
        break;

    case CoinMotion::COIN_MOTION_COIN:
        mVelY = -3.0f - RandRangeFloat(0.0f, 2.0f);
        mVelX = -0.5f + RandRangeFloat(0.0f, 1.0f);
        mGroundY = mPosY + 45 + Rand(20);
        if (mGroundY > 521)
        {
            mGroundY = 521;
        }
        if (mGroundY < 80)
        {
            mGroundY = 80;
        }
        if (mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
        {
            mPosY -= 100.0f;
            mGroundY = mPosY + 45.0f;
            if (mGroundY > 400)
            {
                mGroundY = 400;
            }
        }
        if (mType == CoinType::COIN_FINAL_SEED_PACKET ||
            mType == CoinType::COIN_USABLE_SEED_PACKET ||
            mType == CoinType::COIN_TROPHY ||
            mType == CoinType::COIN_SHOVEL ||
            mType == CoinType::COIN_CARKEYS ||
            mType == CoinType::COIN_ALMANAC ||
            mType == CoinType::COIN_VASE ||
            mType == CoinType::COIN_WATERING_CAN ||
            mType == CoinType::COIN_TACO ||
            mType == CoinType::COIN_NOTE)
        {
            mGroundY -= 30;
        }
        break;

    case CoinMotion::COIN_MOTION_LAWNMOWER_COIN:
        mVelY = 0.0f;
        mVelX = 0.0f;
        mGroundY = 600;
        Collect();
        break;

    case CoinMotion::COIN_MOTION_FROM_PRESENT:
        mVelY = 0.0f;
        mVelX = 0.0f;
        mGroundY = 600;
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 1);
        break;

    case CoinMotion::COIN_MOTION_FROM_BOSS:
        mVelY = -5.0f;
        mVelX = -3.0f;
        mPosX = 750.0f;
        mPosY = mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER ? 130.0f : 245.0f;
        mGroundY = mPosY + 40;
        break;
    }

    float aScale;
    if (mType == CoinType::COIN_SMALLSUN)
    {
        aScale = 0.5f;
    }
    else if (mType == CoinType::COIN_LARGESUN)
    {
        aScale = 2.0f;
    }
    else
    {
        aScale = 1.0f;
    }
    mScale *= aScale;

    if (CoinGetsBouncyArrowStub(*this))
    {
        mNeedsBouncyArrow = true;
    }

    if (mCoinMotion != CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        PlayLaunchSoundStub(*this);
    }
}

// ==================== FormA-present：礼物段换回 13c77bf3^ else-if 链（其余同 HEAD） ====================
// 说明：原链礼物支前两行（PRESENT 宽高）与 kCoinSizeRows 表行同图同值（已由表覆盖），
// 此处只换内容选择逻辑（隔离对拍面=选择器本身）。
__declspec(noinline) void Coin::CoinInitialize_Apresent(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion)
{
    mPosX = theX;
    mPosY = theY;
    mType = theCoinType;
    mCollectionDistance = 0.0f;
    mDead = false;
    mWidth = 60;
    mHeight = 60;
    mDisappearCounter = 0;
    mIsBeingCollected = false;
    mFadeCount = 0;
    mCoinMotion = theCoinMotion;
    mCoinAge = 0;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_COIN_BANK, 0, 1);
    mScale = 1.0f;
    mUsableSeedType = SeedType::SEED_NONE;
    mNeedsBouncyArrow = false;
    mHasBouncyArrow = false;
    mHitGround = false;
    mTimesDropped = 0;
    mPottedPlantSpec.InitializePottedPlant(SeedType::SEED_NONE);

    if (IsSun())
    {
        float aPosX = mWidth * 0.5f;
        float aPosY = mHeight * 0.5f;
        Reanimation* aSunReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SUN);
        aSunReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aSunReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aSunReanim->mAnimRate = 6.0f;
        AttachReanim(mAttachmentID, aSunReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_SILVER)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_SILVER);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_GOLD)
    {
        mPosX -= 10.0f;
        mPosY -= 8.0f;

        float aPosX = 9.0f;
        float aPosY = 9.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_COIN_GOLD);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate *= RandRangeFloat(0.6f, 1.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }
    else if (mType == CoinType::COIN_DIAMOND)
    {
        mPosX -= 15.0f;
        mPosY -= 15.0f;

        float aPosX = -3.0f;
        float aPosY = 4.0f;
        Reanimation* aCoinReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_DIAMOND);
        aCoinReanim->SetPosition(mPosX + aPosX, mPosY + aPosY);
        aCoinReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aCoinReanim->mAnimTime = RandRangeFloat(0.0f, 0.99f);
        aCoinReanim->mAnimRate = RandRangeFloat(50.0f, 80.0f);
        AttachReanim(mAttachmentID, aCoinReanim, aPosX, aPosY);
    }

    if (mApp->IsStormyNightLevel())
    {
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    static constexpr struct { Image* const* mImage; RenderLayer mLayer; uint8_t mRow; uint8_t mLayerOffset; bool mSetOrder; } kCoinSizeRows[] = {
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { nullptr,                   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_TROPHY,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SHOVEL,             RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_ALMANAC,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CARKEYS,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SCARY_POT,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_WATERINGCAN,        RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_TACO,               RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_ZOMBIE_NOTE_SMALL,  RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SEEDS,              RenderLayer::RENDER_LAYER_FOG,      0, 2, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, false },
        { &IMAGE_MONEYBAG,           RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_SUNFLOWER_TROPHY,   RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_CHOCOLATE,          RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
        { &IMAGE_PRESENT,            RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0, true  },
    };
    static_assert(sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) == (int)CoinType::COIN_PRESENT_SURVIVAL_MODE + 1,
        "kCoinSizeRows 槽位须与 CoinType 枚举同步");

    if ((unsigned)mType < sizeof(kCoinSizeRows) / sizeof(kCoinSizeRows[0]) && kCoinSizeRows[(int)mType].mImage != nullptr)
    {
        const auto& aRow = kCoinSizeRows[(int)mType];
        mWidth = (*aRow.mImage)->GetCelWidth();
        mHeight = (*aRow.mImage)->GetCelHeight();
        if (aRow.mSetOrder)
        {
            mRenderOrder = Board::MakeRenderOrder(aRow.mLayer, aRow.mRow, aRow.mLayerOffset);
        }
    }

    // ===== 原礼物段（13c77bf3^ 五连 else-if 逐字·内容选择部分） =====
    if (mType == CoinType::COIN_PRESENT_PLANT || mType == CoinType::COIN_AWARD_PRESENT)
    {
        TOD_ASSERT(mBoard);

        if (mApp->IsSurvivalEndless(mApp->mGameMode) || mApp->IsEndlessIZombie(mApp->mGameMode) || mApp->IsEndlessScaryPotter(mApp->mGameMode))
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_1_DAY)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_PEASHOOTER,
                SeedType::SEED_SUNFLOWER,
                SeedType::SEED_CHERRYBOMB,
                SeedType::SEED_WALLNUT,
                SeedType::SEED_REPEATER,
                SeedType::SEED_POTATOMINE,
                SeedType::SEED_SNOWPEA,
                SeedType::SEED_CHOMPER
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_2_NIGHT)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_PUFFSHROOM,
                SeedType::SEED_SUNSHROOM,
                SeedType::SEED_FUMESHROOM,
                SeedType::SEED_GRAVEBUSTER,
                SeedType::SEED_HYPNOSHROOM,
                SeedType::SEED_SCAREDYSHROOM,
                SeedType::SEED_ICESHROOM,
                SeedType::SEED_DOOMSHROOM
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_3_POOL)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_LILYPAD,
                SeedType::SEED_SQUASH,
                SeedType::SEED_THREEPEATER,
                SeedType::SEED_TANGLEKELP,
                SeedType::SEED_JALAPENO,
                SeedType::SEED_SPIKEWEED,
                SeedType::SEED_TORCHWOOD,
                SeedType::SEED_TALLNUT
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_4_FOG)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_SEASHROOM,
                SeedType::SEED_PLANTERN,
                SeedType::SEED_CACTUS,
                SeedType::SEED_BLOVER,
                SeedType::SEED_SPLITPEA,
                SeedType::SEED_STARFRUIT,
                SeedType::SEED_PUMPKINSHELL,
                SeedType::SEED_MAGNETSHROOM
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else if (mBoard->mBackground == BackgroundType::BACKGROUND_5_ROOF)
        {
            SeedType aSeedList[] = {
                SeedType::SEED_CABBAGEPULT,
                SeedType::SEED_KERNELPULT,
                SeedType::SEED_INSTANT_COFFEE,
                SeedType::SEED_GARLIC,
                SeedType::SEED_UMBRELLA,
                SeedType::SEED_MELONPULT
            };

            SeedType aSeedType = TodPickFromArray(aSeedList, LENGTH(aSeedList));
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }
        else
        {
            SeedType aSeedType = mApp->mZenGarden->PickRandomSeedType();
            mPottedPlantSpec.InitializePottedPlant(aSeedType);
        }

    }

    const unsigned aMotionIndex = static_cast<unsigned>(mCoinMotion);
    if (aMotionIndex <= static_cast<unsigned>(CoinMotion::COIN_MOTION_FROM_BOSS))
    {
        kCoinInitCases[aMotionIndex](*this);
    }
    else
    {
        CoinInitDefault(*this);
    }


    float aScale;
    if (mType == CoinType::COIN_SMALLSUN)
    {
        aScale = 0.5f;
    }
    else if (mType == CoinType::COIN_LARGESUN)
    {
        aScale = 2.0f;
    }
    else
    {
        aScale = 1.0f;
    }
    mScale *= aScale;

    if (CoinGetsBouncyArrowStub(*this))
    {
        mNeedsBouncyArrow = true;
    }

    if (mCoinMotion != CoinMotion::COIN_MOTION_FROM_PRESENT)
    {
        PlayLaunchSoundStub(*this);
    }
}

// ============================ main ============================
static Coin g_coin;
static Board g_board;
static LawnApp g_app;
static ZenGarden g_zen;
static PlayerInfo g_pi;

static void ResetCoin(const R3Input& in)
{
    g_coin.mApp = &g_app;
    g_coin.mBoard = &g_board;
    g_app.mBoard = &g_board;
    g_app.mZenGarden = &g_zen;
    g_app.mPlayerInfo = &g_pi;
    g_board.mBackground = (BackgroundType)(in.d % 10);
    g_coin.mType = (CoinType)(in.a % 28);
    g_coin.mCoinMotion = (CoinMotion)(in.b % 7);
    g_coin.mDead = false;
    g_coin.mIsBeingCollected = false;
    g_coin.mScale = 1.0f;
}

int main()
{
    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetCoin(g_inputs[i]);
                g_coin.CoinInitialize_Amotion((int)(g_inputs[i].c % 700), (int)(g_inputs[i].d % 500), g_coin.mType, g_coin.mCoinMotion);
                g_coin.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetCoin(g_inputs[i]);
                g_coin.CoinInitialize_B((int)(g_inputs[i].c % 700), (int)(g_inputs[i].d % 500), g_coin.mType, g_coin.mCoinMotion);
                g_coin.HashFold(ck);
            }
        };
        rc |= R3BenchMain("b23_CoinInitialize_kCoinInitCases", reset, pa, pb);
    }
    {
        // 礼物路径定向输入：类型固定礼盒，背景均匀
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetCoin(g_inputs[i]);
                g_coin.mType = (i & 1) ? CoinType::COIN_PRESENT_PLANT : CoinType::COIN_AWARD_PRESENT;
                g_coin.mCoinMotion = CoinMotion::COIN_MOTION_FROM_PRESENT;
                g_coin.CoinInitialize_Apresent((int)(g_inputs[i].c % 700), (int)(g_inputs[i].d % 500), g_coin.mType, g_coin.mCoinMotion);
                g_coin.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetCoin(g_inputs[i]);
                g_coin.mType = (i & 1) ? CoinType::COIN_PRESENT_PLANT : CoinType::COIN_AWARD_PRESENT;
                g_coin.mCoinMotion = CoinMotion::COIN_MOTION_FROM_PRESENT;
                g_coin.CoinInitialize_B((int)(g_inputs[i].c % 700), (int)(g_inputs[i].d % 500), g_coin.mType, g_coin.mCoinMotion);
                g_coin.HashFold(ck);
            }
        };
        rc |= R3BenchMain("b24_PresentSeeds_kPresentSeeds6", reset, pa, pb);
    }
    return rc;
}
