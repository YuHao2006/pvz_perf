#include "ScaleEffectRuntime.h"
#include "../LogPath.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>

#pragma comment(lib, "d3d11.lib")

namespace Sexy
{

namespace
{

struct FormatNameMap
{
	const char*		mName;
	DXGI_FORMAT		mFormat;
};

const FormatNameMap kFormats[] =
{
	{ "R32G32B32A32_FLOAT", DXGI_FORMAT_R32G32B32A32_FLOAT },
	{ "R16G16B16A16_FLOAT", DXGI_FORMAT_R16G16B16A16_FLOAT },
	{ "R16G16B16A16_UNORM", DXGI_FORMAT_R16G16B16A16_UNORM },
	{ "R16G16B16A16_SNORM", DXGI_FORMAT_R16G16B16A16_SNORM },
	{ "R32G32_FLOAT", DXGI_FORMAT_R32G32_FLOAT },
	{ "R10G10B10A2_UNORM", DXGI_FORMAT_R10G10B10A2_UNORM },
	{ "R11G11B10_FLOAT", DXGI_FORMAT_R11G11B10_FLOAT },
	{ "R8G8B8A8_UNORM", DXGI_FORMAT_R8G8B8A8_UNORM },
	{ "R8G8B8A8_SNORM", DXGI_FORMAT_R8G8B8A8_SNORM },
	{ "R16G16_FLOAT", DXGI_FORMAT_R16G16_FLOAT },
	{ "R16G16_UNORM", DXGI_FORMAT_R16G16_UNORM },
	{ "R16G16_SNORM", DXGI_FORMAT_R16G16_SNORM },
	{ "R32_FLOAT", DXGI_FORMAT_R32_FLOAT },
	{ "R8G8_UNORM", DXGI_FORMAT_R8G8_UNORM },
	{ "R8G8_SNORM", DXGI_FORMAT_R8G8_SNORM },
	{ "R16_FLOAT", DXGI_FORMAT_R16_FLOAT },
	{ "R16_UNORM", DXGI_FORMAT_R16_UNORM },
	{ "R16_SNORM", DXGI_FORMAT_R16_SNORM },
	{ "R8_UNORM", DXGI_FORMAT_R8_UNORM },
	{ "R8_SNORM", DXGI_FORMAT_R8_SNORM },
};

DXGI_FORMAT FindFormat(const std::string& theName)
{
	for (const FormatNameMap& aInfo : kFormats)
		if (aInfo.mName == theName)
			return aInfo.mFormat;
	// An unknown format is a malformed effect, not permission to silently
	// substitute RGBA8 and report a successful pipeline.
	return DXGI_FORMAT_UNKNOWN;
}

const ScaleEffectTextureDesc* FindTexture(const ScaleEffectDesc& theEffect, const std::string& theName)
{
	for (const ScaleEffectTextureDesc& aTex : theEffect.mTextures)
		if (aTex.mName == theName)
			return &aTex;
	return nullptr;
}

// Tiny expression evaluator for MagpieFX WIDTH/HEIGHT expressions:
// identifiers INPUT_WIDTH/INPUT_HEIGHT/OUTPUT_WIDTH/OUTPUT_HEIGHT, integers,
// + - * / and parentheses.
class ExprParser
{
public:
	ExprParser(const std::string& theText, int inW, int inH, int outW, int outH)
		: mText(theText), mPos(0), mInW(inW), mInH(inH), mOutW(outW), mOutH(outH), mOk(true) {}

	int Parse()
	{
		int aValue = ParseAddSub();
		SkipSpace();
		if (mPos != mText.size())
			mOk = false;
		return mOk ? aValue : 1;
	}

	bool Ok() const { return mOk; }

private:
	void SkipSpace()
	{
		while (mPos < mText.size() && isspace((unsigned char)mText[mPos]))
			mPos++;
	}

	int ParseAddSub()
	{
		int aValue = ParseMulDiv();
		for (;;)
		{
			SkipSpace();
			if (mPos >= mText.size())
				break;
			char aOp = mText[mPos];
			if (aOp != '+' && aOp != '-')
				break;
			mPos++;
			int aRight = ParseMulDiv();
			aValue = aOp == '+' ? aValue + aRight : aValue - aRight;
		}
		return aValue;
	}

	int ParseMulDiv()
	{
		int aValue = ParsePrimary();
		for (;;)
		{
			SkipSpace();
			if (mPos >= mText.size())
				break;
			char aOp = mText[mPos];
			if (aOp != '*' && aOp != '/')
				break;
			mPos++;
			int aRight = ParsePrimary();
			if (aOp == '/' && aRight == 0)
			{
				mOk = false;
				return 1;
			}
			aValue = aOp == '*' ? aValue * aRight : aValue / aRight;
		}
		return aValue;
	}

	int ParsePrimary()
	{
		SkipSpace();
		if (mPos >= mText.size())
		{
			mOk = false;
			return 1;
		}

		if (mText[mPos] == '(')
		{
			mPos++;
			int aValue = ParseAddSub();
			SkipSpace();
			if (mPos < mText.size() && mText[mPos] == ')')
				mPos++;
			else
				mOk = false;
			return aValue;
		}

		if (isdigit((unsigned char)mText[mPos]))
		{
			int aValue = 0;
			while (mPos < mText.size() && isdigit((unsigned char)mText[mPos]))
			{
				aValue = aValue * 10 + (mText[mPos] - '0');
				mPos++;
			}
			return aValue;
		}

		// Identifier.
		size_t aStart = mPos;
		while (mPos < mText.size() && (isalnum((unsigned char)mText[mPos]) || mText[mPos] == '_'))
			mPos++;
		std::string aName = mText.substr(aStart, mPos - aStart);
		if (aName == "INPUT_WIDTH") return mInW;
		if (aName == "INPUT_HEIGHT") return mInH;
		if (aName == "OUTPUT_WIDTH") return mOutW;
		if (aName == "OUTPUT_HEIGHT") return mOutH;
		mOk = false;
		return 1;
	}

	const std::string&	mText;
	size_t				mPos;
	int					mInW;
	int					mInH;
	int					mOutW;
	int					mOutH;
	bool				mOk;
};

} // namespace

ScaleEffectRuntime::ScaleEffectRuntime()
	: mDevice(nullptr),
	mContext(nullptr),
	mOwnsDevice(true),
	mConstantBuffer(nullptr),
	mConstantBufferSize(0)
{
}

ScaleEffectRuntime::~ScaleEffectRuntime()
{
	DestroyDevice();
}

void ScaleEffectRuntime::DestroyDevice()
{
	if (mConstantBuffer != nullptr)
	{
		mConstantBuffer->Release();
		mConstantBuffer = nullptr;
	}
	for (auto& aPair : mEffectTextures)
	{
		if (aPair.second.mUAV != nullptr)
		{
			aPair.second.mUAV->Release();
			aPair.second.mUAV = nullptr;
		}
		if (aPair.second.mSRV != nullptr)
		{
			aPair.second.mSRV->Release();
			aPair.second.mSRV = nullptr;
		}
		aPair.second.mTexture->Release();
	}
	mEffectTextures.clear();
	for (auto& aPair : mSamplerMap)
		aPair.second->Release();
	mSamplerMap.clear();
	for (auto& aPair : mShaderMap)
		aPair.second->Release();
	mShaderMap.clear();
	if (mOwnsDevice && mContext != nullptr)
		mContext->Release();
	if (mOwnsDevice && mDevice != nullptr)
		mDevice->Release();
	mContext = nullptr;
	mDevice = nullptr;
	mOwnsDevice = true;
}

bool ScaleEffectRuntime::CreateDevice()
{
	if (mDevice != nullptr)
		return true;

	D3D_FEATURE_LEVEL aLevels[] =
	{
		D3D_FEATURE_LEVEL_11_0,
		D3D_FEATURE_LEVEL_10_1,
		D3D_FEATURE_LEVEL_10_0
	};
	D3D_FEATURE_LEVEL aCreatedLevel;
	HRESULT aResult = D3D11CreateDevice(
		nullptr,
		D3D_DRIVER_TYPE_HARDWARE,
		nullptr,
		D3D11_CREATE_DEVICE_BGRA_SUPPORT,
		aLevels,
		3,
		D3D11_SDK_VERSION,
		&mDevice,
		&aCreatedLevel,
		&mContext);
	if (FAILED(aResult))
		return false;
	return true;
}

bool ScaleEffectRuntime::CreateDevice(ID3D11Device* theDevice, ID3D11DeviceContext* theContext)
{
	if (theDevice == nullptr || theContext == nullptr)
		return false;
	if (mDevice == theDevice && mContext == theContext)
		return true;
	// A renderer rebuild can keep the same device pointer while replacing the
	// immediate context.  Cached shader/resource objects are device-owned, but
	// their bindings belong to the old context; clear the whole cache before
	// adopting the new pair.
	if (mDevice != nullptr || mContext != nullptr)
		DestroyDevice();
	mDevice = theDevice;
	mContext = theContext;
	mOwnsDevice = false;
	return true;
}

bool ScaleEffectRuntime::PreparePipelineObjects(const std::vector<ScaleEffectDesc*>& theEffects)
{
	if (mDevice == nullptr || mContext == nullptr || theEffects.empty())
		return false;

	for (const ScaleEffectDesc* anEffect : theEffects)
	{
		if (anEffect == nullptr || !anEffect->mCompiled ||
			anEffect->mPasses.empty() ||
			anEffect->mCompiledCSOs.size() != anEffect->mPasses.size())
			return false;

		for (const ScaleEffectSamplerDesc& aSampler : anEffect->mSamplers)
		{
			if (GetSampler(aSampler.mFilter, aSampler.mAddress) == nullptr)
				return false;
		}
		for (size_t i = 0; i < anEffect->mPasses.size(); ++i)
		{
			if (GetShader(*anEffect, i) == nullptr)
				return false;
		}
	}
	return true;
}

int ScaleEffectRuntime::EvalSizeExpr(
	const std::string& theExpr,
	int theInputW,
	int theInputH,
	int theOutputW,
	int theOutputH,
	bool& ok)
{
	ok = true;
	if (theExpr.empty())
	{
		ok = false;
		return 1;
	}
	ExprParser aParser(theExpr, theInputW, theInputH, theOutputW, theOutputH);
	int aValue = aParser.Parse();
	ok = aParser.Ok();
	return ok ? (std::max)(1, aValue) : 1;
}

ScaleEffectRuntime::TexEntry ScaleEffectRuntime::CreateTexture(int theWidth, int theHeight, DXGI_FORMAT theFormat)
{
	if (theWidth <= 0 || theHeight <= 0 || theFormat == DXGI_FORMAT_UNKNOWN)
		return TexEntry();

	D3D11_TEXTURE2D_DESC aDesc;
	ZeroMemory(&aDesc, sizeof(aDesc));
	aDesc.Width = theWidth;
	aDesc.Height = theHeight;
	aDesc.MipLevels = 1;
	aDesc.ArraySize = 1;
	aDesc.Format = theFormat;
	aDesc.SampleDesc.Count = 1;
	aDesc.Usage = D3D11_USAGE_DEFAULT;
	aDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_UNORDERED_ACCESS;

	ID3D11Texture2D* aTexture = nullptr;
	if (FAILED(mDevice->CreateTexture2D(&aDesc, nullptr, &aTexture)))
		return TexEntry();

	ID3D11ShaderResourceView* aSRV = nullptr;
	D3D11_SHADER_RESOURCE_VIEW_DESC aSRVDesc;
	ZeroMemory(&aSRVDesc, sizeof(aSRVDesc));
	aSRVDesc.Format = theFormat;
	aSRVDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	aSRVDesc.Texture2D.MipLevels = 1;
	if (FAILED(mDevice->CreateShaderResourceView(aTexture, &aSRVDesc, &aSRV)))
	{
		aTexture->Release();
		return TexEntry();
	}

	ID3D11UnorderedAccessView* aUAV = nullptr;
	D3D11_UNORDERED_ACCESS_VIEW_DESC aUAVDesc;
	ZeroMemory(&aUAVDesc, sizeof(aUAVDesc));
	aUAVDesc.Format = theFormat;
	aUAVDesc.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2D;
	if (FAILED(mDevice->CreateUnorderedAccessView(aTexture, &aUAVDesc, &aUAV)))
	{
		aSRV->Release();
		aTexture->Release();
		return TexEntry();
	}

	TexEntry anEntry;
	anEntry.mTexture = aTexture;
	anEntry.mSRV = aSRV;
	anEntry.mUAV = aUAV;
	return anEntry;
}

ID3D11SamplerState* ScaleEffectRuntime::GetSampler(const std::string& theFilter, const std::string& theAddress)
{
	std::string aKey = theFilter + "/" + theAddress;
	auto anItr = mSamplerMap.find(aKey);
	if (anItr != mSamplerMap.end())
		return anItr->second;

	D3D11_SAMPLER_DESC aDesc;
	ZeroMemory(&aDesc, sizeof(aDesc));
	aDesc.Filter = theFilter == "point" ? D3D11_FILTER_MIN_MAG_MIP_POINT : D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	aDesc.AddressU = theAddress == "wrap" ? D3D11_TEXTURE_ADDRESS_WRAP : D3D11_TEXTURE_ADDRESS_CLAMP;
	aDesc.AddressV = aDesc.AddressU;
	aDesc.AddressW = aDesc.AddressU;
	aDesc.MaxLOD = FLT_MAX;

	ID3D11SamplerState* aState = nullptr;
	if (FAILED(mDevice->CreateSamplerState(&aDesc, &aState)))
		return nullptr;
	mSamplerMap[aKey] = aState;
	return aState;
}

ID3D11ComputeShader* ScaleEffectRuntime::GetShader(const ScaleEffectDesc& theEffect, size_t thePassIndex)
{
	auto aKey = std::make_pair(&theEffect, thePassIndex);
	auto anItr = mShaderMap.find(aKey);
	if (anItr != mShaderMap.end())
		return anItr->second;

	ID3D11ComputeShader* aShader = nullptr;
	if (FAILED(mDevice->CreateComputeShader(
			theEffect.mCompiledCSOs[thePassIndex].data(),
			theEffect.mCompiledCSOs[thePassIndex].size(),
			nullptr,
			&aShader)))
		return nullptr;
	mShaderMap[aKey] = aShader;
	return aShader;
}

bool ScaleEffectRuntime::RunEffect(
	const ScaleEffectDesc& theEffect,
	size_t thePipelineInstance,
	size_t theEffectInstance,
	TexEntry* theInput,
	int theInputW,
	int theInputH,
	int theEffectOutputW,
	int theEffectOutputH,
	TexEntry** outEntry)
{
	*outEntry = nullptr;
	if (theInput == nullptr || theInput->mTexture == nullptr || theInput->mSRV == nullptr ||
		theInputW <= 0 || theInputH <= 0 || theEffectOutputW <= 0 || theEffectOutputH <= 0 ||
		theEffect.mPasses.empty())
		return false;

	// Pre-create samplers declared by this effect.
	std::vector<ID3D11SamplerState*> aEffectSamplers;
	for (const ScaleEffectSamplerDesc& aSam : theEffect.mSamplers)
	{
		ID3D11SamplerState* aState = GetSampler(aSam.mFilter, aSam.mAddress);
		if (aState == nullptr)
			return false;
		aEffectSamplers.push_back(aState);
	}

	// Map texture names to entries for this effect instance.
	std::map<std::string, TexEntry*> aEntries;
	aEntries["INPUT"] = theInput;
	for (const ScaleEffectTextureDesc& aTex : theEffect.mTextures)
	{
		if (aTex.mName == "INPUT")
			continue;
		DXGI_FORMAT aFormat = FindFormat(aTex.mFormat.empty() ? "R8G8B8A8_UNORM" : aTex.mFormat);
		if (aFormat == DXGI_FORMAT_UNKNOWN)
			return false;
		bool aWidthOk = aTex.mWidthExpr.empty();
		bool aHeightOk = aTex.mHeightExpr.empty();
		int aW = aTex.mWidthExpr.empty()
			? theEffectOutputW
			: EvalSizeExpr(aTex.mWidthExpr, theInputW, theInputH, theEffectOutputW, theEffectOutputH, aWidthOk);
		int aH = aTex.mHeightExpr.empty()
			? theEffectOutputH
			: EvalSizeExpr(aTex.mHeightExpr, theInputW, theInputH, theEffectOutputW, theEffectOutputH, aHeightOk);
		if (!aWidthOk || !aHeightOk || aW <= 0 || aH <= 0)
			return false;
		auto aKey = std::make_tuple(&theEffect, thePipelineInstance, theEffectInstance, aTex.mName);
		auto anItr = mEffectTextures.find(aKey);
		TexEntry* anEntry = nullptr;
		if (anItr != mEffectTextures.end())
		{
			D3D11_TEXTURE2D_DESC aDesc;
			anItr->second.mTexture->GetDesc(&aDesc);
			if (aDesc.Width == (UINT)aW && aDesc.Height == (UINT)aH && aDesc.Format == aFormat)
				anEntry = &anItr->second;
			else
			{
				if (anItr->second.mUAV != nullptr)
					anItr->second.mUAV->Release();
				if (anItr->second.mSRV != nullptr)
					anItr->second.mSRV->Release();
				anItr->second.mTexture->Release();
				mEffectTextures.erase(anItr);
			}
		}
		if (anEntry == nullptr)
		{
			TexEntry aNewEntry = CreateTexture(aW, aH, aFormat);
			if (aNewEntry.mTexture == nullptr)
				return false;
			auto aResult = mEffectTextures.insert(std::make_pair(aKey, aNewEntry));
			anEntry = &aResult.first->second;
		}
		aEntries[aTex.mName] = anEntry;
	}

	for (size_t i = 0; i < theEffect.mPasses.size(); i++)
	{
		const ScaleEffectPassDesc& aPass = theEffect.mPasses[i];
		if (aPass.mInputs.empty() || aPass.mOutputs.empty())
			return false;

		auto aFirstInputItr = aEntries.find(aPass.mInputs[0]);
		auto aFirstOutputItr = aEntries.find(aPass.mOutputs[0]);
		TexEntry* aFirstInput = aFirstInputItr != aEntries.end() ? aFirstInputItr->second : nullptr;
		TexEntry* aFirstOutput = aFirstOutputItr != aEntries.end() ? aFirstOutputItr->second : nullptr;
		if (aFirstInput == nullptr || aFirstOutput == nullptr)
			return false;

		// Per-pass sizes come from the pass's first input/output textures.
		D3D11_TEXTURE2D_DESC aInDesc;
		aFirstInput->mTexture->GetDesc(&aInDesc);
		D3D11_TEXTURE2D_DESC aOutDesc;
		aFirstOutput->mTexture->GetDesc(&aOutDesc);
		int aPassInputW = (int)aInDesc.Width;
		int aPassInputH = (int)aInDesc.Height;
		int aPassOutputW = (int)aOutDesc.Width;
		int aPassOutputH = (int)aOutDesc.Height;

		if (!UpdateConstantBuffer(theEffect, i, aPassInputW, aPassInputH, aPassOutputW, aPassOutputH))
			return false;

		mContext->CSSetConstantBuffers(0, 1, &mConstantBuffer);

		// Bind input SRVs.
		mSRVScratch.clear();
		std::vector<ID3D11ShaderResourceView*>& aSRVs = mSRVScratch;
		for (const std::string& aName : aPass.mInputs)
		{
			auto anItr = aEntries.find(aName);
			TexEntry* anEntry = anItr != aEntries.end() ? anItr->second : nullptr;
			if (anEntry == nullptr || anEntry->mSRV == nullptr)
				return false;
			aSRVs.push_back(anEntry->mSRV);
		}
		if (!aSRVs.empty())
			mContext->CSSetShaderResources(0, (UINT)aSRVs.size(), aSRVs.data());

		// Bind output UAVs.
		mUAVScratch.clear();
		std::vector<ID3D11UnorderedAccessView*>& aUAVs = mUAVScratch;
		for (const std::string& aName : aPass.mOutputs)
		{
			auto anItr = aEntries.find(aName);
			TexEntry* anEntry = anItr != aEntries.end() ? anItr->second : nullptr;
			if (anEntry == nullptr || anEntry->mUAV == nullptr)
				return false;
			for (ID3D11ShaderResourceView* anInputSRV : aSRVs)
			{
				if (anInputSRV == anEntry->mSRV)
					return false;
			}
			aUAVs.push_back(anEntry->mUAV);
		}
		if (!aUAVs.empty())
			mContext->CSSetUnorderedAccessViews(0, (UINT)aUAVs.size(), aUAVs.data(), nullptr);

		// Bind samplers in declaration order.
		if (!aEffectSamplers.empty())
			mContext->CSSetSamplers(0, (UINT)aEffectSamplers.size(), aEffectSamplers.data());

		ID3D11ComputeShader* aShader = GetShader(theEffect, i);
		if (aShader == nullptr)
			return false;
		mContext->CSSetShader(aShader, nullptr, 0);

		UINT aGroupsX;
		UINT aGroupsY;
		if (aPass.mPSStyle)
		{
			aGroupsX = (aPassOutputW + 7) / 8;
			aGroupsY = (aPassOutputH + 7) / 8;
		}
		else
		{
			if (aPass.mBlockWidth <= 0 || aPass.mBlockHeight <= 0)
				return false;
			aGroupsX = (aPassOutputW + aPass.mBlockWidth - 1) / aPass.mBlockWidth;
			aGroupsY = (aPassOutputH + aPass.mBlockHeight - 1) / aPass.mBlockHeight;
		}
		mContext->Dispatch(aGroupsX, aGroupsY, 1);

		mContext->CSSetShader(nullptr, nullptr, 0);

		// Unbind UAVs so the next pass can read them as SRVs.
		ID3D11UnorderedAccessView* aNullUAVs[8] = {};
		mContext->CSSetUnorderedAccessViews(0, 8, aNullUAVs, nullptr);
		if (!aSRVs.empty())
		{
			mNullSRVScratch.assign(aSRVs.size(), nullptr);
			mContext->CSSetShaderResources(0, (UINT)mNullSRVScratch.size(), mNullSRVScratch.data());
		}
	}

	auto anOutputItr = aEntries.find(theEffect.mPasses.back().mOutputs[0]);
	*outEntry = anOutputItr != aEntries.end() ? anOutputItr->second : nullptr;
	return *outEntry != nullptr;
}

bool ScaleEffectRuntime::UpdateConstantBuffer(
	const ScaleEffectDesc& theEffect,
	size_t thePassIndex,
	int theInputW,
	int theInputH,
	int theOutputW,
	int theOutputH)
{
	(void)thePassIndex;

	size_t aPsCount = 0;
	for (size_t i = 0; i + 1 < theEffect.mPasses.size(); i++)
		if (theEffect.mPasses[i].mPSStyle)
			aPsCount++;

	// Magpie InlineParams keeps user PARAMETER values out of __CB1.  Only
	// dimensions that can vary with the target remain runtime constants.
	if (!theEffect.mInlineParamsEnabled)
		return false;
	size_t aSize = 40 + aPsCount * 16;
	aSize = (aSize + 15) & ~(size_t)15;

	if (mConstantBuffer == nullptr || mConstantBufferSize < aSize)
	{
		if (mConstantBuffer != nullptr)
		{
			mConstantBuffer->Release();
			mConstantBuffer = nullptr;
		}
		D3D11_BUFFER_DESC aDesc;
		ZeroMemory(&aDesc, sizeof(aDesc));
		aDesc.ByteWidth = (UINT)aSize;
		aDesc.Usage = D3D11_USAGE_DEFAULT;
		aDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		if (FAILED(mDevice->CreateBuffer(&aDesc, nullptr, &mConstantBuffer)))
			return false;
		mConstantBufferSize = aSize;
	}

	mConstantData.assign(aSize, 0);
	std::vector<uint8_t>& aData = mConstantData;
	size_t aOffset = 0;
	auto Put32 = [&](uint32_t theValue)
	{
		if (aOffset + 4 <= aData.size())
		{
			aData[aOffset] = (uint8_t)(theValue & 0xFF);
			aData[aOffset + 1] = (uint8_t)((theValue >> 8) & 0xFF);
			aData[aOffset + 2] = (uint8_t)((theValue >> 16) & 0xFF);
			aData[aOffset + 3] = (uint8_t)((theValue >> 24) & 0xFF);
		}
		aOffset += 4;
	};
	auto PutFloat = [&](float theValue)
	{
		uint32_t aBits;
		memcpy(&aBits, &theValue, sizeof(aBits));
		Put32(aBits);
	};

	Put32((uint32_t)theInputW);
	Put32((uint32_t)theInputH);
	Put32((uint32_t)theOutputW);
	Put32((uint32_t)theOutputH);
	PutFloat(theInputW > 0 ? 1.0f / theInputW : 1.0f);
	PutFloat(theInputH > 0 ? 1.0f / theInputH : 1.0f);
	PutFloat(theOutputW > 0 ? 1.0f / theOutputW : 1.0f);
	PutFloat(theOutputH > 0 ? 1.0f / theOutputH : 1.0f);
	PutFloat(theInputW > 0 ? (float)theOutputW / theInputW : 1.0f);
	PutFloat(theInputH > 0 ? (float)theOutputH / theInputH : 1.0f);

	for (size_t i = 0; i + 1 < theEffect.mPasses.size(); i++)
	{
		if (!theEffect.mPasses[i].mPSStyle)
			continue;

		const ScaleEffectPassDesc& aPass = theEffect.mPasses[i];
		if (aPass.mOutputs.empty())
			return false;
		const ScaleEffectTextureDesc* aTex = FindTexture(theEffect, aPass.mOutputs[0]);
		if (aTex == nullptr)
			return false;
		bool aOk = false;
		int aPassW = aTex->mWidthExpr.empty()
			? theOutputW
			: EvalSizeExpr(aTex->mWidthExpr, theInputW, theInputH, theOutputW, theOutputH, aOk);
		int aPassH = aTex->mHeightExpr.empty()
			? theOutputH
			: EvalSizeExpr(aTex->mHeightExpr, theInputW, theInputH, theOutputW, theOutputH, aOk);
		Put32((uint32_t)aPassW);
		Put32((uint32_t)aPassH);
		PutFloat(aPassW > 0 ? 1.0f / aPassW : 1.0f);
		PutFloat(aPassH > 0 ? 1.0f / aPassH : 1.0f);
	}

	mContext->UpdateSubresource(mConstantBuffer, 0, nullptr, aData.data(), 0, 0);
	return true;
}

bool ScaleEffectRuntime::RunPipeline(
	const std::vector<ScaleEffectDesc*>& theEffects,
	const std::vector<ScaleEffectScaling>& theScalings,
	size_t thePipelineInstance,
	ID3D11Texture2D* theSource,
	const ScaleEffectRuntimeOptions& theOptions,
	ID3D11Texture2D** outTexture,
	ID3D11ShaderResourceView* theSourceSRV)
{
	if (outTexture == nullptr)
		return false;
	*outTexture = nullptr;
	if (theEffects.empty() || theSource == nullptr ||
		theOptions.mSrcWidth <= 0 || theOptions.mSrcHeight <= 0 ||
		theOptions.mTargetWidth <= 0 || theOptions.mTargetHeight <= 0)
		return false;
	if (!theScalings.empty() && theScalings.size() != theEffects.size())
		return false;
	if (!CreateDevice())
		return false;

	// Reuse the renderer-owned scene SRV when available.  The fallback creates
	// a temporary view for standalone/self-test callers.
	D3D11_TEXTURE2D_DESC aSourceDesc;
	theSource->GetDesc(&aSourceDesc);
	if ((int)aSourceDesc.Width != theOptions.mSrcWidth ||
		(int)aSourceDesc.Height != theOptions.mSrcHeight)
		return false;
	ID3D11ShaderResourceView* aSourceSRV = theSourceSRV;
	struct SourceSRVGuard
	{
		ID3D11ShaderResourceView* mView;
		bool mOwn;
		~SourceSRVGuard() { if (mOwn && mView != nullptr) mView->Release(); }
	} aSourceGuard = { aSourceSRV, false };
	if (aSourceSRV == nullptr)
	{
		D3D11_SHADER_RESOURCE_VIEW_DESC aSRVDesc;
		ZeroMemory(&aSRVDesc, sizeof(aSRVDesc));
		aSRVDesc.Format = aSourceDesc.Format;
		aSRVDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
		aSRVDesc.Texture2D.MipLevels = 1;
		if (FAILED(mDevice->CreateShaderResourceView(theSource, &aSRVDesc, &aSourceSRV)))
			return false;
		aSourceGuard.mView = aSourceSRV;
		aSourceGuard.mOwn = true;
	}

	TexEntry aSourceEntry;
	aSourceEntry.mTexture = theSource;
	aSourceEntry.mSRV = aSourceSRV;
	aSourceEntry.mUAV = nullptr;

	TexEntry* aCurrent = &aSourceEntry;
	int aCurrentW = theOptions.mSrcWidth;
	int aCurrentH = theOptions.mSrcHeight;

	bool aOk = true;
	for (size_t i = 0; i < theEffects.size() && aOk; i++)
	{
		if (theEffects[i] == nullptr)
			return false;
		const ScaleEffectDesc& aEffect = *theEffects[i];
		const ScaleEffectTextureDesc* aOutputTex = FindTexture(aEffect, "OUTPUT");
		int aEffectOutW;
		int aEffectOutH;
		if (aOutputTex != nullptr &&
			(!aOutputTex->mWidthExpr.empty() || !aOutputTex->mHeightExpr.empty()))
		{
			bool aWidthOk = false;
			bool aHeightOk = false;
			aEffectOutW = EvalSizeExpr(aOutputTex->mWidthExpr, aCurrentW, aCurrentH, theOptions.mTargetWidth, theOptions.mTargetHeight, aWidthOk);
			aEffectOutH = EvalSizeExpr(aOutputTex->mHeightExpr, aCurrentW, aCurrentH, theOptions.mTargetWidth, theOptions.mTargetHeight, aHeightOk);
			if (!aWidthOk || !aHeightOk)
				return false;
		}
		else if (i < theScalings.size() &&
			(theScalings[i].mScalingType != SCALE_SCALING_NORMAL ||
			 theScalings[i].mScaleX != 1.0f ||
			 theScalings[i].mScaleY != 1.0f))
		{
			// Magpie _CalcOutputSize for effects without an OUTPUT metadata
			// expr (the scaling type + scale drive the size).
			const ScaleEffectScaling& aScaling = theScalings[i];
			switch (aScaling.mScalingType)
			{
			case SCALE_SCALING_NORMAL: // 倍数
				aEffectOutW = ((int)((aCurrentW * aScaling.mScaleX) + 0.5f));
				aEffectOutH = ((int)((aCurrentH * aScaling.mScaleY) + 0.5f));
				break;
			case SCALE_SCALING_ABSOLUTE: // 绝对
				aEffectOutW = ((int)((aScaling.mScaleX) + 0.5f));
				aEffectOutH = ((int)((aScaling.mScaleY) + 0.5f));
				break;
			case SCALE_SCALING_FILL: // 充满
				aEffectOutW = theOptions.mTargetWidth;
				aEffectOutH = theOptions.mTargetHeight;
				break;
			case SCALE_SCALING_FIT: // 适应
			default:
			{
				const float aScaleW = (float)theOptions.mTargetWidth / (float)aCurrentW;
				const float aScaleH = (float)theOptions.mTargetHeight / (float)aCurrentH;
				const float aFillScale = aScaleW < aScaleH ? aScaleW : aScaleH;
				aEffectOutW = ((int)((aCurrentW * aFillScale * aScaling.mScaleX) + 0.5f));
				aEffectOutH = ((int)((aCurrentH * aFillScale * aScaling.mScaleY) + 0.5f));
				break;
			}
			}
		}
		else if (i + 1 == theEffects.size())
		{
			aEffectOutW = theOptions.mTargetWidth;
			aEffectOutH = theOptions.mTargetHeight;
		}
		else
		{
			aEffectOutW = aCurrentW;
			aEffectOutH = aCurrentH;
		}
		if (aEffectOutW <= 0 || aEffectOutH <= 0)
			return false;
		TexEntry* anOutput = nullptr;
		aOk = RunEffect(aEffect, thePipelineInstance, i, aCurrent, aCurrentW, aCurrentH, aEffectOutW, aEffectOutH, &anOutput);
		if (aOk)
		{
			aCurrent = anOutput;
			aCurrentW = aEffectOutW;
			aCurrentH = aEffectOutH;
		}
	}

	if (!aOk)
		return false;

	if (aCurrent == nullptr || aCurrent->mTexture == nullptr)
		return false;
	aCurrent->mTexture->AddRef();
	*outTexture = aCurrent->mTexture;
	return true;
}

bool ScaleEffectRuntime::RunSelfTest(
	const std::vector<ScaleEffectDesc*>& theEffects,
	size_t thePipelineInstance,
	int theTargetW,
	int theTargetH,
	const char* theOutFile,
	const std::vector<ScaleEffectScaling>& theScalings)
{
	auto aLog = [&](const char* theMessage)
	{
		FILE* aFile = fopen(GetLogFilePathC("scale-selftest.log"), "a");
		if (aFile != nullptr)
		{
			fprintf(aFile, "%s\n", theMessage);
			fclose(aFile);
		}
	};

	if (theEffects.empty())
		return false;
	if (!CreateDevice())
		return false;
	aLog("device-created");

	// 800x600 checkerboard source (each cell 64px, red/blue).
	const int kSrcW = 800;
	const int kSrcH = 600;
	std::vector<uint32_t> aPixels((size_t)kSrcW * kSrcH);
	for (int y = 0; y < kSrcH; y++)
	{
		for (int x = 0; x < kSrcW; x++)
		{
			bool aCell = ((x / 64) + (y / 64)) & 1;
			aPixels[(size_t)y * kSrcW + x] = aCell ? 0xFF0000FFu : 0xFFFF0000u; // BGRA
		}
	}

	D3D11_TEXTURE2D_DESC aDesc;
	ZeroMemory(&aDesc, sizeof(aDesc));
	aDesc.Width = kSrcW;
	aDesc.Height = kSrcH;
	aDesc.MipLevels = 1;
	aDesc.ArraySize = 1;
	aDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	aDesc.SampleDesc.Count = 1;
	aDesc.Usage = D3D11_USAGE_DEFAULT;
	aDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

	D3D11_SUBRESOURCE_DATA aData;
	ZeroMemory(&aData, sizeof(aData));
	aData.pSysMem = aPixels.data();
	aData.SysMemPitch = kSrcW * 4;

	ID3D11Texture2D* aSource = nullptr;
	if (FAILED(mDevice->CreateTexture2D(&aDesc, &aData, &aSource)))
		return false;
	aLog("source-created");

	ScaleEffectRuntimeOptions aOptions;
	aOptions.mSrcWidth = kSrcW;
	aOptions.mSrcHeight = kSrcH;
	aOptions.mTargetWidth = theTargetW;
	aOptions.mTargetHeight = theTargetH;
	aOptions.mFill = false;

	ID3D11Texture2D* aOutput = nullptr;
	bool aOk = RunPipeline(theEffects, theScalings, thePipelineInstance, aSource, aOptions, &aOutput);
	aSource->Release();
	if (!aOk || aOutput == nullptr)
		return false;
	aLog("pipeline-ok");

	// Copy to a staging texture and read back (test-only).
	D3D11_TEXTURE2D_DESC aOutDesc;
	aOutput->GetDesc(&aOutDesc);
	D3D11_TEXTURE2D_DESC aStagingDesc = aOutDesc;
	aStagingDesc.Usage = D3D11_USAGE_STAGING;
	aStagingDesc.BindFlags = 0;
	aStagingDesc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
	ID3D11Texture2D* aStaging = nullptr;
	if (FAILED(mDevice->CreateTexture2D(&aStagingDesc, nullptr, &aStaging)))
	{
		aOutput->Release();
		return false;
	}
	mContext->CopyResource(aStaging, aOutput);
	aOutput->Release();
	aLog("staging-copied");

	D3D11_MAPPED_SUBRESOURCE aMapped;
	if (FAILED(mContext->Map(aStaging, 0, D3D11_MAP_READ, 0, &aMapped)))
	{
		aStaging->Release();
		return false;
	}
	aLog("mapped");

	const int aW = (int)aOutDesc.Width;
	const int aH = (int)aOutDesc.Height;
	FILE* aBmp = fopen(theOutFile, "wb");
	bool aHasNonBlackPixel = false;
	if (aBmp != nullptr)
	{
		uint32_t aFileSize = 54 + (uint32_t)aW * aH * 4;
		uint8_t aHeader[54] = {};
		aHeader[0] = 'B';
		aHeader[1] = 'M';
		aHeader[2] = (uint8_t)(aFileSize & 0xFF);
		aHeader[3] = (uint8_t)((aFileSize >> 8) & 0xFF);
		aHeader[4] = (uint8_t)((aFileSize >> 16) & 0xFF);
		aHeader[5] = (uint8_t)((aFileSize >> 24) & 0xFF);
		aHeader[10] = 54;
		aHeader[14] = 40;
		aHeader[18] = (uint8_t)(aW & 0xFF);
		aHeader[19] = (uint8_t)((aW >> 8) & 0xFF);
		aHeader[20] = (uint8_t)((aW >> 16) & 0xFF);
		aHeader[21] = (uint8_t)((aW >> 24) & 0xFF);
		aHeader[22] = (uint8_t)(aH & 0xFF);
		aHeader[23] = (uint8_t)((aH >> 8) & 0xFF);
		aHeader[24] = (uint8_t)((aH >> 16) & 0xFF);
		aHeader[25] = (uint8_t)((aH >> 24) & 0xFF);
		aHeader[26] = 1;
		aHeader[28] = 32;
		fwrite(aHeader, 1, 54, aBmp);
		for (int y = aH - 1; y >= 0; y--)
		{
			const uint32_t* aRow = (const uint32_t*)((const uint8_t*)aMapped.pData + (size_t)y * aMapped.RowPitch);
			for (int x = 0; x < aW && !aHasNonBlackPixel; ++x)
				aHasNonBlackPixel = (aRow[x] & 0x00FFFFFFu) != 0;
			fwrite((const uint8_t*)aMapped.pData + (size_t)y * aMapped.RowPitch, 1, (size_t)aW * 4, aBmp);
		}
		fclose(aBmp);
	}

	mContext->Unmap(aStaging, 0);
	aStaging->Release();
	aLog("done");
	if (!aHasNonBlackPixel)
		aLog("output-all-black");
	return aBmp != nullptr && aHasNonBlackPixel;
}

} // namespace Sexy
