// bench_board.cpp -- 目标12 kZenToolToolTip(22)      Board::UpdateToolTip 禅境工具段（悬停，热）
//                   目标13 kNightGraves(6x6)+Pattern(50) Board::PickBackground 墓石段（装载，冷）
//                   目标14 kMusicBurst/DrumsStateLabels  Board::DrawDebugText 音乐标签段（调试，热）
//                   目标15 kCheatKeyActions(4)        Board::KeyChar 尾段（按键，冷）
// FormA = 36a066a7^ 逐字；FormB = HEAD 逐字。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// GameObjectType 摘录（0..21）
enum GameObjectType {
    OBJECT_TYPE_NONE = 0, OBJECT_TYPE_PLANT, OBJECT_TYPE_PROJECTILE, OBJECT_TYPE_COIN,
    OBJECT_TYPE_SEEDPACKET, OBJECT_TYPE_SHOVEL, OBJECT_TYPE_WATERING_CAN, OBJECT_TYPE_FERTILIZER,
    OBJECT_TYPE_BUG_SPRAY, OBJECT_TYPE_PHONOGRAPH, OBJECT_TYPE_CHOCOLATE, OBJECT_TYPE_GLOVE,
    OBJECT_TYPE_MONEY_SIGN, OBJECT_TYPE_WHEELBARROW, OBJECT_TYPE_TREE_FOOD, OBJECT_TYPE_NEXT_GARDEN,
    OBJECT_TYPE_MENU, OBJECT_TYPE_STORE, OBJECT_TYPE_SLOT_HANDLE, OBJECT_TYPE_SCARY_POT,
    OBJECT_TYPE_STINKY, OBJECT_TYPE_TREE_OF_WISDOM
};
struct Rect2 { int mX, mY, mW, mH; };

// 提示串 id
static uint64_t StrId(const char* s) { uint64_t h = 0; for (int i = 0; s[i] && i < 6; i++) h = h * 256 + (unsigned char)s[i]; return h; }

struct ToolTipStub {
    bool mVisible = false; bool mCenter = false; int mX = 0, mY = 0;
    uint64_t mLabel = 0;
    void SetLabel(const char* s) { mLabel = StrId(s); CS(70); CS(mLabel); }
};
static Rect2 g_shovelRect{ 5, 90, 80, 80 };
static Rect2 GetShovelButtonRect() { CS(71); return g_shovelRect; }
static void GetZenButtonRect(int type, Rect2& r) { CS(72); CS((uint64_t)type); r.mX = 5 + type * 90; }

struct HitResult { int mObjectType; int mObject; };
static void MouseHitTest(int x, int y, HitResult* r) { (void)x; (void)y; CS(73); }

// —— t12 两形态共用前缀状态 ——
struct TipBoardStub {
    ToolTipStub* mToolTip;
    HitResult mHitResult;
};

// ================= t12 FormA (36a066a7^) =================
namespace FormA {
__declspec(noinline) void UpdateToolTipZen(TipBoardStub& s, int aMouseX, int aMouseY)
{
    (void)aMouseX; (void)aMouseY;
    HitResult aHitResult = s.mHitResult;
    MouseHitTest(aMouseX, aMouseY, &aHitResult);

    if (aHitResult.mObjectType == OBJECT_TYPE_SHOVEL)
    {
        s.mToolTip->SetLabel("SHOVEL_TOOLTIP");
        Rect2 aShovelButtonRect = GetShovelButtonRect();
        s.mToolTip->mX = aShovelButtonRect.mX + 35;
        s.mToolTip->mY = aShovelButtonRect.mY + 72;
        s.mToolTip->mCenter = true;
        s.mToolTip->mVisible = true;
        return;
    }

    if (aHitResult.mObjectType == OBJECT_TYPE_NEXT_GARDEN)
    {
        s.mToolTip->SetLabel("NEXT_GARDEN_TOOLTIP");
        Rect2 aButtonRect = GetShovelButtonRect();
        s.mToolTip->mX = 599;
        s.mToolTip->mY = aButtonRect.mY + 52;
        s.mToolTip->mCenter = true;
        s.mToolTip->mVisible = true;
        return;
    }

    if (aHitResult.mObjectType == OBJECT_TYPE_WATERING_CAN ||
        aHitResult.mObjectType == OBJECT_TYPE_FERTILIZER ||
        aHitResult.mObjectType == OBJECT_TYPE_BUG_SPRAY ||
        aHitResult.mObjectType == OBJECT_TYPE_PHONOGRAPH ||
        aHitResult.mObjectType == OBJECT_TYPE_CHOCOLATE ||
        aHitResult.mObjectType == OBJECT_TYPE_GLOVE ||
        aHitResult.mObjectType == OBJECT_TYPE_MONEY_SIGN ||
        aHitResult.mObjectType == OBJECT_TYPE_WHEELBARROW ||
        aHitResult.mObjectType == OBJECT_TYPE_TREE_FOOD)
    {
        if (aHitResult.mObjectType == OBJECT_TYPE_WATERING_CAN)
        {
            s.mToolTip->SetLabel("WATERING_CAN_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_FERTILIZER)
        {
            s.mToolTip->SetLabel("FERTILIZER_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_BUG_SPRAY)
        {
            s.mToolTip->SetLabel("BUG_SPRAY_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_PHONOGRAPH)
        {
            s.mToolTip->SetLabel("PHONOGRAPH_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_CHOCOLATE)
        {
            s.mToolTip->SetLabel("CHOCOLATE_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_GLOVE)
        {
            s.mToolTip->SetLabel("GLOVE_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_MONEY_SIGN)
        {
            s.mToolTip->SetLabel("MONEY_SIGN_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_WHEELBARROW)
        {
            s.mToolTip->SetLabel("WHEELBARROW_TOOLTIP");
        }
        else if (aHitResult.mObjectType == OBJECT_TYPE_TREE_FOOD)
        {
            s.mToolTip->SetLabel("TREE_FERTILIZER_TOOLTIP");
        }

        Rect2 aButtonRect = GetShovelButtonRect();
        GetZenButtonRect(aHitResult.mObjectType, aButtonRect);
        s.mToolTip->mX = aButtonRect.mX + 35;
        s.mToolTip->mY = aButtonRect.mY + 72;
        s.mToolTip->mCenter = true;
        s.mToolTip->mVisible = true;
        return;
    }

    if (aHitResult.mObjectType != OBJECT_TYPE_SEEDPACKET)
    {
        s.mToolTip->mVisible = false;
        return;
    }
    CS(74); // 种子包后续段桩
}
} // namespace FormA

// ================= t12 FormB (HEAD) =================
namespace FormB {
namespace {
constexpr const char* kZenToolToolTip[OBJECT_TYPE_TREE_OF_WISDOM + 1] = {
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
    "WATERING_CAN_TOOLTIP",
    "FERTILIZER_TOOLTIP",
    "BUG_SPRAY_TOOLTIP",
    "PHONOGRAPH_TOOLTIP",
    "CHOCOLATE_TOOLTIP",
    "GLOVE_TOOLTIP",
    "MONEY_SIGN_TOOLTIP",
    "WHEELBARROW_TOOLTIP",
    "TREE_FERTILIZER_TOOLTIP",
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
};
} // namespace

__declspec(noinline) void UpdateToolTipZen(TipBoardStub& s, int aMouseX, int aMouseY)
{
    (void)aMouseX; (void)aMouseY;
    HitResult aHitResult = s.mHitResult;
    MouseHitTest(aMouseX, aMouseY, &aHitResult);

    if (aHitResult.mObjectType == OBJECT_TYPE_SHOVEL)
    {
        s.mToolTip->SetLabel("SHOVEL_TOOLTIP");
        Rect2 aShovelButtonRect = GetShovelButtonRect();
        s.mToolTip->mX = aShovelButtonRect.mX + 35;
        s.mToolTip->mY = aShovelButtonRect.mY + 72;
        s.mToolTip->mCenter = true;
        s.mToolTip->mVisible = true;
        return;
    }

    if (aHitResult.mObjectType == OBJECT_TYPE_NEXT_GARDEN)
    {
        s.mToolTip->SetLabel("NEXT_GARDEN_TOOLTIP");
        Rect2 aButtonRect = GetShovelButtonRect();
        s.mToolTip->mX = 599;
        s.mToolTip->mY = aButtonRect.mY + 52;
        s.mToolTip->mCenter = true;
        s.mToolTip->mVisible = true;
        return;
    }

    // B 形态 -> 常量表 kZenToolToolTip：GameObjectType 直下标，一次查表合并
    const char* aZenToolToolTip = nullptr;
    if ((unsigned)aHitResult.mObjectType < (unsigned)(sizeof(kZenToolToolTip) / sizeof(kZenToolToolTip[0])))
    {
        aZenToolToolTip = kZenToolToolTip[aHitResult.mObjectType];
    }
    if (aZenToolToolTip != nullptr)
    {
        s.mToolTip->SetLabel(aZenToolToolTip);

        Rect2 aButtonRect = GetShovelButtonRect();
        GetZenButtonRect(aHitResult.mObjectType, aButtonRect);
        s.mToolTip->mX = aButtonRect.mX + 35;
        s.mToolTip->mY = aButtonRect.mY + 72;
        s.mToolTip->mCenter = true;
        s.mToolTip->mVisible = true;
        return;
    }

    if (aHitResult.mObjectType != OBJECT_TYPE_SEEDPACKET)
    {
        s.mToolTip->mVisible = false;
        return;
    }
    CS(74);
}
} // namespace FormB

// ---------------- t13 PickBackground 墓石段 ----------------
enum BackgroundTypeB { BG_DAY = 0, BG_NIGHT, BG_POOL, BG_FOG, BG_ROOF, BG_BOSS };
struct MTRandStub { int mSeed; int Next() { mSeed = mSeed * 1103515245 + 12345; return (mSeed >> 16) & 0x7FFF; } };
static int RandRangeInt(int lo, int hi, MTRandStub& rng) { int r = lo + rng.Next() % (hi - lo + 1); CS(80); CS((uint64_t)r); return r; }
static void AddGraveStones(int column, int count, MTRandStub& rng) { (void)rng; CS(81); CS((uint64_t)column); CS((uint64_t)count); }
static void PickSpecialGraveStone() { CS(82); }
static void WhackAZombiePlaceGraves(int n) { CS(83); CS((uint64_t)n); }

struct PickBgBoardStub {
    BackgroundTypeB mBackground;
    int mLevel;
    bool mHasGraves;      // StageHasGraveStones()
    bool mGraveDanger;    // GAMEMODE_CHALLENGE_GRAVE_DANGER
    bool mWhackAZombie;
    bool mSurvivalNormal;
    bool mAdventure;
};
struct PickBgAppStub {
    bool mGraveDangerMode;
    bool mWhackAZombieMode;
    bool mSurvivalNormalMode;
    bool mAdventureMode;
};

namespace FormA {
__declspec(noinline) void PickBackgroundGraves(PickBgBoardStub& m, PickBgAppStub& app, MTRandStub& aLevelRNG)
{
    if (m.mHasGraves)
    {
        if (app.mGraveDangerMode)
        {
            AddGraveStones(6, RandRangeInt(1, 2, aLevelRNG), aLevelRNG);
            AddGraveStones(7, RandRangeInt(1, 3, aLevelRNG), aLevelRNG);
            AddGraveStones(8, RandRangeInt(2, 3, aLevelRNG), aLevelRNG);
        }
        else if (m.mWhackAZombie)
        {
            WhackAZombiePlaceGraves(9);
        }
        else if (m.mBackground == BG_NIGHT)
        {
            if (m.mSurvivalNormal)
            {
                AddGraveStones(5, 1, aLevelRNG);
                AddGraveStones(6, 1, aLevelRNG);
                AddGraveStones(7, 1, aLevelRNG);
                AddGraveStones(8, 2, aLevelRNG);
            }
            else if (!m.mAdventure)
            {
                AddGraveStones(4, 1, aLevelRNG);
                AddGraveStones(5, 1, aLevelRNG);
                AddGraveStones(6, 2, aLevelRNG);
                AddGraveStones(7, 2, aLevelRNG);
                AddGraveStones(8, 3, aLevelRNG);
            }
            else if (m.mLevel == 11 || m.mLevel == 12 || m.mLevel == 13)
            {
                AddGraveStones(6, 1, aLevelRNG);
                AddGraveStones(7, 1, aLevelRNG);
                AddGraveStones(8, 2, aLevelRNG);
            }
            else if (m.mLevel == 14 || m.mLevel == 16)
            {
                AddGraveStones(5, 1, aLevelRNG);
                AddGraveStones(6, 1, aLevelRNG);
                AddGraveStones(7, 2, aLevelRNG);
                AddGraveStones(8, 3, aLevelRNG);
            }
            else if (m.mLevel == 17 || m.mLevel == 18 || m.mLevel == 19)
            {
                AddGraveStones(4, 1, aLevelRNG);
                AddGraveStones(5, 2, aLevelRNG);
                AddGraveStones(6, 2, aLevelRNG);
                AddGraveStones(7, 3, aLevelRNG);
                AddGraveStones(8, 3, aLevelRNG);
            }
            else if (m.mLevel >= 20)
            {
                AddGraveStones(3, 1, aLevelRNG);
                AddGraveStones(4, 2, aLevelRNG);
                AddGraveStones(5, 2, aLevelRNG);
                AddGraveStones(6, 2, aLevelRNG);
                AddGraveStones(7, 3, aLevelRNG);
                AddGraveStones(8, 3, aLevelRNG);
            }
        }
    }
    PickSpecialGraveStone();
}
} // namespace FormA

namespace FormB {
namespace {
constexpr int kNightGravesPerColumn[6][6] = {
    { 0, 0, 1, 1, 1, 2 },
    { 0, 1, 1, 2, 2, 3 },
    { 0, 0, 0, 1, 1, 2 },
    { 0, 0, 1, 1, 2, 3 },
    { 0, 1, 2, 2, 3, 3 },
    { 1, 2, 2, 2, 3, 3 },
};
constexpr int FINAL_LEVEL = 50;
constexpr int kNightGravePatternNone = -1;
constexpr int kNightGravePatternPerLevel[FINAL_LEVEL] = {
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    2, 2, 2,
    3,
    -1,
    3,
    4, 4, 4,
    5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
};
} // namespace

__declspec(noinline) void PickBackgroundGraves(PickBgBoardStub& m, PickBgAppStub& app, MTRandStub& aLevelRNG)
{
    if (m.mHasGraves)
    {
        if (app.mGraveDangerMode)
        {
            AddGraveStones(6, RandRangeInt(1, 2, aLevelRNG), aLevelRNG);
            AddGraveStones(7, RandRangeInt(1, 3, aLevelRNG), aLevelRNG);
            AddGraveStones(8, RandRangeInt(2, 3, aLevelRNG), aLevelRNG);
        }
        else if (m.mWhackAZombie)
        {
            WhackAZombiePlaceGraves(9);
        }
        else if (m.mBackground == BG_NIGHT)
        {
            // B 形态 -> 常量表（kNightGravesPerColumn / kNightGravePatternPerLevel）
            int aGravePattern = kNightGravePatternNone;
            if (m.mSurvivalNormal)
            {
                aGravePattern = 0;
            }
            else if (!m.mAdventure)
            {
                aGravePattern = 1;
            }
            else
            {
                int aLevelIndex = m.mLevel - 1;
                if ((unsigned)aLevelIndex < (unsigned)(sizeof(kNightGravePatternPerLevel) / sizeof(kNightGravePatternPerLevel[0])))
                {
                    aGravePattern = kNightGravePatternPerLevel[aLevelIndex];
                }
            }
            if (aGravePattern != kNightGravePatternNone)
            {
                for (int aColumn = 3; aColumn <= 8; aColumn++)
                {
                    int aCount = kNightGravesPerColumn[aGravePattern][aColumn - 3];
                    if (aCount > 0)
                    {
                        AddGraveStones(aColumn, aCount, aLevelRNG);
                    }
                }
            }
        }
    }
    PickSpecialGraveStone();
}
} // namespace FormB

// ---------------- t14 DrawDebugText 音乐标签段 ----------------
enum MusicBurstState { MUSIC_BURST_OFF = 0, MUSIC_BURST_STARTING, MUSIC_BURST_ON, MUSIC_BURST_FINISHING };
enum MusicDrumsState { MUSIC_DRUMS_OFF = 0, MUSIC_DRUMS_ON_QUEUED, MUSIC_DRUMS_ON, MUSIC_DRUMS_OFF_QUEUED, MUSIC_DRUMS_FADING };
struct MusicStub {
    int mMusicBurstState;
    int mMusicDrumsState;
    int mBurstStateCounter, mDrumsStateCounter;
};
static void AppendFmt(const char* s, int a = 0, int b = 0)
{
    CS(90); CS(StrId(s)); CS((uint64_t)(int64_t)a); CS((uint64_t)(int64_t)b);
}
static void AppendStr(const char* s) { CS(91); CS(StrId(s)); }

namespace FormA {
__declspec(noinline) void DrawDebugTextMusic(MusicStub& m)
{
    AppendStr("MUSIC DEBUG");
    if (m.mMusicBurstState == MUSIC_BURST_OFF)
        AppendFmt("Off");
    else if (m.mMusicBurstState == MUSIC_BURST_STARTING)
        AppendFmt("Starting %d/%d", m.mBurstStateCounter, 400);
    else if (m.mMusicBurstState == MUSIC_BURST_ON)
        AppendFmt("On at least until %d/%d", m.mBurstStateCounter, 800);
    else if (m.mMusicBurstState == MUSIC_BURST_FINISHING)
        AppendFmt("Finishing %d/%d", m.mBurstStateCounter, 400);

    if (m.mMusicDrumsState == MUSIC_DRUMS_OFF)
        AppendFmt(", Drums off");
    else if (m.mMusicDrumsState == MUSIC_DRUMS_ON_QUEUED)
        AppendFmt(", Drums queued on");
    else if (m.mMusicDrumsState == MUSIC_DRUMS_ON)
        AppendFmt(", Drums on");
    else if (m.mMusicDrumsState == MUSIC_DRUMS_OFF_QUEUED)
        AppendFmt(", Drums queued off");
    else if (m.mMusicDrumsState == MUSIC_DRUMS_FADING)
        AppendFmt(", Drums fading off %d/%d", m.mDrumsStateCounter, 50);
    AppendStr("\n");
}
} // namespace FormA

namespace FormB {
namespace {
using MusicStateLabelFn = void (*)(MusicStub&);
constexpr MusicStateLabelFn kMusicBurstStateLabels[MUSIC_BURST_FINISHING + 1] = {
    [](MusicStub&) { AppendFmt("Off"); },
    [](MusicStub& m) { AppendFmt("Starting %d/%d", m.mBurstStateCounter, 400); },
    [](MusicStub& m) { AppendFmt("On at least until %d/%d", m.mBurstStateCounter, 800); },
    [](MusicStub& m) { AppendFmt("Finishing %d/%d", m.mBurstStateCounter, 400); },
};
constexpr MusicStateLabelFn kMusicDrumsStateLabels[MUSIC_DRUMS_FADING + 1] = {
    [](MusicStub&) { AppendFmt(", Drums off"); },
    [](MusicStub&) { AppendFmt(", Drums queued on"); },
    [](MusicStub&) { AppendFmt(", Drums on"); },
    [](MusicStub&) { AppendFmt(", Drums queued off"); },
    [](MusicStub& m) { AppendFmt(", Drums fading off %d/%d", m.mDrumsStateCounter, 50); },
};
} // namespace

__declspec(noinline) void DrawDebugTextMusic(MusicStub& m)
{
    AppendStr("MUSIC DEBUG");
    // C 形态 -> 函数指针表（kMusicBurstStateLabels / kMusicDrumsStateLabels）
    int aBurstState = m.mMusicBurstState;
    if ((unsigned)aBurstState < (unsigned)(sizeof(kMusicBurstStateLabels) / sizeof(kMusicBurstStateLabels[0])))
    {
        kMusicBurstStateLabels[aBurstState](m);
    }

    int aDrumsState = m.mMusicDrumsState;
    if ((unsigned)aDrumsState < (unsigned)(sizeof(kMusicDrumsStateLabels) / sizeof(kMusicDrumsStateLabels[0])))
    {
        kMusicDrumsStateLabels[aDrumsState](m);
    }
    AppendStr("\n");
}
} // namespace FormB

// ---------------- t15 KeyChar 尾段 ----------------
enum DebugTextMode2 { DEBUG_TEXT_NONE = 0, DEBUG_TEXT_ZOMBIE_SPAWN, DEBUG_TEXT_MUSIC, DEBUG_TEXT_MEMORY, DEBUG_TEXT_COLLISION };
struct KeyBoardStub {
    bool mEasyPlantingCheat;
    int mDebugTextMode;
    void* mApp;
};
static void ToggleSlowMo() { CS(95); }
static void ToggleFastMo() { CS(96); }

namespace FormA {
__declspec(noinline) void KeyCharTail(KeyBoardStub& m, char theChar)
{
    if (theChar == ('8'))
    {
        m.mEasyPlantingCheat = !m.mEasyPlantingCheat;
    }
    else if (theChar == ('7'))
    {
        ToggleSlowMo();
    }
    else if (theChar == ('6'))
    {
        ToggleFastMo();
    }
    else if (theChar == ('z'))
    {
        m.mDebugTextMode = (int)(m.mDebugTextMode + 1);
        if (m.mDebugTextMode > DEBUG_TEXT_COLLISION)
        {
            m.mDebugTextMode = DEBUG_TEXT_NONE;
        }
    }
    CS(97); // 尾段公共桩（boss 战按键等表外段未入测）
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void KeyCharTail(KeyBoardStub& m, char theChar)
{
    // C 形态 -> 函数指针配对表 kCheatKeyActions（原 4 支纯 char->动作支）
    using CheatKeyFn = void (*)(KeyBoardStub&);
    static constexpr struct { char mChar; CheatKeyFn mAction; } kCheatKeyActions[] = {
        { '8', [](KeyBoardStub& b) { b.mEasyPlantingCheat = !b.mEasyPlantingCheat; } },
        { '7', [](KeyBoardStub&) { ToggleSlowMo(); } },
        { '6', [](KeyBoardStub&) { ToggleFastMo(); } },
        { 'z', [](KeyBoardStub& b)
            {
                b.mDebugTextMode = (int)(b.mDebugTextMode + 1);
                if (b.mDebugTextMode > DEBUG_TEXT_COLLISION)
                {
                    b.mDebugTextMode = DEBUG_TEXT_NONE;
                }
            } },
    };
    for (const auto& aKeyRow : kCheatKeyActions)
    {
        if (aKeyRow.mChar == theChar)
        {
            aKeyRow.mAction(m);
            break;
        }
    }
    CS(97);
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];

static ToolTipStub g_tip;
static TipBoardStub g_tipBoard;
static PickBgBoardStub g_pbb;
static PickBgAppStub g_pba;
static MusicStub g_music;
static KeyBoardStub g_keyb;

typedef void (*TipFn)(TipBoardStub&, int, int);
typedef void (*BgFn)(PickBgBoardStub&, PickBgAppStub&, MTRandStub&);
typedef void (*MusFn)(MusicStub&);
typedef void (*KeyFn)(KeyBoardStub&, char);

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    LCG rng{ 0x452821E638D01377ULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();

    // t12
    {
        g_tipBoard.mToolTip = &g_tip;
        auto prep = [](uint32_t v) { g_tipBoard.mHitResult.mObjectType = (int)((v >> 2) % 23); };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::UpdateToolTipZen(g_tipBoard, 100, 100); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::UpdateToolTipZen(g_tipBoard, 100, 100); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t12 kZenToolToolTip(22) Board::UpdateToolTip zen", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t13
    {
        MTRandStub rng2{ 12345 };
        auto prep = [&](uint32_t v, MTRandStub& r) {
            bool adventure = ((v >> 0) & 1) != 0;
            g_pbb.mHasGraves = ((v >> 1) & 1) != 0;
            g_pba.mGraveDangerMode = ((v >> 2) & 1) != 0;
            g_pbb.mWhackAZombie = ((v >> 3) & 1) != 0;
            g_pbb.mBackground = (BackgroundTypeB)((v >> 4) & 1); // DAY/NIGHT
            g_pbb.mSurvivalNormal = ((v >> 5) & 1) != 0 && !adventure;
            g_pbb.mAdventure = adventure;
            g_pbb.mLevel = adventure ? (int)((v >> 6) % 50) + 1 : 0;
            r.mSeed = (int)v | 1;
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; MTRandStub r; for (int i = 0; i < N; i++) { prep(g_in[i], r); FormA::PickBackgroundGraves(g_pbb, g_pba, r); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; MTRandStub r; for (int i = 0; i < N; i++) { prep(g_in[i], r); FormB::PickBackgroundGraves(g_pbb, g_pba, r); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t13 kNightGravesPerColumn+PatternPerLevel PickBackground", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t14
    {
        auto prep = [](uint32_t v) {
            g_music.mMusicBurstState = (int)((v >> 2) % 6); // 4..5 越界回落
            g_music.mMusicDrumsState = (int)((v >> 5) % 7); // 5..6 越界回落
            g_music.mBurstStateCounter = (int)((v >> 8) & 255);
            g_music.mDrumsStateCounter = (int)((v >> 16) & 255);
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::DrawDebugTextMusic(g_music); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::DrawDebugTextMusic(g_music); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t14 kMusicBurst/DrumsStateLabels DrawDebugText music", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t15
    {
        static const char keys[8] = { '8', '7', '6', 'z', 'n', 'b', 'u', '8' };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { g_keyb.mEasyPlantingCheat = ((g_in[i] >> 1) & 1) != 0; g_keyb.mDebugTextMode = (int)((g_in[i] >> 2) % 5); FormA::KeyCharTail(g_keyb, keys[g_in[i] % 8]); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { g_keyb.mEasyPlantingCheat = ((g_in[i] >> 1) & 1) != 0; g_keyb.mDebugTextMode = (int)((g_in[i] >> 2) % 5); FormB::KeyCharTail(g_keyb, keys[g_in[i] % 8]); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t15 kCheatKeyActions(4) Board::KeyChar tail", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
