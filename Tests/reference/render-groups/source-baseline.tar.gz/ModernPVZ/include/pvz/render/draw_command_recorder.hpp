#pragma once

#include "pvz/render/backend.hpp"

#include <array>
#include <cstdint>
#include <span>
#include <vector>

namespace pvz::render {

struct TextureRegion {
    TextureHandle texture;
    Extent2D texture_extent;
    Rect2D source_pixels;
};

class DrawCommandRecorder {
public:
    DrawCommandRecorder(
        std::uint64_t frame_index,
        Extent2D logical_extent,
        Rect2D pixel_viewport,
        double interpolation_alpha = 0.0);

    [[nodiscard]] Rect2D full_scissor() const noexcept;

    void fill_rect(
        Rect2D destination,
        std::uint32_t rgba,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {});

    void draw_sprite(
        const TextureRegion& source,
        Rect2D destination,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        SamplingState sampling = {},
        bool mirror_x = false,
        bool mirror_y = false);

    void draw_sprite_quad(
        const TextureRegion& source,
        const std::array<Point2D, 4>& positions,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        SamplingState sampling = {},
        bool mirror_x = false,
        bool mirror_y = false);

    void draw_triangle_list(
        TextureHandle texture,
        std::span<const Vertex2D> vertices,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        SamplingState sampling = {});

    [[nodiscard]] FramePacket frame() const noexcept;
    [[nodiscard]] const std::vector<Vertex2D>& vertices() const noexcept;
    [[nodiscard]] const std::vector<std::uint32_t>& indices() const noexcept;
    [[nodiscard]] const std::vector<DrawBatch>& batches() const noexcept;

private:
    [[nodiscard]] Rect2D normalized_scissor(Rect2D logical_scissor) const;
    void append_batch(
        TextureHandle texture,
        BlendMode blend_mode,
        Rect2D logical_scissor,
        SamplingState sampling,
        std::uint32_t first_index,
        std::uint32_t index_count);

    std::uint64_t frame_index_{0};
    Extent2D logical_extent_;
    Rect2D pixel_viewport_;
    double interpolation_alpha_{0.0};
    std::vector<Vertex2D> vertices_;
    std::vector<std::uint32_t> indices_;
    std::vector<DrawBatch> batches_;
};

} // namespace pvz::render
