#include "pvz/assets/image_dimensions.hpp"

#include <algorithm>
#include <array>
#include <cstddef>

namespace pvz::assets {
namespace {

[[nodiscard]] std::uint16_t read_big_u16(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) noexcept
{
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(bytes[offset]) << 8) |
        static_cast<std::uint16_t>(bytes[offset + 1]));
}

[[nodiscard]] std::uint32_t read_big_u32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) noexcept
{
    return (static_cast<std::uint32_t>(bytes[offset]) << 24) |
           (static_cast<std::uint32_t>(bytes[offset + 1]) << 16) |
           (static_cast<std::uint32_t>(bytes[offset + 2]) << 8) |
           static_cast<std::uint32_t>(bytes[offset + 3]);
}

[[nodiscard]] bool is_jpeg_start_of_frame(const std::uint8_t marker) noexcept
{
    switch (marker) {
    case 0xC0:
    case 0xC1:
    case 0xC2:
    case 0xC3:
    case 0xC5:
    case 0xC6:
    case 0xC7:
    case 0xC9:
    case 0xCA:
    case 0xCB:
    case 0xCD:
    case 0xCE:
    case 0xCF:
        return true;
    default:
        return false;
    }
}

[[nodiscard]] std::optional<ImageDimensions> inspect_jpeg(
    const std::span<const std::uint8_t> bytes) noexcept
{
    std::size_t offset = 2;
    while (offset + 1 < bytes.size()) {
        if (bytes[offset] != 0xFF) {
            ++offset;
            continue;
        }

        while (offset < bytes.size() && bytes[offset] == 0xFF)
            ++offset;
        if (offset >= bytes.size())
            return std::nullopt;

        const auto marker = bytes[offset++];
        if (marker == 0xD9 || marker == 0xDA)
            return std::nullopt;
        if (marker == 0x01 || (marker >= 0xD0 && marker <= 0xD8))
            continue;
        if (offset + 1 >= bytes.size())
            return std::nullopt;

        const auto segment_length = read_big_u16(bytes, offset);
        if (segment_length < 2 || offset + segment_length > bytes.size())
            return std::nullopt;

        if (is_jpeg_start_of_frame(marker)) {
            if (segment_length < 7)
                return std::nullopt;
            const auto height = read_big_u16(bytes, offset + 3);
            const auto width = read_big_u16(bytes, offset + 5);
            if (width == 0 || height == 0)
                return std::nullopt;
            return ImageDimensions{width, height, ImageFormat::jpeg};
        }

        offset += segment_length;
    }
    return std::nullopt;
}

} // namespace

std::optional<ImageDimensions> inspect_image_dimensions(
    const std::span<const std::uint8_t> bytes) noexcept
{
    constexpr std::array<std::uint8_t, 8> png_signature{0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
    if (bytes.size() >= 24 && std::equal(png_signature.begin(), png_signature.end(), bytes.begin())) {
        const auto width = read_big_u32(bytes, 16);
        const auto height = read_big_u32(bytes, 20);
        if (width != 0 && height != 0)
            return ImageDimensions{width, height, ImageFormat::png};
    }

    if (bytes.size() >= 10 &&
        bytes[0] == 'G' && bytes[1] == 'I' && bytes[2] == 'F' &&
        bytes[3] == '8' && (bytes[4] == '7' || bytes[4] == '9') && bytes[5] == 'a') {
        const auto width = static_cast<std::uint16_t>(bytes[6] | (bytes[7] << 8));
        const auto height = static_cast<std::uint16_t>(bytes[8] | (bytes[9] << 8));
        if (width != 0 && height != 0)
            return ImageDimensions{width, height, ImageFormat::gif};
    }

    if (bytes.size() >= 4 && bytes[0] == 0xFF && bytes[1] == 0xD8)
        return inspect_jpeg(bytes);

    return std::nullopt;
}

std::string_view image_format_name(const ImageFormat format) noexcept
{
    switch (format) {
    case ImageFormat::png:
        return "png";
    case ImageFormat::jpeg:
        return "jpeg";
    case ImageFormat::gif:
        return "gif";
    }
    return "unknown";
}

} // namespace pvz::assets
