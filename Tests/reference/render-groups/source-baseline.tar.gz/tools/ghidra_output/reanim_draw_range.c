/* 00477550 FUN_00477550 */

/* WARNING: Function: __alloca_probe replaced with injection: alloca_probe */

void __thiscall FUN_00477550(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  int local_3c20;
  int local_3c1c;
  undefined1 local_3c18 [15372];
  undefined4 uStack_c;
  
  uStack_c = 0x477560;
  if (*(char *)(param_1 + 0x14) == '\0') {
    FUN_00448dd0();
    local_3c1c = 0;
    if (0 < *(int *)(*(int *)(param_1 + 0xc) + 4)) {
      local_3c20 = 0;
      do {
        iVar3 = *(int *)(param_1 + 0x58) + local_3c20;
        if (*(int *)(iVar3 + 0x48) == param_3) {
          cVar2 = FUN_004769b0(param_1,param_2,local_3c1c,local_3c18);
          if (*(int *)(iVar3 + 0x40) != 0) {
            FUN_00448e10(param_2);
            uVar1 = *(uint *)(iVar3 + 0x40);
            if (uVar1 != 0) {
              if (((uVar1 & 0xffff) < (uint)(*(int **)(DAT_00729668 + 0xc))[2]) &&
                 (*(uint *)((uVar1 & 0xffff) * 0x30c + **(int **)(DAT_00729668 + 0xc) + 0x308) ==
                  uVar1)) {
                FUN_00405980(param_2,cVar2 == '\0');
              }
            }
          }
        }
        local_3c20 = local_3c20 + 0x60;
        local_3c1c = local_3c1c + 1;
      } while (local_3c1c < *(int *)(*(int *)(param_1 + 0xc) + 4));
    }
    FUN_00448e10(param_2);
  }
  return;
}



/* 00477640 FUN_00477640 */

int FUN_00477640(char *param_1)

{
  int *piVar1;
  int iVar2;
  int unaff_EBX;
  int iVar3;
  int iVar4;
  
  piVar1 = *(int **)(unaff_EBX + 0xc);
  iVar3 = 0;
  if (0 < piVar1[1]) {
    iVar4 = 0;
    do {
      iVar2 = __stricmp(*(char **)(*piVar1 + iVar4),param_1);
      if (iVar2 == 0) {
        return iVar3;
      }
      piVar1 = *(int **)(unaff_EBX + 0xc);
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 0xc;
    } while (iVar3 < piVar1[1]);
  }
  return 0;
}



/* 00477690 FUN_00477690 */

void __fastcall FUN_00477690(undefined4 param_1,undefined4 param_2)

{
  int in_EAX;
  int unaff_ESI;
  
  if (*(int *)(*(int *)(in_EAX + 0xc) + 4) != 0) {
    if (*(int *)(in_EAX + 0x20) == -1) {
      *(undefined4 *)(in_EAX + 0x20) = *(undefined4 *)(in_EAX + 0x18);
    }
    FUN_00477640(param_2);
    FUN_004061a0(2,*(undefined4 *)(unaff_ESI + 0x9c),0,0);
    *(undefined1 *)(unaff_ESI + 100) = 1;
  }
  return;
}



/* 004776e0 FUN_004776e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_004776e0(int param_1)

{
  if (*(int *)(param_1 + 0x20) == -2) {
    FUN_005f0ab0();
    return;
  }
  FUN_00476610();
  FUN_004766e0();
  return;
}



/* 00477770 FUN_00477770 */

undefined4 FUN_00477770(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 in_EAX;
  undefined4 uVar1;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  
  uVar1 = FUN_00477640(in_EAX);
  FUN_005f0cf0();
  FUN_004776e0(uVar1);
  local_3c = param_2;
  local_38 = param_3;
  FUN_005f0bd0(&local_34,&local_3c);
  if (param_1 == 0) {
    return 0;
  }
  uVar1 = FUN_004061a0(0,*(undefined4 *)(param_1 + 0x28),local_34,local_30);
  *(undefined1 *)(param_1 + 0x1d) = 1;
  return uVar1;
}



/* 00477810 FUN_00477810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00477810(undefined4 param_1)

{
  undefined4 in_EAX;
  undefined4 uVar1;
  undefined4 local_98;
  undefined4 local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined4 local_88;
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined1 *local_70;
  undefined1 local_6c [72];
  undefined1 local_24 [36];
  
  local_98 = _DAT_006e3318;
  local_94 = _DAT_006e3318;
  local_90 = _DAT_006e3318;
  local_8c = _DAT_006e3318;
  local_88 = _DAT_006e3318;
  local_84 = _DAT_006e3318;
  local_74 = 0;
  local_80 = _DAT_006e3318;
  local_78 = 0;
  local_7c = _DAT_006e3318;
  local_70 = &DAT_006e346c;
  FUN_00476580(param_1);
  FUN_005f0cf0();
  FUN_004766e0();
  FUN_0051d1b0(local_6c);
  FUN_005f0cf0();
  FUN_004776e0(in_EAX);
  FUN_005f0cf0();
  FUN_0051d080(local_24);
  uVar1 = FUN_005f0b10(&local_98,local_24);
  FUN_005f0d10(uVar1);
  return;
}



/* 004778f0 FUN_004778f0 */

void __fastcall FUN_004778f0(undefined4 param_1,undefined4 param_2,int *param_3,int *param_4)

{
  float fVar1;
  int in_EAX;
  int iVar2;
  int iVar3;
  int iVar4;
  float *pfVar5;
  
  if (*(int *)(*(int *)(in_EAX + 0xc) + 4) == 0) {
    *param_3 = 0;
    *param_4 = 0;
    return;
  }
  iVar2 = FUN_00477640(param_2);
  iVar2 = **(int **)(in_EAX + 0xc) + iVar2 * 0xc;
  *param_3 = 0;
  *param_4 = 1;
  iVar3 = 0;
  if (0 < *(int *)(iVar2 + 8)) {
    pfVar5 = (float *)(*(int *)(iVar2 + 4) + 0x18);
    do {
      fVar1 = *pfVar5;
      if (!NAN(fVar1) && 0.0 < fVar1 != (fVar1 == 0.0)) {
        *param_3 = iVar3;
        break;
      }
      iVar3 = iVar3 + 1;
      pfVar5 = pfVar5 + 0xb;
    } while (iVar3 < *(int *)(iVar2 + 8));
  }
  if (iVar3 < *(int *)(iVar2 + 8)) {
    iVar4 = iVar3 * 0x2c;
    do {
      fVar1 = *(float *)(*(int *)(iVar2 + 4) + 0x18 + iVar4);
      if (!NAN(fVar1) && 0.0 < fVar1 != (fVar1 == 0.0)) {
        *param_4 = (iVar3 - *param_3) + 1;
      }
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 0x2c;
    } while (iVar3 < *(int *)(iVar2 + 8));
  }
  return;
}



/* 004779a0 FUN_004779a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_004779a0(int param_1)

{
  float fVar1;
  undefined4 uVar2;
  
  fVar1 = *(float *)(param_1 + 8);
  uVar2 = 0;
  if (NAN(fVar1) || 0.0 < fVar1 == (fVar1 == 0.0)) {
    uVar2 = _DAT_006fdce0;
  }
  *(undefined4 *)(param_1 + 4) = uVar2;
  *(undefined4 *)(param_1 + 0x94) = _DAT_006fdb88;
  FUN_004778f0(param_1 + 0x18,param_1 + 0x1c);
  return;
}



/* 004779e0 FUN_004779e0 */

undefined4 FUN_004779e0(char *param_1)

{
  int *piVar1;
  int iVar2;
  int unaff_EBX;
  int iVar3;
  int iVar4;
  
  piVar1 = *(int **)(unaff_EBX + 0xc);
  iVar3 = 0;
  if (0 < piVar1[1]) {
    iVar4 = 0;
    do {
      iVar2 = __stricmp(*(char **)(*piVar1 + iVar4),param_1);
      if (iVar2 == 0) {
        return 1;
      }
      piVar1 = *(int **)(unaff_EBX + 0xc);
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 0xc;
    } while (iVar3 < piVar1[1]);
  }
  return 0;
}



/* 00477a30 FUN_00477a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00477a30(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  float *pfVar5;
  float *pfVar6;
  float local_2c [4];
  float local_1c;
  float local_18;
  float local_14;
  float local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined1 *local_4;
  
  iVar1 = param_1;
  iVar4 = 0;
  if (0 < *(int *)(*(int *)(param_1 + 0xc) + 4)) {
    param_1 = 0;
    do {
      local_2c[0] = _DAT_006e3318;
      local_2c[1] = _DAT_006e3318;
      local_8 = 0;
      local_2c[2] = _DAT_006e3318;
      local_c = 0;
      local_2c[3] = _DAT_006e3318;
      local_4 = &DAT_006e346c;
      local_1c = _DAT_006e3318;
      local_18 = _DAT_006e3318;
      local_14 = _DAT_006e3318;
      local_10 = _DAT_006e3318;
      FUN_00476580(iVar1);
      iVar2 = FUN_006ba960();
      if (-1 < iVar2) {
        puVar3 = (undefined4 *)(*(int *)(iVar1 + 0x58) + param_1);
        pfVar5 = local_2c;
        pfVar6 = (float *)(puVar3 + 2);
        for (iVar2 = 0xb; iVar2 != 0; iVar2 = iVar2 + -1) {
          *pfVar6 = *pfVar5;
          pfVar5 = pfVar5 + 1;
          pfVar6 = pfVar6 + 1;
        }
        *puVar3 = param_2;
        puVar3[1] = param_2;
        puVar3[0xb] = 0;
        puVar3[0xc] = &DAT_006e346c;
        puVar3[10] = 0;
      }
      param_1 = param_1 + 0x60;
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(*(int *)(iVar1 + 0xc) + 4));
  }
  return;
}



/* 00477b10 FUN_00477b10 */

void __fastcall FUN_00477b10(int param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  if (*(char *)(param_1 + 0x14) == '\0') {
    iVar4 = 0;
    *(undefined1 *)(param_1 + 0x14) = 1;
    if (0 < *(int *)(*(int *)(param_1 + 0xc) + 4)) {
      iVar5 = 0;
      do {
        puVar1 = (uint *)(*(int *)(param_1 + 0x58) + 0x40 + iVar5);
        uVar2 = *puVar1;
        if (uVar2 != 0) {
          if ((uVar2 & 0xffff) < (uint)(*(int **)(DAT_00729668 + 0xc))[2]) {
            uVar3 = (uVar2 & 0xffff) * 0x30c + **(int **)(DAT_00729668 + 0xc);
            uVar3 = (*(uint *)(uVar3 + 0x308) != uVar2) - 1 & uVar3;
          }
          else {
            uVar3 = 0;
          }
          *puVar1 = 0;
          if (uVar3 != 0) {
            FUN_00405c30();
          }
        }
        iVar4 = iVar4 + 1;
        iVar5 = iVar5 + 0x60;
      } while (iVar4 < *(int *)(*(int *)(param_1 + 0xc) + 4));
    }
  }
  return;
}



/* 00477b90 FUN_00477b90 */

undefined4 __fastcall FUN_00477b90(int param_1)

{
  undefined4 in_EAX;
  int iVar1;
  
  iVar1 = FUN_00477640(in_EAX);
  return *(undefined4 *)(iVar1 * 0x60 + 0x44 + *(int *)(param_1 + 0x58));
}



/* 00477bb0 FUN_00477bb0 */

void __thiscall FUN_00477bb0(int param_1,undefined4 param_2)

{
  undefined4 in_EAX;
  int iVar1;
  
  iVar1 = FUN_00477640(in_EAX);
  *(undefined4 *)(iVar1 * 0x60 + 0x44 + *(int *)(param_1 + 0x58)) = param_2;
  return;
}



/* 00477bd0 FUN_00477bd0 */

void __fastcall FUN_00477bd0(int param_1)

{
  int in_EAX;
  int iVar1;
  int iVar2;
  
  if (in_EAX == 0) {
    iVar1 = 0;
    if (0 < *(int *)(*(int *)(param_1 + 0xc) + 4)) {
      iVar2 = 0;
      do {
        *(undefined1 *)(iVar2 + 0x5d + *(int *)(param_1 + 0x58)) = 0;
        iVar1 = iVar1 + 1;
        iVar2 = iVar2 + 0x60;
      } while (iVar1 < *(int *)(*(int *)(param_1 + 0xc) + 4));
      return;
    }
  }
  else {
    iVar1 = FUN_00477640(in_EAX);
    *(undefined1 *)(iVar1 * 0x60 + 0x5d + *(int *)(param_1 + 0x58)) = 0;
  }
  return;
}



/* 00477c20 FUN_00477c20 */

void FUN_00477c20(int *param_1)

{
  void *pvStack_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  puStack_8 = &LAB_006bd8a8;
  pvStack_c = ExceptionList;
  local_4 = 0;
  ExceptionList = &pvStack_c;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_c;
    FUN_004496d0();
    FUN_0069a21b(*param_1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[6] = 0;
  }
  local_4 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_004496d0();
    FUN_0069a21b(*param_1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[6] = 0;
  }
  ExceptionList = pvStack_c;
  return;
}



/* 00477cb0 FUN_00477cb0 */

undefined4 * FUN_00477cb0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 in_EAX;
  undefined4 *puVar1;
  undefined4 unaff_EBX;
  
  puVar1 = (undefined4 *)FUN_00478df0();
  puVar1[0x18] = in_EAX;
  puVar1[0x1a] = param_3;
  FUN_00477d00();
  *puVar1 = unaff_EBX;
  FUN_00476100(puVar1,param_1,param_2);
  return puVar1;
}



/* 00477d00 FUN_00477d00 */

/* WARNING: Removing unreachable block (ram,0x00477e05) */

void FUN_00477d00(int param_1,char param_2)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  HWND hWnd;
  int iVar4;
  int *piVar5;
  char acStack_418 [1028];
  void *local_14;
  undefined1 *puStack_10;
  undefined4 uStack_c;
  
  uStack_c = 0xffffffff;
  puStack_10 = &LAB_006ca390;
  local_14 = ExceptionList;
  piVar5 = (int *)(param_1 * 0x10 + DAT_00729698);
  if (*piVar5 == 0) {
    iVar4 = DAT_007296a0 + param_1 * 0xc;
    if (param_2 == '\0') {
      ExceptionList = &local_14;
      (*(code *)PTR_FUN_0071d9f0)();
    }
    else {
      if (*(char *)(DAT_007296fc + 0x365) != '\0') {
        return;
      }
      ExceptionList = &local_14;
      cVar2 = (*(code *)PTR_FUN_0071d9ec)();
      if (cVar2 != '\0') {
        ExceptionList = local_14;
        return;
      }
    }
    FUN_005f6c20();
    FUN_005f6cb0();
    FUN_005256f0("Load Reanim \'%s\'",*(undefined4 *)(iVar4 + 4));
    uStack_c = 0;
    pcVar1 = *(char **)(iVar4 + 4);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    uStack_c = CONCAT31(uStack_c._1_3_,1);
    cVar2 = FUN_00475be0(piVar5);
    if (cVar2 == '\0') {
      _sprintf(acStack_418,"Failed to load reanim \'%s\'",*(undefined4 *)(iVar4 + 4));
      if ((DAT_007296fc == 0) || (hWnd = *(HWND *)(DAT_007296fc + 0x374), hWnd == (HWND)0x0)) {
        hWnd = GetActiveWindow();
      }
      MessageBoxA(hWnd,acStack_418,"Error",0x30);
    }
    FUN_005f6d00();
    iVar4 = FUN_006ba960();
    if (0 < iVar4) {
      FUN_005f6d00();
    }
  }
  ExceptionList = local_14;
  return;
}



/* 00477e90 FUN_00477e90 */

/* WARNING: Removing unreachable block (ram,0x00477f79) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00477e90(void)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined **ppuVar7;
  void *pvStack_c;
  undefined1 *puStack_8;
  uint local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006ca450;
  pvStack_c = ExceptionList;
  ExceptionList = &pvStack_c;
  FUN_005256f0("ReanimatorLoadDefinitions");
  local_4 = 0;
  DAT_0072969c = 0x90;
  DAT_007296a0 = &DAT_00720a80;
  DAT_00729694 = 0x90;
  DAT_00729698 = FUN_00688c17(0x900);
  uVar3 = _DAT_006fdb98;
  if (DAT_00729698 == 0) {
    DAT_00729698 = 0;
  }
  else {
    iVar6 = 0x8f;
    puVar5 = (undefined4 *)(DAT_00729698 + 4);
    do {
      puVar5[1] = uVar3;
      puVar5[-1] = 0;
      *puVar5 = 0;
      puVar5[2] = 0;
      puVar5 = puVar5 + 4;
      iVar6 = iVar6 + -1;
    } while (-1 < iVar6);
  }
  iVar6 = 0;
  if (0 < DAT_0072969c) {
    ppuVar7 = &PTR_s_reanim_LoadBar_sprout_reanim_00720a84;
    do {
      pcVar2 = *ppuVar7;
      pcVar4 = pcVar2;
      do {
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      FUN_004020c0(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
      local_4 = local_4 & 0xffffff00;
      iVar6 = iVar6 + 1;
      ppuVar7 = ppuVar7 + 3;
    } while (iVar6 < DAT_0072969c);
  }
  ExceptionList = pvStack_c;
  return;
}



/* 00477fb0 FUN_00477fb0 */

void FUN_00477fb0(void)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < DAT_00729694) {
    do {
      FUN_00475dc0();
      iVar1 = iVar1 + 1;
    } while (iVar1 < DAT_00729694);
  }
  FUN_0069a21b(DAT_00729698);
  DAT_00729698 = 0;
  DAT_00729694 = 0;
  DAT_007296a0 = 0;
  DAT_0072969c = 0;
  return;
}



/* 00478010 FUN_00478010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00478010(void)

{
  int in_EAX;
  int iVar1;
  int local_8;
  int local_4;
  
  FUN_004773e0();
  iVar1 = FUN_00477640("_ground");
  iVar1 = *(int *)(**(int **)(in_EAX + 0xc) + iVar1 * 0xc + 4);
  return (float10)((*(float *)(local_4 * 0x2c + iVar1) - *(float *)(local_8 * 0x2c + iVar1)) *
                   (float)_DAT_006fdcd8 * *(float *)(in_EAX + 8));
}



/* 00478070 FUN_00478070 */

int FUN_00478070(void)

{
  float fVar1;
  int in_EAX;
  int iVar2;
  uint3 uVar3;
  int local_4;
  
  FUN_004773e0();
  iVar2 = FUN_00477640("anim_wheelie2");
  fVar1 = *(float *)(*(int *)(**(int **)(in_EAX + 0xc) + 4 + iVar2 * 0xc) + 0x18 + local_4 * 0x2c);
  uVar3 = (uint3)(CONCAT22((short)((uint)**(int **)(in_EAX + 0xc) >> 0x10),
                           (ushort)(0.0 < fVar1) << 8 | (ushort)NAN(fVar1) << 10 |
                           (ushort)(fVar1 == 0.0) << 0xe) >> 8);
  if (!NAN(fVar1) && 0.0 < fVar1 != (fVar1 == 0.0)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* 004780c0 FUN_004780c0 */

void FUN_004780c0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  piVar2 = *(int **)(param_1 + 0xc);
  iVar5 = 0;
  if (0 < piVar2[1]) {
    iVar4 = 0;
    iVar6 = 0;
    do {
      iVar1 = *(int *)(param_1 + 0x58);
      iVar3 = __stricmp(*(char **)(*piVar2 + iVar6),"anim_glow");
      *(uint *)(iVar1 + iVar4 + 0x48) = -(uint)(iVar3 != 0);
      piVar2 = *(int **)(param_1 + 0xc);
      iVar5 = iVar5 + 1;
      iVar6 = iVar6 + 0xc;
      iVar4 = iVar4 + 0x60;
    } while (iVar5 < piVar2[1]);
  }
  return;
}



/* 00478120 FUN_00478120 */

void FUN_00478120(char *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int unaff_EBX;
  int iVar3;
  int iVar4;
  
  piVar1 = *(int **)(unaff_EBX + 0xc);
  iVar3 = 0;
  if (0 < piVar1[1]) {
    iVar4 = 0;
    while( true ) {
      iVar2 = __stricmp(*(char **)(*piVar1 + iVar4),param_1);
      if (iVar2 == 0) break;
      piVar1 = *(int **)(unaff_EBX + 0xc);
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 0xc;
      if (piVar1[1] <= iVar3) {
        return;
      }
    }
    *(undefined4 *)(iVar3 * 0x60 + 0x48 + *(int *)(unaff_EBX + 0x58)) = param_2;
  }
  return;
}



/* 00478170 FUN_00478170 */

void FUN_00478170(int param_1,char *param_2,undefined4 param_3)

{
  char cVar1;
  char *_Str1;
  char *pcVar2;
  int *piVar3;
  char *pcVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  pcVar2 = param_2;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  piVar3 = *(int **)(param_1 + 0xc);
  iVar8 = 0;
  if (0 < piVar3[1]) {
    iVar7 = 0;
    iVar6 = 0;
    do {
      _Str1 = *(char **)(*piVar3 + iVar6);
      pcVar4 = _Str1;
      do {
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      if (((uint)((int)pcVar2 - (int)(param_2 + 1)) <= (uint)((int)pcVar4 - (int)(_Str1 + 1))) &&
         (iVar5 = __strnicmp(_Str1,param_2,(int)pcVar2 - (int)(param_2 + 1)), iVar5 == 0)) {
        *(undefined4 *)(*(int *)(param_1 + 0x58) + 0x48 + iVar7) = param_3;
      }
      piVar3 = *(int **)(param_1 + 0xc);
      iVar8 = iVar8 + 1;
      iVar6 = iVar6 + 0xc;
      iVar7 = iVar7 + 0x60;
    } while (iVar8 < piVar3[1]);
  }
  return;
}



/* 00478200 FUN_00478200 */

void __fastcall FUN_00478200(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = 0;
  if (0 < *(int *)(*(int *)(param_1 + 0xc) + 4)) {
    iVar3 = 0;
    do {
      uVar1 = *(uint *)(*(int *)(param_1 + 0x58) + 0x40 + iVar3);
      if (uVar1 != 0) {
        if (((uVar1 & 0xffff) < (uint)(*(int **)(DAT_00729668 + 0xc))[2]) &&
           (*(uint *)((uVar1 & 0xffff) * 0x30c + **(int **)(DAT_00729668 + 0xc) + 0x308) == uVar1))
        {
          FUN_00405510(param_1 + 0x48,*(undefined1 *)(param_1 + 0x7c),param_1 + 0x6c,
                       *(undefined1 *)(param_1 + 0x90),param_1 + 0x80);
        }
      }
      iVar2 = iVar2 + 1;
      iVar3 = iVar3 + 0x60;
    } while (iVar2 < *(int *)(*(int *)(param_1 + 0xc) + 4));
  }
  return;
}



