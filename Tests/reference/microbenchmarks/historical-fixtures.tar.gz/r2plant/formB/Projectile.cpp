#include "Board.h"
#include "Plant.h"
#include "Zombie.h"
#include "Cutscene.h"
#include "Projectile.h"
#include "../LawnApp.h"
#include "../Resources.h"
#include "../GameConstants.h"
#include "../Sexy.TodLib/TodFoley.h"
#include "../Sexy.TodLib/TodDebug.h"
#include "../Sexy.TodLib/Reanimator.h"
#include "../Sexy.TodLib/Attachment.h"
#include "Widget/AchievementsWidget.h"

ProjectileDefinition gProjectileDefinition[] = {  //0x69F1C0
	{ ProjectileType::PROJECTILE_PEA,           0,  20  },
	{ ProjectileType::PROJECTILE_SNOWPEA,       0,  20  },
	{ ProjectileType::PROJECTILE_CABBAGE,       0,  40  },
	{ ProjectileType::PROJECTILE_MELON,         0,  80  },
	{ ProjectileType::PROJECTILE_PUFF,          0,  20  },
	{ ProjectileType::PROJECTILE_WINTERMELON,   0,  80  },
	{ ProjectileType::PROJECTILE_FIREBALL,      0,  40  },
	{ ProjectileType::PROJECTILE_STAR,          0,  20  },
	{ ProjectileType::PROJECTILE_SPIKE,         0,  20  },
	{ ProjectileType::PROJECTILE_BASKETBALL,    0,  75  },
	{ ProjectileType::PROJECTILE_KERNEL,        0,  20  },
	{ ProjectileType::PROJECTILE_COBBIG,        0,  300 },
	{ ProjectileType::PROJECTILE_BUTTER,        0,  40  },
	{ ProjectileType::PROJECTILE_ZOMBIE_PEA,    0,  20  }
};

Projectile::Projectile()
{
}

Projectile::~Projectile()
{
	AttachmentDie(mAttachmentID);
}

//0x46C730
void Projectile::ProjectileInitialize(int theX, int theY, int theRenderOrder, int theRow, ProjectileType theProjectileType)
{
	int aGridX = mBoard->PixelToGridXKeepOnBoard(theX, theY);
	mProjectileType = theProjectileType;
	mPosX = theX;
	mPosY = theY;
	mPosZ = 0.0f;
	mVelX = 0.0f;
	mVelY = 0.0f;
	mVelZ = 0.0f;
	mAccZ = 0.0f;
	mShadowY = mBoard->GridToPixelY(aGridX, theRow) + 67.0f;
	mHitTorchwoodGridX = -1;
	mMotionType = ProjectileMotion::MOTION_STRAIGHT;
	mFrame = 0;
	mNumFrames = 1;
	mRow = theRow;
	mCobTargetX = 0.0f;
	mDamageRangeFlags = 0;
	mDead = false;
	mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
	mCobTargetRow = 0;
	mTargetZombieID = ZombieID::ZOMBIEID_NULL;
	mOnHighGround = mBoard->mGridSquareType[aGridX][theRow] == GridSquareType::GRIDSQUARE_HIGH_GROUND;
	// GOTY 1.2.0.1073 only raises the projectile shadow on the left roof slope.
	if (mBoard->StageHasRoof() && theX < 480)
	{
		mShadowY -= 12.0f;
	}
	mRenderOrder = theRenderOrder;
	mRotation = 0.0f;
	mRotationSpeed = 0.0f;
	mWidth = 40;
	mHeight = 40;
	mProjectileAge = 0;
	mClickBackoffCounter = 0;
	mAnimTicksPerFrame = 0;

	// B 形态 -> 常量表 kProjInitRows（原 9 支链合并；行序 = ProjectileType 枚举序
	// 0..13，NUM_PROJECTILES 锚定）。mSpeedLo/mSpeedHi 双 0 槽 = 原链不改角速度
	// （亦不消耗 RNG）；FIREBALL 断言与 COBBIG 图像 W/H 并入行数据；零槽 =
	// 原链不匹配。
	constexpr struct {
		float mRotation;            // 初始角（mRandomRot 时忽略）
		float mSpeedLo;             // 角速度区间；双 0 = 不赋值
		float mSpeedHi;
		float mShadowDY;            // mShadowY 修正；0 = 不修正
		ParticleEffect mTrail;      // 附加尾迹粒子；PARTICLE_NONE = 无
		float mTrailOffX;
		float mTrailOffY;
		Image* const* mSizeImage;   // W/H 改取图像尺寸；nullptr = 不改
		bool mRandomRot;            // 初始角随机取 [0,2PI)
		bool mFlipSpeed;            // 50% 概率角速度取反
	} kProjInitRows[(int)ProjectileType::NUM_PROJECTILES] = {
		{ 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 0 PEA（原链不匹配）
		{ 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_SNOWPEA_TRAIL, 8.0f, 13.0f, nullptr,                    false, false },  // 1 SNOWPEA
		{ (float)(-7 * PI / 25), -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 2 CABBAGE
		{ (float)(-2 * PI / 5),  -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 3 MELON
		{ 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_PUFFSHROOM_TRAIL, 13.0f, 13.0f, nullptr,              false, false },  // 4 PUFF
		{ (float)(-2 * PI / 5),  -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 5 WINTERMELON（共体）
		{ 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 6 FIREBALL（断言见表外）
		{ 0.0f,              0.05f,  0.1f,  15.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, true  },  // 7 STAR
		{ 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 8 SPIKE（原链不匹配）
		{ 0.0f,              0.05f,  0.1f,   0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        true,  false },  // 9 BASKETBALL
		{ 0.0f,             -0.2f,  -0.08f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 10 KERNEL
		{ (float)(PI / 2),   0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, &IMAGE_REANIM_COBCANNON_COB,    false, false },  // 11 COBBIG
		{ (float)(-7 * PI / 25), -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 12 BUTTER（共体）
		{ 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                        false, false },  // 13 ZOMBIE_PEA（原链不匹配）
	};
	static_assert(sizeof(kProjInitRows) / sizeof(kProjInitRows[0]) == (int)ProjectileType::NUM_PROJECTILES,
		"kProjInitRows 槽位须与 ProjectileType 枚举同步");

	if ((unsigned)mProjectileType < sizeof(kProjInitRows) / sizeof(kProjInitRows[0]))
	{
		const auto& aRow = kProjInitRows[(int)mProjectileType];
		if (aRow.mSizeImage != nullptr)
		{
			mWidth = (*aRow.mSizeImage)->GetWidth();
			mHeight = (*aRow.mSizeImage)->GetHeight();
		}
		mRotation = aRow.mRandomRot ? RandRangeFloat(0.0f, 2 * PI) : aRow.mRotation;
		if (aRow.mSpeedLo != 0.0f || aRow.mSpeedHi != 0.0f)
		{
			mRotationSpeed = RandRangeFloat(aRow.mSpeedLo, aRow.mSpeedHi);
			if (aRow.mFlipSpeed && Rand(2) == 0)
			{
				mRotationSpeed = -mRotationSpeed;
			}
		}
		if (aRow.mShadowDY != 0.0f)
		{
			mShadowY += aRow.mShadowDY;
		}
		if (aRow.mTrail != ParticleEffect::PARTICLE_NONE)
		{
			TodParticleSystem* aParticle = mApp->AddTodParticle(mPosX + aRow.mTrailOffX, mPosY + aRow.mTrailOffY, 400000, aRow.mTrail);
			AttachParticle(mAttachmentID, aParticle, aRow.mTrailOffX, aRow.mTrailOffY);
		}
	}

	// 表外特例：FIREBALL 不应经 ProjectileInitialize 产生（原链内联断言）
	if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
	{
		TOD_ASSERT(false);
	}

	mAnimCounter = 0;
	mX = (int)mPosX;
	mY = (int)mPosY;
}

//0x46CAA0
Plant* Projectile::FindCollisionTargetPlant()
{
	Rect aProjectileRect = GetProjectileRect();

	Plant* aPlant = nullptr;
	while (mBoard->IteratePlants(aPlant))
	{
		if (aPlant->mRow != mRow)
			continue;

		if (mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
		{
			if (aPlant->mSeedType == SeedType::SEED_PUFFSHROOM ||
				aPlant->mSeedType == SeedType::SEED_SUNSHROOM ||
				aPlant->mSeedType == SeedType::SEED_POTATOMINE ||
				aPlant->mSeedType == SeedType::SEED_SPIKEWEED ||
				aPlant->mSeedType == SeedType::SEED_SPIKEROCK ||
				aPlant->mSeedType == SeedType::SEED_LILYPAD)  // ��ʬ�㶹���ܻ��еͰ�ֲ��
				continue;
		}

		Rect aPlantRect = aPlant->GetPlantRect();
		if (GetRectOverlap(aProjectileRect, aPlantRect) > 8)
		{
			if (mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
			{
				return mBoard->GetTopPlantAt(aPlant->mPlantCol, aPlant->mRow, PlantPriority::TOPPLANT_EATING_ORDER);
			}
			else
			{
				return mBoard->GetTopPlantAt(aPlant->mPlantCol, aPlant->mRow, PlantPriority::TOPPLANT_CATAPULT_ORDER);
			}
		}
	}

	return nullptr;
}

//0x46CC30
bool Projectile::PeaAboutToHitTorchwood()
{
	if (mMotionType != ProjectileMotion::MOTION_STRAIGHT)
		return false;

	if (mProjectileType != ProjectileType::PROJECTILE_PEA && mProjectileType != ProjectileType::PROJECTILE_SNOWPEA)
		return false;

	Plant* aPlant = nullptr;
	while (mBoard->IteratePlants(aPlant))
	{
		if (aPlant->mSeedType == SeedType::SEED_TORCHWOOD && aPlant->mRow == mRow && !aPlant->NotOnGround() && mHitTorchwoodGridX != aPlant->mPlantCol)
		{
			Rect aPlantAttackRect = aPlant->GetPlantAttackRect(PlantWeapon::WEAPON_PRIMARY);
			Rect aProjectileRect = GetProjectileRect();
			aProjectileRect.mX += 40;

			if (GetRectOverlap(aPlantAttackRect, aProjectileRect) > 10)
			{
				return true;
			}
		}
	}

	return false;
}

//0x46CD40
Zombie* Projectile::FindCollisionTarget()
{
	if (PeaAboutToHitTorchwood())  // ������桱��ԭ������δ����������ڲ���о�������
		return nullptr;

	Rect aProjectileRect = GetProjectileRect();
	Zombie* aBestZombie = nullptr;
	int aMinX = 0;

	Zombie* aZombie = nullptr;
	while (mBoard->IterateZombies(aZombie))
	{
		if ((aZombie->mZombieType == ZombieType::ZOMBIE_BOSS || aZombie->mRow == mRow) && aZombie->EffectedByDamage((unsigned int)mDamageRangeFlags))
		{
			if (aZombie->mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL && mPosZ <= 45.0f)
			{
				continue;
			}

			if (mProjectileType == ProjectileType::PROJECTILE_STAR && mProjectileAge < 25 && mVelX >= 0.0f && aZombie->mZombieType == ZombieType::ZOMBIE_DIGGER)
			{
				continue;
			}

			Rect aZombieRect = aZombie->GetZombieRect();
			if (GetRectOverlap(aProjectileRect, aZombieRect) >= 0)
			{
				if (aBestZombie == nullptr || aZombie->mX < aMinX)
				{
					aBestZombie = aZombie;
					aMinX = aZombie->mX;
				}
			}
		}
	}

	return aBestZombie;
}

//0x46CE80
void Projectile::CheckForCollision()
{
	if (mMotionType == ProjectileMotion::MOTION_PUFF && mProjectileAge >= 75)
	{
		Die();
		return;
	}

	if (mPosX > WIDE_BOARD_WIDTH || mPosX + mWidth < 0.0f)
	{
		Die();
		return;
	}

	if (mMotionType == ProjectileMotion::MOTION_HOMING)
	{
		Zombie* aZombie = mBoard->ZombieTryToGet(mTargetZombieID);
		if (aZombie && aZombie->EffectedByDamage((unsigned int)mDamageRangeFlags))
		{
			Rect aProjectileRect = GetProjectileRect();
			Rect aZombieRect = aZombie->GetZombieRect();
			if (GetRectOverlap(aProjectileRect, aZombieRect) >= 0 && mPosY > aZombieRect.mY&& mPosY < aZombieRect.mY + aZombieRect.mHeight)
			{
				DoImpact(aZombie);
			}
		}
		return;
	}

	if (mProjectileType == ProjectileType::PROJECTILE_STAR && (mPosY > 600.0f || mPosY < 40.0f))
	{
		Die();
		return;
	}

	if ((mProjectileType == ProjectileType::PROJECTILE_PEA || mProjectileType == ProjectileType::PROJECTILE_STAR) && mShadowY - mPosY > 90.0f)
	{
		return;
	}

	if (mMotionType == ProjectileMotion::MOTION_FLOAT_OVER)
	{
		return;
	}

	if (mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
	{
		Plant* aPlant = FindCollisionTargetPlant();
		if (aPlant)
		{
			const ProjectileDefinition& aProjectileDef = GetProjectileDef();
			aPlant->mPlantHealth -= aProjectileDef.mDamage;
			aPlant->mEatenFlashCountdown = std::max(aPlant->mEatenFlashCountdown, 25);

			mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
			mApp->AddTodParticle(mPosX - 3.0f, mPosY + 17.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_PEA_SPLAT);
			Die();
		}
		return;
	}

	Zombie* aZombie = FindCollisionTarget();
	if (aZombie)
	{
		if (aZombie->mOnHighGround && CantHitHighGround())
		{
			return;
		}

		DoImpact(aZombie);
	}
}

//0x46D090
bool Projectile::CantHitHighGround()
{
	if (mMotionType == ProjectileMotion::MOTION_BACKWARDS || mMotionType == ProjectileMotion::MOTION_HOMING)
		return false;

	return (
		mProjectileType == ProjectileType::PROJECTILE_PEA ||
		mProjectileType == ProjectileType::PROJECTILE_SNOWPEA ||
		mProjectileType == ProjectileType::PROJECTILE_STAR ||
		mProjectileType == ProjectileType::PROJECTILE_PUFF ||
		mProjectileType == ProjectileType::PROJECTILE_FIREBALL
		) && !mOnHighGround;
}

//0x46D0D0
void Projectile::CheckForHighGround()
{
	float aShadowDelta = mShadowY - mPosY;

	if (mProjectileType == ProjectileType::PROJECTILE_PEA ||
		mProjectileType == ProjectileType::PROJECTILE_SNOWPEA ||
		mProjectileType == ProjectileType::PROJECTILE_FIREBALL ||
		mProjectileType == ProjectileType::PROJECTILE_SPIKE ||
		mProjectileType == ProjectileType::PROJECTILE_COBBIG)
	{
		if (aShadowDelta < 28.0f)
		{
			DoImpact(nullptr);
			return;
		}
	}

	if (mProjectileType == ProjectileType::PROJECTILE_PUFF && aShadowDelta < 0.0f)
	{
		DoImpact(nullptr);
		return;
	}

	if (mProjectileType == ProjectileType::PROJECTILE_STAR && aShadowDelta < 23.0f)
	{
		DoImpact(nullptr);
		return;
	}

	if (CantHitHighGround())
	{
		int aGridX = mBoard->PixelToGridXKeepOnBoard(mPosX + 30, mPosY);
		if (mBoard->mGridSquareType[aGridX][mRow] == GridSquareType::GRIDSQUARE_HIGH_GROUND)
		{
			DoImpact(nullptr);
		}
	}
}

//0x46D1F0
bool Projectile::IsSplashDamage(Zombie* theZombie)
{
	if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL && theZombie && theZombie->IsFireResistant())
		return false;

	return 
		mProjectileType == ProjectileType::PROJECTILE_MELON || 
		mProjectileType == ProjectileType::PROJECTILE_WINTERMELON || 
		mProjectileType == ProjectileType::PROJECTILE_FIREBALL;
}

//0x46D230
unsigned int Projectile::GetDamageFlags(Zombie* theZombie)
{
	unsigned int aDamageFlags = 0U;

	if (IsSplashDamage(theZombie))
	{
		SetBit(aDamageFlags, (int)DamageFlags::DAMAGE_HITS_SHIELD_AND_BODY, true);
	}
	else if (mMotionType == ProjectileMotion::MOTION_LOBBED || mMotionType == ProjectileMotion::MOTION_BACKWARDS)
	{
		SetBit(aDamageFlags, (int)DamageFlags::DAMAGE_BYPASSES_SHIELD, true);
	}
	else if (mMotionType == ProjectileMotion::MOTION_STAR && mVelX < 0.0f)
	{
		SetBit(aDamageFlags, (int)DamageFlags::DAMAGE_BYPASSES_SHIELD, true);
	}

	if (mProjectileType == ProjectileType::PROJECTILE_SNOWPEA || mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
	{
		SetBit(aDamageFlags, (int)DamageFlags::DAMAGE_FREEZE, true);
	}

	return aDamageFlags;
}

//0x46D2B0
bool Projectile::IsZombieHitBySplash(Zombie* theZombie)
{
	Rect aProjectileRect = GetProjectileRect();
	if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
	{
		aProjectileRect.mWidth = 100;
	}

	int aRowDeviation = theZombie->mRow - mRow;
	Rect aZombieRect = theZombie->GetZombieRect();
	if (theZombie->IsFireResistant() && mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
	{
		return false;
	}

	if (theZombie->mZombieType == ZombieType::ZOMBIE_BOSS)
	{
		aRowDeviation = 0;
	}
	if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
	{
		if (aRowDeviation != 0)
		{
			return false;
		}
	}
	else if (aRowDeviation > 1 || aRowDeviation < -1)
	{
		return false;
	}

	return theZombie->EffectedByDamage((unsigned int)mDamageRangeFlags) && GetRectOverlap(aProjectileRect, aZombieRect) >= 0;
}

//0x46D390
void Projectile::DoSplashDamage(Zombie* theZombie)
{
	const ProjectileDefinition& aProjectileDef = GetProjectileDef();

	int aZombiesGetSplashed = 0;
	Zombie* aZombie = nullptr;
	while (mBoard->IterateZombies(aZombie))
	{
		if (aZombie != theZombie && IsZombieHitBySplash(aZombie))
		{
			aZombiesGetSplashed++;
		}
	}

	int aOriginalDamage = aProjectileDef.mDamage;
	int aSplashDamage = aProjectileDef.mDamage / 3;
	int aMaxSplashDamageAmount = aOriginalDamage * 7;
	if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
	{
		aMaxSplashDamageAmount = aOriginalDamage;
	}
	int aSplashDamageAmount = aSplashDamage * aZombiesGetSplashed;
	if (aSplashDamageAmount > aMaxSplashDamageAmount)
	{
		//aSplashDamage *= aMaxSplashDamageAmount / aSplashDamage;
		aSplashDamage = aOriginalDamage * aMaxSplashDamageAmount / (aSplashDamageAmount * 3);
		aSplashDamage = std::max(aSplashDamage, 1);
	}

	aZombie = nullptr;
	while (mBoard->IterateZombies(aZombie))
	{
		if (IsZombieHitBySplash(aZombie))
		{
			unsigned int aDamageFlags = GetDamageFlags(aZombie);
			if (aZombie == theZombie)
			{
				aZombie->TakeDamage(aOriginalDamage, aDamageFlags);
			}
			else
			{
				aZombie->TakeDamage(aSplashDamage, aDamageFlags);
			}
		}
	}
}

//0x46D490
// GOTY @Patoke: 0x471B41
void Projectile::UpdateLobMotion()
{
	if (mProjectileType == ProjectileType::PROJECTILE_COBBIG && mPosZ < -700.0f)
	{
		mVelZ = 8.0f;
		mRow = mCobTargetRow;
		mPosX = mCobTargetX;
		int aCobTargetCol = mBoard->PixelToGridXKeepOnBoard(mCobTargetX, 0);
		mPosY = mBoard->GridToPixelY(aCobTargetCol, mCobTargetRow);
		mShadowY = mPosY + 67.0f;
		mRotation = -PI / 2;
	}

	mVelZ += mAccZ;
	if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY)
	{
		mVelZ += mAccZ;
	}
	mPosX += mVelX;
	mPosY += mVelY;
	mPosZ += mVelZ;

	bool isRising = mVelZ < 0.0f;
	if (isRising && (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL || mProjectileType == ProjectileType::PROJECTILE_COBBIG))
	{
		return;
	}
	if (mProjectileAge > 20)
	{
		if (isRising)
		{
			return;
		}

		float aMinCollisionZ = 0.0f;

		// B 形态 -> 常量表 kProjMinCollisionZ（原 5 支链合并；行序 =
		// ProjectileType 枚举序 0..13，NUM_PROJECTILES 锚定；0 槽 = 原默认 0）
		static constexpr float kProjMinCollisionZ[(int)ProjectileType::NUM_PROJECTILES] = {
			0.0f,    // 0 PEA（原默认）
			0.0f,    // 1 SNOWPEA（原默认）
			-30.0f,  // 2 CABBAGE
			-35.0f,  // 3 MELON
			0.0f,    // 4 PUFF（原默认）
			-35.0f,  // 5 WINTERMELON（共体）
			0.0f,    // 6 FIREBALL（原默认）
			0.0f,    // 7 STAR（原默认）
			0.0f,    // 8 SPIKE（原默认）
			60.0f,   // 9 BASKETBALL
			-30.0f,  // 10 KERNEL（共体）
			-60.0f,  // 11 COBBIG
			-32.0f,  // 12 BUTTER
			0.0f,    // 13 ZOMBIE_PEA（原默认）
		};
		static_assert(sizeof(kProjMinCollisionZ) / sizeof(kProjMinCollisionZ[0]) == (int)ProjectileType::NUM_PROJECTILES,
			"kProjMinCollisionZ 槽位须与 ProjectileType 枚举同步");

		if ((unsigned)mProjectileType < sizeof(kProjMinCollisionZ) / sizeof(kProjMinCollisionZ[0]))
		{
			aMinCollisionZ = kProjMinCollisionZ[(int)mProjectileType];
		}
		if (mBoard->mPlantRow[mRow] == PlantRowType::PLANTROW_POOL)
		{
			aMinCollisionZ += 40.0f;
		}

		if (mPosZ <= aMinCollisionZ)
		{
			return;
		}
	}

	Plant* aPlant = nullptr;
	Zombie* aZombie = nullptr;
	if (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL || mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
	{
		aPlant = FindCollisionTargetPlant();
	}
	else
	{
		aZombie = FindCollisionTarget();
	}

	float aGroundZ = 80.0f;
	if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
	{
		aGroundZ = -40.0f;
	}
	bool hitGround = mPosZ > aGroundZ;
	if (aZombie == nullptr && aPlant == nullptr && !hitGround)
	{
		return;
	}

	if (aPlant)
	{
		Plant* aUmbrellaPlant = mBoard->FindUmbrellaPlant(aPlant->mPlantCol, aPlant->mRow);
		if (aUmbrellaPlant)
		{
			if (aUmbrellaPlant->mState == PlantState::STATE_UMBRELLA_REFLECTING)
			{
				mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
				int aRenderPosition = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_TOP, 0, 1);
				mApp->AddTodParticle(mPosX + 20.0f, mPosY + 20.0f, aRenderPosition, ParticleEffect::PARTICLE_UMBRELLA_REFLECT);
				Die();
			}
			else if (aUmbrellaPlant->mState != PlantState::STATE_UMBRELLA_TRIGGERED)
			{
				mApp->PlayFoley(FoleyType::FOLEY_UMBRELLA);
				aUmbrellaPlant->DoSpecial();
			}
		}
		else
		{
			aPlant->mPlantHealth -= GetProjectileDef().mDamage;
			aPlant->mEatenFlashCountdown = std::max(aPlant->mEatenFlashCountdown, 25);
			mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
			Die();
		}
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
	{
		// @Patoke: implemented
		int aBeforeGargantuarCount = mBoard->GetLiveGargantuarCount();
		mBoard->KillAllZombiesInRadius(mRow, mPosX + 80, mPosY + 40, 115, 1, true, mDamageRangeFlags);
		int aAfterGargantuarCount = mBoard->GetLiveGargantuarCount();
		mBoard->mGargantuarsKillsByCornCob += aBeforeGargantuarCount - aAfterGargantuarCount;
		if (mBoard->mGargantuarsKillsByCornCob >= 2)
			ReportAchievement::GiveAchievement(mApp, PopcornParty, true);

		DoImpact(nullptr);
	}
	else
	{
		DoImpact(aZombie);
	}
}

namespace
{
// Projectile::UpdateNormalMotion 分发表：表内匿名 lambda = 原 case 体逐句迁移；
// default（STRAIGHT/LOBBED/PUFF 直进）具名并被缺槽/越界复用。
using ProjMotionFn = void (*)(Projectile&);

// 原 else（无 case 的 0/1/5 型与表外值共用）
void ProjMotionDefault(Projectile& p)
{
	p.mPosX += 3.33f;
}

// 匿名 lambda 函数指针表，行序 = ProjectileMotion 枚举值序（0..9）。
constexpr ProjMotionFn kProjMotionCases[(int)ProjectileMotion::MOTION_HOMING + 1] = {
    &ProjMotionDefault,  // 0 MOTION_STRAIGHT（原 else）
    &ProjMotionDefault,  // 1 MOTION_LOBBED（原 else）
    // 原 case MOTION_THREEPEATER
    [](Projectile& p)
    {
        p.mPosX += 3.33f;
        p.mPosY += p.mVelY;
        p.mVelY *= 0.97f;
        p.mShadowY += p.mVelY;
    },  // 2 MOTION_THREEPEATER
    // 原 case MOTION_BEE
    [](Projectile& p)
    {
        if (p.mProjectileAge < 60)
        {
            p.mPosY -= 0.5f;
        }
        p.mPosX += 3.33f;
    },  // 3 MOTION_BEE
    // 原 case MOTION_BEE_BACKWARDS
    [](Projectile& p)
    {
        if (p.mProjectileAge < 60)
        {
            p.mPosY -= 0.5f;
        }
        p.mPosX -= 3.33f;
    },  // 4 MOTION_BEE_BACKWARDS
    &ProjMotionDefault,  // 5 MOTION_PUFF（原 else）
    // 原 case MOTION_BACKWARDS
    [](Projectile& p)
    {
        p.mPosX -= 3.33f;
    },  // 6 MOTION_BACKWARDS
    // 原 case MOTION_STAR
    [](Projectile& p)
    {
        p.mPosY += p.mVelY;
        p.mPosX += p.mVelX;
        p.mShadowY += p.mVelY;

        if (p.mVelY != 0.0f)
        {
            p.mRow = p.mBoard->PixelToGridYKeepOnBoard(p.mPosX, p.mPosY);
        }
    },  // 7 MOTION_STAR
    // 原 case MOTION_FLOAT_OVER
    [](Projectile& p)
    {
        if (p.mVelZ < 0.0f)
        {
            p.mVelZ += 0.002f;
            p.mVelZ = std::min(p.mVelZ, 0.0f);
            p.mPosY += p.mVelZ;
            p.mRotation = 0.3f - 0.7f * p.mVelZ * PI * 0.25f;
        }
        p.mPosX += 0.4f;
    },  // 8 MOTION_FLOAT_OVER
    // 原 case MOTION_HOMING
    [](Projectile& p)
    {
        Zombie* aZombie = p.mBoard->ZombieTryToGet(p.mTargetZombieID);
        if (aZombie && aZombie->EffectedByDamage((unsigned int)p.mDamageRangeFlags))
        {
            Rect aZombieRect = aZombie->GetZombieRect();
            SexyVector2 aTargetCenter(aZombie->ZombieTargetLeadX(0.0f), aZombieRect.mY + aZombieRect.mHeight / 2);
            SexyVector2 aProjectileCenter(p.mPosX + p.mWidth / 2, p.mPosY + p.mHeight / 2);
            SexyVector2 aToTarget = (aTargetCenter - aProjectileCenter).Normalize();
            SexyVector2 aMotion(p.mVelX, p.mVelY);

            aMotion += aToTarget * (0.001f * p.mProjectileAge);
            aMotion = aMotion.Normalize();
            aMotion *= 2.0f;

            p.mVelX = aMotion.x;
            p.mVelY = aMotion.y;
            p.mRotation = -atan2(p.mVelY, p.mVelX);
        }

        p.mPosY += p.mVelY;
        p.mPosX += p.mVelX;
        p.mShadowY += p.mVelY;
        p.mRow = p.mBoard->PixelToGridYKeepOnBoard(p.mPosX, p.mPosY);
    },  // 9 MOTION_HOMING
};
static_assert(sizeof(kProjMotionCases) / sizeof(kProjMotionCases[0]) ==
    (int)ProjectileMotion::MOTION_HOMING + 1, "kProjMotionCases 槽位数须与 ProjectileMotion 枚举同步");
}  // namespace

//0x46D890
void Projectile::UpdateNormalMotion()
{
    // C 形态 -> 匿名 lambda 表（上方 kProjMotionCases）：行序 = ProjectileMotion
    // 枚举序（0..9，无 NUM 哨兵=末值 MOTION_HOMING 锚定）；default 具名并被
    // 缺槽/越界复用。
    const unsigned aMotionIndex = static_cast<unsigned>(mMotionType);
    if (aMotionIndex <= static_cast<unsigned>(ProjectileMotion::MOTION_HOMING))
    {
        kProjMotionCases[aMotionIndex](*this);
    }
    else
    {
        ProjMotionDefault(*this);
    }

	if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY)
	{
		if (mMotionType == ProjectileMotion::MOTION_FLOAT_OVER)
		{
			mVelZ += 0.004f;
		}
		else
		{
			mVelZ += 0.2f;
		}

		mPosY += mVelZ;
	}

	CheckForCollision();
	CheckForHighGround();
}

//0x46DC70
void Projectile::UpdateMotion()
{
	if (mAnimTicksPerFrame > 0)
	{
		mAnimCounter = (mAnimCounter + 1) % (mNumFrames * mAnimTicksPerFrame);
		mFrame = mAnimCounter / mAnimTicksPerFrame;
	}

	int aOldRow = mRow;
	float aOldY = mBoard->GetPosYBasedOnRow(mPosX, mRow);
	if (mMotionType == ProjectileMotion::MOTION_LOBBED)
	{
		UpdateLobMotion();
	}
	else
	{
		UpdateNormalMotion();
	}

	float aSlopeHeightChange = mBoard->GetPosYBasedOnRow(mPosX, aOldRow) - aOldY;
#ifdef DO_FIX_BUGS
	if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
	{
		aSlopeHeightChange = 0.0f;  // �޸����Ͻ�֮�硱
	}
#endif
	if (mMotionType == ProjectileMotion::MOTION_FLOAT_OVER)
	{
		mPosY += aSlopeHeightChange;
	}
	if (mMotionType == ProjectileMotion::MOTION_LOBBED)
	{
		mPosY += aSlopeHeightChange;
		mPosZ -= aSlopeHeightChange;
	}
	mShadowY += aSlopeHeightChange;
	mX = (int)mPosX;
	mY = (int)(mPosY + mPosZ);
}

//0x46DD30
void Projectile::PlayImpactSound(Zombie* theZombie)
{
	bool aPlayHelmSound = true;
	bool aPlaySplatSound = true;
	if (mProjectileType == ProjectileType::PROJECTILE_KERNEL)
	{
		mApp->PlayFoley(FoleyType::FOLEY_KERNEL_SPLAT);
		aPlayHelmSound = false;
		aPlaySplatSound = false;
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_BUTTER)
	{
		mApp->PlayFoley(FoleyType::FOLEY_BUTTER);
		aPlaySplatSound = false;
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL && IsSplashDamage(theZombie))
	{
		mApp->PlayFoley(FoleyType::FOLEY_IGNITE);
		aPlayHelmSound = false;
		aPlaySplatSound = false;
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_MELON || mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
	{
		mApp->PlayFoley(FoleyType::FOLEY_MELONIMPACT);
		aPlaySplatSound = false;
	}

	if (aPlayHelmSound && theZombie)
	{
		if (theZombie->mHelmType == HELMTYPE_PAIL)
		{
			mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
			aPlaySplatSound = false;
		}
		else if (theZombie->mHelmType == HELMTYPE_TRAFFIC_CONE || theZombie->mHelmType == HELMTYPE_DIGGER || theZombie->mHelmType == HELMTYPE_FOOTBALL)
		{
			mApp->PlayFoley(FoleyType::FOLEY_PLASTIC_HIT);
		}
	}

	if (aPlaySplatSound)
	{
		mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
	}
}

//0x46E000
void Projectile::DoImpact(Zombie* theZombie)
{
	PlayImpactSound(theZombie);

	if (IsSplashDamage(theZombie))
	{
		if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL && theZombie)
		{
			theZombie->RemoveColdEffects();
		}

		DoSplashDamage(theZombie);
	}
	else if (theZombie)
	{
		unsigned int aDamageFlags = GetDamageFlags(theZombie);
		theZombie->TakeDamage(GetProjectileDef().mDamage, aDamageFlags);
	}

	float aLastPosX = mPosX - mVelX;
	float aLastPosY = mPosY + mPosZ - mVelY - mVelZ;
	ParticleEffect aEffect = ParticleEffect::PARTICLE_NONE;
	float aSplatPosX = mPosX + 12.0f;
	float aSplatPosY = mPosY + 12.0f;

	// B 形态 -> 常量表 kProjSplatRows（原 10 支链中 6 支同构溅落合并；行序 =
	// ProjectileType 枚举序 0..13，NUM_PROJECTILES 锚定）。mFromLastPos = true
	// 时以 aLastPos 为基绝对改写（原 CABBAGE/BUTTER 支），否则以默认 aSplatPos
	// 为基做增量；NONE 槽 = 表外特例或原链不溅落。
	static constexpr struct { ParticleEffect mEffect; float mOffX; float mOffY; bool mFromLastPos; } kProjSplatRows[(int)ProjectileType::NUM_PROJECTILES] = {
		{ ParticleEffect::PARTICLE_PEA_SPLAT,      -15.0f,   0.0f, false },  // 0 PEA
		{ ParticleEffect::PARTICLE_SNOWPEA_SPLAT, -15.0f,   0.0f, false },  // 1 SNOWPEA
		{ ParticleEffect::PARTICLE_CABBAGE_SPLAT, -38.0f,  23.0f, true  },  // 2 CABBAGE
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 3 MELON（表外直加）
		{ ParticleEffect::PARTICLE_PUFF_SPLAT,    -20.0f,   0.0f, false },  // 4 PUFF
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 5 WINTERMELON（表外直加）
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 6 FIREBALL（表外加火苗）
		{ ParticleEffect::PARTICLE_STAR_SPLAT,     0.0f,   0.0f, false },  // 7 STAR
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 8 SPIKE（原链不匹配）
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 9 BASKETBALL（原链不匹配）
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 10 KERNEL（原链不匹配）
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 11 COBBIG（表外爆记）
		{ ParticleEffect::PARTICLE_BUTTER_SPLAT, -20.0f,  63.0f, true  },  // 12 BUTTER（ApplyButter 见表外）
		{ ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 13 ZOMBIE_PEA（原链不匹配）
	};
	static_assert(sizeof(kProjSplatRows) / sizeof(kProjSplatRows[0]) == (int)ProjectileType::NUM_PROJECTILES,
		"kProjSplatRows 槽位须与 ProjectileType 枚举同步");

	if ((unsigned)mProjectileType < sizeof(kProjSplatRows) / sizeof(kProjSplatRows[0]))
	{
		const auto& aRow = kProjSplatRows[(int)mProjectileType];
		if (aRow.mEffect != ParticleEffect::PARTICLE_NONE)
		{
			aEffect = aRow.mEffect;
			if (aRow.mFromLastPos)
			{
				aSplatPosX = aLastPosX + aRow.mOffX;
				aSplatPosY = aLastPosY + aRow.mOffY;
			}
			else
			{
				aSplatPosX += aRow.mOffX;
				aSplatPosY += aRow.mOffY;
			}
		}
	}

	// 表外特例：MELON/WINTERMELON 无条件直加溅落；COBBIG 爆记 + 爆米花 + 音效 +
	// 震屏；FIREBALL 溅射命中时加火苗 reanim；BUTTER 命中僵尸上黄油。
	if (mProjectileType == ProjectileType::PROJECTILE_MELON)
	{
		mApp->AddTodParticle(aLastPosX + 30.0f, aLastPosY + 30.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_MELONSPLASH);
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
	{
		mApp->AddTodParticle(aLastPosX + 30.0f, aLastPosY + 30.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_WINTERMELON);
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
	{
		int aRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_GROUND, mCobTargetRow, 2);
		mApp->AddTodParticle(mPosX + 80.0f, mPosY + 40.0f, aRenderOrder, ParticleEffect::PARTICLE_BLASTMARK);
		mApp->AddTodParticle(mPosX + 80.0f, mPosY + 40.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_POPCORNSPLASH);
		mApp->PlaySample(SOUND_DOOMSHROOM);
		mBoard->ShakeBoard(3, -4);
	}
	else if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
	{
		if (IsSplashDamage(theZombie))
		{
			Reanimation* aFireReanim = mApp->AddReanimation(mPosX + 38.0f, mPosY - 20.0f, mRenderOrder + 1, ReanimationType::REANIM_JALAPENO_FIRE);
			aFireReanim->mAnimTime = 0.25f;
			aFireReanim->mAnimRate = 24.0f;
			aFireReanim->OverrideScale(0.7f, 0.4f);
		}
	}

	if (mProjectileType == ProjectileType::PROJECTILE_BUTTER && theZombie)
	{
		theZombie->ApplyButter();
	}

	if (aEffect != ParticleEffect::PARTICLE_NONE)
	{
		if (theZombie)
		{
			float aPosX = aSplatPosX + 52.0f - theZombie->mX;
			float aPosY = aSplatPosY - theZombie->mY;
			if (theZombie->mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL || theZombie->mZombiePhase == ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL)
			{
				aPosY += 60.0f;
			}
			if (mMotionType == ProjectileMotion::MOTION_BACKWARDS)
			{
				aPosX -= 80.0f;
			}
			else if (mPosX > theZombie->mX + 40 && mMotionType != ProjectileMotion::MOTION_LOBBED)
			{
				aPosX -= 60.0f;
			}

			aPosY = ClampFloat(aPosY, 20.0f, 100.0f);
			theZombie->AddAttachedParticle(aPosX, aPosY, aEffect);
		}
		else
		{
			mApp->AddTodParticle(aSplatPosX, aSplatPosY, mRenderOrder + 1, aEffect);
		}
	}

	Die();
}

//0x46E460
void Projectile::Update()
{
	mProjectileAge++;
	if (mApp->mGameScene != GameScenes::SCENE_PLAYING && !mBoard->mCutScene->ShouldRunUpsellBoard())
		return;

	// 直飞弹种（出生即入弹道渲染层，无 20cs 延迟）：按 ProjectileType 槽位直查。
	// 行序 = 枚举序 0..13；原 10 连比较 OR 链退役。
	static constexpr bool kImmediateRender[] = {
		true,   // PROJECTILE_PEA          豌豆
		true,   // PROJECTILE_SNOWPEA      冰豌豆
		true,   // PROJECTILE_CABBAGE      卷心菜
		true,   // PROJECTILE_MELON        西瓜
		false,  // PROJECTILE_PUFF         孢子
		true,   // PROJECTILE_WINTERMELON  冰瓜
		false,  // PROJECTILE_FIREBALL     火豌豆
		false,  // PROJECTILE_STAR         星星
		true,   // PROJECTILE_SPIKE        尖刺
		false,  // PROJECTILE_BASKETBALL   篮球
		true,   // PROJECTILE_KERNEL       玉米粒
		true,   // PROJECTILE_COBBIG       玉米加农炮
		true,   // PROJECTILE_BUTTER       黄油
		true,   // PROJECTILE_ZOMBIE_PEA   僵尸豌豆
	};
	static_assert(sizeof(kImmediateRender) / sizeof(kImmediateRender[0]) == (int)ProjectileType::NUM_PROJECTILES,
		"直飞槽位须与 ProjectileType 枚举同步");
	int aTime = kImmediateRender[mProjectileType] ? 0 : 20;
	if (mProjectileAge > aTime)
	{
		mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_PROJECTILE, mRow, 0);
	}

	if (mClickBackoffCounter > 0)
	{
		mClickBackoffCounter--;
	}
	mRotation += mRotationSpeed;

	UpdateMotion();
	AttachmentUpdateAndMove(mAttachmentID, mPosX, mPosY + mPosZ);
}

//0x46E540
void Projectile::Draw(Graphics* g)
{
	const ProjectileDefinition& aProjectileDef = GetProjectileDef();

	// 弹体贴图/缩放：按 ProjectileType 槽位直查 {图, 缩放}，行序 = 枚举序。
	// 孢子缩放随飞行龄曲线变化（保留特例）；火豌豆无贴图（走附件/粒子）。
	// 表存全局 Image* 变量的地址（constexpr 取址常量），用时解引用——
	// IMAGE_* 为运行期装载的全局，constexpr 直存指针不可行。
	static constexpr struct { Image* const* mImage; float mScale; } kDrawParams[] = {
		{ &IMAGE_PROJECTILEPEA,                     1.0f  },  // PROJECTILE_PEA          豌豆
		{ &IMAGE_PROJECTILESNOWPEA,                 1.0f  },  // PROJECTILE_SNOWPEA      冰豌豆
		{ &IMAGE_REANIM_CABBAGEPULT_CABBAGE,        1.0f  },  // PROJECTILE_CABBAGE      卷心菜
		{ &IMAGE_REANIM_MELONPULT_MELON,            1.0f  },  // PROJECTILE_MELON        西瓜
		{ &IMAGE_PUFFSHROOM_PUFF1,                  0.3f  },  // PROJECTILE_PUFF         孢子（缩放走曲线，下行覆盖）
		{ &IMAGE_REANIM_WINTERMELON_PROJECTILE,     1.0f  },  // PROJECTILE_WINTERMELON  冰瓜
		{ nullptr,                                 1.0f  },  // PROJECTILE_FIREBALL（空，占位）     火豌豆
		{ &IMAGE_PROJECTILE_STAR,                   1.0f  },  // PROJECTILE_STAR         星星
		{ &IMAGE_PROJECTILECACTUS,                  1.0f  },  // PROJECTILE_SPIKE        尖刺
		{ &IMAGE_REANIM_ZOMBIE_CATAPULT_BASKETBALL, 1.1f  },  // PROJECTILE_BASKETBALL   篮球
		{ &IMAGE_REANIM_CORNPULT_KERNAL,            0.95f },  // PROJECTILE_KERNEL       玉米粒
		{ &IMAGE_REANIM_COBCANNON_COB,              0.9f  },  // PROJECTILE_COBBIG       玉米加农炮
		{ &IMAGE_REANIM_CORNPULT_BUTTER,            0.8f  },  // PROJECTILE_BUTTER       黄油
		{ &IMAGE_PROJECTILEPEA,                     1.0f  },  // PROJECTILE_ZOMBIE_PEA   僵尸豌豆
	};
	static_assert(sizeof(kDrawParams) / sizeof(kDrawParams[0]) == (int)ProjectileType::NUM_PROJECTILES,
		"弹体贴图槽位须与 ProjectileType 枚举同步");
	Image* aImage = kDrawParams[mProjectileType].mImage ? *kDrawParams[mProjectileType].mImage : nullptr;
	float aScale = kDrawParams[mProjectileType].mScale;
	if (mProjectileType == ProjectileType::PROJECTILE_PUFF)
	{
		aScale = TodAnimateCurveFloat(0, 30, mProjectileAge, 0.3f, 1.0f, Curves::Linear);
	}

	bool aMirror = false;
	if (mMotionType == ProjectileMotion::MOTION_BEE_BACKWARDS)
	{
		aMirror = true;
	}

	if (aImage)
	{
		TOD_ASSERT(aProjectileDef.mImageRow < aImage->mNumRows);
		TOD_ASSERT(mFrame < aImage->mNumCols);

		int aCelWidth = aImage->GetCelWidth();
		int aCelHeight = aImage->GetCelHeight();
		Rect aSrcRect(aCelWidth * mFrame, aCelHeight * aProjectileDef.mImageRow, aCelWidth, aCelHeight);
		if (FloatApproxEqual(mRotation, 0.0f) && FloatApproxEqual(aScale, 1.0f))
		{
			Rect aDestRect(0, 0, aCelWidth, aCelHeight);
			g->DrawImageMirror(aImage, aDestRect, aSrcRect, aMirror);
		}
		else
		{
			float aOffsetX = mPosX + aCelWidth * 0.5f;
			float aOffsetY = mPosZ + mPosY + aCelHeight * 0.5f;
			SexyTransform2D aTransform;
			TodScaleRotateTransformMatrix(aTransform, aOffsetX + mBoard->mX, aOffsetY + mBoard->mY, mRotation, aScale, aScale);
			TodBltMatrix(g, aImage, aTransform, g->mClipRect, Color::White, g->mDrawMode, aSrcRect);
		}
	}

	if (mAttachmentID != AttachmentID::ATTACHMENTID_NULL)
	{
		Graphics theParticleGraphics(*g);
		MakeParentGraphicsFrame(&theParticleGraphics);
		AttachmentDraw(mAttachmentID, &theParticleGraphics, false);
	}
}

//0x46E8C0
void Projectile::DrawShadow(Graphics* g)
{
	int aCelCol = 0;
	float aScale = 1.0f;
	float aStretch = 1.0f;
	float aOffsetX = mPosX - mX;
	float aOffsetY = mPosY - mY;

	int aGridX = mBoard->PixelToGridXKeepOnBoard(mX, mY);
	bool isHighGround = false;
	if (mBoard->mGridSquareType[aGridX][mRow] == GridSquareType::GRIDSQUARE_HIGH_GROUND)
	{
		isHighGround = true;
	}
	if (mOnHighGround && !isHighGround)
	{
		aOffsetY += HIGH_GROUND_HEIGHT;
	}
	else if (!mOnHighGround && isHighGround)
	{
		aOffsetY -= HIGH_GROUND_HEIGHT;
	}

	if (mBoard->StageIsNight())
	{
		aCelCol = 1;
	}

	// 阴影参数：按 ProjectileType 槽位直查 {dx, dy, 缩放, 拉伸, 跳过}，行序 = 枚举序。
	// 孢子无影（skip）；缺省行 = 无修正。
	static constexpr struct { float mDX, mDY, mScale, mStretch; bool mSkip; } kShadowParams[] = {
		{  3,  0, 1.0f, 1.0f, false },  // PROJECTILE_PEA          豌豆
		{ -1,  0, 1.3f, 1.0f, false },  // PROJECTILE_SNOWPEA      冰豌豆
		{  3, 10, 1.6f, 1.0f, false },  // PROJECTILE_CABBAGE      卷心菜
		{  3, 10, 1.6f, 1.0f, false },  // PROJECTILE_MELON        西瓜
		{  0,  0, 1.0f, 1.0f, true  },  // PROJECTILE_PUFF         孢子（无影）
		{  3, 10, 1.6f, 1.0f, false },  // PROJECTILE_WINTERMELON  冰瓜
		{  0,  0, 1.4f, 1.0f, false },  // PROJECTILE_FIREBALL     火豌豆
		{  7,  0, 1.0f, 1.0f, false },  // PROJECTILE_STAR         星星
		{  0,  0, 1.0f, 1.0f, false },  // PROJECTILE_SPIKE        尖刺
		{  0,  0, 1.0f, 1.0f, false },  // PROJECTILE_BASKETBALL   篮球
		{  3, 10, 1.6f, 1.0f, false },  // PROJECTILE_KERNEL       玉米粒
		{ 57,  0, 1.0f, 3.0f, false },  // PROJECTILE_COBBIG       玉米加农炮
		{  3, 10, 1.6f, 1.0f, false },  // PROJECTILE_BUTTER       黄油
		{  3,  0, 1.0f, 1.0f, false },  // PROJECTILE_ZOMBIE_PEA   僵尸豌豆
	};
	static_assert(sizeof(kShadowParams) / sizeof(kShadowParams[0]) == (int)ProjectileType::NUM_PROJECTILES,
		"阴影槽位须与 ProjectileType 枚举同步");
	{
		const auto& aShadow = kShadowParams[mProjectileType];
		if (aShadow.mSkip)
			return;
		aOffsetX += aShadow.mDX;
		aOffsetY += aShadow.mDY;
		aScale = aShadow.mScale;
		aStretch = aShadow.mStretch;
	}

	if (mMotionType == ProjectileMotion::MOTION_LOBBED)
	{
		float aHeight = ClampFloat(-mPosZ, 0.0f, 200.0f);
		aScale *= 200.0f / (aHeight + 200.0f);
	}

	TodDrawImageCelScaledF(g, IMAGE_PEA_SHADOWS, aOffsetX, (mShadowY - mPosY + aOffsetY), aCelCol, 0, aScale * aStretch, aScale);
}

//0x46EB20
void Projectile::Die()
{
	mDead = true;

	if (mProjectileType == ProjectileType::PROJECTILE_PUFF || mProjectileType == ProjectileType::PROJECTILE_SNOWPEA)
	{
		AttachmentCrossFade(mAttachmentID, "FadeOut");
		AttachmentDetach(mAttachmentID);
	}
	else
	{
		AttachmentDie(mAttachmentID);
	}
}

//0x46EBC0
Rect Projectile::GetProjectileRect()
{
	// B 形态 -> 常量表 kProjRectRows（原 5 支链合并；行序 = ProjectileType 枚举
	// 序 0..13，NUM_PROJECTILES 锚定）。mW/mH：正值 = 绝对宽/高；负值/0 =
	// mWidth/mHeight 增量；零槽 = 原默认 Rect(mX, mY, mWidth, mHeight)。
	// COBBIG 中心 230 方框表外特例（先行分发）。
	if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
	{
		return Rect(mX + mWidth / 2 - 115, mY + mHeight / 2 - 115, 230, 230);
	}

	static constexpr struct { int mDX; int mDY; int mW; int mH; } kProjRectRows[(int)ProjectileType::NUM_PROJECTILES] = {
		{ -15, 0, -15, 0 },  // 0 PEA
		{ -15, 0, -15, 0 },  // 1 SNOWPEA（共体）
		{   0, 0,   0, 0 },  // 2 CABBAGE（原默认）
		{  20, 0,  60, 0 },  // 3 MELON
		{   0, 0,   0, 0 },  // 4 PUFF（原默认）
		{  20, 0,  60, 0 },  // 5 WINTERMELON（共体）
		{   0, 0, -10, 0 },  // 6 FIREBALL
		{   0, 0,   0, 0 },  // 7 STAR（原默认）
		{ -25, 0, -25, 0 },  // 8 SPIKE
		{   0, 0,   0, 0 },  // 9 BASKETBALL（原默认）
		{   0, 0,   0, 0 },  // 10 KERNEL（原默认）
		{   0, 0,   0, 0 },  // 11 COBBIG（表外特例占位）
		{ -15, 0, -15, 0 },  // 12 BUTTER
		{ -15, 0, -15, 0 },  // 13 ZOMBIE_PEA（共体）
	};
	static_assert(sizeof(kProjRectRows) / sizeof(kProjRectRows[0]) == (int)ProjectileType::NUM_PROJECTILES,
		"kProjRectRows 槽位须与 ProjectileType 枚举同步");

	if ((unsigned)mProjectileType >= sizeof(kProjRectRows) / sizeof(kProjRectRows[0]))
	{
		return Rect(mX, mY, mWidth, mHeight);  // 原 else 兜底
	}

	const auto& aRow = kProjRectRows[(int)mProjectileType];
	const int aWidth = aRow.mW > 0 ? aRow.mW : mWidth - aRow.mW;
	const int aHeight = aRow.mH > 0 ? aRow.mH : mHeight - aRow.mH;
	return Rect(mX + aRow.mDX, mY + aRow.mDY, aWidth, aHeight);
}

//0x46ECB0
void Projectile::ConvertToFireball(int theGridX)
{
	if (mHitTorchwoodGridX == theGridX)
		return;

	mProjectileType = ProjectileType::PROJECTILE_FIREBALL;
	mHitTorchwoodGridX = theGridX;
	mApp->PlayFoley(FoleyType::FOLEY_FIREPEA);

	float aOffsetX = -25.0f;
	float aOffsetY = -25.0f;
	Reanimation* aFirePeaReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FIRE_PEA);
	if (mMotionType == ProjectileMotion::MOTION_BACKWARDS)
	{
		aFirePeaReanim->OverrideScale(-1.0f, 1.0f);
		aOffsetX += 80.0f;
	}

	aFirePeaReanim->SetPosition(mPosX + aOffsetX, mPosY + aOffsetY);
	aFirePeaReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
	aFirePeaReanim->mAnimRate = RandRangeFloat(50.0f, 80.0f);
	AttachReanim(mAttachmentID, aFirePeaReanim, aOffsetX, aOffsetY);
}

//0x46EE00
void Projectile::ConvertToPea(int theGridX)
{
	if (mHitTorchwoodGridX == theGridX)
		return;

	AttachmentDie(mAttachmentID);
	mProjectileType = ProjectileType::PROJECTILE_PEA;
	mHitTorchwoodGridX = theGridX;
	mApp->PlayFoley(FoleyType::FOLEY_THROW);
}

ProjectileDefinition& Projectile::GetProjectileDef()
{
	ProjectileDefinition& aProjectileDef = gProjectileDefinition[(int)mProjectileType];
	TOD_ASSERT(aProjectileDef.mProjectileType == mProjectileType);

	return aProjectileDef;
}
