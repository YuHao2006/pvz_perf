#include "D3DInterface.h"
#include "DDInterface.h"
#include "Graphics.h"
#include "misc/AutoCrit.h"
#include "misc/SexyMatrix.h"
#include "SexyAppBase.h"
#include "TriVertex.h"
#include <assert.h>
#include <algorithm>
#include <cmath>
#include <cstdio>

#pragma warning(disable:4244)

using namespace Sexy;

static int gMinTextureWidth;
static int gMinTextureHeight;
static int gMaxTextureWidth;
static int gMaxTextureHeight;
static int gMaxTextureAspectRatio;
static DWORD gSupportedPixelFormats;
static bool gTextureSizeMustBePow2;
static const int MAX_TEXTURE_SIZE = 1024;
static bool gLinearFilter = false;
static bool gD3D11AddressWrap = false;
std::string D3DInterface::mErrorString;
static D3D11Renderer* gD3D11Renderer = NULL;
static int gD3D11CurrentDrawMode = 0;
static int gD3D11SceneWidth = 800;
static int gD3D11SceneHeight = 600;
bool gD3DInterfacePreDrawError = false;

// Primitive types kept local (D3D9 enum values) so the file has no D3D9 dep.
enum D3D11PrimitiveType
{
	D3D11PT_TRIANGLELIST = 0,
	D3D11PT_TRIANGLESTRIP = 1,
	D3D11PT_TRIANGLEFAN = 2
};

struct D3D8Vertex
{
	float sx, sy, sz, rhw;
	DWORD color;
	float tu, tv;
};

#define RGBA_MAKE(r, g, b, a) (((DWORD)(a) << 24) | ((DWORD)(r) << 16) | ((DWORD)(g) << 8) | (DWORD)(b))

struct VertexList
{
	enum { MAX_STACK_VERTS = 100 };
	D3D8Vertex mStackVerts[MAX_STACK_VERTS];
	D3D8Vertex *mVerts;
	int mSize;
	int mCapacity;

	typedef int size_type;

	VertexList() : mVerts(mStackVerts), mSize(0), mCapacity(MAX_STACK_VERTS) { }
	VertexList(const VertexList &theList) : mVerts(mStackVerts), mSize(theList.mSize), mCapacity(MAX_STACK_VERTS)
	{
		reserve(mSize);
		memcpy(mVerts, theList.mVerts, mSize*sizeof(mVerts[0]));
	}

	~VertexList()
	{
		if (mVerts != mStackVerts)
			delete mVerts;
	}

	void reserve(int theCapacity)
	{
		if (mCapacity < theCapacity)
		{
			mCapacity = theCapacity;
			D3D8Vertex *aNewList = new D3D8Vertex[theCapacity];
			memcpy(aNewList, mVerts, mSize*sizeof(mVerts[0]));
			if (mVerts != mStackVerts)
				delete mVerts;
			mVerts = aNewList;
		}
	}

	void push_back(const D3D8Vertex &theVert)
	{
		if (mSize == mCapacity)
			reserve(mCapacity*2);
		mVerts[mSize++] = theVert;
	}

	void operator=(const VertexList &theList)
	{
		reserve(theList.mSize);
		mSize = theList.mSize;
		memcpy(mVerts, theList.mVerts, mSize*sizeof(mVerts[0]));
	}

	D3D8Vertex& operator[](int thePos)
	{
		return mVerts[thePos];
	}

	int size() { return mSize; }
	void clear() { mSize = 0; }
};

static int GetClosestPowerOf2Above(int theNum)
{
	int aPower2 = 1;
	while (aPower2 < theNum)
		aPower2 <<= 1;
	return aPower2;
}

static bool IsPowerOf2(int theNum)
{
	int aNumBits = 0;
	while (theNum > 0)
	{
		aNumBits += theNum & 1;
		theNum >>= 1;
	}
	return aNumBits == 1;
}

static void GetBestTextureDimensions(int &theWidth, int &theHeight, bool isEdge, bool usePow2, DWORD theImageFlags)
{
	if (theImageFlags & D3DImageFlag_Use64By64Subdivisions)
	{
		theWidth = theHeight = 64;
		return;
	}

	static int aGoodTextureSize[MAX_TEXTURE_SIZE];
	static bool haveInited = false;
	if (!haveInited)
	{
		haveInited = true;
		int i;
		int aPow2 = 1;
		for (i=0; i<MAX_TEXTURE_SIZE; i++)
		{
			if (i > aPow2)
				aPow2 <<= 1;
			int aGoodValue = aPow2;
			if ((aGoodValue - i) > 64)
			{
				aGoodValue >>= 1;
				while (true)
				{
					int aLeftOver = i % aGoodValue;
					if (aLeftOver < 64 || IsPowerOf2(aLeftOver))
						break;
					aGoodValue >>= 1;
				}
			}
			aGoodTextureSize[i] = aGoodValue;
		}
	}

	int aWidth = theWidth;
	int aHeight = theHeight;

	if (usePow2)
	{
		if (isEdge || (theImageFlags & D3DImageFlag_MinimizeNumSubdivisions))
		{
			aWidth = aWidth >= gMaxTextureWidth ? gMaxTextureWidth : GetClosestPowerOf2Above(aWidth);
			aHeight = aHeight >= gMaxTextureHeight ? gMaxTextureHeight : GetClosestPowerOf2Above(aHeight);
		}
		else
		{
			aWidth = aWidth >= gMaxTextureWidth ? gMaxTextureWidth : aGoodTextureSize[aWidth];
			aHeight = aHeight >= gMaxTextureHeight ? gMaxTextureHeight : aGoodTextureSize[aHeight];
		}
	}

	if (aWidth < gMinTextureWidth)
		aWidth = gMinTextureWidth;
	if (aHeight < gMinTextureHeight)
		aHeight = gMinTextureHeight;

	if (aWidth > aHeight)
	{
		while (aWidth > gMaxTextureAspectRatio*aHeight)
			aHeight <<= 1;
	}
	else if (aHeight > aWidth)
	{
		while (aHeight > gMaxTextureAspectRatio*aWidth)
			aWidth <<= 1;
	}

	theWidth = aWidth;
	theHeight = aHeight;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool D3DInterface::CheckDXError(HRESULT theError, const char *theMsg)
{
	if (SUCCEEDED(theError))
		return false;
	FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
	if (aLog != NULL)
	{
		fprintf(aLog, "DX error hr=0x%08lx context=%s\n",
			(unsigned long)theError, theMsg != NULL ? theMsg : "");
		fclose(aLog);
	}
	mErrorString = theMsg != NULL ? theMsg : "D3D11 call failed";
	return true;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
D3DInterface::D3DInterface()
{
	mHWnd = NULL;
	mWidth = 640;
	mHeight = 480;
	mD3D11 = NULL;
	mPresentWidth = 0;
	mPresentHeight = 0;
	mSceneBegun = false;
	mIsWindowed = true;

	gMinTextureWidth = 64;
	gMinTextureHeight = 64;
	gMaxTextureWidth = 64;
	gMaxTextureHeight = 64;
	gMaxTextureAspectRatio = 1;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
D3DInterface::~D3DInterface()
{
	Cleanup();
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool D3DInterface::InitD3D()
{
	mPresentWidth = mPresentWidth > 0 ? mPresentWidth : mWidth;
	mPresentHeight = mPresentHeight > 0 ? mPresentHeight : mHeight;

	gTextureSizeMustBePow2 = true;
	gMinTextureWidth = 1;
	gMinTextureHeight = 1;
	gMaxTextureWidth = MAX_TEXTURE_SIZE;
	gMaxTextureHeight = MAX_TEXTURE_SIZE;
	gMaxTextureAspectRatio = 65536;
	gSupportedPixelFormats = PixelFormat_A8R8G8B8;
	gLinearFilter = false;
	gD3D11AddressWrap = false;

	mD3D11 = new D3D11Renderer();
	if (!mD3D11->Init(mHWnd, mWidth, mHeight, mPresentWidth, mPresentHeight))
	{
		FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
		if (aLog != NULL)
		{
			fprintf(aLog, "init-failed\n");
			fclose(aLog);
		}
		delete mD3D11;
		mD3D11 = NULL;
		return false;
	}

	FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
	if (aLog != NULL)
	{
		fprintf(aLog, "ok scene=%dx%d present=%dx%d renderer=%p\n", mWidth, mHeight, mPresentWidth, mPresentHeight, (void*)mD3D11);
		fclose(aLog);
	}
	gD3D11Renderer = mD3D11;
	gD3D11SceneWidth = mWidth;
	gD3D11SceneHeight = mHeight;
	return true;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool D3DInterface::InitFromDDInterface(DDInterface *theInterface)
{
	mErrorString.erase();

	mHWnd = theInterface->mHWnd;
	mWidth = theInterface->mWidth;
	mHeight = theInterface->mHeight;
	mPresentWidth = theInterface->mDisplayWidth;
	mPresentHeight = theInterface->mDisplayHeight;
	mIsWindowed = theInterface->mIsWindowed;

	return InitD3D();
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool D3DInterface::ResizePresent(int thePresentWidth, int thePresentHeight)
{
	if (mD3D11 == NULL)
		return false;
	// A mode request can arrive from a widget/message while the current frame
	// is between PreDraw and Flush.  Finish that frame before ResizeBuffers;
	// otherwise ClearState leaves the renderer with mSceneBegun==true and the
	// next draw skips BeginScene, targeting an unbound render target.
	if (mSceneBegun)
		Flush();
	if (!mD3D11->ResizeSwapChain(thePresentWidth, thePresentHeight))
	{
		mErrorString = "ResizeSwapChain failed";
		return false;
	}
	mPresentWidth = thePresentWidth;
	mPresentHeight = thePresentHeight;
	return true;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool D3DInterface::PreDraw()
{
	if (gSexyAppBase->mPhysMinimized)
		return false;

	if (mD3D11 == NULL)
		return false;

	if (!mSceneBegun)
	{
		mD3D11->BeginScene();
		mSceneBegun = true;
	}
	return true;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::SetSamplerAddressWrap(bool theWrap)
{
	gD3D11AddressWrap = theWrap;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::SetupDrawMode(int theDrawMode, const Color &theColor, Image *theImage)
{
	(void)theColor;
	(void)theImage;
	// D3D11 renderer selects the blend state at submit time.
	gD3D11CurrentDrawMode = theDrawMode;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
static void SetLinearFilter(bool linear)
{
	gLinearFilter = linear;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
static void CopyImageToTexture8888(void *theDest, DWORD theDestPitch, MemoryImage *theImage, int offx, int offy, int theWidth, int theHeight, bool rightPad, int thePieceHeight)
{
	if (theImage->mColorTable == NULL)
	{
		DWORD *srcRow = theImage->GetBits() + offy * theImage->GetWidth() + offx;
		char *dstRow = (char*)theDest;

		for(int y=0; y<theHeight; y++)
		{
			DWORD *dst = (DWORD*)dstRow;
			// Both buffers are already A8R8G8B8. Copy the complete row instead
			// of moving each pixel individually; padding semantics below remain
			// byte-for-byte identical.
			memcpy(dst, srcRow, (size_t)theWidth * sizeof(DWORD));
			dst += theWidth;

			if (rightPad)
				*dst = *(dst-1);

			srcRow += theImage->GetWidth();
			dstRow += theDestPitch;
		}
	}
	else // palette
	{
		uchar *srcRow = (uchar*)theImage->mColorIndices + offy * theImage->GetWidth() + offx;
		uchar *dstRow = (uchar*)theDest;
		DWORD *palette = theImage->mColorTable;

		for(int y=0; y<theHeight; y++)
		{
			uchar *src = srcRow;
			DWORD *dst = (DWORD*)dstRow;
			for(int x=0; x<theWidth; x++)
				*dst++ = palette[*src++];

			if (rightPad)
				*dst = *(dst-1);

			srcRow += theImage->GetWidth();
			dstRow += theDestPitch;
		}
	}

	// Match the original bottomPad: copy the last valid row into the padding
	// row below the content so vertical linear filtering never samples zeros.
	if (theHeight < thePieceHeight)
	{
		char *dstRow = (char*)theDest + theDestPitch * theHeight;
		char *srcRow = dstRow - theDestPitch;
		memcpy(dstRow, srcRow, theDestPitch);
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
TextureData::TextureData()
{
	mWidth = 0;
	mHeight = 0;
	mTexVecWidth = 0;
	mTexVecHeight = 0;
	mBitsChangedCount = 0;
	mTexMemSize = 0;
	mTexPieceWidth = 64;
	mTexPieceHeight = 64;
	mPixelFormat = PixelFormat_Unknown;
	mImageFlags = 0;
	mMaxTotalU = 1.0f;
	mMaxTotalV = 1.0f;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
TextureData::~TextureData()
{
	ReleaseTextures();
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::ReleaseTextures()
{
	for (TextureVector::iterator anItr = mTextures.begin(); anItr != mTextures.end(); ++anItr)
	{
		if (anItr->mSRV11 != NULL)
		{
			anItr->mSRV11->Release();
			anItr->mSRV11 = NULL;
		}
	}
	mTextures.clear();
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::CreateTextureDimensions(MemoryImage *theImage)
{
	int aWidth = theImage->GetWidth();
	int aHeight = theImage->GetHeight();
	int i;

	// Calculate inner piece sizes
	mTexPieceWidth = aWidth;
	mTexPieceHeight = aHeight;
	bool usePow2 = true;
	GetBestTextureDimensions(mTexPieceWidth, mTexPieceHeight, false, usePow2, mImageFlags);

	// Calculate right boundary piece sizes
	int aRightWidth = aWidth % mTexPieceWidth;
	int aRightHeight = mTexPieceHeight;
	if (aRightWidth > 0)
		GetBestTextureDimensions(aRightWidth, aRightHeight, true, usePow2, mImageFlags);
	else
		aRightWidth = mTexPieceWidth;

	// Calculate bottom boundary piece sizes
	int aBottomWidth = mTexPieceWidth;
	int aBottomHeight = aHeight % mTexPieceHeight;
	if (aBottomHeight > 0)
		GetBestTextureDimensions(aBottomWidth, aBottomHeight, true, usePow2, mImageFlags);
	else
		aBottomHeight = mTexPieceHeight;

	// Calculate corner piece size
	int aCornerWidth = aRightWidth;
	int aCornerHeight = aBottomHeight;
	GetBestTextureDimensions(aCornerWidth, aCornerHeight, true, usePow2, mImageFlags);

	// Allocate texture array
	mTexVecWidth = (aWidth + mTexPieceWidth - 1) / mTexPieceWidth;
	mTexVecHeight = (aHeight + mTexPieceHeight - 1) / mTexPieceHeight;
	mTextures.resize(mTexVecWidth * mTexVecHeight);

	// Assign inner pieces
	for(i=0; i<(int)mTextures.size(); i++)
	{
		TextureDataPiece &aPiece = mTextures[i];
		aPiece.mSRV11 = NULL;
		aPiece.mWidth = mTexPieceWidth;
		aPiece.mHeight = mTexPieceHeight;
	}

	// Assign right pieces
	for(i=mTexVecWidth-1; i<(int)mTextures.size(); i+=mTexVecWidth)
	{
		TextureDataPiece &aPiece = mTextures[i];
		aPiece.mWidth = aRightWidth;
		aPiece.mHeight = aRightHeight;
	}

	// Assign bottom pieces
	for(i=mTexVecWidth*(mTexVecHeight-1); i<(int)mTextures.size(); i++)
	{
		TextureDataPiece &aPiece = mTextures[i];
		aPiece.mWidth = aBottomWidth;
		aPiece.mHeight = aBottomHeight;
	}

	// Assign corner piece
	mTextures.back().mWidth = aCornerWidth;
	mTextures.back().mHeight = aCornerHeight;

	mMaxTotalU = aWidth/(float)mTexPieceWidth;
	mMaxTotalV = aHeight/(float)mTexPieceHeight;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::CreateTextures(MemoryImage *theImage)
{
	theImage->DeleteSWBuffers();
	theImage->CommitBits();

	// D3D11 always uploads 32-bit ARGB from the CPU bits.
	PixelFormat aFormat = PixelFormat_A8R8G8B8;

	if (mWidth != theImage->mWidth || mHeight != theImage->mHeight || aFormat != mPixelFormat || theImage->mD3DFlags != mImageFlags)
	{
		ReleaseTextures();
		mPixelFormat = aFormat;
		mImageFlags = theImage->mD3DFlags;
		CreateTextureDimensions(theImage);
	}

	int i, x, y;
	int aHeight = theImage->GetHeight();
	int aWidth = theImage->GetWidth();
	DWORD* aSourceBits = theImage->mColorTable == NULL ? theImage->GetBits() : NULL;

	i = 0;
	for(y=0; y<aHeight; y+=mTexPieceHeight)
	{
		for(x=0; x<aWidth; x+=mTexPieceWidth, i++)
		{
			TextureDataPiece &aPiece = mTextures[i];
			if (aPiece.mSRV11 != NULL)
			{
				aPiece.mSRV11->Release();
				aPiece.mSRV11 = NULL;
			}

			bool aHasSourceBits = theImage->mColorTable != NULL || aSourceBits != NULL;
			if (aHasSourceBits)
			{
				int aPieceW = aPiece.mWidth;
				int aPieceH = aPiece.mHeight;
				// CreateTexture2D consumes SUBRESOURCE_DATA synchronously. For any
				// complete non-edge piece it can read the stable MemoryImage buffer
				// directly, eliminating the redundant CPU staging copy. The source
				// row pitch may be wider than the piece; D3D11 advances by that pitch.
				const int aCopyW = std::min(aPieceW, aWidth - x);
				const int aCopyH = std::min(aPieceH, aHeight - y);
				const bool aCanDirectUpload =
					aSourceBits != NULL &&
					aCopyW == aPieceW && aCopyH == aPieceH &&
					x + aPieceW <= aWidth && y + aPieceH <= aHeight;
				if (aCanDirectUpload)
				{
					bool aOpaque = !theImage->mHasAlpha && !theImage->mHasTrans;
					aPiece.mSRV11 = gD3D11Renderer->CreateTextureSRV(
						aPieceW, aPieceH, aSourceBits + y * aWidth + x, aWidth * 4, aOpaque);
					continue;
				}
				std::vector<uint32_t> aBits((size_t)aPieceW * aPieceH);
				// Clamp the copy to the source image's remaining extent (edge
				// pieces are padded up to the texture piece size); the rest of
				// aBits stays zero-initialized.
				if (aCopyW > 0 && aCopyH > 0)
					// Match the original D3D7 upload: edge pieces are
					// right-padded with the last valid texel (rightPad=true)
					// so linear filtering during stretched draws never samples
					// the zero padding (the 8x SelectorScreen_BG right edge).
					CopyImageToTexture8888(aBits.data(), aPieceW * 4, theImage, x, y, aCopyW, aCopyH, true, aPieceH);
				// Opaque images use B8G8R8X8 (alpha ignored); D3D11 has no true
				// 24-bit format, so storage stays 32-bit either way.
				bool aOpaque = !theImage->mHasAlpha && !theImage->mHasTrans;
				aPiece.mSRV11 = gD3D11Renderer->CreateTextureSRV(
					aPieceW,
					aPieceH,
					aBits.data(),
					aPieceW * 4,
					aOpaque);
			}
		}
	}

	mWidth = theImage->mWidth;
	mHeight = theImage->mHeight;
	mBitsChangedCount = theImage->mBitsChangedCount;
	mPixelFormat = aFormat;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::CheckCreateTextures(MemoryImage *theImage)
{
	if (mPixelFormat == PixelFormat_Unknown || theImage->mWidth != mWidth || theImage->mHeight != mHeight || theImage->mBitsChangedCount != mBitsChangedCount || theImage->mD3DFlags != mImageFlags)
		CreateTextures(theImage);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
ID3D11ShaderResourceView* TextureData::GetTexture11(int x, int y, int &width, int &height, float &u1, float &v1, float &u2, float &v2)
{
	int tx = x/mTexPieceWidth;
	int ty = y/mTexPieceHeight;

	TextureDataPiece &aPiece = mTextures[ty*mTexVecWidth + tx];

	int left = x%mTexPieceWidth;
	int top = y%mTexPieceHeight;
	int right = left+width;
	int bottom = top+height;

	if(right > aPiece.mWidth)
		right = aPiece.mWidth;
	if(bottom > aPiece.mHeight)
		bottom = aPiece.mHeight;

	width = right-left;
	height = bottom-top;

	// Exact-edge UVs, matching the original GetTexture. Bleeding into edge
	// padding is prevented the same way as the original: edge pieces are
	// right-padded with the last valid texel at upload time (rightPad=true).
	u1 = (float)left / aPiece.mWidth;
	v1 = (float)top / aPiece.mHeight;
	u2 = (float)right / aPiece.mWidth;
	v2 = (float)bottom / aPiece.mHeight;

	return aPiece.mSRV11;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
ID3D11ShaderResourceView* TextureData::GetTexture11F(float x, float y, float &width, float &height, float &u1, float &v1, float &u2, float &v2)
{
	int tx = (int)(x / mTexPieceWidth);
	int ty = (int)(y / mTexPieceHeight);

	TextureDataPiece &aPiece = mTextures[ty*mTexVecWidth + tx];

	float left = x - tx*mTexPieceWidth;
	float top = y - ty*mTexPieceHeight;
	float right = left + width;
	float bottom = top + height;

	if (right > aPiece.mWidth)
		right = (float)aPiece.mWidth;
	if (bottom > aPiece.mHeight)
		bottom = (float)aPiece.mHeight;

	width = right - left;
	height = bottom - top;

	u1 = left / aPiece.mWidth;
	v1 = top / aPiece.mHeight;
	u2 = right / aPiece.mWidth;
	v2 = bottom / aPiece.mHeight;

	return aPiece.mSRV11;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
static void SubmitD3D11Triangles(
	const D3D8Vertex* theVertices,
	int theNumVertices,
	D3D11PrimitiveType theType,
	ID3D11ShaderResourceView* theSRV,
	bool theLinearFilter,
	int theDrawMode,
	const Rect* theClipRect)
{
	if (gD3D11Renderer == NULL || theNumVertices <= 0)
		return;
	int aDrawMode = theDrawMode < 0 ? gD3D11CurrentDrawMode : theDrawMode;

	D3D11Vertex aConverted[4096];
	int aCount = 0;

	auto ConvertVertex = [&](const D3D8Vertex& theVertex)
	{
		D3D11Vertex& aOut = aConverted[aCount++];
		aOut.mX = theVertex.sx;
		aOut.mY = theVertex.sy;
		aOut.mR = ((theVertex.color >> 16) & 0xFF) / 255.0f;
		aOut.mG = ((theVertex.color >> 8) & 0xFF) / 255.0f;
		aOut.mB = (theVertex.color & 0xFF) / 255.0f;
		aOut.mA = ((theVertex.color >> 24) & 0xFF) / 255.0f;
		aOut.mU = theVertex.tu;
		aOut.mV = theVertex.tv;
	};

	if (theType == D3D11PT_TRIANGLESTRIP)
	{
		for (int i = 0; i + 2 < theNumVertices && aCount + 3 <= 4096; i++)
		{
			ConvertVertex(theVertices[i]);
			ConvertVertex(theVertices[i + 1]);
			ConvertVertex(theVertices[i + 2]);
		}
	}
	else if (theType == D3D11PT_TRIANGLEFAN)
	{
		for (int i = 1; i + 1 < theNumVertices && aCount + 3 <= 4096; i++)
		{
			ConvertVertex(theVertices[0]);
			ConvertVertex(theVertices[i]);
			ConvertVertex(theVertices[i + 1]);
		}
	}
	else
	{
		for (int i = 0; i < theNumVertices && aCount < 4096; i++)
			ConvertVertex(theVertices[i]);
	}

	gD3D11Renderer->SubmitTriangles(
		aConverted,
		aCount,
		theSRV,
		theLinearFilter,
		gD3D11AddressWrap,
		aDrawMode,
		theClipRect,
		gD3D11SceneWidth,
		gD3D11SceneHeight);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
template<class Pred>
struct PointClipper
{
	Pred mPred;

	float GetCoord(const D3D8Vertex &theVertex, int n)
	{
		if (n == 0)
			return theVertex.sx;
		if (n == 1)
			return theVertex.sy;
		if (n == 3)
			return theVertex.tu;
		return theVertex.tv;
	}

	void SetCoord(D3D8Vertex &theVertex, int n, float theValue)
	{
		if (n == 0)
			theVertex.sx = theValue;
		else if (n == 1)
			theVertex.sy = theValue;
		else if (n == 3)
			theVertex.tu = theValue;
		else
			theVertex.tv = theValue;
	}

	D3D8Vertex Interpolate(const D3D8Vertex &v1, const D3D8Vertex &v2, float t)
	{
		D3D8Vertex result;
		result.sx = v1.sx + (v2.sx-v1.sx)*t;
		result.sy = v1.sy + (v2.sy-v1.sy)*t;
		result.sz = v1.sz + (v2.sz-v1.sz)*t;
		result.rhw = v1.rhw + (v2.rhw-v1.rhw)*t;
		result.color = v1.color;
		result.tu = v1.tu + (v2.tu-v1.tu)*t;
		result.tv = v1.tv + (v2.tv-v1.tv)*t;
		return result;
	}

	void ClipPoint(int n, float clipVal, D3D8Vertex &v1, D3D8Vertex &v2, VertexList &out)
	{
		float aV1 = GetCoord(v1,n);
		float aV2 = GetCoord(v2,n);
		// Inside means the coordinate survives this clip. The original
		// clip keeps NOT-mPred: less() keeps coord >= left, greater_equal()
		// keeps coord < right, so the polygon stays inside the rect.
		bool aV1Inside = !mPred(aV1, clipVal);
		bool aV2Inside = !mPred(aV2, clipVal);

		if (aV1Inside && aV2Inside)
		{
			out.push_back(v2);
		}
		else if (aV1Inside && !aV2Inside)
		{
			float t = (clipVal - aV1) / (aV2 - aV1);
			out.push_back(Interpolate(v1, v2, t));
		}
		else if (!aV1Inside && aV2Inside)
		{
			float t = (clipVal - aV1) / (aV2 - aV1);
			out.push_back(Interpolate(v1, v2, t));
			out.push_back(v2);
		}
	}

	void ClipPoints(int n, float clipVal, VertexList &in, VertexList &out)
	{
		if (in.size() < 2)
			return;
		ClipPoint(n, clipVal, in[in.size()-1], in[0], out);
		for (VertexList::size_type i=0; i<in.size()-1; i++)
			ClipPoint(n, clipVal, in[i], in[i+1], out);
	}
};

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
static void DrawPolyClipped11(const Rect *theClipRect, const VertexList &theList, ID3D11ShaderResourceView* theSRV)
{
	VertexList l1, l2;
	l1 = theList;

	int left = theClipRect->mX;
	int right = left + theClipRect->mWidth;
	int top = theClipRect->mY;
	int bottom = top + theClipRect->mHeight;

	VertexList *in = &l1, *out = &l2;
	PointClipper<std::less<float> > aLessClipper;
	PointClipper<std::greater_equal<float> > aGreaterClipper;

	aLessClipper.ClipPoints(0, left, *in, *out); std::swap(in, out); out->clear();
	aLessClipper.ClipPoints(1, top, *in, *out); std::swap(in, out); out->clear();
	aGreaterClipper.ClipPoints(0, right, *in, *out); std::swap(in, out); out->clear();
	aGreaterClipper.ClipPoints(1, bottom, *in, *out);

	VertexList &aList = *out;
	if (aList.size() >= 3)
		SubmitD3D11Triangles(&aList[0], (int)aList.size(), D3D11PT_TRIANGLEFAN, theSRV, gLinearFilter, -1, NULL);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
static void DoPolyTextureClip(VertexList &theList)
{
	VertexList l2;

	float left = 0;
	float right = 1;
	float top = 0;
	float bottom = 1;

	VertexList *in = &theList, *out = &l2;
	PointClipper<std::less<float> > aLessClipper;
	PointClipper<std::greater_equal<float> > aGreaterClipper;

	aLessClipper.ClipPoints(3, left, *in, *out); std::swap(in, out); out->clear();
	aLessClipper.ClipPoints(4, top, *in, *out); std::swap(in, out); out->clear();
	aGreaterClipper.ClipPoints(3, right, *in, *out); std::swap(in, out); out->clear();
	aGreaterClipper.ClipPoints(4, bottom, *in, *out);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::Blt(float theX, float theY, const Rect& theSrcRect, const Color& theColor)
{
	int srcLeft = theSrcRect.mX;
	int srcTop = theSrcRect.mY;
	int srcRight = srcLeft + theSrcRect.mWidth;
	int srcBottom = srcTop + theSrcRect.mHeight;
	int srcX, srcY;
	float dstX, dstY;
	int aWidth, aHeight;
	float u1, v1, u2, v2;

	srcY = srcTop;
	dstY = theY;

	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);

	if ((srcLeft >= srcRight) || (srcTop >= srcBottom))
		return;

	while (srcY < srcBottom)
	{
		srcX = srcLeft;
		dstX = theX;
		while (srcX < srcRight)
		{
			aWidth = srcRight - srcX;
			aHeight = srcBottom - srcY;
			ID3D11ShaderResourceView* aSRV11 = GetTexture11(srcX, srcY, aWidth, aHeight, u1, v1, u2, v2);

			// D3D11 maps integer coordinates to the top-left corner of the
			// corresponding pixel (the vertex shader divides by the viewport
			// size). D3D9 needed a -0.5 pixel-center correction; D3D11 does
			// not, and keeping it shifts every 1:1 blit half a pixel so the
			// right/bottom edge pixels are never covered (green strip under
			// full-screen fades, faint thin font strokes).
			float x = dstX;
			float y = dstY;

			D3D8Vertex aVertex[4] =
			{
				{ x, y, 0, 1, aColor, u1, v1 },
				{ x, y + aHeight, 0, 1, aColor, u1, v2 },
				{ x + aWidth, y, 0, 1, aColor, u2, v1 },
				{ x + aWidth, y + aHeight, 0, 1, aColor, u2, v2 }
			};

			SubmitD3D11Triangles(aVertex, 4, D3D11PT_TRIANGLESTRIP, aSRV11, gLinearFilter, -1, NULL);

			srcX += aWidth;
			dstX += aWidth;
		}
		srcY += aHeight;
		dstY += aHeight;
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::BltTransformed(const SexyMatrix3 &theTrans, const Rect& theSrcRect, const Color& theColor, const Rect *theClipRect, float theX, float theY, bool center)
{
	int srcLeft = theSrcRect.mX;
	int srcTop = theSrcRect.mY;
	int srcRight = srcLeft + theSrcRect.mWidth;
	int srcBottom = srcTop + theSrcRect.mHeight;
	int srcX, srcY;
	float dstX, dstY;
	int aWidth;
	int aHeight;
	float u1, v1, u2, v2;
	float startx = 0, starty = 0;

	if (center)
	{
		startx = -theSrcRect.mWidth/2.0f;
		starty = -theSrcRect.mHeight/2.0f;
	}

	srcY = srcTop;
	dstY = starty;

	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);

	if ((srcLeft >= srcRight) || (srcTop >= srcBottom))
		return;

	while (srcY < srcBottom)
	{
		srcX = srcLeft;
		dstX = startx;
		while (srcX < srcRight)
		{
			aWidth = srcRight - srcX;
			aHeight = srcBottom - srcY;
			ID3D11ShaderResourceView* aSRV11 = GetTexture11(srcX, srcY, aWidth, aHeight, u1, v1, u2, v2);

			float x = dstX;
			float y = dstY;

			SexyVector2 p[4] = { SexyVector2(x, y), SexyVector2(x, y+aHeight), SexyVector2(x+aWidth, y), SexyVector2(x+aWidth, y+aHeight) };
			SexyVector2 tp[4];

			int i;
			for (i=0; i<4; i++)
			{
				tp[i] = theTrans*p[i];
				// D3D11 has no D3D9-style pixel-center half-offset; the
				// transform already maps integer coordinates to pixel corners.
				tp[i].x += theX;
				tp[i].y += theY;
			}

			D3D8Vertex aVertex[4] =
			{
				{ tp[0].x, tp[0].y, 0, 1, aColor, u1, v1 },
				{ tp[1].x, tp[1].y, 0, 1, aColor, u1, v2 },
				{ tp[2].x, tp[2].y, 0, 1, aColor, u2, v1 },
				{ tp[3].x, tp[3].y, 0, 1, aColor, u2, v2 }
			};

			// CPU polygon clipping (the GPU scissor is disabled to avoid
			// driver faults).
			if (theClipRect != NULL)
			{
				VertexList aList;
				aList.push_back(aVertex[0]);
				aList.push_back(aVertex[1]);
				aList.push_back(aVertex[3]);
				aList.push_back(aVertex[2]);
				DrawPolyClipped11(theClipRect, aList, aSRV11);
			}
			else
				SubmitD3D11Triangles(aVertex, 4, D3D11PT_TRIANGLESTRIP, aSRV11, gLinearFilter, -1, NULL);

			srcX += aWidth;
			dstX += aWidth;
		}
		srcY += aHeight;
		dstY += aHeight;
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
#define GetColorFromTriVertex(theVertex, theColor) (theVertex.color?theVertex.color:theColor)

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void TextureData::BltTriangles(const TriVertex theVertices[][3], int theNumTriangles, DWORD theColor, float tx, float ty)
{
	if ((mMaxTotalU <= 1.0) && (mMaxTotalV <= 1.0))
	{
		D3D8Vertex aVertexCache[100][3];
		int aVertexCacheNum = 0;

		for (int aTriangleNum = 0; aTriangleNum < theNumTriangles; aTriangleNum++)
		{
			TriVertex* aTriVerts = (TriVertex*) theVertices[aTriangleNum];
			D3D8Vertex* aD3DVertex = (D3D8Vertex*) aVertexCache[aVertexCacheNum++];

			aD3DVertex[0].sx = aTriVerts[0].x + tx;
			aD3DVertex[0].sy = aTriVerts[0].y + ty;
			aD3DVertex[0].sz = 0;
			aD3DVertex[0].rhw = 1;
			aD3DVertex[0].color = GetColorFromTriVertex(aTriVerts[0], theColor);
			aD3DVertex[0].tu = aTriVerts[0].u * mMaxTotalU;
			aD3DVertex[0].tv = aTriVerts[0].v * mMaxTotalV;

			aD3DVertex[1].sx = aTriVerts[1].x + tx;
			aD3DVertex[1].sy = aTriVerts[1].y + ty;
			aD3DVertex[1].sz = 0;
			aD3DVertex[1].rhw = 1;
			aD3DVertex[1].color = GetColorFromTriVertex(aTriVerts[1], theColor);
			aD3DVertex[1].tu = aTriVerts[1].u * mMaxTotalU;
			aD3DVertex[1].tv = aTriVerts[1].v * mMaxTotalV;

			aD3DVertex[2].sx = aTriVerts[2].x + tx;
			aD3DVertex[2].sy = aTriVerts[2].y + ty;
			aD3DVertex[2].sz = 0;
			aD3DVertex[2].rhw = 1;
			aD3DVertex[2].color = GetColorFromTriVertex(aTriVerts[2], theColor);
			aD3DVertex[2].tu = aTriVerts[2].u * mMaxTotalU;
			aD3DVertex[2].tv = aTriVerts[2].v * mMaxTotalV;

			if ((aVertexCacheNum == 100) || (aTriangleNum == theNumTriangles - 1))
			{
				// aVertexCacheNum counts triangles; every triangle holds three
				// vertices, and the D3D11 submitter takes a vertex count.
				SubmitD3D11Triangles((D3D8Vertex*)aVertexCache, aVertexCacheNum * 3, D3D11PT_TRIANGLELIST, mTextures[0].mSRV11, gLinearFilter, -1, NULL);
				aVertexCacheNum = 0;
			}
		}
	}
	else
	{
		for (int aTriangleNum = 0; aTriangleNum < theNumTriangles; aTriangleNum++)
		{
			TriVertex* aTriVerts = (TriVertex*) theVertices[aTriangleNum];

			D3D8Vertex aVertex[3] =
			{
				{ aTriVerts[0].x + tx, aTriVerts[0].y + ty, 0, 1, GetColorFromTriVertex(aTriVerts[0], theColor), aTriVerts[0].u*mMaxTotalU, aTriVerts[0].v*mMaxTotalV },
				{ aTriVerts[1].x + tx, aTriVerts[1].y + ty, 0, 1, GetColorFromTriVertex(aTriVerts[1], theColor), aTriVerts[1].u*mMaxTotalU, aTriVerts[1].v*mMaxTotalV },
				{ aTriVerts[2].x + tx, aTriVerts[2].y + ty, 0, 1, GetColorFromTriVertex(aTriVerts[2], theColor), aTriVerts[2].u*mMaxTotalU, aTriVerts[2].v*mMaxTotalV }
			};

			float aMinU = mMaxTotalU, aMinV = mMaxTotalV;
			float aMaxU = 0, aMaxV = 0;

			int i, j, k;
			for (i=0; i<3; i++)
			{
				if (aVertex[i].tu < aMinU) aMinU = aVertex[i].tu;
				if (aVertex[i].tv < aMinV) aMinV = aVertex[i].tv;
				if (aVertex[i].tu > aMaxU) aMaxU = aVertex[i].tu;
				if (aVertex[i].tv > aMaxV) aMaxV = aVertex[i].tv;
			}

			VertexList aMasterList;
			aMasterList.push_back(aVertex[0]);
			aMasterList.push_back(aVertex[1]);
			aMasterList.push_back(aVertex[2]);

			int aLeft = floorf(aMinU);
			int aTop = floorf(aMinV);
			int aRight = ceilf(aMaxU);
			int aBottom = ceilf(aMaxV);
			if (aLeft < 0) aLeft = 0;
			if (aTop < 0) aTop = 0;
			if (aRight > mTexVecWidth) aRight = mTexVecWidth;
			if (aBottom > mTexVecHeight) aBottom = mTexVecHeight;

			TextureDataPiece &aStandardPiece = mTextures[0];
			for (i=aTop; i<aBottom; i++)
			{
				for (j=aLeft; j<aRight; j++)
				{
					TextureDataPiece &aPiece = mTextures[i*mTexVecWidth + j];

					VertexList aList = aMasterList;
					for (k=0; k<3; k++)
					{
						aList[k].tu -= j;
						aList[k].tv -= i;
						if (i == mTexVecHeight-1)
							aList[k].tv *= (float)aStandardPiece.mHeight / aPiece.mHeight;
						if (j == mTexVecWidth-1)
							aList[k].tu *= (float)aStandardPiece.mWidth / aPiece.mWidth;
					}

					DoPolyTextureClip(aList);
					if (aList.size() >= 3)
						SubmitD3D11Triangles(&aList[0], (int)aList.size(), D3D11PT_TRIANGLEFAN, aPiece.mSRV11, gLinearFilter, -1, NULL);
				}
			}
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool D3DInterface::CreateImageTexture(MemoryImage *theImage)
{
	bool wantPurge = false;

	if (theImage->mD3DData == NULL)
	{
		theImage->mD3DData = new TextureData();
		wantPurge = theImage->mPurgeBits;

		AutoCrit aCrit(gSexyAppBase->mDDInterface->mCritSect);
		mImageSet.insert(theImage);
	}

	TextureData *aData = (TextureData*)theImage->mD3DData;
	aData->CheckCreateTextures(theImage);

	// D3D11 owns the atlas SRVs straight from the CPU bits. Never purge the
	// bits: a screen-mode/scale rebuild destroys the SRVs and must be able to
	// re-upload from memory, otherwise purged images (large backgrounds)
	// would come back as transparent black.
	if (wantPurge && gD3D11Renderer == NULL)
		theImage->PurgeBits();

	return aData->mPixelFormat != PixelFormat_Unknown;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::RemoveMemoryImage(MemoryImage *theImage)
{
	if (theImage->mD3DData != NULL)
	{
		delete (TextureData*)theImage->mD3DData;
		theImage->mD3DData = NULL;

		AutoCrit aCrit(gSexyAppBase->mDDInterface->mCritSect);
		mImageSet.erase(theImage);
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::Cleanup()
{
	Flush();

	ImageSet::iterator anItr;
	for (anItr = mImageSet.begin(); anItr != mImageSet.end(); ++anItr)
	{
		MemoryImage *anImage = *anItr;
		// Keep CPU bits around in case the image is re-uploaded after a
		// renderer rebuild.
		if (anImage->mBits == NULL && anImage->mColorIndices == NULL)
			anImage->GetBits();
		delete (TextureData*)anImage->mD3DData;
		anImage->mD3DData = NULL;
	}
	mImageSet.clear();

	if (mD3D11 != NULL)
	{
		delete mD3D11;
		mD3D11 = NULL;
		gD3D11Renderer = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::SetCurTexture(MemoryImage *theImage)
{
	CreateImageTexture(theImage);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::PushTransform(const SexyMatrix3 &theTransform, bool concatenate)
{
	if (concatenate && !mTransformStack.empty())
		mTransformStack.push_back(mTransformStack.back() * theTransform);
	else
		mTransformStack.push_back(theTransform);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::PopTransform()
{
	if (!mTransformStack.empty())
		mTransformStack.pop_back();
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::Blt(Image* theImage, float theX, float theY, const Rect& theSrcRect, const Color& theColor, int theDrawMode, bool linearFilter)
{
	if (!mTransformStack.empty())
	{
		BltClipF(theImage, theX, theY, theSrcRect, NULL, theColor, theDrawMode);
		return;
	}

	if (!PreDraw())
		return;

	MemoryImage* aSrcMemoryImage = (MemoryImage*) theImage;
	if (!CreateImageTexture(aSrcMemoryImage))
		return;

	SetupDrawMode(theDrawMode, theColor, theImage);
	TextureData *aData = (TextureData*)aSrcMemoryImage->mD3DData;

	SetLinearFilter(linearFilter);
	aData->Blt(theX, theY, theSrcRect, theColor);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::BltMirror(Image* theImage, float theX, float theY, const Rect& theSrcRect, const Color& theColor, int theDrawMode, bool linearFilter)
{
	SexyTransform2D aTransform;
	aTransform.Translate(-theSrcRect.mWidth, 0);
	aTransform.Scale(-1, 1);
	aTransform.Translate(theX, theY);
	BltTransformed(theImage, NULL, theColor, theDrawMode, theSrcRect, aTransform, linearFilter);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::BltClipF(Image* theImage, float theX, float theY, const Rect& theSrcRect, const Rect *theClipRect, const Color& theColor, int theDrawMode)
{
	SexyTransform2D aTransform;
	aTransform.Translate(theX, theY);
	BltTransformed(theImage, theClipRect, theColor, theDrawMode, theSrcRect, aTransform, true);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::StretchBlt(Image* theImage, const Rect& theDestRect, const Rect& theSrcRect, const Rect* theClipRect, const Color &theColor, int theDrawMode, bool fastStretch, bool mirror)
{
	float xScale = (float)theDestRect.mWidth / theSrcRect.mWidth;
	float yScale = (float)theDestRect.mHeight / theSrcRect.mHeight;

	SexyTransform2D aTransform;
	if (mirror)
	{
		aTransform.Translate(-theSrcRect.mWidth, 0);
		aTransform.Scale(-xScale, yScale);
	}
	else
		aTransform.Scale(xScale, yScale);

	aTransform.Translate(theDestRect.mX, theDestRect.mY);
	BltTransformed(theImage, theClipRect, theColor, theDrawMode, theSrcRect, aTransform, !fastStretch);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::BltRotated(Image* theImage, float theX, float theY, const Rect* theClipRect, const Color& theColor, int theDrawMode, double theRot, float theRotCenterX, float theRotCenterY, const Rect &theSrcRect)
{
	SexyTransform2D aTransform;
	aTransform.Translate(-theRotCenterX, -theRotCenterY);
	aTransform.RotateRad(theRot);
	aTransform.Translate(theX + theRotCenterX, theY + theRotCenterY);
	BltTransformed(theImage, theClipRect, theColor, theDrawMode, theSrcRect, aTransform, true);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::BltTransformed(Image* theImage, const Rect* theClipRect, const Color& theColor, int theDrawMode, const Rect &theSrcRect, const SexyMatrix3 &theTransform, bool linearFilter, float theX, float theY, bool center)
{
	if (!PreDraw())
		return;

	MemoryImage* aSrcMemoryImage = (MemoryImage*) theImage;
	if (!CreateImageTexture(aSrcMemoryImage))
		return;

	SetupDrawMode(theDrawMode, theColor, theImage);
	TextureData *aData = (TextureData*)aSrcMemoryImage->mD3DData;

	if (!mTransformStack.empty())
	{
		SetLinearFilter(true);
		if (theX != 0 || theY != 0)
		{
			SexyTransform2D aTransform;
			if (center)
				aTransform.Translate(-theSrcRect.mWidth/2.0f, -theSrcRect.mHeight/2.0f);
			aTransform = theTransform * aTransform;
			aTransform.Translate(theX, theY);
			aTransform = mTransformStack.back() * aTransform;
			aData->BltTransformed(aTransform, theSrcRect, theColor, theClipRect);
		}
		else
		{
			SexyTransform2D aTransform = mTransformStack.back() * theTransform;
			aData->BltTransformed(aTransform, theSrcRect, theColor, theClipRect, theX, theY, center);
		}
	}
	else
	{
		SetLinearFilter(linearFilter);
		aData->BltTransformed(theTransform, theSrcRect, theColor, theClipRect, theX, theY, center);
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::DrawLine(double theStartX, double theStartY, double theEndX, double theEndY, const Color& theColor, int theDrawMode)
{
	if (!PreDraw())
		return;

	SetupDrawMode(theDrawMode, theColor, NULL);

	float x1, y1, x2, y2;
	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);

	if (!mTransformStack.empty())
	{
		SexyVector2 p1(theStartX, theStartY);
		SexyVector2 p2(theEndX, theEndY);
		p1 = mTransformStack.back()*p1;
		p2 = mTransformStack.back()*p2;
		x1 = p1.x;
		y1 = p1.y;
		x2 = p2.x;
		y2 = p2.y;
	}
	else
	{
		x1 = theStartX;
		y1 = theStartY;
		x2 = theEndX;
		y2 = theEndY;
	}

	// 1px-thick line quad (triangle list) replacing the D3D9 line strip.
	float aDx = x2 - x1;
	float aDy = y2 - y1;
	float aLen = sqrtf(aDx*aDx + aDy*aDy);
	if (aLen < 1.0f)
		aLen = 1.0f;
	float aPx = -aDy / aLen * 0.5f;
	float aPy = aDx / aLen * 0.5f;

	D3D8Vertex aVertex[6] =
	{
		{ x1 + aPx, y1 + aPy, 0, 1, aColor, 0, 0 },
		{ x2 + aPx, y2 + aPy, 0, 1, aColor, 0, 0 },
		{ x2 - aPx, y2 - aPy, 0, 1, aColor, 0, 0 },
		{ x1 + aPx, y1 + aPy, 0, 1, aColor, 0, 0 },
		{ x2 - aPx, y2 - aPy, 0, 1, aColor, 0, 0 },
		{ x1 - aPx, y1 - aPy, 0, 1, aColor, 0, 0 }
	};
	SubmitD3D11Triangles(aVertex, 6, D3D11PT_TRIANGLELIST,
		gD3D11Renderer->GetWhiteSRV(), false, theDrawMode, NULL);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::FillRect(const Rect& theRect, const Color& theColor, int theDrawMode)
{
	if (!PreDraw())
		return;

	SetupDrawMode(theDrawMode, theColor, NULL);

	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);
	float x = theRect.mX;
	float y = theRect.mY;
	float aWidth = theRect.mWidth;
	float aHeight = theRect.mHeight;

	D3D8Vertex aVertex[4] =
	{
		{ x, y, 0, 1, aColor, 0, 0 },
		{ x, y + aHeight, 0, 1, aColor, 0, 0 },
		{ x + aWidth, y, 0, 1, aColor, 0, 0 },
		{ x + aWidth, y + aHeight, 0, 1, aColor, 0, 0 }
	};

	if (!mTransformStack.empty())
	{
		SexyVector2 p[4] = { SexyVector2(x, y), SexyVector2(x, y+aHeight), SexyVector2(x+aWidth, y), SexyVector2(x+aWidth, y+aHeight) };
		for (int i=0; i<4; i++)
		{
			p[i] = mTransformStack.back()*p[i];
			aVertex[i].sx = p[i].x;
			aVertex[i].sy = p[i].y;
		}
	}

	SubmitD3D11Triangles(aVertex, 4, D3D11PT_TRIANGLESTRIP,
		gD3D11Renderer->GetWhiteSRV(), false, theDrawMode, NULL);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::DrawTriangle(const TriVertex &p1, const TriVertex &p2, const TriVertex &p3, const Color &theColor, int theDrawMode)
{
	if (!PreDraw())
		return;

	SetupDrawMode(theDrawMode, theColor, NULL);
	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);

	D3D8Vertex aVertex[3] =
	{
		{ p1.x, p1.y, 0, 1, aColor, 0, 0 },
		{ p2.x, p2.y, 0, 1, aColor, 0, 0 },
		{ p3.x, p3.y, 0, 1, aColor, 0, 0 }
	};
	SubmitD3D11Triangles(aVertex, 3, D3D11PT_TRIANGLESTRIP,
		gD3D11Renderer->GetWhiteSRV(), false, theDrawMode, NULL);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::FillPoly(const Point theVertices[], int theNumVertices, const Rect *theClipRect, const Color &theColor, int theDrawMode, int tx, int ty)
{
	if (theNumVertices < 3)
		return;

	if (!PreDraw())
		return;

	SetupDrawMode(theDrawMode, theColor, NULL);
	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);

	VertexList aList;
	for (int i=0; i<theNumVertices; i++)
	{
		D3D8Vertex vert = { theVertices[i].mX + (float)tx, theVertices[i].mY + (float)ty, 0, 1, aColor, 0, 0 };
		if (!mTransformStack.empty())
		{
			SexyVector2 v(vert.sx, vert.sy);
			v = mTransformStack.back()*v;
			vert.sx = v.x;
			vert.sy = v.y;
		}
		aList.push_back(vert);
	}

	if (theClipRect != NULL)
		DrawPolyClipped11(theClipRect, aList, gD3D11Renderer->GetWhiteSRV());
	else
		SubmitD3D11Triangles(&aList[0], (int)aList.size(), D3D11PT_TRIANGLEFAN,
			gD3D11Renderer->GetWhiteSRV(), false, theDrawMode, NULL);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::DrawTriangleTex(const TriVertex &p1, const TriVertex &p2, const TriVertex &p3, const Color &theColor, int theDrawMode, Image *theTexture, bool blend)
{
	TriVertex aVertices[1][3] = {{p1, p2, p3}};
	DrawTrianglesTex(aVertices, 1, theColor, theDrawMode, theTexture, blend);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::DrawTrianglesTex(const TriVertex theVertices[][3], int theNumTriangles, const Color &theColor, int theDrawMode, Image *theTexture, float tx, float ty, bool blend)
{
	if (!PreDraw())
		return;

	MemoryImage* aSrcMemoryImage = (MemoryImage*)theTexture;
	if (!CreateImageTexture(aSrcMemoryImage))
		return;

	SetupDrawMode(theDrawMode, theColor, theTexture);
	DWORD aColor = RGBA_MAKE(theColor.mRed, theColor.mGreen, theColor.mBlue, theColor.mAlpha);

	TextureData *aData = (TextureData*)aSrcMemoryImage->mD3DData;
	SetLinearFilter(blend);
	aData->BltTriangles(theVertices, theNumTriangles, aColor, tx, ty);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::DrawTrianglesTexStrip(const TriVertex theVertices[], int theNumTriangles, const Color &theColor, int theDrawMode, Image *theTexture, float tx, float ty, bool blend)
{
	TriVertex aList[100][3];
	int aTriNum = 0;
	while (aTriNum < theNumTriangles)
	{
		int aMaxTriangles = std::min(100, theNumTriangles - aTriNum);
		for (int i=0; i<aMaxTriangles; i++)
		{
			aList[i][0] = theVertices[aTriNum];
			aList[i][1] = theVertices[aTriNum+1];
			aList[i][2] = theVertices[aTriNum+2];
			aTriNum++;
		}
		DrawTrianglesTex(aList, aMaxTriangles, theColor, theDrawMode, theTexture, tx, ty, blend);
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void D3DInterface::Flush()
{
	if (mD3D11 != NULL)
	{
		if (mSceneBegun)
		{
			mD3D11->EndSceneAndPresent();
			mSceneBegun = false;
		}
		return;
	}
}
