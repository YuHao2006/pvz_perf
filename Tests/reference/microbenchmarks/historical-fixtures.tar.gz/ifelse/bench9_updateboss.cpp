// bench9_updateboss.cpp - 目标9: Zombie::UpdateBoss 13 相位 if 链 -> 函数内 lambda 函数指针表
// 计时区 = 相位分派段（ENTER..HEAD_LEAVE + else 兜底）；公共前缀（计数器/头部 reanim/UpdateBossFireball）两形态逐字相同，不计入
#include "bench_common.h"

enum ZombiePhase
{
    PHASE_WALKING = 0,
    PHASE_BOSS_ENTER = 78,
    PHASE_BOSS_IDLE,
    PHASE_BOSS_SPAWNING,
    PHASE_BOSS_STOMPING,
    PHASE_BOSS_BUNGEES_ENTER,
    PHASE_BOSS_BUNGEES_DROP,
    PHASE_BOSS_BUNGEES_LEAVE,
    PHASE_BOSS_DROP_RV,
    PHASE_BOSS_HEAD_ENTER,
    PHASE_BOSS_HEAD_IDLE_BEFORE_SPIT,
    PHASE_BOSS_HEAD_IDLE_AFTER_SPIT,
    PHASE_BOSS_HEAD_SPIT,
    PHASE_BOSS_HEAD_LEAVE,
    PHASE_YETI_RUNNING
};
enum ReanimTrackId { anim_idle = 0, anim_head_idle, anim_head_leave };
enum ReanimLoopType { REANIM_LOOP = 0, REANIM_PLAY_ONCE_AND_HOLD };
enum FoleyType { FOLEY_THUMP = 0, FOLEY_HYDRAULIC };

struct Reanimation
{
    int mLoopCount;
    float mAnimRate;
    uint32_t mTriggerMask;
    bool ShouldTriggerTimedEvent(float f) const { return (mTriggerMask >> ((unsigned)(f * 100.0f) % 32u)) & 1u; }
    void PlayReanim(ReanimTrackId t, ReanimLoopType l, int a, float r) { Mix(0xB0A0u); MixI((int)t); MixI((int)l); MixI(a); MixF(r); }
};
struct Board { void ShakeBoard(int a, int b) { Mix(0xB0B0u); MixI(a); MixI(b); } };
struct LawnAppStub
{
    Reanimation mBodyReanim, mHeadReanim, mSpecial;
    void PlayFoley(FoleyType f) { Mix(0xB0C0u); MixI((int)f); }
    bool IsAdventureMode() const { return gAdvMode; }
    Reanimation* ReanimationGet(int) { return &mSpecial; }
    Reanimation* ReanimationTryToGet(int) { return &mSpecial; }
    bool gAdvMode = true;
};
static LawnAppStub gApp;
static Board gBoard;

static uint32_t gRandState = 1;
static int Rand(unsigned v) { gRandState = gRandState * 1664525u + 1013904223u; return (int)(gRandState % (v ? v : 1u)); }
static int RandRangeInt(int lo, int hi) { gRandState = gRandState * 1664525u + 1013904223u; return lo + (int)(gRandState % (uint32_t)(hi - lo + 1)); }

struct Zombie
{
    ZombiePhase mZombiePhase;
    int mBodyHealth, mPhaseCounter, mBossMode;
    int mSummonCounter, mBossBungeeCounter, mBossStompCounter, mBossHeadCounter;
    int mChilledCounter, mTargetRow;
    int mBodyReanimID, mSpecialHeadReanimID;
    LawnAppStub* mApp;
    Board* mBoard;

    int GetBodyDamageIndex() const { return mDamageIndex; }
    int mDamageIndex;

    void BossPlayIdle() { Mix(0xB100u); }
    void PlayDeathAnim(unsigned v) { Mix(0xB101u); MixI((int)v); }
    void BossBungeeAttack() { Mix(0xB102u); }
    void BossRVAttack() { Mix(0xB103u); }
    void BossStompAttack() { Mix(0xB104u); }
    void BossHeadAttack() { Mix(0xB105u); }
    void BossSpawnAttack() { Mix(0xB106u); }
    void BossSpawnContact() { Mix(0xB107u); }
    void BossStompContact() { Mix(0xB108u); }
    void BossBungeeSpawn() { Mix(0xB109u); }
    bool BossAreBungeesDone() { Mix(0xB10Au); return gBungeesDone; }
    void BossBungeeLeave() { Mix(0xB10Bu); }
    void BossRVLanding() { Mix(0xB10Cu); }
    void ApplyBossSmokeParticles(bool b) { Mix(0xB10Du); MixI((int)b); }
    void BossHeadSpit() { Mix(0xB10Eu); }
    void BossHeadSpitEffect() { Mix(0xB10Fu); }
    void BossHeadSpitContact() { Mix(0xB110u); }
    void BossStartDeath() { Mix(0xB111u); }
    void UpdateAnimSpeed() { Mix(0xB112u); }
    void PlayZombieReanim(ReanimTrackId t, ReanimLoopType l, int a, float r) { Mix(0xB113u); MixI((int)t); MixI((int)l); MixI(a); MixF(r); }

    bool gBungeesDone = true;
};
static Zombie gZombie;

static void SetupBoss(uint32_t inp)
{
    gZombie.mZombiePhase = (ZombiePhase)((int)ZombiePhase::PHASE_BOSS_ENTER + (int)(inp % 13u));
    gZombie.mBodyHealth = ((inp >> 10) & 1u) ? 1 : 500;
    gZombie.mPhaseCounter = (int)((inp >> 11) & 0x1FFu);
    gZombie.mBossMode = (int)((inp >> 20) & 3u);
    gZombie.mSummonCounter = (int)((inp >> 4) & 0xFFu);
    gZombie.mBossBungeeCounter = (int)((inp >> 12) & 0xFFu);
    gZombie.mBossStompCounter = (int)((inp >> 16) & 0xFFu);
    gZombie.mBossHeadCounter = (int)((inp >> 24) & 0xFFu);
    gZombie.mChilledCounter = (int)((inp >> 6) & 0xFu);
    gZombie.mTargetRow = (int)((inp >> 8) & 0x7u);
    gZombie.mDamageIndex = (int)((inp >> 22) & 3u);
    gZombie.mBodyReanimID = (int)(inp >> 3);
    gZombie.mSpecialHeadReanimID = (int)(inp >> 5);
    gZombie.mApp = &gApp;
    gZombie.mBoard = &gBoard;
    gZombie.gBungeesDone = (inp >> 9) & 1u;
    gApp.mBodyReanim.mTriggerMask = inp;
    gApp.mBodyReanim.mLoopCount = (int)((inp >> 17) & 3u);
    gApp.mBodyReanim.mAnimRate = 0.0f;
    gApp.mSpecial.mTriggerMask = inp ^ 0x55555555u;
    gApp.mSpecial.mLoopCount = (int)((inp >> 18) & 3u);
    gApp.mSpecial.mAnimRate = 0.0f;
    gApp.gAdvMode = (inp >> 19) & 1u;
    gRandState = inp | 1u;
}

// ---------------- FormA：原 13 相位 if 链（逐字） ----------------
__declspec(noinline) void OneA(uint32_t inp)
{
    SetupBoss(inp);
    Zombie& mThis = gZombie;
    Reanimation* aBodyReanim = &gApp.mBodyReanim;
#define mZombiePhase mThis.mZombiePhase
#define mApp mThis.mApp
#define mBodyHealth mThis.mBodyHealth
#define mPhaseCounter mThis.mPhaseCounter
#define mBossMode mThis.mBossMode
#define mSummonCounter mThis.mSummonCounter
#define mBossBungeeCounter mThis.mBossBungeeCounter
#define mBossStompCounter mThis.mBossStompCounter
#define mBossHeadCounter mThis.mBossHeadCounter
#define mChilledCounter mThis.mChilledCounter
#define mTargetRow mThis.mTargetRow
#define mSpecialHeadReanimID mThis.mSpecialHeadReanimID
#define GetBodyDamageIndex() mThis.GetBodyDamageIndex()
#define PlayDeathAnim(v) mThis.PlayDeathAnim(v)
#define BossPlayIdle() mThis.BossPlayIdle()
#define BossBungeeAttack() mThis.BossBungeeAttack()
#define BossRVAttack() mThis.BossRVAttack()
#define BossStompAttack() mThis.BossStompAttack()
#define BossHeadAttack() mThis.BossHeadAttack()
#define BossSpawnAttack() mThis.BossSpawnAttack()
#define BossSpawnContact() mThis.BossSpawnContact()
#define BossStompContact() mThis.BossStompContact()
#define BossBungeeSpawn() mThis.BossBungeeSpawn()
#define BossAreBungeesDone() mThis.BossAreBungeesDone()
#define BossBungeeLeave() mThis.BossBungeeLeave()
#define BossRVLanding() mThis.BossRVLanding()
#define ApplyBossSmokeParticles(b) mThis.ApplyBossSmokeParticles(b)
#define BossHeadSpit() mThis.BossHeadSpit()
#define BossHeadSpitEffect() mThis.BossHeadSpitEffect()
#define BossHeadSpitContact() mThis.BossHeadSpitContact()
#define BossStartDeath() mThis.BossStartDeath()
#define UpdateAnimSpeed() mThis.UpdateAnimSpeed()
#define PlayZombieReanim(t, l, a, r) mThis.PlayZombieReanim(t, l, a, r)

    if (mZombiePhase == ZombiePhase::PHASE_BOSS_ENTER)
    {
        BossPlayIdle();
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_IDLE)
    {
        if (mBodyHealth == 1)
        {
            PlayDeathAnim(0U);
            goto done;
        }

        if (mPhaseCounter > 0)
            goto done;

        int aDamageIndex = GetBodyDamageIndex();
        if (aDamageIndex != mBossMode)
        {
            mBossMode = aDamageIndex;
            if (mBossMode == 1)
            {
                BossBungeeAttack();
            }
            else
            {
                BossRVAttack();
            }
        }
        else if (mBossStompCounter == 0)
        {
            BossStompAttack();
        }
        else if (mBossBungeeCounter == 0)
        {
            if (Rand(mApp->IsAdventureMode() ? 4 : 2) == 0)
            {
                mBossBungeeCounter = RandRangeInt(4000, 5000);
                BossRVAttack();
            }
            else
            {
                BossBungeeAttack();
            }
        }
        else if (mBossHeadCounter == 0)
        {
            BossHeadAttack();
        }
        else if (mSummonCounter == 0)
        {
            BossSpawnAttack();
        }
        else
        {
            mPhaseCounter = RandRangeInt(100, 200);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_SPAWNING)
    {
        if (aBodyReanim->ShouldTriggerTimedEvent(0.6f))
        {
            BossSpawnContact();
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            BossPlayIdle();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_STOMPING)
    {
        float aTrigger = 0.5f;
        if (mTargetRow >= 2)
        {
            aTrigger = 0.55f;
        }
        if (aBodyReanim->ShouldTriggerTimedEvent(aTrigger))
        {
            BossStompContact();
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            BossPlayIdle();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_BUNGEES_ENTER)
    {
        if (aBodyReanim->ShouldTriggerTimedEvent(0.4f))
        {
            BossBungeeSpawn();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_BUNGEES_DROP)
    {
        if (BossAreBungeesDone())
        {
            BossBungeeLeave();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_BUNGEES_LEAVE)
    {
        if (aBodyReanim->mLoopCount > 0)
        {
            BossPlayIdle();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_DROP_RV)
    {
        if (aBodyReanim->ShouldTriggerTimedEvent(0.65f))
        {
            BossRVLanding();
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            BossPlayIdle();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_HEAD_ENTER)
    {
        if (GetBodyDamageIndex() == 2 && aBodyReanim->ShouldTriggerTimedEvent(0.37f))
        {
            ApplyBossSmokeParticles(true);
        }

        if (aBodyReanim->ShouldTriggerTimedEvent(0.55f))
        {
            mApp->PlayFoley(FoleyType::FOLEY_HYDRAULIC);
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            mZombiePhase = ZombiePhase::PHASE_BOSS_HEAD_IDLE_BEFORE_SPIT;
            PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            mPhaseCounter = 500;
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_HEAD_IDLE_BEFORE_SPIT)
    {
        if (mBodyHealth == 1)
        {
            BossStartDeath();
        }
        else if (mPhaseCounter == 0)
        {
            BossHeadSpit();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_HEAD_IDLE_AFTER_SPIT)
    {
        if (mBodyHealth == 1)
        {
            BossStartDeath();
        }
        else if (mPhaseCounter == 0)
        {
            mZombiePhase = ZombiePhase::PHASE_BOSS_HEAD_LEAVE;
            PlayZombieReanim(ReanimTrackId::anim_head_leave, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_HEAD_SPIT)
    {
        if (aBodyReanim->ShouldTriggerTimedEvent(0.37f))
        {
            BossHeadSpitEffect();
        }

        if (aBodyReanim->ShouldTriggerTimedEvent(0.42f))
        {
            BossHeadSpitContact();
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            Reanimation* aHeadReanim = mApp->ReanimationTryToGet(mSpecialHeadReanimID);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 20, 18.0f);
            mZombiePhase = ZombiePhase::PHASE_BOSS_HEAD_IDLE_AFTER_SPIT;
            PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            mPhaseCounter = 300;
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BOSS_HEAD_LEAVE)
    {
        if (aBodyReanim->ShouldTriggerTimedEvent(0.23f))
        {
            mChilledCounter = 0;
            UpdateAnimSpeed();
        }

        if (aBodyReanim->ShouldTriggerTimedEvent(0.48f) || aBodyReanim->ShouldTriggerTimedEvent(0.8f))
        {
            mApp->PlayFoley(FoleyType::FOLEY_THUMP);
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            ApplyBossSmokeParticles(false);
            BossPlayIdle();
        }
    }
    else
    {
        TOD_ASSERT(false);
    }
done:;
#undef mZombiePhase
#undef mApp
#undef mBodyHealth
#undef mPhaseCounter
#undef mBossMode
#undef mSummonCounter
#undef mBossBungeeCounter
#undef mBossStompCounter
#undef mBossHeadCounter
#undef mChilledCounter
#undef mTargetRow
#undef mSpecialHeadReanimID
#undef GetBodyDamageIndex
#undef PlayDeathAnim
#undef BossPlayIdle
#undef BossBungeeAttack
#undef BossRVAttack
#undef BossStompAttack
#undef BossHeadAttack
#undef BossSpawnAttack
#undef BossSpawnContact
#undef BossStompContact
#undef BossBungeeSpawn
#undef BossAreBungeesDone
#undef BossBungeeLeave
#undef BossRVLanding
#undef ApplyBossSmokeParticles
#undef BossHeadSpit
#undef BossHeadSpitEffect
#undef BossHeadSpitContact
#undef BossStartDeath
#undef UpdateAnimSpeed
#undef PlayZombieReanim
    MixI((int)gZombie.mZombiePhase); MixI(gZombie.mPhaseCounter); MixI(gZombie.mBossMode); MixI(gZombie.mBossBungeeCounter); MixI(gZombie.mChilledCounter);
}

// ---------------- FormB：当前 lambda 函数指针表形态（逐字） ----------------
__declspec(noinline) void OneB(uint32_t inp)
{
    SetupBoss(inp);
    Zombie& z = gZombie;
    Reanimation* aBodyReanim = &gApp.mBodyReanim;

    using BossPhaseCaseFn = void (*)(Zombie&, Reanimation*);
    static constexpr BossPhaseCaseFn kBossPhaseCases[(int)ZombiePhase::PHASE_BOSS_HEAD_LEAVE - (int)ZombiePhase::PHASE_BOSS_ENTER + 1] = {
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            z.BossPlayIdle();
        },  // 78 PHASE_BOSS_ENTER
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (z.mBodyHealth == 1)
            {
                z.PlayDeathAnim(0U);
                return;
            }

            if (z.mPhaseCounter > 0)
                return;

            int aDamageIndex = z.GetBodyDamageIndex();
            if (aDamageIndex != z.mBossMode)
            {
                z.mBossMode = aDamageIndex;
                if (z.mBossMode == 1)
                {
                    z.BossBungeeAttack();
                }
                else
                {
                    z.BossRVAttack();
                }
            }
            else if (z.mBossStompCounter == 0)
            {
                z.BossStompAttack();
            }
            else if (z.mBossBungeeCounter == 0)
            {
                if (Rand(z.mApp->IsAdventureMode() ? 4 : 2) == 0)
                {
                    z.mBossBungeeCounter = RandRangeInt(4000, 5000);
                    z.BossRVAttack();
                }
                else
                {
                    z.BossBungeeAttack();
                }
            }
            else if (z.mBossHeadCounter == 0)
            {
                z.BossHeadAttack();
            }
            else if (z.mSummonCounter == 0)
            {
                z.BossSpawnAttack();
            }
            else
            {
                z.mPhaseCounter = RandRangeInt(100, 200);
            }
        },  // 79 PHASE_BOSS_IDLE
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (aBodyReanim->ShouldTriggerTimedEvent(0.6f))
            {
                z.BossSpawnContact();
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.BossPlayIdle();
            }
        },  // 80 PHASE_BOSS_SPAWNING
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            float aTrigger = 0.5f;
            if (z.mTargetRow >= 2)
            {
                aTrigger = 0.55f;
            }
            if (aBodyReanim->ShouldTriggerTimedEvent(aTrigger))
            {
                z.BossStompContact();
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.BossPlayIdle();
            }
        },  // 81 PHASE_BOSS_STOMPING
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (aBodyReanim->ShouldTriggerTimedEvent(0.4f))
            {
                z.BossBungeeSpawn();
            }
        },  // 82 PHASE_BOSS_BUNGEES_ENTER
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (z.BossAreBungeesDone())
            {
                z.BossBungeeLeave();
            }
        },  // 83 PHASE_BOSS_BUNGEES_DROP
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (aBodyReanim->mLoopCount > 0)
            {
                z.BossPlayIdle();
            }
        },  // 84 PHASE_BOSS_BUNGEES_LEAVE
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (aBodyReanim->ShouldTriggerTimedEvent(0.65f))
            {
                z.BossRVLanding();
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.BossPlayIdle();
            }
        },  // 85 PHASE_BOSS_DROP_RV
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (z.GetBodyDamageIndex() == 2 && aBodyReanim->ShouldTriggerTimedEvent(0.37f))
            {
                z.ApplyBossSmokeParticles(true);
            }

            if (aBodyReanim->ShouldTriggerTimedEvent(0.55f))
            {
                z.mApp->PlayFoley(FoleyType::FOLEY_HYDRAULIC);
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.mZombiePhase = ZombiePhase::PHASE_BOSS_HEAD_IDLE_BEFORE_SPIT;
                z.PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
                z.mPhaseCounter = 500;
            }
        },  // 86 PHASE_BOSS_HEAD_ENTER
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (z.mBodyHealth == 1)
            {
                z.BossStartDeath();
            }
            else if (z.mPhaseCounter == 0)
            {
                z.BossHeadSpit();
            }
        },  // 87 PHASE_BOSS_HEAD_IDLE_BEFORE_SPIT
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (z.mBodyHealth == 1)
            {
                z.BossStartDeath();
            }
            else if (z.mPhaseCounter == 0)
            {
                z.mZombiePhase = ZombiePhase::PHASE_BOSS_HEAD_LEAVE;
                z.PlayZombieReanim(ReanimTrackId::anim_head_leave, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
            }
        },  // 88 PHASE_BOSS_HEAD_IDLE_AFTER_SPIT
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (aBodyReanim->ShouldTriggerTimedEvent(0.37f))
            {
                z.BossHeadSpitEffect();
            }

            if (aBodyReanim->ShouldTriggerTimedEvent(0.42f))
            {
                z.BossHeadSpitContact();
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                Reanimation* aHeadReanim = z.mApp->ReanimationTryToGet(z.mSpecialHeadReanimID);
                aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 20, 18.0f);
                z.mZombiePhase = ZombiePhase::PHASE_BOSS_HEAD_IDLE_AFTER_SPIT;
                z.PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
                z.mPhaseCounter = 300;
            }
        },  // 89 PHASE_BOSS_HEAD_SPIT
        [](Zombie& z, Reanimation* aBodyReanim)
        {
            if (aBodyReanim->ShouldTriggerTimedEvent(0.23f))
            {
                z.mChilledCounter = 0;
                z.UpdateAnimSpeed();
            }

            if (aBodyReanim->ShouldTriggerTimedEvent(0.48f) || aBodyReanim->ShouldTriggerTimedEvent(0.8f))
            {
                z.mApp->PlayFoley(FoleyType::FOLEY_THUMP);
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.ApplyBossSmokeParticles(false);
                z.BossPlayIdle();
            }
        },  // 90 PHASE_BOSS_HEAD_LEAVE
    };
    static_assert(sizeof(kBossPhaseCases) / sizeof(kBossPhaseCases[0]) ==
        (int)ZombiePhase::PHASE_BOSS_HEAD_LEAVE - (int)ZombiePhase::PHASE_BOSS_ENTER + 1,
        "kBossPhaseCases 槽位须与 ZombiePhase BOSS 段同步");

    const int aBossPhaseIndex = (int)z.mZombiePhase - (int)ZombiePhase::PHASE_BOSS_ENTER;
    if (aBossPhaseIndex >= 0 && aBossPhaseIndex < (int)(sizeof(kBossPhaseCases) / sizeof(kBossPhaseCases[0])))
    {
        kBossPhaseCases[aBossPhaseIndex](z, aBodyReanim);
    }
    else
    {
        TOD_ASSERT(false);  // 原 else 兜底
    }

    MixI((int)gZombie.mZombiePhase); MixI(gZombie.mPhaseCounter); MixI(gZombie.mBossMode); MixI(gZombie.mBossBungeeCounter); MixI(gZombie.mChilledCounter);
}

static void RunA() { for (int i = 0; i < kN; i++) OneA(gInput[i]); }
static void RunB() { for (int i = 0; i < kN; i++) OneB(gInput[i]); }

int main()
{
    GenInput();
    uint64_t ca = CheckOnly(RunA);
    uint64_t cb = CheckOnly(RunB);
    double a = TimePerIterNs(RunA, kN);
    double b = TimePerIterNs(RunB, kN);
    printf("bench9 UpdateBossPhases | before %.2f ns | after %.2f ns | diff %.1f%% | checksum=%s (A=%016llX B=%016llX)\n",
        a, b, (a - b) / a * 100.0, ca == cb ? "OK" : "MISMATCH", (unsigned long long)ca, (unsigned long long)cb);
    return ca == cb ? 0 : 1;
}
