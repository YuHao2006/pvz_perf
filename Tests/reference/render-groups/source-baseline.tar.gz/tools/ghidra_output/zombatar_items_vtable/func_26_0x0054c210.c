
void __thiscall FUN_0054c210(int *param_1,char param_2)

{
  if ((char)param_1[0x19] != param_2) {
    *(char *)(param_1 + 0x19) = param_2;
    if ((char)param_1[0x19] == '\0') {
      (**(code **)(*param_1 + 0x4c))();
    }
    else {
      (**(code **)(*param_1 + 0x44))();
    }
    if (param_1[8] != 0) {
      FUN_0054b6f0();
    }
  }
  return;
}

