// bench_spawnparticle.cpp — 目标13：TodParticleEmitter::SpawnParticle
// FormA = ac447d19^ 改造前（发射几何 3 标签共体 5 case switch + default）
// FormB = HEAD 终态（kParticleSpawnPosCases 5 槽 lambda 表 + 越界守卫）
// 判别式输入：2M 均匀分布 EmitterType(0..4)（固定种子），逐 call 选 5 个预建
// def 之一；两形态消费同一数组、同一 def 环、同一随机序列（LCG 每趟复位）。
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <random>
#include <cstring>
#include <cmath>
#include <algorithm>

// ---------------- harness ----------------
static uint64_t g_cs = 0;
static inline void CsMix(uint64_t v) { g_cs = g_cs * 0x9E3779B97F4A7C15ull + v; }
static uint64_t QpcFreq() { static uint64_t f = 0; if (!f) { LARGE_INTEGER li; QueryPerformanceFrequency(&li); f = (uint64_t)li.QuadPart; } return f; }
static uint64_t QpcNow() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (uint64_t)c.QuadPart; }
static double QpcToNs(uint64_t ticks) { return (double)ticks * 1e9 / (double)QpcFreq(); }
#define TOD_ASSERT(...) ((void)0)
constexpr float PI = 3.14159265358979323846f;
#define DEG_TO_RAD(a) ((a) * PI / 180.0f)

// ---------------- game type stubs ----------------
enum EmitterType { EMITTER_CIRCLE = 0, EMITTER_BOX = 1, EMITTER_BOX_PATH = 2, EMITTER_CIRCLE_PATH = 3, EMITTER_CIRCLE_EVEN_SPACING = 4 };
enum ParticleFlags
{
    PARTICLE_RANDOM_LAUNCH_SPIN, PARTICLE_ALIGN_LAUNCH_SPIN, PARTICLE_ALIGN_TO_PIXELS, PARTICLE_SYSTEM_LOOPS,
    PARTICLE_PARTICLE_LOOPS, PARTICLE_PARTICLES_DONT_FOLLOW, PARTICLE_RANDOM_START_TIME, PARTICLE_DIE_IF_OVERLOADED,
    PARTICLE_ADDITIVE, PARTICLE_FULLSCREEN, PARTICLE_SOFTWARE_ONLY, PARTICLE_HARDWARE_ONLY
};
enum ParticleSystemTracks
{
    TRACK_SPAWN_RATE, TRACK_SPAWN_MIN_ACTIVE, TRACK_SPAWN_MAX_ACTIVE, TRACK_SPAWN_MAX_LAUNCHED, TRACK_EMITTER_PATH,
    TRACK_SYSTEM_RED, TRACK_SYSTEM_GREEN, TRACK_SYSTEM_BLUE, TRACK_SYSTEM_ALPHA, TRACK_SYSTEM_BRIGHTNESS, NUM_SYSTEM_TRACKS
};
enum ParticleTracks
{
    TRACK_PARTICLE_RED, TRACK_PARTICLE_GREEN, TRACK_PARTICLE_BLUE, TRACK_PARTICLE_ALPHA, TRACK_PARTICLE_BRIGHTNESS,
    TRACK_PARTICLE_SPIN_SPEED, TRACK_PARTICLE_SPIN_ANGLE, TRACK_PARTICLE_SCALE, TRACK_PARTICLE_STRETCH,
    TRACK_PARTICLE_COLLISION_REFLECT, TRACK_PARTICLE_COLLISION_SPIN,
    TRACK_PARTICLE_CLIP_TOP, TRACK_PARTICLE_CLIP_BOTTOM, TRACK_PARTICLE_CLIP_LEFT, TRACK_PARTICLE_CLIP_RIGHT,
    TRACK_PARTICLE_ANIMATION_RATE, NUM_PARTICLE_TRACKS
};
#define MAX_PARTICLE_FIELDS 4
enum ParticleID { PARTICLEID_NULL = 0 };

struct SexyVector2
{
    float x = 0.0f, y = 0.0f;
    SexyVector2() {}
    SexyVector2(float theX, float theY) : x(theX), y(theY) {}
};

class FloatParameterTrack { public: int mCountNodes = 0; };

class ParticleField { public: int mFieldType = 0; FloatParameterTrack mX, mY; };
struct EmitterFieldArray { public: ParticleField* Fields; int count; };

class TodEmitterDefinition
{
public:
    int mImageCol = 0, mImageRow = 0, mImageFrames = 8, mAnimated = 0, mParticleFlags = 0;
    EmitterType mEmitterType = EMITTER_CIRCLE;
    const char* mName = "bench";
    FloatParameterTrack mSystemDuration, mCrossFadeDuration, mSpawnRate, mSpawnMinActive, mSpawnMaxActive, mSpawnMaxLaunched;
    FloatParameterTrack mEmitterRadius, mEmitterOffsetX, mEmitterOffsetY, mEmitterBoxX, mEmitterBoxY, mEmitterSkewX, mEmitterSkewY, mEmitterPath;
    FloatParameterTrack mParticleDuration, mLaunchSpeed, mLaunchAngle;
    EmitterFieldArray mParticleFields;
    FloatParameterTrack mAnimationRate;
};

class TodParticleEmitter;
class TodParticle
{
public:
    TodParticleEmitter* mParticleEmitter = nullptr;
    int mParticleDuration = 0, mParticleAge = 0;
    float mParticleTimeValue = 0.0f, mParticleLastTimeValue = 0.0f, mAnimationTimeValue = 0.0f;
    SexyVector2 mVelocity, mPosition;
    int mImageFrame = 0;
    float mSpinPosition = 0.0f, mSpinVelocity = 0.0f;
    ParticleID mCrossFadeParticleID = PARTICLEID_NULL;
    int mCrossFadeDuration = 0;
    float mParticleInterp[ParticleTracks::NUM_PARTICLE_TRACKS];
    float mParticleFieldInterp[MAX_PARTICLE_FIELDS][2];
};

// ---- 游戏函数 → 同签名空桩（编号入 checksum） ----
static float FloatTrackEvaluate(FloatParameterTrack& theTrack, float theTimeValue, float theInterp)
{
    CsMix(41);
    return theInterp * 1.7f + theTimeValue * 0.3f + (float)(theTrack.mCountNodes & 7);
}
static bool FloatTrackIsConstantZero(FloatParameterTrack& theTrack)
{
    CsMix(42);
    return theTrack.mCountNodes == 0;
}
static bool FloatTrackIsSet(const FloatParameterTrack& theTrack)
{
    CsMix(43);
    return theTrack.mCountNodes != 0;
}
static inline bool TestBit(int theVal, int theBit) { return (theVal & (1 << theBit)) != 0; }
static void TodTraceWithoutSpamming(const char* theFormat, ...) { CsMix(44); }

static uint64_t g_randState = 1;
static void ResetRand() { g_randState = 0x243F6A8885A308D3ull; }
namespace Sexy
{
    float Rand(float range)
    {
        g_randState = g_randState * 6364136223846793005ull + 1442695040888963407ull;
        return range * (float)((g_randState >> 33) & 0xFFFFFF) / 16777216.0f;
    }
}

// ---- DataArray / TodList 最小桩 ----
template <class T> class DataArray
{
public:
    T* mItems = nullptr;
    unsigned int mMaxSize = 0;
    unsigned int mSize = 0;
    T* DataArrayAlloc()
    {
        CsMix(45);
        T* p = &mItems[mSize % 1024];
        mSize++;
        return p;
    }
    unsigned int DataArrayGetID(T* theItem) { CsMix(46); return (unsigned int)(theItem - mItems) + 1; }
};

template <class T> class TodList
{
public:
    int mCount = 0;
    void AddHead(const T& theHead) { CsMix(47); mCount++; }
};

class TodParticleHolder
{
public:
    DataArray<TodParticle> mParticles;
};

class TodParticleSystem
{
public:
    TodParticleHolder* mParticleHolder = nullptr;
};

static TodParticle g_particlePool[1024];

class TodParticleEmitter
{
public:
    TodEmitterDefinition* mEmitterDef = nullptr;
    TodParticleSystem* mParticleSystem = nullptr;
    TodList<ParticleID> mParticleList;
    SexyVector2 mSystemCenter;
    int mParticlesSpawned = 0;
    float mSystemTimeValue = 1.25f;
    float mTrackInterp[ParticleSystemTracks::NUM_SYSTEM_TRACKS];

    bool UpdateParticle(TodParticle* theParticle) { CsMix(48); return true; }

    TodParticle* SpawnParticle_A(int theIndex, int theSpawnCount);
    TodParticle* SpawnParticle_B(int theIndex, int theSpawnCount);
};

// ================= FormA：改造前（ac447d19^ 逐字） =================
__declspec(noinline) TodParticle* TodParticleEmitter::SpawnParticle_A(int theIndex, int theSpawnCount)
{
	DataArray<TodParticle>& aDataArray = mParticleSystem->mParticleHolder->mParticles;
	if (aDataArray.mSize == aDataArray.mMaxSize)
	{
		TodTraceWithoutSpamming("Too many particles '%s'\n", mEmitterDef->mName);
		return nullptr;
	}

	TodParticle* aParticle = aDataArray.DataArrayAlloc();
	TOD_ASSERT(mEmitterDef->mParticleFields.count <= MAX_PARTICLE_FIELDS);
	for (int i = 0; i < mEmitterDef->mParticleFields.count; i++)
	{
		aParticle->mParticleFieldInterp[i][0] = Sexy::Rand(1.0f);  // 初始化每个粒子场的横向插值
		aParticle->mParticleFieldInterp[i][1] = Sexy::Rand(1.0f);  // 初始化每个粒子场的纵向插值
	}
	for (int i = 0; i < (int)ParticleTracks::NUM_PARTICLE_TRACKS; i++)
		aParticle->mParticleInterp[i] = Sexy::Rand(1.0f);  // 初始化每条通道的插值

	float aParticleDurationInterp = Sexy::Rand(1.0f);
	float aLaunchSpeedInterp = Sexy::Rand(1.0f);
	float aEmitterOffsetXInterp = Sexy::Rand(1.0f);
	float aEmitterOffsetYInterp = Sexy::Rand(1.0f);
	aParticle->mParticleDuration = FloatTrackEvaluate(mEmitterDef->mParticleDuration, mSystemTimeValue, aParticleDurationInterp);
	aParticle->mParticleDuration = std::max(1, aParticle->mParticleDuration);  // 初始化粒子持续时间（至少为 1）
	aParticle->mParticleAge = 0;
	aParticle->mParticleEmitter = this;
	aParticle->mParticleTimeValue = -1.0f;
	aParticle->mParticleLastTimeValue = -1.0f;
	if (TestBit(mEmitterDef->mParticleFlags, (int)ParticleFlags::PARTICLE_RANDOM_START_TIME))
		aParticle->mParticleAge = Sexy::Rand(aParticle->mParticleDuration);  // 对于“随机初始时间”的粒子
	float aLaunchSpeed = FloatTrackEvaluate(mEmitterDef->mLaunchSpeed, mSystemTimeValue, aLaunchSpeedInterp) * 0.01f;
	float aLaunchAngleInterp = Sexy::Rand(1.0f);

	float aLaunchAngle;
	if (mEmitterDef->mEmitterType == EmitterType::EMITTER_CIRCLE_PATH)
	{
		// 发射角度 = 根据路径定义计算的圆周上的基础角度 + 根据发射角度定义计算的额外偏移的角度
		aLaunchAngle = FloatTrackEvaluate(mEmitterDef->mEmitterPath, mSystemTimeValue, mTrackInterp[ParticleSystemTracks::TRACK_EMITTER_PATH]) * 2 * PI;
		aLaunchAngle += DEG_TO_RAD(FloatTrackEvaluate(mEmitterDef->mLaunchAngle, mSystemTimeValue, aLaunchAngleInterp));
	}
	else if (mEmitterDef->mEmitterType == EmitterType::EMITTER_CIRCLE_EVEN_SPACING)
		// 基础发射角度要使 theSpawnCount 个粒子平均布满圆周
		aLaunchAngle = 2 * PI * theIndex / theSpawnCount + DEG_TO_RAD(FloatTrackEvaluate(mEmitterDef->mLaunchAngle, mSystemTimeValue, aLaunchAngleInterp));
	else if (FloatTrackIsConstantZero(mEmitterDef->mLaunchAngle))
		// 未定义的轨道，发射角度直接取 [0, 2π] 的随机值
		aLaunchAngle = Sexy::Rand((float)(2 * PI));
	else
		// 其他情况下，根据发射角度的定义值计算
		aLaunchAngle = DEG_TO_RAD(FloatTrackEvaluate(mEmitterDef->mLaunchAngle, mSystemTimeValue, aLaunchAngleInterp));

	float aPosX, aPosY;
	switch (mEmitterDef->mEmitterType)
	{
	case EmitterType::EMITTER_CIRCLE:
	case EmitterType::EMITTER_CIRCLE_PATH:
	case EmitterType::EMITTER_CIRCLE_EVEN_SPACING:
	{
		float aEmitterRadiusInterp = Sexy::Rand(1.0f);
		float aRadius = FloatTrackEvaluate(mEmitterDef->mEmitterRadius, mSystemTimeValue, aEmitterRadiusInterp);
		// ★ 以竖直向下的方向为 0 角度
		aPosX = sin(aLaunchAngle) * aRadius;
		aPosY = cos(aLaunchAngle) * aRadius;
		break;
	}
	case EmitterType::EMITTER_BOX:
	{
		float aEmitterBoxXInterp = Sexy::Rand(1.0f);
		float aEmitterBoxYInterp = Sexy::Rand(1.0f);
		aPosX = FloatTrackEvaluate(mEmitterDef->mEmitterBoxX, mSystemTimeValue, aEmitterBoxXInterp);
		aPosY = FloatTrackEvaluate(mEmitterDef->mEmitterBoxY, mSystemTimeValue, aEmitterBoxYInterp);
		break;
	}
	case EmitterType::EMITTER_BOX_PATH:
	{
		float aEmitterPathPosition = FloatTrackEvaluate(mEmitterDef->mEmitterPath, mSystemTimeValue, mTrackInterp[ParticleSystemTracks::TRACK_EMITTER_PATH]);
		float aMinX = FloatTrackEvaluate(mEmitterDef->mEmitterBoxX, mSystemTimeValue, 0.0f);
		float aMaxX = FloatTrackEvaluate(mEmitterDef->mEmitterBoxX, mSystemTimeValue, 1.0f);
		float aMinY = FloatTrackEvaluate(mEmitterDef->mEmitterBoxY, mSystemTimeValue, 0.0f);
		float aMaxY = FloatTrackEvaluate(mEmitterDef->mEmitterBoxY, mSystemTimeValue, 1.0f);
		float aDistanceX = aMaxX - aMinX;  // 路径矩形的横向宽度
		float aDistanceY = aMaxY - aMinY;  // 路径矩形的纵向高度
		float aPathPos = aEmitterPathPosition * (aDistanceY + aDistanceX + aDistanceY + aDistanceX);  // 发射点位于矩形边上的位置
		// ★ 注释规定：以矩形左上的顶点开始，按逆时针方向依次将矩形的四个顶点标记为 A、B、C、D，并标记发射点为 P
		// ★           如此，aPathPos 即为 P 点与 A 点在矩形路径上的距离。注意，游戏中取横向水平向右和纵向竖直向下为正方向。
		if (aPathPos < aDistanceY)  // 发射点落在矩形 AB 边（左边）上
		{
			aPosX = aMinX;  // 横坐标 = 矩形左端横坐标
			aPosY = aMinY + aPathPos;  // 纵坐标 = 矩形底端坐标 + |PA|
		}
		else if (aPathPos < aDistanceY + aDistanceX)  // 发射点落在矩形 BC 边（顶边）上
		{
			aPosX = aMinX + (aPathPos - aDistanceY);  // 横坐标 = 矩形左端横坐标 + |PB|
			aPosY = aMaxY;
		}
		else if (aPathPos < aDistanceY + aDistanceX + aDistanceY)  // 发射点落在矩形 CD 边（右边）上
		{
			aPosX = aMaxX;
			aPosY = aMaxY - (aPathPos - aDistanceY - aDistanceX);  // 纵坐标 = 矩形顶端纵坐标 - |PC|
		}
		else  // 发射点落在矩形 AD 边（底边）上
		{
			aPosX = aMaxX - (aPathPos - aDistanceY - aDistanceX - aDistanceY);  // 横坐标 = 矩形右端横坐标 - |PD|
			aPosY = aMinY;
		}
		break;
	}
	default:
		TOD_ASSERT(false);
		break;
	}
	float aEmitterSkewXInterp = Sexy::Rand(1.0f);
	float aEmitterSkewYInterp = Sexy::Rand(1.0f);
	float aSkewX = FloatTrackEvaluate(mEmitterDef->mEmitterSkewX, mSystemTimeValue, aEmitterSkewXInterp);
	float aSkewY = FloatTrackEvaluate(mEmitterDef->mEmitterSkewY, mSystemTimeValue, aEmitterSkewYInterp);
	aParticle->mPosition.x = mSystemCenter.x + aPosX + aPosY * aSkewX;  // 横向（左右）倾斜的幅度受纵坐标影响
	aParticle->mPosition.y = mSystemCenter.y + aPosY + aPosX * aSkewY;  // 纵向（上下）倾斜的幅度受横坐标影响
	aParticle->mVelocity.x = sin(aLaunchAngle) * aLaunchSpeed;
	aParticle->mVelocity.y = cos(aLaunchAngle) * aLaunchSpeed;
	aParticle->mPosition.x += FloatTrackEvaluate(mEmitterDef->mEmitterOffsetX, mSystemTimeValue, aEmitterOffsetXInterp);  // 横坐标加上横向偏移值
	aParticle->mPosition.y += FloatTrackEvaluate(mEmitterDef->mEmitterOffsetY, mSystemTimeValue, aEmitterOffsetYInterp);  // 纵坐标加上纵向偏移值
	
	aParticle->mAnimationTimeValue = 0.0f;
	if (mEmitterDef->mAnimated || FloatTrackIsSet(mEmitterDef->mAnimationRate))
		aParticle->mImageFrame = 0;  // 如果定义了粒子动态或动画速率，则粒子的当前帧将在后续根据粒子时间值或动画循环率实时计算，此处先初始化为 0
	else
		aParticle->mImageFrame = Sexy::Rand(mEmitterDef->mImageFrames);  // 对于帧固定的粒子，在贴图的所有帧中随机取得一帧，后续一般不再变化

	if (TestBit(mEmitterDef->mParticleFlags, (int)ParticleFlags::PARTICLE_RANDOM_LAUNCH_SPIN))
		aParticle->mSpinPosition = Sexy::Rand((float)(2 * PI));  // 在 [0, 2π] 之间随机取得一个初始旋转角度
	else if (TestBit(mEmitterDef->mParticleFlags, (int)ParticleFlags::PARTICLE_ALIGN_LAUNCH_SPIN))
		aParticle->mSpinPosition = aLaunchAngle;  // 粒子旋转角度对齐发射角度
	else
		aParticle->mSpinPosition = 0.0f;  // 默认无初始旋转
	aParticle->mSpinVelocity = 0.0f;
	aParticle->mCrossFadeDuration = 0;
	aParticle->mCrossFadeParticleID = ParticleID::PARTICLEID_NULL;

	ParticleID aParticleID = (ParticleID)aDataArray.DataArrayGetID(aParticle);
	mParticleList.AddHead(aParticleID);
	mParticlesSpawned++;
	UpdateParticle(aParticle);
	return aParticle;
}

// ================= FormB：当前终态（HEAD 逐字） =================
namespace
{
using ParticleSpawnPosCaseFn = void (*)(TodParticleEmitter&, float, float&, float&);

void ParticleSpawnPosEmitterCircle(TodParticleEmitter& e, float aLaunchAngle, float& aPosX, float& aPosY)
{
    		float aEmitterRadiusInterp = Sexy::Rand(1.0f);
    		float aRadius = FloatTrackEvaluate(e.mEmitterDef->mEmitterRadius, e.mSystemTimeValue, aEmitterRadiusInterp);
    		// ★ 以竖直向下的方向为 0 角度
    		aPosX = sin(aLaunchAngle) * aRadius;
    		aPosY = cos(aLaunchAngle) * aRadius;
}

void ParticleSpawnPosDefault(TodParticleEmitter& e, float aLaunchAngle, float& aPosX, float& aPosY)
{
    		TOD_ASSERT(false);
}

constexpr ParticleSpawnPosCaseFn kParticleSpawnPosCases[(int)EmitterType::EMITTER_CIRCLE_EVEN_SPACING + 1] = {
    &ParticleSpawnPosEmitterCircle,  // 0 EMITTER_CIRCLE（共体）
    [](TodParticleEmitter& e, float aLaunchAngle, float& aPosX, float& aPosY)
    {
    		float aEmitterBoxXInterp = Sexy::Rand(1.0f);
    		float aEmitterBoxYInterp = Sexy::Rand(1.0f);
    		aPosX = FloatTrackEvaluate(e.mEmitterDef->mEmitterBoxX, e.mSystemTimeValue, aEmitterBoxXInterp);
    		aPosY = FloatTrackEvaluate(e.mEmitterDef->mEmitterBoxY, e.mSystemTimeValue, aEmitterBoxYInterp);
    },  // 1 EMITTER_BOX
    [](TodParticleEmitter& e, float aLaunchAngle, float& aPosX, float& aPosY)
    {
    		float aEmitterPathPosition = FloatTrackEvaluate(e.mEmitterDef->mEmitterPath, e.mSystemTimeValue, e.mTrackInterp[ParticleSystemTracks::TRACK_EMITTER_PATH]);
    		float aMinX = FloatTrackEvaluate(e.mEmitterDef->mEmitterBoxX, e.mSystemTimeValue, 0.0f);
    		float aMaxX = FloatTrackEvaluate(e.mEmitterDef->mEmitterBoxX, e.mSystemTimeValue, 1.0f);
    		float aMinY = FloatTrackEvaluate(e.mEmitterDef->mEmitterBoxY, e.mSystemTimeValue, 0.0f);
    		float aMaxY = FloatTrackEvaluate(e.mEmitterDef->mEmitterBoxY, e.mSystemTimeValue, 1.0f);
    		float aDistanceX = aMaxX - aMinX;  // 路径矩形的横向宽度
    		float aDistanceY = aMaxY - aMinY;  // 路径矩形的纵向高度
    		float aPathPos = aEmitterPathPosition * (aDistanceY + aDistanceX + aDistanceY + aDistanceX);  // 发射点位于矩形边上的位置
    		// ★ 注释规定：以矩形左上的顶点开始，按逆时针方向依次将矩形的四个顶点标记为 A、B、C、D，并标记发射点为 P
    		// ★           如此，aPathPos 即为 P 点与 A 点在矩形路径上的距离。注意，游戏中取横向水平向右和纵向竖直向下为正方向。
    		if (aPathPos < aDistanceY)  // 发射点落在矩形 AB 边（左边）上
    		{
    			aPosX = aMinX;  // 横坐标 = 矩形左端横坐标
    			aPosY = aMinY + aPathPos;  // 纵坐标 = 矩形底端坐标 + |PA|
    		}
    		else if (aPathPos < aDistanceY + aDistanceX)  // 发射点落在矩形 BC 边（顶边）上
    		{
    			aPosX = aMinX + (aPathPos - aDistanceY);  // 横坐标 = 矩形左端横坐标 + |PB|
    			aPosY = aMaxY;
    		}
    		else if (aPathPos < aDistanceY + aDistanceX + aDistanceY)  // 发射点落在矩形 CD 边（右边）上
    		{
    			aPosX = aMaxX;
    			aPosY = aMaxY - (aPathPos - aDistanceY - aDistanceX);  // 纵坐标 = 矩形顶端纵坐标 - |PC|
    		}
    		else  // 发射点落在矩形 AD 边（底边）上
    		{
    			aPosX = aMaxX - (aPathPos - aDistanceY - aDistanceX - aDistanceY);  // 横坐标 = 矩形右端横坐标 - |PD|
    			aPosY = aMinY;
    		}
    },  // 2 EMITTER_BOX_PATH
    &ParticleSpawnPosEmitterCircle,  // 3 EMITTER_CIRCLE_PATH（共体）
    &ParticleSpawnPosEmitterCircle,  // 4 EMITTER_CIRCLE_EVEN_SPACING（共体）
};
static_assert(sizeof(kParticleSpawnPosCases) / sizeof(kParticleSpawnPosCases[0]) ==
    (int)EmitterType::EMITTER_CIRCLE_EVEN_SPACING + 1, "kParticleSpawnPosCases 槽位数须与 EmitterType 枚举同步");
}  // namespace

__declspec(noinline) TodParticle* TodParticleEmitter::SpawnParticle_B(int theIndex, int theSpawnCount)
{
	DataArray<TodParticle>& aDataArray = mParticleSystem->mParticleHolder->mParticles;
	if (aDataArray.mSize == aDataArray.mMaxSize)
	{
		TodTraceWithoutSpamming("Too many particles '%s'\n", mEmitterDef->mName);
		return nullptr;
	}

	TodParticle* aParticle = aDataArray.DataArrayAlloc();
	TOD_ASSERT(mEmitterDef->mParticleFields.count <= MAX_PARTICLE_FIELDS);
	for (int i = 0; i < mEmitterDef->mParticleFields.count; i++)
	{
		aParticle->mParticleFieldInterp[i][0] = Sexy::Rand(1.0f);  // 初始化每个粒子场的横向插值
		aParticle->mParticleFieldInterp[i][1] = Sexy::Rand(1.0f);  // 初始化每个粒子场的纵向插值
	}
	for (int i = 0; i < (int)ParticleTracks::NUM_PARTICLE_TRACKS; i++)
		aParticle->mParticleInterp[i] = Sexy::Rand(1.0f);  // 初始化每条通道的插值

	float aParticleDurationInterp = Sexy::Rand(1.0f);
	float aLaunchSpeedInterp = Sexy::Rand(1.0f);
	float aEmitterOffsetXInterp = Sexy::Rand(1.0f);
	float aEmitterOffsetYInterp = Sexy::Rand(1.0f);
	aParticle->mParticleDuration = FloatTrackEvaluate(mEmitterDef->mParticleDuration, mSystemTimeValue, aParticleDurationInterp);
	aParticle->mParticleDuration = std::max(1, aParticle->mParticleDuration);  // 初始化粒子持续时间（至少为 1）
	aParticle->mParticleAge = 0;
	aParticle->mParticleEmitter = this;
	aParticle->mParticleTimeValue = -1.0f;
	aParticle->mParticleLastTimeValue = -1.0f;
	if (TestBit(mEmitterDef->mParticleFlags, (int)ParticleFlags::PARTICLE_RANDOM_START_TIME))
		aParticle->mParticleAge = Sexy::Rand(aParticle->mParticleDuration);  // 对于“随机初始时间”的粒子
	float aLaunchSpeed = FloatTrackEvaluate(mEmitterDef->mLaunchSpeed, mSystemTimeValue, aLaunchSpeedInterp) * 0.01f;
	float aLaunchAngleInterp = Sexy::Rand(1.0f);

	float aLaunchAngle;
	if (mEmitterDef->mEmitterType == EmitterType::EMITTER_CIRCLE_PATH)
	{
		// 发射角度 = 根据路径定义计算的圆周上的基础角度 + 根据发射角度定义计算的额外偏移的角度
		aLaunchAngle = FloatTrackEvaluate(mEmitterDef->mEmitterPath, mSystemTimeValue, mTrackInterp[ParticleSystemTracks::TRACK_EMITTER_PATH]) * 2 * PI;
		aLaunchAngle += DEG_TO_RAD(FloatTrackEvaluate(mEmitterDef->mLaunchAngle, mSystemTimeValue, aLaunchAngleInterp));
	}
	else if (mEmitterDef->mEmitterType == EmitterType::EMITTER_CIRCLE_EVEN_SPACING)
		// 基础发射角度要使 theSpawnCount 个粒子平均布满圆周
		aLaunchAngle = 2 * PI * theIndex / theSpawnCount + DEG_TO_RAD(FloatTrackEvaluate(mEmitterDef->mLaunchAngle, mSystemTimeValue, aLaunchAngleInterp));
	else if (FloatTrackIsConstantZero(mEmitterDef->mLaunchAngle))
		// 未定义的轨道，发射角度直接取 [0, 2π] 的随机值
		aLaunchAngle = Sexy::Rand((float)(2 * PI));
	else
		// 其他情况下，根据发射角度的定义值计算
		aLaunchAngle = DEG_TO_RAD(FloatTrackEvaluate(mEmitterDef->mLaunchAngle, mSystemTimeValue, aLaunchAngleInterp));

	float aPosX, aPosY;
	// C 形态 -> 匿名 lambda 函数指针表：行序 = EmitterType 枚举序（0..4）。
	// 三种圆形发射器标签共体 → 具名（匿名 lambda 无法跨槽复用）；
	// aPosX/aPosY 经引用直写（分发点之后消费）；发射角经值参直传。
	// default（TOD_ASSERT）具名并被越界分支复用。
	const unsigned aEmitterKindIndex = static_cast<unsigned>(mEmitterDef->mEmitterType);
	if (aEmitterKindIndex <= static_cast<unsigned>(EmitterType::EMITTER_CIRCLE_EVEN_SPACING))
	{
		kParticleSpawnPosCases[aEmitterKindIndex](*this, aLaunchAngle, aPosX, aPosY);
	}
	else
	{
		ParticleSpawnPosDefault(*this, aLaunchAngle, aPosX, aPosY);
	}

	float aEmitterSkewXInterp = Sexy::Rand(1.0f);
	float aEmitterSkewYInterp = Sexy::Rand(1.0f);
	float aSkewX = FloatTrackEvaluate(mEmitterDef->mEmitterSkewX, mSystemTimeValue, aEmitterSkewXInterp);
	float aSkewY = FloatTrackEvaluate(mEmitterDef->mEmitterSkewY, mSystemTimeValue, aEmitterSkewYInterp);
	aParticle->mPosition.x = mSystemCenter.x + aPosX + aPosY * aSkewX;  // 横向（左右）倾斜的幅度受纵坐标影响
	aParticle->mPosition.y = mSystemCenter.y + aPosY + aPosX * aSkewY;  // 纵向（上下）倾斜的幅度受横坐标影响
	aParticle->mVelocity.x = sin(aLaunchAngle) * aLaunchSpeed;
	aParticle->mVelocity.y = cos(aLaunchAngle) * aLaunchSpeed;
	aParticle->mPosition.x += FloatTrackEvaluate(mEmitterDef->mEmitterOffsetX, mSystemTimeValue, aEmitterOffsetXInterp);  // 横坐标加上横向偏移值
	aParticle->mPosition.y += FloatTrackEvaluate(mEmitterDef->mEmitterOffsetY, mSystemTimeValue, aEmitterOffsetYInterp);  // 纵坐标加上纵向偏移值
	
	aParticle->mAnimationTimeValue = 0.0f;
	if (mEmitterDef->mAnimated || FloatTrackIsSet(mEmitterDef->mAnimationRate))
		aParticle->mImageFrame = 0;  // 如果定义了粒子动态或动画速率，则粒子的当前帧将在后续根据粒子时间值或动画循环率实时计算，此处先初始化为 0
	else
		aParticle->mImageFrame = Sexy::Rand(mEmitterDef->mImageFrames);  // 对于帧固定的粒子，在贴图的所有帧中随机取得一帧，后续一般不再变化

	if (TestBit(mEmitterDef->mParticleFlags, (int)ParticleFlags::PARTICLE_RANDOM_LAUNCH_SPIN))
		aParticle->mSpinPosition = Sexy::Rand((float)(2 * PI));  // 在 [0, 2π] 之间随机取得一个初始旋转角度
	else if (TestBit(mEmitterDef->mParticleFlags, (int)ParticleFlags::PARTICLE_ALIGN_LAUNCH_SPIN))
		aParticle->mSpinPosition = aLaunchAngle;  // 粒子旋转角度对齐发射角度
	else
		aParticle->mSpinPosition = 0.0f;  // 默认无初始旋转
	aParticle->mSpinVelocity = 0.0f;
	aParticle->mCrossFadeDuration = 0;
	aParticle->mCrossFadeParticleID = ParticleID::PARTICLEID_NULL;

	ParticleID aParticleID = (ParticleID)aDataArray.DataArrayGetID(aParticle);
	mParticleList.AddHead(aParticleID);
	mParticlesSpawned++;
	UpdateParticle(aParticle);
	return aParticle;
}

// ---------------- bench driver ----------------
static const int N = 2000000;
static int g_input[N];

static TodParticleHolder g_holder;
static TodParticleSystem g_system;
static TodParticleEmitter g_em;
static TodEmitterDefinition g_defs[5];
static ParticleField g_fieldData[5];

static inline uint64_t FBits(float f) { uint64_t u; memcpy(&u, &f, 4); return u; }

static void MixResult(const TodParticle* p, const TodParticleEmitter& e)
{
    CsMix(FBits(p->mPosition.x) << 32 | FBits(p->mPosition.y));
    CsMix(FBits(p->mVelocity.x) << 32 | FBits(p->mVelocity.y));
    CsMix(FBits(p->mSpinPosition) << 32 | FBits(p->mSpinVelocity));
    CsMix((uint64_t)(unsigned)p->mParticleDuration << 32 | (uint64_t)(unsigned)p->mImageFrame);
    CsMix((uint64_t)(unsigned)p->mParticleAge << 32 | (uint64_t)(unsigned)p->mCrossFadeDuration);
    CsMix((uint64_t)e.mParticlesSpawned * 131 + (uint64_t)e.mParticleList.mCount);
}

static void SetupDefs()
{
    for (int k = 0; k < 5; k++)
    {
        TodEmitterDefinition& d = g_defs[k];
        d.mEmitterType = (EmitterType)k;
        d.mParticleDuration.mCountNodes = 1 + k;
        d.mLaunchSpeed.mCountNodes = 2 + k;
        d.mLaunchAngle.mCountNodes = (k == 0 || k == 3) ? 0 : (3 + k);  // 圆形 0/3 走 IsConstantZero 真分支
        d.mEmitterRadius.mCountNodes = 1 + k;
        d.mEmitterBoxX.mCountNodes = 2 + k;
        d.mEmitterBoxY.mCountNodes = 3 + k;
        d.mEmitterSkewX.mCountNodes = 1;
        d.mEmitterSkewY.mCountNodes = 2;
        d.mEmitterOffsetX.mCountNodes = 1;
        d.mEmitterOffsetY.mCountNodes = 2;
        d.mEmitterPath.mCountNodes = 2;
        d.mAnimationRate.mCountNodes = (k & 1);
        d.mAnimated = (k == 2) ? 1 : 0;
        d.mParticleFlags = (k & 1) ? (1 << PARTICLE_RANDOM_LAUNCH_SPIN) : ((k == 2) ? (1 << PARTICLE_ALIGN_LAUNCH_SPIN) : 0);
        d.mParticleFields.Fields = &g_fieldData[k];
        d.mParticleFields.count = 2;
    }
}

template <int WHICH>
static void RunPass(const int* in, int n, bool mix)
{
    ResetRand();
    g_holder.mParticles.mItems = g_particlePool;
    g_holder.mParticles.mMaxSize = 0x40000000u;
    g_holder.mParticles.mSize = 0;
    g_em.mParticleList.mCount = 0;
    g_em.mParticlesSpawned = 0;
    for (int k = 0; k < n; k++)
    {
        g_em.mEmitterDef = &g_defs[in[k]];
        TodParticle* p = WHICH == 0 ? g_em.SpawnParticle_A(k & 3, 4) : g_em.SpawnParticle_B(k & 3, 4);
        if (mix) MixResult(p, g_em);
    }
}

int main(int argc, char** argv)
{
    int mask = argc > 1 ? atoi(argv[1]) : -1;
    std::mt19937 rng(20261002);
    std::uniform_int_distribution<int> dist(0, (int)EmitterType::EMITTER_CIRCLE_EVEN_SPACING);
    for (int k = 0; k < N; k++) g_input[k] = mask >= 0 ? mask : dist(rng);

    (void)argv;
    SetupDefs();
    g_holder.mParticles.mItems = g_particlePool;
    g_holder.mParticles.mMaxSize = 0x40000000u;
    g_system.mParticleHolder = &g_holder;
    g_em.mParticleSystem = &g_system;
    g_em.mSystemCenter = SexyVector2(400.0f, 300.0f);
    for (int i = 0; i < NUM_SYSTEM_TRACKS; i++) g_em.mTrackInterp[i] = 0.1f * (i + 1);

    // ---- checksum pass ----
    g_cs = 0; RunPass<0>(g_input, N, true); uint64_t csA = g_cs;
    g_cs = 0; RunPass<1>(g_input, N, true); uint64_t csB = g_cs;
    bool csOK = (csA == csB);

    // ---- warmup ----
    RunPass<0>(g_input, 10000, false); RunPass<1>(g_input, 10000, false);

    // ---- timing：min-of-5，A/B 交错 ----
    uint64_t aMin = UINT64_MAX, bMin = UINT64_MAX;
    for (int rep = 0; rep < 5; rep++)
    {
        uint64_t t0 = QpcNow(); RunPass<0>(g_input, N, false); uint64_t t1 = QpcNow();
        uint64_t t2 = QpcNow(); RunPass<1>(g_input, N, false); uint64_t t3 = QpcNow();
        if (t1 - t0 < aMin) aMin = t1 - t0;
        if (t3 - t2 < bMin) bMin = t3 - t2;
    }

    double nsA = QpcToNs(aMin) / N;
    double nsB = QpcToNs(bMin) / N;
    double diff = (nsB - nsA) / nsA * 100.0;
    printf("SpawnParticle | before %.2f ns | after %.2f ns | diff %+.2f%% | checksum=%s (A=%016llx B=%016llx)\n",
        nsA, nsB, diff, csOK ? "OK" : "FAIL", (unsigned long long)csA, (unsigned long long)csB);
    return csOK ? 0 : 1;
}
