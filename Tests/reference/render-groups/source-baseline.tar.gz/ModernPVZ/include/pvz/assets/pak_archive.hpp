#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace pvz::assets {

struct PakEntry {
    std::string path;
    std::uint32_t size{0};
    std::uint64_t windows_file_time{0};
    std::uint64_t data_offset{0};
};

class PakArchive {
public:
    [[nodiscard]] static PakArchive open(const std::filesystem::path& path);

    [[nodiscard]] const std::filesystem::path& path() const noexcept;
    [[nodiscard]] std::span<const PakEntry> entries() const noexcept;
    [[nodiscard]] std::optional<std::reference_wrapper<const PakEntry>> find(
        std::string_view path) const noexcept;

    [[nodiscard]] std::vector<std::uint8_t> read(
        const PakEntry& entry,
        std::uint64_t offset,
        std::size_t size) const;
    [[nodiscard]] std::vector<std::uint8_t> read(const PakEntry& entry) const;

private:
    std::filesystem::path path_;
    std::vector<PakEntry> entries_;
};

} // namespace pvz::assets
