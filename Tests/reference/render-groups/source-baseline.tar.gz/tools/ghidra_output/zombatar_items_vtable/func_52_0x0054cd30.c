
int FUN_0054cd30(int param_1)

{
  undefined4 local_c;
  undefined4 local_8;
  
  local_c = 1;
  for (local_8 = 10; local_8 <= param_1; local_8 = local_8 * 10) {
    local_c = local_c + 1;
  }
  return local_c;
}

