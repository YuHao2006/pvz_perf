/* 0052fcd0 FUN_0052fcd0 */

undefined ** __fastcall FUN_0052fcd0(int param_1)

{
  int *in_EAX;
  uint uVar1;
  undefined **ppuVar2;
  
  uVar1 = *(uint *)(param_1 + 0x24 + *in_EAX * 4);
  ppuVar2 = (undefined **)0x0;
  if (uVar1 != 0xffffffff) {
    if (0x10 < (int)uVar1) {
      uVar1 = uVar1 - uVar1 / 0x11;
    }
    switch(*in_EAX) {
    case 1:
      return &PTR_DAT_0071ca68 + uVar1 * 10;
    case 2:
      return &PTR_DAT_0071c5b8 + uVar1 * 10;
    case 3:
      return &PTR_DAT_0071cc48 + uVar1 * 10;
    case 4:
      return &PTR_DAT_0071c1f8 + uVar1 * 10;
    case 5:
      return &PTR_DAT_0071bf78 + uVar1 * 10;
    case 6:
      return &PTR_DAT_0071c7e8 + uVar1 * 10;
    case 7:
      return &PTR_DAT_0071cea0 + uVar1 * 10;
    case 8:
      ppuVar2 = &PTR_DAT_0071d0d0 + uVar1 * 10;
    }
  }
  return ppuVar2;
}



/* 00530c90 FUN_00530c90 */

void __fastcall FUN_00530c90(undefined4 param_1,int param_2,uint param_3)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  int *piVar5;
  char ****ppppcVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  char ***local_40 [4];
  undefined4 local_30;
  uint local_2c;
  char ***local_24 [4];
  undefined4 local_14;
  uint local_10;
  void *local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c97c0;
  local_c = ExceptionList;
  iVar9 = (*(uint *)(param_2 + 0x148) & 0xffff) * 0xa0 + **(int **)(*(int *)(param_3 + 0x940) + 8);
  uVar8 = 0;
  ExceptionList = &local_c;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_DAT_0071bf98 + uVar8),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_DAT_0071bf98 + uVar8);
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 0;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    cVar2 = FUN_004779e0(ppppcVar6);
    if (cVar2 != '\0') {
      ppppcVar6 = (char ****)local_40[0];
      if (local_2c < 0x10) {
        ppppcVar6 = local_40;
      }
      FUN_00478120(ppppcVar6,0xffffffff);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    uVar8 = uVar8 + 0x28;
  } while (uVar8 < 0x280);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_facialHair_00_0071c218 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_facialHair_00_0071c218 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 1;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(*piVar5 + iVar7),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 0x3c0);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_eyeWear_00_0071c808 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_eyeWear_00_0071c808 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 2;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(*piVar5 + iVar7),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 0x280);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_tidBits_00_0071c5d8 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_tidBits_00_0071c5d8 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 3;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(iVar7 + *piVar5),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 0x230);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_accessories_00_0071cc68 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_accessories_00_0071cc68 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 4;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(iVar7 + *piVar5),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 600);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_DAT_0071cec0 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_DAT_0071cec0 + param_3);
    iVar7 = 0;
    local_10 = 0xf;
    local_14 = 0;
    local_24[0] = (char ***)((uint)local_24[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 5;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_24[0];
    if (local_10 < 0x10) {
      ppppcVar6 = local_24;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(iVar7 + *piVar5),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_24[0];
          if (local_10 < 0x10) {
            ppppcVar6 = local_24;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_10) {
      FUN_00699e4a(local_24[0]);
    }
    param_3 = param_3 + 0x28;
    if (0x22f < param_3) {
      ExceptionList = local_c;
      return;
    }
  } while( true );
}



