
void __fastcall FUN_00531250(int param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  char *pcVar8;
  undefined4 ***pppuVar9;
  undefined4 *puVar10;
  uint local_30;
  undefined4 **local_24 [4];
  undefined4 local_14;
  uint local_10;
  void *local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006cbc48;
  local_c = ExceptionList;
  ExceptionList = &local_c;
  FUN_00530c90(param_2);
  uVar1 = *(uint *)(param_1 + 0x148);
  iVar2 = **(int **)(*(int *)(param_2 + 0x940) + 8);
  local_30 = 0;
  do {
    if ((((local_30 != 8) && (local_30 != 0)) && (local_30 != 1)) &&
       (iVar6 = FUN_0052fcd0(), iVar6 != 0)) {
      FUN_00478120(*(undefined4 *)(iVar6 + 0x20),*(undefined4 *)(iVar6 + 0x24));
      iVar7 = FUN_00477640(*(undefined4 *)(iVar6 + 0x20));
      iVar3 = *(int *)(param_3 + local_30 * 4);
      iVar7 = iVar7 * 0x60 + *(int *)((uVar1 & 0xffff) * 0xa0 + iVar2 + 0x58);
      if (iVar3 == -1) {
        puVar10 = &DAT_007a2300;
      }
      else {
        puVar10 = (undefined4 *)(&DAT_007a2010 + iVar3 * 0x10);
      }
      *(undefined4 *)(iVar7 + 0x4c) = *puVar10;
      *(undefined4 *)(iVar7 + 0x50) = puVar10[1];
      *(undefined4 *)(iVar7 + 0x54) = puVar10[2];
      *(undefined4 *)(iVar7 + 0x58) = puVar10[3];
      pcVar4 = *(char **)(iVar6 + 0x20);
      local_10 = 0xf;
      local_14 = 0;
      local_24[0] = (undefined4 **)((uint)local_24[0] & 0xffffff00);
      pcVar8 = pcVar4;
      do {
        cVar5 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar5 != '\0');
      FUN_004020c0(pcVar4,(int)pcVar8 - (int)(pcVar4 + 1));
      local_4 = 0;
      FUN_00409ad0("_line",5);
      pppuVar9 = (undefined4 ***)local_24[0];
      if (local_10 < 0x10) {
        pppuVar9 = local_24;
      }
      cVar5 = FUN_004779e0(pppuVar9);
      if (cVar5 != '\0') {
        pppuVar9 = (undefined4 ***)local_24[0];
        if (local_10 < 0x10) {
          pppuVar9 = local_24;
        }
        FUN_00478120(pppuVar9,*(int *)(iVar6 + 0x24) + 1);
      }
      local_4 = 0xffffffff;
      if (0xf < local_10) {
        FUN_00699e4a(local_24[0]);
      }
    }
    local_30 = local_30 + 1;
  } while (local_30 < 9);
  ExceptionList = local_c;
  return;
}

