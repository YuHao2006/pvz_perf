#include "pvz/assets/pak_archive.hpp"

#include <algorithm>
#include <cctype>
#include <exception>
#include <iostream>
#include <string>
#include <string_view>

namespace {

[[nodiscard]] std::string lowercase(std::string_view value)
{
    std::string result(value);
    std::ranges::transform(result, result.begin(), [](const unsigned char character) {
        return static_cast<char>(std::tolower(character));
    });
    return result;
}

} // namespace

int main(const int argc, const char* const argv[])
{
    if (argc < 2 || argc > 3) {
        std::cerr << "usage: pvz_pak_list <main.pak> [path-filter]\n";
        return 2;
    }

    try {
        const auto archive = pvz::assets::PakArchive::open(argv[1]);
        const std::string filter = argc == 3 ? lowercase(argv[2]) : std::string{};
        std::size_t matched = 0;

        for (const auto& entry : archive.entries()) {
            if (!filter.empty() && lowercase(entry.path).find(filter) == std::string::npos)
                continue;
            std::cout << entry.size << '\t' << entry.path << '\n';
            ++matched;
        }

        std::cerr << "matched " << matched << " of " << archive.entries().size() << " entries\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "pvz_pak_list: " << error.what() << '\n';
        return 1;
    }
}
