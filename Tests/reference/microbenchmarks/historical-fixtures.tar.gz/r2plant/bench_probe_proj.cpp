// bench_proj.cpp — Projectile.cpp 5 目标段表性能对拍（第二轮补测）
//   #12 kProjSplatRows 14    -> Projectile::DoImpact（static constexpr，照抄 HEAD）
//   #13 kProjInitRows 14     -> Projectile::ProjectileInitialize（HEAD 为裸 constexpr——照抄）
//   #14 kProjMotionCases 10  -> Projectile::UpdateNormalMotion（命名空间级 constexpr——照抄）
//   #15 kProjMinCollisionZ 14-> Projectile::UpdateLobMotion（static constexpr，照抄）
//   #16 kProjRectRows 14     -> Projectile::GetProjectileRect（static constexpr，照抄）
// FormA = 403c1968^ 原函数。注意：#16 BUTTER 槽 B 表 {-15,0,-15,0} 与 A 默认框
// 不同（403c1968 引入的语义差）——checksum 预期 DIFF，逐槽归因见报告。
#include "r2_stub.h"

inline unsigned Rand(unsigned n) { MixCk(0x1090ULL, n); return n ? RngNext() % n : 0u; }

// 全局 Plant 桩（UpdateLobMotion 的 aPlant/aUmbrellaPlant 用）
struct Plant
{
    int mPlantCol = 3, mRow = 2;
    PlantState mState = STATE_READY;
    int mPlantHealth = 300;
    int mEatenFlashCountdown = 0;
    void DoSpecial() { MixCk(0x5000ULL); }
};
inline Plant g_plantPool[4];

// 命中控制（driver 设置）
inline int  g_pFindPlant = 0;   // FindCollisionTargetPlant：0=null 1..4=池下标+1
inline int  g_pFindZombie = 0;  // FindCollisionTarget：0=null 1..16=池下标

#define PROJ_MEMBERS                                                                                            \
    ProjectileType mProjectileType = PROJECTILE_PEA;                                                            \
    ProjectileMotion mMotionType = MOTION_STRAIGHT;                                                             \
    float mPosX = 0, mPosY = 0, mPosZ = 0, mVelX = 0, mVelY = 0, mVelZ = 0, mAccZ = 0, mShadowY = 0;            \
    float mRotation = 0, mRotationSpeed = 0;                                                                    \
    int mX = 0, mY = 0, mWidth = 40, mHeight = 40;                                                              \
    int mRow = 2, mRenderOrder = 0, mFrame = 0, mNumFrames = 1, mAnimCounter = 0, mAnimTicksPerFrame = 0;       \
    int mHitTorchwoodGridX = -1;                                                                                \
    int mCobTargetRow = 0;                                                                                      \
    float mCobTargetX = 0;                                                                                      \
    unsigned mDamageRangeFlags = 0;                                                                             \
    bool mDead = false, mOnHighGround = false;                                                                 \
    int mProjectileAge = 0, mClickBackoffCounter = 0;                                                           \
    AttachmentID mAttachmentID = ATTACHMENTID_NULL;                                                             \
    ZombieID mTargetZombieID = ZOMBIEID_NULL;                                                                   \
    LawnApp* mApp = &g_app;                                                                                     \
    Board* mBoard = &g_board;                                                                                   \
                                                                                                                \
    void PlayImpactSound(Zombie* z) { MixCk(0x5001ULL, (uint64_t)(uintptr_t)z); }                               \
    bool IsSplashDamage(Zombie* z) { return ((int)mProjectileType ^ (int)(uintptr_t)z) % 4 == 0; }              \
    unsigned GetDamageFlags(Zombie* z) { MixCk(0x5002ULL, (uint64_t)(uintptr_t)z); return 5u; }                 \
    void DoSplashDamage(Zombie* z) { MixCk(0x5003ULL, (uint64_t)(uintptr_t)z); }                                \
    void Die() { MixCk(0x5004ULL); }                                                                            \
    void CheckForCollision() { MixCk(0x5005ULL); }                                                              \
    void CheckForHighGround() { MixCk(0x5006ULL); }                                                             \
    Plant* FindCollisionTargetPlant() { MixCk(0x5007ULL); return g_pFindPlant ? &g_plantPool[g_pFindPlant - 1] : nullptr; } \
    Zombie* FindCollisionTarget() { MixCk(0x5008ULL); return g_pFindZombie ? &g_zombiePool[g_pFindZombie - 1] : nullptr; } \
    void AttachParticle(AttachmentID& id, TodParticleSystem* p, float x, float y) { MixCk(0x5009ULL, (uint64_t)(int)(x + y)); (void)id; (void)p; } \
    const ProjectileDef& GetProjectileDef() const { MixCk(0x500AULL); return g_projDefs[mProjectileType & (NUM_PROJECTILES - 1)]; } \
    __declspec(noinline) void ProjectileInitialize(int theX, int theY, int theRenderOrder, int theRow, ProjectileType theProjectileType); \
    __declspec(noinline) void UpdateLobMotion();                                                                \
    __declspec(noinline) void UpdateNormalMotion();                                                             \
    __declspec(noinline) void DoImpact(Zombie* theZombie);                                                      \
    __declspec(noinline) Rect GetProjectileRect();

// ================================================================= FormA
namespace FA {

struct Projectile
{
    PROJ_MEMBERS
};

// ---- #13 ProjectileInitialize（A：9 支链）
void Projectile::ProjectileInitialize(int theX, int theY, int theRenderOrder, int theRow, ProjectileType theProjectileType)
{
    int aGridX = mBoard->PixelToGridXKeepOnBoard(theX, theY);
    mProjectileType = theProjectileType;
    mPosX = theX;
    mPosY = theY;
    mPosZ = 0.0f;
    mVelX = 0.0f;
    mVelY = 0.0f;
    mVelZ = 0.0f;
    mAccZ = 0.0f;
    mShadowY = mBoard->GridToPixelY(aGridX, theRow) + 67.0f;
    mHitTorchwoodGridX = -1;
    mMotionType = ProjectileMotion::MOTION_STRAIGHT;
    mFrame = 0;
    mNumFrames = 1;
    mRow = theRow;
    mCobTargetX = 0.0f;
    mDamageRangeFlags = 0;
    mDead = false;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mCobTargetRow = 0;
    mTargetZombieID = ZombieID::ZOMBIEID_NULL;
    mOnHighGround = mBoard->mGridSquareType[aGridX][theRow] == GridSquareType::GRIDSQUARE_HIGH_GROUND;
    // GOTY 1.2.0.1073 only raises the projectile shadow on the left roof slope.
    if (mBoard->StageHasRoof() && theX < 480)
    {
        mShadowY -= 12.0f;
    }
    mRenderOrder = theRenderOrder;
    mRotation = 0.0f;
    mRotationSpeed = 0.0f;
    mWidth = 40;
    mHeight = 40;
    mProjectileAge = 0;
    mClickBackoffCounter = 0;
    mAnimTicksPerFrame = 0;

    if (mProjectileType == ProjectileType::PROJECTILE_CABBAGE || mProjectileType == ProjectileType::PROJECTILE_BUTTER)
    {
        mRotation = -7 * PI / 25;
        mRotationSpeed = RandRangeFloat(-0.08f, -0.02f);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_MELON || mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
    {
        mRotation = -2 * PI / 5;
        mRotationSpeed = RandRangeFloat(-0.08f, -0.02f);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_KERNEL)
    {
        mRotation = 0.0f;
        mRotationSpeed = RandRangeFloat(-0.2f, -0.08f);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_SNOWPEA)
    {
        TodParticleSystem* aParticle = mApp->AddTodParticle(mPosX + 8.0f, mPosY + 13.0f, 400000, ParticleEffect::PARTICLE_SNOWPEA_TRAIL);
        AttachParticle(mAttachmentID, aParticle, 8.0f, 13.0f);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
    {
        TOD_ASSERT(false);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        mWidth = IMAGE_REANIM_COBCANNON_COB->GetWidth();
        mHeight = IMAGE_REANIM_COBCANNON_COB->GetHeight();
        mRotation = PI / 2;
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_PUFF)
    {
        TodParticleSystem* aParticle = mApp->AddTodParticle(mPosX + 13.0f, mPosY + 13.0f, 400000, ParticleEffect::PARTICLE_PUFFSHROOM_TRAIL);
        AttachParticle(mAttachmentID, aParticle, 13.0f, 13.0f);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL)
    {
        mRotation = RandRangeFloat(0.0f, 2 * PI);
        mRotationSpeed = RandRangeFloat(0.05f, 0.1f);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_STAR)
    {
        mShadowY += 15.0f;
        mRotationSpeed = RandRangeFloat(0.05f, 0.1f);
        if (Rand(2) == 0)
        {
            mRotationSpeed = -mRotationSpeed;
        }
    }

    mAnimCounter = 0;
    mX = (int)mPosX;
    mY = (int)mPosY;
}

// ---- #15 UpdateLobMotion（A：5 支 minCollisionZ 链）
void Projectile::UpdateLobMotion()
{
    if (mProjectileType == ProjectileType::PROJECTILE_COBBIG && mPosZ < -700.0f)
    {
        mVelZ = 8.0f;
        mRow = mCobTargetRow;
        mPosX = mCobTargetX;
        int aCobTargetCol = mBoard->PixelToGridXKeepOnBoard(mCobTargetX, 0);
        mPosY = mBoard->GridToPixelY(aCobTargetCol, mCobTargetRow);
        mShadowY = mPosY + 67.0f;
        mRotation = -PI / 2;
    }

    mVelZ += mAccZ;
    if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY)
    {
        mVelZ += mAccZ;
    }
    mPosX += mVelX;
    mPosY += mVelY;
    mPosZ += mVelZ;

    bool isRising = mVelZ < 0.0f;
    if (isRising && (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL || mProjectileType == ProjectileType::PROJECTILE_COBBIG))
    {
        return;
    }
    if (mProjectileAge > 20)
    {
        if (isRising)
        {
            return;
        }

        float aMinCollisionZ = 0.0f;
        if (mProjectileType == ProjectileType::PROJECTILE_BUTTER)
        {
            aMinCollisionZ = -32.0f;
        }
        else if (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL)
        {
            aMinCollisionZ = 60.0f;
        }
        else if (mProjectileType == ProjectileType::PROJECTILE_MELON || mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
        {
            aMinCollisionZ = -35.0f;
        }
        else if (mProjectileType == ProjectileType::PROJECTILE_CABBAGE || mProjectileType == ProjectileType::PROJECTILE_KERNEL)
        {
            aMinCollisionZ = -30.0f;
        }
        else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
        {
            aMinCollisionZ = -60.0f;
        }
        if (mBoard->mPlantRow[mRow] == PlantRowType::PLANTROW_POOL)
        {
            aMinCollisionZ += 40.0f;
        }

        if (mPosZ <= aMinCollisionZ)
        {
            return;
        }
    }

    Plant* aPlant = nullptr;
    Zombie* aZombie = nullptr;
    if (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL || mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
    {
        aPlant = FindCollisionTargetPlant();
    }
    else
    {
        aZombie = FindCollisionTarget();
    }

    float aGroundZ = 80.0f;
    if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        aGroundZ = -40.0f;
    }
    bool hitGround = mPosZ > aGroundZ;
    if (aZombie == nullptr && aPlant == nullptr && !hitGround)
    {
        return;
    }

    if (aPlant)
    {
        Plant* aUmbrellaPlant = mBoard->FindUmbrellaPlant(aPlant->mPlantCol, aPlant->mRow);
        if (aUmbrellaPlant)
        {
            if (aUmbrellaPlant->mState == PlantState::STATE_UMBRELLA_REFLECTING)
            {
                mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
                int aRenderPosition = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_TOP, 0, 1);
                mApp->AddTodParticle(mPosX + 20.0f, mPosY + 20.0f, aRenderPosition, ParticleEffect::PARTICLE_UMBRELLA_REFLECT);
                Die();
            }
            else if (aUmbrellaPlant->mState != PlantState::STATE_UMBRELLA_TRIGGERED)
            {
                mApp->PlayFoley(FoleyType::FOLEY_UMBRELLA);
                aUmbrellaPlant->DoSpecial();
            }
        }
        else
        {
            aPlant->mPlantHealth -= GetProjectileDef().mDamage;
            aPlant->mEatenFlashCountdown = std::max(aPlant->mEatenFlashCountdown, 25);
            mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
            Die();
        }
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        int aBeforeGargantuarCount = mBoard->GetLiveGargantuarCount();
        mBoard->KillAllZombiesInRadius(mRow, mPosX + 80, mPosY + 40, 115, 1, true, mDamageRangeFlags);
        int aAfterGargantuarCount = mBoard->GetLiveGargantuarCount();
        mBoard->mGargantuarsKillsByCornCob += aBeforeGargantuarCount - aAfterGargantuarCount;
        if (mBoard->mGargantuarsKillsByCornCob >= 2)
            ReportAchievement::GiveAchievement(mApp, PopcornParty, true);

        DoImpact(nullptr);
    }
    else
    {
        DoImpact(aZombie);
    }
}

// ---- #14 UpdateNormalMotion（A：7 支链 + else）
void Projectile::UpdateNormalMotion()
{
    if (mMotionType == ProjectileMotion::MOTION_BACKWARDS)
    {
        mPosX -= 3.33f;
    }
    else if (mMotionType == ProjectileMotion::MOTION_HOMING)
    {
        Zombie* aZombie = mBoard->ZombieTryToGet(mTargetZombieID);
        if (aZombie && aZombie->EffectedByDamage((unsigned int)mDamageRangeFlags))
        {
            Rect aZombieRect = aZombie->GetZombieRect();
            SexyVector2 aTargetCenter(aZombie->ZombieTargetLeadX(0.0f), aZombieRect.mY + aZombieRect.mHeight / 2);
            SexyVector2 aProjectileCenter(mPosX + mWidth / 2, mPosY + mHeight / 2);
            SexyVector2 aToTarget = (aTargetCenter - aProjectileCenter).Normalize();
            SexyVector2 aMotion(mVelX, mVelY);

            aMotion += aToTarget * (0.001f * mProjectileAge);
            aMotion = aMotion.Normalize();
            aMotion *= 2.0f;

            mVelX = aMotion.x;
            mVelY = aMotion.y;
            mRotation = -atan2(mVelY, mVelX);
        }

        mPosY += mVelY;
        mPosX += mVelX;
        mShadowY += mVelY;
        mRow = mBoard->PixelToGridYKeepOnBoard(mPosX, mPosY);
    }
    else if (mMotionType == ProjectileMotion::MOTION_STAR)
    {
        mPosY += mVelY;
        mPosX += mVelX;
        mShadowY += mVelY;

        if (mVelY != 0.0f)
        {
            mRow = mBoard->PixelToGridYKeepOnBoard(mPosX, mPosY);
        }
    }
    else if (mMotionType == ProjectileMotion::MOTION_BEE)
    {
        if (mProjectileAge < 60)
        {
            mPosY -= 0.5f;
        }
        mPosX += 3.33f;
    }
    else if (mMotionType == ProjectileMotion::MOTION_FLOAT_OVER)
    {
        if (mVelZ < 0.0f)
        {
            mVelZ += 0.002f;
            mVelZ = std::min(mVelZ, 0.0f);
            mPosY += mVelZ;
            mRotation = 0.3f - 0.7f * mVelZ * PI * 0.25f;
        }
        mPosX += 0.4f;
    }
    else if (mMotionType == ProjectileMotion::MOTION_BEE_BACKWARDS)
    {
        if (mProjectileAge < 60)
        {
            mPosY -= 0.5f;
        }
        mPosX -= 3.33f;
    }
    else if (mMotionType == ProjectileMotion::MOTION_THREEPEATER)
    {
        mPosX += 3.33f;
        mPosY += mVelY;
        mVelY *= 0.97f;
        mShadowY += mVelY;
    }
    else
    {
        mPosX += 3.33f;
    }

    if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY)
    {
        if (mMotionType == ProjectileMotion::MOTION_FLOAT_OVER)
        {
            mVelZ += 0.004f;
        }
        else
        {
            mVelZ += 0.2f;
        }

        mPosY += mVelZ;
    }

    CheckForCollision();
    CheckForHighGround();
}

// ---- #12 DoImpact（A：10 支溅落链）
void Projectile::DoImpact(Zombie* theZombie)
{
    PlayImpactSound(theZombie);

    if (IsSplashDamage(theZombie))
    {
        if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL && theZombie)
        {
            theZombie->RemoveColdEffects();
        }

        DoSplashDamage(theZombie);
    }
    else if (theZombie)
    {
        unsigned int aDamageFlags = GetDamageFlags(theZombie);
        theZombie->TakeDamage(GetProjectileDef().mDamage, aDamageFlags);
    }

    float aLastPosX = mPosX - mVelX;
    float aLastPosY = mPosY + mPosZ - mVelY - mVelZ;
    ParticleEffect aEffect = ParticleEffect::PARTICLE_NONE;
    float aSplatPosX = mPosX + 12.0f;
    float aSplatPosY = mPosY + 12.0f;
    if (mProjectileType == ProjectileType::PROJECTILE_MELON)
    {
        mApp->AddTodParticle(aLastPosX + 30.0f, aLastPosY + 30.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_MELONSPLASH);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
    {
        mApp->AddTodParticle(aLastPosX + 30.0f, aLastPosY + 30.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_WINTERMELON);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        int aRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_GROUND, mCobTargetRow, 2);
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 40.0f, aRenderOrder, ParticleEffect::PARTICLE_BLASTMARK);
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 40.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_POPCORNSPLASH);
        mApp->PlaySample(SOUND_DOOMSHROOM);
        mBoard->ShakeBoard(3, -4);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_PEA)
    {
        aSplatPosX -= 15.0f;
        aEffect = ParticleEffect::PARTICLE_PEA_SPLAT;
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_SNOWPEA)
    {
        aSplatPosX -= 15.0f;
        aEffect = ParticleEffect::PARTICLE_SNOWPEA_SPLAT;
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
    {
        if (IsSplashDamage(theZombie))
        {
            Reanimation* aFireReanim = mApp->AddReanimation(mPosX + 38.0f, mPosY - 20.0f, mRenderOrder + 1, ReanimationType::REANIM_JALAPENO_FIRE);
            aFireReanim->mAnimTime = 0.25f;
            aFireReanim->mAnimRate = 24.0f;
            aFireReanim->OverrideScale(0.7f, 0.4f);
        }
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_STAR)
    {
        aEffect = ParticleEffect::PARTICLE_STAR_SPLAT;
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_PUFF)
    {
        aSplatPosX -= 20.0f;
        aEffect = ParticleEffect::PARTICLE_PUFF_SPLAT;
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_CABBAGE)
    {
        aSplatPosX = aLastPosX - 38.0f;
        aSplatPosY = aLastPosY + 23.0f;
        aEffect = ParticleEffect::PARTICLE_CABBAGE_SPLAT;
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_BUTTER)
    {
        aSplatPosX = aLastPosX - 20.0f;
        aSplatPosY = aLastPosY + 63.0f;
        aEffect = ParticleEffect::PARTICLE_BUTTER_SPLAT;

        if (theZombie)
        {
            theZombie->ApplyButter();
        }
    }

    if (aEffect != ParticleEffect::PARTICLE_NONE)
    {
        if (theZombie)
        {
            float aPosX = aSplatPosX + 52.0f - theZombie->mX;
            float aPosY = aSplatPosY - theZombie->mY;
            if (theZombie->mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL || theZombie->mZombiePhase == ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL)
            {
                aPosY += 60.0f;
            }
            if (mMotionType == ProjectileMotion::MOTION_BACKWARDS)
            {
                aPosX -= 80.0f;
            }
            else if (mPosX > theZombie->mX + 40 && mMotionType != ProjectileMotion::MOTION_LOBBED)
            {
                aPosX -= 60.0f;
            }

            aPosY = ClampFloat(aPosY, 20.0f, 100.0f);
            theZombie->AddAttachedParticle(aPosX, aPosY, aEffect);
        }
        else
        {
            mApp->AddTodParticle(aSplatPosX, aSplatPosY, mRenderOrder + 1, aEffect);
        }
    }

    Die();
}

// ---- #16 GetProjectileRect（A：5 支链）
Rect Projectile::GetProjectileRect()
{
    if (mProjectileType == ProjectileType::PROJECTILE_PEA ||
        mProjectileType == ProjectileType::PROJECTILE_SNOWPEA ||
        mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
    {
        return Rect(mX - 15, mY, mWidth + 15, mHeight);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        return Rect(mX + mWidth / 2 - 115, mY + mHeight / 2 - 115, 230, 230);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_MELON || mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
    {
        return Rect(mX + 20, mY, 60, mHeight);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
    {
        return Rect(mX, mY, mWidth - 10, mHeight);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_SPIKE)
    {
        return Rect(mX - 25, mY, mWidth + 25, mHeight);
    }
    else
    {
        return Rect(mX, mY, mWidth, mHeight);
    }
}

} // namespace FA

// ================================================================= FormB
namespace FB {

struct Projectile
{
    PROJ_MEMBERS
};

// ---- #13 ProjectileInitialize（B：kProjInitRows 14 槽，HEAD 为裸 constexpr——照抄）
void Projectile::ProjectileInitialize(int theX, int theY, int theRenderOrder, int theRow, ProjectileType theProjectileType)
{
    int aGridX = mBoard->PixelToGridXKeepOnBoard(theX, theY);
    mProjectileType = theProjectileType;
    mPosX = theX;
    mPosY = theY;
    mPosZ = 0.0f;
    mVelX = 0.0f;
    mVelY = 0.0f;
    mVelZ = 0.0f;
    mAccZ = 0.0f;
    mShadowY = mBoard->GridToPixelY(aGridX, theRow) + 67.0f;
    mHitTorchwoodGridX = -1;
    mMotionType = ProjectileMotion::MOTION_STRAIGHT;
    mFrame = 0;
    mNumFrames = 1;
    mRow = theRow;
    mCobTargetX = 0.0f;
    mDamageRangeFlags = 0;
    mDead = false;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mCobTargetRow = 0;
    mTargetZombieID = ZombieID::ZOMBIEID_NULL;
    mOnHighGround = mBoard->mGridSquareType[aGridX][theRow] == GridSquareType::GRIDSQUARE_HIGH_GROUND;
    // GOTY 1.2.0.1073 only raises the projectile shadow on the left roof slope.
    if (mBoard->StageHasRoof() && theX < 480)
    {
        mShadowY -= 12.0f;
    }
    mRenderOrder = theRenderOrder;
    mRotation = 0.0f;
    mRotationSpeed = 0.0f;
    mWidth = 40;
    mHeight = 40;
    mProjectileAge = 0;
    mClickBackoffCounter = 0;
    mAnimTicksPerFrame = 0;

    // B 形态 -> 常量表 kProjInitRows（原 9 支链合并；行序 = ProjectileType 枚举序 0..13）
    static constexpr struct {
        float mRotation;
        float mSpeedLo;
        float mSpeedHi;
        float mShadowDY;
        ParticleEffect mTrail;
        float mTrailOffX;
        float mTrailOffY;
        Image* const* mSizeImage;
        bool mRandomRot;
        bool mFlipSpeed;
    } kProjInitRows[(int)ProjectileType::NUM_PROJECTILES] = {
        { 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     false, false },  // 0 PEA（原链不匹配）
        { 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_SNOWPEA_TRAIL,  8.0f, 13.0f, nullptr,                    false, false },  // 1 SNOWPEA
        { (float)(-7 * PI / 25), -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                     false, false },  // 2 CABBAGE
        { (float)(-2 * PI / 5),  -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                     false, false },  // 3 MELON
        { 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_PUFFSHROOM_TRAIL, 13.0f, 13.0f, nullptr,              false, false },  // 4 PUFF
        { (float)(-2 * PI / 5),  -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                     false, false },  // 5 WINTERMELON（共体）
        { 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     false, false },  // 6 FIREBALL（断言见表外）
        { 0.0f,              0.05f,  0.1f,  15.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     false, true  },  // 7 STAR
        { 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     false, false },  // 8 SPIKE（原链不匹配）
        { 0.0f,              0.05f,  0.1f,   0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     true,  false },  // 9 BASKETBALL
        { 0.0f,             -0.2f,  -0.08f,  0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     false, false },  // 10 KERNEL
        { (float)(PI / 2),   0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, &IMAGE_REANIM_COBCANNON_COB, false, false },  // 11 COBBIG
        { (float)(-7 * PI / 25), -0.08f, -0.02f,  0.0f, ParticleEffect::PARTICLE_NONE,       0.0f,  0.0f, nullptr,                     false, false },  // 12 BUTTER（共体）
        { 0.0f,              0.0f,   0.0f,   0.0f, ParticleEffect::PARTICLE_NONE,           0.0f,  0.0f, nullptr,                     false, false },  // 13 ZOMBIE_PEA（原链不匹配）
    };
    static_assert(sizeof(kProjInitRows) / sizeof(kProjInitRows[0]) == (int)ProjectileType::NUM_PROJECTILES,
        "kProjInitRows 槽位须与 ProjectileType 枚举同步");

    if ((unsigned)mProjectileType < sizeof(kProjInitRows) / sizeof(kProjInitRows[0]))
    {
        const auto& aRow = kProjInitRows[(int)mProjectileType];
        if (aRow.mSizeImage != nullptr)
        {
            mWidth = (*aRow.mSizeImage)->GetWidth();
            mHeight = (*aRow.mSizeImage)->GetHeight();
        }
        mRotation = aRow.mRandomRot ? RandRangeFloat(0.0f, 2 * PI) : aRow.mRotation;
        if (aRow.mSpeedLo != 0.0f || aRow.mSpeedHi != 0.0f)
        {
            mRotationSpeed = RandRangeFloat(aRow.mSpeedLo, aRow.mSpeedHi);
            if (aRow.mFlipSpeed && Rand(2) == 0)
            {
                mRotationSpeed = -mRotationSpeed;
            }
        }
        if (aRow.mShadowDY != 0.0f)
        {
            mShadowY += aRow.mShadowDY;
        }
        if (aRow.mTrail != ParticleEffect::PARTICLE_NONE)
        {
            TodParticleSystem* aParticle = mApp->AddTodParticle(mPosX + aRow.mTrailOffX, mPosY + aRow.mTrailOffY, 400000, aRow.mTrail);
            AttachParticle(mAttachmentID, aParticle, aRow.mTrailOffX, aRow.mTrailOffY);
        }
    }

    // 表外特例：FIREBALL 不应经 ProjectileInitialize 产生（原链内联断言）
    if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
    {
        TOD_ASSERT(false);
    }

    mAnimCounter = 0;
    mX = (int)mPosX;
    mY = (int)mPosY;
}

// ---- #15 UpdateLobMotion（B：kProjMinCollisionZ 14 槽 static constexpr——照抄）
void Projectile::UpdateLobMotion()
{
    if (mProjectileType == ProjectileType::PROJECTILE_COBBIG && mPosZ < -700.0f)
    {
        mVelZ = 8.0f;
        mRow = mCobTargetRow;
        mPosX = mCobTargetX;
        int aCobTargetCol = mBoard->PixelToGridXKeepOnBoard(mCobTargetX, 0);
        mPosY = mBoard->GridToPixelY(aCobTargetCol, mCobTargetRow);
        mShadowY = mPosY + 67.0f;
        mRotation = -PI / 2;
    }

    mVelZ += mAccZ;
    if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY)
    {
        mVelZ += mAccZ;
    }
    mPosX += mVelX;
    mPosY += mVelY;
    mPosZ += mVelZ;

    bool isRising = mVelZ < 0.0f;
    if (isRising && (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL || mProjectileType == ProjectileType::PROJECTILE_COBBIG))
    {
        return;
    }
    if (mProjectileAge > 20)
    {
        if (isRising)
        {
            return;
        }

        float aMinCollisionZ = 0.0f;

        // B 形态 -> 常量表 kProjMinCollisionZ（原 5 支链合并；行序 = ProjectileType 0..13）
        static constexpr float kProjMinCollisionZ[(int)ProjectileType::NUM_PROJECTILES] = {
            0.0f,    // 0 PEA（原默认）
            0.0f,    // 1 SNOWPEA（原默认）
            -30.0f,  // 2 CABBAGE
            -35.0f,  // 3 MELON
            0.0f,    // 4 PUFF（原默认）
            -35.0f,  // 5 WINTERMELON（共体）
            0.0f,    // 6 FIREBALL（原默认）
            0.0f,    // 7 STAR（原默认）
            0.0f,    // 8 SPIKE（原默认）
            60.0f,   // 9 BASKETBALL
            -30.0f,  // 10 KERNEL（共体）
            -60.0f,  // 11 COBBIG
            -32.0f,  // 12 BUTTER
            0.0f,    // 13 ZOMBIE_PEA（原默认）
        };
        static_assert(sizeof(kProjMinCollisionZ) / sizeof(kProjMinCollisionZ[0]) == (int)ProjectileType::NUM_PROJECTILES,
            "kProjMinCollisionZ 槽位须与 ProjectileType 枚举同步");

        if ((unsigned)mProjectileType < sizeof(kProjMinCollisionZ) / sizeof(kProjMinCollisionZ[0]))
        {
            aMinCollisionZ = kProjMinCollisionZ[(int)mProjectileType];
        }
        if (mBoard->mPlantRow[mRow] == PlantRowType::PLANTROW_POOL)
        {
            aMinCollisionZ += 40.0f;
        }

        if (mPosZ <= aMinCollisionZ)
        {
            return;
        }
    }

    Plant* aPlant = nullptr;
    Zombie* aZombie = nullptr;
    if (mProjectileType == ProjectileType::PROJECTILE_BASKETBALL || mProjectileType == ProjectileType::PROJECTILE_ZOMBIE_PEA)
    {
        aPlant = FindCollisionTargetPlant();
    }
    else
    {
        aZombie = FindCollisionTarget();
    }

    float aGroundZ = 80.0f;
    if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        aGroundZ = -40.0f;
    }
    bool hitGround = mPosZ > aGroundZ;
    if (aZombie == nullptr && aPlant == nullptr && !hitGround)
    {
        return;
    }

    if (aPlant)
    {
        Plant* aUmbrellaPlant = mBoard->FindUmbrellaPlant(aPlant->mPlantCol, aPlant->mRow);
        if (aUmbrellaPlant)
        {
            if (aUmbrellaPlant->mState == PlantState::STATE_UMBRELLA_REFLECTING)
            {
                mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
                int aRenderPosition = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_TOP, 0, 1);
                mApp->AddTodParticle(mPosX + 20.0f, mPosY + 20.0f, aRenderPosition, ParticleEffect::PARTICLE_UMBRELLA_REFLECT);
                Die();
            }
            else if (aUmbrellaPlant->mState != PlantState::STATE_UMBRELLA_TRIGGERED)
            {
                mApp->PlayFoley(FoleyType::FOLEY_UMBRELLA);
                aUmbrellaPlant->DoSpecial();
            }
        }
        else
        {
            aPlant->mPlantHealth -= GetProjectileDef().mDamage;
            aPlant->mEatenFlashCountdown = std::max(aPlant->mEatenFlashCountdown, 25);
            mApp->PlayFoley(FoleyType::FOLEY_SPLAT);
            Die();
        }
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        int aBeforeGargantuarCount = mBoard->GetLiveGargantuarCount();
        mBoard->KillAllZombiesInRadius(mRow, mPosX + 80, mPosY + 40, 115, 1, true, mDamageRangeFlags);
        int aAfterGargantuarCount = mBoard->GetLiveGargantuarCount();
        mBoard->mGargantuarsKillsByCornCob += aBeforeGargantuarCount - aAfterGargantuarCount;
        if (mBoard->mGargantuarsKillsByCornCob >= 2)
            ReportAchievement::GiveAchievement(mApp, PopcornParty, true);

        DoImpact(nullptr);
    }
    else
    {
        DoImpact(aZombie);
    }
}

namespace
{
// Projectile::UpdateNormalMotion 分发表：表内匿名 lambda = 原 case 体逐句迁移
using ProjMotionFn = void (*)(Projectile&);

// 原 else（无 case 的 0/1/5 型与表外值共用）
void ProjMotionDefault(Projectile& p)
{
    p.mPosX += 3.33f;
}

// 匿名 lambda 函数指针表，行序 = ProjectileMotion 枚举值序（0..9）。
constexpr ProjMotionFn kProjMotionCases[(int)ProjectileMotion::MOTION_HOMING + 1] = {
    &ProjMotionDefault,  // 0 MOTION_STRAIGHT（原 else）
    &ProjMotionDefault,  // 1 MOTION_LOBBED（原 else）
    [](Projectile& p)
    {
        p.mPosX += 3.33f;
        p.mPosY += p.mVelY;
        p.mVelY *= 0.97f;
        p.mShadowY += p.mVelY;
    },  // 2 MOTION_THREEPEATER
    [](Projectile& p)
    {
        if (p.mProjectileAge < 60)
        {
            p.mPosY -= 0.5f;
        }
        p.mPosX += 3.33f;
    },  // 3 MOTION_BEE
    [](Projectile& p)
    {
        if (p.mProjectileAge < 60)
        {
            p.mPosY -= 0.5f;
        }
        p.mPosX -= 3.33f;
    },  // 4 MOTION_BEE_BACKWARDS
    &ProjMotionDefault,  // 5 MOTION_PUFF（原 else）
    [](Projectile& p)
    {
        p.mPosX -= 3.33f;
    },  // 6 MOTION_BACKWARDS
    [](Projectile& p)
    {
        p.mPosY += p.mVelY;
        p.mPosX += p.mVelX;
        p.mShadowY += p.mVelY;

        if (p.mVelY != 0.0f)
        {
            p.mRow = p.mBoard->PixelToGridYKeepOnBoard(p.mPosX, p.mPosY);
        }
    },  // 7 MOTION_STAR
    [](Projectile& p)
    {
        if (p.mVelZ < 0.0f)
        {
            p.mVelZ += 0.002f;
            p.mVelZ = std::min(p.mVelZ, 0.0f);
            p.mPosY += p.mVelZ;
            p.mRotation = 0.3f - 0.7f * p.mVelZ * PI * 0.25f;
        }
        p.mPosX += 0.4f;
    },  // 8 MOTION_FLOAT_OVER
    [](Projectile& p)
    {
        Zombie* aZombie = p.mBoard->ZombieTryToGet(p.mTargetZombieID);
        if (aZombie && aZombie->EffectedByDamage((unsigned int)p.mDamageRangeFlags))
        {
            Rect aZombieRect = aZombie->GetZombieRect();
            SexyVector2 aTargetCenter(aZombie->ZombieTargetLeadX(0.0f), aZombieRect.mY + aZombieRect.mHeight / 2);
            SexyVector2 aProjectileCenter(p.mPosX + p.mWidth / 2, p.mPosY + p.mHeight / 2);
            SexyVector2 aToTarget = (aTargetCenter - aProjectileCenter).Normalize();
            SexyVector2 aMotion(p.mVelX, p.mVelY);

            aMotion += aToTarget * (0.001f * p.mProjectileAge);
            aMotion = aMotion.Normalize();
            aMotion *= 2.0f;

            p.mVelX = aMotion.x;
            p.mVelY = aMotion.y;
            p.mRotation = -atan2(p.mVelY, p.mVelX);
        }

        p.mPosY += p.mVelY;
        p.mPosX += p.mVelX;
        p.mShadowY += p.mVelY;
        p.mRow = p.mBoard->PixelToGridYKeepOnBoard(p.mPosX, p.mPosY);
    },  // 9 MOTION_HOMING
};
static_assert(sizeof(kProjMotionCases) / sizeof(kProjMotionCases[0]) ==
    (int)ProjectileMotion::MOTION_HOMING + 1, "kProjMotionCases 槽位数须与 ProjectileMotion 枚举同步");
}  // namespace

// ---- #14 UpdateNormalMotion（B：kProjMotionCases 10 槽，命名空间级 constexpr——照抄）
void Projectile::UpdateNormalMotion()
{
    const unsigned aMotionIndex = static_cast<unsigned>(mMotionType);
    if (aMotionIndex <= static_cast<unsigned>(ProjectileMotion::MOTION_HOMING))
    {
        kProjMotionCases[aMotionIndex](*this);
    }
    else
    {
        ProjMotionDefault(*this);
    }

    if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY)
    {
        if (mMotionType == ProjectileMotion::MOTION_FLOAT_OVER)
        {
            mVelZ += 0.004f;
        }
        else
        {
            mVelZ += 0.2f;
        }

        mPosY += mVelZ;
    }

    CheckForCollision();
    CheckForHighGround();
}

// ---- #12 DoImpact（B：kProjSplatRows 14 槽 static constexpr——照抄）
void Projectile::DoImpact(Zombie* theZombie)
{
    PlayImpactSound(theZombie);

    if (IsSplashDamage(theZombie))
    {
        if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL && theZombie)
        {
            theZombie->RemoveColdEffects();
        }

        DoSplashDamage(theZombie);
    }
    else if (theZombie)
    {
        unsigned int aDamageFlags = GetDamageFlags(theZombie);
        theZombie->TakeDamage(GetProjectileDef().mDamage, aDamageFlags);
    }

    float aLastPosX = mPosX - mVelX;
    float aLastPosY = mPosY + mPosZ - mVelY - mVelZ;
    ParticleEffect aEffect = ParticleEffect::PARTICLE_NONE;
    float aSplatPosX = mPosX + 12.0f;
    float aSplatPosY = mPosY + 12.0f;

    // B 形态 -> 常量表 kProjSplatRows（原 10 支链中 6 支同构溅落合并）
    static constexpr struct { ParticleEffect mEffect; float mOffX; float mOffY; bool mFromLastPos; } kProjSplatRows[(int)ProjectileType::NUM_PROJECTILES] = {
        { ParticleEffect::PARTICLE_PEA_SPLAT,      -15.0f,   0.0f, false },  // 0 PEA
        { ParticleEffect::PARTICLE_SNOWPEA_SPLAT, -15.0f,   0.0f, false },  // 1 SNOWPEA
        { ParticleEffect::PARTICLE_CABBAGE_SPLAT, -38.0f,  23.0f, true  },  // 2 CABBAGE
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 3 MELON（表外直加）
        { ParticleEffect::PARTICLE_PUFF_SPLAT,    -20.0f,   0.0f, false },  // 4 PUFF
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 5 WINTERMELON（表外直加）
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 6 FIREBALL（表外加火苗）
        { ParticleEffect::PARTICLE_STAR_SPLAT,     0.0f,   0.0f, false },  // 7 STAR
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 8 SPIKE（原链不匹配）
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 9 BASKETBALL（原链不匹配）
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 10 KERNEL（原链不匹配）
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 11 COBBIG（表外爆记）
        { ParticleEffect::PARTICLE_BUTTER_SPLAT, -20.0f,  63.0f, true  },  // 12 BUTTER（ApplyButter 见表外）
        { ParticleEffect::PARTICLE_NONE,           0.0f,   0.0f, false },  // 13 ZOMBIE_PEA（原链不匹配）
    };
    static_assert(sizeof(kProjSplatRows) / sizeof(kProjSplatRows[0]) == (int)ProjectileType::NUM_PROJECTILES,
        "kProjSplatRows 槽位须与 ProjectileType 枚举同步");

    if ((unsigned)mProjectileType < sizeof(kProjSplatRows) / sizeof(kProjSplatRows[0]))
    {
        const auto& aRow = kProjSplatRows[(int)mProjectileType];
        if (aRow.mEffect != ParticleEffect::PARTICLE_NONE)
        {
            aEffect = aRow.mEffect;
            if (aRow.mFromLastPos)
            {
                aSplatPosX = aLastPosX + aRow.mOffX;
                aSplatPosY = aLastPosY + aRow.mOffY;
            }
            else
            {
                aSplatPosX += aRow.mOffX;
                aSplatPosY += aRow.mOffY;
            }
        }
    }

    // 表外特例：MELON/WINTERMELON 无条件直加溅落；COBBIG 爆记 + 爆米花 + 音效 +
    // 震屏；FIREBALL 溅射命中时加火苗 reanim；BUTTER 命中僵尸上黄油。
    if (mProjectileType == ProjectileType::PROJECTILE_MELON)
    {
        mApp->AddTodParticle(aLastPosX + 30.0f, aLastPosY + 30.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_MELONSPLASH);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_WINTERMELON)
    {
        mApp->AddTodParticle(aLastPosX + 30.0f, aLastPosY + 30.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_WINTERMELON);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        int aRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_GROUND, mCobTargetRow, 2);
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 40.0f, aRenderOrder, ParticleEffect::PARTICLE_BLASTMARK);
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 40.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_POPCORNSPLASH);
        mApp->PlaySample(SOUND_DOOMSHROOM);
        mBoard->ShakeBoard(3, -4);
    }
    else if (mProjectileType == ProjectileType::PROJECTILE_FIREBALL)
    {
        if (IsSplashDamage(theZombie))
        {
            Reanimation* aFireReanim = mApp->AddReanimation(mPosX + 38.0f, mPosY - 20.0f, mRenderOrder + 1, ReanimationType::REANIM_JALAPENO_FIRE);
            aFireReanim->mAnimTime = 0.25f;
            aFireReanim->mAnimRate = 24.0f;
            aFireReanim->OverrideScale(0.7f, 0.4f);
        }
    }

    if (mProjectileType == ProjectileType::PROJECTILE_BUTTER && theZombie)
    {
        theZombie->ApplyButter();
    }

    if (aEffect != ParticleEffect::PARTICLE_NONE)
    {
        if (theZombie)
        {
            float aPosX = aSplatPosX + 52.0f - theZombie->mX;
            float aPosY = aSplatPosY - theZombie->mY;
            if (theZombie->mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL || theZombie->mZombiePhase == ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL)
            {
                aPosY += 60.0f;
            }
            if (mMotionType == ProjectileMotion::MOTION_BACKWARDS)
            {
                aPosX -= 80.0f;
            }
            else if (mPosX > theZombie->mX + 40 && mMotionType != ProjectileMotion::MOTION_LOBBED)
            {
                aPosX -= 60.0f;
            }

            aPosY = ClampFloat(aPosY, 20.0f, 100.0f);
            theZombie->AddAttachedParticle(aPosX, aPosY, aEffect);
        }
        else
        {
            mApp->AddTodParticle(aSplatPosX, aSplatPosY, mRenderOrder + 1, aEffect);
        }
    }

    Die();
}

// ---- #16 GetProjectileRect（B：kProjRectRows 14 槽 static constexpr——照抄）
Rect Projectile::GetProjectileRect()
{
    // B 形态 -> 常量表 kProjRectRows（原 5 支链合并）。COBBIG 表外特例先行分发。
    if (mProjectileType == ProjectileType::PROJECTILE_COBBIG)
    {
        return Rect(mX + mWidth / 2 - 115, mY + mHeight / 2 - 115, 230, 230);
    }

    static constexpr struct { int mDX; int mDY; int mW; int mH; } kProjRectRows[(int)ProjectileType::NUM_PROJECTILES] = {
        { -15, 0, -15, 0 },  // 0 PEA
        { -15, 0, -15, 0 },  // 1 SNOWPEA（共体）
        {   0, 0,   0, 0 },  // 2 CABBAGE（原默认）
        {  20, 0,  60, 0 },  // 3 MELON
        {   0, 0,   0, 0 },  // 4 PUFF（原默认）
        {  20, 0,  60, 0 },  // 5 WINTERMELON（共体）
        {   0, 0, -10, 0 },  // 6 FIREBALL
        {   0, 0,   0, 0 },  // 7 STAR（原默认）
        { -25, 0, -25, 0 },  // 8 SPIKE
        {   0, 0,   0, 0 },  // 9 BASKETBALL（原默认）
        {   0, 0,   0, 0 },  // 10 KERNEL（原默认）
        {   0, 0,   0, 0 },  // 11 COBBIG（表外特例占位）
        { -15, 0, -15, 0 },  // 12 BUTTER
        { -15, 0, -15, 0 },  // 13 ZOMBIE_PEA（共体）
    };
    static_assert(sizeof(kProjRectRows) / sizeof(kProjRectRows[0]) == (int)ProjectileType::NUM_PROJECTILES,
        "kProjRectRows 槽位须与 ProjectileType 枚举同步");

    if ((unsigned)mProjectileType >= sizeof(kProjRectRows) / sizeof(kProjRectRows[0]))
    {
        return Rect(mX, mY, mWidth, mHeight);  // 原 else 兜底
    }

    const auto& aRow = kProjRectRows[(int)mProjectileType];
    const int aWidth = aRow.mW > 0 ? aRow.mW : mWidth - aRow.mW;
    const int aHeight = aRow.mH > 0 ? aRow.mH : mHeight - aRow.mH;
    return Rect(mX + aRow.mDX, mY + aRow.mDY, aWidth, aHeight);
}

} // namespace FB

// ================================================================= 驱动
static FA::Projectile g_objA[NOBJ], g_pristineA[NOBJ];
static FB::Projectile g_objB[NOBJ], g_pristineB[NOBJ];
static In g_in[NIN];

void A_Init(FA::Projectile* p) { p->ProjectileInitialize(p->mX, p->mY, 1000, p->mRow, p->mProjectileType); }
void B_Init(FB::Projectile* p) { p->ProjectileInitialize(p->mX, p->mY, 1000, p->mRow, p->mProjectileType); }
void A_Lob(FA::Projectile* p) { p->UpdateLobMotion(); }
void B_Lob(FB::Projectile* p) { p->UpdateLobMotion(); }
void A_Norm(FA::Projectile* p) { p->UpdateNormalMotion(); }
void B_Norm(FB::Projectile* p) { p->UpdateNormalMotion(); }
void A_Impact(FA::Projectile* p) { p->DoImpact(g_zHitFlag ? &g_zombiePool[g_zIdx & 15] : nullptr); }
void B_Impact(FB::Projectile* p) { p->DoImpact(g_zHitFlag ? &g_zombiePool[g_zIdx & 15] : nullptr); }
void A_Rect(FA::Projectile* p) { Rect r = p->GetProjectileRect(); MixCk(0x5F00ULL, (uint64_t)(r.mX + r.mY * 3 + r.mWidth * 7 + r.mHeight * 11)); }
void B_Rect(FB::Projectile* p) { Rect r = p->GetProjectileRect(); MixCk(0x5F00ULL, (uint64_t)(r.mX + r.mY * 3 + r.mWidth * 7 + r.mHeight * 11)); }

int main()
{
    InitZombiePool();
    gSexyAppBase = &g_app;

    printf("%-28s | %19s | %19s | %8s | %s\n", "target(Proj)", "A ns r1/r2", "B ns r1/r2", "diff%", "checksum A/B");

    // ---- #12 DoImpact：type 0..13 + theZombie 空/实混合 + motion 混合
    GenInputs(g_in, NIN, 0xA001, 14, 10, 16, 8);
    {
        auto prepA = [](FA::Projectile& p, const In& in) {
            p.mProjectileType = (ProjectileType)in.a; p.mMotionType = (ProjectileMotion)in.b;
            p.mPosX = 300.0f + in.c; p.mPosY = 300.0f + in.d; p.mPosZ = 10.0f;
            p.mVelX = 3.0f; p.mVelY = 0.5f; p.mVelZ = 1.0f; p.mRenderOrder = 500000;
            g_zHitFlag = (in.c & 3) != 0; g_zIdx = in.c >> 2;
        };
        auto prepB = [](FB::Projectile& p, const In& in) {
            p.mProjectileType = (ProjectileType)in.a; p.mMotionType = (ProjectileMotion)in.b;
            p.mPosX = 300.0f + in.c; p.mPosY = 300.0f + in.d; p.mPosZ = 10.0f;
            p.mVelX = 3.0f; p.mVelY = 0.5f; p.mVelZ = 1.0f; p.mRenderOrder = 500000;
            g_zHitFlag = (in.c & 3) != 0; g_zIdx = in.c >> 2;
        };
        RunTarget("12 kProjSplatRows 14", A_Impact, B_Impact,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #13 ProjectileInitialize：type 0..13 均匀（含 FIREBALL 断言槽；RNG 零差构造）
    GenInputs(g_in, NIN, 0xA002, 14, 8, 5, 5);
    {
        auto prepA = [](FA::Projectile& p, const In& in) {
            p.mX = 100 + in.b * 40; p.mY = 100 + in.c * 30; p.mRow = in.d; p.mProjectileType = (ProjectileType)in.a;
        };
        auto prepB = [](FB::Projectile& p, const In& in) {
            p.mX = 100 + in.b * 40; p.mY = 100 + in.c * 30; p.mRow = in.d; p.mProjectileType = (ProjectileType)in.a;
        };
        RunTarget("13 kProjInitRows 14", A_Init, B_Init,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #14 UpdateNormalMotion：motion 0..9 均匀
    GenInputs(g_in, NIN, 0xA003, 10, 8, 16, 80);
    {
        auto prepA = [](FA::Projectile& p, const In& in) {
            p.mMotionType = (ProjectileMotion)in.a; p.mVelX = (float)(in.b) - 4.0f; p.mVelY = (float)(in.c % 7) - 3.0f;
            p.mVelZ = 0.1f; p.mProjectileAge = in.d; p.mPosX = 400; p.mPosY = 300; p.mShadowY = 100;
            p.mWidth = 40; p.mHeight = 40; p.mTargetZombieID = (ZombieID)in.c; p.mDamageRangeFlags = in.c & 1;
            g_app.mGameMode = (in.d & 15) == 3 ? GAMEMODE_CHALLENGE_HIGH_GRAVITY : GAMEMODE_ADVENTURE;
        };
        auto prepB = [](FB::Projectile& p, const In& in) {
            p.mMotionType = (ProjectileMotion)in.a; p.mVelX = (float)(in.b) - 4.0f; p.mVelY = (float)(in.c % 7) - 3.0f;
            p.mVelZ = 0.1f; p.mProjectileAge = in.d; p.mPosX = 400; p.mPosY = 300; p.mShadowY = 100;
            p.mWidth = 40; p.mHeight = 40; p.mTargetZombieID = (ZombieID)in.c; p.mDamageRangeFlags = in.c & 1;
            g_app.mGameMode = (in.d & 15) == 3 ? GAMEMODE_CHALLENGE_HIGH_GRAVITY : GAMEMODE_ADVENTURE;
        };
        RunTarget("14 kProjMotionCases 10", A_Norm, B_Norm,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #15 UpdateLobMotion：type 0..13 + 上升/下降 + 泳道行混合
    GenInputs(g_in, NIN, 0xA004, 14, 16, 5, 16);
    {
        auto prepA = [](FA::Projectile& p, const In& in) {
            p.mProjectileType = (ProjectileType)in.a; p.mVelX = 1.0f; p.mVelY = 0.5f;
            p.mVelZ = (float)(in.b % 13) - 6.0f; p.mAccZ = 0.5f; p.mPosZ = (float)(in.d % 100) - 50.0f;
            p.mProjectileAge = in.b; p.mRow = in.c; p.mPosX = 400; p.mPosY = 300; p.mShadowY = 100;
            p.mCobTargetRow = in.c; p.mCobTargetX = 300.0f; p.mDamageRangeFlags = 3;
            g_app.mGameMode = GAMEMODE_ADVENTURE;
            g_pFindPlant = (in.d & 7) == 1 ? (in.d % 4) + 1 : 0;
            g_pFindZombie = (in.d & 7) != 1 ? (in.d % 16) + 1 : 0;
        };
        auto prepB = [](FB::Projectile& p, const In& in) {
            p.mProjectileType = (ProjectileType)in.a; p.mVelX = 1.0f; p.mVelY = 0.5f;
            p.mVelZ = (float)(in.b % 13) - 6.0f; p.mAccZ = 0.5f; p.mPosZ = (float)(in.d % 100) - 50.0f;
            p.mProjectileAge = in.b; p.mRow = in.c; p.mPosX = 400; p.mPosY = 300; p.mShadowY = 100;
            p.mCobTargetRow = in.c; p.mCobTargetX = 300.0f; p.mDamageRangeFlags = 3;
            g_app.mGameMode = GAMEMODE_ADVENTURE;
            g_pFindPlant = (in.d & 7) == 1 ? (in.d % 4) + 1 : 0;
            g_pFindZombie = (in.d & 7) != 1 ? (in.d % 16) + 1 : 0;
        };
        RunTarget("15 kProjMinCollisionZ 14", A_Lob, B_Lob,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #16 GetProjectileRect：type 0..13 + 尺寸混合（BUTTER 槽 B=-15/+15 vs A 默认——预期 DIFF）
    GenInputs(g_in, NIN, 0xA005, 14, 8, 8, 8);
    {
        auto prepA = [](FA::Projectile& p, const In& in) {
            p.mProjectileType = (ProjectileType)in.a; p.mX = 200 + in.b * 10; p.mY = 200 + in.c * 10;
            p.mWidth = 30 + in.d; p.mHeight = 30 + in.b;
        };
        auto prepB = [](FB::Projectile& p, const In& in) {
            p.mProjectileType = (ProjectileType)in.a; p.mX = 200 + in.b * 10; p.mY = 200 + in.c * 10;
            p.mWidth = 30 + in.d; p.mHeight = 30 + in.b;
        };
        RunTarget("16 kProjRectRows 14", A_Rect, B_Rect,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    return 0;
}
