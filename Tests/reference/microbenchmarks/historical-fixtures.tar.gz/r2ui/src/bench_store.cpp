// bench_store.cpp -- 目标1 kStoreIconDrawRows(31) StoreScreen::DrawItemIcon (商店每帧x商品)
//                 目标2 kStoreComingSoon(31)     StoreScreen::IsComingSoon  (商店绘制)
// FormA = 36a066a7^ 逐字; FormB = HEAD 逐字。表声明与当前源码一致(命名空间级 constexpr)。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

// ---------------- common harness ----------------
static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// ---------------- shared stub layer (identical for both forms) ----------------
enum StoreItem {
    STORE_ITEM_PLANT_GATLINGPEA = 0, STORE_ITEM_PLANT_TWINSUNFLOWER, STORE_ITEM_PLANT_GLOOMSHROOM,
    STORE_ITEM_PLANT_CATTAIL, STORE_ITEM_PLANT_WINTERMELON, STORE_ITEM_PLANT_GOLD_MAGNET,
    STORE_ITEM_PLANT_SPIKEROCK, STORE_ITEM_PLANT_COBCANNON, STORE_ITEM_PLANT_IMITATER,
    STORE_ITEM_BONUS_LAWN_MOWER, STORE_ITEM_POTTED_MARIGOLD_1, STORE_ITEM_POTTED_MARIGOLD_2,
    STORE_ITEM_POTTED_MARIGOLD_3, STORE_ITEM_GOLD_WATERINGCAN, STORE_ITEM_FERTILIZER,
    STORE_ITEM_BUG_SPRAY, STORE_ITEM_PHONOGRAPH, STORE_ITEM_GARDENING_GLOVE,
    STORE_ITEM_MUSHROOM_GARDEN, STORE_ITEM_WHEEL_BARROW, STORE_ITEM_STINKY_THE_SNAIL,
    STORE_ITEM_PACKET_UPGRADE, STORE_ITEM_POOL_CLEANER, STORE_ITEM_ROOF_CLEANER,
    STORE_ITEM_RAKE, STORE_ITEM_AQUARIUM_GARDEN, STORE_ITEM_CHOCOLATE, STORE_ITEM_TREE_OF_WISDOM,
    STORE_ITEM_TREE_FOOD, STORE_ITEM_FIRSTAID, STORE_ITEM_PVZ,
};
static const int PURCHASE_COUNT_OFFSET = 100;

struct Image { int id; int mWidth; int mHeight; };
static Image g_imgStore[32]; // g_imgStore[k].id = k（编号 Image* 桩）
// 表存 Image* const*（资源指针运行期才填充，存址取值——照抄源码形态）
static Image* const IMG_IMITATERSEED = &g_imgStore[8];
static Image* const IMG_WATERINGCANGOLD = &g_imgStore[13];
static Image* const IMG_FERTILIZER = &g_imgStore[14];
static Image* const IMG_BUG_SPRAY = &g_imgStore[15];
static Image* const IMG_PHONOGRAPH = &g_imgStore[16];
static Image* const IMG_ZEN_GARDENGLOVE = &g_imgStore[17];
static Image* const IMG_STORE_MUSHROOMGARDENICON = &g_imgStore[18];
static Image* const IMG_ZEN_WHEELBARROW = &g_imgStore[19];
static Image* const IMG_REANIM_STINKY_TURN3 = &g_imgStore[20];
static Image* const IMG_ICON_POOLCLEANER = &g_imgStore[22];
static Image* const IMG_ICON_ROOFCLEANER = &g_imgStore[23];
static Image* const IMG_ICON_RAKE = &g_imgStore[24];
static Image* const IMG_STORE_AQUARIUMGARDENICON = &g_imgStore[25];
static Image* const IMG_STORE_TREEOFWISDOMICON = &g_imgStore[27];
static Image* const IMG_TREEFOOD = &g_imgStore[28];
static Image* const IMG_STORE_FIRSTAIDWALLNUTICON = &g_imgStore[29];
static Image* const IMG_STORE_PVZICON = &g_imgStore[30];
static Image* const IMG_STORE_PACKETUPGRADE = &g_imgStore[21];

struct Graphics { int mDrawMode; void SetDrawMode(int m) { mDrawMode = m; } void SetColorizeImages(bool b) { (void)b; } };
struct SexyString { const char* p = nullptr; };
struct Rect { int mX, mY, mW, mH; Rect(int x, int y, int w, int h) : mX(x), mY(y), mW(w), mH(h) {} };

// 编号空桩：Draw 类记录 (桩号, 图 id, x, y)
static void S_DrawImage(int n, const Image* img, int x, int y) { CS(n); CS(img ? (uint64_t)img->id : 9999); CS((uint64_t)(int64_t)x); CS((uint64_t)(int64_t)y); }
static void S_DrawImageScaled(int n, const Image* img, int x, int y, int w, int h) { CS(n); CS(img ? (uint64_t)img->id : 9999); CS((uint64_t)(int64_t)x); CS((uint64_t)(int64_t)y); CS((uint64_t)w); CS((uint64_t)h); }
static void S_TodDrawString(int n, const char* s, int x, int y, int font, int align) { CS(n); CS(x); CS(y); CS(font); CS(align); CS(s ? (uint64_t)s[0] : 0); }
static SexyString S_TodReplaceNumberString(int n) { CS(n); return SexyString{}; }
static void S_TodDrawStringWrapped(int n) { CS(n); }
static void S_DrawSeedPacket(int n, int x, int y, int seed) { CS(n); CS(x); CS(y); CS(seed); }
static void S_DrawPottedPlantIcon(int n) { CS(n); }

// 运行期状态（输入驱动，两形态同值）
struct AppStub {
    bool mHasFinishedAdventure;
    bool mIsTrialStageLocked;
    int mPurchases[32];
};
struct StoreScreenStub {
    AppStub* mApp;
};

static bool IsFullVersionOnly(StoreScreenStub& s, StoreItem theStoreItem)
{
    if (!s.mApp->mIsTrialStageLocked)
        return false;
    if (theStoreItem == STORE_ITEM_PACKET_UPGRADE && s.mApp->mPurchases[STORE_ITEM_PACKET_UPGRADE] >= 2)
        return true;
    return theStoreItem == STORE_ITEM_PLANT_TWINSUNFLOWER;
}
static bool IsPottedPlant(StoreItem theStoreItem)
{
    return theStoreItem == STORE_ITEM_POTTED_MARIGOLD_1 || theStoreItem == STORE_ITEM_POTTED_MARIGOLD_2 || theStoreItem == STORE_ITEM_POTTED_MARIGOLD_3;
}
static void GetStorePosition(int theSpotIndex, int& thePosX, int& thePosY)
{
    if (theSpotIndex <= 3) { thePosX = 100 + 120 * theSpotIndex; thePosY = 50; }
    else { thePosX = 100 + 120 * (theSpotIndex - 4); thePosY = 250; }
}

// ================= FormA (36a066a7^) =================
namespace FormA {
static bool IsComingSoon(StoreScreenStub& s, StoreItem theStoreItem)
{
    if (IsFullVersionOnly(s, theStoreItem))
        return true;
    else if (theStoreItem == STORE_ITEM_WHEEL_BARROW)
        return !s.mApp->mPurchases[STORE_ITEM_MUSHROOM_GARDEN] && !s.mApp->mPurchases[STORE_ITEM_AQUARIUM_GARDEN];
    else if (IsPottedPlant(theStoreItem))
        return !s.mApp->mHasFinishedAdventure;
    else if (theStoreItem == STORE_ITEM_TREE_FOOD)
        return !s.mApp->mPurchases[STORE_ITEM_TREE_OF_WISDOM] || s.mApp->mPurchases[STORE_ITEM_TREE_FOOD] < PURCHASE_COUNT_OFFSET;
    return false;
}

static void DrawItemIcon(Graphics* g, StoreScreenStub& s, int theItemPosition, StoreItem theItemType, bool theIsForHighlight)
{
    if (theIsForHighlight)
    {
        g->SetDrawMode(1);
        g->SetColorizeImages(true);
    }
    int aPosX, aPosY;
    GetStorePosition(theItemPosition, aPosX, aPosY);
    if (theItemType == STORE_ITEM_PACKET_UPGRADE)
    {
        g->SetDrawMode(0);
        S_DrawImage(101, IMG_STORE_PACKETUPGRADE, aPosX - 7, aPosY + 7);
        if (theIsForHighlight) { g->SetDrawMode(0); g->SetColorizeImages(false); }
        SexyString aSlotText = S_TodReplaceNumberString(102);
        Rect aRect(aPosX, aPosY + 6, 55, 70);
        S_TodDrawStringWrapped(103);
    }
    else if (theItemType == STORE_ITEM_POOL_CLEANER)
        S_DrawImage(104, IMG_ICON_POOLCLEANER, aPosX + 1, aPosY + 7);
    else if (theItemType == STORE_ITEM_RAKE)
        S_DrawImage(104, IMG_ICON_RAKE, aPosX - 5, aPosY + 10);
    else if (theItemType == STORE_ITEM_ROOF_CLEANER)
        S_DrawImage(104, IMG_ICON_ROOFCLEANER, aPosX, aPosY + 28);
    else if (theItemType == STORE_ITEM_PLANT_IMITATER)
        S_DrawImage(104, IMG_IMITATERSEED, aPosX, aPosY);
    else if (theItemType == STORE_ITEM_MUSHROOM_GARDEN)
        S_DrawImage(104, IMG_STORE_MUSHROOMGARDENICON, aPosX - 8, aPosY + 2);
    else if (theItemType == STORE_ITEM_AQUARIUM_GARDEN)
        S_DrawImage(104, IMG_STORE_AQUARIUMGARDENICON, aPosX - 8, aPosY + 2);
    else if (theItemType == STORE_ITEM_TREE_OF_WISDOM)
        S_DrawImage(104, IMG_STORE_TREEOFWISDOMICON, aPosX - 8, aPosY + 2);
    else if (theItemType == STORE_ITEM_FIRSTAID)
        S_DrawImage(104, IMG_STORE_FIRSTAIDWALLNUTICON, aPosX - 1, aPosY + 13);
    else if (theItemType == STORE_ITEM_PVZ)
        S_DrawImage(104, IMG_STORE_PVZICON, aPosX, aPosY - 9);
    else if (theItemType == STORE_ITEM_TREE_FOOD)
        S_DrawImage(104, IMG_TREEFOOD, aPosX - 8, aPosY - 2);
    else if (theItemType == STORE_ITEM_STINKY_THE_SNAIL)
        S_DrawImage(104, IMG_REANIM_STINKY_TURN3, aPosX - 24, aPosY + 14);
    else if (theItemType == STORE_ITEM_GOLD_WATERINGCAN)
        S_DrawImage(104, IMG_WATERINGCANGOLD, aPosX - 14, aPosY - 4);
    else if (theItemType == STORE_ITEM_FERTILIZER)
    {
        S_DrawImage(104, IMG_FERTILIZER, aPosX - 11, aPosY - 2);
        S_TodDrawString(105, "x5", aPosX + 56, aPosY + 62, 16, 2);
    }
    else if (theItemType == STORE_ITEM_PHONOGRAPH)
        S_DrawImage(104, IMG_PHONOGRAPH, aPosX - 12, aPosY + 3);
    else if (theItemType == STORE_ITEM_BUG_SPRAY)
    {
        S_DrawImage(104, IMG_BUG_SPRAY, aPosX - 12, aPosY + 3);
        S_TodDrawString(105, "x5", aPosX + 56, aPosY + 62, 16, 2);
    }
    else if (theItemType == STORE_ITEM_GARDENING_GLOVE)
        S_DrawImage(104, IMG_ZEN_GARDENGLOVE, aPosX - 12, aPosY + 3);
    else if (theItemType == STORE_ITEM_WHEEL_BARROW)
        S_DrawImage(104, IMG_ZEN_WHEELBARROW, aPosX - 12, aPosY + 3);
    else if (IsPottedPlant(theItemType))
        S_DrawPottedPlantIcon(106);
    else
        S_DrawSeedPacket(107, aPosX, aPosY, (int)theItemType + 40);

    g->SetDrawMode(0);
    g->SetColorizeImages(false);
}
} // namespace FormA

// ================= FormB (HEAD) =================
namespace FormB {
// 命名空间级表（照抄当前源码声明形式：匿名命名空间 constexpr）
namespace {
using StoreComingSoonFn = bool (*)(StoreScreenStub&);
static bool StoreComingSoonPotted(StoreScreenStub& s)
{
    return !s.mApp->mHasFinishedAdventure;
}
constexpr StoreComingSoonFn kStoreComingSoon[(int)STORE_ITEM_PVZ + 1] = {
    nullptr,                                                                                        // 0 GATLINGPEA
    [](StoreScreenStub& s) { return IsFullVersionOnly(s, STORE_ITEM_PLANT_TWINSUNFLOWER); },         // 1 TWINSUNFLOWER
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,                                  // 2..8
    nullptr,                                                                                        // 9 BONUS_LAWN_MOWER
    &StoreComingSoonPotted, &StoreComingSoonPotted, &StoreComingSoonPotted,                         // 10..12 POTTED
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,                                           // 13..18
    [](StoreScreenStub& s) { return !s.mApp->mPurchases[STORE_ITEM_MUSHROOM_GARDEN] && !s.mApp->mPurchases[STORE_ITEM_AQUARIUM_GARDEN]; },  // 19 WHEEL_BARROW
    nullptr,                                                                                        // 20 STINKY
    [](StoreScreenStub& s) { return IsFullVersionOnly(s, STORE_ITEM_PACKET_UPGRADE); },              // 21 PACKET_UPGRADE
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,                                           // 22..27
    [](StoreScreenStub& s) { return !s.mApp->mPurchases[STORE_ITEM_TREE_OF_WISDOM] || s.mApp->mPurchases[STORE_ITEM_TREE_FOOD] < PURCHASE_COUNT_OFFSET; },  // 28 TREE_FOOD
    nullptr, nullptr,                                                                               // 29..30
};
constexpr struct
{
    Image* const* mImage;
    int mDx;
    int mDy;
    bool mDrawX5;
} kStoreIconDrawRows[(int)STORE_ITEM_PVZ + 1] = {
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { &IMG_IMITATERSEED, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { nullptr, 0, 0, false },
    { &IMG_WATERINGCANGOLD, -14, -4, false },
    { &IMG_FERTILIZER, -11, -2, true },
    { &IMG_BUG_SPRAY, -12, 3, true },
    { &IMG_PHONOGRAPH, -12, 3, false },
    { &IMG_ZEN_GARDENGLOVE, -12, 3, false },
    { &IMG_STORE_MUSHROOMGARDENICON, -8, 2, false },
    { &IMG_ZEN_WHEELBARROW, -12, 3, false },
    { &IMG_REANIM_STINKY_TURN3, -24, 14, false },
    { nullptr, 0, 0, false },
    { &IMG_ICON_POOLCLEANER, 1, 7, false },
    { &IMG_ICON_ROOFCLEANER, 0, 28, false },
    { &IMG_ICON_RAKE, -5, 10, false },
    { &IMG_STORE_AQUARIUMGARDENICON, -8, 2, false },
    { nullptr, 0, 0, false },
    { &IMG_STORE_TREEOFWISDOMICON, -8, 2, false },
    { &IMG_TREEFOOD, -8, -2, false },
    { &IMG_STORE_FIRSTAIDWALLNUTICON, -1, 13, false },
    { &IMG_STORE_PVZICON, 0, -9, false },
};
} // namespace

static bool IsComingSoon(StoreScreenStub& s, StoreItem theStoreItem)
{
    if ((unsigned)theStoreItem < sizeof(kStoreComingSoon) / sizeof(kStoreComingSoon[0]) &&
        kStoreComingSoon[theStoreItem] != nullptr)
    {
        return kStoreComingSoon[theStoreItem](s);
    }
    return false;
}

static void DrawItemIcon(Graphics* g, StoreScreenStub& s, int theItemPosition, StoreItem theItemType, bool theIsForHighlight)
{
    if (theIsForHighlight)
    {
        g->SetDrawMode(1);
        g->SetColorizeImages(true);
    }
    int aPosX, aPosY;
    GetStorePosition(theItemPosition, aPosX, aPosY);
    if (theItemType == STORE_ITEM_PACKET_UPGRADE)
    {
        g->SetDrawMode(0);
        S_DrawImage(101, IMG_STORE_PACKETUPGRADE, aPosX - 7, aPosY + 7);
        if (theIsForHighlight) { g->SetDrawMode(0); g->SetColorizeImages(false); }
        SexyString aSlotText = S_TodReplaceNumberString(102);
        Rect aRect(aPosX, aPosY + 6, 55, 70);
        S_TodDrawStringWrapped(103);
    }
    else if (IsPottedPlant(theItemType))
    {
        S_DrawPottedPlantIcon(106);
    }
    else
    {
        const unsigned anIconIndex = (unsigned)theItemType;
        if (anIconIndex < sizeof(kStoreIconDrawRows) / sizeof(kStoreIconDrawRows[0]) &&
            kStoreIconDrawRows[anIconIndex].mImage != nullptr)
        {
            const auto& anIconRow = kStoreIconDrawRows[anIconIndex];
            S_DrawImage(104, *anIconRow.mImage, aPosX + anIconRow.mDx, aPosY + anIconRow.mDy);
            if (anIconRow.mDrawX5)
            {
                S_TodDrawString(105, "x5", aPosX + 56, aPosY + 62, 16, 2);
            }
        }
        else
        {
            S_DrawSeedPacket(107, aPosX, aPosY, (int)theItemType + 40);
        }
    }

    g->SetDrawMode(0);
    g->SetColorizeImages(false);
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static int g_type[2000000];
static unsigned char g_pos[2000000];
static unsigned char g_hl[2000000];
static unsigned char g_adv[2000000]; // finished adventure
static unsigned char g_lock[2000000];
static int g_pur[2000000];

static uint64_t RunIsComingSoon(bool formB)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    StoreScreenStub s; AppStub app; s.mApp = &app;
    uint64_t acc = 0;
    for (int i = 0; i < N; i++)
    {
        app.mHasFinishedAdventure = g_adv[i] & 1;
        app.mIsTrialStageLocked = g_lock[i] & 1;
        for (int k = 0; k < 32; k++) app.mPurchases[k] = (g_pur[i] >> k) & 1 ? 105 : 0;
        bool r = formB ? FormB::IsComingSoon(s, (StoreItem)g_type[i]) : FormA::IsComingSoon(s, (StoreItem)g_type[i]);
        acc += r;
    }
    CS(acc);
    return g_cs;
}

static uint64_t RunDrawItemIcon(bool formB)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    StoreScreenStub s; AppStub app; s.mApp = &app;
    Graphics g;
    for (int i = 0; i < N; i++)
    {
        app.mHasFinishedAdventure = g_adv[i] & 1;
        app.mIsTrialStageLocked = g_lock[i] & 1;
        app.mPurchases[STORE_ITEM_PACKET_UPGRADE] = g_pur[i] & 3;
        if (formB) FormB::DrawItemIcon(&g, s, g_pos[i], (StoreItem)g_type[i], (g_hl[i] & 1) != 0);
        else FormA::DrawItemIcon(&g, s, g_pos[i], (StoreItem)g_type[i], (g_hl[i] & 1) != 0);
    }
    return g_cs;
}

struct Res { double nsA1, nsA2, nsB1, nsB2; uint64_t csA, csB; };

static void Report(const char* name, Res& r)
{
    double b1 = r.nsB1, b2 = r.nsB2, a1 = r.nsA1, a2 = r.nsA2;
    double diff1 = (a1 - b1) / a1 * 100.0, diff2 = (a2 - b2) / a2 * 100.0;
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, diff1, diff2, (unsigned long long)r.csA, (unsigned long long)r.csB,
        r.csA == r.csB ? "OK" : "MISMATCH");
}

int main()
{
    for (int k = 0; k < 32; k++) { g_imgStore[k].id = k; g_imgStore[k].mWidth = 60; g_imgStore[k].mHeight = 60; }
    LCG rng{ 0xB5AD4ECEDA1CE2A9ULL };
    for (int i = 0; i < N; i++)
    {
        uint64_t v = rng.nx();
        g_type[i] = (int)(v % 34) - 1;         // -1..32: 含越界键
        g_pos[i] = (unsigned char)(v % 8);
        g_hl[i] = (unsigned char)(v >> 8);
        g_adv[i] = (unsigned char)(v >> 16);
        g_lock[i] = (unsigned char)(v >> 24);
        g_pur[i] = (int)(v >> 32);
    }

    // --- target 2: IsComingSoon ---
    {
        Res r{};
        r.csA = RunIsComingSoon(false); r.csB = RunIsComingSoon(true);
        for (int round = 0; round < 2; round++)
        {
            double ta = TimeMin5([] { RunIsComingSoon(false); });
            double tb = TimeMin5([] { RunIsComingSoon(true); });
            double nsA = ta / N * 1e9, nsB = tb / N * 1e9;
            if (round == 0) { r.nsA1 = nsA; r.nsB1 = nsB; } else { r.nsA2 = nsA; r.nsB2 = nsB; }
        }
        Report("t2 kStoreComingSoon(31) IsComingSoon", r);
    }
    // --- target 1: DrawItemIcon ---
    {
        Res r{};
        r.csA = RunDrawItemIcon(false); r.csB = RunDrawItemIcon(true);
        for (int round = 0; round < 2; round++)
        {
            double ta = TimeMin5([] { RunDrawItemIcon(false); });
            double tb = TimeMin5([] { RunDrawItemIcon(true); });
            double nsA = ta / N * 1e9, nsB = tb / N * 1e9;
            if (round == 0) { r.nsA1 = nsA; r.nsB1 = nsB; } else { r.nsA2 = nsA; r.nsB2 = nsB; }
        }
        Report("t1 kStoreIconDrawRows(31) DrawItemIcon", r);
    }
    return 0;
}
