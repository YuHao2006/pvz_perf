
void __thiscall FUN_00549370(int *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined1 local_b0 [8];
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 local_9c;
  int *local_98;
  undefined4 local_94;
  undefined4 *local_90;
  int *local_8c;
  int local_88;
  undefined1 local_84 [4];
  int local_80;
  undefined1 local_7c [40];
  undefined4 local_54;
  undefined4 local_50;
  undefined1 local_4c [8];
  undefined1 local_44 [8];
  undefined4 local_3c;
  undefined4 local_38;
  int *local_2c;
  int local_28;
  int local_24;
  int local_20;
  int local_1c;
  int *local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  (**(code **)(*param_1 + 0x4c))();
  *(undefined1 *)(param_2 + 0x3c) = 1;
  if (param_1[9] == 0) {
    local_8c = param_1 + 1;
    local_88 = param_1[6];
    FUN_00559350(local_88,local_8c);
    local_98 = param_1 + 1;
    local_90 = (undefined4 *)param_1[6];
    local_94 = *local_90;
    FUN_00559350(local_94,local_98);
    FUN_006215c0(&local_a0);
    FUN_006215c0(&local_a8);
    puVar4 = (undefined4 *)FUN_0055aba0(local_b0,local_a8,local_a4,local_a0,local_9c,&param_2);
    FUN_0055b150(*puVar4,puVar4[1]);
    local_c = local_3c;
    local_8 = local_38;
    FUN_00559350(param_1[6],param_1 + 1);
    cVar3 = FUN_006143c0(local_44);
    if (cVar3 == '\0') {
      local_14 = local_c;
      local_10 = local_8;
      FUN_00559350(*(undefined4 *)param_1[6],param_1 + 1);
      cVar3 = FUN_006143c0(local_4c);
      uVar2 = local_10;
      uVar5 = local_14;
      if (cVar3 == '\0') {
        FUN_005e5fb0();
        local_54 = uVar5;
        local_50 = uVar2;
        do {
          local_18 = (int *)FUN_005e2150();
          local_18 = (int *)*local_18;
          if ((char)local_18[0x19] != '\0') {
            if ((*(char *)((int)local_18 + 0x6a) == '\0') && ((char)local_18[0x14] == '\0')) {
              FUN_00401a90(param_1[0x12],param_1[0x13]);
              FUN_00401a90(*(undefined4 *)(param_2 + 0x48),*(undefined4 *)(param_2 + 0x4c));
              FUN_0045a330();
              cVar3 = (**(code **)(*local_18 + 0x110))(local_28,local_24);
              if ((cVar3 != '\0') &&
                 (cVar3 = (**(code **)(*local_18 + 0x110))
                                    (local_28 + -1 + local_20,local_24 + -1 + local_1c),
                 cVar3 != '\0')) {
                (**(code **)(*local_18 + 0x44))();
                break;
              }
            }
            cVar3 = (**(code **)(*local_18 + 8))(param_2);
            if (cVar3 != '\0') {
              (**(code **)(*param_1 + 0x40))(local_18);
            }
          }
          uVar5 = FUN_005b75d0(local_7c);
          cVar3 = FUN_006143c0(uVar5);
          if (cVar3 != '\0') break;
          FUN_005e5fb0();
        } while( true );
      }
      local_14 = local_c;
      local_10 = local_8;
      while( true ) {
        iVar1 = param_1[6];
        FUN_00420ae0();
        local_80 = iVar1;
        if (param_1 == (int *)0xfffffffc) {
          FUN_0069a6f2();
        }
        FUN_0040a150();
        cVar3 = FUN_006143c0(local_84);
        if (cVar3 != '\0') break;
        local_2c = (int *)FUN_005e2150();
        local_2c = (int *)*local_2c;
        if (((char)local_2c[0x19] != '\0') &&
           (cVar3 = (**(code **)(*local_2c + 8))(param_2), cVar3 != '\0')) {
          (**(code **)(*param_1 + 0x40))(local_2c);
        }
        FUN_00614350();
      }
    }
  }
  return;
}

