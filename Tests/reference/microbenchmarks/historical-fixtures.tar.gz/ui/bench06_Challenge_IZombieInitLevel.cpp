// bench06 | Challenge::IZombieInitLevel | 10 case switch -> squares+rows data tables
// FormA = ac447d19^ (verbatim switch), FormB = HEAD. mGameMode uniform over {63..72} (I,ZOMBIE 1..9 + ENDLESS).
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

static const int kN = 2000000;
static uint32_t g_raw[kN];
static uint32_t g_rngState = 1;
static inline uint32_t RngNext() { g_rngState ^= g_rngState << 13; g_rngState ^= g_rngState >> 17; g_rngState ^= g_rngState << 5; return g_rngState; }

enum GameMode {
    GAMEMODE_PUZZLE_I_ZOMBIE_1 = 63, GAMEMODE_PUZZLE_I_ZOMBIE_2, GAMEMODE_PUZZLE_I_ZOMBIE_3, GAMEMODE_PUZZLE_I_ZOMBIE_4,
    GAMEMODE_PUZZLE_I_ZOMBIE_5, GAMEMODE_PUZZLE_I_ZOMBIE_6, GAMEMODE_PUZZLE_I_ZOMBIE_7, GAMEMODE_PUZZLE_I_ZOMBIE_8,
    GAMEMODE_PUZZLE_I_ZOMBIE_9, GAMEMODE_PUZZLE_I_ZOMBIE_ENDLESS
};
enum SeedTypeZ {
    SEED_NONE = 0, SEED_PEASHOOTER = 1, SEED_SUNFLOWER = 2, SEED_SQUASH = 3, SEED_WALLNUT = 4, SEED_POTATOMINE = 5,
    SEED_SNOWPEA = 6, SEED_CHOMPER = 7, SEED_REPEATER = 8, SEED_PUFFSHROOM = 9, SEED_FUMESHROOM = 10,
    SEED_SCAREDYSHROOM = 11, SEED_HYPNOSHROOM = 12, SEED_TALLNUT = 13, SEED_SPIKEWEED = 14, SEED_TORCHWOOD = 15,
    SEED_THREEPEATER = 16, SEED_SPLITPEA = 17, SEED_MAGNETSHROOM = 18, SEED_CACTUS = 19, SEED_GARLIC = 20,
    SEED_KERNELPULT = 21, SEED_STARFRUIT = 22, SEED_UMBRELLA = 23
};
enum GridItemTypeZ { GRIDITEM_IZOMBIE_BRAIN = 1 };
enum RenderLayer { RENDER_LAYER_PLANT = 1 };
const int I_ZOMBIE_WINNING_SCORE = 5;

static inline void TOD_ASSERT_IMPL(bool) {}
#define TOD_ASSERT(x) TOD_ASSERT_IMPL((x))  // release no-op (game asserts compiled out)
static inline int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int RandRangeInt(int lo, int hi) { Mix(40); return lo + (int)(RngNext() % (uint32_t)(hi - lo + 1)); }

struct GridItemStub {
    int mGridItemType; int mGridX; int mGridY; int mRenderOrder; int mGridItemCounter; float mPosX; float mPosY;
};
static GridItemStub g_brain;
struct ListStub { GridItemStub* DataArrayAlloc() { Mix(41); return &g_brain; } };
struct BoardStub {
    ListStub mGridItems;
    int mBonusLawnMowersRemaining;
    static int MakeRenderOrder(RenderLayer l, int row, int z) { Mix(42); return ((int)l << 12) + row * 64 + z; }
    int GridToPixelX(int x, int y) { Mix(43); return x * 80 + y; }
    int GridToPixelY(int x, int y) { Mix(44); return y * 100 + x; }
};
static BoardStub g_board;
struct AppStub { GameMode mGameMode; void GiveAch(int id) { Mix(45); Mix((uint64_t)id); } };
static AppStub g_app;

struct ChallengeStub {
    AppStub* mApp;
    BoardStub* mBoard;
    int mSurvivalStage;
    int mChallengeScore;

    void IZombiePlacePlantInSquare(SeedTypeZ s, int x, int y) { Mix(46); Mix((uint64_t)s * 271 + (uint64_t)x * 17 + (uint64_t)y); }
    void IZombiePlacePlants(SeedTypeZ s, int count, int y) { Mix(47); Mix((uint64_t)s * 271 + (uint64_t)count * 17 + (uint64_t)(y + 2)); }
};
static ChallengeStub g_challenge;

// ================= FormA: verbatim switch (ac447d19^) =================
static void IZombieInitLevelA()
{
    g_challenge.mChallengeScore = 0;
    for (int aRow = 0; aRow < I_ZOMBIE_WINNING_SCORE; aRow++)
    {
        GridItemStub* aBrain = g_challenge.mBoard->mGridItems.DataArrayAlloc();
        aBrain->mGridItemType = GRIDITEM_IZOMBIE_BRAIN;
        aBrain->mGridX = 0;
        aBrain->mGridY = aRow;
        aBrain->mRenderOrder = BoardStub::MakeRenderOrder(RENDER_LAYER_PLANT, aRow, 0);
        aBrain->mGridItemCounter = 70;
        aBrain->mPosX = g_challenge.mBoard->GridToPixelX(0, aRow) - 40;
        aBrain->mPosY = g_challenge.mBoard->GridToPixelY(0, aRow) + 40;
    }

    switch (g_challenge.mApp->mGameMode)
    {
    case GAMEMODE_PUZZLE_I_ZOMBIE_1:
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 3, 2);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 3, 3);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 7, -1);
        g_challenge.IZombiePlacePlants(SEED_SQUASH, 3, -1);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 6, -1);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 2, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_2:
        g_challenge.IZombiePlacePlantInSquare(SEED_SPIKEWEED, 3, 0);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 2, 0);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 3, 3);
        g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 1, 0);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 1, 0);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 2, 3);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 1, 3);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 4, -1);
        g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 4, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_3:
        g_challenge.IZombiePlacePlantInSquare(SEED_POTATOMINE, 3, 0);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 2, 0);
        g_challenge.IZombiePlacePlantInSquare(SEED_POTATOMINE, 2, 2);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 2, 4);
        g_challenge.IZombiePlacePlantInSquare(SEED_TORCHWOOD, 3, 3);
        g_challenge.IZombiePlacePlants(SEED_TORCHWOOD, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 5, -1);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 7, -1);
        g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 1, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_4:
        g_challenge.IZombiePlacePlantInSquare(SEED_WALLNUT, 3, 0);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 2, 0);
        g_challenge.IZombiePlacePlantInSquare(SEED_WALLNUT, 3, 1);
        g_challenge.IZombiePlacePlantInSquare(SEED_WALLNUT, 3, 2);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 2, 2);
        g_challenge.IZombiePlacePlantInSquare(SEED_WALLNUT, 3, 3);
        g_challenge.IZombiePlacePlantInSquare(SEED_WALLNUT, 3, 4);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 2, 4);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 1, 0);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 1, 1);
        g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 2, 2);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 1, 3);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 4, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_5:
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 3, 2);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 3, 3);
        g_challenge.IZombiePlacePlants(SEED_CACTUS, 1, 1);
        g_challenge.IZombiePlacePlants(SEED_CACTUS, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 1, -1);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 5, -1);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 8, -1);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 2, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_6:
        g_challenge.IZombiePlacePlantInSquare(SEED_GARLIC, 4, 1);
        g_challenge.IZombiePlacePlantInSquare(SEED_GARLIC, 4, 3);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 3, 1);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 3, 3);
        g_challenge.IZombiePlacePlants(SEED_TORCHWOOD, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 3, -1);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 1, -1);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 5, -1);
        g_challenge.IZombiePlacePlants(SEED_SQUASH, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_KERNELPULT, 2, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_7:
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 4, 2);
        g_challenge.IZombiePlacePlantInSquare(SEED_SUNFLOWER, 4, 4);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 6, -1);
        g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 9, -1);
        g_challenge.IZombiePlacePlants(SEED_CHOMPER, 8, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_8:
        g_challenge.IZombiePlacePlants(SEED_WALLNUT, 3, -1);
        g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 8, -1);
        g_challenge.IZombiePlacePlants(SEED_SQUASH, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 2, -1);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 8, -1);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_9:
        g_challenge.IZombiePlacePlantInSquare(SEED_TALLNUT, 5, 1);
        g_challenge.IZombiePlacePlantInSquare(SEED_TORCHWOOD, 5, 3);
        g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 4, 0);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 2, 0);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 2, 1);
        g_challenge.IZombiePlacePlants(SEED_THREEPEATER, 1, 1);
        g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 1, 1);
        g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 1, 1);
        g_challenge.IZombiePlacePlants(SEED_CHOMPER, 3, 2);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 2, 2);
        g_challenge.IZombiePlacePlants(SEED_SQUASH, 1, 2);
        g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 3, 3);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 2, 3);
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_SCAREDYSHROOM, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_STARFRUIT, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 1, 4);
        g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 1, 4);
        break;
    case GAMEMODE_PUZZLE_I_ZOMBIE_ENDLESS:
    {
        if (g_challenge.mSurvivalStage == 10)
            g_challenge.mApp->GiveAch(1);

        int aFormationHit = RandRangeInt(0, 4);

        int aPuffshroomCount = RandRangeInt(ClampInt(2 + g_challenge.mSurvivalStage / 3, 2, 4), ClampInt(3 + g_challenge.mSurvivalStage / 2, 2, 6));
        if (g_challenge.mSurvivalStage == 0)
        {
            aPuffshroomCount = 0;
        }
        else if (g_challenge.mSurvivalStage == 1)
        {
            aPuffshroomCount = 1;
        }
        else if (g_challenge.mSurvivalStage >= 10)
        {
            aPuffshroomCount = RandRangeInt(ClampInt(2 + g_challenge.mSurvivalStage / 3, 2, 5), ClampInt(3 + g_challenge.mSurvivalStage / 2, 2, 7));
        }
        int aSunflowerCount = 8 - aPuffshroomCount;
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, aSunflowerCount, -1);
        g_challenge.IZombiePlacePlants(SEED_PUFFSHROOM, aPuffshroomCount, -1);

        if (aFormationHit == 0 && g_challenge.mSurvivalStage >= 1)
        {
            switch (RandRangeInt(0, 4))
            {
            case 0:
                g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 4, -1);
                g_challenge.IZombiePlacePlants(SEED_REPEATER, 4, -1);
                break;
            case 1:
                g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_CHOMPER, 8, -1);
                break;
            case 2:
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_STARFRUIT, 8, -1);
                break;
            case 3:
                g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 8, -1);
                break;
            default:
                g_challenge.IZombiePlacePlants(SEED_SCAREDYSHROOM, 12, -1);
                g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 5, -1);
            }
        }
        else
        {
            switch (RandRangeInt(0, 5))
            {
            case 0:
            case 1:
            case 2:
                g_challenge.IZombiePlacePlants(SEED_WALLNUT, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_TORCHWOOD, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_CHOMPER, 2, -1);
                g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_KERNELPULT, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_THREEPEATER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SQUASH, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_UMBRELLA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_STARFRUIT, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 2, -1);
                break;
            case 3:
            case 4:
                g_challenge.IZombiePlacePlants(SEED_TORCHWOOD, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_REPEATER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_KERNELPULT, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_THREEPEATER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_UMBRELLA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 3, -1);
                break;
            default:
                g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 4, -1);
                g_challenge.IZombiePlacePlants(SEED_CHOMPER, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_SQUASH, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 4, -1);
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 3, -1);
                break;
            }
        }
        break;
    }
    default:
        TOD_ASSERT(false);
        break;
    }

    g_challenge.mBoard->mBonusLawnMowersRemaining = 0;
}

// ================= FormB: HEAD tables =================
namespace {
struct IZombieSquare { SeedTypeZ mSeedType; int mGridX; int mGridY; };
struct IZombieRow { SeedTypeZ mSeedType; int mCount; int mGridY; };
constexpr IZombieSquare kIZombieSquares[] = {
    {SEED_SUNFLOWER, 3, 2}, {SEED_SUNFLOWER, 3, 3},
    {SEED_SPIKEWEED, 3, 0}, {SEED_SUNFLOWER, 2, 0}, {SEED_SUNFLOWER, 3, 3},
    {SEED_POTATOMINE, 3, 0}, {SEED_SUNFLOWER, 2, 0}, {SEED_POTATOMINE, 2, 2}, {SEED_SUNFLOWER, 2, 4}, {SEED_TORCHWOOD, 3, 3},
    {SEED_WALLNUT, 3, 0}, {SEED_SUNFLOWER, 2, 0}, {SEED_WALLNUT, 3, 1}, {SEED_WALLNUT, 3, 2}, {SEED_SUNFLOWER, 2, 2}, {SEED_WALLNUT, 3, 3}, {SEED_WALLNUT, 3, 4}, {SEED_SUNFLOWER, 2, 4},
    {SEED_SUNFLOWER, 3, 2}, {SEED_SUNFLOWER, 3, 3},
    {SEED_GARLIC, 4, 1}, {SEED_GARLIC, 4, 3},
    {SEED_SUNFLOWER, 4, 2}, {SEED_SUNFLOWER, 4, 4},
    {SEED_TALLNUT, 5, 1}, {SEED_TORCHWOOD, 5, 3},
};
constexpr int kIZombieSquareBegin[10] = {0, 2, 5, 10, 18, 20, 22, 24, 24, 26};
constexpr IZombieRow kIZombieRows[] = {
    {SEED_SUNFLOWER, 7, -1}, {SEED_SQUASH, 3, -1}, {SEED_PEASHOOTER, 6, -1}, {SEED_SNOWPEA, 2, -1},
    {SEED_SPIKEWEED, 1, 0}, {SEED_PEASHOOTER, 1, 0}, {SEED_SNOWPEA, 2, 3}, {SEED_SUNFLOWER, 1, 3}, {SEED_SUNFLOWER, 4, -1}, {SEED_SPIKEWEED, 2, -1}, {SEED_SNOWPEA, 2, -1}, {SEED_PEASHOOTER, 4, -1},
    {SEED_TORCHWOOD, 2, -1}, {SEED_SUNFLOWER, 5, -1}, {SEED_PEASHOOTER, 7, -1}, {SEED_SPLITPEA, 1, -1},
    {SEED_PEASHOOTER, 1, 0}, {SEED_SNOWPEA, 1, 1}, {SEED_FUMESHROOM, 2, 2}, {SEED_SNOWPEA, 1, 3}, {SEED_PEASHOOTER, 1, 4}, {SEED_PEASHOOTER, 2, -1}, {SEED_SUNFLOWER, 4, -1},
    {SEED_CACTUS, 1, 1}, {SEED_CACTUS, 1, 4}, {SEED_MAGNETSHROOM, 1, -1}, {SEED_SUNFLOWER, 5, -1}, {SEED_PEASHOOTER, 8, -1}, {SEED_SNOWPEA, 2, -1},
    {SEED_SUNFLOWER, 3, 1}, {SEED_SUNFLOWER, 3, 3}, {SEED_TORCHWOOD, 2, -1}, {SEED_SUNFLOWER, 2, -1}, {SEED_SPIKEWEED, 3, -1}, {SEED_SNOWPEA, 1, -1}, {SEED_PEASHOOTER, 5, -1}, {SEED_SQUASH, 2, -1}, {SEED_KERNELPULT, 2, -1},
    {SEED_SUNFLOWER, 6, -1}, {SEED_POTATOMINE, 9, -1}, {SEED_CHOMPER, 8, -1},
    {SEED_WALLNUT, 3, -1}, {SEED_MAGNETSHROOM, 2, -1}, {SEED_PEASHOOTER, 8, -1}, {SEED_SQUASH, 2, -1}, {SEED_POTATOMINE, 2, -1}, {SEED_SUNFLOWER, 8, -1},
    {SEED_POTATOMINE, 4, 0}, {SEED_SUNFLOWER, 2, 0}, {SEED_SUNFLOWER, 2, 1}, {SEED_THREEPEATER, 1, 1}, {SEED_SNOWPEA, 1, 1}, {SEED_SPLITPEA, 1, 1}, {SEED_CHOMPER, 3, 2}, {SEED_SUNFLOWER, 2, 2}, {SEED_SQUASH, 1, 2}, {SEED_PEASHOOTER, 3, 3}, {SEED_SUNFLOWER, 2, 3}, {SEED_SUNFLOWER, 1, 4}, {SEED_FUMESHROOM, 1, 4}, {SEED_SCAREDYSHROOM, 1, 4}, {SEED_STARFRUIT, 1, 4}, {SEED_SPLITPEA, 1, 4}, {SEED_MAGNETSHROOM, 1, 4},
};
constexpr int kIZombieRowBegin[10] = {0, 4, 12, 16, 23, 29, 38, 41, 47, 64};
static_assert(sizeof(kIZombieSquares) / sizeof(kIZombieSquares[0]) == 26, "squares total");
static_assert(sizeof(kIZombieRows) / sizeof(kIZombieRows[0]) == 64, "rows total");
}  // namespace

static void IZombieInitLevelB()
{
    g_challenge.mChallengeScore = 0;
    for (int aRow = 0; aRow < I_ZOMBIE_WINNING_SCORE; aRow++)
    {
        GridItemStub* aBrain = g_challenge.mBoard->mGridItems.DataArrayAlloc();
        aBrain->mGridItemType = GRIDITEM_IZOMBIE_BRAIN;
        aBrain->mGridX = 0;
        aBrain->mGridY = aRow;
        aBrain->mRenderOrder = BoardStub::MakeRenderOrder(RENDER_LAYER_PLANT, aRow, 0);
        aBrain->mGridItemCounter = 70;
        aBrain->mPosX = g_challenge.mBoard->GridToPixelX(0, aRow) - 40;
        aBrain->mPosY = g_challenge.mBoard->GridToPixelY(0, aRow) + 40;
    }

    if (g_challenge.mApp->mGameMode == GAMEMODE_PUZZLE_I_ZOMBIE_ENDLESS)
    {
        if (g_challenge.mSurvivalStage == 10)
            g_challenge.mApp->GiveAch(1);

        int aFormationHit = RandRangeInt(0, 4);

        int aPuffshroomCount = RandRangeInt(ClampInt(2 + g_challenge.mSurvivalStage / 3, 2, 4), ClampInt(3 + g_challenge.mSurvivalStage / 2, 2, 6));
        if (g_challenge.mSurvivalStage == 0)
        {
            aPuffshroomCount = 0;
        }
        else if (g_challenge.mSurvivalStage == 1)
        {
            aPuffshroomCount = 1;
        }
        else if (g_challenge.mSurvivalStage >= 10)
        {
            aPuffshroomCount = RandRangeInt(ClampInt(2 + g_challenge.mSurvivalStage / 3, 2, 5), ClampInt(3 + g_challenge.mSurvivalStage / 2, 2, 7));
        }
        int aSunflowerCount = 8 - aPuffshroomCount;
        g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, aSunflowerCount, -1);
        g_challenge.IZombiePlacePlants(SEED_PUFFSHROOM, aPuffshroomCount, -1);

        if (aFormationHit == 0 && g_challenge.mSurvivalStage >= 1)
        {
            switch (RandRangeInt(0, 4))
            {
            case 0:
                g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 4, -1);
                g_challenge.IZombiePlacePlants(SEED_REPEATER, 4, -1);
                break;
            case 1:
                g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_CHOMPER, 8, -1);
                break;
            case 2:
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_STARFRUIT, 8, -1);
                break;
            case 3:
                g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 9, -1);
                g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 8, -1);
                break;
            default:
                g_challenge.IZombiePlacePlants(SEED_SCAREDYSHROOM, 12, -1);
                g_challenge.IZombiePlacePlants(SEED_SUNFLOWER, 5, -1);
            }
        }
        else
        {
            switch (RandRangeInt(0, 5))
            {
            case 0:
            case 1:
            case 2:
                g_challenge.IZombiePlacePlants(SEED_WALLNUT, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_TORCHWOOD, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_CHOMPER, 2, -1);
                g_challenge.IZombiePlacePlants(SEED_PEASHOOTER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_KERNELPULT, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_THREEPEATER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SQUASH, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_UMBRELLA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_STARFRUIT, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 2, -1);
                break;
            case 3:
            case 4:
                g_challenge.IZombiePlacePlants(SEED_TORCHWOOD, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPLITPEA, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_REPEATER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_KERNELPULT, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_THREEPEATER, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SNOWPEA, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_UMBRELLA, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_MAGNETSHROOM, 1, -1);
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 3, -1);
                break;
            default:
                g_challenge.IZombiePlacePlants(SEED_POTATOMINE, 4, -1);
                g_challenge.IZombiePlacePlants(SEED_CHOMPER, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_SQUASH, 3, -1);
                g_challenge.IZombiePlacePlants(SEED_FUMESHROOM, 4, -1);
                g_challenge.IZombiePlacePlants(SEED_SPIKEWEED, 3, -1);
                break;
            }
        }
    }
    else
    {
        const int aLevelIndex = (int)g_challenge.mApp->mGameMode - (int)GAMEMODE_PUZZLE_I_ZOMBIE_1;
        if (aLevelIndex < 0 || aLevelIndex > 8)
        {
            TOD_ASSERT(false);
        }
        else
        {
            for (int k = kIZombieSquareBegin[aLevelIndex]; k < kIZombieSquareBegin[aLevelIndex + 1]; k++)
            {
                g_challenge.IZombiePlacePlantInSquare(kIZombieSquares[k].mSeedType, kIZombieSquares[k].mGridX, kIZombieSquares[k].mGridY);
            }
            for (int k = kIZombieRowBegin[aLevelIndex]; k < kIZombieRowBegin[aLevelIndex + 1]; k++)
            {
                g_challenge.IZombiePlacePlants(kIZombieRows[k].mSeedType, kIZombieRows[k].mCount, kIZombieRows[k].mGridY);
            }
        }
    }

    g_challenge.mBoard->mBonusLawnMowersRemaining = 0;
}

// ---------------- harness ----------------
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    uint32_t v = g_raw[i];
    g_app.mGameMode = (GameMode)(63 + (v % 10));
    g_rngState = v | 1;
    g_challenge.mApp = &g_app;
    g_challenge.mBoard = &g_board;
    g_challenge.mSurvivalStage = (int)((v >> 8) % 20);
    g_challenge.mChallengeScore = 5;
    g_board.mBonusLawnMowersRemaining = 3;
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); IZombieInitLevelA(); Mix(g_challenge.mChallengeScore); Mix(g_board.mBonusLawnMowersRemaining); Mix(g_brain.mRenderOrder); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum; g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); IZombieInitLevelB(); Mix(g_challenge.mChallengeScore); Mix(g_board.mBonusLawnMowersRemaining); Mix(g_brain.mRenderOrder); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("Challenge::IZombieInitLevel | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
