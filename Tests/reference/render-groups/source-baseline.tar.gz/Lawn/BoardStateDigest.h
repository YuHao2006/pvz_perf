#ifndef __BOARD_STATE_DIGEST_H__
#define __BOARD_STATE_DIGEST_H__

#include <cstdint>

class Board;

namespace pvz
{
namespace legacy
{

std::uint64_t ComputeBoardStateDigest(const Board& theBoard);
void InitializeBoardStateTrace();
void TraceBoardStateIfEnabled(const Board& theBoard);

class BoardStateTraceScope
{
public:
	explicit BoardStateTraceScope(const Board& theBoard);
	~BoardStateTraceScope();

private:
	const Board& mBoard;
};

}
}

#endif
