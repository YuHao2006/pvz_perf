
void __thiscall FUN_0054c760(int *param_1,char param_2)

{
  char cVar1;
  
  if (*(char *)((int)param_1 + 0x66) != param_2) {
    *(char *)((int)param_1 + 0x66) = param_2;
    if ((param_2 != '\0') && (param_1[8] != 0)) {
      (**(code **)(*(int *)param_1[8] + 0x18))(param_1);
    }
    (**(code **)(*param_1 + 0x44))();
    if (((param_2 == '\0') && (param_1[8] != 0)) &&
       (cVar1 = (**(code **)(*param_1 + 0x110))
                          (*(undefined4 *)(param_1[8] + 0x108),*(undefined4 *)(param_1[8] + 0x10c)),
       cVar1 != '\0')) {
      FUN_0054b5f0(*(undefined4 *)(param_1[8] + 0x108),*(undefined4 *)(param_1[8] + 0x10c));
    }
  }
  return;
}

