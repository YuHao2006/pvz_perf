// bench01 | Board::DrawDebugText | 5 case switch -> kDebugTextCases 5-slot lambda table
// FormA = ac447d19^ (pre switch-batch), FormB = HEAD (table). Bodies identical (shared stubs).
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstdarg>

// ---------------- checksum ----------------
static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

// ---------------- inputs ----------------
static const int kN = 2000000;
static uint32_t g_raw[kN];
static int g_pos = 0;
static inline uint32_t NextVal() { uint32_t v = g_raw[g_pos % kN]; g_pos++; return v; }

// ---------------- game stubs ----------------
enum DebugTextMode { DEBUG_TEXT_NONE = 0, DEBUG_TEXT_ZOMBIE_SPAWN = 1, DEBUG_TEXT_MUSIC = 2, DEBUG_TEXT_MEMORY = 3, DEBUG_TEXT_COLLISION = 4 };
enum MusicFile { MUSIC_FILE_NONE = 0, MUSIC_FILE_MAIN = 1, MUSIC_FILE_HIHATS = 2, MUSIC_FILE_DRUMS = 3 };
enum MusicBurstState { MUSIC_BURST_OFF = 0, MUSIC_BURST_STARTING = 1, MUSIC_BURST_ON = 2, MUSIC_BURST_FINISHING = 3 };
enum MusicDrumsState { MUSIC_DRUMS_OFF = 0, MUSIC_DRUMS_ON_QUEUED = 1, MUSIC_DRUMS_ON = 2, MUSIC_DRUMS_OFF_QUEUED = 3, MUSIC_DRUMS_FADING = 4 };
enum MusicTune { MUSIC_TUNE_DAY_GRASSWALK = 0, MUSIC_TUNE_POOL_WATERYGRAVES = 1, MUSIC_TUNE_FOG_RIGORMORMIST = 2, MUSIC_TUNE_ROOF_GRAZETHEROOF = 3, MUSIC_TUNE_NIGHT_MOONGRAINS = 4, MUSIC_TUNE_OTHER = 5 };
typedef int HMUSIC;
const int BASS_ATTRIB_MUSIC_BPM = 7;

struct SexyString {
    uint64_t h = 0;
    SexyString() {}
    SexyString(uint64_t v) : h(v) {}
};
static inline SexyString& operator+=(SexyString& a, const SexyString& b) { a.h = a.h * 131 + b.h; return a; }

// stub ids
static SexyString StrFormat(const char* fmt, ...) { // id 1 per-callsite via fmt ptr
    va_list ap; va_start(ap, fmt); va_end(ap);
    Mix(1); Mix((uint64_t)(uintptr_t)fmt);
    return SexyString((uint64_t)(uintptr_t)fmt);
}
static inline void TOD_ASSERT_IMPL(bool) {}
#define TOD_ASSERT(x) TOD_ASSERT_IMPL((x))  // release no-op (game asserts compiled out)

struct ListStub { int mSize; };
struct ZombieStub {
    int mSummonCounter, mBossStompCounter, mBossBungeeCounter, mBossHeadCounter, mBodyHealth, mBodyMaxHealth;
};
struct BassStub { void BASS_ChannelGetAttribute(HMUSIC, int, float* out) { Mix(6); *out = 120.0f; } };
static BassStub* gBass = nullptr;
struct MusicStub {
    MusicFile mCurMusicFileMain, mCurMusicFileHihats, mCurMusicFileDrums;
    MusicBurstState mMusicBurstState; int mBurstStateCounter;
    MusicDrumsState mMusicDrumsState; int mDrumsStateCounter;
    MusicTune mCurMusicTune;
    int GetMusicOrder(MusicFile f) { Mix(4); return (int)f * 0x10003 + 0x11; }
    HMUSIC GetBassMusicHandle(MusicFile f) { Mix(5); return (int)f + 1; }
};
struct HolderStub { ListStub mAttachments; ListStub mEmitters; ListStub mParticles; ListStub mParticleSystems; ListStub mReanimations; };
struct EffectSystemStub { HolderStub* mAttachmentHolder; HolderStub* mParticleHolder; HolderStub* mReanimationHolder; };
struct AppStub { MusicStub* mMusic; EffectSystemStub* mEffectSystem; };

struct GraphicsStub {
    void* mFont = nullptr;
    void SetFont(void* f) { Mix(7); mFont = f; }
    void SetColor(int c) { Mix(8); (void)c; }
    void DrawStringWordWrapped(const SexyString& s, int x, int y) { Mix(9); Mix(s.h); Mix((uint64_t)x * 31 + (uint64_t)y); }
};
struct ColorStub { int c; ColorStub(int v) : c(v) {} };
static const ColorStub Color_Black(1);
static ColorStub ColorWhite(2);

static ZombieStub g_bossZombie;
struct BoardStub {
    DebugTextMode mDebugTextMode;
    int mZombieCountDownStart, mZombieCountDown, mCurrentWave, mNumWaves;
    int mZombieHealthToNextWave, mZombieHealthWaveStart, mHugeWaveCountDown;
    ListStub mZombies, mPlants, mProjectiles, mCoins, mLawnMowers, mGridItems;
    void* mDebugFont;
    AppStub* mApp;

    int TotalZombiesHealthInWave(int w) { Mix(2); return w * 17 + 3; }
    ZombieStub* GetBossZombie() { Mix(3); return (NextVal() & 1) ? &g_bossZombie : nullptr; }
};
static HolderStub g_holder;
static EffectSystemStub g_effects{ &g_holder, &g_holder, &g_holder };
static MusicStub g_music;
static AppStub g_app{ &g_music, &g_effects };
static BoardStub g_board;

// ================= FormA: verbatim pre-conversion switch (ac447d19^) =================
static void DrawDebugTextA(GraphicsStub* g)
{
    SexyString aText;

    switch (g_board.mDebugTextMode)
    {
    case DebugTextMode::DEBUG_TEXT_NONE:
        break;

    case DebugTextMode::DEBUG_TEXT_ZOMBIE_SPAWN:
    {
        int aTime = g_board.mZombieCountDownStart - g_board.mZombieCountDown;
        float aCountDownFraction = (float)aTime / (float)g_board.mZombieCountDownStart;

        aText += StrFormat(("ZOMBIE SPAWNING DEBUG\n"));
        aText += StrFormat(("CurrentWave: %d of %d\n"), g_board.mCurrentWave, g_board.mNumWaves);
        aText += StrFormat(("TimeSinseLastSpawn: %d %s\n"), aTime, aTime > 400 ? ("") : ("(too soon)"));
        aText += StrFormat(("ZombieCountDown: %d/%d (%.0f%%)\n"), g_board.mZombieCountDown, g_board.mZombieCountDownStart, aCountDownFraction);

        if (g_board.mZombieHealthToNextWave != -1)
        {
            int aTotalHealth = g_board.TotalZombiesHealthInWave(g_board.mCurrentWave - 1);
            int aHealthRange = (g_board.mZombieHealthWaveStart - g_board.mZombieHealthToNextWave > 1) ? g_board.mZombieHealthWaveStart - g_board.mZombieHealthToNextWave : 1;
            float aHealthFraction = (float)(g_board.mZombieHealthToNextWave - aTotalHealth + aHealthRange) / (float)aHealthRange;
            aText += StrFormat(("ZombieHealth: CurZombieHealth %d trigger %d (%.0f%%)\n"), aTotalHealth, g_board.mZombieHealthToNextWave, aHealthFraction * 100);
        }
        else
        {
            aText += StrFormat(("ZombieHealth: before first wave\n"));
        }

        if (g_board.mHugeWaveCountDown > 0)
        {
            aText += StrFormat(("HugeWaveCountDown: %d\n"), g_board.mHugeWaveCountDown);
        }

        ZombieStub* aBossZombie = g_board.GetBossZombie();
        if (aBossZombie)
        {
            aText += StrFormat(("\nSpawn: %d\n"), aBossZombie->mSummonCounter);
            aText += StrFormat(("Stomp: %d\n"), aBossZombie->mBossStompCounter);
            aText += StrFormat(("Bungee: %d\n"), aBossZombie->mBossBungeeCounter);
            aText += StrFormat(("Head: %d\n"), aBossZombie->mBossHeadCounter);
            aText += StrFormat(("Health: %d of %d\n"), aBossZombie->mBodyHealth, aBossZombie->mBodyMaxHealth);
        }

        break;
    }

    case DebugTextMode::DEBUG_TEXT_MUSIC:
    {
        aText += StrFormat(("MUSIC DEBUG\n"));
        aText += StrFormat(("CurrentWave: %d of %d\n"), g_board.mCurrentWave, g_board.mNumWaves);

        if (g_board.mApp->mMusic->mCurMusicFileMain == MusicFile::MUSIC_FILE_NONE)
        {
            aText += StrFormat(("No music"));
        }
        else
        {
            aText += StrFormat(("Music Burst: "));

            if (g_board.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_OFF)
            {
                aText += StrFormat(("Off"));
            }
            else if (g_board.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_STARTING)
            {
                aText += StrFormat(("Starting %d/%d"), g_board.mApp->mMusic->mBurstStateCounter, 400);
            }
            else if (g_board.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_ON)
            {
                aText += StrFormat(("On at least until %d/%d"), g_board.mApp->mMusic->mBurstStateCounter, 800);
            }
            else if (g_board.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_FINISHING)
            {
                aText += StrFormat(("Finishing %d/%d"), g_board.mApp->mMusic->mBurstStateCounter, 400);
            }

            if (g_board.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_OFF)
            {
                aText += StrFormat((", Drums off"));
            }
            else if (g_board.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_ON_QUEUED)
            {
                aText += StrFormat((", Drums queued on"));
            }
            else if (g_board.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_ON)
            {
                aText += StrFormat((", Drums on"));
            }
            else if (g_board.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_OFF_QUEUED)
            {
                aText += StrFormat((", Drums queued off"));
            }
            else if (g_board.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_FADING)
            {
                aText += StrFormat((", Drums fading off %d/%d"), g_board.mApp->mMusic->mDrumsStateCounter, 50);
            }
            aText += StrFormat(("\n"));

            int aPackedOrderMain = g_board.mApp->mMusic->GetMusicOrder(g_board.mApp->mMusic->mCurMusicFileMain);
            int aCurrentOrder = LOWORD(aPackedOrderMain);
            aText += StrFormat(("Music order %02d row %02d\n"), LOWORD(aPackedOrderMain), HIWORD(aPackedOrderMain) / 4);
            if (g_board.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_DAY_GRASSWALK ||
                g_board.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_POOL_WATERYGRAVES ||
                g_board.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_FOG_RIGORMORMIST ||
                g_board.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_ROOF_GRAZETHEROOF)
            {
                int aPackedOrderHihats = g_board.mApp->mMusic->GetMusicOrder(g_board.mApp->mMusic->mCurMusicFileHihats);
                int aPackedOrderDrums = g_board.mApp->mMusic->GetMusicOrder(g_board.mApp->mMusic->mCurMusicFileDrums);
                if (aCurrentOrder == LOWORD(aPackedOrderHihats) && aCurrentOrder == LOWORD(aPackedOrderDrums))
                {
                    int aDiffHihats = HIWORD(aPackedOrderHihats) - HIWORD(aPackedOrderMain);
                    int aDiffDrums = HIWORD(aPackedOrderDrums) - HIWORD(aPackedOrderMain);
                    if (abs(aDiffHihats) > 1 || abs(aDiffDrums) > 1)
                    {
                        aText += StrFormat(("Music unsynced hihats %d drums %d\n"), aDiffHihats, aDiffDrums);
                    }
                }

                HMUSIC aMusicHandle1 = g_board.mApp->mMusic->GetBassMusicHandle(g_board.mApp->mMusic->mCurMusicFileMain);
                HMUSIC aMusicHandle2 = g_board.mApp->mMusic->GetBassMusicHandle(g_board.mApp->mMusic->mCurMusicFileHihats);
                HMUSIC aMusicHandle3 = g_board.mApp->mMusic->GetBassMusicHandle(g_board.mApp->mMusic->mCurMusicFileDrums);
                float bpm1;
                float bpm2;
                float bpm3;
                gBass->BASS_ChannelGetAttribute(aMusicHandle1, BASS_ATTRIB_MUSIC_BPM, &bpm1);
                gBass->BASS_ChannelGetAttribute(aMusicHandle2, BASS_ATTRIB_MUSIC_BPM, &bpm2);
                gBass->BASS_ChannelGetAttribute(aMusicHandle3, BASS_ATTRIB_MUSIC_BPM, &bpm3);
                aText += StrFormat(("bpm1 %f bmp2 %f bpm3 %f\n"), bpm1, bpm2, bpm3);
            }
            else if (g_board.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_NIGHT_MOONGRAINS)
            {
                int aPackedOrderDrums = g_board.mApp->mMusic->GetMusicOrder(g_board.mApp->mMusic->mCurMusicFileDrums);
                aText += StrFormat(("Drum order %02d row %02d\n"), LOWORD(aPackedOrderDrums), HIWORD(aPackedOrderDrums) / 4);
                int aDiffDrums = HIWORD(aPackedOrderDrums) - HIWORD(aPackedOrderMain);
                if (abs(aDiffDrums) > 0 && abs(aDiffDrums) <= 128)
                {
                    aText += StrFormat(("Drum unsynced %d"), aDiffDrums);
                }
            }
        }

        break;
    }

    case DebugTextMode::DEBUG_TEXT_MEMORY:
        aText += StrFormat(("MEMORY DEBUG\n"));
        aText += StrFormat(("attachments %d\n"), g_board.mApp->mEffectSystem->mAttachmentHolder->mAttachments.mSize);
        aText += StrFormat(("emitters %d\n"), g_board.mApp->mEffectSystem->mParticleHolder->mEmitters.mSize);
        aText += StrFormat(("particles %d\n"), g_board.mApp->mEffectSystem->mParticleHolder->mParticles.mSize);
        aText += StrFormat(("particle systems %d\n"), g_board.mApp->mEffectSystem->mParticleHolder->mParticleSystems.mSize);
        aText += StrFormat(("reanimation %d\n"), g_board.mApp->mEffectSystem->mReanimationHolder->mReanimations.mSize);
        aText += StrFormat(("zombies %d\n"), g_board.mZombies.mSize);
        aText += StrFormat(("plants %d\n"), g_board.mPlants.mSize);
        aText += StrFormat(("projectiles %d\n"), g_board.mProjectiles.mSize);
        aText += StrFormat(("coins %d\n"), g_board.mCoins.mSize);
        aText += StrFormat(("lawn mowers %d\n"), g_board.mLawnMowers.mSize);
        aText += StrFormat(("grid items %d\n"), g_board.mGridItems.mSize);
        break;

    case DebugTextMode::DEBUG_TEXT_COLLISION:
        aText += StrFormat(("COLLISION DEBUG\n"));
        break;

    default:
        TOD_ASSERT(false);
        break;
    }

    g->SetFont(g_board.mDebugFont);
    g->SetColor(1);
    g->DrawStringWordWrapped(aText, 10, 89);
    g->DrawStringWordWrapped(aText, 11, 91);
    g->DrawStringWordWrapped(aText, 9, 90);
    g->DrawStringWordWrapped(aText, 11, 90);
    g->SetColor(2);
    g->DrawStringWordWrapped(aText, 10, 90);
}

// ================= FormB: HEAD lambda table =================
namespace {
using DebugTextCaseFn = void (*)(BoardStub&, SexyString&);

void DebugTextDefault(BoardStub& aBoard, SexyString& aText)
{
    (void)aBoard; (void)aText;
    TOD_ASSERT(false);
}

constexpr DebugTextCaseFn kDebugTextCases[(int)DebugTextMode::DEBUG_TEXT_COLLISION + 1] = {
    [](BoardStub& aBoard, SexyString& aText)
    {
        (void)aBoard; (void)aText;
    },  // 0 DEBUG_TEXT_NONE
    [](BoardStub& aBoard, SexyString& aText)
    {
        int aTime = aBoard.mZombieCountDownStart - aBoard.mZombieCountDown;
        float aCountDownFraction = (float)aTime / (float)aBoard.mZombieCountDownStart;

        aText += StrFormat(("ZOMBIE SPAWNING DEBUG\n"));
        aText += StrFormat(("CurrentWave: %d of %d\n"), aBoard.mCurrentWave, aBoard.mNumWaves);
        aText += StrFormat(("TimeSinseLastSpawn: %d %s\n"), aTime, aTime > 400 ? ("") : ("(too soon)"));
        aText += StrFormat(("ZombieCountDown: %d/%d (%.0f%%)\n"), aBoard.mZombieCountDown, aBoard.mZombieCountDownStart, aCountDownFraction);

        if (aBoard.mZombieHealthToNextWave != -1)
        {
            int aTotalHealth = aBoard.TotalZombiesHealthInWave(aBoard.mCurrentWave - 1);
            int aHealthRange = (aBoard.mZombieHealthWaveStart - aBoard.mZombieHealthToNextWave > 1) ? aBoard.mZombieHealthWaveStart - aBoard.mZombieHealthToNextWave : 1;
            float aHealthFraction = (float)(aBoard.mZombieHealthToNextWave - aTotalHealth + aHealthRange) / (float)aHealthRange;
            aText += StrFormat(("ZombieHealth: CurZombieHealth %d trigger %d (%.0f%%)\n"), aTotalHealth, aBoard.mZombieHealthToNextWave, aHealthFraction * 100);
        }
        else
        {
            aText += StrFormat(("ZombieHealth: before first wave\n"));
        }

        if (aBoard.mHugeWaveCountDown > 0)
        {
            aText += StrFormat(("HugeWaveCountDown: %d\n"), aBoard.mHugeWaveCountDown);
        }

        ZombieStub* aBossZombie = aBoard.GetBossZombie();
        if (aBossZombie)
        {
            aText += StrFormat(("\nSpawn: %d\n"), aBossZombie->mSummonCounter);
            aText += StrFormat(("Stomp: %d\n"), aBossZombie->mBossStompCounter);
            aText += StrFormat(("Bungee: %d\n"), aBossZombie->mBossBungeeCounter);
            aText += StrFormat(("Head: %d\n"), aBossZombie->mBossHeadCounter);
            aText += StrFormat(("Health: %d of %d\n"), aBossZombie->mBodyHealth, aBossZombie->mBodyMaxHealth);
        }
    },  // 1 DEBUG_TEXT_ZOMBIE_SPAWN
    [](BoardStub& aBoard, SexyString& aText)
    {
        aText += StrFormat(("MUSIC DEBUG\n"));
        aText += StrFormat(("CurrentWave: %d of %d\n"), aBoard.mCurrentWave, aBoard.mNumWaves);

        if (aBoard.mApp->mMusic->mCurMusicFileMain == MusicFile::MUSIC_FILE_NONE)
        {
            aText += StrFormat(("No music"));
        }
        else
        {
            aText += StrFormat(("Music Burst: "));

            if (aBoard.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_OFF)
            {
                aText += StrFormat(("Off"));
            }
            else if (aBoard.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_STARTING)
            {
                aText += StrFormat(("Starting %d/%d"), aBoard.mApp->mMusic->mBurstStateCounter, 400);
            }
            else if (aBoard.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_ON)
            {
                aText += StrFormat(("On at least until %d/%d"), aBoard.mApp->mMusic->mBurstStateCounter, 800);
            }
            else if (aBoard.mApp->mMusic->mMusicBurstState == MusicBurstState::MUSIC_BURST_FINISHING)
            {
                aText += StrFormat(("Finishing %d/%d"), aBoard.mApp->mMusic->mBurstStateCounter, 400);
            }

            if (aBoard.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_OFF)
            {
                aText += StrFormat((", Drums off"));
            }
            else if (aBoard.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_ON_QUEUED)
            {
                aText += StrFormat((", Drums queued on"));
            }
            else if (aBoard.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_ON)
            {
                aText += StrFormat((", Drums on"));
            }
            else if (aBoard.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_OFF_QUEUED)
            {
                aText += StrFormat((", Drums queued off"));
            }
            else if (aBoard.mApp->mMusic->mMusicDrumsState == MusicDrumsState::MUSIC_DRUMS_FADING)
            {
                aText += StrFormat((", Drums fading off %d/%d"), aBoard.mApp->mMusic->mDrumsStateCounter, 50);
            }
            aText += StrFormat(("\n"));

            int aPackedOrderMain = aBoard.mApp->mMusic->GetMusicOrder(aBoard.mApp->mMusic->mCurMusicFileMain);
            int aCurrentOrder = LOWORD(aPackedOrderMain);
            aText += StrFormat(("Music order %02d row %02d\n"), LOWORD(aPackedOrderMain), HIWORD(aPackedOrderMain) / 4);
            if (aBoard.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_DAY_GRASSWALK ||
                aBoard.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_POOL_WATERYGRAVES ||
                aBoard.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_FOG_RIGORMORMIST ||
                aBoard.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_ROOF_GRAZETHEROOF)
            {
                int aPackedOrderHihats = aBoard.mApp->mMusic->GetMusicOrder(aBoard.mApp->mMusic->mCurMusicFileHihats);
                int aPackedOrderDrums = aBoard.mApp->mMusic->GetMusicOrder(aBoard.mApp->mMusic->mCurMusicFileDrums);
                if (aCurrentOrder == LOWORD(aPackedOrderHihats) && aCurrentOrder == LOWORD(aPackedOrderDrums))
                {
                    int aDiffHihats = HIWORD(aPackedOrderHihats) - HIWORD(aPackedOrderMain);
                    int aDiffDrums = HIWORD(aPackedOrderDrums) - HIWORD(aPackedOrderMain);
                    if (abs(aDiffHihats) > 1 || abs(aDiffDrums) > 1)
                    {
                        aText += StrFormat(("Music unsynced hihats %d drums %d\n"), aDiffHihats, aDiffDrums);
                    }
                }

                HMUSIC aMusicHandle1 = aBoard.mApp->mMusic->GetBassMusicHandle(aBoard.mApp->mMusic->mCurMusicFileMain);
                HMUSIC aMusicHandle2 = aBoard.mApp->mMusic->GetBassMusicHandle(aBoard.mApp->mMusic->mCurMusicFileHihats);
                HMUSIC aMusicHandle3 = aBoard.mApp->mMusic->GetBassMusicHandle(aBoard.mApp->mMusic->mCurMusicFileDrums);
                float bpm1;
                float bpm2;
                float bpm3;
                gBass->BASS_ChannelGetAttribute(aMusicHandle1, BASS_ATTRIB_MUSIC_BPM, &bpm1);
                gBass->BASS_ChannelGetAttribute(aMusicHandle2, BASS_ATTRIB_MUSIC_BPM, &bpm2);
                gBass->BASS_ChannelGetAttribute(aMusicHandle3, BASS_ATTRIB_MUSIC_BPM, &bpm3);
                aText += StrFormat(("bpm1 %f bmp2 %f bpm3 %f\n"), bpm1, bpm2, bpm3);
            }
            else if (aBoard.mApp->mMusic->mCurMusicTune == MusicTune::MUSIC_TUNE_NIGHT_MOONGRAINS)
            {
                int aPackedOrderDrums = aBoard.mApp->mMusic->GetMusicOrder(aBoard.mApp->mMusic->mCurMusicFileDrums);
                aText += StrFormat(("Drum order %02d row %02d\n"), LOWORD(aPackedOrderDrums), HIWORD(aPackedOrderDrums) / 4);
                int aDiffDrums = HIWORD(aPackedOrderDrums) - HIWORD(aPackedOrderMain);
                if (abs(aDiffDrums) > 0 && abs(aDiffDrums) <= 128)
                {
                    aText += StrFormat(("Drum unsynced %d"), aDiffDrums);
                }
            }
        }
    },  // 2 DEBUG_TEXT_MUSIC
    [](BoardStub& aBoard, SexyString& aText)
    {
        aText += StrFormat(("MEMORY DEBUG\n"));
        aText += StrFormat(("attachments %d\n"), aBoard.mApp->mEffectSystem->mAttachmentHolder->mAttachments.mSize);
        aText += StrFormat(("emitters %d\n"), aBoard.mApp->mEffectSystem->mParticleHolder->mEmitters.mSize);
        aText += StrFormat(("particles %d\n"), aBoard.mApp->mEffectSystem->mParticleHolder->mParticles.mSize);
        aText += StrFormat(("particle systems %d\n"), aBoard.mApp->mEffectSystem->mParticleHolder->mParticleSystems.mSize);
        aText += StrFormat(("reanimation %d\n"), aBoard.mApp->mEffectSystem->mReanimationHolder->mReanimations.mSize);
        aText += StrFormat(("zombies %d\n"), aBoard.mZombies.mSize);
        aText += StrFormat(("plants %d\n"), aBoard.mPlants.mSize);
        aText += StrFormat(("projectiles %d\n"), aBoard.mProjectiles.mSize);
        aText += StrFormat(("coins %d\n"), aBoard.mCoins.mSize);
        aText += StrFormat(("lawn mowers %d\n"), aBoard.mLawnMowers.mSize);
        aText += StrFormat(("grid items %d\n"), aBoard.mGridItems.mSize);
    },  // 3 DEBUG_TEXT_MEMORY
    [](BoardStub& aBoard, SexyString& aText)
    {
        aText += StrFormat(("COLLISION DEBUG\n"));
    },  // 4 DEBUG_TEXT_COLLISION
};
static_assert(sizeof(kDebugTextCases) / sizeof(kDebugTextCases[0]) ==
    (int)DebugTextMode::DEBUG_TEXT_COLLISION + 1, "kDebugTextCases slot count");
}  // namespace

static void DrawDebugTextB(GraphicsStub* g)
{
    SexyString aText;

    const unsigned aDebugIndex = static_cast<unsigned>(g_board.mDebugTextMode);
    if (aDebugIndex <= static_cast<unsigned>(DebugTextMode::DEBUG_TEXT_COLLISION))
    {
        kDebugTextCases[aDebugIndex](g_board, aText);
    }
    else
    {
        DebugTextDefault(g_board, aText);
    }

    g->SetFont(g_board.mDebugFont);
    g->SetColor(1);
    g->DrawStringWordWrapped(aText, 10, 89);
    g->DrawStringWordWrapped(aText, 11, 91);
    g->DrawStringWordWrapped(aText, 9, 90);
    g->DrawStringWordWrapped(aText, 11, 90);
    g->SetColor(2);
    g->DrawStringWordWrapped(aText, 10, 90);
}

// ---------------- harness ----------------
static GraphicsStub g_gfx;
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    g_pos = 0;
    g_board.mDebugTextMode = (DebugTextMode)(g_raw[i] % 5);
    uint32_t v = g_raw[i];
    g_board.mZombieCountDownStart = 500 + (v % 100);
    g_board.mZombieCountDown = (int)(v % 400) + ((v >> 8) & 1) * 200;
    g_board.mCurrentWave = (v >> 4) % 10 + 1;
    g_board.mNumWaves = 20;
    g_board.mZombieHealthToNextWave = ((v >> 3) & 1) ? 1000 : -1;
    g_board.mZombieHealthWaveStart = 2000;
    g_board.mHugeWaveCountDown = ((v >> 5) & 1) ? 30 : 0;
    g_board.mZombies.mSize = 5; g_board.mPlants.mSize = 6; g_board.mProjectiles.mSize = 7;
    g_board.mCoins.mSize = 8; g_board.mLawnMowers.mSize = 9; g_board.mGridItems.mSize = 10;
    g_board.mDebugFont = nullptr;
    g_board.mApp = &g_app;
    g_music.mCurMusicFileMain = ((v >> 6) & 1) ? MusicFile::MUSIC_FILE_MAIN : MusicFile::MUSIC_FILE_NONE;
    g_music.mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
    g_music.mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
    g_music.mMusicBurstState = (MusicBurstState)((v >> 7) % 4);
    g_music.mMusicDrumsState = (MusicDrumsState)((v >> 9) % 5);
    g_music.mBurstStateCounter = 200; g_music.mDrumsStateCounter = 25;
    g_music.mCurMusicTune = (MusicTune)((v >> 10) % 6);
    g_bossZombie.mSummonCounter = (v % 7); g_bossZombie.mBossStompCounter = 2;
    g_bossZombie.mBossBungeeCounter = 3; g_bossZombie.mBossHeadCounter = 4;
    g_bossZombie.mBodyHealth = 500; g_bossZombie.mBodyMaxHealth = 1000;
    g_holder.mAttachments.mSize = 1; g_holder.mEmitters.mSize = 2; g_holder.mParticles.mSize = 3;
    g_holder.mParticleSystems.mSize = 4; g_holder.mReanimations.mSize = 5;
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }
    gBass = new BassStub();

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); DrawDebugTextA(&g_gfx); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum;
    g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); DrawDebugTextB(&g_gfx); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("Board::DrawDebugText | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
