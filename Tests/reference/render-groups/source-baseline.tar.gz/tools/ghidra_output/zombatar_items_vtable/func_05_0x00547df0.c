
bool __fastcall FUN_00547df0(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  undefined1 local_24 [4];
  undefined4 local_20;
  undefined1 local_1c [8];
  undefined1 local_14 [8];
  undefined4 local_c;
  undefined4 local_8;
  
  uVar3 = *(undefined4 *)(param_1 + 0x18);
  FUN_00420ae0();
  local_20 = uVar3;
  if (param_1 == -4) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  uVar3 = *(undefined4 *)(param_1 + 0x18);
  FUN_00420ae0();
  local_8 = uVar3;
  if (param_1 == -4) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  puVar4 = &stack0x00000004;
  uVar3 = local_8;
  puVar2 = (undefined4 *)FUN_005b75d0(local_14);
  FUN_0055a680(local_1c,*puVar2,puVar2[1],local_c,uVar3,puVar4);
  cVar1 = FUN_006143c0(local_24);
  return cVar1 == '\0';
}

