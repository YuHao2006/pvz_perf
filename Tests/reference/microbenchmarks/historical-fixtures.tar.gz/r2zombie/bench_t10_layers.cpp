// bench_t10 — kZombieLayerOps 34x4 -> Zombie::SetupReanimLayers（装载事件）
#include "zb_common.h"
#include <cstdint>

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::SetupReanimLayers_A(Reanimation* aReanim, ZombieType theZombieType)
{
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_cone, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_bucket, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_screendoor, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_flaghand, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_duckytube, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_mustache, RENDER_GROUP_HIDDEN);
    SetupDoorArms(aReanim, false);

    if (theZombieType == ZombieType::ZOMBIE_TRAFFIC_CONE)
    {
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_cone, RENDER_GROUP_NORMAL);
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
    }
    else if (theZombieType == ZombieType::ZOMBIE_PAIL)
    {
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_bucket, RENDER_GROUP_NORMAL);
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
    }
    else if (theZombieType == ZombieType::ZOMBIE_DOOR)
    {
        SetupDoorArms(aReanim, true);
    }
    else if (theZombieType == ZombieType::ZOMBIE_NEWSPAPER)
    {
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_paper_paper, RENDER_GROUP_HIDDEN);
    }
    else if (theZombieType == ZombieType::ZOMBIE_FLAG)
    {
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_innerarm, RENDER_GROUP_HIDDEN);
        aReanim->AssignRenderGroupToTrack(ReanimTrackId::Zombie_flaghand, RENDER_GROUP_NORMAL);
        aReanim->AssignRenderGroupToTrack(ReanimTrackId::Zombie_innerarm_screendoor, RENDER_GROUP_NORMAL);
    }
    else if (theZombieType == ZombieType::ZOMBIE_ZOMBATAR)
    {
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_innerarm, RENDER_GROUP_HIDDEN);
        aReanim->AssignRenderGroupToTrack(ReanimTrackId::Zombie_flaghand, RENDER_GROUP_NORMAL);
        aReanim->AssignRenderGroupToTrack(ReanimTrackId::Zombie_innerarm_screendoor, RENDER_GROUP_NORMAL);
        aReanim->AssignRenderGroupToTrack(ReanimTrackId::anim_head1, RENDER_GROUP_OVER_SHIELD);
    }
    else if (theZombieType == ZombieType::ZOMBIE_DUCKY_TUBE)
    {
        aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_duckytube, RENDER_GROUP_NORMAL);
    }
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::SetupReanimLayers_B(Reanimation* aReanim, ZombieType theZombieType)
{
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_cone, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_bucket, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_screendoor, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_flaghand, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_duckytube, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_HIDDEN);
    aReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_mustache, RENDER_GROUP_HIDDEN);
    SetupDoorArms(aReanim, false);

    // B 形态 -> 常量表 kZombieLayerOps（原 7 支链合并；行序 = ZombieType 枚举序
    // 0..33，每行至多 4 个渲染组操作，空区间（mLo==mHi）= 行尾哨兵/无 case。
    // 单轨操作（原 AssignRenderGroupToTrack）编码为 [t, t+1) 单元素区间——
    // 与按轨道号精确命中语义等价（Reanimator.cpp 两实现对照）；DOOR 支为
    // SetupDoorArms 整体调用，异构特例表外保留。
    struct ZombieLayerOp
    {
        ReanimTrackIdRange mRange;  // mLo == mHi = 空操作（行尾）
        int mGroup;
    };
    constexpr auto JustTrack = [](ReanimTrackId theTrack)
    {
        return ReanimTrackIdRange{theTrack, static_cast<ReanimTrackId>(static_cast<std::uint32_t>(theTrack) + 1)};
    };
    constexpr ZombieLayerOp kNoLayerOp{ReanimTrackIdRange{}, 0};
    static constexpr ZombieLayerOp kZombieLayerOps[(int)ZombieType::NUM_ZOMBIE_TYPES][4] = {
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 0 ZOMBIE_NORMAL（无 case）
        { { ReanimTrackRanges::anim_innerarm, RENDER_GROUP_HIDDEN }, { JustTrack(ReanimTrackId::Zombie_flaghand), RENDER_GROUP_NORMAL }, { JustTrack(ReanimTrackId::Zombie_innerarm_screendoor), RENDER_GROUP_NORMAL }, kNoLayerOp },  // 1 ZOMBIE_FLAG（后两支原为单轨 AssignRenderGroupToTrack）
        { { ReanimTrackRanges::anim_cone, RENDER_GROUP_NORMAL }, { ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN }, kNoLayerOp, kNoLayerOp },  // 2 ZOMBIE_TRAFFIC_CONE
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 3 ZOMBIE_POLEVAULTER（无 case）
        { { ReanimTrackRanges::anim_bucket, RENDER_GROUP_NORMAL }, { ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN }, kNoLayerOp, kNoLayerOp },  // 4 ZOMBIE_PAIL
        { { ReanimTrackRanges::Zombie_paper_paper, RENDER_GROUP_HIDDEN }, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 5 ZOMBIE_NEWSPAPER
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 6 ZOMBIE_DOOR（特例表外，槽位不可达）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 7 ZOMBIE_FOOTBALL（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 8 ZOMBIE_DANCER（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 9 ZOMBIE_BACKUP_DANCER（无 case）
        { { ReanimTrackRanges::Zombie_duckytube, RENDER_GROUP_NORMAL }, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 10 ZOMBIE_DUCKY_TUBE
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 11 ZOMBIE_SNORKEL（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 12 ZOMBIE_ZAMBONI（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 13 ZOMBIE_BOBSLED（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 14 ZOMBIE_DOLPHIN_RIDER（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 15 ZOMBIE_JACK_IN_THE_BOX（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 16 ZOMBIE_BALLOON（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 17 ZOMBIE_DIGGER（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 18 ZOMBIE_POGO（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 19 ZOMBIE_YETI（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 20 ZOMBIE_BUNGEE（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 21 ZOMBIE_LADDER（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 22 ZOMBIE_CATAPULT（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 23 ZOMBIE_GARGANTUAR（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 24 ZOMBIE_IMP（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 25 ZOMBIE_BOSS（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 26 ZOMBIE_PEA_HEAD（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 27 ZOMBIE_WALLNUT_HEAD（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 28 ZOMBIE_JALAPENO_HEAD（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 29 ZOMBIE_GATLING_HEAD（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 30 ZOMBIE_SQUASH_HEAD（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 31 ZOMBIE_TALLNUT_HEAD（无 case）
        { kNoLayerOp, kNoLayerOp, kNoLayerOp, kNoLayerOp },  // 32 ZOMBIE_REDEYE_GARGANTUAR（无 case）
        { { ReanimTrackRanges::anim_innerarm, RENDER_GROUP_HIDDEN }, { JustTrack(ReanimTrackId::Zombie_flaghand), RENDER_GROUP_NORMAL }, { JustTrack(ReanimTrackId::Zombie_innerarm_screendoor), RENDER_GROUP_NORMAL }, { JustTrack(ReanimTrackId::anim_head1), RENDER_GROUP_OVER_SHIELD } },  // 33 ZOMBIE_ZOMBATAR（FLAG 共体 + anim_head1 单轨）
    };
    static_assert(sizeof(kZombieLayerOps) / sizeof(kZombieLayerOps[0]) ==
        (int)ZombieType::NUM_ZOMBIE_TYPES, "kZombieLayerOps 槽位须与 ZombieType 枚举同步");

    if (theZombieType == ZombieType::ZOMBIE_DOOR)
    {
        SetupDoorArms(aReanim, true);
    }
    else
    {
        const unsigned aTypeIndex = static_cast<unsigned>(theZombieType);
        if (aTypeIndex < sizeof(kZombieLayerOps) / sizeof(kZombieLayerOps[0]))
        {
            for (const ZombieLayerOp& aOp : kZombieLayerOps[aTypeIndex])
            {
                if (aOp.mRange.mLo == aOp.mRange.mHi)  // 空区间 = 行尾
                {
                    break;
                }
                aReanim->AssignRenderGroupToRange(aOp.mRange, aOp.mGroup);
            }
        }
    }
}

static Zombie g_z;
int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ZombieType t = (ZombieType)(g_zb_inputs[i].a % 34);
            g_z.SetupReanimLayers_A(&g_zb_reanimA, t);
            ck = ZBMixU64(ck, (uint64_t)t);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ZombieType t = (ZombieType)(g_zb_inputs[i].a % 34);
            g_z.SetupReanimLayers_B(&g_zb_reanimA, t);
            ck = ZBMixU64(ck, (uint64_t)t);
        }
    };
    return ZBenchMain("t10_SetupReanimLayers", passA, passB);
}
