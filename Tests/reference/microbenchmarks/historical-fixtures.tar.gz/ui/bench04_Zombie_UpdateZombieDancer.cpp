// bench04 | Zombie::UpdateZombieDancer | 6 case switch -> kDancerPhaseCases (96-slot, shared with BackupDancer)
// FormA = ac447d19^, FormB = HEAD. Discriminant aDancerPhase uniform over ZombiePhase 0..95.
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

static const int kN = 2000000;
static uint32_t g_raw[kN];

enum ZombiePhase {
    PHASE_ZOMBIE_NORMAL = 0,
    PHASE_DANCER_DANCING_IN = 40, PHASE_DANCER_SNAPPING_FINGERS = 41, PHASE_DANCER_SNAPPING_FINGERS_WITH_LIGHT = 42,
    PHASE_DANCER_SNAPPING_FINGERS_HOLD = 43, PHASE_DANCER_DANCING_LEFT = 44, PHASE_DANCER_WALK_TO_RAISE = 45,
    PHASE_DANCER_RAISE_LEFT_1 = 46, PHASE_DANCER_RAISE_RIGHT_1 = 47, PHASE_DANCER_RAISE_LEFT_2 = 48,
    PHASE_DANCER_RAISE_RIGHT_2 = 49, PHASE_DANCER_RISING = 50,
    PHASE_SQUASH_DONE_FALLING = 95
};
enum ReanimTrackId { anim_walk = 0, anim_armraise = 1, anim_point = 2 };
enum ReanimLoopType { REANIM_LOOP = 0, REANIM_PLAY_ONCE_AND_HOLD = 1 };
enum FoleyType { FOLEY_DANCER = 1 };

struct ReanimationStub { float mAnimTime; int mLoopCount; };
static ReanimationStub g_reanim;
struct AppStub {
    ReanimationStub* ReanimationTryToGet(int id) { Mix(21); return &g_reanim; }
    void PlayFoley(FoleyType f) { Mix(30); Mix(f); }
};
static AppStub g_app;
struct BoardStub { int CountZombiesOnScreen() { Mix(31); return 10; } };
static BoardStub g_board;

static ZombiePhase g_inputPhase;
struct Zombie {
    bool mIsEating;
    bool mHasHead;
    ZombiePhase mZombiePhase;
    int mPhaseCounter;
    int mSummonCounter;
    int mBodyReanimID;
    float mPosX;
    AppStub* mApp;
    BoardStub* mBoard;

    int GetDancerFrame() { Mix(32); return 12; }
    void PickRandomSpeed() { Mix(33); }
    void SummonBackupDancers() { Mix(34); }
    bool NeedsMoreBackupDancers() { Mix(35); return false; }
    void PlayZombieReanim(ReanimTrackId t, ReanimLoopType l, int blend, float rate) { Mix(24); Mix((uint64_t)t + (int)l + blend + (int)rate * 1000); }
    ZombiePhase GetDancerPhase() { Mix(23); return g_inputPhase; }
};
static Zombie g_zombie;

// ================= FormA: verbatim switch (ac447d19^) =================
static void UpdateZombieDancerA()
{
    if (g_zombie.mIsEating)
        return;

    if (g_zombie.mSummonCounter > 0)
    {
        g_zombie.mSummonCounter--;
        if (g_zombie.mSummonCounter == 0)
        {
            if (g_zombie.GetDancerFrame() == 12 && g_zombie.mHasHead && g_zombie.mPosX < 700.0f)
            {
                g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_WITH_LIGHT;
                g_zombie.PlayZombieReanim(ReanimTrackId::anim_point, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 24.0f);
            }
            else
            {
                g_zombie.mSummonCounter = 1;
            }
        }
    }

    if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_DANCING_IN)
    {
        if (g_zombie.mHasHead && g_zombie.mPhaseCounter == 0)
        {
            g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_point, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 24.0f);
            g_zombie.PickRandomSpeed();
        }
    }
    else if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS || g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_WITH_LIGHT)
    {
        ReanimationStub* aBodyReanim = g_zombie.mApp->ReanimationTryToGet(g_zombie.mBodyReanimID);
        if (aBodyReanim->mLoopCount > 0)
        {
            if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS && g_zombie.mBoard->CountZombiesOnScreen() <= 15)
            {
                g_zombie.mApp->PlayFoley(FoleyType::FOLEY_DANCER);
            }

            g_zombie.SummonBackupDancers();
            g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_HOLD;
            g_zombie.mPhaseCounter = 200;
        }
    }
    else
    {
        if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_HOLD)
        {
            if (g_zombie.mPhaseCounter != 0)
                return;

            g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_LEFT;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 20, 0.0f);
        }

        ZombiePhase aDancerPhase = g_zombie.GetDancerPhase();
        if (aDancerPhase != g_zombie.mZombiePhase)
        {
            switch (aDancerPhase)
            {
            case ZombiePhase::PHASE_DANCER_DANCING_LEFT:
                g_zombie.mZombiePhase = aDancerPhase;
                g_zombie.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 10, 0.0f);
                break;

            case ZombiePhase::PHASE_DANCER_WALK_TO_RAISE:
                g_zombie.mZombiePhase = aDancerPhase;
                g_zombie.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
                g_zombie.mApp->ReanimationTryToGet(g_zombie.mBodyReanimID)->mAnimTime = 0.6f;
                break;

            case ZombiePhase::PHASE_DANCER_RAISE_LEFT_1:
            case ZombiePhase::PHASE_DANCER_RAISE_RIGHT_1:
            case ZombiePhase::PHASE_DANCER_RAISE_LEFT_2:
            case ZombiePhase::PHASE_DANCER_RAISE_RIGHT_2:
                g_zombie.mZombiePhase = aDancerPhase;
                g_zombie.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
                break;
            default:
                break;
            }
        }

        if (g_zombie.mHasHead && g_zombie.mSummonCounter == 0 && g_zombie.NeedsMoreBackupDancers())
        {
            g_zombie.mSummonCounter = 100;
        }
    }
}

// ================= FormB: HEAD shared table =================
namespace {
using DancerPhaseCaseFn = void (*)(Zombie&, ZombiePhase);

void DancerPhaseDancerRaiseLeft1(Zombie& z, ZombiePhase aDancerPhase)
{
    z.mZombiePhase = aDancerPhase;
    z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
}

void DancerDefault(Zombie& z, ZombiePhase aDancerPhase) { (void)z; (void)aDancerPhase; }

constexpr DancerPhaseCaseFn kDancerLeftLambda = [](Zombie& z, ZombiePhase aDancerPhase)
{
    z.mZombiePhase = aDancerPhase;
    z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 10, 0.0f);
};
constexpr DancerPhaseCaseFn kDancerWalkToRaiseLambda = [](Zombie& z, ZombiePhase aDancerPhase)
{
    z.mZombiePhase = aDancerPhase;
    z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 10, 18.0f);
    z.mApp->ReanimationTryToGet(z.mBodyReanimID)->mAnimTime = 0.6f;
};

constexpr DancerPhaseCaseFn kDancerPhaseCases[(int)ZombiePhase::PHASE_SQUASH_DONE_FALLING + 1] = {
    &DancerDefault,  // 0
    &DancerDefault,  // 1
    &DancerDefault,  // 2
    &DancerDefault,  // 3
    &DancerDefault,  // 4
    &DancerDefault,  // 5
    &DancerDefault,  // 6
    &DancerDefault,  // 7
    &DancerDefault,  // 8
    &DancerDefault,  // 9
    &DancerDefault,  // 10
    &DancerDefault,  // 11
    &DancerDefault,  // 12
    &DancerDefault,  // 13
    &DancerDefault,  // 14
    &DancerDefault,  // 15
    &DancerDefault,  // 16
    &DancerDefault,  // 17
    &DancerDefault,  // 18
    &DancerDefault,  // 19
    &DancerDefault,  // 20
    &DancerDefault,  // 21
    &DancerDefault,  // 22
    &DancerDefault,  // 23
    &DancerDefault,  // 24
    &DancerDefault,  // 25
    &DancerDefault,  // 26
    &DancerDefault,  // 27
    &DancerDefault,  // 28
    &DancerDefault,  // 29
    &DancerDefault,  // 30
    &DancerDefault,  // 31
    &DancerDefault,  // 32
    &DancerDefault,  // 33
    &DancerDefault,  // 34
    &DancerDefault,  // 35
    &DancerDefault,  // 36
    &DancerDefault,  // 37
    &DancerDefault,  // 38
    &DancerDefault,  // 39
    &DancerDefault,  // 40
    &DancerDefault,  // 41
    &DancerDefault,  // 42
    &DancerDefault,  // 43
    kDancerLeftLambda,  // 44 PHASE_DANCER_DANCING_LEFT
    kDancerWalkToRaiseLambda,  // 45 PHASE_DANCER_WALK_TO_RAISE
    &DancerPhaseDancerRaiseLeft1,  // 46（共体）
    &DancerPhaseDancerRaiseLeft1,  // 47（共体）
    &DancerPhaseDancerRaiseLeft1,  // 48（共体）
    &DancerPhaseDancerRaiseLeft1,  // 49（共体）
    &DancerDefault,  // 50
    &DancerDefault,  // 51
    &DancerDefault,  // 52
    &DancerDefault,  // 53
    &DancerDefault,  // 54
    &DancerDefault,  // 55
    &DancerDefault,  // 56
    &DancerDefault,  // 57
    &DancerDefault,  // 58
    &DancerDefault,  // 59
    &DancerDefault,  // 60
    &DancerDefault,  // 61
    &DancerDefault,  // 62
    &DancerDefault,  // 63
    &DancerDefault,  // 64
    &DancerDefault,  // 65
    &DancerDefault,  // 66
    &DancerDefault,  // 67
    &DancerDefault,  // 68
    &DancerDefault,  // 69
    &DancerDefault,  // 70
    &DancerDefault,  // 71
    &DancerDefault,  // 72
    &DancerDefault,  // 73
    &DancerDefault,  // 74
    &DancerDefault,  // 75
    &DancerDefault,  // 76
    &DancerDefault,  // 77
    &DancerDefault,  // 78
    &DancerDefault,  // 79
    &DancerDefault,  // 80
    &DancerDefault,  // 81
    &DancerDefault,  // 82
    &DancerDefault,  // 83
    &DancerDefault,  // 84
    &DancerDefault,  // 85
    &DancerDefault,  // 86
    &DancerDefault,  // 87
    &DancerDefault,  // 88
    &DancerDefault,  // 89
    &DancerDefault,  // 90
    &DancerDefault,  // 91
    &DancerDefault,  // 92
    &DancerDefault,  // 93
    &DancerDefault,  // 94
    &DancerDefault,  // 95
};
static_assert(sizeof(kDancerPhaseCases) / sizeof(kDancerPhaseCases[0]) ==
    (int)ZombiePhase::PHASE_SQUASH_DONE_FALLING + 1, "slot count");
}  // namespace

static void UpdateZombieDancerB()
{
    if (g_zombie.mIsEating)
        return;

    if (g_zombie.mSummonCounter > 0)
    {
        g_zombie.mSummonCounter--;
        if (g_zombie.mSummonCounter == 0)
        {
            if (g_zombie.GetDancerFrame() == 12 && g_zombie.mHasHead && g_zombie.mPosX < 700.0f)
            {
                g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_WITH_LIGHT;
                g_zombie.PlayZombieReanim(ReanimTrackId::anim_point, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 24.0f);
            }
            else
            {
                g_zombie.mSummonCounter = 1;
            }
        }
    }

    if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_DANCING_IN)
    {
        if (g_zombie.mHasHead && g_zombie.mPhaseCounter == 0)
        {
            g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_point, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 24.0f);
            g_zombie.PickRandomSpeed();
        }
    }
    else if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS || g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_WITH_LIGHT)
    {
        ReanimationStub* aBodyReanim = g_zombie.mApp->ReanimationTryToGet(g_zombie.mBodyReanimID);
        if (aBodyReanim->mLoopCount > 0)
        {
            if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS && g_zombie.mBoard->CountZombiesOnScreen() <= 15)
            {
                g_zombie.mApp->PlayFoley(FoleyType::FOLEY_DANCER);
            }

            g_zombie.SummonBackupDancers();
            g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_HOLD;
            g_zombie.mPhaseCounter = 200;
        }
    }
    else
    {
        if (g_zombie.mZombiePhase == ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS_HOLD)
        {
            if (g_zombie.mPhaseCounter != 0)
                return;

            g_zombie.mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_LEFT;
            g_zombie.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 20, 0.0f);
        }

        ZombiePhase aDancerPhase = g_zombie.GetDancerPhase();
        if (aDancerPhase != g_zombie.mZombiePhase)
        {
            const unsigned aPhaseIndex = static_cast<unsigned>(aDancerPhase);
            if (aPhaseIndex <= static_cast<unsigned>(ZombiePhase::PHASE_SQUASH_DONE_FALLING))
            {
                kDancerPhaseCases[aPhaseIndex](g_zombie, aDancerPhase);
            }
        }

        if (g_zombie.mHasHead && g_zombie.mSummonCounter == 0 && g_zombie.NeedsMoreBackupDancers())
        {
            g_zombie.mSummonCounter = 100;
        }
    }
}

// ---------------- harness ----------------
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    uint32_t v = g_raw[i];
    g_inputPhase = (ZombiePhase)(v % 96);
    g_zombie.mIsEating = false;
    g_zombie.mHasHead = true;
    g_zombie.mZombiePhase = (ZombiePhase)44;  // DANCING_LEFT: falls to final else, exercises dispatch
    g_zombie.mPhaseCounter = 0;
    g_zombie.mSummonCounter = ((v >> 8) & 1);  // 0 or 1: exercises the summon pre-branch
    g_zombie.mBodyReanimID = 7;
    g_zombie.mPosX = 100.0f;
    g_zombie.mApp = &g_app;
    g_zombie.mBoard = &g_board;
    g_reanim.mAnimTime = 0.0f;
    g_reanim.mLoopCount = 1;
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); UpdateZombieDancerA(); Mix(g_zombie.mZombiePhase); Mix(g_zombie.mSummonCounter); Mix(g_zombie.mPhaseCounter); Mix((uint64_t)(g_reanim.mAnimTime * 1000)); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum; g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); UpdateZombieDancerB(); Mix(g_zombie.mZombiePhase); Mix(g_zombie.mSummonCounter); Mix(g_zombie.mPhaseCounter); Mix((uint64_t)(g_reanim.mAnimTime * 1000)); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("Zombie::UpdateZombieDancer | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
