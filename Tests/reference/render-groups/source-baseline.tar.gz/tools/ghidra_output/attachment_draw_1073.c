/* 00405980 FUN_00405980 */

void __thiscall FUN_00405980(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  uint *puVar6;
  int local_14;
  
  piVar1 = (int *)DAT_00729668[1];
  piVar2 = (int *)*DAT_00729668;
  piVar3 = (int *)DAT_00729668[2];
  piVar4 = (int *)DAT_00729668[3];
  local_14 = 0;
  puVar6 = param_1;
  if (0 < (int)param_1[0xc0]) {
    do {
      if (((char)param_3 == '\0') || ((char)puVar6[0xb] == '\0')) {
        switch(puVar6[1]) {
        case 0:
          uVar5 = *puVar6;
          if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar2[2])) &&
             (*(uint *)((uVar5 & 0xffff) * 0x2c + *piVar2 + 0x28) == uVar5)) {
            FUN_00522a10();
          }
          break;
        case 1:
          uVar5 = *puVar6;
          if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar1[2])) &&
             (*(uint *)((uVar5 & 0xffff) * 0xec + *piVar1 + 0xe8) == uVar5)) {
            FUN_00526690(param_2);
          }
          break;
        case 2:
          uVar5 = *puVar6;
          if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar3[2])) &&
             (*(uint *)((uVar5 & 0xffff) * 0xa0 + *piVar3 + 0x9c) == uVar5)) {
            FUN_00477490();
          }
          break;
        case 3:
          uVar5 = *puVar6;
          if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar4[2])) &&
             (*(uint *)((uVar5 & 0xffff) * 0x30c + *piVar4 + 0x308) == uVar5)) {
            FUN_00405980(param_2,param_3);
          }
        }
      }
      local_14 = local_14 + 1;
      puVar6 = puVar6 + 0xc;
    } while (local_14 < (int)param_1[0xc0]);
  }
  return;
}



/* 00405c30 FUN_00405c30 */

void __fastcall FUN_00405c30(uint *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint *puVar8;
  
  piVar1 = (int *)DAT_00729668[1];
  piVar2 = (int *)*DAT_00729668;
  piVar3 = (int *)DAT_00729668[2];
  piVar4 = (int *)DAT_00729668[3];
  iVar7 = 0;
  puVar8 = param_1;
  if ((int)param_1[0xc0] < 1) {
    param_1[0xc0] = 0;
    *(undefined1 *)(param_1 + 0xc1) = 1;
    return;
  }
  do {
    switch(puVar8[1]) {
    case 0:
      uVar5 = *puVar8;
      if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar2[2])) &&
         (iVar6 = (uVar5 & 0xffff) * 0x2c + *piVar2, *(uint *)(iVar6 + 0x28) == uVar5)) {
        FUN_00520770(iVar6);
      }
      break;
    case 1:
      uVar5 = *puVar8;
      if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar1[2])) &&
         (iVar6 = (uVar5 & 0xffff) * 0xec + *piVar1, *(uint *)(iVar6 + 0xe8) == uVar5)) {
        *(undefined1 *)(iVar6 + 0xa4) = 1;
      }
      break;
    case 2:
      uVar5 = *puVar8;
      if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar3[2])) &&
         (*(uint *)((uVar5 & 0xffff) * 0xa0 + *piVar3 + 0x9c) == uVar5)) {
        FUN_00477b10();
      }
      break;
    case 3:
      uVar5 = *puVar8;
      if (((uVar5 != 0) && ((uVar5 & 0xffff) < (uint)piVar4[2])) &&
         (*(uint *)((uVar5 & 0xffff) * 0x30c + *piVar4 + 0x308) == uVar5)) {
        FUN_00405c30();
      }
    }
    *puVar8 = 0;
    iVar7 = iVar7 + 1;
    puVar8 = puVar8 + 0xc;
  } while (iVar7 < (int)param_1[0xc0]);
  param_1[0xc0] = 0;
  *(undefined1 *)(param_1 + 0xc1) = 1;
  return;
}



/* 00405d00 FUN_00405d00 */

void FUN_00405d00(void)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *unaff_EBX;
  int unaff_EBP;
  uint *unaff_ESI;
  uint *puVar4;
  int unaff_EDI;
  int *in_stack_00000010;
  int *in_stack_00000014;
  int *in_stack_00000018;
  
  do {
    FUN_00477b10();
    puVar4 = unaff_ESI;
switchD_00405c80_default:
    *puVar4 = 0;
    unaff_EBP = unaff_EBP + 1;
    unaff_ESI = puVar4 + 0xc;
    if (*(int *)(unaff_EDI + 0x300) <= unaff_EBP) {
      *(undefined4 *)(unaff_EDI + 0x300) = 0;
      *(undefined1 *)(unaff_EDI + 0x304) = 1;
      return;
    }
    puVar1 = puVar4 + 0xd;
    puVar4 = unaff_ESI;
    switch(*puVar1) {
    case 0:
      uVar2 = *unaff_ESI;
      if (((uVar2 != 0) && ((uVar2 & 0xffff) < (uint)unaff_EBX[2])) &&
         (iVar3 = (uVar2 & 0xffff) * 0x2c + *unaff_EBX, *(uint *)(iVar3 + 0x28) == uVar2)) {
        FUN_00520770(iVar3);
      }
      goto switchD_00405c80_default;
    case 1:
      uVar2 = *unaff_ESI;
      if (((uVar2 != 0) && ((uVar2 & 0xffff) < (uint)in_stack_00000018[2])) &&
         (iVar3 = (uVar2 & 0xffff) * 0xec + *in_stack_00000018, *(uint *)(iVar3 + 0xe8) == uVar2)) {
        *(undefined1 *)(iVar3 + 0xa4) = 1;
      }
      goto switchD_00405c80_default;
    case 2:
      uVar2 = *unaff_ESI;
      if (((uVar2 == 0) || ((uint)in_stack_00000010[2] <= (uVar2 & 0xffff))) ||
         (*(uint *)((uVar2 & 0xffff) * 0xa0 + *in_stack_00000010 + 0x9c) != uVar2))
      goto switchD_00405c80_default;
      break;
    case 3:
      uVar2 = *unaff_ESI;
      if (((uVar2 != 0) && ((uVar2 & 0xffff) < (uint)in_stack_00000014[2])) &&
         (*(uint *)((uVar2 & 0xffff) * 0x30c + *in_stack_00000014 + 0x308) == uVar2)) {
        FUN_00405c30();
      }
    default:
      goto switchD_00405c80_default;
    }
  } while( true );
}



