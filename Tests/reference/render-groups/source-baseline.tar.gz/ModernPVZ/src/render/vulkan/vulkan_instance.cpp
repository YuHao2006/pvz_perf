#include "pvz/render/vulkan/vulkan_instance.hpp"

#include <vulkan/vulkan.h>

#include <algorithm>
#include <stdexcept>
#include <utility>
#include <vector>

namespace pvz::render::vulkan {

struct VulkanInstance::Implementation {
    VkInstance instance{VK_NULL_HANDLE};
    std::uint32_t loader_api_version{VK_API_VERSION_1_0};
    std::uint32_t instance_api_version{VK_API_VERSION_1_0};
    std::vector<PhysicalDeviceInfo> physical_devices;

    ~Implementation()
    {
        if (instance != VK_NULL_HANDLE)
            vkDestroyInstance(instance, nullptr);
    }
};

VulkanInstance::VulkanInstance()
    : implementation_(std::make_unique<Implementation>())
{
    const auto enumerate_instance_version = reinterpret_cast<PFN_vkEnumerateInstanceVersion>(
        vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion"));
    if (enumerate_instance_version != nullptr &&
        enumerate_instance_version(&implementation_->loader_api_version) != VK_SUCCESS)
        throw std::runtime_error("vkEnumerateInstanceVersion failed");

    implementation_->instance_api_version = std::min(
        implementation_->loader_api_version,
        static_cast<std::uint32_t>(VK_API_VERSION_1_4));

    VkApplicationInfo application_info{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    application_info.pApplicationName = "Modern PvZ";
    application_info.applicationVersion = VK_MAKE_API_VERSION(0, 0, 1, 0);
    application_info.pEngineName = "ModernPVZ";
    application_info.engineVersion = VK_MAKE_API_VERSION(0, 0, 1, 0);
    application_info.apiVersion = implementation_->instance_api_version;

    VkInstanceCreateInfo create_info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    create_info.pApplicationInfo = &application_info;
    const auto create_result = vkCreateInstance(&create_info, nullptr, &implementation_->instance);
    if (create_result != VK_SUCCESS)
        throw std::runtime_error("vkCreateInstance failed with error " + std::to_string(create_result));

    std::uint32_t device_count = 0;
    auto result = vkEnumeratePhysicalDevices(implementation_->instance, &device_count, nullptr);
    if (result != VK_SUCCESS)
        throw std::runtime_error("vkEnumeratePhysicalDevices count query failed");

    std::vector<VkPhysicalDevice> devices(device_count);
    if (device_count != 0) {
        result = vkEnumeratePhysicalDevices(implementation_->instance, &device_count, devices.data());
        if (result != VK_SUCCESS && result != VK_INCOMPLETE)
            throw std::runtime_error("vkEnumeratePhysicalDevices failed");
        devices.resize(device_count);
    }

    implementation_->physical_devices.reserve(devices.size());
    for (const auto device : devices) {
        VkPhysicalDeviceProperties properties{};
        vkGetPhysicalDeviceProperties(device, &properties);
        implementation_->physical_devices.push_back(PhysicalDeviceInfo{
            properties.deviceName,
            properties.apiVersion,
            properties.vendorID,
            properties.deviceID,
            static_cast<std::uint32_t>(properties.deviceType),
            properties.limits.maxImageDimension2D,
        });
    }
}

VulkanInstance::~VulkanInstance() = default;

VulkanInstance::VulkanInstance(VulkanInstance&&) noexcept = default;
VulkanInstance& VulkanInstance::operator=(VulkanInstance&&) noexcept = default;

std::uint32_t VulkanInstance::loader_api_version() const noexcept
{
    return implementation_->loader_api_version;
}

std::uint32_t VulkanInstance::instance_api_version() const noexcept
{
    return implementation_->instance_api_version;
}

const std::vector<PhysicalDeviceInfo>& VulkanInstance::physical_devices() const noexcept
{
    return implementation_->physical_devices;
}

} // namespace pvz::render::vulkan
