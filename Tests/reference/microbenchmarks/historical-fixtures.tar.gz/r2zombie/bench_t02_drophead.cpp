// bench_t02 — kDropHeadParticleImage 34 -> Zombie::DropHead 粒子段（事件）
#include "zb_common.h"
#define TOD_ASSERT(x) ((void)0)

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::DropHead_A(unsigned int theDamageFlags)
{
    if (!CanLoseBodyParts() || !mHasHead)
        return;

    if (mButteredCounter > 0)
    {
        mButteredCounter = 0;
        UpdateAnimSpeed();
    }

    mHasHead = false;
    SetupReanimForLostHead();
    if (TestBit(theDamageFlags, DamageFlags::DAMAGE_DOESNT_LEAVE_BODY))
    {
        return;
    }

    if (Zombie::IsZombotany(mZombieType))
    {
        mApp->ReanimationGet(mSpecialHeadReanimID)->ReanimationDie();
        mSpecialHeadReanimID = ReanimationID::REANIMATIONID_NULL;
        return;
    }

    int aRenderOrder = mRenderOrder + 1;
    ZombieDrawPosition aDrawPos;
    GetDrawPos(aDrawPos);
    float aPosX = mPosX + aDrawPos.mImageOffsetX + aDrawPos.mHeadX + 11.0f;
    float aPosY = mPosY + aDrawPos.mImageOffsetY + aDrawPos.mHeadY + aDrawPos.mBodyY + 21.0f;
    if (mBodyReanimID != ReanimationID::REANIMATIONID_NULL)
    {
        GetTrackPosition(ReanimTrackId::anim_head1, aPosX, aPosY);
    }

    ParticleEffect aEffect = ParticleEffect::PARTICLE_ZOMBIE_HEAD;
    if (mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED)
    {
        aEffect = ParticleEffect::PARTICLE_MOWERED_ZOMBIE_HEAD;
    }
    else if (mInPool)
    {
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_HEAD_POOL;
    }
    if (mZombieType == ZombieType::ZOMBIE_DANCER)
    {
        aRenderOrder = mRenderOrder - 1;
    }
    if (mZombieType == ZombieType::ZOMBIE_NEWSPAPER)
    {
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_NEWSPAPER_HEAD;
    }
    else if (mZombieType == ZombieType::ZOMBIE_POGO)
    {
        PogoBreak(theDamageFlags);
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_POGO_HEAD;
    }
    else if (mZombieType == ZombieType::ZOMBIE_BALLOON)
    {
        ReanimShowRange(ReanimTrackRanges::anim_hat, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::hat, RENDER_GROUP_HIDDEN);
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_BALLOON_HEAD;
    }
    else if (mZombieType == ZombieType::ZOMBIE_POLEVAULTER)
    {
        DropPole();
    }
    else if (mZombieType == ZombieType::ZOMBIE_FLAG ||
             mZombieType == ZombieType::ZOMBIE_ZOMBATAR)
    {
        DropFlag();
    }

    TodParticleSystem* aParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, aEffect);
    OverrideParticleColor(aParticle);
    OverrideParticleScale(aParticle);
    if (aParticle)
    {
        if (mZombieType == ZombieType::ZOMBIE_DANCER)
        {
            // @Patoke: added new assets
            ReanimShowRange(ReanimTrackRanges::Zombie_disco_chops, RENDER_GROUP_HIDDEN);
            ReanimShowRange(ReanimTrackRanges::Zombie_disco_glasses, RENDER_GROUP_HIDDEN);
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEDANCERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_BACKUP_DANCER)
        {
            // @Patoke: added new assets
            ReanimShowRange(ReanimTrackRanges::Zombie_disco_chops, RENDER_GROUP_HIDDEN);
            ReanimShowRange(ReanimTrackRanges::Zombie_backup_stash, RENDER_GROUP_HIDDEN);
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEBACKUPDANCERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_BOBSLED)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEBOBSLEDHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_LADDER)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIELADDERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_IMP)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEIMPHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_FOOTBALL)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEFOOTBALLHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_POLEVAULTER)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEPOLEVAULTERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_SNORKEL)
        {
            aParticle->OverrideImage(nullptr, IMAGE_REANIM_ZOMBIE_SNORKLE_HEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_DIGGER)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEDIGGERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEDOLPHINRIDERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_YETI)
        {
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEYETIHEAD);
        }
    }

    Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
    if (mBoard->mMustacheMode && aBodyReanim->TrackExists(ReanimTrackId::Zombie_mustache))
    {
        ReanimShowRange(ReanimTrackRanges::Zombie_mustache, RENDER_GROUP_HIDDEN);

        TodParticleSystem* aMustacheParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, ParticleEffect::PARTICLE_ZOMBIE_MUSTACHE);
        OverrideParticleColor(aMustacheParticle);
        OverrideParticleScale(aMustacheParticle);

        Image* aMustacheImage = aBodyReanim->GetImageOverride(ReanimTrackId::Zombie_mustache);
        if (aMustacheParticle && aMustacheImage)
        {
            aMustacheParticle->OverrideImage(nullptr, aMustacheImage);
        }
    }
    if (mBoard->mFutureMode)
    {
        Image* aHeadImage = aBodyReanim->GetImageOverride(ReanimTrackId::anim_head1);
        int aFrame = -1;
        if (aHeadImage)
        {
            if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES1)
            {
                aFrame = 0;
            }
            else if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES2)
            {
                aFrame = 1;
            }
            else if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES3)
            {
                aFrame = 2;
            }
            else if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES4)
            {
                aFrame = 3;
            }
        }

        if (aFrame != -1)
        {
            TodParticleSystem* aSunglassParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, ParticleEffect::PARTICLE_ZOMBIE_SUNGLASS);
            OverrideParticleColor(aSunglassParticle);
            OverrideParticleScale(aSunglassParticle);
            if (aSunglassParticle)
            {
                aSunglassParticle->OverrideFrame(nullptr, aFrame);
            }
        }
    }
    if (mBoard->mPinataMode && mZombiePhase != ZombiePhase::PHASE_ZOMBIE_MOWERED)
    {
        TodParticleSystem* aPinataParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, ParticleEffect::PARTICLE_ZOMBIE_PINATA);
        (void)aPinataParticle; // Unused
        OverrideParticleScale(aParticle); // Weird, TODO: test the Pinata Mode
    }

    mApp->PlayFoley(FoleyType::FOLEY_LIMBS_POP);
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::DropHead_B(unsigned int theDamageFlags)
{
    if (!CanLoseBodyParts() || !mHasHead)
        return;

    if (mButteredCounter > 0)
    {
        mButteredCounter = 0;
        UpdateAnimSpeed();
    }

    mHasHead = false;
    SetupReanimForLostHead();
    if (TestBit(theDamageFlags, DamageFlags::DAMAGE_DOESNT_LEAVE_BODY))
    {
        return;
    }

    if (Zombie::IsZombotany(mZombieType))
    {
        mApp->ReanimationGet(mSpecialHeadReanimID)->ReanimationDie();
        mSpecialHeadReanimID = ReanimationID::REANIMATIONID_NULL;
        return;
    }

    int aRenderOrder = mRenderOrder + 1;
    ZombieDrawPosition aDrawPos;
    GetDrawPos(aDrawPos);
    float aPosX = mPosX + aDrawPos.mImageOffsetX + aDrawPos.mHeadX + 11.0f;
    float aPosY = mPosY + aDrawPos.mImageOffsetY + aDrawPos.mHeadY + aDrawPos.mBodyY + 21.0f;
    if (mBodyReanimID != ReanimationID::REANIMATIONID_NULL)
    {
        GetTrackPosition(ReanimTrackId::anim_head1, aPosX, aPosY);
    }

    ParticleEffect aEffect = ParticleEffect::PARTICLE_ZOMBIE_HEAD;
    if (mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED)
    {
        aEffect = ParticleEffect::PARTICLE_MOWERED_ZOMBIE_HEAD;
    }
    else if (mInPool)
    {
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_HEAD_POOL;
    }
    if (mZombieType == ZombieType::ZOMBIE_DANCER)
    {
        aRenderOrder = mRenderOrder - 1;
    }
    if (mZombieType == ZombieType::ZOMBIE_NEWSPAPER)
    {
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_NEWSPAPER_HEAD;
    }
    else if (mZombieType == ZombieType::ZOMBIE_POGO)
    {
        PogoBreak(theDamageFlags);
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_POGO_HEAD;
    }
    else if (mZombieType == ZombieType::ZOMBIE_BALLOON)
    {
        ReanimShowRange(ReanimTrackRanges::anim_hat, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::hat, RENDER_GROUP_HIDDEN);
        aEffect = ParticleEffect::PARTICLE_ZOMBIE_BALLOON_HEAD;
    }
    else if (mZombieType == ZombieType::ZOMBIE_POLEVAULTER)
    {
        DropPole();
    }
    else if (mZombieType == ZombieType::ZOMBIE_FLAG ||
             mZombieType == ZombieType::ZOMBIE_ZOMBATAR)
    {
        DropFlag();
    }

    TodParticleSystem* aParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, aEffect);
    OverrideParticleColor(aParticle);
    OverrideParticleScale(aParticle);
    if (aParticle)
    {
        // B 形态 -> 常量表 kDropHeadParticleImage（仿 kLostArmParticleImage 范式，
        // 原 11 支链合并）：行序 = ZombieType 枚举序 0..33；nullptr = 无 case 槽
        //（default 无覆写）。DANCER/BACKUP_DANCER 两支除 OverrideImage 外还各带
        // 两处 ReanimShowRange 藏轨道动作，异构特例表外保留（表前两 if）。
        static constexpr Image* const* kDropHeadParticleImage[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
            nullptr,  // 0 ZOMBIE_NORMAL（无 case）
            nullptr,  // 1 ZOMBIE_FLAG（无 case）
            nullptr,  // 2 ZOMBIE_TRAFFIC_CONE（无 case）
            &IMAGE_ZOMBIEPOLEVAULTERHEAD,  // 3 ZOMBIE_POLEVAULTER
            nullptr,  // 4 ZOMBIE_PAIL（无 case）
            nullptr,  // 5 ZOMBIE_NEWSPAPER（无 case）
            nullptr,  // 6 ZOMBIE_DOOR（无 case）
            &IMAGE_ZOMBIEFOOTBALLHEAD,  // 7 ZOMBIE_FOOTBALL
            nullptr,  // 8 ZOMBIE_DANCER（特例表外，槽位不可达）
            nullptr,  // 9 ZOMBIE_BACKUP_DANCER（特例表外，槽位不可达）
            nullptr,  // 10 ZOMBIE_DUCKY_TUBE（无 case）
            &IMAGE_REANIM_ZOMBIE_SNORKLE_HEAD,  // 11 ZOMBIE_SNORKEL
            nullptr,  // 12 ZOMBIE_ZAMBONI（无 case）
            &IMAGE_ZOMBIEBOBSLEDHEAD,  // 13 ZOMBIE_BOBSLED
            &IMAGE_ZOMBIEDOLPHINRIDERHEAD,  // 14 ZOMBIE_DOLPHIN_RIDER
            nullptr,  // 15 ZOMBIE_JACK_IN_THE_BOX（无 case）
            nullptr,  // 16 ZOMBIE_BALLOON（无 case）
            &IMAGE_ZOMBIEDIGGERHEAD,  // 17 ZOMBIE_DIGGER
            nullptr,  // 18 ZOMBIE_POGO（无 case）
            &IMAGE_ZOMBIEYETIHEAD,  // 19 ZOMBIE_YETI
            nullptr,  // 20 ZOMBIE_BUNGEE（无 case）
            &IMAGE_ZOMBIELADDERHEAD,  // 21 ZOMBIE_LADDER
            nullptr,  // 22 ZOMBIE_CATAPULT（无 case）
            nullptr,  // 23 ZOMBIE_GARGANTUAR（无 case）
            &IMAGE_ZOMBIEIMPHEAD,  // 24 ZOMBIE_IMP
            nullptr,  // 25 ZOMBIE_BOSS（无 case）
            nullptr,  // 26 ZOMBIE_PEA_HEAD（无 case）
            nullptr,  // 27 ZOMBIE_WALLNUT_HEAD（无 case）
            nullptr,  // 28 ZOMBIE_JALAPENO_HEAD（无 case）
            nullptr,  // 29 ZOMBIE_GATLING_HEAD（无 case）
            nullptr,  // 30 ZOMBIE_SQUASH_HEAD（无 case）
            nullptr,  // 31 ZOMBIE_TALLNUT_HEAD（无 case）
            nullptr,  // 32 ZOMBIE_REDEYE_GARGANTUAR（无 case）
            nullptr,  // 33 ZOMBIE_ZOMBATAR（无 case）
        };
        static_assert(sizeof(kDropHeadParticleImage) / sizeof(kDropHeadParticleImage[0]) ==
            (int)ZombieType::NUM_ZOMBIE_TYPES, "kDropHeadParticleImage 槽位须与 ZombieType 枚举同步");

        if (mZombieType == ZombieType::ZOMBIE_DANCER)
        {
            // @Patoke: added new assets
            ReanimShowRange(ReanimTrackRanges::Zombie_disco_chops, RENDER_GROUP_HIDDEN);
            ReanimShowRange(ReanimTrackRanges::Zombie_disco_glasses, RENDER_GROUP_HIDDEN);
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEDANCERHEAD);
        }
        else if (mZombieType == ZombieType::ZOMBIE_BACKUP_DANCER)
        {
            // @Patoke: added new assets
            ReanimShowRange(ReanimTrackRanges::Zombie_disco_chops, RENDER_GROUP_HIDDEN);
            ReanimShowRange(ReanimTrackRanges::Zombie_backup_stash, RENDER_GROUP_HIDDEN);
            aParticle->OverrideImage(nullptr, IMAGE_ZOMBIEBACKUPDANCERHEAD);
        }
        else if (static_cast<unsigned>(mZombieType) < static_cast<unsigned>(ZombieType::NUM_ZOMBIE_TYPES) &&
            kDropHeadParticleImage[static_cast<unsigned>(mZombieType)] != nullptr)
        {
            aParticle->OverrideImage(nullptr, *kDropHeadParticleImage[static_cast<unsigned>(mZombieType)]);
        }
    }

    Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
    if (mBoard->mMustacheMode && aBodyReanim->TrackExists(ReanimTrackId::Zombie_mustache))
    {
        ReanimShowRange(ReanimTrackRanges::Zombie_mustache, RENDER_GROUP_HIDDEN);

        TodParticleSystem* aMustacheParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, ParticleEffect::PARTICLE_ZOMBIE_MUSTACHE);
        OverrideParticleColor(aMustacheParticle);
        OverrideParticleScale(aMustacheParticle);

        Image* aMustacheImage = aBodyReanim->GetImageOverride(ReanimTrackId::Zombie_mustache);
        if (aMustacheParticle && aMustacheImage)
        {
            aMustacheParticle->OverrideImage(nullptr, aMustacheImage);
        }
    }
    if (mBoard->mFutureMode)
    {
        Image* aHeadImage = aBodyReanim->GetImageOverride(ReanimTrackId::anim_head1);
        int aFrame = -1;
        if (aHeadImage)
        {
            if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES1)
            {
                aFrame = 0;
            }
            else if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES2)
            {
                aFrame = 1;
            }
            else if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES3)
            {
                aFrame = 2;
            }
            else if (aHeadImage == IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES4)
            {
                aFrame = 3;
            }
        }

        if (aFrame != -1)
        {
            TodParticleSystem* aSunglassParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, ParticleEffect::PARTICLE_ZOMBIE_SUNGLASS);
            OverrideParticleColor(aSunglassParticle);
            OverrideParticleScale(aSunglassParticle);
            if (aSunglassParticle)
            {
                aSunglassParticle->OverrideFrame(nullptr, aFrame);
            }
        }
    }
    if (mBoard->mPinataMode && mZombiePhase != ZombiePhase::PHASE_ZOMBIE_MOWERED)
    {
        TodParticleSystem* aPinataParticle = mApp->AddTodParticle(aPosX, aPosY, aRenderOrder, ParticleEffect::PARTICLE_ZOMBIE_PINATA);
        (void)aPinataParticle; // Unused
        OverrideParticleScale(aParticle); // Weird, TODO: test the Pinata Mode
    }

    mApp->PlayFoley(FoleyType::FOLEY_LIMBS_POP);
}

static Zombie g_z;
static void ResetDropHead(const ZBInput& in, unsigned& flags)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    g_z.mZombieType = (ZombieType)(in.a % 34);
    g_z.mZombiePhase = (ZombiePhase)(in.b % 8);
    g_z.mHasHead = (in.c % 16) != 0;
    g_z.mButteredCounter = (int)(in.c % 5) - 1;
    g_z.mInPool = (in.d & 1) != 0;
    g_z.mPosX = (float)(in.b % 700);
    g_z.mPosY = (float)(in.c % 500);
    g_z.mRenderOrder = (int)(in.d % 1000);
    g_z.mBodyReanimID = (in.b % 7 == 0) ? (ReanimationID)0 : (ReanimationID)(1 + in.b % 2);
    g_z.mSpecialHeadReanimID = (ReanimationID)(1 + in.a % 2);
    g_z.mBoard->mMustacheMode = (in.a % 3) == 0;
    g_z.mBoard->mFutureMode = (in.a % 4) == 1;
    g_z.mBoard->mPinataMode = (in.a % 5) == 2;
    g_z.mHasObject = (in.c % 3) == 0;
    flags = (in.d & (1u << 4)) ? 0u : 1u;  // DAMAGE_DOESNT_LEAVE_BODY 位
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            unsigned fl;
            ResetDropHead(g_zb_inputs[i], fl);
            g_z.DropHead_A(fl);
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            unsigned fl;
            ResetDropHead(g_zb_inputs[i], fl);
            g_z.DropHead_B(fl);
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t02_DropHeadParticle", passA, passB);
}
