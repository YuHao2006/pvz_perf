
undefined4 __thiscall FUN_00532300(undefined4 param_1,byte param_2)

{
  FUN_00532320();
  if ((param_2 & 1) != 0) {
    FUN_00699e4a(param_1);
  }
  return param_1;
}

