#include "pvz/render/draw_command_recorder.hpp"
#include "pvz/render/viewport.hpp"
#include "pvz/render/vulkan/vulkan_window_backend.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string_view>
#include <thread>
#include <vector>

namespace {

constexpr std::array<std::uint8_t, 4> kGreen{52, 168, 83, 255};
constexpr std::array<std::uint8_t, 4> kGold{246, 194, 62, 255};

void write_u16(std::ofstream& output, const std::uint16_t value)
{
    output.put(static_cast<char>(value & 0xFFU));
    output.put(static_cast<char>((value >> 8U) & 0xFFU));
}

void write_u32(std::ofstream& output, const std::uint32_t value)
{
    output.put(static_cast<char>(value & 0xFFU));
    output.put(static_cast<char>((value >> 8U) & 0xFFU));
    output.put(static_cast<char>((value >> 16U) & 0xFFU));
    output.put(static_cast<char>((value >> 24U) & 0xFFU));
}

void write_bmp(const std::filesystem::path& path, const pvz::render::vulkan::CapturedFrame& frame)
{
    const std::uint32_t pixel_bytes = frame.extent.width * frame.extent.height * 4;
    std::ofstream output{path, std::ios::binary};
    if (!output)
        throw std::runtime_error("unable to create capture: " + path.string());

    output.write("BM", 2);
    write_u32(output, 14 + 40 + pixel_bytes);
    write_u16(output, 0);
    write_u16(output, 0);
    write_u32(output, 14 + 40);
    write_u32(output, 40);
    write_u32(output, frame.extent.width);
    write_u32(output, frame.extent.height);
    write_u16(output, 1);
    write_u16(output, 32);
    write_u32(output, 0);
    write_u32(output, pixel_bytes);
    write_u32(output, 2835);
    write_u32(output, 2835);
    write_u32(output, 0);
    write_u32(output, 0);

    for (std::uint32_t y = frame.extent.height; y-- > 0;) {
        for (std::uint32_t x = 0; x < frame.extent.width; ++x) {
            const std::size_t offset = (static_cast<std::size_t>(y) * frame.extent.width + x) * 4;
            output.put(static_cast<char>(frame.rgba8[offset + 2]));
            output.put(static_cast<char>(frame.rgba8[offset + 1]));
            output.put(static_cast<char>(frame.rgba8[offset]));
            output.put(static_cast<char>(frame.rgba8[offset + 3]));
        }
    }
    if (!output)
        throw std::runtime_error("unable to write capture: " + path.string());
}

[[nodiscard]] std::uint64_t fnv1a64(const std::vector<std::uint8_t>& bytes)
{
    std::uint64_t hash = 14695981039346656037ULL;
    for (const std::uint8_t byte : bytes) {
        hash ^= byte;
        hash *= 1099511628211ULL;
    }
    return hash;
}

[[nodiscard]] bool near_color(
    const std::vector<std::uint8_t>& pixels,
    const std::size_t offset,
    const std::array<std::uint8_t, 4>& expected,
    const int tolerance)
{
    for (std::size_t channel = 0; channel < 3; ++channel) {
        if (std::abs(static_cast<int>(pixels[offset + channel]) - expected[channel]) > tolerance)
            return false;
    }
    return pixels[offset + 3] >= 250;
}

[[nodiscard]] std::size_t pixel_offset(
    const pvz::render::vulkan::CapturedFrame& frame,
    const std::uint32_t x,
    const std::uint32_t y)
{
    return (static_cast<std::size_t>(y) * frame.extent.width + x) * 4;
}

[[nodiscard]] std::vector<std::byte> make_checker_texture(
    const std::uint32_t width,
    const std::uint32_t height)
{
    std::vector<std::byte> pixels(static_cast<std::size_t>(width) * height * 4);
    for (std::uint32_t y = 0; y < height; ++y) {
        for (std::uint32_t x = 0; x < width; ++x) {
            const auto& color = ((x / 8U) + (y / 8U)) % 2U == 0 ? kGreen : kGold;
            const std::size_t offset = (static_cast<std::size_t>(y) * width + x) * 4;
            for (std::size_t channel = 0; channel < 4; ++channel)
                pixels[offset + channel] = static_cast<std::byte>(color[channel]);
        }
    }
    return pixels;
}

int run(
    const std::filesystem::path& vertex_shader,
    const std::filesystem::path& fragment_shader,
    const std::filesystem::path& output_path,
    const bool visible,
    const bool enable_validation)
{
    pvz::render::vulkan::VulkanWindowConfig config;
    config.title = "Modern PvZ Vulkan frame-packet probe";
    config.pixel_width = 800;
    config.pixel_height = 600;
    config.visible = visible;
    config.enable_validation = enable_validation;
    config.vertical_sync = true;
    pvz::render::vulkan::VulkanWindowBackend backend{
        std::move(config),
        vertex_shader,
        fragment_shader,
    };

    constexpr std::uint32_t texture_width = 64;
    constexpr std::uint32_t texture_height = 64;
    const auto texture_pixels = make_checker_texture(texture_width, texture_height);
    const auto texture = backend.create_texture({
        texture_width,
        texture_height,
        texture_width * 4,
        pvz::render::TextureFormat::rgba8_srgb,
        texture_pixels,
    });

    bool resized_to_wide = false;
    bool resized_to_ultrawide = false;
    bool capture_requested = false;
    std::optional<pvz::render::vulkan::CapturedFrame> capture;
    std::uint64_t frame_index = 0;

    while (backend.poll_events() && backend.presented_frames() < 150 && !capture) {
        const auto presented = backend.presented_frames();
        if (!resized_to_wide && presented >= 40) {
            backend.resize(1068, 600);
            resized_to_wide = true;
        }
        if (!resized_to_ultrawide && presented >= 85) {
            backend.resize(1280, 600);
            resized_to_ultrawide = true;
        }
        if (!capture_requested && presented >= 125) {
            backend.request_capture();
            capture_requested = true;
        }

        const auto pixels = backend.pixel_extent();
        if (pixels.width == 0 || pixels.height == 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }
        const auto transform = pvz::render::ViewportTransform::create(pixels.width, pixels.height);
        const auto logical = transform.logical_extent();
        pvz::render::DrawCommandRecorder recorder{
            frame_index++,
            logical,
            transform.pixel_viewport(),
        };
        recorder.draw_sprite(
            {
                texture,
                {texture_width, texture_height},
                {{0.0, 0.0}, {texture_width * 2.0, texture_height * 2.0}},
            },
            {{0.0, 0.0}, logical},
            pvz::render::pack_rgba8(255, 255, 255, 255),
            pvz::render::BlendMode::opaque,
            {},
            {
                pvz::render::TextureFilter::nearest,
                pvz::render::TextureAddressMode::repeat,
                pvz::render::TextureAddressMode::repeat,
            });
        backend.submit(recorder.frame());
        capture = backend.take_capture();
    }

    backend.wait_idle();
    backend.destroy_texture(texture);
    if (!capture)
        throw std::runtime_error("the Vulkan window probe did not capture a presented frame");
    if (capture->extent.width != 1280 || capture->extent.height != 600)
        throw std::runtime_error("captured frame did not use the final resized swapchain extent");

    std::size_t green_pixels = 0;
    std::size_t gold_pixels = 0;
    std::size_t dark_pixels = 0;
    for (std::size_t offset = 0; offset < capture->rgba8.size(); offset += 4) {
        if (near_color(capture->rgba8, offset, kGreen, 2))
            ++green_pixels;
        else if (near_color(capture->rgba8, offset, kGold, 2))
            ++gold_pixels;
        if (capture->rgba8[offset] < 80 && capture->rgba8[offset + 1] < 80 && capture->rgba8[offset + 2] < 80)
            ++dark_pixels;
    }

    const std::size_t total_pixels = static_cast<std::size_t>(capture->extent.width) * capture->extent.height;
    if (green_pixels < total_pixels / 5 || gold_pixels < total_pixels / 5)
        throw std::runtime_error("captured frame is missing the checkerboard texture content");
    if (dark_pixels < 100'000)
        throw std::runtime_error("captured ultrawide frame is missing its safe side bars");
    if (!near_color(capture->rgba8, pixel_offset(*capture, 110, 10), kGreen, 2) ||
        !near_color(capture->rgba8, pixel_offset(*capture, 1169, 10), kGold, 2) ||
        !near_color(capture->rgba8, pixel_offset(*capture, 110, 589), kGold, 2) ||
        !near_color(capture->rgba8, pixel_offset(*capture, 1169, 589), kGreen, 2))
        throw std::runtime_error("captured texture orientation or viewport mapping is incorrect");
    if (capture->rgba8[pixel_offset(*capture, 0, 300)] >= 80 ||
        capture->rgba8[pixel_offset(*capture, 1279, 300)] >= 80)
        throw std::runtime_error("captured frame does not preserve both ultrawide side bars");
    if (backend.swapchain_recreations() < 3)
        throw std::runtime_error("window resizes did not rebuild the Vulkan swapchain");
    if (backend.validation_error_count() != 0)
        throw std::runtime_error("Vulkan validation reported errors");

    write_bmp(output_path, *capture);
    std::cout << "backend=" << backend.capabilities().name
              << "\nsize=" << capture->extent.width << 'x' << capture->extent.height
              << "\npresented_frames=" << backend.presented_frames()
              << "\nswapchain_recreations=" << backend.swapchain_recreations()
              << "\nvalidation=" << (enable_validation ? "on" : "off")
              << "\nvalidation_errors=" << backend.validation_error_count()
              << "\ngreen_pixels=" << green_pixels
              << "\ngold_pixels=" << gold_pixels
              << "\ndark_pixels=" << dark_pixels
              << "\nfnv1a64=0x" << std::hex << fnv1a64(capture->rgba8) << std::dec
              << "\noutput=" << output_path.string() << '\n';
    return 0;
}

} // namespace

int main(const int argc, const char* const argv[])
{
    if (argc < 4 || argc > 6) {
        std::cerr << "usage: pvz_vulkan_window <vertex.spv> <fragment.spv> <output.bmp> "
                     "[--hidden] [--validation]\n";
        return 2;
    }
    bool visible = true;
    bool enable_validation = false;
    for (int index = 4; index < argc; ++index) {
        const std::string_view option{argv[index]};
        if (option == "--hidden")
            visible = false;
        else if (option == "--validation")
            enable_validation = true;
        else {
            std::cerr << "unknown option: " << option << '\n';
            return 2;
        }
    }
    try {
        return run(argv[1], argv[2], argv[3], visible, enable_validation);
    } catch (const std::exception& error) {
        std::cerr << "pvz_vulkan_window: " << error.what() << '\n';
        return 1;
    }
}
