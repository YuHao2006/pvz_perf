
void __fastcall FUN_00531b50(undefined4 param_1)

{
  int iVar1;
  int unaff_ESI;
  
  iVar1 = FUN_00699ed2(0x164,param_1);
  if (iVar1 == 0) {
    iVar1 = 0;
  }
  else {
    iVar1 = FUN_00532930();
  }
  *(int *)(unaff_ESI + 0x188) = iVar1;
  *(undefined4 *)(iVar1 + 4) = 0;
  FUN_005329a0(0,0x21,0,0,0xfffffffd);
  *(float *)(*(int *)(unaff_ESI + 0x188) + 0x2c) =
       (float)(*(int *)(*(int *)(unaff_ESI + 0x194) + 0x48) + *(int *)(unaff_ESI + 0x18c));
  *(float *)(*(int *)(unaff_ESI + 0x188) + 0x30) = (float)*(int *)(unaff_ESI + 400);
  FUN_00531250(*(int *)(unaff_ESI + 0x194) + 0xf14);
  return;
}

