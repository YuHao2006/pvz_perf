#include "pvz/time/fixed_step_clock.hpp"

#include <algorithm>
#include <array>
#include <stdexcept>

namespace pvz::time {
namespace {

constexpr std::int64_t kNanosecondsPerSecond = 1'000'000'000;
constexpr std::array<std::uint32_t, 5> kSupportedRates{100, 200, 400, 500, 1000};

} // namespace

bool StepBatch::is_semantic_tick(const std::uint32_t batch_offset) const noexcept
{
    if (batch_offset >= tick_count || ticks_per_semantic_tick == 0)
        return false;

    return (semantic_phase + batch_offset + 1) % ticks_per_semantic_tick == 0;
}

FixedStepClock::FixedStepClock(ClockConfig config)
    : config_(config),
      tick_interval_(0)
{
    if (!is_supported_simulation_rate(config_.simulation_hz))
        throw std::invalid_argument("unsupported simulation rate");
    if (config_.semantic_hz == 0 || config_.simulation_hz % config_.semantic_hz != 0)
        throw std::invalid_argument("simulation rate must be an integer multiple of semantic rate");
    if (config_.max_steps_per_advance == 0)
        throw std::invalid_argument("max steps per advance must be positive");
    if (config_.max_frame_delta <= std::chrono::nanoseconds::zero())
        throw std::invalid_argument("max frame delta must be positive");

    tick_interval_ = std::chrono::nanoseconds{kNanosecondsPerSecond / config_.simulation_hz};
}

StepBatch FixedStepClock::advance(std::chrono::nanoseconds elapsed)
{
    StepBatch batch;
    batch.first_tick = total_ticks_ + 1;
    batch.ticks_per_semantic_tick = config_.simulation_hz / config_.semantic_hz;
    batch.semantic_phase = semantic_phase_;

    elapsed = std::max(elapsed, std::chrono::nanoseconds::zero());
    const auto accepted_elapsed = std::min(elapsed, config_.max_frame_delta);
    batch.discarded_time = elapsed - accepted_elapsed;
    accumulator_ += accepted_elapsed;

    const auto available_steps = static_cast<std::uint64_t>(accumulator_.count() / tick_interval_.count());
    const auto scheduled_steps = std::min<std::uint64_t>(available_steps, config_.max_steps_per_advance);
    const auto discarded_steps = available_steps - scheduled_steps;

    if (discarded_steps != 0) {
        const auto discarded_backlog = tick_interval_ * static_cast<std::int64_t>(discarded_steps);
        accumulator_ -= discarded_backlog;
        batch.discarded_time += discarded_backlog;
    }

    batch.tick_count = static_cast<std::uint32_t>(scheduled_steps);
    accumulator_ -= tick_interval_ * static_cast<std::int64_t>(scheduled_steps);
    total_ticks_ += scheduled_steps;
    semantic_phase_ = static_cast<std::uint32_t>(
        (semantic_phase_ + scheduled_steps) % batch.ticks_per_semantic_tick);
    total_discarded_time_ += batch.discarded_time;
    batch.interpolation_alpha = static_cast<double>(accumulator_.count()) /
                                static_cast<double>(tick_interval_.count());
    return batch;
}

void FixedStepClock::set_simulation_rate(const std::uint32_t simulation_hz)
{
    if (!is_supported_simulation_rate(simulation_hz))
        throw std::invalid_argument("unsupported simulation rate");
    if (simulation_hz % config_.semantic_hz != 0)
        throw std::invalid_argument("simulation rate must be an integer multiple of semantic rate");
    if (simulation_hz == config_.simulation_hz)
        return;
    if (semantic_phase_ != 0)
        throw std::logic_error("simulation rate changes must occur at a semantic boundary");

    config_.simulation_hz = simulation_hz;
    tick_interval_ = std::chrono::nanoseconds{kNanosecondsPerSecond / config_.simulation_hz};
}

void FixedStepClock::reset() noexcept
{
    accumulator_ = std::chrono::nanoseconds::zero();
    total_discarded_time_ = std::chrono::nanoseconds::zero();
    total_ticks_ = 0;
    semantic_phase_ = 0;
}

const ClockConfig& FixedStepClock::config() const noexcept
{
    return config_;
}

std::chrono::nanoseconds FixedStepClock::tick_interval() const noexcept
{
    return tick_interval_;
}

std::uint64_t FixedStepClock::total_ticks() const noexcept
{
    return total_ticks_;
}

std::chrono::nanoseconds FixedStepClock::total_discarded_time() const noexcept
{
    return total_discarded_time_;
}

bool is_supported_simulation_rate(const std::uint32_t hz) noexcept
{
    return std::ranges::find(kSupportedRates, hz) != kSupportedRates.end();
}

} // namespace pvz::time
