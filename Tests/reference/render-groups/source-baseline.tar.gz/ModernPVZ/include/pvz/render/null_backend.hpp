#pragma once

#include "pvz/render/backend.hpp"

#include <cstdint>
#include <unordered_set>

namespace pvz::render {

class NullRenderBackend final : public IRenderBackend {
public:
    NullRenderBackend();

    [[nodiscard]] const BackendCapabilities& capabilities() const noexcept override;
    [[nodiscard]] TextureHandle create_texture(const TextureUpload& upload) override;
    void update_texture(TextureHandle texture, const TextureUpload& upload) override;
    void destroy_texture(TextureHandle texture) override;
    void resize(std::uint32_t pixel_width, std::uint32_t pixel_height) override;
    void submit(const FramePacket& frame) override;
    void wait_idle() override;

    [[nodiscard]] std::uint64_t submitted_frames() const noexcept;
    [[nodiscard]] std::uint64_t submitted_batches() const noexcept;

private:
    BackendCapabilities capabilities_;
    std::uint32_t pixel_width_{0};
    std::uint32_t pixel_height_{0};
    std::uint64_t submitted_frames_{0};
    std::uint64_t submitted_batches_{0};
    std::uint32_t next_texture_handle_{1};
    std::unordered_set<std::uint32_t> textures_;
};

} // namespace pvz::render
