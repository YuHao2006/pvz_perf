// b18_almanac.cpp — kAlmanacIconOffset + kAlmanacPortraitOffset -> AlmanacDialog::DrawZombies（图鉴每帧）
// FormA = 34dfeb8f^ 双 switch（逐字）；FormB = HEAD 34×2 双常量表（逐字）。
// 截断说明：两侧一致截断于 ZOMBIECARD 绘制（其后名称/描述排版与两表无关，属同一函数尾）。
#include "r3_entities.h"

// ==================== FormA：34dfeb8f^ switch 逐字（图标段+立绘段） ====================
__declspec(noinline) void AlmanacDialog::DrawZombies_A(Graphics* g)
{
    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEBACK, 0, 0);
    TodDrawString(g, gStr.SUBURBAN_ALMANAC_ZOMBIES, BOARD_WIDTH / 2, 54, Sexy::FONT_DWARVENTODCRAFT24, Color(0, 196, 0), DS_ALIGN_CENTER);

    ZombieType aZombieMouseOn = ZombieHitTest(mApp->mWidgetManager->mLastMouseX, mApp->mWidgetManager->mLastMouseY);
    for (int i = 0; i < NUM_ALMANAC_ZOMBIES; i++)
    {
        ZombieType aZombieType = GetZombieType(i);
        int aPosX, aPosY;
        GetZombiePosition(aZombieType, aPosX, aPosY);
        if (aZombieType != ZombieType::ZOMBIE_INVALID)
        {
            if (!ZombieIsShown(aZombieType))
                g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEBLANK, aPosX, aPosY);
            else
            {
                g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW, aPosX, aPosY);
                if (aZombieType == aZombieMouseOn)
                {
                    g->SetDrawMode(Graphics::DRAWMODE_ADDITIVE);
                    g->SetColor(Color(255, 255, 255, 48));
                    g->SetColorizeImages(true);
                    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW, aPosX, aPosY);
                    g->SetDrawMode(Graphics::DRAWMODE_NORMAL);
                    g->SetColorizeImages(false);
                }

                ZombieType aZombieTypeToDraw = aZombieType;
                Graphics aZombieGraphics = Graphics(*g);
                aZombieGraphics.SetClipRect(aPosX + 2, aPosY + 2, 72, 72);
                aZombieGraphics.Translate(aPosX + 1, aPosY - 6);
                aZombieGraphics.mScaleX = 0.5f;
                aZombieGraphics.mScaleY = 0.5f;
                // GOTY 1073 icon offsets; Backup Dancer is -5, not Portable's -4.
                switch (aZombieType)
                {
                case ZombieType::ZOMBIE_POLEVAULTER:
                    aZombieGraphics.TranslateF(2, -3);
                    aZombieTypeToDraw = ZombieType::ZOMBIE_CACHED_POLEVAULTER_WITH_POLE;		break;
                case ZombieType::ZOMBIE_FLAG:			aZombieGraphics.TranslateF(2, 10);		break;
                case ZombieType::ZOMBIE_TRAFFIC_CONE:	aZombieGraphics.TranslateF(0, 12);		break;
                case ZombieType::ZOMBIE_PAIL:			aZombieGraphics.TranslateF(0, 9);		break;
                case ZombieType::ZOMBIE_FOOTBALL:		aZombieGraphics.TranslateF(-15, -1);	break;
                case ZombieType::ZOMBIE_ZAMBONI:		aZombieGraphics.TranslateF(0, 3);		break;
                case ZombieType::ZOMBIE_DOLPHIN_RIDER:	aZombieGraphics.TranslateF(-2, -10);	break;
                case ZombieType::ZOMBIE_POGO:			aZombieGraphics.TranslateF(0, -3);		break;
                case ZombieType::ZOMBIE_GARGANTUAR:		aZombieGraphics.TranslateF(15, 17);		break;
                case ZombieType::ZOMBIE_IMP:			aZombieGraphics.TranslateF(-8, -7);		break;
                case ZombieType::ZOMBIE_BUNGEE:			aZombieGraphics.TranslateF(-4, 3);		break;
                case ZombieType::ZOMBIE_DANCER:			aZombieGraphics.TranslateF(0, 15);		break;
                case ZombieType::ZOMBIE_BACKUP_DANCER:	aZombieGraphics.TranslateF(-5, 20);	break;
                case ZombieType::ZOMBIE_SNORKEL:		aZombieGraphics.TranslateF(-10, 0);	break;
                case ZombieType::ZOMBIE_YETI:			aZombieGraphics.TranslateF(0, 4);		break;
                case ZombieType::ZOMBIE_CATAPULT:		aZombieGraphics.TranslateF(-24, -1);	break;
                case ZombieType::ZOMBIE_BOBSLED:		aZombieGraphics.TranslateF(0, -8);		break;
                case ZombieType::ZOMBIE_LADDER:			aZombieGraphics.TranslateF(0, -3);		break;
                default: break;
                }
                if (ZombieHasSilhouette(aZombieType))
                {
                    aZombieGraphics.SetColor(Color(0, 0, 0, 40));
                    aZombieGraphics.SetColorizeImages(true);
                }
                g_reanimCache.DrawCachedZombie(&aZombieGraphics, 0, 0, aZombieTypeToDraw);
                aZombieGraphics.SetColorizeImages(false);

                g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW2, aPosX, aPosY);
                if (aZombieType == aZombieMouseOn)
                {
                    g->SetDrawMode(Graphics::DRAWMODE_ADDITIVE);
                    g->SetColor(Color(255, 255, 255, 48));
                    g->SetColorizeImages(true);
                    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW2, aPosX, aPosY);
                    g->SetDrawMode(Graphics::DRAWMODE_NORMAL);
                    g->SetColorizeImages(false);
                }
            }
        }
    }

    g->DrawImage(mZombie->mZombieType == ZombieType::ZOMBIE_ZAMBONI || mZombie->mZombieType == ZombieType::ZOMBIE_BOBSLED ?
        Sexy::IMAGE_ALMANAC_GROUNDICE : Sexy::IMAGE_ALMANAC_GROUNDDAY, 518, 110);
    if (mZombie && !ZombieHasSilhouette(mZombie->mZombieType))
    {
        Graphics aZombieGraphics = Graphics(*g);
        mZombie->BeginDraw(&aZombieGraphics);
        aZombieGraphics.SetClipRect(-42, -51, 197, 187);
        // @Patoke todo: add new functionality
        switch (mZombie->mZombieType)
        {
        case ZombieType::ZOMBIE_ZAMBONI:		aZombieGraphics.TranslateF(-30, 5);		break;
        case ZombieType::ZOMBIE_GARGANTUAR:		aZombieGraphics.TranslateF(0, 40);		break;
        case ZombieType::ZOMBIE_FOOTBALL:		aZombieGraphics.TranslateF(-10, 0);		break;
        case ZombieType::ZOMBIE_BALLOON:		aZombieGraphics.TranslateF(0, -20);		break;
        case ZombieType::ZOMBIE_BUNGEE:			aZombieGraphics.TranslateF(15, 0);		break;
        case ZombieType::ZOMBIE_CATAPULT:		aZombieGraphics.TranslateF(-10, 0);		break;
        case ZombieType::ZOMBIE_BOSS:			aZombieGraphics.TranslateF(-540, -175);	break;
        default: break;
        }
        if (mZombie->mZombieType != ZombieType::ZOMBIE_BUNGEE && mZombie->mZombieType != ZombieType::ZOMBIE_BOSS &&
            mZombie->mZombieType != ZombieType::ZOMBIE_ZAMBONI && mZombie->mZombieType != ZombieType::ZOMBIE_CATAPULT)
            mZombie->DrawShadow(&aZombieGraphics);
        mZombie->Draw(&aZombieGraphics);
    }
    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIECARD, 455, 78);
}

// ==================== FormB：HEAD 双常量表（逐字） ====================
namespace
{
// kAlmanacIconOffset：生成器解析原 switch 生成（逐槽对拍 0 差异）；
// 哨兵 0x7FFFFFFF, 0x7FFFFFFF = 无 case 槽（default 无操作）。
constexpr const int kAlmanacIconOffset[(int)ZombieType::NUM_ZOMBIE_TYPES][2] = {
		0x7FFFFFFF, 0x7FFFFFFF,  // 0 ZOMBIE_NORMAL（无 case）
		{2, 10},  // 1 ZOMBIE_FLAG
		{0, 12},  // 2 ZOMBIE_TRAFFIC_CONE
		0x7FFFFFFF, 0x7FFFFFFF,  // 3 ZOMBIE_POLEVAULTER（无 case）
		{0, 9},  // 4 ZOMBIE_PAIL
		0x7FFFFFFF, 0x7FFFFFFF,  // 5 ZOMBIE_NEWSPAPER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 6 ZOMBIE_DOOR（无 case）
		{-15, -1},  // 7 ZOMBIE_FOOTBALL
		{0, 15},  // 8 ZOMBIE_DANCER
		{-5, 20},  // 9 ZOMBIE_BACKUP_DANCER
		0x7FFFFFFF, 0x7FFFFFFF,  // 10 ZOMBIE_DUCKY_TUBE（无 case）
		{-10, 0},  // 11 ZOMBIE_SNORKEL
		{0, 3},  // 12 ZOMBIE_ZAMBONI
		{0, -8},  // 13 ZOMBIE_BOBSLED
		{-2, -10},  // 14 ZOMBIE_DOLPHIN_RIDER
		0x7FFFFFFF, 0x7FFFFFFF,  // 15 ZOMBIE_JACK_IN_THE_BOX（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 16 ZOMBIE_BALLOON（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 17 ZOMBIE_DIGGER（无 case）
		{0, -3},  // 18 ZOMBIE_POGO
		{0, 4},  // 19 ZOMBIE_YETI
		{-4, 3},  // 20 ZOMBIE_BUNGEE
		{0, -3},  // 21 ZOMBIE_LADDER
		{-24, -1},  // 22 ZOMBIE_CATAPULT
		{15, 17},  // 23 ZOMBIE_GARGANTUAR
		{-8, -7},  // 24 ZOMBIE_IMP
		0x7FFFFFFF, 0x7FFFFFFF,  // 25 ZOMBIE_BOSS（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 26 ZOMBIE_PEA_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 27 ZOMBIE_WALLNUT_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 28 ZOMBIE_JALAPENO_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 29 ZOMBIE_GATLING_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 30 ZOMBIE_SQUASH_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 31 ZOMBIE_TALLNUT_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 32 ZOMBIE_REDEYE_GARGANTUAR（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 33 ZOMBIE_ZOMBATAR（无 case）
};
static_assert(sizeof(kAlmanacIconOffset) / sizeof(kAlmanacIconOffset[0]) ==
    (int)ZombieType::NUM_ZOMBIE_TYPES, "槽位须与 ZombieType 枚举同步");

// kAlmanacPortraitOffset：生成器解析原 switch 生成（逐槽对拍 0 差异）；
// 哨兵 0x7FFFFFFF, 0x7FFFFFFF = 无 case 槽（default 无操作）。
constexpr const int kAlmanacPortraitOffset[(int)ZombieType::NUM_ZOMBIE_TYPES][2] = {
		0x7FFFFFFF, 0x7FFFFFFF,  // 0 ZOMBIE_NORMAL（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 1 ZOMBIE_FLAG（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 2 ZOMBIE_TRAFFIC_CONE（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 3 ZOMBIE_POLEVAULTER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 4 ZOMBIE_PAIL（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 5 ZOMBIE_NEWSPAPER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 6 ZOMBIE_DOOR（无 case）
		{-10, 0},  // 7 ZOMBIE_FOOTBALL
		0x7FFFFFFF, 0x7FFFFFFF,  // 8 ZOMBIE_DANCER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 9 ZOMBIE_BACKUP_DANCER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 10 ZOMBIE_DUCKY_TUBE（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 11 ZOMBIE_SNORKEL（无 case）
		{-30, 5},  // 12 ZOMBIE_ZAMBONI
		0x7FFFFFFF, 0x7FFFFFFF,  // 13 ZOMBIE_BOBSLED（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 14 ZOMBIE_DOLPHIN_RIDER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 15 ZOMBIE_JACK_IN_THE_BOX（无 case）
		{0, -20},  // 16 ZOMBIE_BALLOON
		0x7FFFFFFF, 0x7FFFFFFF,  // 17 ZOMBIE_DIGGER（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 18 ZOMBIE_POGO（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 19 ZOMBIE_YETI（无 case）
		{15, 0},  // 20 ZOMBIE_BUNGEE
		0x7FFFFFFF, 0x7FFFFFFF,  // 21 ZOMBIE_LADDER（无 case）
		{-10, 0},  // 22 ZOMBIE_CATAPULT
		{0, 40},  // 23 ZOMBIE_GARGANTUAR
		0x7FFFFFFF, 0x7FFFFFFF,  // 24 ZOMBIE_IMP（无 case）
		{-540, -175},  // 25 ZOMBIE_BOSS
		0x7FFFFFFF, 0x7FFFFFFF,  // 26 ZOMBIE_PEA_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 27 ZOMBIE_WALLNUT_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 28 ZOMBIE_JALAPENO_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 29 ZOMBIE_GATLING_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 30 ZOMBIE_SQUASH_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 31 ZOMBIE_TALLNUT_HEAD（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 32 ZOMBIE_REDEYE_GARGANTUAR（无 case）
		0x7FFFFFFF, 0x7FFFFFFF,  // 33 ZOMBIE_ZOMBATAR（无 case）
};
static_assert(sizeof(kAlmanacPortraitOffset) / sizeof(kAlmanacPortraitOffset[0]) ==
    (int)ZombieType::NUM_ZOMBIE_TYPES, "槽位须与 ZombieType 枚举同步");
}  // namespace

//0x402C00
__declspec(noinline) void AlmanacDialog::DrawZombies_B(Graphics* g)
{
    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEBACK, 0, 0);
    TodDrawString(g, gStr.SUBURBAN_ALMANAC_ZOMBIES, BOARD_WIDTH / 2, 54, Sexy::FONT_DWARVENTODCRAFT24, Color(0, 196, 0), DS_ALIGN_CENTER);

    ZombieType aZombieMouseOn = ZombieHitTest(mApp->mWidgetManager->mLastMouseX, mApp->mWidgetManager->mLastMouseY);
    for (int i = 0; i < NUM_ALMANAC_ZOMBIES; i++)
    {
        ZombieType aZombieType = GetZombieType(i);
        int aPosX, aPosY;
        GetZombiePosition(aZombieType, aPosX, aPosY);
        if (aZombieType != ZombieType::ZOMBIE_INVALID)
        {
            if (!ZombieIsShown(aZombieType))
                g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEBLANK, aPosX, aPosY);
            else
            {
                g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW, aPosX, aPosY);
                if (aZombieType == aZombieMouseOn)
                {
                    g->SetDrawMode(Graphics::DRAWMODE_ADDITIVE);
                    g->SetColor(Color(255, 255, 255, 48));
                    g->SetColorizeImages(true);
                    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW, aPosX, aPosY);
                    g->SetDrawMode(Graphics::DRAWMODE_NORMAL);
                    g->SetColorizeImages(false);
                }

                ZombieType aZombieTypeToDraw = aZombieType;
                Graphics aZombieGraphics = Graphics(*g);
                aZombieGraphics.SetClipRect(aPosX + 2, aPosY + 2, 72, 72);
                aZombieGraphics.Translate(aPosX + 1, aPosY - 6);
                aZombieGraphics.mScaleX = 0.5f;
                aZombieGraphics.mScaleY = 0.5f;
                // GOTY 1073 icon offsets; Backup Dancer is -5, not Portable's -4.
                // B 形态 -> 常量表（见上 kAlmanacIconOffset）；POLEVAULTER
                // 特例（平移+换缓存型）表外。
                if (aZombieType == ZombieType::ZOMBIE_POLEVAULTER)
                {
                    aZombieGraphics.TranslateF(2, -3);
                    aZombieTypeToDraw = ZombieType::ZOMBIE_CACHED_POLEVAULTER_WITH_POLE;
                }
                else if (static_cast<unsigned>(aZombieType) < static_cast<unsigned>(ZombieType::NUM_ZOMBIE_TYPES) && kAlmanacIconOffset[aZombieType][0] != 0x7FFFFFFF)
                {
                    aZombieGraphics.TranslateF(kAlmanacIconOffset[aZombieType][0], kAlmanacIconOffset[aZombieType][1]);
                }

                if (ZombieHasSilhouette(aZombieType))
                {
                    aZombieGraphics.SetColor(Color(0, 0, 0, 40));
                    aZombieGraphics.SetColorizeImages(true);
                }
                g_reanimCache.DrawCachedZombie(&aZombieGraphics, 0, 0, aZombieTypeToDraw);
                aZombieGraphics.SetColorizeImages(false);

                g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW2, aPosX, aPosY);
                if (aZombieType == aZombieMouseOn)
                {
                    g->SetDrawMode(Graphics::DRAWMODE_ADDITIVE);
                    g->SetColor(Color(255, 255, 255, 48));
                    g->SetColorizeImages(true);
                    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIEWINDOW2, aPosX, aPosY);
                    g->SetDrawMode(Graphics::DRAWMODE_NORMAL);
                    g->SetColorizeImages(false);
                }
            }
        }
    }

    g->DrawImage(mZombie->mZombieType == ZombieType::ZOMBIE_ZAMBONI || mZombie->mZombieType == ZombieType::ZOMBIE_BOBSLED ?
        Sexy::IMAGE_ALMANAC_GROUNDICE : Sexy::IMAGE_ALMANAC_GROUNDDAY, 518, 110);
    if (mZombie && !ZombieHasSilhouette(mZombie->mZombieType))
    {
        Graphics aZombieGraphics = Graphics(*g);
        mZombie->BeginDraw(&aZombieGraphics);
        aZombieGraphics.SetClipRect(-42, -51, 197, 187);
        // @Patoke todo: add new functionality
        // B 形态 -> 常量表（见上 kAlmanacPortraitOffset），越界/无 case 槽
        // = 哨兵行，不平移。
        if (static_cast<unsigned>(mZombie->mZombieType) < static_cast<unsigned>(ZombieType::NUM_ZOMBIE_TYPES) && kAlmanacPortraitOffset[mZombie->mZombieType][0] != 0x7FFFFFFF)
        {
            aZombieGraphics.TranslateF(kAlmanacPortraitOffset[mZombie->mZombieType][0], kAlmanacPortraitOffset[mZombie->mZombieType][1]);
        }

        if (mZombie->mZombieType != ZombieType::ZOMBIE_BUNGEE && mZombie->mZombieType != ZombieType::ZOMBIE_BOSS &&
            mZombie->mZombieType != ZombieType::ZOMBIE_ZAMBONI && mZombie->mZombieType != ZombieType::ZOMBIE_CATAPULT)
            mZombie->DrawShadow(&aZombieGraphics);
        mZombie->Draw(&aZombieGraphics);
    }
    g->DrawImage(Sexy::IMAGE_ALMANAC_ZOMBIECARD, 455, 78);
}

// ============================ main ============================
static AlmanacDialog g_almanac;
static LawnApp g_app;
static Board g_board;
static WidgetManager g_wm;
static Graphics g_gfx;
static Zombie g_selZombie;

// Zombie::DrawShadow/Draw 桩（图鉴立绘段消费；两形态同参）
__declspec(noinline) void Zombie::DrawShadow(Graphics* g) { ZSink(RID_Coin_Draw, 51); }
__declspec(noinline) void Zombie::DrawReanim(Graphics* g, const ZombieDrawPosition&, int) { ZSink(RID_Coin_Draw, 53); }
__declspec(noinline) void Zombie::DrawBungeeTarget(Graphics* g) { ZSink(RID_Coin_Draw, 54); }
__declspec(noinline) void Zombie::DrawBossPart(Graphics* g, BossPart p) { ZSink(RID_Coin_Draw, 55, (uint32_t)p); }

int main()
{
    g_almanac.mApp = &g_app;
    g_app.mBoard = &g_board;
    g_app.mWidgetManager = &g_wm;
    g_almanac.mZombie = &g_selZombie;

    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                g_wm.mLastMouseX = (int)(g_inputs[i].a % 800);
                g_wm.mLastMouseY = (int)(g_inputs[i].b % 600);
                g_selZombie.mZombieType = (ZombieType)(g_inputs[i].c % (int)ZombieType::NUM_ZOMBIE_TYPES);
                g_almanac.DrawZombies_A(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_selZombie.mZombieType);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                g_wm.mLastMouseX = (int)(g_inputs[i].a % 800);
                g_wm.mLastMouseY = (int)(g_inputs[i].b % 600);
                g_selZombie.mZombieType = (ZombieType)(g_inputs[i].c % (int)ZombieType::NUM_ZOMBIE_TYPES);
                g_almanac.DrawZombies_B(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_selZombie.mZombieType);
            }
        };
        rc |= R3BenchMain("b18_Almanac_DrawZombies_IconPortrait", reset, pa, pb);
    }
    return rc;
}
