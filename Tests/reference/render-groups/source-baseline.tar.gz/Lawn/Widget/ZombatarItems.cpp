#include "ZombatarItems.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../Sexy.TodLib/Reanimator.h"
#include "../../Sexy.TodLib/TodCommon.h"
#include "../../Sexy.TodLib/TodStringFile.h"
#include "../../SexyAppFramework/graphics/MemoryImage.h"
#include "../../SexyAppFramework/imagelib/ImageLib.h"
#include "GameSelector.h"
#include "widget/Dialog.h"
#include "widget/WidgetManager.h"

#include <ShlObj.h>
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace
{
const Color gZombatarColors[] = {
	{ 134, 147, 122, 255 }, { 79, 135, 94, 255 }, { 127, 135, 94, 255 },
	{ 120, 130, 50, 255 }, { 156, 163, 105, 255 }, { 96, 151, 11, 255 },
	{ 147, 184, 77, 255 }, { 82, 143, 54, 255 }, { 121, 168, 99, 255 },
	{ 65, 156, 74, 255 }, { 107, 178, 114, 255 }, { 104, 121, 90, 255 },
	{ 151, 33, 33, 255 }, { 199, 53, 53, 255 }, { 220, 112, 47, 255 },
	{ 251, 251, 172, 255 }, { 240, 210, 87, 255 }, { 165, 126, 65, 255 },
	{ 106, 72, 32, 255 }, { 72, 35, 5, 255 }, { 50, 56, 61, 255 },
	{ 0, 0, 10, 255 }, { 197, 239, 239, 255 }, { 63, 109, 242, 255 },
	{ 13, 202, 151, 255 }, { 158, 183, 19, 255 }, { 30, 210, 64, 255 },
	{ 225, 65, 230, 255 }, { 128, 47, 204, 255 }, { 255, 255, 255, 255 },
	{ 238, 19, 24, 255 }, { 247, 89, 215, 255 }, { 239, 198, 253, 255 },
	{ 160, 56, 241, 255 }, { 86, 74, 241, 255 }, { 74, 160, 241, 255 },
	{ 199, 244, 251, 255 }, { 49, 238, 237, 255 }, { 16, 194, 66, 255 },
	{ 112, 192, 33, 255 }, { 16, 145, 52, 255 }, { 248, 247, 41, 255 },
	{ 227, 180, 20, 255 }, { 241, 115, 25, 255 }, { 248, 247, 175, 255 },
	{ 103, 85, 54, 255 }, { 159, 17, 20, 255 }, { 255, 255, 255, 255 }
};

const ZombatarItem gHairItems[] = {
	{ IMAGE_ZOMBATAR_HAIR_1, IMAGE_ZOMBATAR_HAIR_1_MASK, 23, 0, 8, 1, ZOMBATAR_COLOR_HAIR, 32, "hair_00", 8 },
	{ IMAGE_ZOMBATAR_HAIR_2, IMAGE_ZOMBATAR_HAIR_2_MASK, 23, 25, 2, 3, ZOMBATAR_COLOR_HAIR, 32, "hair_01", 8 },
	{ IMAGE_ZOMBATAR_HAIR_3, nullptr, 23, 30, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "hair_02", 8 },
	{ IMAGE_ZOMBATAR_HAIR_4, nullptr, 30, 15, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_03", 8 },
	{ IMAGE_ZOMBATAR_HAIR_5, nullptr, 36, 37, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_04", 8 },
	{ IMAGE_ZOMBATAR_HAIR_6, nullptr, 39, 13, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_05", 8 },
	{ IMAGE_ZOMBATAR_HAIR_7, nullptr, 51, 22, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_06", 8 },
	{ IMAGE_ZOMBATAR_HAIR_8, nullptr, 28, 15, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_07", 8 },
	{ IMAGE_ZOMBATAR_HAIR_9, nullptr, 128, 55, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_08", 8 },
	{ IMAGE_ZOMBATAR_HAIR_10, nullptr, 22, 32, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "hair_09", 8 },
	{ IMAGE_ZOMBATAR_HAIR_11, IMAGE_ZOMBATAR_HAIR_11_MASK, 25, 19, 2, 2, ZOMBATAR_COLOR_HAIR, 32, "hair_10", 8 },
	{ IMAGE_ZOMBATAR_HAIR_12, IMAGE_ZOMBATAR_HAIR_12_MASK, 51, -5, 2, 2, ZOMBATAR_COLOR_HAIR, 2, "hair_11", 8 },
	{ IMAGE_ZOMBATAR_HAIR_13, IMAGE_ZOMBATAR_HAIR_13_MASK, 33, 13, 2, 2, ZOMBATAR_COLOR_HAIR, 32, "hair_12", 8 },
	{ IMAGE_ZOMBATAR_HAIR_14, IMAGE_ZOMBATAR_HAIR_14_MASK, 9, -2, 1, 5, ZOMBATAR_COLOR_HAIR, 32, "hair_13", 8 },
	{ IMAGE_ZOMBATAR_HAIR_15, IMAGE_ZOMBATAR_HAIR_15_MASK, 45, 4, 0, -1, ZOMBATAR_COLOR_HAIR, 32, "hair_14", 8 },
	{ IMAGE_ZOMBATAR_HAIR_16, nullptr, 26, 20, 0, 0, ZOMBATAR_COLOR_HAIR, 2, "hair_15", 8 }
};

const ZombatarItem gFacialHairItems[] = {
	{ IMAGE_ZOMBATAR_FACIALHAIR_1, IMAGE_ZOMBATAR_FACIALHAIR_1_MASK, 35, 107, 1, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_00", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_2, nullptr, 51, 110, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_01", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_3, nullptr, 45, 110, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_02", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_4, IMAGE_ZOMBATAR_FACIALHAIR_4_MASK, 38, 105, 3, 2, ZOMBATAR_COLOR_HAIR, 32, "facialHair_03", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_5, nullptr, 69, 145, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_04", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_6, nullptr, 48, 112, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_05", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_7, nullptr, 13, 107, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_06", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_8, IMAGE_ZOMBATAR_FACIALHAIR_8_MASK, 45, 105, 1, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_07", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_9, IMAGE_ZOMBATAR_FACIALHAIR_9_MASK, 41, 105, 1, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_08", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_10, IMAGE_ZOMBATAR_FACIALHAIR_10_MASK, 44, 112, 1, 2, ZOMBATAR_COLOR_HAIR, 32, "facialHair_09", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_11, IMAGE_ZOMBATAR_FACIALHAIR_11_MASK, 43, 88, 1, 4, ZOMBATAR_COLOR_HAIR, 32, "facialHair_10", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_12, IMAGE_ZOMBATAR_FACIALHAIR_12_MASK, 28, 105, 8, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_11", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_13, nullptr, 45, 110, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_12", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_14, IMAGE_ZOMBATAR_FACIALHAIR_14_MASK, 18, 103, 1, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_13", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_15, IMAGE_ZOMBATAR_FACIALHAIR_15_MASK, 63, 145, 2, 1, ZOMBATAR_COLOR_HAIR, 4, "facialHair_14", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_16, IMAGE_ZOMBATAR_FACIALHAIR_16_MASK, 63, 140, 1, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_15", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_17, nullptr, 43, 110, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_16", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_18, IMAGE_ZOMBATAR_FACIALHAIR_18_MASK, 58, 96, 1, 3, ZOMBATAR_COLOR_HAIR, 32, "facialHair_17", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_19, nullptr, 46, 92, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_18", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_20, nullptr, 114, 80, 0, 0, ZOMBATAR_COLOR_HAIR, 32, "facialHair_19", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_21, IMAGE_ZOMBATAR_FACIALHAIR_21_MASK, 118, 83, 1, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_20", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_22, IMAGE_ZOMBATAR_FACIALHAIR_22_MASK, 13, 87, 3, 4, ZOMBATAR_COLOR_HAIR, 4, "facialHair_21", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_23, IMAGE_ZOMBATAR_FACIALHAIR_23_MASK, 58, 145, 1, 1, ZOMBATAR_COLOR_HAIR, 32, "facialHair_22", 6 },
	{ IMAGE_ZOMBATAR_FACIALHAIR_24, IMAGE_ZOMBATAR_FACIALHAIR_24_MASK, 38, 108, 4, 2, ZOMBATAR_COLOR_HAIR, 4, "facialHair_23", 6 }
};

const ZombatarItem gTidbitsItems[] = {
	{ IMAGE_ZOMBATAR_TIDBITS_1, IMAGE_ZOMBATAR_TIDBITS_3, 28, 63, 18, 48, ZOMBATAR_COLOR_BRIGHT, 32, "tidBits_00", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_2, nullptr, 28, 63, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "tidBits_01", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_3, nullptr, 46, 111, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "tidBits_02", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_4, nullptr, 31, 62, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_03", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_5, nullptr, 31, 58, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_04", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_6, nullptr, 28, 66, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_05", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_7, nullptr, 28, 72, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_06", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_8, nullptr, 33, 55, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_07", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_9, nullptr, 21, 76, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_08", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_10, nullptr, 36, 71, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "tidBits_09", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_11, nullptr, 36, 70, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "tidBits_10", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_12, nullptr, 86, 91, 0, 6, ZOMBATAR_COLOR_BRIGHT, 32, "tidBits_11", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_13, nullptr, 88, 50, 0, 8, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_12", 2 },
	{ IMAGE_ZOMBATAR_TIDBITS_14, nullptr, 113, 115, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "tidBits_13", 2 }
};

const ZombatarItem gEyewearItems[] = {
	{ IMAGE_ZOMBATAR_EYEWEAR_1, IMAGE_ZOMBATAR_EYEWEAR_1_MASK, 28, 73, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_00", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_2, IMAGE_ZOMBATAR_EYEWEAR_2_MASK, 31, 85, 0, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_01", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_3, IMAGE_ZOMBATAR_EYEWEAR_3_MASK, 28, 69, 0, 1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_02", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_4, IMAGE_ZOMBATAR_EYEWEAR_4_MASK, 28, 78, 0, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_03", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_5, IMAGE_ZOMBATAR_EYEWEAR_5_MASK, 30, 75, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_04", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_6, IMAGE_ZOMBATAR_EYEWEAR_6_MASK, 30, 78, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_05", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_7, IMAGE_ZOMBATAR_EYEWEAR_7_MASK, 50, 90, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_06", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_8, IMAGE_ZOMBATAR_EYEWEAR_8_MASK, 32, 70, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_07", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_9, IMAGE_ZOMBATAR_EYEWEAR_9_MASK, 36, 100, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_08", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_10, IMAGE_ZOMBATAR_EYEWEAR_10_MASK, 31, 75, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_09", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_11, IMAGE_ZOMBATAR_EYEWEAR_11_MASK, 31, 67, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_10", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_12, IMAGE_ZOMBATAR_EYEWEAR_12_MASK, 38, 95, -1, -1, ZOMBATAR_COLOR_BRIGHT, 32, "eyeWear_11", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_13, nullptr, 30, 81, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "eyeWear_12", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_14, nullptr, 35, 64, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "eyeWear_13", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_15, nullptr, 42, 65, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "eyeWear_14", 10 },
	{ IMAGE_ZOMBATAR_EYEWEAR_16, nullptr, 35, 65, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "eyeWear_15", 10 }
};

const ZombatarItem gClothesItems[] = {
	{ IMAGE_ZOMBATAR_CLOTHES_1, nullptr, 88, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_2, nullptr, 75, 100, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_3, nullptr, 85, 112, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_4, nullptr, 76, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_5, nullptr, 89, 115, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_6, nullptr, 93, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_7, nullptr, 78, 105, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_8, nullptr, 88, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_9, nullptr, 88, 102, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_10, nullptr, 85, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_11, nullptr, 85, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 },
	{ IMAGE_ZOMBATAR_CLOTHES_12, nullptr, 79, 112, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 20, "", 0 }
};

const ZombatarItem gAccessoriesItems[] = {
	{ IMAGE_ZOMBATAR_ACCESSORY_1, nullptr, 103, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_00", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_2, nullptr, 108, 110, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_01", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_3, nullptr, 86, 113, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_02", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_4, nullptr, 131, 95, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_03", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_5, nullptr, 131, 100, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_04", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_6, nullptr, 131, 100, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_14", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_8, nullptr, 104, 111, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_05", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_9, nullptr, 118, 65, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "accessories_06", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_10, nullptr, 61, 118, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_12", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_11, nullptr, 43, 100, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "accessories_07", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_12, nullptr, 135, 92, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_09", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_13, nullptr, 78, 130, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "accessories_10", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_14, nullptr, 68, 145, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "accessories_11", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_15, nullptr, 133, 70, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_13", 4 },
	{ IMAGE_ZOMBATAR_ACCESSORY_16, nullptr, 13, 40, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "accessories_08", 10 }
};

const ZombatarItem gHatsItems[] = {
	{ IMAGE_ZOMBATAR_HATS_1, IMAGE_ZOMBATAR_HATS_1_MASK, 28, 5, 2, 1, ZOMBATAR_COLOR_BRIGHT, 32, "hats_00", 12 },
	{ IMAGE_ZOMBATAR_HATS_2, nullptr, 47, 12, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "hats_01", 12 },
	{ IMAGE_ZOMBATAR_HATS_3, IMAGE_ZOMBATAR_HATS_3_MASK, 36, 20, 15, -1, ZOMBATAR_COLOR_BRIGHT, 32, "hats_02", 12 },
	{ IMAGE_ZOMBATAR_HATS_4, nullptr, 11, 10, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "hats_03", 12 },
	{ IMAGE_ZOMBATAR_HATS_5, nullptr, 41, 16, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "hats_04", 12 },
	{ IMAGE_ZOMBATAR_HATS_6, IMAGE_ZOMBATAR_HATS_6_MASK, 18, 3, 4, -2, ZOMBATAR_COLOR_BRIGHT, 32, "hats_05", 12 },
	{ IMAGE_ZOMBATAR_HATS_7, IMAGE_ZOMBATAR_HATS_7_MASK, 53, 17, 0, 15, ZOMBATAR_COLOR_BRIGHT, 2, "hats_06", 12 },
	{ IMAGE_ZOMBATAR_HATS_8, IMAGE_ZOMBATAR_HATS_8_MASK, 3, 0, 0, -2, ZOMBATAR_COLOR_BRIGHT, 2, "hats_07", 12 },
	{ IMAGE_ZOMBATAR_HATS_9, IMAGE_ZOMBATAR_HATS_9_MASK, 38, 0, -1, -2, ZOMBATAR_COLOR_BRIGHT, 2, "hats_08", 12 },
	{ IMAGE_ZOMBATAR_HATS_10, nullptr, 13, 45, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "hats_09", 12 },
	{ IMAGE_ZOMBATAR_HATS_11, IMAGE_ZOMBATAR_HATS_11_MASK, 63, 8, 1, 14, ZOMBATAR_COLOR_BRIGHT, 32, "hats_10", 12 },
	{ IMAGE_ZOMBATAR_HATS_12, nullptr, 43, 15, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "hats_11", 12 },
	{ IMAGE_ZOMBATAR_HATS_13, nullptr, 18, 0, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "hats_12", 12 },
	{ IMAGE_ZOMBATAR_HATS_14, nullptr, 23, 5, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "hats_13", 12 }
};

const ZombatarItem gBackdropItems[] = {
	{ IMAGE_ZOMBATAR_BACKGROUND_CRAZYDAVE, nullptr, 0, 0, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "", 0 },
	{ IMAGE_ZOMBATAR_BACKGROUND_MENU, nullptr, 0, 0, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "", 0 },
	{ IMAGE_ZOMBATAR_BACKGROUND_MENU_DOS, nullptr, 0, 0, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "", 0 },
	{ IMAGE_ZOMBATAR_BACKGROUND_ROOF, nullptr, 0, 0, 0, 0, ZOMBATAR_COLOR_NOT_APPLICABLE, 32, "", 0 },
	{ IMAGE_ZOMBATAR_BACKGROUND_BLANK, nullptr, 0, 0, 0, 0, ZOMBATAR_COLOR_BRIGHT, 32, "", 0 }
};

struct ZombatarItemSpan
{
	const ZombatarItem* mItems;
	int mCount;
};

template <size_t Count>
ZombatarItemSpan MakeSpan(const ZombatarItem (&theItems)[Count])
{
	return { theItems, static_cast<int>(Count) };
}

ZombatarItemSpan GetRawItems(ZombatarCustomizationPage thePage)
{
	switch (thePage)
	{
	case ZOMBATAR_CUSTOM_CLOTHES: return MakeSpan(gClothesItems);
	case ZOMBATAR_CUSTOM_TIDBITS: return MakeSpan(gTidbitsItems);
	case ZOMBATAR_CUSTOM_ACCESSORIES: return MakeSpan(gAccessoriesItems);
	case ZOMBATAR_CUSTOM_FACIAL_HAIR: return MakeSpan(gFacialHairItems);
	case ZOMBATAR_CUSTOM_HAIR: return MakeSpan(gHairItems);
	case ZOMBATAR_CUSTOM_EYEWEAR: return MakeSpan(gEyewearItems);
	case ZOMBATAR_CUSTOM_HATS: return MakeSpan(gHatsItems);
	case ZOMBATAR_CUSTOM_BACKDROPS: return MakeSpan(gBackdropItems);
	default: return { nullptr, 0 };
	}
}

GameButton* MakeZombatarButton(
	int theId,
	Widget* theParent,
	Image* theNormalImage,
	Image* theOverImage,
	Image* theDownImage,
	Image* theDisabledImage = nullptr)
{
	GameButton* aButton = new GameButton(theId);
	aButton->mParentWidget = theParent;
	aButton->mButtonImage = theNormalImage;
	aButton->mOverImage = theOverImage;
	aButton->mDownImage = theDownImage;
	aButton->mDisabledImage = theDisabledImage;

	Image* aSizeImage = theNormalImage ? theNormalImage :
		(theOverImage ? theOverImage : theDownImage);
	if (aSizeImage)
		aButton->Resize(0, 0, aSizeImage->mWidth, aSizeImage->mHeight);
	return aButton;
}

void MoveButton(GameButton* theButton, int theX, int theY)
{
	if (theButton)
		theButton->Resize(theX, theY, theButton->mWidth, theButton->mHeight);
}

bool CanPress(const GameButton* theButton)
{
	return theButton && theButton->mIsOver && !theButton->mDisabled &&
		!theButton->mBtnNoDraw;
}

Rect ClampSourceRect(const Rect& theRect, const Image* theImage)
{
	if (!theImage)
		return Rect();

	const int aLeft = std::clamp(theRect.mX, 0, theImage->mWidth);
	const int aTop = std::clamp(theRect.mY, 0, theImage->mHeight);
	const int aRight = std::clamp(
		theRect.mX + theRect.mWidth, aLeft, theImage->mWidth);
	const int aBottom = std::clamp(
		theRect.mY + theRect.mHeight, aTop, theImage->mHeight);
	return Rect(aLeft, aTop, aRight - aLeft, aBottom - aTop);
}

// The alignment bits in the 1073 Zombatar table are the same bits used by
// the original FitIconRect helper: 2=top, 4=bottom, 8=left, 16=right.
// Keeping this separate from the portrait coordinates prevents the thumbnail
// page from accidentally treating vertical alignment as horizontal.
Rect FitZombatarIconRect(const Rect& theCell, const Image* theImage, int theAlignment)
{
	if (!theImage)
		return Rect();

	const int aInset = 10;
	const int aAvailableWidth = std::max(1, theCell.mWidth - aInset * 2);
	const int aAvailableHeight = std::max(1, theCell.mHeight - aInset * 2);
	int aWidth = theImage->mWidth;
	int aHeight = theImage->mHeight;
	const bool aWidthOverflows = aWidth > aAvailableWidth;
	const bool aHeightOverflows = aHeight > aAvailableHeight;
	if (aWidthOverflows && (!aHeightOverflows || aWidth >= aHeight))
	{
		aHeight = std::max(1, static_cast<int>(aHeight *
			(static_cast<float>(aAvailableWidth) / aWidth)));
		aWidth = aAvailableWidth;
	}
	else if (aHeightOverflows)
	{
		aWidth = std::max(1, static_cast<int>(aWidth *
			(static_cast<float>(aAvailableHeight) / aHeight)));
		aHeight = aAvailableHeight;
	}

	int aX = theCell.mX + (theCell.mWidth - aWidth) / 2;
	int aY = theCell.mY + (theCell.mHeight - aHeight) / 2;
	if (theAlignment & 2)
		aY = theCell.mY + aInset;
	else if (theAlignment & 4)
		aY = theCell.mY + theCell.mHeight - aInset - aHeight;
	if (theAlignment & 8)
		aX = theCell.mX + aInset;
	else if (theAlignment & 16)
		aX = theCell.mX + theCell.mWidth - aInset - aWidth;
	return Rect(aX, aY, aWidth, aHeight);
}

// Manifest images may discard their CPU pixels after the D3D11 upload. The
// official JPEG writer is nevertheless a software composition path. Reload
// only the handful of selected Zombatar assets from pak64 for the duration of
// the export; restoring the global slots immediately afterwards avoids both a
// GPU readback and permanent duplicate texture memory.
class ScopedZombatarSoftwareImages
{
public:
	explicit ScopedZombatarSoftwareImages(LawnApp* theApp) : mApp(theApp) {}

	~ScopedZombatarSoftwareImages()
	{
		for (Entry& anEntry : mEntries)
			*anEntry.mSlot = anEntry.mOriginal;
	}

	bool Add(Image** theSlot)
	{
		if (!theSlot || !*theSlot)
			return true;
		for (const Entry& anEntry : mEntries)
		{
			if (anEntry.mSlot == theSlot)
				return true;
		}

		MemoryImage* aSource = dynamic_cast<MemoryImage*>(*theSlot);
		if (!aSource || aSource->mFilePath.empty())
		{
			TodTraceAndLog("ZOMBATAR_EXPORT_SOURCE_MISSING image=%p", *theSlot);
			return false;
		}

		std::unique_ptr<ImageLib::Image> aLoaded(
			ImageLib::GetImage(aSource->mFilePath, true));
		if (!aLoaded || !aLoaded->mBits ||
			aLoaded->mWidth <= 0 || aLoaded->mHeight <= 0)
		{
			TodTraceAndLog(
				"ZOMBATAR_EXPORT_RELOAD_FAILED path=%s",
				aSource->mFilePath.c_str());
			return false;
		}

		auto aCopy = std::make_unique<MemoryImage>(mApp);
		aCopy->mFilePath = aSource->mFilePath;
		aCopy->SetBits(
			aLoaded->mBits,
			aLoaded->mWidth,
			aLoaded->mHeight,
			true);

		Entry anEntry;
		anEntry.mSlot = theSlot;
		anEntry.mOriginal = *theSlot;
		anEntry.mCopy = std::move(aCopy);
		*theSlot = anEntry.mCopy.get();
		mEntries.push_back(std::move(anEntry));
		return true;
	}

private:
	struct Entry
	{
		Image** mSlot = nullptr;
		Image* mOriginal = nullptr;
		std::unique_ptr<MemoryImage> mCopy;
	};

	LawnApp* mApp;
	std::vector<Entry> mEntries;
};

bool ExportZombatarJpeg(const Zombatar& theZombatar, int theNumber, LawnApp* theApp)
{
	if (theNumber <= 0 || !theApp)
		return false;
	TodTraceAndLog("ZOMBATAR_EXPORT_BEGIN number=%d", theNumber);

	ScopedZombatarSoftwareImages aSoftwareImages(theApp);
	if (!aSoftwareImages.Add(&IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN) ||
		!aSoftwareImages.Add(&IMAGE_ZOMBATAR_ZOMBIE_BLANK) ||
		! aSoftwareImages.Add(&IMAGE_ZOMBATAR_BACKGROUND_BLANK))
	{
		return false;
	}

	const ZombatarItem* aBackdrop = ZombatarGetItem(
		ZOMBATAR_CUSTOM_BACKDROPS,
		theZombatar.mItems[ZOMBATAR_CUSTOM_BACKDROPS]);
	if (aBackdrop && !aSoftwareImages.Add(aBackdrop->mImage))
		return false;
	for (int aPage = ZOMBATAR_CUSTOM_CLOTHES;
		aPage <= ZOMBATAR_CUSTOM_HATS;
		++aPage)
	{
		const ZombatarItem* anItem = ZombatarGetItem(
			static_cast<ZombatarCustomizationPage>(aPage),
			theZombatar.mItems[aPage]);
		if (anItem &&
			(!aSoftwareImages.Add(anItem->mImage) ||
			 !aSoftwareImages.Add(anItem->mColorMask)))
		{
			return false;
		}
	}

	Image* aBackdropImage =
		aBackdrop && aBackdrop->mImage ? *aBackdrop->mImage : nullptr;
	const int aWidth = aBackdropImage ? aBackdropImage->mWidth : 180;
	const int aHeight = aBackdropImage ? aBackdropImage->mHeight : 180;
	if (aWidth <= 0 || aHeight <= 0)
		return false;

	// The original FUN_005313F0 renders the portrait into a software image
	// before passing it to the JPEG writer.  Keep the export independent of
	// the active D3D11 swap chain.
	MemoryImage aMemoryImage(theApp);
	aMemoryImage.Create(aWidth, aHeight);
	Graphics aGraphics(&aMemoryImage);
	aGraphics.SetLinearBlend(true);
	DrawZombatarPortrait(&aGraphics, theZombatar, 0, 0);

	char aDesktopPath[MAX_PATH] = {};
	if (FAILED(SHGetFolderPathA(
		nullptr,
		CSIDL_DESKTOP,
		nullptr,
		SHGFP_TYPE_CURRENT,
		aDesktopPath)))
	{
		TodTraceAndLog("ZOMBATAR_EXPORT_DESKTOP_PATH_FAILED number=%d", theNumber);
		return false;
	}

	const std::string aFileName = std::string(aDesktopPath) +
		"\\Zombatar_" + std::to_string(theNumber) + ".png";
	ImageLib::Image aExportImage;
	aExportImage.mWidth = aMemoryImage.mWidth;
	aExportImage.mHeight = aMemoryImage.mHeight;
	aExportImage.mBits = aMemoryImage.GetBits();
	// The refreshed build keeps the portrait lossless.  The original 1073
	// export used a low-quality JPEG, which introduced avoidable colour and
	// alpha differences in the saved avatar.
	const bool aWritten = ImageLib::WritePNGImage(aFileName, &aExportImage);
	TodTraceAndLog(
		"ZOMBATAR_EXPORT_END number=%d written=%d path=%s",
		theNumber,
		aWritten ? 1 : 0,
		aFileName.c_str());
	// ImageLib::Image owns mBits by default; this instance only borrows the
	// MemoryImage buffer.
	aExportImage.mBits = nullptr;
	return aWritten;
}

std::array<GameButton*, 18> GetAllButtons(ZombatarItems* theItems)
{
	return {
		theItems->mPrevPageButton,
		theItems->mNextPageButton,
		theItems->mSkinButton,
		theItems->mHairButton,
		theItems->mFacialHairButton,
		theItems->mTidbitsButton,
		theItems->mEyeWearButton,
		theItems->mClothesButton,
		theItems->mAccessoryButton,
		theItems->mHatsButton,
		theItems->mBackdropsButton,
		theItems->mBackButton,
		theItems->mFinishedButton,
		theItems->mNewZombieButton,
		theItems->mNextZombieButton,
		theItems->mPrevZombieButton,
		theItems->mMainMenuButton,
		theItems->mViewButton
	};
}
}

const Color& ZombatarGetColor(int theColorIndex)
{
	static const Color aWhite(255, 255, 255, 255);
	if (theColorIndex < 0 ||
		theColorIndex >= static_cast<int>(sizeof(gZombatarColors) / sizeof(gZombatarColors[0])))
		return aWhite;
	return gZombatarColors[theColorIndex];
}

const ZombatarItem* ZombatarGetItem(ZombatarCustomizationPage thePage, int theSelectionIndex)
{
	if (theSelectionIndex < 0)
		return nullptr;

	// 1073 FUN_0052FCD0 stores the display-cell index in the save record and
	// removes the inserted separator cells only when looking up the raw item
	// table.  Keep this intentionally asymmetric with the editor grid: the
	// serialized value is the logical grid index, not a compact raw index.
	if (thePage != ZOMBATAR_CUSTOM_BACKDROPS && theSelectionIndex > 16)
		theSelectionIndex -= theSelectionIndex / 17;

	ZombatarItemSpan aItems = GetRawItems(thePage);
	if (theSelectionIndex < 0 || theSelectionIndex >= aItems.mCount)
		return nullptr;
	return &aItems.mItems[theSelectionIndex];
}

// 1073's editor initializes the skin swatch to palette entry 0.  A partially
// written/old detail record can contain -1 (or an out-of-range value) there;
// feeding that value into the portrait path selects the white fallback palette
// and makes the entire skin appear bleached.  Normalize only values that are
// invalid for the corresponding table; valid component values are left byte
// for byte compatible with the GOTY save.
Zombatar NormalizeZombatarForRender(const Zombatar& theZombatar)
{
	Zombatar aResult = theZombatar;
	if (aResult.mColors[ZOMBATAR_CUSTOM_SKIN] < 0 ||
		aResult.mColors[ZOMBATAR_CUSTOM_SKIN] >= 12)
	{
		aResult.mColors[ZOMBATAR_CUSTOM_SKIN] = 0;
	}

	for (int aPage = ZOMBATAR_CUSTOM_CLOTHES;
		aPage <= ZOMBATAR_CUSTOM_HATS;
		++aPage)
	{
		if (aResult.mItems[aPage] >= 0 &&
			ZombatarGetItem(
				static_cast<ZombatarCustomizationPage>(aPage),
				aResult.mItems[aPage]) == nullptr)
		{
			aResult.mItems[aPage] = -1;
		}
	}
	if (aResult.mItems[ZOMBATAR_CUSTOM_BACKDROPS] < 0 ||
		aResult.mItems[ZOMBATAR_CUSTOM_BACKDROPS] >= ZombatarGetRawItemCount(ZOMBATAR_CUSTOM_BACKDROPS))
	{
		aResult.mItems[ZOMBATAR_CUSTOM_BACKDROPS] = 4;
	}
	return aResult;
}

int ZombatarGetRawItemCount(ZombatarCustomizationPage thePage)
{
	return GetRawItems(thePage).mCount;
}

void ResetZombatarReanimation(Reanimation* theReanimation)
{
	if (!theReanimation)
		return;

	for (int aPage = ZOMBATAR_CUSTOM_TIDBITS; aPage <= ZOMBATAR_CUSTOM_HATS; ++aPage)
	{
		ZombatarItemSpan aItems = GetRawItems(static_cast<ZombatarCustomizationPage>(aPage));
		for (int anIndex = 0; anIndex < aItems.mCount; ++anIndex)
		{
			const char* aTrackName = aItems.mItems[anIndex].mTrackName;
			if (!aTrackName || aTrackName[0] == '\0')
				continue;
			theReanimation->AssignRenderGroupToTrack(aTrackName, RENDER_GROUP_HIDDEN);

			std::string aLineTrack = std::string(aTrackName) + "_line";
			if (theReanimation->TrackExists(aLineTrack.c_str()))
				theReanimation->AssignRenderGroupToTrack(aLineTrack.c_str(), RENDER_GROUP_HIDDEN);
		}
	}
}

void ApplyZombatarReanimation(Reanimation* theReanimation, const Zombatar& theZombatar)
{
	if (!theReanimation)
		return;

	const Zombatar aNormalized = NormalizeZombatarForRender(theZombatar);
	ResetZombatarReanimation(theReanimation);
	for (int aPage = ZOMBATAR_CUSTOM_TIDBITS; aPage <= ZOMBATAR_CUSTOM_HATS; ++aPage)
	{
		const ZombatarItem* anItem = ZombatarGetItem(
			static_cast<ZombatarCustomizationPage>(aPage),
			aNormalized.mItems[aPage]);
		if (!anItem || !anItem->mTrackName || anItem->mTrackName[0] == '\0')
			continue;

		theReanimation->AssignRenderGroupToTrack(anItem->mTrackName, anItem->mRenderGroup);
		if (ReanimatorTrackInstance* aTrack =
			theReanimation->GetTrackInstanceByName(anItem->mTrackName))
		{
			aTrack->mTrackColor = ZombatarGetColor(aNormalized.mColors[aPage]);
		}

		std::string aLineTrack = std::string(anItem->mTrackName) + "_line";
		if (theReanimation->TrackExists(aLineTrack.c_str()))
			theReanimation->AssignRenderGroupToTrack(aLineTrack.c_str(), anItem->mRenderGroup + 1);
	}
}

void DrawZombatarPortrait(Graphics* g, const Zombatar& theZombatar, int theX, int theY)
{
	if (!g)
		return;

	GraphicsAutoState aState(g);
	// A portrait is composed from several independent images.  Some of the
	// source sheets intentionally contain pixels outside the 180x180 portrait
	// canvas (for example a hat brim or a backdrop edge).  The original
	// Zombatar renderer establishes the portrait canvas before composing those
	// images; without that state adjacent saved portraits can bleed into one
	// another and through the stone display frame.
	const int aPortraitWidth = IMAGE_ZOMBATAR_BACKGROUND_BLANK
		? IMAGE_ZOMBATAR_BACKGROUND_BLANK->mWidth
		: 180;
	const int aPortraitHeight = IMAGE_ZOMBATAR_BACKGROUND_BLANK
		? IMAGE_ZOMBATAR_BACKGROUND_BLANK->mHeight
		: 180;
	g->ClipRect(theX, theY, aPortraitWidth, aPortraitHeight);
	const Zombatar aNormalized = NormalizeZombatarForRender(theZombatar);
	// A portrait may follow a reanimation draw in the same Graphics object.
	// Establish the neutral state explicitly so a stale tint cannot leak into
	// the skin or the next component.
	g->SetColorizeImages(false);
	g->SetColor(Color::White);
	const ZombatarItem* aBackdrop = ZombatarGetItem(
		ZOMBATAR_CUSTOM_BACKDROPS,
		aNormalized.mItems[ZOMBATAR_CUSTOM_BACKDROPS]);
	if (aBackdrop && aBackdrop->mImage && *aBackdrop->mImage)
	{
		if (aBackdrop->mColorMode != ZOMBATAR_COLOR_NOT_APPLICABLE)
		{
			g->SetColor(ZombatarGetColor(aNormalized.mColors[ZOMBATAR_CUSTOM_BACKDROPS]));
			g->SetColorizeImages(true);
		}
		g->DrawImage(*aBackdrop->mImage, theX + aBackdrop->mX, theY + aBackdrop->mY);
		g->SetColorizeImages(false);
		g->SetColor(Color::White);
	}

	Image* aSkin = IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN;
	Image* aBlank = IMAGE_ZOMBATAR_ZOMBIE_BLANK;
	if (aSkin && aBlank)
	{
		// 1073 FUN_00530970 aligns both zombie base images to the backdrop's
		// bottom-right corner.  Centering them shifts the portrait about
		// 19 pixels left and 20 pixels up in the 180x180 display window.
		// 1073 anchors the two base images to the blank-background canvas,
		// rather than to whichever backdrop happens to be selected.
		Image* aBlankBackdrop = IMAGE_ZOMBATAR_BACKGROUND_BLANK;
		const int aSkinX = theX + (aBlankBackdrop
			? aBlankBackdrop->mWidth - aSkin->mWidth
			: 0);
		const int aSkinY = theY + (aBlankBackdrop
			? aBlankBackdrop->mHeight - aSkin->mHeight
			: 0);
		g->SetColor(ZombatarGetColor(aNormalized.mColors[ZOMBATAR_CUSTOM_SKIN]));
		g->SetColorizeImages(true);
		g->DrawImage(aSkin, aSkinX, aSkinY);
		g->SetColorizeImages(false);

		const int aBlankX = theX + (aBlankBackdrop
			? aBlankBackdrop->mWidth - aBlank->mWidth
			: 0);
		const int aBlankY = theY + (aBlankBackdrop
			? aBlankBackdrop->mHeight - aBlank->mHeight
			: 0);
		g->DrawImage(aBlank, aBlankX, aBlankY);
		g->SetColor(Color::White);
	}

	struct SelectedItem
	{
		int mPage;
		const ZombatarItem* mItem;
	};
	std::vector<SelectedItem> aSelectedItems;
	for (int aPage = ZOMBATAR_CUSTOM_CLOTHES; aPage <= ZOMBATAR_CUSTOM_HATS; ++aPage)
	{
		const ZombatarItem* anItem = ZombatarGetItem(
			static_cast<ZombatarCustomizationPage>(aPage),
			aNormalized.mItems[aPage]);
		if (anItem)
			aSelectedItems.push_back({ aPage, anItem });
	}

	std::stable_sort(aSelectedItems.begin(), aSelectedItems.end(),
		[](const SelectedItem& theLeft, const SelectedItem& theRight)
		{
			if (theLeft.mItem->mRenderGroup != theRight.mItem->mRenderGroup)
				return theLeft.mItem->mRenderGroup < theRight.mItem->mRenderGroup;
			return theLeft.mPage > theRight.mPage;
		});

	for (const SelectedItem& aSelected : aSelectedItems)
	{
		const ZombatarItem& anItem = *aSelected.mItem;
		if (!anItem.mImage || !*anItem.mImage)
			continue;

		if (anItem.mColorMode != ZOMBATAR_COLOR_NOT_APPLICABLE)
		{
			g->SetColor(ZombatarGetColor(aNormalized.mColors[aSelected.mPage]));
			g->SetColorizeImages(true);
		}

		if (anItem.mColorMask && *anItem.mColorMask)
		{
			g->DrawImage(
				*anItem.mColorMask,
				theX + anItem.mX + anItem.mMaskX,
				theY + anItem.mY + anItem.mMaskY);
			g->SetColorizeImages(false);
			g->DrawImage(*anItem.mImage, theX + anItem.mX, theY + anItem.mY);
		}
		else
		{
			g->DrawImage(*anItem.mImage, theX + anItem.mX, theY + anItem.mY);
			g->SetColorizeImages(false);
		}
		g->SetColor(Color::White);
	}
}

ZombatarItems::ZombatarItems(LawnApp* theApp) :
	mApp(theApp),
	mPrevPageButton(nullptr),
	mNextPageButton(nullptr),
	mSkinButton(nullptr),
	mHairButton(nullptr),
	mFacialHairButton(nullptr),
	mTidbitsButton(nullptr),
	mEyeWearButton(nullptr),
	mClothesButton(nullptr),
	mAccessoryButton(nullptr),
	mHatsButton(nullptr),
	mBackdropsButton(nullptr),
	mBackButton(nullptr),
	mFinishedButton(nullptr),
	mNewZombieButton(nullptr),
	mNextZombieButton(nullptr),
	mPrevZombieButton(nullptr),
	mMainMenuButton(nullptr),
	mViewButton(nullptr),
	mColors(nullptr),
	mCurrentPage(1),
	mPageCount(1),
	mItemGap(-4),
	mItemCount(0),
	mItemsPerPage(18),
	mCellPadding(10),
	mHoveredItem(-1),
	mPressedItem(-1),
	mCurrentCategory(ZOMBATAR_CUSTOM_SKIN),
	mState(ZombatarEditorState::EDITING),
	mTransitionCounter(0),
	mSelectedZombatar(0),
	mPortraitGap(40),
	mSelectionChanged(false),
	mSelectionChangedLastFrame(false),
	mDeleteHovered(false),
	mDeleteRect(321, 121, 60, 20),
	mPressedButtonId(-1)
{
	// 1073 gives the child the asset width but keeps the full logical screen
	// height for the controls below the 560x493 artwork.
	const int aWidth = IMAGE_ZOMBATAR_WIDGET_BG
		? IMAGE_ZOMBATAR_WIDGET_BG->mWidth
		: 560;
	const int aHeight = mApp ? mApp->mHeight : 600;
	Resize(25, 25, aWidth, aHeight);

	mPrevPageButton = MakeZombatarButton(
		BUTTON_PREV_PAGE, this, IMAGE_ZOMBATAR_PREV_BUTTON,
		IMAGE_ZOMBATAR_PREV_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_PREV_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_PREV_BUTTON);
	mNextPageButton = MakeZombatarButton(
		BUTTON_NEXT_PAGE, this, IMAGE_ZOMBATAR_NEXT_BUTTON,
		IMAGE_ZOMBATAR_NEXT_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_NEXT_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_NEXT_BUTTON);

	const int aPageButtonY = mHeight - mPrevPageButton->mHeight - 215;
	MoveButton(mPrevPageButton, 150, aPageButtonY);
	MoveButton(mNextPageButton, mWidth - mNextPageButton->mWidth - 55, aPageButtonY);

	mSkinButton = MakeZombatarButton(
		BUTTON_SKIN, this, IMAGE_ZOMBATAR_SKIN_BUTTON,
		IMAGE_ZOMBATAR_SKIN_BUTTON, IMAGE_ZOMBATAR_SKIN_BUTTON_HIGHLIGHT);
	mHairButton = MakeZombatarButton(
		BUTTON_HAIR, this, IMAGE_ZOMBATAR_HAIR_BUTTON,
		IMAGE_ZOMBATAR_HAIR_BUTTON_OVER, IMAGE_ZOMBATAR_HAIR_BUTTON_HIGHLIGHT);
	mFacialHairButton = MakeZombatarButton(
		BUTTON_FACIAL_HAIR, this, IMAGE_ZOMBATAR_FACIAL_HAIR_BUTTON,
		IMAGE_ZOMBATAR_FACIAL_HAIR_BUTTON_OVER, IMAGE_ZOMBATAR_FACIAL_HAIR_BUTTON_HIGHLIGHT);
	mTidbitsButton = MakeZombatarButton(
		BUTTON_TIDBITS, this, IMAGE_ZOMBATAR_TIDBITS_BUTTON,
		IMAGE_ZOMBATAR_TIDBITS_BUTTON_OVER, IMAGE_ZOMBATAR_TIDBITS_BUTTON_HIGHLIGHT);
	mEyeWearButton = MakeZombatarButton(
		BUTTON_EYEWEAR, this, IMAGE_ZOMBATAR_EYEWEAR_BUTTON,
		IMAGE_ZOMBATAR_EYEWEAR_BUTTON_OVER, IMAGE_ZOMBATAR_EYEWEAR_BUTTON_HIGHLIGHT);
	mClothesButton = MakeZombatarButton(
		BUTTON_CLOTHES, this, IMAGE_ZOMBATAR_CLOTHES_BUTTON,
		IMAGE_ZOMBATAR_CLOTHES_BUTTON_OVER, IMAGE_ZOMBATAR_CLOTHES_BUTTON_HIGHLIGHT);
	mAccessoryButton = MakeZombatarButton(
		BUTTON_ACCESSORIES, this, IMAGE_ZOMBATAR_ACCESSORY_BUTTON,
		IMAGE_ZOMBATAR_ACCESSORY_BUTTON_OVER, IMAGE_ZOMBATAR_ACCESSORY_BUTTON_HIGHLIGHT);
	mHatsButton = MakeZombatarButton(
		BUTTON_HATS, this, IMAGE_ZOMBATAR_HATS_BUTTON,
		IMAGE_ZOMBATAR_HATS_BUTTON_OVER, IMAGE_ZOMBATAR_HATS_BUTTON_HIGHLIGHT);
	mBackdropsButton = MakeZombatarButton(
		BUTTON_BACKDROPS, this, IMAGE_ZOMBATAR_BACKDROPS_BUTTON,
		IMAGE_ZOMBATAR_BACKDROPS_BUTTON_OVER, IMAGE_ZOMBATAR_BACKDROPS_BUTTON_HIGHLIGHT);

	const std::array<GameButton*, 9> aCategoryButtons = {
		mSkinButton, mHairButton, mFacialHairButton, mTidbitsButton,
		mEyeWearButton, mClothesButton, mAccessoryButton, mHatsButton,
		mBackdropsButton
	};
	int aCategoryY = 103;
	for (GameButton* aButton : aCategoryButtons)
	{
		MoveButton(aButton, 33, aCategoryY);
		aCategoryY += aButton->mHeight - 3;
	}

	mBackButton = MakeZombatarButton(
		BUTTON_BACK, this, IMAGE_ZOMBATAR_BACK_BUTTON,
		IMAGE_ZOMBATAR_BACK_BUTTON_HIGHLIGHT, nullptr);
	MoveButton(mBackButton, 360, 320);

	mFinishedButton = MakeZombatarButton(
		BUTTON_FINISHED, this, IMAGE_ZOMBATAR_FINISHED_BUTTON,
		IMAGE_ZOMBATAR_FINISHED_BUTTON_HIGHLIGHT, IMAGE_ZOMBATAR_FINISHED_BUTTON_HIGHLIGHT);
	MoveButton(mFinishedButton, 420, 447);

	mNewZombieButton = MakeZombatarButton(
		BUTTON_NEW_ZOMBIE, this, IMAGE_ZOMBATAR_NEWZOMBIE_BUTTON,
		IMAGE_ZOMBATAR_NEWZOMBIE_BUTTON_HIGHLIGHT, IMAGE_ZOMBATAR_NEWZOMBIE_BUTTON_HIGHLIGHT);
	MoveButton(mNewZombieButton, 170, 370);

	mNextZombieButton = MakeZombatarButton(
		BUTTON_NEXT_ZOMBIE, this, IMAGE_ZOMBATAR_NEXT_BUTTON,
		IMAGE_ZOMBATAR_NEXT_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_NEXT_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_NEXT_BUTTON);
	mPrevZombieButton = MakeZombatarButton(
		BUTTON_PREV_ZOMBIE, this, IMAGE_ZOMBATAR_PREV_BUTTON,
		IMAGE_ZOMBATAR_PREV_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_PREV_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_PREV_BUTTON);
	const int aBrowseButtonY = mHeight - mNextZombieButton->mHeight - 189;
	MoveButton(mNextZombieButton, mWidth - mNextZombieButton->mWidth - 85, aBrowseButtonY);
	MoveButton(mPrevZombieButton, 95, aBrowseButtonY);

	mMainMenuButton = MakeZombatarButton(
		BUTTON_MAIN_MENU, this, nullptr,
		IMAGE_ZOMBATAR_MAINMENUBACK_HIGHLIGHT,
		IMAGE_ZOMBATAR_MAINMENUBACK_HIGHLIGHT);
	MoveButton(mMainMenuButton, 253, mHeight - 97);

	mViewButton = MakeZombatarButton(
		BUTTON_VIEW, this, IMAGE_ZOMBATAR_VIEW_BUTTON,
		IMAGE_ZOMBATAR_VIEW_BUTTON_HIGHLIGHT,
		IMAGE_ZOMBATAR_VIEW_BUTTON_HIGHLIGHT);
	// FUN_0052D550 initially gives button 0x3F0 the same location as the
	// main-menu hit target.  FUN_0052E710 moves it to the editor frame's
	// lower-left corner before every draw; Draw() reproduces that second step.
	MoveButton(mViewButton, 253, mHeight - 97);

	mColors = new ZombatarColors(mApp);
	AddWidget(mColors);

	ResetZombatar();
	EnterInitialState();
}

ZombatarItems::~ZombatarItems()
{
	if (mColors && mColors->mParent == this)
		RemoveWidget(mColors);
	delete mColors;
	mColors = nullptr;

	for (GameButton* aButton : GetAllButtons(this))
		delete aButton;
}

void ZombatarItems::ResetZombatar()
{
	for (int aPage = 0; aPage < ZOMBATAR_NUM_ZOMBATAR_CUSTOM_PAGES; ++aPage)
	{
		mZombatar.mColors[aPage] = -1;
		mZombatar.mItems[aPage] = -1;
	}
	mZombatar.mColors[ZOMBATAR_CUSTOM_SKIN] = 0;
	mZombatar.mColors[ZOMBATAR_CUSTOM_BACKDROPS] = 47;
	mZombatar.mItems[ZOMBATAR_CUSTOM_BACKDROPS] = 4;

	mSelectedZombatar = 0;
	mSelectionChanged = true;
	SetCategory(ZOMBATAR_CUSTOM_SKIN);
}

void ZombatarItems::EnterInitialState()
{
	PlayerInfo* aPlayer = mApp ? mApp->mPlayerInfo : nullptr;
	mState = aPlayer && aPlayer->mNumZombatars > 0
		? ZombatarEditorState::BROWSING
		: ZombatarEditorState::EDITING;
	mSelectedZombatar = 0;
	mCurrentPage = 1;
	mHoveredItem = -1;
	mPressedItem = -1;
	mPressedButtonId = -1;
	mDeleteHovered = false;
	mTransitionCounter = 0;
	ResetTransientLayout();
	RefreshState();
}

void ZombatarItems::ResetTransientLayout()
{
	// These controls participate in the 180-tick editor/confirmation
	// transition.  The selector keeps this widget alive while it slides to
	// other pages, so a transition can be interrupted and leave the button at
	// its animated coordinate.  1073 reconstructs the static endpoints every
	// time the page is entered.
	MoveButton(mBackButton, 360, 320);
	MoveButton(mFinishedButton, 420, 447);
	MoveButton(mNewZombieButton, 170, 370);
	MoveButton(mMainMenuButton, 253, mHeight - 97);
}

void ZombatarItems::UpdateViewButtonLayout()
{
	if (!mViewButton || !IMAGE_ZOMBATAR_VIEW_BUTTON_HIGHLIGHT)
		return;

	// FUN_0052E710 applies this relocation before the input pass as well as
	// before drawing.  Doing it in one helper keeps the visual rectangle and
	// the mouse hit rectangle identical on the first frame after a page change.
	MoveButton(
		mViewButton,
		40,
		(mApp ? mApp->mHeight : 600) - 153);
}

void ZombatarItems::SetCategory(ZombatarCustomizationPage thePage)
{
	if (thePage < ZOMBATAR_CUSTOM_SKIN || thePage >= ZOMBATAR_NUM_ZOMBATAR_CUSTOM_PAGES)
		return;

	mCurrentCategory = thePage;
	mCurrentPage = 1;
	mHoveredItem = -1;
	mPressedItem = -1;
	LayoutCategoryItems();
	SyncColorMode();
	MarkDirty();
}

void ZombatarItems::LayoutCategoryItems()
{
	for (ZombatarItemCell& aCell : mItemCells)
		aCell = ZombatarItemCell();

	if (mCurrentCategory == ZOMBATAR_CUSTOM_SKIN)
	{
		mItemCount = 0;
		mPageCount = 1;
		mItemsPerPage = 18;
		mPrevPageButton->SetDisabled(true);
		mNextPageButton->SetDisabled(true);
		return;
	}

	std::vector<const ZombatarItem*> aLogicalItems;
	const int aRawCount = ZombatarGetRawItemCount(mCurrentCategory);
	for (int aRawIndex = 0; aRawIndex < aRawCount; ++aRawIndex)
	{
		// FUN_0052f6a0 appends the separator after every seventeenth raw
		// item, then appends one final separator for non-backdrop pages.
		// The save record remains compact; separators are display-only.
		aLogicalItems.push_back(&GetRawItems(mCurrentCategory).mItems[aRawIndex]);
		if (mCurrentCategory != ZOMBATAR_CUSTOM_BACKDROPS &&
			(((aRawIndex + 1) % 17) == 0 || aRawIndex == aRawCount - 1))
		{
			aLogicalItems.push_back(nullptr);
		}
	}

	mItemCount = std::min(static_cast<int>(aLogicalItems.size()), MAX_ITEM_CELLS);
	mItemsPerPage = 18;
	mPageCount = std::max(1, (mItemCount + mItemsPerPage - 1) / mItemsPerPage);
	mCurrentPage = std::clamp(mCurrentPage, 1, mPageCount);

	const int aTileWidth = IMAGE_ZOMBATAR_ACCESSORY_BG->mWidth;
	const int aTileHeight = IMAGE_ZOMBATAR_ACCESSORY_BG->mHeight;
	const int aStartX = (mWidth - (aTileWidth + mItemGap) * 6) / 2 + 50;
	const int aStartY = mItemGap * 2 + 120;

	for (int anIndex = 0; anIndex < mItemCount; ++anIndex)
	{
		const int anIndexOnPage = anIndex % mItemsPerPage;
		const int aColumn = anIndexOnPage % 6;
		const int aRow = anIndexOnPage / 6;
		ZombatarItemCell& aCell = mItemCells[anIndex];
		aCell.mItem = aLogicalItems[anIndex];
		if (aCell.mItem)
		{
			// The original stores this logical grid index, including the
			// separator slots, in Zombatar::mItems.
			aCell.mRawIndex = anIndex;
		}
		aCell.mX = aStartX + aColumn * (aTileWidth + mItemGap);
		aCell.mY = aStartY + aRow * (aTileHeight + mItemGap + 3);

		if (!aCell.mItem || !aCell.mItem->mImage || !*aCell.mItem->mImage)
			continue;

		// Keep the complete source image.  1073 fits the icon into the cell
		// (preserving aspect ratio) and applies the alignment bits to the
		// destination rectangle; cropping the source changes the visible part
		// of large hats/facial hair.
		Image* anImage = *aCell.mItem->mImage;
		aCell.mSourceRect = Rect(0, 0, anImage->mWidth, anImage->mHeight);
	}

	mPrevPageButton->SetDisabled(mCurrentPage <= 1);
	mNextPageButton->SetDisabled(mCurrentPage >= mPageCount);
}

void ZombatarItems::SyncColorMode()
{
	if (!mColors)
		return;

	ZombatarColorMode aMode = ZOMBATAR_COLOR_SKIN;
	if (mCurrentCategory != ZOMBATAR_CUSTOM_SKIN)
	{
		const int aSelection = mZombatar.mItems[mCurrentCategory];
		if (aSelection < 0)
			aMode = ZOMBATAR_COLOR_ITEM_NOT_CHOSEN;
		else
		{
			const ZombatarItem* anItem = ZombatarGetItem(mCurrentCategory, aSelection);
			aMode = anItem ? anItem->mColorMode : ZOMBATAR_COLOR_NOT_APPLICABLE;
		}
	}
	mColors->SetColorMode(aMode, mZombatar.mColors[mCurrentCategory]);
}

void ZombatarItems::RefreshState()
{
	const bool isEditing =
		mState == ZombatarEditorState::EDITING ||
		mState == ZombatarEditorState::LEAVING_CONFIRMATION;
	const bool isConfirmation =
		mState == ZombatarEditorState::ENTERING_CONFIRMATION ||
		mState == ZombatarEditorState::CONFIRMATION;

	for (GameButton* aButton : {
		mPrevPageButton, mNextPageButton, mSkinButton, mHairButton,
		mFacialHairButton, mTidbitsButton, mEyeWearButton, mClothesButton,
		mAccessoryButton, mHatsButton, mBackdropsButton })
	{
		aButton->SetDisabled(!isEditing);
	}

	if (isEditing)
	{
		mPrevPageButton->SetDisabled(mCurrentPage <= 1);
		mNextPageButton->SetDisabled(mCurrentPage >= mPageCount);
	}

	mBackButton->SetDisabled(!isConfirmation);
	mFinishedButton->SetDisabled(mState == ZombatarEditorState::BROWSING);
	mMainMenuButton->SetDisabled(false);

	PlayerInfo* aPlayer = mApp ? mApp->mPlayerInfo : nullptr;
	const int aCount = aPlayer ? aPlayer->mNumZombatars : 0;
	mViewButton->SetDisabled(!isEditing || aCount <= 0);
	mNewZombieButton->SetDisabled(mState != ZombatarEditorState::BROWSING ||
		aCount >= MAX_NUM_ZOMBATARS);
	mPrevZombieButton->SetDisabled(mState != ZombatarEditorState::BROWSING ||
		mSelectedZombatar <= 0);
	mNextZombieButton->SetDisabled(mState != ZombatarEditorState::BROWSING ||
		mSelectedZombatar >= aCount - 1);

	if (mColors)
		mColors->SetVisible(isEditing);
	MarkDirty();
}

void ZombatarItems::UpdateEditorButtons()
{
	for (GameButton* aButton : GetAllButtons(this))
		aButton->Update();
}

void ZombatarItems::Update()
{
	Widget::Update();
	UpdateViewButtonLayout();
	mSelectionChangedLastFrame = mSelectionChanged;
	mSelectionChanged = false;
	UpdateEditorButtons();

	if (mState == ZombatarEditorState::EDITING)
	{
		if (mColors && mColors->mSelectionChangedLastFrame)
		{
			mZombatar.mColors[mCurrentCategory] = mColors->mSelectedColor;
			mSelectionChanged = true;
		}
	}
	else if (mState == ZombatarEditorState::ENTERING_CONFIRMATION ||
		mState == ZombatarEditorState::LEAVING_CONFIRMATION)
	{
		--mTransitionCounter;
		const bool isEntering = mState == ZombatarEditorState::ENTERING_CONFIRMATION;
		const int aStartX = isEntering ? 420 : 130;
		const int anEndX = isEntering ? 130 : 420;
		const int aStartY = isEntering ? 445 : 320;
		const int anEndY = isEntering ? 320 : 445;
		const int aX = TodAnimateCurve(180, 0, mTransitionCounter, aStartX, anEndX, CURVE_LINEAR);
		const int aY = TodAnimateCurve(180, 0, mTransitionCounter, aStartY, anEndY, CURVE_LINEAR);
		MoveButton(mFinishedButton, aX, aY);

		if (mTransitionCounter <= 0)
		{
			mTransitionCounter = 0;
			MoveButton(
				mFinishedButton,
				isEntering ? 130 : 420,
				isEntering ? 320 : 447);
			mState = isEntering
				? ZombatarEditorState::CONFIRMATION
				: ZombatarEditorState::EDITING;
			RefreshState();
		}
	}
}

void ZombatarItems::Draw(Graphics* g)
{
	// Original 1073 FUN_0052E710 overwrites the constructor position of the
	// View Avatars button on every draw: x=40, y=appHeight-153.  The button at
	// (253, appHeight-97) is the separate transparent Main Menu/Back target.
	UpdateViewButtonLayout();

	g->DrawImage(IMAGE_ZOMBATAR_WIDGET_BG, 0, 0);

	switch (mState)
	{
	case ZombatarEditorState::EDITING:
		DrawEditor(g);
		break;
	case ZombatarEditorState::ENTERING_CONFIRMATION:
	case ZombatarEditorState::LEAVING_CONFIRMATION:
	{
		DrawEditor(g);
		const int anAlpha = mState == ZombatarEditorState::ENTERING_CONFIRMATION
			? TodAnimateCurve(180, 0, mTransitionCounter, 0, 255, CURVE_LINEAR)
			: TodAnimateCurve(180, 0, mTransitionCounter, 255, 0, CURVE_LINEAR);
		g->SetColor(Color(0, 0, 0, anAlpha));
		g->FillRect(33, 100, mWidth - 63, mHeight - 269);
		break;
	}
	case ZombatarEditorState::CONFIRMATION:
		DrawConfirmation(g);
		break;
	case ZombatarEditorState::BROWSING:
		DrawSavedZombatars(g);
		break;
	}

	mMainMenuButton->Draw(g);
}

void ZombatarItems::DrawEditor(Graphics* g)
{
	g->DrawImage(IMAGE_ZOMBATAR_WIDGET_INNER_BG, 127, 100);
	for (GameButton* aButton : {
		mSkinButton, mHairButton, mFacialHairButton, mTidbitsButton,
		mEyeWearButton, mClothesButton, mAccessoryButton, mHatsButton,
		mBackdropsButton })
	{
		aButton->Draw(g);
	}

	if (mCurrentCategory == ZOMBATAR_CUSTOM_SKIN)
	{
		TodDrawStringWrapped(
			g,
			_S("[ZOMBATAR_START_TEXT]"),
			Rect(mWidth / 2 - 200, 160, 500, 100),
			// 1073 FUN_0052FE90 loads DAT_00726728 here, which the
			// LoadingFonts table identifies as FONT_DWARVENTODCRAFT15.
			FONT_DWARVENTODCRAFT15,
			Color(254, 227, 0, 175),
			// The original passes justification 2 (horizontal centering only).
			DS_ALIGN_CENTER);
	}
	else
	{
		DrawItemGrid(g);
	}

	DrawCategoryHighlight(g);
	mFinishedButton->Draw(g);
	if (!mViewButton->mDisabled)
		mViewButton->Draw(g);
}

void ZombatarItems::DrawItemGrid(Graphics* g)
{
	const int aFirstIndex = (mCurrentPage - 1) * mItemsPerPage;
	const int anEndIndex = std::min(mItemCount, aFirstIndex + mItemsPerPage);
	const int aSelectedIndex = mZombatar.mItems[mCurrentCategory];
	const int aTileWidth = IMAGE_ZOMBATAR_ACCESSORY_BG->mWidth;
	const int aTileHeight = IMAGE_ZOMBATAR_ACCESSORY_BG->mHeight;

	for (int anIndex = aFirstIndex; anIndex < anEndIndex; ++anIndex)
	{
		const ZombatarItemCell& aCell = mItemCells[anIndex];
		const bool isSelected = aCell.mItem && aCell.mRawIndex == aSelectedIndex;
		const bool isHovered = anIndex == mHoveredItem;
		const bool isDimmed = !isSelected && !isHovered;
		if (isSelected)
		{
			// In 1073 only the selected cell has the green border.  Hovering a
			// cell cancels the dim overlay but keeps its normal stone frame.
			g->SetColorizeImages(false);
			g->DrawImage(IMAGE_ZOMBATAR_ACCESSORY_BG_HIGHLIGHT, aCell.mX, aCell.mY);
		}
		else
		{
			if (!isDimmed)
				g->SetColorizeImages(false);
			else
			{
				g->SetColorizeImages(true);
				g->SetColor(Color(128, 128, 128, 128));
			}
			g->DrawImage(IMAGE_ZOMBATAR_ACCESSORY_BG, aCell.mX, aCell.mY);
		}

		if (!aCell.mItem)
		{
			// The separator/none image inherits the same cell-wide state as the
			// stone frame. 1073 does not establish a second tint here.
			g->DrawImage(IMAGE_ZOMBATAR_ACCESSORY_BG_NONE, aCell.mX, aCell.mY);
			continue;
		}
		if (!aCell.mItem->mImage || !*aCell.mItem->mImage)
		{
			continue;
		}

		// The clothes page shows the same cropped blank zombie behind every
		// clothing item in 1073.  It is part of the editor, not a separate
		// saved component.
		if (mCurrentCategory == ZOMBATAR_CUSTOM_CLOTHES &&
			IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN && IMAGE_ZOMBATAR_ZOMBIE_BLANK)
		{
			GraphicsAutoState aClothesState(g);
			// 1073 0x530117/0x530152 deliberately queries the dimensions of
			// IMAGE_ZOMBATAR_ACCESSORY_BG, not the 142x140 zombie images.  Both
			// zombie layers are therefore scaled to the 67x67 stone-cell size,
			// positioned ten pixels up/left, and clipped by the inset cell rect.
			// Drawing the source images at native size leaves only a giant eye and
			// mouth visible in each thumbnail.
			g->ClipRect(
				aCell.mX + mCellPadding,
				aCell.mY + mCellPadding,
				aTileWidth - mCellPadding,
				aTileHeight - mCellPadding);
			const Zombatar aNormalized = NormalizeZombatarForRender(mZombatar);
			Color aSkinColor = ZombatarGetColor(
				aNormalized.mColors[ZOMBATAR_CUSTOM_SKIN]);
			if (isDimmed)
				aSkinColor.mAlpha = 128;
			g->SetColorizeImages(true);
			g->SetColor(aSkinColor);
			g->DrawImage(
				IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN,
				aCell.mX - mCellPadding,
				aCell.mY - mCellPadding,
				aTileWidth,
				aTileHeight);
			g->SetColorizeImages(false);
			g->DrawImage(
				IMAGE_ZOMBATAR_ZOMBIE_BLANK,
				aCell.mX - mCellPadding,
				aCell.mY - mCellPadding,
				aTileWidth,
				aTileHeight);
			g->SetColor(Color::White);
		}

		Image* anImage = *aCell.mItem->mImage;
		const Rect aIconRect = FitZombatarIconRect(
			Rect(aCell.mX, aCell.mY, aTileWidth, aTileHeight),
			anImage,
			aCell.mItem->mAlignment);
		const Rect aSourceRect(0, 0, anImage->mWidth, anImage->mHeight);

		if (aCell.mItem->mColorMask && *aCell.mItem->mColorMask)
		{
			Image* aMask = *aCell.mItem->mColorMask;
			if (aMask)
			{
				const float aScaleX = static_cast<float>(aIconRect.mWidth) / anImage->mWidth;
				const float aScaleY = static_cast<float>(aIconRect.mHeight) / anImage->mHeight;
				const Rect aMaskRect(
					aIconRect.mX + static_cast<int>(aCell.mItem->mMaskX * aScaleX),
					aIconRect.mY + static_cast<int>(aCell.mItem->mMaskY * aScaleY),
					std::max(1, static_cast<int>(aMask->mWidth * aScaleX)),
					std::max(1, static_cast<int>(aMask->mHeight * aScaleY)));
				g->DrawImage(aMask, aMaskRect,
					Rect(0, 0, aMask->mWidth, aMask->mHeight));
			}
			// The mask and primary image both inherit the cell-wide gray/original
			// state. Thumbnail colors never follow the selected portrait palette.
			g->DrawImage(anImage, aIconRect, aSourceRect);
		}
		else
		{
			g->DrawImage(anImage, aIconRect, aSourceRect);
		}
	}
	g->SetColorizeImages(false);
	g->SetColor(Color::White);

	if (mPageCount > 1)
	{
		// 1073 draws the normal arrow through the image-color path with this
		// translucent blue-grey tint after reaching the first or last page.
		auto DrawPageButton = [g](GameButton* theButton)
		{
			if (!theButton->mDisabled)
			{
				theButton->Draw(g);
				return;
			}

			g->SetColorizeImages(true);
			g->SetColor(Color(108, 109, 140, 40));
			theButton->DrawButtonImage(
				g,
				theButton->mButtonImage,
				theButton->mNormalRect,
				theButton->mX,
				theButton->mY);
			g->SetColorizeImages(false);
		};
		DrawPageButton(mPrevPageButton);
		DrawPageButton(mNextPageButton);
		char aPageText[32];
		std::snprintf(aPageText, sizeof(aPageText), "Page %d / %d", mCurrentPage, mPageCount);
		TodDrawString(
			g,
			StringToSexyStringFast(aPageText),
			(mPrevPageButton->mX + mNextPageButton->mX) / 2 - 15,
			mPrevPageButton->mY + mPrevPageButton->mHeight / 2 + 50,
			FONT_BRIANNETOD12,
			Color::White,
			DS_ALIGN_CENTER);
	}
}

void ZombatarItems::DrawCategoryHighlight(Graphics* g)
{
	Image* aHighlight = nullptr;
	GameButton* aButton = nullptr;
	switch (mCurrentCategory)
	{
	case ZOMBATAR_CUSTOM_SKIN:
		aHighlight = IMAGE_ZOMBATAR_SKIN_BUTTON_HIGHLIGHT;
		aButton = mSkinButton;
		break;
	case ZOMBATAR_CUSTOM_CLOTHES:
		aHighlight = IMAGE_ZOMBATAR_CLOTHES_BUTTON_HIGHLIGHT;
		aButton = mClothesButton;
		break;
	case ZOMBATAR_CUSTOM_TIDBITS:
		aHighlight = IMAGE_ZOMBATAR_TIDBITS_BUTTON_HIGHLIGHT;
		aButton = mTidbitsButton;
		break;
	case ZOMBATAR_CUSTOM_ACCESSORIES:
		aHighlight = IMAGE_ZOMBATAR_ACCESSORY_BUTTON_HIGHLIGHT;
		aButton = mAccessoryButton;
		break;
	case ZOMBATAR_CUSTOM_FACIAL_HAIR:
		aHighlight = IMAGE_ZOMBATAR_FACIAL_HAIR_BUTTON_HIGHLIGHT;
		aButton = mFacialHairButton;
		break;
	case ZOMBATAR_CUSTOM_HAIR:
		aHighlight = IMAGE_ZOMBATAR_HAIR_BUTTON_HIGHLIGHT;
		aButton = mHairButton;
		break;
	case ZOMBATAR_CUSTOM_EYEWEAR:
		aHighlight = IMAGE_ZOMBATAR_EYEWEAR_BUTTON_HIGHLIGHT;
		aButton = mEyeWearButton;
		break;
	case ZOMBATAR_CUSTOM_HATS:
		aHighlight = IMAGE_ZOMBATAR_HATS_BUTTON_HIGHLIGHT;
		aButton = mHatsButton;
		break;
	case ZOMBATAR_CUSTOM_BACKDROPS:
		aHighlight = IMAGE_ZOMBATAR_BACKDROPS_BUTTON_HIGHLIGHT;
		aButton = mBackdropsButton;
		break;
	default:
		break;
	}
	if (aHighlight && aButton)
		g->DrawImage(aHighlight, aButton->mX, aButton->mY);
}

void ZombatarItems::DrawConfirmation(Graphics* g)
{
	TodDrawString(
		g,
		_S("[ZOMBATAR_FINISHED_WARNING_HEADER]"),
		mWidth / 2,
		160,
		// 1073 loads FONT_HOUSEOFTERROR28 for the large warning header.
		FONT_HOUSEOFTERROR28,
		Color(254, 227, 0),
		DS_ALIGN_CENTER);
	TodDrawStringWrapped(
		g,
		_S("[ZOMBATAR_FINISHED_WARNING_TEXT]"),
		Rect(mWidth / 2 - 245, 200, 500, 100),
		// 1073 DAT_00726804 = FONT_CONTINUUMBOLD14 for the body.
		FONT_CONTINUUMBOLD14,
		Color::White,
		DS_ALIGN_CENTER_VERTICAL_MIDDLE);
	TodDrawString(
		g,
		_S("[ZOMBATAR_FINISHED_BUTTON_TEXT]"),
		mFinishedButton->mX + mFinishedButton->mWidth / 2,
		mFinishedButton->mY - 10,
		FONT_BRIANNETOD12,
		Color::White,
		DS_ALIGN_CENTER);
	TodDrawString(
		g,
		_S("[ZOMBATAR_BACK_BUTTON_TEXT]"),
		mBackButton->mX + mBackButton->mWidth / 2,
		mBackButton->mY - 10,
		FONT_BRIANNETOD12,
		Color::White,
		DS_ALIGN_CENTER);
	mBackButton->Draw(g);
	mFinishedButton->Draw(g);
}

void ZombatarItems::DrawSavedZombatars(Graphics* g)
{
	PlayerInfo* aPlayer = mApp ? mApp->mPlayerInfo : nullptr;
	if (!aPlayer || aPlayer->mNumZombatars <= 0)
		return;

	mSelectedZombatar = std::clamp(mSelectedZombatar, 0, aPlayer->mNumZombatars - 1);
	const Zombatar& aCurrent = aPlayer->mZombatars[mSelectedZombatar];
	// FUN_0052FE90 uses the fixed blank-background canvas for the three
	// adjacent portraits.  Using the selected backdrop's width makes the
	// neighbours drift when records contain different backgrounds.
	const int aPortraitWidth = IMAGE_ZOMBATAR_BACKGROUND_BLANK
		? IMAGE_ZOMBATAR_BACKGROUND_BLANK->mWidth
		: (IMAGE_ZOMBATAR_ZOMBIE_BLANK ? IMAGE_ZOMBATAR_ZOMBIE_BLANK->mWidth : 180);
	const int aCurrentX = (mWidth - 30) / 2 + mPortraitGap / 2 - aPortraitWidth / 2;
	const int aPortraitY = 150;

	{
		// FUN_0052e710 brackets the saved-portrait composition with the
		// widget's inner black panel.  The previous port omitted that state,
		// allowing the left/right 180x180 canvases to paint over the stone
		// frame.  Keep the clip local to the widget; the controls and counter
		// below are deliberately drawn after it is restored.
		GraphicsAutoState aPortraitPanelState(g);
		g->ClipRect(33, 100, mWidth - 63, mHeight - 0x10D);

		DrawZombatarPortrait(g, aCurrent, aCurrentX, aPortraitY);
		if (mSelectedZombatar > 0)
		{
			DrawZombatarPortrait(
				g,
				aPlayer->mZombatars[mSelectedZombatar - 1],
				aCurrentX - mPortraitGap - aPortraitWidth,
				aPortraitY);
		}
		if (mSelectedZombatar + 1 < aPlayer->mNumZombatars)
		{
			DrawZombatarPortrait(
				g,
				aPlayer->mZombatars[mSelectedZombatar + 1],
				aCurrentX + mPortraitGap + aPortraitWidth,
				aPortraitY);
		}
	}

	if (!mPrevZombieButton->mDisabled)
		mPrevZombieButton->Draw(g);
	if (!mNextZombieButton->mDisabled)
		mNextZombieButton->Draw(g);
	if (!mNewZombieButton->mDisabled)
		mNewZombieButton->Draw(g);

	char aCounter[32];
	std::snprintf(
		aCounter,
		sizeof(aCounter),
		"%d / %d",
		mSelectedZombatar + 1,
		aPlayer->mNumZombatars);
	TodDrawString(
		g,
		StringToSexyStringFast(aCounter),
		(mPrevZombieButton->mX + mNextZombieButton->mX) / 2 + 115,
		mPrevZombieButton->mY - 18,
		FONT_BRIANNETOD12,
		Color::White,
		DS_ALIGN_CENTER);
	TodDrawString(
		g,
		_S("Delete?"),
		mDeleteRect.mX + mDeleteRect.mWidth / 2,
		mDeleteRect.mY + 15,
		FONT_DWARVENTODCRAFT12,
		mDeleteHovered ? Color(22, 253, 5) : Color::White,
		DS_ALIGN_CENTER);
}

int ZombatarItems::HitTestItem(int x, int y) const
{
	if (mState != ZombatarEditorState::EDITING || mItemCount <= 0)
		return -1;

	const int aFirstIndex = (mCurrentPage - 1) * mItemsPerPage;
	const int anEndIndex = std::min(mItemCount, aFirstIndex + mItemsPerPage);
	for (int anIndex = aFirstIndex; anIndex < anEndIndex; ++anIndex)
	{
		const ZombatarItemCell& aCell = mItemCells[anIndex];
		const Rect aHitRect(
			aCell.mX + mCellPadding,
			aCell.mY + mCellPadding,
			IMAGE_ZOMBATAR_ACCESSORY_BG->mWidth - mCellPadding * 2,
			IMAGE_ZOMBATAR_ACCESSORY_BG->mHeight - mCellPadding * 2);
		if (aHitRect.Contains(x, y))
			return anIndex;
	}
	return -1;
}

void ZombatarItems::MouseMove(int x, int y)
{
	UpdateViewButtonLayout();
	GameButton* aHoveredButton = HitTestButton(x, y);
	if (mState == ZombatarEditorState::EDITING)
	{
		mHoveredItem = HitTestItem(x, y);
		mDeleteHovered = false;
	}
	else if (mState == ZombatarEditorState::BROWSING)
	{
		mHoveredItem = -1;
		mDeleteHovered = mDeleteRect.Contains(x, y);
	}
	else
	{
		mHoveredItem = -1;
		mDeleteHovered = false;
	}
	if (mApp)
	{
		const bool aClickable = aHoveredButton != nullptr ||
			(mState == ZombatarEditorState::EDITING && mHoveredItem >= 0) ||
			(mState == ZombatarEditorState::BROWSING && mDeleteHovered);
		mApp->SetCursor(aClickable ? CURSOR_HAND : CURSOR_POINTER);
	}
	MarkDirty();
}

void ZombatarItems::MouseLeave()
{
	mHoveredItem = -1;
	mDeleteHovered = false;
	mPressedButtonId = -1;
	if (mApp)
		mApp->SetCursor(CURSOR_POINTER);
	MarkDirty();
}

GameButton* ZombatarItems::FindPressedButton() const
{
	for (GameButton* aButton : GetAllButtons(const_cast<ZombatarItems*>(this)))
	{
		if (CanPress(aButton))
			return aButton;
	}
	return nullptr;
}

GameButton* ZombatarItems::HitTestButton(int x, int y) const
{
	for (GameButton* aButton : GetAllButtons(const_cast<ZombatarItems*>(this)))
	{
		if (aButton == nullptr || aButton->mDisabled || aButton->mBtnNoDraw)
			continue;
		if (Rect(aButton->mX, aButton->mY, aButton->mWidth, aButton->mHeight).Contains(x, y))
			return aButton;
	}
	return nullptr;
}

void ZombatarItems::MouseDown(int x, int y, int theClickCount)
{
	// Let Widget translate the legacy click-count convention (1/-1/2) to the
	// explicit button-number overload below.  In particular, a right click
	// must never activate a Zombatar control.
	Widget::MouseDown(x, y, theClickCount);
}

void ZombatarItems::MouseDown(int x, int y, int theBtnNum, int theClickCount)
{
	mPressedButtonId = -1;
	if (theBtnNum == 0 && theClickCount > 0)
	{
		if (GameButton* aButton = HitTestButton(x, y))
			mPressedButtonId = aButton->mId;
	}
	Widget::MouseDown(x, y, theBtnNum, theClickCount);
}

void ZombatarItems::MouseUp(int x, int y, int theLastDownButtonId)
{
	// Widget converts the stored button id back to the explicit overload.  Do
	// not interpret it as a click count: -1 is a right-button release.
	Widget::MouseUp(x, y, theLastDownButtonId);
}

void ZombatarItems::MouseUp(int x, int y, int theBtnNum, int theClickCount)
{
	if (theBtnNum != 0)
	{
		mPressedButtonId = -1;
		return;
	}

	const int aPressedButtonId = mPressedButtonId;
	mPressedButtonId = -1;
	if (aPressedButtonId >= 0)
	{
		for (GameButton* aButton : GetAllButtons(this))
		{
			if (aButton == nullptr || aButton->mId != aPressedButtonId ||
				aButton->mDisabled || aButton->mBtnNoDraw)
				continue;
			if (Rect(aButton->mX, aButton->mY, aButton->mWidth, aButton->mHeight).Contains(x, y))
			{
				ButtonDepress(aPressedButtonId);
			}
			// A press that began on a button is consumed even if the release
			// moved outside it.  This is the normal ButtonWidget semantic and
			// prevents a drag-release from selecting a grid cell underneath.
			return;
		}
	}

	if (mState == ZombatarEditorState::EDITING)
	{
		const int anItemIndex = HitTestItem(x, y);
		if (anItemIndex >= 0)
		{
			mPressedItem = anItemIndex;
			mZombatar.mItems[mCurrentCategory] =
				mItemCells[anItemIndex].mItem
					? mItemCells[anItemIndex].mRawIndex
					: -1;
			SyncColorMode();
			mSelectionChanged = true;
			MarkDirty();
		}
	}
	else if (mState == ZombatarEditorState::BROWSING &&
		mDeleteRect.Contains(x, y))
	{
		PlayerInfo* aPlayer = mApp ? mApp->mPlayerInfo : nullptr;
		if (!aPlayer || aPlayer->mNumZombatars <= 0)
			return;

		const int aResult = mApp->LawnMessageBox(
			Dialogs::DIALOG_DELETEZOMBATAR,
			_S(""),
			_S("Delete this Zombatar?"),
			_S("[DIALOG_BUTTON_YES]"),
			_S("[DIALOG_BUTTON_NO]"),
			Dialog::BUTTONS_YES_NO);
		if (aResult == Dialog::ID_YES)
		{
			aPlayer->DeleteZombatarFromIndex(&mSelectedZombatar);
			aPlayer->SaveDetails();
			if (aPlayer->mNumZombatars <= 0)
			{
				ResetZombatar();
				mState = ZombatarEditorState::EDITING;
			}
			else
			{
				mSelectedZombatar = std::min(
					mSelectedZombatar,
					aPlayer->mNumZombatars - 1);
			}
			RefreshState();
		}
	}
	(void)theClickCount;
}

void ZombatarItems::ButtonDepress(int theId)
{
	switch (theId)
	{
	case BUTTON_NEXT_PAGE:
		mCurrentPage = std::min(mCurrentPage + 1, mPageCount);
		mHoveredItem = -1;
		mPressedItem = -1;
		LayoutCategoryItems();
		break;
	case BUTTON_PREV_PAGE:
		mCurrentPage = std::max(mCurrentPage - 1, 1);
		mHoveredItem = -1;
		mPressedItem = -1;
		LayoutCategoryItems();
		break;
	case BUTTON_BACK:
		if (mState == ZombatarEditorState::CONFIRMATION)
		{
			mState = ZombatarEditorState::LEAVING_CONFIRMATION;
			mTransitionCounter = 180;
			RefreshState();
		}
		break;
	case BUTTON_FINISHED:
		if (mState == ZombatarEditorState::EDITING)
		{
			MoveButton(mFinishedButton, 420, 447);
			mState = ZombatarEditorState::ENTERING_CONFIRMATION;
			mTransitionCounter = 180;
			RefreshState();
		}
		else if (mState == ZombatarEditorState::CONFIRMATION)
		{
			SaveCurrentZombatar();
			mState = ZombatarEditorState::BROWSING;
			RefreshState();
		}
		break;
	case BUTTON_NEW_ZOMBIE:
		if (mState == ZombatarEditorState::BROWSING)
		{
			ResetZombatar();
			mState = ZombatarEditorState::EDITING;
			ResetTransientLayout();
			RefreshState();
		}
		break;
	case BUTTON_NEXT_ZOMBIE:
		if (mApp && mApp->mPlayerInfo)
			mSelectedZombatar = std::min(
				mSelectedZombatar + 1,
				mApp->mPlayerInfo->mNumZombatars - 1);
		RefreshState();
		break;
	case BUTTON_PREV_ZOMBIE:
		mSelectedZombatar = std::max(mSelectedZombatar - 1, 0);
		RefreshState();
		break;
	case BUTTON_MAIN_MENU:
		ReturnToMainMenu();
		break;
	case BUTTON_VIEW:
		if (mApp && mApp->mPlayerInfo && mApp->mPlayerInfo->mNumZombatars > 0)
		{
			mState = ZombatarEditorState::BROWSING;
			mSelectedZombatar = 0;
			RefreshState();
		}
		break;
	case BUTTON_SKIN:
		SetCategory(ZOMBATAR_CUSTOM_SKIN);
		break;
	case BUTTON_HAIR:
		SetCategory(ZOMBATAR_CUSTOM_HAIR);
		break;
	case BUTTON_FACIAL_HAIR:
		SetCategory(ZOMBATAR_CUSTOM_FACIAL_HAIR);
		break;
	case BUTTON_TIDBITS:
		SetCategory(ZOMBATAR_CUSTOM_TIDBITS);
		break;
	case BUTTON_EYEWEAR:
		SetCategory(ZOMBATAR_CUSTOM_EYEWEAR);
		break;
	case BUTTON_CLOTHES:
		SetCategory(ZOMBATAR_CUSTOM_CLOTHES);
		break;
	case BUTTON_ACCESSORIES:
		SetCategory(ZOMBATAR_CUSTOM_ACCESSORIES);
		break;
	case BUTTON_HATS:
		SetCategory(ZOMBATAR_CUSTOM_HATS);
		break;
	case BUTTON_BACKDROPS:
		SetCategory(ZOMBATAR_CUSTOM_BACKDROPS);
		break;
	default:
		break;
	}
	MarkDirty();
}

void ZombatarItems::SaveCurrentZombatar()
{
	PlayerInfo* aPlayer = mApp ? mApp->mPlayerInfo : nullptr;
	if (!aPlayer || aPlayer->mNumZombatars >= MAX_NUM_ZOMBATARS)
		return;

	aPlayer->mZombatars[aPlayer->mNumZombatars] = mZombatar;
	++aPlayer->mNumZombatars;
	mSelectedZombatar = aPlayer->mNumZombatars - 1;
	aPlayer->SaveDetails();
	ExportZombatarJpeg(
		aPlayer->mZombatars[mSelectedZombatar],
		aPlayer->mNumZombatars,
		mApp);
}

void ZombatarItems::ReturnToMainMenu()
{
	ResetZombatar();
	if (mApp && mApp->mGameSelector)
	{
		mApp->mGameSelector->SlideTo(-800, 0);
		if (mApp->mWidgetManager)
			mApp->mWidgetManager->SetFocus(mApp->mGameSelector);
	}
}

bool ZombatarItems::HasVisualSelectionChanged() const
{
	return mSelectionChangedLastFrame ||
		(mColors && mColors->mSelectionChangedLastFrame);
}

const Zombatar& ZombatarItems::GetZombatar() const
{
	return mZombatar;
}
