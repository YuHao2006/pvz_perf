#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace pvz::render::vulkan {

struct PhysicalDeviceInfo {
    std::string name;
    std::uint32_t api_version{0};
    std::uint32_t vendor_id{0};
    std::uint32_t device_id{0};
    std::uint32_t device_type{0};
    std::uint32_t max_texture_dimension_2d{0};
};

class VulkanInstance {
public:
    VulkanInstance();
    ~VulkanInstance();

    VulkanInstance(VulkanInstance&&) noexcept;
    VulkanInstance& operator=(VulkanInstance&&) noexcept;
    VulkanInstance(const VulkanInstance&) = delete;
    VulkanInstance& operator=(const VulkanInstance&) = delete;

    [[nodiscard]] std::uint32_t loader_api_version() const noexcept;
    [[nodiscard]] std::uint32_t instance_api_version() const noexcept;
    [[nodiscard]] const std::vector<PhysicalDeviceInfo>& physical_devices() const noexcept;

private:
    struct Implementation;
    std::unique_ptr<Implementation> implementation_;
};

} // namespace pvz::render::vulkan
