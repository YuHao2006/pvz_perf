// diag25.cpp — t25 段错误定位：最小复现单次调用
#define main t25_main_unused
#include "t25_plant_init.cpp"
#undef main

int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    R3InitPlantDefs();
    R3InitInputs();
    ZBInitImages(); R3InitZombieDefs();
    ResetP(g_inputs[0]);
    printf("start\n");
    for (int t = 0; t < (int)SeedType::NUM_SEED_TYPES; t++)
    {
        ResetP(g_inputs[5]);
        printf("t=%d ...", t);
        g_p.PlantInitialize_B(3, 2, (SeedType)t, SeedType::SEED_NONE);
        printf(" ok\n");
    }
    return 0;
}
