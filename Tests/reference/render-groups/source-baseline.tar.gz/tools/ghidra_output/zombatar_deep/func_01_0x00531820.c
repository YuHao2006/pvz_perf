
/* WARNING: Removing unreachable block (ram,0x005318d6) */

undefined4 * __thiscall FUN_00531820(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 local_60 [4];
  uint local_5c;
  undefined4 local_4c;
  uint local_48;
  undefined1 local_44 [4];
  uint local_40;
  undefined4 local_30;
  uint local_2c;
  uint local_24;
  undefined4 local_14;
  uint local_10;
  void *local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c95fb;
  local_c = ExceptionList;
  local_2c = 0xf;
  local_30 = 0;
  local_40 = local_40 & 0xffffff00;
  ExceptionList = &local_c;
  FUN_004020c0(&DAT_006e346c,0);
  local_4 = 0;
  local_48 = 0xf;
  local_4c = 0;
  local_5c = local_5c & 0xffffff00;
  FUN_004020c0(&DAT_006e346c,0);
  local_4._0_1_ = 1;
  FUN_004020c0("Zombatar",8);
  local_4 = CONCAT31(local_4._1_3_,2);
  FUN_0045a3b0(param_2,param_1,0x33,1,local_60,local_44,0);
  if (0xf < local_48) {
    FUN_00699e4a(local_5c);
  }
  local_48 = 0xf;
  local_4c = 0;
  local_5c = local_5c & 0xffffff00;
  local_4._0_1_ = 6;
  if (0xf < local_2c) {
    FUN_00699e4a(local_40);
  }
  local_2c = 0xf;
  local_30 = 0;
  local_40 = local_40 & 0xffffff00;
  *param_2 = &PTR_FUN_006f2b00;
  param_2[0x28] = &PTR_FUN_006f2c38;
  param_2[0x61] = param_1;
  local_10 = 0xf;
  local_14 = 0;
  local_24 = local_24 & 0xffffff00;
  FUN_004020c0("DelayLoad_Almanac",0x11);
  local_4._0_1_ = 7;
  FUN_0051d4c0();
  local_4._0_1_ = 6;
  if (0xf < local_10) {
    FUN_00699e4a(local_24);
  }
  local_10 = 0xf;
  local_14 = 0;
  local_24 = local_24 & 0xffffff00;
  FUN_004020c0("DelayLoad_Zombatar",0x12);
  local_4._0_1_ = 8;
  FUN_0051d4c0();
  local_4._0_1_ = 6;
  if (0xf < local_10) {
    FUN_00699e4a(local_24);
  }
  param_2[99] = 0x50;
  param_2[100] = 0x15e;
  param_2[0x62] = 0;
  iVar1 = FUN_00699ed2(0xf80);
  local_4._0_1_ = 9;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0052d550(iVar1);
  }
  local_4 = CONCAT31(local_4._1_3_,6);
  param_2[0x65] = uVar2;
  FUN_00547c30(uVar2);
  ExceptionList = local_c;
  return param_2;
}

