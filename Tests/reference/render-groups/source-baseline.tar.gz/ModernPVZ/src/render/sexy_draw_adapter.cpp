#include "pvz/render/sexy_draw_adapter.hpp"

#include <array>
#include <cmath>
#include <stdexcept>
#include <vector>

namespace pvz::render {
namespace {

[[nodiscard]] Point2D rotate_about(const Point2D point, const Point2D center, const double radians)
{
    const double sine = std::sin(radians);
    const double cosine = std::cos(radians);
    const double x = point.x - center.x;
    const double y = point.y - center.y;
    return {
        center.x + x * cosine - y * sine,
        center.y + x * sine + y * cosine,
    };
}

} // namespace

void SexyDrawCommandAdapter::set_texture_address_modes(
    const TextureAddressMode address_u,
    const TextureAddressMode address_v) noexcept
{
    sampling_state_.address_u = address_u;
    sampling_state_.address_v = address_v;
}

void SexyDrawCommandAdapter::set_filter(const TextureFilter filter) noexcept
{
    sampling_state_.filter = filter;
}

SamplingState SexyDrawCommandAdapter::sampling_state() const noexcept
{
    return sampling_state_;
}

SamplingState SexyDrawCommandAdapter::sampling_for(const bool linear_filter) const noexcept
{
    SamplingState result = sampling_state_;
    result.filter = linear_filter ? TextureFilter::linear : TextureFilter::nearest;
    return result;
}

void SexyDrawCommandAdapter::blt(
    const TextureRegion& source,
    const Point2D top_left,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const bool linear_filter)
{
    if (source.source_pixels.extent.width <= 0.0 || source.source_pixels.extent.height <= 0.0)
        throw std::invalid_argument("Blt source extent must be positive");
    recorder_.draw_sprite(
        source,
        {top_left, source.source_pixels.extent},
        rgba,
        blend_mode,
        logical_scissor,
        sampling_for(linear_filter));
}

void SexyDrawCommandAdapter::blt_mirror(
    const TextureRegion& source,
    const Point2D top_left,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const bool linear_filter)
{
    if (source.source_pixels.extent.width <= 0.0 || source.source_pixels.extent.height <= 0.0)
        throw std::invalid_argument("BltMirror source extent must be positive");
    recorder_.draw_sprite(
        source,
        {top_left, source.source_pixels.extent},
        rgba,
        blend_mode,
        logical_scissor,
        sampling_for(linear_filter),
        true,
        false);
}

void SexyDrawCommandAdapter::stretch_blt(
    const TextureRegion& source,
    const Rect2D destination,
    const Rect2D source_pixels,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const bool fast_stretch,
    const bool mirror_x)
{
    TextureRegion region = source;
    region.source_pixels = source_pixels;
    recorder_.draw_sprite(
        region,
        destination,
        rgba,
        blend_mode,
        logical_scissor,
        sampling_for(!fast_stretch),
        mirror_x,
        false);
}

void SexyDrawCommandAdapter::blt_rotated(
    const TextureRegion& source,
    const Point2D top_left,
    const double radians,
    const Point2D rotation_center,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor)
{
    if (source.source_pixels.extent.width <= 0.0 || source.source_pixels.extent.height <= 0.0)
        throw std::invalid_argument("BltRotated source extent must be positive");
    const double right = top_left.x + source.source_pixels.extent.width;
    const double bottom = top_left.y + source.source_pixels.extent.height;
    const std::array positions{
        rotate_about(top_left, {top_left.x + rotation_center.x, top_left.y + rotation_center.y}, radians),
        rotate_about(
            {right, top_left.y},
            {top_left.x + rotation_center.x, top_left.y + rotation_center.y},
            radians),
        rotate_about(
            {right, bottom},
            {top_left.x + rotation_center.x, top_left.y + rotation_center.y},
            radians),
        rotate_about(
            {top_left.x, bottom},
            {top_left.x + rotation_center.x, top_left.y + rotation_center.y},
            radians),
    };
    recorder_.draw_sprite_quad(
        source,
        positions,
        rgba,
        blend_mode,
        logical_scissor,
        sampling_for(true));
}

void SexyDrawCommandAdapter::fill_rect(
    const Rect2D destination,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor)
{
    recorder_.fill_rect(destination, rgba, blend_mode, logical_scissor);
}

void SexyDrawCommandAdapter::draw_triangles_tex(
    const TextureHandle texture,
    const std::span<const Vertex2D> vertices,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const bool linear_filter)
{
    if (rgba != 0xFFFFFFFF) {
        // D3D7 multiplies the per-vertex color by the current draw color. Keep
        // that operation explicit before handing the vertices to Vulkan.
        std::vector<Vertex2D> modulated(vertices.begin(), vertices.end());
        for (Vertex2D& vertex : modulated) {
            const auto multiply = [](const std::uint32_t left, const std::uint32_t right) {
                return static_cast<std::uint32_t>((left * right + 127U) / 255U);
            };
            const std::uint32_t r = multiply(vertex.rgba & 0xFFU, rgba & 0xFFU);
            const std::uint32_t g = multiply((vertex.rgba >> 8U) & 0xFFU, (rgba >> 8U) & 0xFFU);
            const std::uint32_t b = multiply((vertex.rgba >> 16U) & 0xFFU, (rgba >> 16U) & 0xFFU);
            const std::uint32_t a = multiply((vertex.rgba >> 24U) & 0xFFU, (rgba >> 24U) & 0xFFU);
            vertex.rgba = r | (g << 8U) | (b << 16U) | (a << 24U);
        }
        recorder_.draw_triangle_list(
            texture,
            modulated,
            blend_mode,
            logical_scissor,
            sampling_for(linear_filter));
        return;
    }
    recorder_.draw_triangle_list(
        texture,
        vertices,
        blend_mode,
        logical_scissor,
        sampling_for(linear_filter));
}

} // namespace pvz::render
