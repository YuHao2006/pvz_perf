
void __thiscall FUN_0054c890(int param_1,int param_2)

{
  if (param_2 == 9) {
    if (*(char *)(*(int *)(param_1 + 0x20) + 300) == '\0') {
      if (*(int *)(param_1 + 0x9c) != 0) {
        (**(code **)(**(int **)(param_1 + 0x20) + 0x20))(*(undefined4 *)(param_1 + 0x9c));
      }
    }
    else if (*(int *)(param_1 + 0x98) != 0) {
      (**(code **)(**(int **)(param_1 + 0x20) + 0x20))(*(undefined4 *)(param_1 + 0x98));
    }
  }
  return;
}

