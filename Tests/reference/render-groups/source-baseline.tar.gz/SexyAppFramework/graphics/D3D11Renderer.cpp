#include "D3D11Renderer.h"

#include <cstdio>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")

namespace Sexy
{

namespace
{

const char* kVertexShaderSrc =
	"cbuffer CB : register(b0) {\n"
	"	float2 ViewportSize;\n"
	"};\n"
	"struct VSIn {\n"
	"	float2 Pos : POSITION;\n"
	"	float4 Color : COLOR0;\n"
	"	float2 UV : TEXCOORD0;\n"
	"};\n"
	"struct VSOut {\n"
	"	float4 Pos : SV_Position;\n"
	"	float4 Color : COLOR0;\n"
	"	float2 UV : TEXCOORD0;\n"
	"};\n"
	"VSOut main(VSIn input) {\n"
	"	VSOut output;\n"
	"	output.Pos = float4(input.Pos.x / ViewportSize.x * 2.0 - 1.0,\n"
	"	                   -(input.Pos.y / ViewportSize.y * 2.0 - 1.0), 0.0, 1.0);\n"
	"	output.Color = input.Color;\n"
	"	output.UV = input.UV;\n"
	"	return output;\n"
	"}\n";

const char* kPixelShaderSrc =
	"Texture2D Tex : register(t0);\n"
	"SamplerState Sam : register(s0);\n"
	"struct PSIn {\n"
	"	float4 Pos : SV_Position;\n"
	"	float4 Color : COLOR0;\n"
	"	float2 UV : TEXCOORD0;\n"
	"};\n"
	"float4 main(PSIn input) : SV_Target {\n"
	"	return Tex.Sample(Sam, input.UV) * input.Color;\n"
	"}\n";

} // namespace

D3D11Renderer::D3D11Renderer()
	: mDevice(nullptr),
	mContext(nullptr),
	mSwapChain(nullptr),
	mSceneTexture(nullptr),
	mSceneRTV(nullptr),
	mSceneSRV(nullptr),
	mBackBufferRTV(nullptr),
	mVertexShader(nullptr),
	mPixelShader(nullptr),
	mInputLayout(nullptr),
	mConstantBuffer(nullptr),
	mVertexBuffer(nullptr),
	mVertexBufferCapacity(0),
	mVertexWriteOffset(0),
	mConstantViewportWidth(-1),
	mConstantViewportHeight(-1),
	mSceneWidth(0),
	mSceneHeight(0),
	mPresentWidth(0),
	mPresentHeight(0),
	mBlendNormal(nullptr),
	mBlendAdditive(nullptr),
	mSamplerPoint(nullptr),
	mSamplerLinear(nullptr),
	mSamplerPointWrap(nullptr),
	mSamplerLinearWrap(nullptr),
	mWhiteSRV(nullptr),
	mRasterizer(nullptr),
	mPresentSRVTexture(nullptr),
	mPresentSRV(nullptr),
	mBoundPSRV(nullptr),
	mBoundSampler(nullptr),
	mBoundBlend(nullptr),
	mScissorValid(false),
	mBoundScissor{}
{
}

D3D11Renderer::~D3D11Renderer()
{
	Shutdown();
}

void D3D11Renderer::Shutdown()
{
	ReleasePresentSRVCache();
	if (mBlendNormal != nullptr) mBlendNormal->Release();
	if (mBlendAdditive != nullptr) mBlendAdditive->Release();
	if (mSamplerPoint != nullptr) mSamplerPoint->Release();
	if (mSamplerLinear != nullptr) mSamplerLinear->Release();
	if (mSamplerPointWrap != nullptr) mSamplerPointWrap->Release();
	if (mSamplerLinearWrap != nullptr) mSamplerLinearWrap->Release();
	if (mWhiteSRV != nullptr) mWhiteSRV->Release();
	if (mRasterizer != nullptr) mRasterizer->Release();
	if (mVertexBuffer != nullptr) mVertexBuffer->Release();
	if (mConstantBuffer != nullptr) mConstantBuffer->Release();
	if (mInputLayout != nullptr) mInputLayout->Release();
	if (mPixelShader != nullptr) mPixelShader->Release();
	if (mVertexShader != nullptr) mVertexShader->Release();
	if (mBackBufferRTV != nullptr) mBackBufferRTV->Release();
	if (mSceneSRV != nullptr) mSceneSRV->Release();
	if (mSceneRTV != nullptr) mSceneRTV->Release();
	if (mSceneTexture != nullptr) mSceneTexture->Release();
	if (mSwapChain != nullptr) mSwapChain->Release();
	if (mContext != nullptr) mContext->Release();
	if (mDevice != nullptr) mDevice->Release();
	mDevice = nullptr;
	mContext = nullptr;
	mSwapChain = nullptr;
	mSceneTexture = nullptr;
	mSceneRTV = nullptr;
	mSceneSRV = nullptr;
	mBackBufferRTV = nullptr;
	mVertexShader = nullptr;
	mPixelShader = nullptr;
	mInputLayout = nullptr;
	mConstantBuffer = nullptr;
	mVertexBuffer = nullptr;
	mVertexWriteOffset = 0;
	mConstantViewportWidth = -1;
	mConstantViewportHeight = -1;
	mBlendNormal = nullptr;
	mBlendAdditive = nullptr;
	mSamplerPoint = nullptr;
	mSamplerLinear = nullptr;
	mSamplerPointWrap = nullptr;
	mSamplerLinearWrap = nullptr;
	mWhiteSRV = nullptr;
	mRasterizer = nullptr;
	mPresentSRVTexture = nullptr;
	mPresentSRV = nullptr;
	mBoundPSRV = nullptr;
	mBoundSampler = nullptr;
	mBoundBlend = nullptr;
	mScissorValid = false;
	ZeroMemory(&mBoundScissor, sizeof(mBoundScissor));
}

bool D3D11Renderer::CreateDeviceAndSwapChain(HWND theHWnd, int thePresentWidth, int thePresentHeight)
{
	D3D_FEATURE_LEVEL aLevels[] =
	{
		D3D_FEATURE_LEVEL_11_0,
		D3D_FEATURE_LEVEL_10_1,
		D3D_FEATURE_LEVEL_10_0
	};
	D3D_FEATURE_LEVEL aCreatedLevel;
	if (FAILED(D3D11CreateDevice(
			nullptr,
			D3D_DRIVER_TYPE_HARDWARE,
			nullptr,
			D3D11_CREATE_DEVICE_BGRA_SUPPORT,
			aLevels,
			3,
			D3D11_SDK_VERSION,
			&mDevice,
			&aCreatedLevel,
			&mContext)))
		return false;

	IDXGIFactory1* aFactory = nullptr;
	if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&aFactory)))
		return false;

	DXGI_SWAP_CHAIN_DESC aDesc;
	ZeroMemory(&aDesc, sizeof(aDesc));
	aDesc.BufferDesc.Width = thePresentWidth;
	aDesc.BufferDesc.Height = thePresentHeight;
	aDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	aDesc.BufferDesc.RefreshRate.Numerator = 0;
	aDesc.BufferDesc.RefreshRate.Denominator = 1;
	aDesc.SampleDesc.Count = 1;
	aDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	aDesc.BufferCount = 1;
	aDesc.OutputWindow = theHWnd;
	aDesc.Windowed = TRUE;
	aDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	HRESULT aResult = aFactory->CreateSwapChain(mDevice, &aDesc, &mSwapChain);
	aFactory->Release();
	if (FAILED(aResult))
		return false;

	mPresentWidth = thePresentWidth;
	mPresentHeight = thePresentHeight;
	return true;
}

bool D3D11Renderer::CreateSceneTarget(int theSceneWidth, int theSceneHeight)
{
	D3D11_TEXTURE2D_DESC aDesc;
	ZeroMemory(&aDesc, sizeof(aDesc));
	aDesc.Width = theSceneWidth;
	aDesc.Height = theSceneHeight;
	aDesc.MipLevels = 1;
	aDesc.ArraySize = 1;
	// Atlas pieces come from D3D9 A8R8G8B8 memory (BGRA byte order).
	aDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
	aDesc.SampleDesc.Count = 1;
	aDesc.Usage = D3D11_USAGE_DEFAULT;
	aDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	if (FAILED(mDevice->CreateTexture2D(&aDesc, nullptr, &mSceneTexture)))
		return false;
	if (FAILED(mDevice->CreateRenderTargetView(mSceneTexture, nullptr, &mSceneRTV)))
		return false;
	if (FAILED(mDevice->CreateShaderResourceView(mSceneTexture, nullptr, &mSceneSRV)))
		return false;
	mSceneWidth = theSceneWidth;
	mSceneHeight = theSceneHeight;
	return true;
}

bool D3D11Renderer::ResizeSwapChain(int aWidth, int aHeight)
{
	if (mSwapChain == nullptr || mContext == nullptr || aWidth <= 0 || aHeight <= 0)
		return false;

	// The back buffer is normally still bound as the render target after the
	// previous EndSceneAndPresent. ResizeBuffers requires every reference to
	// the back buffer to be released and the context to be idle; otherwise it
	// returns DXGI_ERROR_INVALID_CALL (or the driver stalls), leaving the
	// window at the new size but the swapchain at the old size.  Keep this
	// local guard as well as the caller-side transition guard: WM_SIZE can
	// arrive asynchronously while a mode switch is in progress.
	PrepareForResize();

	if (mBackBufferRTV != nullptr)
	{
		mBackBufferRTV->Release();
		mBackBufferRTV = nullptr;
	}
	HRESULT aResult = mSwapChain->ResizeBuffers(
		1, (UINT)aWidth, (UINT)aHeight, DXGI_FORMAT_R8G8B8A8_UNORM, 0);
	if (FAILED(aResult))
	{
		FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "ResizeSwapChain failed hr=0x%08lx size=%dx%d\n",
				(unsigned long)aResult, aWidth, aHeight);
			fclose(aLog);
		}
		return false;
	}
	ID3D11Texture2D* aBackBuffer = nullptr;
	if (FAILED(mSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&aBackBuffer)))
		return false;
	HRESULT aRtvResult = mDevice->CreateRenderTargetView(aBackBuffer, nullptr, &mBackBufferRTV);
	aBackBuffer->Release();
	if (SUCCEEDED(aRtvResult))
	{
		mPresentWidth = aWidth;
		mPresentHeight = aHeight;
	}
	return SUCCEEDED(aRtvResult);
}

void D3D11Renderer::PrepareForResize()
{
	if (mContext == nullptr)
		return;

	// ClearState is deliberately used here instead of only unbinding the
	// output-merger.  The scale runtime uses compute UAVs/SRVs, while the game
	// uses pixel-stage SRVs; either stage can retain a reference to a resource
	// owned by the swapchain transition.  ClearState is a mode-switch-only
	// operation and all state needed for drawing is explicitly restored by
	// BeginScene/SubmitTriangles.
	mContext->ClearState();
	mContext->Flush();
	ReleasePresentSRVCache();
	mBoundPSRV = nullptr;
	mBoundSampler = nullptr;
	mBoundBlend = nullptr;
	mScissorValid = false;
}

void D3D11Renderer::ReleasePresentSRVCache()
{
	if (mPresentSRV != nullptr)
	{
		mPresentSRV->Release();
		mPresentSRV = nullptr;
	}
	if (mPresentSRVTexture != nullptr)
	{
		mPresentSRVTexture->Release();
		mPresentSRVTexture = nullptr;
	}
}

bool D3D11Renderer::WarmScalePresent()
{
	if (mScalePresentFn == nullptr || mSceneTexture == nullptr)
		return false;

	int aOutW = mPresentWidth;
	int aOutH = mPresentHeight;
	ID3D11Texture2D* aScaled = mScalePresentFn(
		mSceneTexture, mSceneWidth, mSceneHeight, aOutW, aOutH);
	if (aScaled == nullptr)
		return false;

	// The callback returns an AddRef'd texture by contract.  No copy or CPU
	// readback is needed for the warm-up; releasing it here leaves all shader,
	// sampler and intermediate resources cached in the runtime.
	aScaled->Release();
	return true;
}

bool D3D11Renderer::CreateShadersAndStates()
{
	ID3DBlob* aVSBlob = nullptr;
	ID3DBlob* aError = nullptr;
	if (FAILED(D3DCompile(
			kVertexShaderSrc,
			strlen(kVertexShaderSrc),
			"quad_vs",
			nullptr,
			nullptr,
			"main",
			"vs_4_0",
			D3DCOMPILE_OPTIMIZATION_LEVEL3,
			0,
			&aVSBlob,
			&aError)))
	{
		if (aError != nullptr)
			aError->Release();
		return false;
	}

	ID3DBlob* aPSBlob = nullptr;
	aError = nullptr;
	if (FAILED(D3DCompile(
			kPixelShaderSrc,
			strlen(kPixelShaderSrc),
			"quad_ps",
			nullptr,
			nullptr,
			"main",
			"ps_4_0",
			D3DCOMPILE_OPTIMIZATION_LEVEL3,
			0,
			&aPSBlob,
			&aError)))
	{
		if (aError != nullptr)
			aError->Release();
		aVSBlob->Release();
		return false;
	}

	if (FAILED(mDevice->CreateVertexShader(aVSBlob->GetBufferPointer(), aVSBlob->GetBufferSize(), nullptr, &mVertexShader)) ||
		FAILED(mDevice->CreatePixelShader(aPSBlob->GetBufferPointer(), aPSBlob->GetBufferSize(), nullptr, &mPixelShader)))
	{
		aPSBlob->Release();
		aVSBlob->Release();
		return false;
	}

	D3D11_INPUT_ELEMENT_DESC aElements[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 8, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 24, D3D11_INPUT_PER_VERTEX_DATA, 0 }
	};
	if (FAILED(mDevice->CreateInputLayout(
			aElements,
			3,
			aVSBlob->GetBufferPointer(),
			aVSBlob->GetBufferSize(),
			&mInputLayout)))
	{
		aPSBlob->Release();
		aVSBlob->Release();
		return false;
	}
	aPSBlob->Release();
	aVSBlob->Release();

	D3D11_BUFFER_DESC aCBDesc;
	ZeroMemory(&aCBDesc, sizeof(aCBDesc));
	aCBDesc.ByteWidth = 16;
	aCBDesc.Usage = D3D11_USAGE_DEFAULT;
	aCBDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	if (FAILED(mDevice->CreateBuffer(&aCBDesc, nullptr, &mConstantBuffer)))
		return false;

	D3D11_BUFFER_DESC aVBDesc;
	ZeroMemory(&aVBDesc, sizeof(aVBDesc));
	// The old 4096-vertex buffer was repeatedly DISCARD-mapped once per
	// sprite/particle.  A long Survival wave could exhaust the driver's
	// rename queue and block in D3DKMTOpenResource for hundreds of ms.  A
	// larger stream lets this frame append with NO_OVERWRITE instead.
	aVBDesc.ByteWidth = sizeof(D3D11Vertex) * 262144;
	aVBDesc.Usage = D3D11_USAGE_DYNAMIC;
	aVBDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	aVBDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	if (FAILED(mDevice->CreateBuffer(&aVBDesc, nullptr, &mVertexBuffer)))
		return false;
	mVertexBufferCapacity = 262144;
	mVertexWriteOffset = 0;
	mConstantViewportWidth = -1;
	mConstantViewportHeight = -1;

	D3D11_BLEND_DESC aBlendDesc;
	ZeroMemory(&aBlendDesc, sizeof(aBlendDesc));
	aBlendDesc.AlphaToCoverageEnable = FALSE;
	aBlendDesc.RenderTarget[0].BlendEnable = TRUE;
	aBlendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	aBlendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
	aBlendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	aBlendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
	aBlendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
	aBlendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	aBlendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
	if (FAILED(mDevice->CreateBlendState(&aBlendDesc, &mBlendNormal)))
		return false;

	aBlendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
	if (FAILED(mDevice->CreateBlendState(&aBlendDesc, &mBlendAdditive)))
		return false;

	D3D11_SAMPLER_DESC aSamplerDesc;
	ZeroMemory(&aSamplerDesc, sizeof(aSamplerDesc));
	aSamplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
	aSamplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	aSamplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	aSamplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	aSamplerDesc.MaxLOD = FLT_MAX;
	if (FAILED(mDevice->CreateSamplerState(&aSamplerDesc, &mSamplerPoint)))
		return false;
	aSamplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	if (FAILED(mDevice->CreateSamplerState(&aSamplerDesc, &mSamplerLinear)))
		return false;
	aSamplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	aSamplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	aSamplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	aSamplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
	if (FAILED(mDevice->CreateSamplerState(&aSamplerDesc, &mSamplerPointWrap)))
		return false;
	aSamplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	if (FAILED(mDevice->CreateSamplerState(&aSamplerDesc, &mSamplerLinearWrap)))
		return false;

	// 1x1 white texture for solid-color draws (no texture bound).
	uint32_t aWhitePixel = 0xFFFFFFFF;
	D3D11_SUBRESOURCE_DATA aWhiteData;
	ZeroMemory(&aWhiteData, sizeof(aWhiteData));
	aWhiteData.pSysMem = &aWhitePixel;
	aWhiteData.SysMemPitch = 4;
	D3D11_TEXTURE2D_DESC aWhiteDesc;
	ZeroMemory(&aWhiteDesc, sizeof(aWhiteDesc));
	aWhiteDesc.Width = 1;
	aWhiteDesc.Height = 1;
	aWhiteDesc.MipLevels = 1;
	aWhiteDesc.ArraySize = 1;
	aWhiteDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	aWhiteDesc.SampleDesc.Count = 1;
	aWhiteDesc.Usage = D3D11_USAGE_DEFAULT;
	aWhiteDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	ID3D11Texture2D* aWhiteTexture = nullptr;
	if (FAILED(mDevice->CreateTexture2D(&aWhiteDesc, &aWhiteData, &aWhiteTexture)))
		return false;
	const HRESULT aWhiteSRVResult = mDevice->CreateShaderResourceView(aWhiteTexture, nullptr, &mWhiteSRV);
	aWhiteTexture->Release();
	if (FAILED(aWhiteSRVResult))
		return false;

	// No culling (the game's D3D9 path never culls and our Y-flip reverses
	// winding), and enable scissor so clip rects work.
	D3D11_RASTERIZER_DESC aRasterDesc;
	ZeroMemory(&aRasterDesc, sizeof(aRasterDesc));
	aRasterDesc.FillMode = D3D11_FILL_SOLID;
	aRasterDesc.CullMode = D3D11_CULL_NONE;
	aRasterDesc.ScissorEnable = FALSE;
	if (FAILED(mDevice->CreateRasterizerState(&aRasterDesc, &mRasterizer)))
		return false;

	return true;
}

bool D3D11Renderer::Init(HWND theHWnd, int theSceneWidth, int theSceneHeight, int thePresentWidth, int thePresentHeight)
{
	if (mDevice != nullptr)
	{
		// A previous partial initialization is not an initialized renderer.
		// Returning true merely because the device exists hides whichever later
		// object failed to be created.
		return mContext != nullptr && mSwapChain != nullptr &&
			mSceneTexture != nullptr && mSceneRTV != nullptr && mSceneSRV != nullptr &&
			mBackBufferRTV != nullptr && mVertexShader != nullptr && mPixelShader != nullptr &&
			mInputLayout != nullptr && mConstantBuffer != nullptr && mVertexBuffer != nullptr &&
			mBlendNormal != nullptr && mBlendAdditive != nullptr &&
			mSamplerPoint != nullptr && mSamplerLinear != nullptr &&
			mSamplerPointWrap != nullptr && mSamplerLinearWrap != nullptr &&
			mWhiteSRV != nullptr && mRasterizer != nullptr;
	}
	if (!CreateDeviceAndSwapChain(theHWnd, thePresentWidth, thePresentHeight))
		return false;
	if (!CreateShadersAndStates())
		return false;
	if (!CreateSceneTarget(theSceneWidth, theSceneHeight))
		return false;

	ID3D11Texture2D* aBackBuffer = nullptr;
	if (FAILED(mSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&aBackBuffer)))
		return false;
	HRESULT aResult = mDevice->CreateRenderTargetView(aBackBuffer, nullptr, &mBackBufferRTV);
	aBackBuffer->Release();
	if (FAILED(aResult))
		return false;
	return true;
}

ID3D11ShaderResourceView* D3D11Renderer::CreateTextureSRV(int theWidth, int theHeight, const void* theBits, int thePitch, bool theOpaque)
{
	if (theWidth <= 0 || theHeight <= 0 || theBits == nullptr || thePitch <= 0)
		return nullptr;
	D3D11_TEXTURE2D_DESC aDesc;
	ZeroMemory(&aDesc, sizeof(aDesc));
	aDesc.Width = theWidth;
	aDesc.Height = theHeight;
	aDesc.MipLevels = 1;
	aDesc.ArraySize = 1;
	// Atlas pieces come from A8R8G8B8 memory (BGRA byte order). Opaque images
	// use B8G8R8X8 (alpha ignored); D3D11 has no true 24-bit texture format,
	// so storage stays 32-bit either way.
	aDesc.Format = theOpaque ? DXGI_FORMAT_B8G8R8X8_UNORM : DXGI_FORMAT_B8G8R8A8_UNORM;
	aDesc.SampleDesc.Count = 1;
	aDesc.Usage = D3D11_USAGE_DEFAULT;
	aDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

	D3D11_SUBRESOURCE_DATA aData;
	ZeroMemory(&aData, sizeof(aData));
	aData.pSysMem = theBits;
	aData.SysMemPitch = thePitch;

	ID3D11Texture2D* aTexture = nullptr;
	if (FAILED(mDevice->CreateTexture2D(&aDesc, &aData, &aTexture)))
		return nullptr;
	ID3D11ShaderResourceView* aSRV = nullptr;
	if (FAILED(mDevice->CreateShaderResourceView(aTexture, nullptr, &aSRV)))
	{
		aTexture->Release();
		return nullptr;
	}
	aTexture->Release();
	return aSRV;
}

void D3D11Renderer::BeginScene()
{
	// The previous frame has been submitted to the GPU.  DISCARD on the first
	// map of this frame gives the driver a fresh backing allocation; subsequent
	// submissions append without invalidating vertices still referenced by
	// earlier draws in this same frame.
	mVertexWriteOffset = 0;
	ID3D11ShaderResourceView* aNullPSRV = nullptr;
	mContext->PSSetShaderResources(0, 1, &aNullPSRV);
	// Resource/state caches are frame-local.  Texture objects can be lazily
	// rebuilt between frames, so carrying raw interface pointers across a frame
	// boundary would be both incorrect and slower than one predictable bind.
	mBoundPSRV = nullptr;
	mBoundSampler = nullptr;
	mBoundBlend = nullptr;
	mScissorValid = false;
	mContext->RSSetState(mRasterizer);
	mContext->OMSetRenderTargets(1, &mSceneRTV, nullptr);
	D3D11_VIEWPORT aViewport = { 0, 0, (float)mSceneWidth, (float)mSceneHeight, 0.0f, 1.0f };
	mContext->RSSetViewports(1, &aViewport);
	float aClear[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	mContext->ClearRenderTargetView(mSceneRTV, aClear);
}

void D3D11Renderer::ApplyDrawMode(int theDrawMode)
{
	// DrawMode values from Graphics.h; NORMAL=0, ADDITIVE=1, plus mask modes.
	ID3D11BlendState* aBlend = (theDrawMode == 1) ? mBlendAdditive : mBlendNormal;
	if (mBoundBlend != aBlend)
	{
		mContext->OMSetBlendState(aBlend, nullptr, 0xFFFFFFFF);
		mBoundBlend = aBlend;
	}
}

void D3D11Renderer::SubmitTriangles(
	const D3D11Vertex* theVertices,
	int theNumVertices,
	ID3D11ShaderResourceView* theSRV,
	bool theLinearFilter,
	bool theWrap,
	int theDrawMode,
	const Rect* theClipRect,
	int theViewportWidth,
	int theViewportHeight)
{
	if (theNumVertices <= 0)
		return;
	if (theNumVertices > mVertexBufferCapacity)
	{
		RaiseException(0xE000D320, EXCEPTION_NONCONTINUABLE, 0, nullptr);
		return;
	}
	// A missing image SRV is an upload/lifetime error.  The old white-texture
	// substitution made failed atlas uploads look like valid rendering and
	// concealed the actual missing resource.
	ID3D11ShaderResourceView* aSRV = theSRV;
	if (aSRV == nullptr)
	{
		RaiseException(0xE000D321, EXCEPTION_NONCONTINUABLE, 0, nullptr);
		return;
	}

	if (mVertexWriteOffset + static_cast<unsigned int>(theNumVertices) >
		static_cast<unsigned int>(mVertexBufferCapacity))
	{
		// Discarding here would invalidate draws already issued in this frame.
		// Expose the capacity violation instead of silently corrupting the frame.
		RaiseException(0xE000D322, EXCEPTION_NONCONTINUABLE, 0, nullptr);
		return;
	}
	const unsigned int aWriteOffset = mVertexWriteOffset;
	const D3D11_MAP aMapMode = (aWriteOffset == 0)
		? D3D11_MAP_WRITE_DISCARD
		: D3D11_MAP_WRITE_NO_OVERWRITE;
	D3D11_MAPPED_SUBRESOURCE aMapped;
	if (FAILED(mContext->Map(mVertexBuffer, 0, aMapMode, 0, &aMapped)))
	{
		RaiseException(0xE000D323, EXCEPTION_NONCONTINUABLE, 0, nullptr);
		return;
	}
	memcpy(static_cast<unsigned char*>(aMapped.pData) +
		aWriteOffset * sizeof(D3D11Vertex), theVertices,
		sizeof(D3D11Vertex) * theNumVertices);
	mContext->Unmap(mVertexBuffer, 0);

	UINT aStride = sizeof(D3D11Vertex);
	UINT anOffset = 0;
	// These immutable pipeline objects are installed once per frame.  The
	// original path set all of them for every sprite, which made the CPU spend
	// more time issuing redundant state calls than submitting vertices.
	if (aWriteOffset == 0)
	{
		mContext->IASetVertexBuffers(0, 1, &mVertexBuffer, &aStride, &anOffset);
		mContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
		mContext->IASetInputLayout(mInputLayout);
		mContext->VSSetShader(mVertexShader, nullptr, 0);
		mContext->PSSetShader(mPixelShader, nullptr, 0);
	}
	if (mBoundPSRV != aSRV)
	{
		mContext->PSSetShaderResources(0, 1, &aSRV);
		mBoundPSRV = aSRV;
	}
	ID3D11SamplerState* aSampler =
		theLinearFilter
			? (theWrap ? mSamplerLinearWrap : mSamplerLinear)
			: (theWrap ? mSamplerPointWrap : mSamplerPoint);
	if (mBoundSampler != aSampler)
	{
		mContext->PSSetSamplers(0, 1, &aSampler);
		mBoundSampler = aSampler;
	}

	if (mConstantViewportWidth != theViewportWidth ||
		mConstantViewportHeight != theViewportHeight)
	{
		float aViewportData[2] = { (float)theViewportWidth, (float)theViewportHeight };
		mContext->UpdateSubresource(mConstantBuffer, 0, nullptr, aViewportData, 0, 0);
		mConstantViewportWidth = theViewportWidth;
		mConstantViewportHeight = theViewportHeight;
	}
	mContext->VSSetConstantBuffers(0, 1, &mConstantBuffer);

	ApplyDrawMode(theDrawMode);

	D3D11_RECT aScissor;
	if (theClipRect != nullptr)
	{
		aScissor = {
			(LONG)theClipRect->mX,
			(LONG)theClipRect->mY,
			(LONG)(theClipRect->mX + theClipRect->mWidth),
			(LONG)(theClipRect->mY + theClipRect->mHeight)
		};
	}
	else
	{
		aScissor = { 0, 0, theViewportWidth, theViewportHeight };
	}
	if (!mScissorValid || memcmp(&mBoundScissor, &aScissor, sizeof(aScissor)) != 0)
	{
		mContext->RSSetScissorRects(1, &aScissor);
		mBoundScissor = aScissor;
		mScissorValid = true;
	}

	mContext->Draw(theNumVertices, aWriteOffset);
	mVertexWriteOffset = aWriteOffset + static_cast<unsigned int>(theNumVertices);

}

void D3D11Renderer::EndSceneAndPresent()
{
	// Release the last sprite SRV before switching to the compute/present
	// stages.  Keeping it bound across frames is unnecessary and would retain
	// lazily rebuilt image resources; one unbind here is cheaper than an
	// unbind after every draw.
	if (mBoundPSRV != nullptr)
	{
		ID3D11ShaderResourceView* aNullSRV = nullptr;
		mContext->PSSetShaderResources(0, 1, &aNullSRV);
		mBoundPSRV = nullptr;
	}
	// Run the custom-scale pipeline (if enabled) over the finished scene
	// texture, then present whichever texture came out at the target size.
	int aOutW = mPresentWidth;
	int aOutH = mPresentHeight;
	ID3D11Texture2D* aScaled = nullptr;
	const bool aScaleCallbackInstalled = (bool)mScalePresentFn;
	if (aScaleCallbackInstalled)
	{
		// Unbind the scene render target first: D3D11 rejects sampling a
		// texture that is still bound as a render target on the same context
		// (undefined/black output).
		ID3D11RenderTargetView* aNullRTV[1] = { nullptr };
		mContext->OMSetRenderTargets(1, aNullRTV, nullptr);
		aScaled = mScalePresentFn(mSceneTexture, mSceneWidth, mSceneHeight, aOutW, aOutH);
	}
	if (aScaleCallbackInstalled && aScaled == nullptr)
	{
		FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "custom scale callback returned null; refusing native fallback window=%dx%d\n",
				mPresentWidth, mPresentHeight);
			fclose(aLog);
		}
		// A configured custom pipeline is a required stage.  Presenting the
		// unscaled scene here would hide the real failure as a black/incorrect
		// fullscreen frame; raise it so SEHCatcher/WER reports the actual path.
		RaiseException(0xE000D311, EXCEPTION_NONCONTINUABLE, 0, nullptr);
	}
	// A failed/partially executed effect must not leave compute bindings active
	// while the graphics presenter is restored.  This is state ownership, not
	// a fallback: the callback result is still handled below exactly as returned.
	mContext->CSSetShader(nullptr, nullptr, 0);
	ID3D11UnorderedAccessView* aNullUAVs[8] = {};
	mContext->CSSetUnorderedAccessViews(0, 8, aNullUAVs, nullptr);
	ID3D11ShaderResourceView* aNullCSSRVs[16] = {};
	mContext->CSSetShaderResources(0, 16, aNullCSSRVs);

	// The swapchain size always matches the window (set when the renderer was
	// (re)created via InitDDInterface). The scaled texture is drawn into it
	// below; never let the pipeline output size drive a swapchain resize, or
	// fullscreen would stretch/tear/present-black when output != window.
	mContext->OMSetRenderTargets(1, &mBackBufferRTV, nullptr);
	D3D11_VIEWPORT aViewport = { 0, 0, (float)mPresentWidth, (float)mPresentHeight, 0.0f, 1.0f };
	mContext->RSSetViewports(1, &aViewport);
	float aClear[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	mContext->ClearRenderTargetView(mBackBufferRTV, aClear);

	ID3D11ShaderResourceView* aSourceSRV = mSceneSRV;
	ID3D11ShaderResourceView* aScaledSRV = nullptr;
	if (aScaled != nullptr)
	{
		// ScaleEffectRuntime keeps the final texture alive and returns the same
		// object across frames whenever the mode/size is unchanged.  Reuse its
		// SRV instead of creating and destroying a view on every Present.
		if (mPresentSRVTexture != aScaled || mPresentSRV == nullptr)
		{
			ReleasePresentSRVCache();
			HRESULT aSrvResult = mDevice->CreateShaderResourceView(aScaled, nullptr, &mPresentSRV);
			if (SUCCEEDED(aSrvResult))
			{
				mPresentSRVTexture = aScaled;
				mPresentSRVTexture->AddRef();
			}
			else
			{
				FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
				if (aLog != nullptr)
				{
					fprintf(aLog, "present SRV creation failed hr=0x%08lx output=%p\n",
						(unsigned long)aSrvResult, (void*)aScaled);
					fclose(aLog);
				}
				RaiseException(0xE000D312, EXCEPTION_NONCONTINUABLE, 0, nullptr);
			}
		}
		if (mPresentSRV != nullptr)
		{
			aScaledSRV = mPresentSRV;
			aSourceSRV = aScaledSRV;
		}
	}

	const bool aUseScaledSource = aScaled != nullptr && aScaledSRV != nullptr;
	// Fit preserving aspect: use the SOURCE texture's aspect (the 4:3 scene,
	// or the scaled pipeline output when scaling is active), not the window.
	// Wider windows (16:9 / 16:10 fullscreen) get centered side letterbox
	// bars, exactly like the original 800x600 game.
	const float aSrcAspect = aUseScaledSource
		? (float)aOutW / (float)aOutH
		: (float)mSceneWidth / (float)mSceneHeight;
	const float aWinAspect = (float)mPresentWidth / (float)mPresentHeight;
	int aDstX = 0;
	int aDstY = 0;
	int aDstW = mPresentWidth;
	int aDstH = mPresentHeight;
	if (aWinAspect > aSrcAspect)
	{
		aDstW = (int)((float)mPresentHeight * aSrcAspect);
		aDstX = (mPresentWidth - aDstW) / 2;
	}
	else
	{
		aDstH = (int)((float)mPresentWidth / aSrcAspect);
		aDstY = (mPresentHeight - aDstH) / 2;
	}

	D3D11Vertex aVertices[6] =
	{
		{ (float)aDstX, (float)aDstY, 1, 1, 1, 1, 0.0f, 0.0f },
		{ (float)(aDstX + aDstW), (float)aDstY, 1, 1, 1, 1, 1.0f, 0.0f },
		{ (float)aDstX, (float)(aDstY + aDstH), 1, 1, 1, 1, 0.0f, 1.0f },
		{ (float)(aDstX + aDstW), (float)aDstY, 1, 1, 1, 1, 1.0f, 0.0f },
		{ (float)aDstX, (float)(aDstY + aDstH), 1, 1, 1, 1, 0.0f, 1.0f },
		{ (float)(aDstX + aDstW), (float)(aDstY + aDstH), 1, 1, 1, 1, 1.0f, 1.0f }
	};
	// The scale runtime may have followed a ClearState during a mode switch
	// and it deliberately owns the compute-stage bindings.  Reinstall the
	// graphics pipeline explicitly for the present quad instead of relying on
	// whatever IA/VS/PS state the last game draw happened to leave behind.
	UINT aPresentStride = sizeof(D3D11Vertex);
	UINT aPresentOffset = 0;
	mContext->IASetVertexBuffers(0, 1, &mVertexBuffer, &aPresentStride, &aPresentOffset);
	mContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	mContext->IASetInputLayout(mInputLayout);
	mContext->VSSetShader(mVertexShader, nullptr, 0);
	mContext->PSSetShader(mPixelShader, nullptr, 0);
	mContext->RSSetState(mRasterizer);
	mBoundPSRV = nullptr;
	mBoundSampler = nullptr;
	mBoundBlend = nullptr;
	mScissorValid = false;
	// Bilinear present: keeps the sun counter legible at non-custom scale.
	// At native 1:1 (no scale pipeline, window == scene size) bilinear
	// sampling blends the last pixel column with the texture edge, leaving a
	// dark 1px strip at the right/bottom border. Point sampling is the
	// faithful equivalent of the original drawing straight into the
	// backbuffer.
	const bool aLinearPresent = aScaled != nullptr ||
		mPresentWidth != mSceneWidth ||
		mPresentHeight != mSceneHeight;
	SubmitTriangles(aVertices, 6, aSourceSRV, aLinearPresent, false, 0, nullptr, mPresentWidth, mPresentHeight);

	if (aScaled != nullptr)
		aScaled->Release();

	HRESULT aPresentResult = mSwapChain->Present(0, 0);
	if (FAILED(aPresentResult))
	{
		FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "Present failed hr=0x%08lx window=%dx%d source=%dx%d scaled=%d\n",
				(unsigned long)aPresentResult, mPresentWidth, mPresentHeight,
				aOutW, aOutH, aScaled != nullptr ? 1 : 0);
			fclose(aLog);
		}
		RaiseException(0xE000D324, EXCEPTION_NONCONTINUABLE, 0, nullptr);
	}
}

} // namespace Sexy
