// bench_static3.cpp -- static 清扫复测（before=36a066a7^ 裸 constexpr，after=HEAD static constexpr；
//                      函数体其余逐字相同，唯一差异=函数内表加 static 消除每次调用的栈物化）
//   目标27 kRGBPermutation(6x3)  FilterEffect::HSL_to_RGB（FilterEffect::DoLumSat 每像素，热）
//   目标28 kLoopMode(6)          Reanimation::Update 循环推进（每 reanim 每帧，热）
//   目标29 kStyleFonts(19)       MessageWidget::GetFont（绘制，热）
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// ---------------- t27 HSL_to_RGB ----------------
static inline int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

namespace FormA {
__declspec(noinline) void HSL_to_RGB(float h, float sl, float l, float& r, float& g, float& b)
{
    float v = (l <= 0.5f) ? (l * (1.0f + sl)) : (l + sl - l * sl);
    if (v <= 0.0f)
    {
        r = 0.0f;
        g = 0.0f;
        b = 0.0f;
        return;
    }

    float y = 2 * l - v;
    float sv = (v - y) / v;
    h *= 6.0f;
    int sextant = ClampInt((int)h, 0, 5);
    float vsf = v * sv * (h - sextant);
    float x = y + vsf;
    float z = v - vsf;

    constexpr uint8_t kRGBPermutation[6][3] = {
        {0, 1, 2},
        {3, 0, 2},
        {2, 0, 1},
        {2, 3, 0},
        {1, 2, 0},
        {0, 2, 3},
    };
    const float aComponents[4] = {v, x, y, z};
    const auto& aPerm = kRGBPermutation[sextant];
    r = aComponents[aPerm[0]];
    g = aComponents[aPerm[1]];
    b = aComponents[aPerm[2]];
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void HSL_to_RGB(float h, float sl, float l, float& r, float& g, float& b)
{
    float v = (l <= 0.5f) ? (l * (1.0f + sl)) : (l + sl - l * sl);
    if (v <= 0.0f)
    {
        r = 0.0f;
        g = 0.0f;
        b = 0.0f;
        return;
    }

    float y = 2 * l - v;
    float sv = (v - y) / v;
    h *= 6.0f;
    int sextant = ClampInt((int)h, 0, 5);
    float vsf = v * sv * (h - sextant);
    float x = y + vsf;
    float z = v - vsf;

    static constexpr uint8_t kRGBPermutation[6][3] = {
        {0, 1, 2},
        {3, 0, 2},
        {2, 0, 1},
        {2, 3, 0},
        {1, 2, 0},
        {0, 2, 3},
    };
    const float aComponents[4] = {v, x, y, z};
    const auto& aPerm = kRGBPermutation[sextant];
    r = aComponents[aPerm[0]];
    g = aComponents[aPerm[1]];
    b = aComponents[aPerm[2]];
}
} // namespace FormB

// ---------------- t28 Reanimation::Update 循环推进 ----------------
enum ReanimLoopType2 { REANIM_LOOP = 0, REANIM_LOOP_FULL_LAST_FRAME, REANIM_PLAY_ONCE, REANIM_PLAY_ONCE_AND_HOLD,
    REANIM_PLAY_ONCE_FULL_LAST_FRAME, REANIM_PLAY_ONCE_FULL_LAST_FRAME_AND_HOLD };
static const float SECONDS_PER_UPDATE = 1.0f / 100.0f;
struct ReanimatorTrackInstance2 { int mBlendCounter; float mShakeOverride; float mShakeX; };
struct ReanimDefTracks2 { int count; };
struct ReanimDef2 { ReanimDefTracks2 mTracks; };
struct Reanimation2 {
    int mFrameCount; bool mDead;
    float mLastFrameTime, mAnimTime, mAnimRate;
    int mLoopCount;
    ReanimLoopType2 mLoopType;
    ReanimDef2* mDefinition;
    ReanimatorTrackInstance2* mTrackInstances;
    int mTrackCount;

    void UpdateTrack(ReanimatorTrackInstance2& t)
    {
        if (t.mBlendCounter > 0) t.mBlendCounter--;
        if (t.mShakeOverride != 0.0f) t.mShakeX = t.mShakeOverride * 0.5f;
    }
};

namespace FormA {
__declspec(noinline) void ReanimationUpdate(Reanimation2& m)
{
    if (m.mFrameCount == 0 || m.mDead)
        return;

    m.mLastFrameTime = m.mAnimTime;
    m.mAnimTime += SECONDS_PER_UPDATE * m.mAnimRate / m.mFrameCount;

    constexpr uint8_t kLoopMode[] = {
        0,
        0,
        1,
        2,
        1,
        2,
    };
    const bool aForward = m.mAnimRate > 0;
    const float aBoundary = aForward ? 1.0f : 0.0f;
    const bool aPast = aForward ? m.mAnimTime >= aBoundary : m.mAnimTime < aBoundary;
    switch (kLoopMode[m.mLoopType])
    {
    case 0:
        while (aForward ? m.mAnimTime >= aBoundary : m.mAnimTime < aBoundary)
        {
            m.mLoopCount++;
            m.mAnimTime += aForward ? -1.0f : 1.0f;
        }
        break;
    case 1:
        if (aPast)
        {
            m.mLoopCount = 1;
            m.mAnimTime = aBoundary;
            m.mDead = true;
        }
        break;
    case 2:
        if (aPast)
        {
            m.mLoopCount = 1;
            m.mAnimTime = aBoundary;
        }
        break;
    default:
        CS(300); // TOD_ASSERT(false) 桩
        break;
    }

    for (int aTrackIndex = 0; aTrackIndex < m.mDefinition->mTracks.count; aTrackIndex++)
    {
        ReanimatorTrackInstance2* aTrack = &m.mTrackInstances[aTrackIndex];
        m.UpdateTrack(*aTrack);
    }
    CS(301); CS((uint64_t)(int64_t)(m.mAnimTime * 1000.0f)); CS((uint64_t)m.mLoopCount);
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void ReanimationUpdate(Reanimation2& m)
{
    if (m.mFrameCount == 0 || m.mDead)
        return;

    m.mLastFrameTime = m.mAnimTime;
    m.mAnimTime += SECONDS_PER_UPDATE * m.mAnimRate / m.mFrameCount;

    static constexpr uint8_t kLoopMode[] = {
        0,
        0,
        1,
        2,
        1,
        2,
    };
    const bool aForward = m.mAnimRate > 0;
    const float aBoundary = aForward ? 1.0f : 0.0f;
    const bool aPast = aForward ? m.mAnimTime >= aBoundary : m.mAnimTime < aBoundary;
    switch (kLoopMode[m.mLoopType])
    {
    case 0:
        while (aForward ? m.mAnimTime >= aBoundary : m.mAnimTime < aBoundary)
        {
            m.mLoopCount++;
            m.mAnimTime += aForward ? -1.0f : 1.0f;
        }
        break;
    case 1:
        if (aPast)
        {
            m.mLoopCount = 1;
            m.mAnimTime = aBoundary;
            m.mDead = true;
        }
        break;
    case 2:
        if (aPast)
        {
            m.mLoopCount = 1;
            m.mAnimTime = aBoundary;
        }
        break;
    default:
        CS(300);
        break;
    }

    for (int aTrackIndex = 0; aTrackIndex < m.mDefinition->mTracks.count; aTrackIndex++)
    {
        ReanimatorTrackInstance2* aTrack = &m.mTrackInstances[aTrackIndex];
        m.UpdateTrack(*aTrack);
    }
    CS(301); CS((uint64_t)(int64_t)(m.mAnimTime * 1000.0f)); CS((uint64_t)m.mLoopCount);
}
} // namespace FormB

// ---------------- t29 MessageWidget::GetFont ----------------
struct FontStub { int id; };
static FontStub g_fonts[3];
static FontStub* const FONT_HOUSEOFTERROR28 = &g_fonts[1];
static FontStub* const FONT_HOUSEOFTERROR16 = &g_fonts[2];
enum MessageStyle { MESSAGE_STYLE_OFF = 0, MESSAGE_STYLE_TUTORIAL_LEVEL1, MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY,
    MESSAGE_STYLE_TUTORIAL_LEVEL2, MESSAGE_STYLE_TUTORIAL_LATER, MESSAGE_STYLE_TUTORIAL_LATER_STAY,
    MESSAGE_STYLE_HINT_LONG, MESSAGE_STYLE_HINT_FAST, MESSAGE_STYLE_HINT_STAY, MESSAGE_STYLE_HINT_TALL_FAST,
    MESSAGE_STYLE_HINT_TALL_UNLOCKMESSAGE, MESSAGE_STYLE_HINT_TALL_LONG, MESSAGE_STYLE_BIG_MIDDLE,
    MESSAGE_STYLE_BIG_MIDDLE_FAST, MESSAGE_STYLE_HOUSE_NAME, MESSAGE_STYLE_HUGE_WAVE, MESSAGE_STYLE_SLOT_MACHINE,
    MESSAGE_STYLE_ZEN_GARDEN_LONG, MESSAGE_STYLE_ACHIEVEMENT };
struct MessageWidgetStub { int mMessageStyle; };

namespace FormA {
__declspec(noinline) FontStub* GetFont(MessageWidgetStub& m)
{
    constexpr FontStub* const* kStyleFonts[] = {
        nullptr,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR16,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
    };
    if (FontStub* const* aFontPtr = kStyleFonts[m.mMessageStyle])
    {
        return *aFontPtr;
    }
    CS(302); // TOD_ASSERT(false) 桩
    return FONT_HOUSEOFTERROR16;
}
} // namespace FormA

namespace FormB {
__declspec(noinline) FontStub* GetFont(MessageWidgetStub& m)
{
    static constexpr FontStub* const* kStyleFonts[] = {
        nullptr,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR16,
        &FONT_HOUSEOFTERROR28,
        &FONT_HOUSEOFTERROR28,
    };
    if (FontStub* const* aFontPtr = kStyleFonts[m.mMessageStyle])
    {
        return *aFontPtr;
    }
    CS(302);
    return FONT_HOUSEOFTERROR16;
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];
static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    LCG rng{ 0x9E3779B97F4A7C15ULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();
    g_fonts[1].id = 28; g_fonts[2].id = 16;

    // t27
    {
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; float r, g, b; for (int i = 0; i < N; i++) { uint32_t v = g_in[i]; FormA::HSL_to_RGB((v & 1023) / 1024.0f, ((v >> 10) & 1023) / 1024.0f, ((v >> 20) & 1023) / 2048.0f, r, g, b); CS((uint64_t)(int64_t)(r * 1000.0f + g * 100.0f + b)); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; float r, g, b; for (int i = 0; i < N; i++) { uint32_t v = g_in[i]; FormB::HSL_to_RGB((v & 1023) / 1024.0f, ((v >> 10) & 1023) / 1024.0f, ((v >> 20) & 1023) / 2048.0f, r, g, b); CS((uint64_t)(int64_t)(r * 1000.0f + g * 100.0f + b)); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t27 kRGBPermutation(6x3) FilterEffect::HSL_to_RGB", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t28
    {
        static Reanimation2 re; static ReanimDef2 def; static ReanimatorTrackInstance2 tracks[4];
        re.mDefinition = &def; re.mTrackInstances = tracks;
        auto prep = [&](uint32_t v) {
            re.mFrameCount = 100;
            re.mDead = false;
            re.mAnimRate = ((v >> 2) & 1) ? 1.0f : -1.0f;
            re.mAnimTime = ((v >> 3) & 63) / 64.0f + 0.005f;
            re.mLoopType = (ReanimLoopType2)((v >> 9) % 6);
            re.mLoopCount = 0;
            def.mTracks.count = (int)((v >> 12) & 3) + 1;
            for (int k = 0; k < 4; k++) { tracks[k].mBlendCounter = k; tracks[k].mShakeOverride = (k & 1) ? 2.0f : 0.0f; tracks[k].mShakeX = 0; }
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::ReanimationUpdate(re); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::ReanimationUpdate(re); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t28 kLoopMode(6) Reanimation::Update loop", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t29
    {
        static MessageWidgetStub mw;
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { mw.mMessageStyle = (int)(g_in[i] % 19); FontStub* f = FormA::GetFont(mw); CS((uint64_t)f->id); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { mw.mMessageStyle = (int)(g_in[i] % 19); FontStub* f = FormB::GetFont(mw); CS((uint64_t)f->id); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t29 kStyleFonts(19) MessageWidget::GetFont", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
