
void __thiscall FUN_0054c910(int param_1,char param_2)

{
  if (*(int *)(param_1 + 0x20) != 0) {
    if (param_2 == '\0') {
      FUN_005d9d80(0);
    }
    else {
      FUN_005d9d80(1);
    }
  }
  return;
}

