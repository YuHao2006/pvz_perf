#include "pvz/determinism/state_hasher.hpp"

#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>

namespace {

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

pvz::determinism::StateDigest make_reference_digest()
{
    pvz::determinism::StateHasher hasher;
    hasher.add_string("pvz");
    hasher.add(std::uint32_t{100});
    hasher.add(0.5F);
    hasher.add(true);
    hasher.add_sequence_size(2);
    hasher.add(std::int32_t{-7});
    hasher.add(std::uint64_t{0x0102030405060708ULL});
    return hasher.finish();
}

void test_repeated_schema_is_stable()
{
    const auto first = make_reference_digest();
    const auto second = make_reference_digest();
    require(first == second, "identical fields must produce an identical digest");
    require(first.value == 0xF241E2EAA38E218CULL, "reference digest must remain cross-build stable");
    require(first.hex().size() == 16, "digest text must contain all 64 bits");
    std::cout << "reference_digest=" << first.hex() << '\n';
}

void test_field_order_is_observable()
{
    pvz::determinism::StateHasher first;
    first.add(std::uint32_t{1});
    first.add(std::uint32_t{2});

    pvz::determinism::StateHasher second;
    second.add(std::uint32_t{2});
    second.add(std::uint32_t{1});
    require(first.finish() != second.finish(), "field order must affect the digest");
}

void test_types_and_lengths_are_framed()
{
    pvz::determinism::StateHasher integer;
    integer.add(std::uint16_t{1});

    pvz::determinism::StateHasher bytes;
    constexpr std::array<std::uint8_t, 2> raw{1, 0};
    bytes.add_bytes(raw);
    require(integer.finish() != bytes.finish(), "type tags must distinguish equal raw payloads");

    pvz::determinism::StateHasher split_strings;
    split_strings.add_string("a");
    split_strings.add_string("bc");
    pvz::determinism::StateHasher joined_string;
    joined_string.add_string("abc");
    require(split_strings.finish() != joined_string.finish(), "string lengths must frame fields");
}

void test_float_bit_patterns_are_preserved()
{
    pvz::determinism::StateHasher positive_zero;
    positive_zero.add(0.0F);
    pvz::determinism::StateHasher negative_zero;
    negative_zero.add(-0.0F);
    require(positive_zero.finish() != negative_zero.finish(), "floating-point sign bits must be observable");
}

} // namespace

int main()
{
    test_repeated_schema_is_stable();
    test_field_order_is_observable();
    test_types_and_lengths_are_framed();
    test_float_bit_patterns_are_preserved();
    return EXIT_SUCCESS;
}
