#include "pvz/render/draw_command_recorder.hpp"

#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>

namespace pvz::render {
namespace {

[[nodiscard]] bool same_rect(const Rect2D& left, const Rect2D& right) noexcept
{
    return left.origin.x == right.origin.x && left.origin.y == right.origin.y &&
           left.extent.width == right.extent.width && left.extent.height == right.extent.height;
}

[[nodiscard]] float checked_float(const double value)
{
    if (!std::isfinite(value) ||
        value < -static_cast<double>(std::numeric_limits<float>::max()) ||
        value > static_cast<double>(std::numeric_limits<float>::max()))
        throw std::out_of_range("draw coordinate cannot be represented as a float");
    return static_cast<float>(value);
}

[[nodiscard]] bool is_default_rect(const Rect2D& rect) noexcept
{
    return rect.origin.x == 0.0 && rect.origin.y == 0.0 &&
           rect.extent.width == 0.0 && rect.extent.height == 0.0;
}

} // namespace

DrawCommandRecorder::DrawCommandRecorder(
    const std::uint64_t frame_index,
    const Extent2D logical_extent,
    const Rect2D pixel_viewport,
    const double interpolation_alpha)
    : frame_index_(frame_index),
      logical_extent_(logical_extent),
      pixel_viewport_(pixel_viewport),
      interpolation_alpha_(interpolation_alpha)
{
    if (logical_extent.width <= 0.0 || logical_extent.height <= 0.0)
        throw std::invalid_argument("logical extent must be positive");
    if (pixel_viewport.extent.width <= 0.0 || pixel_viewport.extent.height <= 0.0)
        throw std::invalid_argument("pixel viewport must be positive");
    if (interpolation_alpha < 0.0 || interpolation_alpha >= 1.0)
        throw std::invalid_argument("interpolation alpha must be in [0, 1)");
}

Rect2D DrawCommandRecorder::full_scissor() const noexcept
{
    return {{0.0, 0.0}, logical_extent_};
}

Rect2D DrawCommandRecorder::normalized_scissor(Rect2D logical_scissor) const
{
    if (is_default_rect(logical_scissor))
        logical_scissor = full_scissor();

    constexpr double epsilon = 1e-6;
    const double right = logical_scissor.origin.x + logical_scissor.extent.width;
    const double bottom = logical_scissor.origin.y + logical_scissor.extent.height;
    if (logical_scissor.origin.x < 0.0 || logical_scissor.origin.y < 0.0 ||
        logical_scissor.extent.width < 0.0 || logical_scissor.extent.height < 0.0 ||
        right > logical_extent_.width + epsilon || bottom > logical_extent_.height + epsilon)
        throw std::out_of_range("logical scissor exceeds the frame");
    return logical_scissor;
}

void DrawCommandRecorder::append_batch(
    const TextureHandle texture,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const SamplingState sampling,
    const std::uint32_t first_index,
    const std::uint32_t index_count)
{
    if (!batches_.empty()) {
        DrawBatch& previous = batches_.back();
        const auto previous_end = static_cast<std::uint64_t>(previous.first_index) + previous.index_count;
        if (previous.texture == texture && previous.blend_mode == blend_mode &&
            previous.sampling == sampling && same_rect(previous.logical_scissor, logical_scissor) &&
            previous_end == first_index &&
            previous.index_count <= std::numeric_limits<std::uint32_t>::max() - index_count) {
            previous.index_count += index_count;
            return;
        }
    }
    batches_.push_back({texture, blend_mode, first_index, index_count, logical_scissor, sampling});
}

void DrawCommandRecorder::fill_rect(
    const Rect2D destination,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor)
{
    const TextureRegion white{{}, {1.0, 1.0}, {{0.0, 0.0}, {1.0, 1.0}}};
    draw_sprite(white, destination, rgba, blend_mode, logical_scissor);
}

void DrawCommandRecorder::draw_sprite(
    const TextureRegion& source,
    const Rect2D destination,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const SamplingState sampling,
    const bool mirror_x,
    const bool mirror_y)
{
    const std::array positions{
        Point2D{destination.origin.x, destination.origin.y},
        Point2D{destination.origin.x + destination.extent.width, destination.origin.y},
        Point2D{
            destination.origin.x + destination.extent.width,
            destination.origin.y + destination.extent.height},
        Point2D{destination.origin.x, destination.origin.y + destination.extent.height},
    };
    draw_sprite_quad(
        source,
        positions,
        rgba,
        blend_mode,
        logical_scissor,
        sampling,
        mirror_x,
        mirror_y);
}

void DrawCommandRecorder::draw_sprite_quad(
    const TextureRegion& source,
    const std::array<Point2D, 4>& positions,
    const std::uint32_t rgba,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const SamplingState sampling,
    const bool mirror_x,
    const bool mirror_y)
{
    if (source.texture_extent.width <= 0.0 || source.texture_extent.height <= 0.0)
        throw std::invalid_argument("texture extent must be positive");
    if (source.source_pixels.extent.width < 0.0 || source.source_pixels.extent.height < 0.0)
        throw std::invalid_argument("source extent must not be negative");

    double u0 = source.source_pixels.origin.x / source.texture_extent.width;
    double v0 = source.source_pixels.origin.y / source.texture_extent.height;
    double u1 = (source.source_pixels.origin.x + source.source_pixels.extent.width) /
                source.texture_extent.width;
    double v1 = (source.source_pixels.origin.y + source.source_pixels.extent.height) /
                source.texture_extent.height;
    if (mirror_x)
        std::swap(u0, u1);
    if (mirror_y)
        std::swap(v0, v1);

    if (vertices_.size() > std::numeric_limits<std::uint32_t>::max() - 4U ||
        indices_.size() > std::numeric_limits<std::uint32_t>::max() - 6U)
        throw std::overflow_error("frame geometry exceeds 32-bit index limits");
    const auto base_vertex = static_cast<std::uint32_t>(vertices_.size());
    const auto first_index = static_cast<std::uint32_t>(indices_.size());
    vertices_.push_back({checked_float(positions[0].x), checked_float(positions[0].y), checked_float(u0), checked_float(v0), rgba});
    vertices_.push_back({checked_float(positions[1].x), checked_float(positions[1].y), checked_float(u1), checked_float(v0), rgba});
    vertices_.push_back({checked_float(positions[2].x), checked_float(positions[2].y), checked_float(u1), checked_float(v1), rgba});
    vertices_.push_back({checked_float(positions[3].x), checked_float(positions[3].y), checked_float(u0), checked_float(v1), rgba});
    indices_.insert(indices_.end(), {
        base_vertex,
        base_vertex + 1U,
        base_vertex + 2U,
        base_vertex + 2U,
        base_vertex + 3U,
        base_vertex,
    });
    append_batch(
        source.texture,
        blend_mode,
        normalized_scissor(logical_scissor),
        sampling,
        first_index,
        6);
}

void DrawCommandRecorder::draw_triangle_list(
    const TextureHandle texture,
    const std::span<const Vertex2D> vertices,
    const BlendMode blend_mode,
    const Rect2D logical_scissor,
    const SamplingState sampling)
{
    if (vertices.size() % 3 != 0)
        throw std::invalid_argument("triangle-list vertex count must be divisible by three");
    if (vertices.empty())
        return;
    if (vertices_.size() > std::numeric_limits<std::uint32_t>::max() - vertices.size() ||
        indices_.size() > std::numeric_limits<std::uint32_t>::max() - vertices.size())
        throw std::overflow_error("frame geometry exceeds 32-bit index limits");

    const auto base_vertex = static_cast<std::uint32_t>(vertices_.size());
    const auto first_index = static_cast<std::uint32_t>(indices_.size());
    vertices_.insert(vertices_.end(), vertices.begin(), vertices.end());
    for (std::uint32_t index = 0; index < vertices.size(); ++index)
        indices_.push_back(base_vertex + index);
    append_batch(
        texture,
        blend_mode,
        normalized_scissor(logical_scissor),
        sampling,
        first_index,
        static_cast<std::uint32_t>(vertices.size()));
}

FramePacket DrawCommandRecorder::frame() const noexcept
{
    return {
        frame_index_,
        logical_extent_,
        pixel_viewport_,
        interpolation_alpha_,
        vertices_,
        indices_,
        batches_,
    };
}

const std::vector<Vertex2D>& DrawCommandRecorder::vertices() const noexcept
{
    return vertices_;
}

const std::vector<std::uint32_t>& DrawCommandRecorder::indices() const noexcept
{
    return indices_;
}

const std::vector<DrawBatch>& DrawCommandRecorder::batches() const noexcept
{
    return batches_;
}

} // namespace pvz::render
