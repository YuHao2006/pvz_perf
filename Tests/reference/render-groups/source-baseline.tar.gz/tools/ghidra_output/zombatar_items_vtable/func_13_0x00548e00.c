
void __thiscall FUN_00548e00(int param_1,int *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined1 *puVar5;
  undefined1 local_5c [4];
  undefined4 local_58;
  undefined1 local_54 [8];
  undefined1 local_4c [8];
  undefined4 local_44;
  undefined4 local_40;
  undefined1 local_3c [8];
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined1 local_24 [8];
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  FUN_00559350(*(undefined4 *)(param_1 + 0x18),param_1 + 4);
  FUN_00559350(**(undefined4 **)(param_1 + 0x18),param_1 + 4);
  FUN_0055a680(&local_c,local_1c,local_18,local_14,local_10,&param_2);
  FUN_00559350(*(undefined4 *)(param_1 + 0x18),param_1 + 4);
  cVar2 = FUN_006143c0(local_24);
  if (cVar2 == '\0') {
    cVar2 = FUN_006143c0(param_1 + 0x2c);
    if (cVar2 != '\0') {
      uVar4 = *(undefined4 *)(param_1 + 0x2c);
      uVar1 = *(undefined4 *)(param_1 + 0x30);
      FUN_00614350();
      *(undefined1 *)(param_1 + 0x28) = 1;
      local_2c = uVar4;
      local_28 = uVar1;
    }
    local_34 = local_c;
    local_30 = local_8;
    FUN_00556e50(local_3c,local_c,local_8);
    uVar4 = *(undefined4 *)(param_1 + 0x18);
    FUN_00420ae0();
    local_40 = uVar4;
    if (param_1 == -4) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    puVar5 = &stack0x00000008;
    uVar4 = local_40;
    puVar3 = (undefined4 *)FUN_005b75d0(local_4c);
    puVar3 = (undefined4 *)FUN_0055a680(local_54,*puVar3,puVar3[1],local_44,uVar4,puVar5);
    local_c = *puVar3;
    local_8 = puVar3[1];
    uVar4 = *(undefined4 *)(param_1 + 0x18);
    FUN_00420ae0();
    local_58 = uVar4;
    if (param_1 == -4) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    cVar2 = FUN_006143c0(local_5c);
    if (cVar2 == '\0') {
      FUN_00614350();
    }
    FUN_005484e0(&local_c,param_2);
    (**(code **)(*param_2 + 0x78))();
  }
  return;
}

