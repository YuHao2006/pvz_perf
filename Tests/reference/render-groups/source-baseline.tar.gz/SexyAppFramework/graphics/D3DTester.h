#ifndef __D3DTESTER_H__
#define __D3DTESTER_H__
#include <windows.h>
#include <string>

namespace Sexy
{

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// 3D acceleration is mandatory and always on in this port, so the D3D9
// capability probe is retired. The class remains as a trivial stub to keep
// the DDInterface/Do3DTest call sites intact.
class D3DTester
{
protected:
	std::string mFailureReason;
	std::string mWarning;
	bool mResultsChanged;

public:
	D3DTester() : mResultsChanged(false) { }
	virtual ~D3DTester() { }

	bool HadWarning() { return !mWarning.empty(); }
	bool HadError() { return !mFailureReason.empty(); }
	bool Is3DSupported() { return !HadError(); }
	bool Is3DRecommended() { return !HadError() && !HadWarning(); }
	std::string GetWarning() { return mWarning; }
	std::string GetError() { return mFailureReason; }
	bool ResultsChanged() { return mResultsChanged; }

	void SetVidMemoryConstraints(DWORD theMin, DWORD theRecommended);
	void TestD3D(HWND theHWND, void* theDDraw);
};

} // namespace Sexy


#endif
