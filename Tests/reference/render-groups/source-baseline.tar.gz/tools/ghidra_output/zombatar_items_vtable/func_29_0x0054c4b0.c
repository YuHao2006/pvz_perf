
void __thiscall FUN_0054c4b0(int *param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = FUN_00432890();
  if (iVar1 <= param_2) {
    puVar2 = (undefined4 *)FUN_00561490();
    FUN_005584d0(param_2 + 1,*puVar2,puVar2[1],puVar2[2],puVar2[3]);
  }
  puVar2 = (undefined4 *)FUN_00432870();
  *puVar2 = *param_3;
  puVar2[1] = param_3[1];
  puVar2[2] = param_3[2];
  puVar2[3] = param_3[3];
  (**(code **)(*param_1 + 0x44))();
  return;
}

