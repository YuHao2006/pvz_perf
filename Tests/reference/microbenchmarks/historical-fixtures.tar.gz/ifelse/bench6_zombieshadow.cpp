// bench6_zombieshadow.cpp - 目标6: Zombie::DrawShadow 11 支 -> kZombieShadowRows 34 槽（前进/后退双列）
// 计时区 = 第一链（FOOTBALL..else 兜底）；第二链（NEWSPAPER/BALLOON/BUNGEE）与高度/末尾绘制两形态逐字相同，不计入
#include "bench_common.h"

enum ZombieType
{
    ZOMBIE_INVALID = -1,
    ZOMBIE_NORMAL, ZOMBIE_FLAG, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL,
    ZOMBIE_NEWSPAPER, ZOMBIE_DOOR, ZOMBIE_FOOTBALL, ZOMBIE_DANCER, ZOMBIE_BACKUP_DANCER,
    ZOMBIE_DUCKY_TUBE, ZOMBIE_SNORKEL, ZOMBIE_ZAMBONI, ZOMBIE_BOBSLED, ZOMBIE_DOLPHIN_RIDER,
    ZOMBIE_JACK_IN_THE_BOX, ZOMBIE_BALLOON, ZOMBIE_DIGGER, ZOMBIE_POGO, ZOMBIE_YETI,
    ZOMBIE_BUNGEE, ZOMBIE_LADDER, ZOMBIE_CATAPULT, ZOMBIE_GARGANTUAR, ZOMBIE_IMP,
    ZOMBIE_BOSS, ZOMBIE_PEA_HEAD, ZOMBIE_WALLNUT_HEAD, ZOMBIE_JALAPENO_HEAD, ZOMBIE_GATLING_HEAD,
    ZOMBIE_SQUASH_HEAD, ZOMBIE_TALLNUT_HEAD, ZOMBIE_REDEYE_GARGANTUAR, ZOMBIE_ZOMBATAR,
    NUM_ZOMBIE_TYPES
};

struct Reanimation { int dummy; };
struct LawnAppStub
{
    Reanimation mReanim;
    Reanimation* ReanimationTryToGet(int id) { return (id & 1) ? &mReanim : nullptr; }  // 确定性：由输入位决定
};
struct ZombieDrawPosition { float mImageOffsetX, mImageOffsetY, mBodyY; };

struct Zombie
{
    ZombieType mZombieType;
    int mBodyReanimID;
    float mScaleZombie;
    bool mWalkingBackwards;
    LawnAppStub* mApp;

    bool IsWalkingBackwards() const { return mWalkingBackwards; }
};
static LawnAppStub gApp;
static Zombie gZombie;

static void SetupZombie(uint32_t inp)
{
    gZombie.mZombieType = (ZombieType)(inp % (uint32_t)NUM_ZOMBIE_TYPES);
    gZombie.mBodyReanimID = (int)((inp >> 29) & 1u);   // 驱动 ReanimationTryToGet 二分
    gZombie.mScaleZombie = BitsToF(inp, 8);
    gZombie.mWalkingBackwards = (inp >> 28) & 1u;
    gZombie.mApp = &gApp;
}

// ---------------- FormA：原 11 支链（逐字） ----------------
__declspec(noinline) void OneA(uint32_t inp)
{
    SetupZombie(inp);
    Zombie& z = gZombie;
    // 前缀公共结果（两形态相同，不计时的 GetDrawPos/StageIsNight 由同一输入确定性给出）
    ZombieDrawPosition aDrawPos;
    aDrawPos.mImageOffsetX = BitsToF(inp, 12);
    aDrawPos.mImageOffsetY = BitsToF(inp, 16);
    aDrawPos.mBodyY = BitsToF(inp, 20);
    int aShadowType = (int)((inp >> 27) & 1u);
    float aShadowOffsetX = aDrawPos.mImageOffsetX;
    float aShadowOffsetY = aDrawPos.mImageOffsetY + aDrawPos.mBodyY;
    float aScale = z.mScaleZombie;
    aShadowOffsetX += z.mScaleZombie * 20.0f - 20.0f;

    if (z.mZombieType == ZombieType::ZOMBIE_FOOTBALL)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 11.0f * z.mScaleZombie;
        }
        else
        {
            aShadowOffsetX += 20.0f + 21.0f * z.mScaleZombie;
        }
        aShadowOffsetY += 16.0f;
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_NEWSPAPER)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 5.0f;
        }
        else
        {
            aShadowOffsetX += 29.0f;
        }
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_POLEVAULTER)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += -5.0f;
        }
        else
        {
            aShadowOffsetX += 36.0f;
        }
        aShadowOffsetY += 11.0f;
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_BOBSLED)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 13.0f;
        }
        else
        {
            aShadowOffsetX += 20.0f;
        }
        aShadowOffsetY += 13.0f;
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_IMP)
    {
        aScale *= 0.6f;
        aShadowOffsetY += 7.0f;
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 13.0f;
        }
        else
        {
            aShadowOffsetX += 25.0f;
        }
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_DIGGER)
    {
        aShadowOffsetY += 5.0f;
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 14.0f;
        }
        else
        {
            aShadowOffsetX += 17.0f;
        }
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_SNORKEL)
    {
        aShadowOffsetY += 5.0f;
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 2.0f;
        }
        else
        {
            aShadowOffsetX += 35.0f;
        }
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER)
    {
        aShadowOffsetY += 11.0f;
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 15.0f;
        }
        else
        {
            aShadowOffsetX += 19.0f;
        }
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_YETI)
    {
        aShadowOffsetY += 20.0f;
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 20.0f;
        }
        else
        {
            aShadowOffsetX += 3.0f;
        }
    }
    else if (z.mZombieType == ZombieType::ZOMBIE_GARGANTUAR || z.mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
    {
        aScale *= 1.5f;
        aShadowOffsetX += 27.0f;
        aShadowOffsetY += 7.0f;
    }
    else if (z.mApp->ReanimationTryToGet(z.mBodyReanimID) != nullptr)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 11.0f;
        }
        else
        {
            aShadowOffsetX += 23.0f;
        }
    }
    else
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 2.0f;
        }
        else
        {
            aShadowOffsetX += 35.f;
        }
    }

    (void)aShadowType;
    MixF(aShadowOffsetX); MixF(aShadowOffsetY); MixF(aScale);
}

// ---------------- FormB：当前表形态（逐字：FOOTBALL 特例 + 34 槽双列表 + fallback） ----------------
__declspec(noinline) void OneB(uint32_t inp)
{
    SetupZombie(inp);
    Zombie& z = gZombie;
    ZombieDrawPosition aDrawPos;
    aDrawPos.mImageOffsetX = BitsToF(inp, 12);
    aDrawPos.mImageOffsetY = BitsToF(inp, 16);
    aDrawPos.mBodyY = BitsToF(inp, 20);
    int aShadowType = (int)((inp >> 27) & 1u);
    float aShadowOffsetX = aDrawPos.mImageOffsetX;
    float aShadowOffsetY = aDrawPos.mImageOffsetY + aDrawPos.mBodyY;
    float aScale = z.mScaleZombie;
    aShadowOffsetX += z.mScaleZombie * 20.0f - 20.0f;

    constexpr struct { float mFwdX; float mBackX; float mOffY; float mScaleMul; } kZombieShadowRows[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
        { 0, 0, 0, 0 },        // 0 ZOMBIE_NORMAL（无行）
        { 0, 0, 0, 0 },        // 1 ZOMBIE_FLAG（无行）
        { 0, 0, 0, 0 },        // 2 ZOMBIE_TRAFFIC_CONE（无行）
        { 36.0f, -5.0f, 11.0f, 1.0f },   // 3 ZOMBIE_POLEVAULTER
        { 0, 0, 0, 0 },        // 4 ZOMBIE_PAIL（无行）
        { 29.0f, 5.0f, 0.0f, 1.0f },     // 5 ZOMBIE_NEWSPAPER
        { 0, 0, 0, 0 },        // 6 ZOMBIE_DOOR（无行）
        { 0, 0, 0, 0 },        // 7 ZOMBIE_FOOTBALL（特例表外，槽位不可达）
        { 0, 0, 0, 0 },        // 8 ZOMBIE_DANCER（无行）
        { 0, 0, 0, 0 },        // 9 ZOMBIE_BACKUP_DANCER（无行）
        { 0, 0, 0, 0 },        // 10 ZOMBIE_DUCKY_TUBE（无行）
        { 35.0f, -2.0f, 5.0f, 1.0f },    // 11 ZOMBIE_SNORKEL
        { 0, 0, 0, 0 },        // 12 ZOMBIE_ZAMBONI（无行）
        { 20.0f, 13.0f, 13.0f, 1.0f },   // 13 ZOMBIE_BOBSLED
        { 19.0f, 15.0f, 11.0f, 1.0f },   // 14 ZOMBIE_DOLPHIN_RIDER
        { 0, 0, 0, 0 },        // 15 ZOMBIE_JACK_IN_THE_BOX（无行）
        { 0, 0, 0, 0 },        // 16 ZOMBIE_BALLOON（无行）
        { 17.0f, 14.0f, 5.0f, 1.0f },    // 17 ZOMBIE_DIGGER
        { 0, 0, 0, 0 },        // 18 ZOMBIE_POGO（无行）
        { 3.0f, 20.0f, 20.0f, 1.0f },    // 19 ZOMBIE_YETI
        { 0, 0, 0, 0 },        // 20 ZOMBIE_BUNGEE（无行）
        { 0, 0, 0, 0 },        // 21 ZOMBIE_LADDER（无行）
        { 0, 0, 0, 0 },        // 22 ZOMBIE_CATAPULT（无行）
        { 27.0f, 27.0f, 7.0f, 1.5f },    // 23 ZOMBIE_GARGANTUAR
        { 25.0f, 13.0f, 7.0f, 0.6f },    // 24 ZOMBIE_IMP
        { 0, 0, 0, 0 },        // 25 ZOMBIE_BOSS（无行）
        { 0, 0, 0, 0 },        // 26 ZOMBIE_PEA_HEAD（无行）
        { 0, 0, 0, 0 },        // 27 ZOMBIE_WALLNUT_HEAD（无行）
        { 0, 0, 0, 0 },        // 28 ZOMBIE_JALAPENO_HEAD（无行）
        { 0, 0, 0, 0 },        // 29 ZOMBIE_GATLING_HEAD（无行）
        { 0, 0, 0, 0 },        // 30 ZOMBIE_SQUASH_HEAD（无行）
        { 0, 0, 0, 0 },        // 31 ZOMBIE_TALLNUT_HEAD（无行）
        { 27.0f, 27.0f, 7.0f, 1.5f },    // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
        { 0, 0, 0, 0 },        // 33 ZOMBIE_ZOMBATAR（无行）
    };

    if (z.mZombieType == ZombieType::ZOMBIE_FOOTBALL)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 11.0f * z.mScaleZombie;
        }
        else
        {
            aShadowOffsetX += 20.0f + 21.0f * z.mScaleZombie;
        }
        aShadowOffsetY += 16.0f;
    }
    else if ((unsigned)z.mZombieType < sizeof(kZombieShadowRows) / sizeof(kZombieShadowRows[0]) &&
        kZombieShadowRows[(int)z.mZombieType].mScaleMul != 0.0f)
    {
        const auto& aRow = kZombieShadowRows[(int)z.mZombieType];
        aShadowOffsetX += z.IsWalkingBackwards() ? aRow.mBackX : aRow.mFwdX;
        aShadowOffsetY += aRow.mOffY;
        aScale *= aRow.mScaleMul;
    }
    else if (z.mApp->ReanimationTryToGet(z.mBodyReanimID) != nullptr)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 11.0f;
        }
        else
        {
            aShadowOffsetX += 23.0f;
        }
    }
    else
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 2.0f;
        }
        else
        {
            aShadowOffsetX += 35.f;
        }
    }

    (void)aShadowType;
    MixF(aShadowOffsetX); MixF(aShadowOffsetY); MixF(aScale);
}

// ---------------- FormC：FormB 逐字 + static constexpr（诊断：免每次调用栈物化） ----------------
__declspec(noinline) void OneC(uint32_t inp)
{
    SetupZombie(inp);
    Zombie& z = gZombie;
    ZombieDrawPosition aDrawPos;
    aDrawPos.mImageOffsetX = BitsToF(inp, 12);
    aDrawPos.mImageOffsetY = BitsToF(inp, 16);
    aDrawPos.mBodyY = BitsToF(inp, 20);
    int aShadowType = (int)((inp >> 27) & 1u);
    float aShadowOffsetX = aDrawPos.mImageOffsetX;
    float aShadowOffsetY = aDrawPos.mImageOffsetY + aDrawPos.mBodyY;
    float aScale = z.mScaleZombie;
    aShadowOffsetX += z.mScaleZombie * 20.0f - 20.0f;

    static constexpr struct { float mFwdX; float mBackX; float mOffY; float mScaleMul; } kZombieShadowRows[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
        { 0, 0, 0, 0 },        // 0 ZOMBIE_NORMAL（无行）
        { 0, 0, 0, 0 },        // 1 ZOMBIE_FLAG（无行）
        { 0, 0, 0, 0 },        // 2 ZOMBIE_TRAFFIC_CONE（无行）
        { 36.0f, -5.0f, 11.0f, 1.0f },   // 3 ZOMBIE_POLEVAULTER
        { 0, 0, 0, 0 },        // 4 ZOMBIE_PAIL（无行）
        { 29.0f, 5.0f, 0.0f, 1.0f },     // 5 ZOMBIE_NEWSPAPER
        { 0, 0, 0, 0 },        // 6 ZOMBIE_DOOR（无行）
        { 0, 0, 0, 0 },        // 7 ZOMBIE_FOOTBALL（特例表外，槽位不可达）
        { 0, 0, 0, 0 },        // 8 ZOMBIE_DANCER（无行）
        { 0, 0, 0, 0 },        // 9 ZOMBIE_BACKUP_DANCER（无行）
        { 0, 0, 0, 0 },        // 10 ZOMBIE_DUCKY_TUBE（无行）
        { 35.0f, -2.0f, 5.0f, 1.0f },    // 11 ZOMBIE_SNORKEL
        { 0, 0, 0, 0 },        // 12 ZOMBIE_ZAMBONI（无行）
        { 20.0f, 13.0f, 13.0f, 1.0f },   // 13 ZOMBIE_BOBSLED
        { 19.0f, 15.0f, 11.0f, 1.0f },   // 14 ZOMBIE_DOLPHIN_RIDER
        { 0, 0, 0, 0 },        // 15 ZOMBIE_JACK_IN_THE_BOX（无行）
        { 0, 0, 0, 0 },        // 16 ZOMBIE_BALLOON（无行）
        { 17.0f, 14.0f, 5.0f, 1.0f },    // 17 ZOMBIE_DIGGER
        { 0, 0, 0, 0 },        // 18 ZOMBIE_POGO（无行）
        { 3.0f, 20.0f, 20.0f, 1.0f },    // 19 ZOMBIE_YETI
        { 0, 0, 0, 0 },        // 20 ZOMBIE_BUNGEE（无行）
        { 0, 0, 0, 0 },        // 21 ZOMBIE_LADDER（无行）
        { 0, 0, 0, 0 },        // 22 ZOMBIE_CATAPULT（无行）
        { 27.0f, 27.0f, 7.0f, 1.5f },    // 23 ZOMBIE_GARGANTUAR
        { 25.0f, 13.0f, 7.0f, 0.6f },    // 24 ZOMBIE_IMP
        { 0, 0, 0, 0 },        // 25 ZOMBIE_BOSS（无行）
        { 0, 0, 0, 0 },        // 26 ZOMBIE_PEA_HEAD（无行）
        { 0, 0, 0, 0 },        // 27 ZOMBIE_WALLNUT_HEAD（无行）
        { 0, 0, 0, 0 },        // 28 ZOMBIE_JALAPENO_HEAD（无行）
        { 0, 0, 0, 0 },        // 29 ZOMBIE_GATLING_HEAD（无行）
        { 0, 0, 0, 0 },        // 30 ZOMBIE_SQUASH_HEAD（无行）
        { 0, 0, 0, 0 },        // 31 ZOMBIE_TALLNUT_HEAD（无行）
        { 27.0f, 27.0f, 7.0f, 1.5f },    // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
        { 0, 0, 0, 0 },        // 33 ZOMBIE_ZOMBATAR（无行）
    };

    if (z.mZombieType == ZombieType::ZOMBIE_FOOTBALL)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 11.0f * z.mScaleZombie;
        }
        else
        {
            aShadowOffsetX += 20.0f + 21.0f * z.mScaleZombie;
        }
        aShadowOffsetY += 16.0f;
    }
    else if ((unsigned)z.mZombieType < sizeof(kZombieShadowRows) / sizeof(kZombieShadowRows[0]) &&
        kZombieShadowRows[(int)z.mZombieType].mScaleMul != 0.0f)
    {
        const auto& aRow = kZombieShadowRows[(int)z.mZombieType];
        aShadowOffsetX += z.IsWalkingBackwards() ? aRow.mBackX : aRow.mFwdX;
        aShadowOffsetY += aRow.mOffY;
        aScale *= aRow.mScaleMul;
    }
    else if (z.mApp->ReanimationTryToGet(z.mBodyReanimID) != nullptr)
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX += 11.0f;
        }
        else
        {
            aShadowOffsetX += 23.0f;
        }
    }
    else
    {
        if (z.IsWalkingBackwards())
        {
            aShadowOffsetX -= 2.0f;
        }
        else
        {
            aShadowOffsetX += 35.f;
        }
    }

    (void)aShadowType;
    MixF(aShadowOffsetX); MixF(aShadowOffsetY); MixF(aScale);
}

static void RunA() { for (int i = 0; i < kN; i++) OneA(gInput[i]); }
static void RunB() { for (int i = 0; i < kN; i++) OneB(gInput[i]); }
static void RunC() { for (int i = 0; i < kN; i++) OneC(gInput[i]); }

int main()
{
    GenInput();
    uint64_t ca = CheckOnly(RunA);
    uint64_t cb = CheckOnly(RunB);
    uint64_t cc = CheckOnly(RunC);
    double a = TimePerIterNs(RunA, kN);
    double b = TimePerIterNs(RunB, kN);
    double c = TimePerIterNs(RunC, kN);
    printf("bench6 ZombieDrawShadow | before %.2f ns | after %.2f ns | diff %.1f%% | C(static) %.2f ns | checksum=%s (A=%016llX B=%016llX C=%016llX)\n",
        a, b, (a - b) / a * 100.0, c, ca == cb && cb == cc ? "OK" : "MISMATCH", (unsigned long long)ca, (unsigned long long)cb, (unsigned long long)cc);
    return (ca == cb && cb == cc) ? 0 : 1;
}
