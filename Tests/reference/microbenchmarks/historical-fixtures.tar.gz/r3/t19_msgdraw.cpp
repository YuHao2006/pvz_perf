// t19_msgdraw.cpp — ★kStyleDraw -> MessageWidget::Draw（每帧·消息显示时）
// + b20 kMessageDurations -> MessageWidget::SetLabel（事件）
// FormA：Draw=d1d92479^ switch / SetLabel=beaacd3b^ switch（逐字）
// FormB：HEAD（kStyleDraw 函数内 static 表 / kMessageDurations lambda 表，逐字）
#include "r3_entities.h"

// 文件域镜像串缓存（仓库原样，两形态共享）
namespace
{
const MessageWidget* gLabelStrOwner = nullptr;
SexyString gLabelStr;
}

// DrawReanimatedText 桩（编号桩，两形态共享；只入 checksum 不跑真循环）
__declspec(noinline) void MessageWidget::DrawReanimatedTextStub(Graphics* g, _Font* theFont, const Color& theColor, float thePosY)
{
    ZSink(RID_TodDrawString, (uint32_t)(int)(thePosY * 8.0f), (uint32_t)(theColor.mRed * 3 + theColor.mAlpha), (uint32_t)sexystrlen(mLabel));
}

// ==================== t19 FormA：d1d92479^ switch 逐字 ====================
__declspec(noinline) void MessageWidget::Draw_A(Graphics* g)
{
    if (mDuration <= 0)
        return;

    _Font* aFont = GetFont();
    _Font* aOutlineFont = nullptr;
    int aPosX = BOARD_WIDTH / 2;
    int aPosY = 596;
    int aTextOffsetY = 0;
    int aRectHeight = 0;
    int aMinAlpha = 255;
    Color aColor(250, 250, 0, 255);
    Color aOutlineColor(0, 0, 0, 255);
    bool aFadeOut = false;
    if (aFont == Sexy::FONT_CONTINUUMBOLD14)
    {
        aOutlineFont = Sexy::FONT_CONTINUUMBOLD14OUTLINE;
    }

    switch (mMessageStyle)
    {
    case MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1:
    case MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY:
        aPosY = 400;
        aRectHeight = 110;
        aTextOffsetY = -4;
        aColor = Color(253, 245, 173);
        aMinAlpha = 192;
        break;

    case MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL2:
    case MessageStyle::MESSAGE_STYLE_TUTORIAL_LATER:
    case MessageStyle::MESSAGE_STYLE_TUTORIAL_LATER_STAY:
    case MessageStyle::MESSAGE_STYLE_HINT_TALL_FAST:
    case MessageStyle::MESSAGE_STYLE_HINT_TALL_UNLOCKMESSAGE:
    case MessageStyle::MESSAGE_STYLE_HINT_TALL_LONG:
    case MessageStyle::MESSAGE_STYLE_ACHIEVEMENT: // @Patoke: implemented
        aPosY = 476;
        aRectHeight = 100;
        aTextOffsetY = -4;
        aColor = Color(253, 245, 173);
        aMinAlpha = 192;
        break;

    case MessageStyle::MESSAGE_STYLE_HINT_LONG:
    case MessageStyle::MESSAGE_STYLE_HINT_FAST:
    case MessageStyle::MESSAGE_STYLE_HINT_STAY:
        aPosY = 527;
        aRectHeight = 55;
        aTextOffsetY = -4;
        aColor = Color(253, 245, 173);
        aMinAlpha = 192;
        break;

    case MessageStyle::MESSAGE_STYLE_BIG_MIDDLE:
    case MessageStyle::MESSAGE_STYLE_BIG_MIDDLE_FAST:
        aPosY = 300;
        aRectHeight = 110;
        aColor = Color(253, 245, 173);
        aMinAlpha = 192;
        break;

    case MessageStyle::MESSAGE_STYLE_HOUSE_NAME:
        aPosY = 550;
        aColor = Color(255, 255, 255, 255);
        aFadeOut = true;
        break;

    case MessageStyle::MESSAGE_STYLE_HUGE_WAVE:
        aPosY = 330;
        aColor = Color(255, 0, 0);
        break;

    case MessageStyle::MESSAGE_STYLE_SLOT_MACHINE:
        aPosY = 93;
        aPosX = 340;
        aMinAlpha = 64;
        break;

    case MessageStyle::MESSAGE_STYLE_ZEN_GARDEN_LONG:
        aPosY = 514;
        aRectHeight = 55;
        aTextOffsetY = -4;
        aColor = Color(253, 245, 173);
        aMinAlpha = 192;
        break;

    default:
        TOD_ASSERT(false);
        break;
    }

    if (mReanimType != ReanimationType::REANIM_NONE)
    {
        if (aFont == Sexy::FONT_CONTINUUMBOLD14)
        {
            DrawReanimatedTextStub(g, Sexy::FONT_CONTINUUMBOLD14OUTLINE, Color::Black, aPosY);
        }
        DrawReanimatedTextStub(g, aFont, aColor, aPosY);
    }
    else
    {
        // 条目5：镜像串按 (属主, 内容) 比对刷新，值不变零分配
        if (gLabelStrOwner != this || gLabelStr.compare(mLabel) != 0)
        {
            gLabelStrOwner = this;
            gLabelStr.assign(mLabel);
        }
        const SexyString& aLabelStr = gLabelStr;

        if (aMinAlpha != 255)
        {
            aColor.mAlpha = TodAnimateCurve(75, 0, mApp->mBoard->mMainCounter % 75, aMinAlpha, 255, Curves::BounceSlowMiddle);
            aOutlineColor.mAlpha = aColor.mAlpha;
        }
        if (aFadeOut)
        {
            aColor.mAlpha = ClampInt(mDuration * 15, 0, 255);
            aOutlineColor.mAlpha = aColor.mAlpha;
        }

        if (aRectHeight > 0)
        {
            aOutlineColor = Color(0, 0, 0, 128);
            Rect aRect(0, aPosY, BOARD_WIDTH, aRectHeight);
            g->SetColor(aOutlineColor);
            g->FillRect(aRect);

            aRect.mY += aTextOffsetY;
            TodDrawStringWrapped(g, aLabelStr, aRect, aFont, aColor, DrawStringJustification::DS_ALIGN_CENTER_VERTICAL_MIDDLE);
        }
        else
        {
            Rect aRect(aPosX - mApp->mBoard->mX - BOARD_WIDTH / 2, aPosY - aFont->mAscent, BOARD_WIDTH, BOARD_HEIGHT);
            if (aOutlineFont)
            {
                TodDrawStringWrapped(g, aLabelStr, aRect, aOutlineFont, aOutlineColor, DrawStringJustification::DS_ALIGN_CENTER);
            }
            TodDrawStringWrapped(g, aLabelStr, aRect, aFont, aColor, DrawStringJustification::DS_ALIGN_CENTER);
        }

        if (mMessageStyle == MessageStyle::MESSAGE_STYLE_HOUSE_NAME)
        {
            SexyString aSubStr;
            if (mApp->IsSurvivalMode() && mApp->mBoard->mChallenge->mSurvivalStage > 0)
            {
                int aFlags = mApp->mBoard->GetNumWavesPerSurvivalStage() * mApp->mBoard->mChallenge->mSurvivalStage / mApp->mBoard->GetNumWavesPerFlag();
                SexyString aFlagStr = mApp->Pluralize(aFlags, gStr.ONE_FLAG.c_str(), gStr.COUNT_FLAGS.c_str());
                aSubStr = TodReplaceString(gStr.FLAGS_COMPLETED, ("{FLAGS}"), aFlagStr);
            }

            if (aSubStr.size() > 0)
            {
                TodDrawString(
                    g,
                    aSubStr,
                    BOARD_WIDTH / 2 - mApp->mBoard->mX,
                    aPosY + 26,
                    Sexy::FONT_HOUSEOFTERROR16,
                    Color(224, 187, 98, aColor.mAlpha),
                    DrawStringJustification::DS_ALIGN_CENTER
                );
            }
        }
    }
}

// ==================== t19 FormB：HEAD kStyleDraw（逐字） ====================
__declspec(noinline) void MessageWidget::Draw_B(Graphics* g)
{
    if (mDuration <= 0)
        return;

    _Font* aFont = GetFont();
    _Font* aOutlineFont = nullptr;
    int aPosX = BOARD_WIDTH / 2;
    int aPosY = 596;
    int aTextOffsetY = 0;
    int aRectHeight = 0;
    int aMinAlpha = 255;
    Color aColor(250, 250, 0, 255);
    Color aOutlineColor(0, 0, 0, 255);
    bool aFadeOut = false;
    if (aFont == Sexy::FONT_CONTINUUMBOLD14)
    {
        aOutlineFont = Sexy::FONT_CONTINUUMBOLD14OUTLINE;
    }

    // 绘制参数按 MessageStyle 槽位直查（行序 = 枚举序 0..18）。Color 构造
    // 非 constexpr，颜色以 RGBA 整数列存表，用时构造。
    static constexpr struct
    {
        int mPosX, mPosY, mRectHeight, mTextOffsetY, mMinAlpha, mR, mG, mB, mA;
        bool mFadeOut;
    } kStyleDraw[] = {
        { BOARD_WIDTH / 2, 596,   0,   0, 255, 250, 250,   0, 255, false },  // OFF（不可达）
        { BOARD_WIDTH / 2, 400, 110,  -4, 192, 253, 245, 173, 255, false },  // TUTORIAL_LEVEL1
        { BOARD_WIDTH / 2, 400, 110,  -4, 192, 253, 245, 173, 255, false },  // TUTORIAL_LEVEL1_STAY
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // TUTORIAL_LEVEL2
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // TUTORIAL_LATER
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // TUTORIAL_LATER_STAY
        { BOARD_WIDTH / 2, 527,  55,  -4, 192, 253, 245, 173, 255, false },  // HINT_LONG
        { BOARD_WIDTH / 2, 527,  55,  -4, 192, 253, 245, 173, 255, false },  // HINT_FAST
        { BOARD_WIDTH / 2, 527,  55,  -4, 192, 253, 245, 173, 255, false },  // HINT_STAY
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // HINT_TALL_FAST
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // HINT_TALL_UNLOCKMESSAGE
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // HINT_TALL_LONG
        { BOARD_WIDTH / 2, 300, 110,   0, 192, 253, 245, 173, 255, false },  // BIG_MIDDLE
        { BOARD_WIDTH / 2, 300, 110,   0, 192, 253, 245, 173, 255, false },  // BIG_MIDDLE_FAST
        { BOARD_WIDTH / 2, 550,   0,   0, 255, 255, 255, 255, 255, true  },  // HOUSE_NAME
        { BOARD_WIDTH / 2, 330,   0,   0, 255, 255,   0,   0, 255, false },  // HUGE_WAVE
        {            340,   93,   0,   0,  64, 250, 250,   0, 255, false },  // SLOT_MACHINE
        { BOARD_WIDTH / 2, 514,  55,  -4, 192, 253, 245, 173, 255, false },  // ZEN_GARDEN_LONG
        { BOARD_WIDTH / 2, 476, 100,  -4, 192, 253, 245, 173, 255, false },  // ACHIEVEMENT
    };
    static_assert(sizeof(kStyleDraw) / sizeof(kStyleDraw[0]) == (int)MessageStyle::MESSAGE_STYLE_ACHIEVEMENT + 1,
        "绘制参数槽位须与 MessageStyle 枚举同步");
    TOD_ASSERT(mMessageStyle != MessageStyle::MESSAGE_STYLE_OFF);
    {
        const auto& aParams = kStyleDraw[mMessageStyle];
        aPosX = aParams.mPosX;
        aPosY = aParams.mPosY;
        aRectHeight = aParams.mRectHeight;
        aTextOffsetY = aParams.mTextOffsetY;
        aMinAlpha = aParams.mMinAlpha;
        aColor = Color(aParams.mR, aParams.mG, aParams.mB, aParams.mA);
        aFadeOut = aParams.mFadeOut;
    }

    if (mReanimType != ReanimationType::REANIM_NONE)
    {
        if (aFont == Sexy::FONT_CONTINUUMBOLD14)
        {
            DrawReanimatedTextStub(g, Sexy::FONT_CONTINUUMBOLD14OUTLINE, Color::Black, aPosY);
        }
        DrawReanimatedTextStub(g, aFont, aColor, aPosY);
    }
    else
    {
        // 条目5：镜像串按 (属主, 内容) 比对刷新，值不变零分配
        if (gLabelStrOwner != this || gLabelStr.compare(mLabel) != 0)
        {
            gLabelStrOwner = this;
            gLabelStr.assign(mLabel);
        }
        const SexyString& aLabelStr = gLabelStr;

        if (aMinAlpha != 255)
        {
            aColor.mAlpha = TodAnimateCurve(75, 0, mApp->mBoard->mMainCounter % 75, aMinAlpha, 255, Curves::BounceSlowMiddle);
            aOutlineColor.mAlpha = aColor.mAlpha;
        }
        if (aFadeOut)
        {
            aColor.mAlpha = ClampInt(mDuration * 15, 0, 255);
            aOutlineColor.mAlpha = aColor.mAlpha;
        }

        if (aRectHeight > 0)
        {
            aOutlineColor = Color(0, 0, 0, 128);
            Rect aRect(0, aPosY, BOARD_WIDTH, aRectHeight);
            g->SetColor(aOutlineColor);
            g->FillRect(aRect);

            aRect.mY += aTextOffsetY;
            TodDrawStringWrapped(g, aLabelStr, aRect, aFont, aColor, DrawStringJustification::DS_ALIGN_CENTER_VERTICAL_MIDDLE);
        }
        else
        {
            Rect aRect(aPosX - mApp->mBoard->mX - BOARD_WIDTH / 2, aPosY - aFont->mAscent, BOARD_WIDTH, BOARD_HEIGHT);
            if (aOutlineFont)
            {
                TodDrawStringWrapped(g, aLabelStr, aRect, aOutlineFont, aOutlineColor, DrawStringJustification::DS_ALIGN_CENTER);
            }
            TodDrawStringWrapped(g, aLabelStr, aRect, aFont, aColor, DrawStringJustification::DS_ALIGN_CENTER);
        }

        if (mMessageStyle == MessageStyle::MESSAGE_STYLE_HOUSE_NAME)
        {
            SexyString aSubStr;
            if (mApp->IsSurvivalMode() && mApp->mBoard->mChallenge->mSurvivalStage > 0)
            {
                int aFlags = mApp->mBoard->GetNumWavesPerSurvivalStage() * mApp->mBoard->mChallenge->mSurvivalStage / mApp->mBoard->GetNumWavesPerFlag();
                SexyString aFlagStr = mApp->Pluralize(aFlags, gStr.ONE_FLAG.c_str(), gStr.COUNT_FLAGS.c_str());
                aSubStr = TodReplaceString(gStr.FLAGS_COMPLETED, ("{FLAGS}"), aFlagStr);
            }

            if (aSubStr.size() > 0)
            {
                TodDrawString(
                    g,
                    aSubStr,
                    BOARD_WIDTH / 2 - mApp->mBoard->mX,
                    aPosY + 26,
                    Sexy::FONT_HOUSEOFTERROR16,
                    Color(224, 187, 98, aColor.mAlpha),
                    DrawStringJustification::DS_ALIGN_CENTER
                );
            }
        }
    }
}

// ==================== b20 FormA：beaacd3b^ switch 逐字 ====================
__declspec(noinline) void MessageWidget::SetLabel_A(const SexyString& theNewLabel, MessageStyle theMessageStyle)
{
    SexyString aLabel = EntityTranslate(theNewLabel);

    if (mReanimType != ReanimationType::REANIM_NONE && mDuration > 0)
    {
        mMessageStyleNext = theMessageStyle;
        CopyMessageLabel(mLabelNext, aLabel);
        ClearLabel();
    }
    else
    {
        ClearReanim();
        CopyMessageLabel(mLabel, aLabel);
        mMessageStyle = theMessageStyle;
        mReanimType = ReanimationType::REANIM_NONE;

        switch (theMessageStyle)
        {
        case MessageStyle::MESSAGE_STYLE_HINT_LONG:
        case MessageStyle::MESSAGE_STYLE_BIG_MIDDLE:
        case MessageStyle::MESSAGE_STYLE_ZEN_GARDEN_LONG:
        case MessageStyle::MESSAGE_STYLE_HINT_TALL_LONG:
            mDuration = 1500;
            break;

        case MessageStyle::MESSAGE_STYLE_HINT_TALL_UNLOCKMESSAGE:
            mDuration = 500;
            break;

        case MessageStyle::MESSAGE_STYLE_HINT_FAST:
        case MessageStyle::MESSAGE_STYLE_HINT_TALL_FAST:
        case MessageStyle::MESSAGE_STYLE_BIG_MIDDLE_FAST:
        case MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1:
        case MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL2:
        case MessageStyle::MESSAGE_STYLE_TUTORIAL_LATER:
            mDuration = 500;
            break;

        case MessageStyle::MESSAGE_STYLE_HINT_STAY:
        case MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY:
        case MessageStyle::MESSAGE_STYLE_TUTORIAL_LATER_STAY:
            mDuration = 10000;
            break;

        case MessageStyle::MESSAGE_STYLE_HOUSE_NAME:
            mDuration = 250;
            break;

        case MessageStyle::MESSAGE_STYLE_HUGE_WAVE:
            mDuration = 750;
            mReanimType = ReanimationType::REANIM_TEXT_FADE_ON;
            break;

        case MessageStyle::MESSAGE_STYLE_SLOT_MACHINE:
            mDuration = 750;
            break;

        case MessageStyle::MESSAGE_STYLE_ACHIEVEMENT: // @Patoke: implemented
            mDuration = 250;
            break;

        default:
            TOD_ASSERT(false);
            break;
        }

        if (mReanimType != ReanimationType::REANIM_NONE)
        {
            LayoutReanimText();
        }
        mDisplayTime = mDuration;
    }
}

// ==================== b20 FormB：HEAD kMessageDurations（逐字） ====================
namespace
{
// MessageWidget::SetLabel 时长表：表内匿名 lambda = 原 case 体逐句迁移
//（生成器 + 逆变换 token 对拍 0 差异）；HUGE_WAVE 双效（时长+文字淡出
// reanim）随体迁移；default 具名并被缺槽/越界复用。
using MessageDurationCaseFn = void (*)(MessageWidget&, int);

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case MESSAGE_STYLE_HINT_LONG, MESSAGE_STYLE_BIG_MIDDLE, MESSAGE_STYLE_ZEN_GARDEN_LONG, MESSAGE_STYLE_HINT_TALL_LONG
void MsgDurationMessageStyleHintLong(MessageWidget& w, int theMessageStyle)
{
    			w.mDuration = 1500;
}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case MESSAGE_STYLE_HINT_FAST, MESSAGE_STYLE_HINT_TALL_FAST, MESSAGE_STYLE_BIG_MIDDLE_FAST, MESSAGE_STYLE_TUTORIAL_LEVEL1, MESSAGE_STYLE_TUTORIAL_LEVEL2, MESSAGE_STYLE_TUTORIAL_LATER
void MsgDurationMessageStyleHintFast(MessageWidget& w, int theMessageStyle)
{
    			w.mDuration = 500;
}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case MESSAGE_STYLE_HINT_STAY, MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, MESSAGE_STYLE_TUTORIAL_LATER_STAY
void MsgDurationMessageStyleHintStay(MessageWidget& w, int theMessageStyle)
{
    			w.mDuration = 10000;
}

// 原 default（无 case 的 1 型与表外哨兵共用）
void MsgDurationDefault(MessageWidget& w, int theMessageStyle)
{
    			TOD_ASSERT(false);
}

// 匿名 lambda 函数指针表，行序 = MessageStyle 枚举值序（0..18）。
constexpr MessageDurationCaseFn kMessageDurations[(int)MessageStyle::MESSAGE_STYLE_ACHIEVEMENT + 1] = {
    &MsgDurationDefault,  // 0 MESSAGE_STYLE_OFF（原 default）
    &MsgDurationMessageStyleHintFast,  // 1 MESSAGE_STYLE_TUTORIAL_LEVEL1（共体）
    &MsgDurationMessageStyleHintStay,  // 2 MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY（共体）
    &MsgDurationMessageStyleHintFast,  // 3 MESSAGE_STYLE_TUTORIAL_LEVEL2（共体）
    &MsgDurationMessageStyleHintFast,  // 4 MESSAGE_STYLE_TUTORIAL_LATER（共体）
    &MsgDurationMessageStyleHintStay,  // 5 MESSAGE_STYLE_TUTORIAL_LATER_STAY（共体）
    &MsgDurationMessageStyleHintLong,  // 6 MESSAGE_STYLE_HINT_LONG（共体）
    &MsgDurationMessageStyleHintFast,  // 7 MESSAGE_STYLE_HINT_FAST（共体）
    &MsgDurationMessageStyleHintStay,  // 8 MESSAGE_STYLE_HINT_STAY（共体）
    &MsgDurationMessageStyleHintFast,  // 9 MESSAGE_STYLE_HINT_TALL_FAST（共体）
    // 原 case MESSAGE_STYLE_HINT_TALL_UNLOCKMESSAGE
    [](MessageWidget& w, int theMessageStyle)
    {
    			w.mDuration = 500;
    },  // 10 MESSAGE_STYLE_HINT_TALL_UNLOCKMESSAGE
    &MsgDurationMessageStyleHintLong,  // 11 MESSAGE_STYLE_HINT_TALL_LONG（共体）
    &MsgDurationMessageStyleHintLong,  // 12 MESSAGE_STYLE_BIG_MIDDLE（共体）
    &MsgDurationMessageStyleHintFast,  // 13 MESSAGE_STYLE_BIG_MIDDLE_FAST（共体）
    // 原 case MESSAGE_STYLE_HOUSE_NAME
    [](MessageWidget& w, int theMessageStyle)
    {
    			w.mDuration = 250;
    },  // 14 MESSAGE_STYLE_HOUSE_NAME
    // 原 case MESSAGE_STYLE_HUGE_WAVE
    [](MessageWidget& w, int theMessageStyle)
    {
    			w.mDuration = 750;
    			w.mReanimType = ReanimationType::REANIM_TEXT_FADE_ON;
    },  // 15 MESSAGE_STYLE_HUGE_WAVE
    // 原 case MESSAGE_STYLE_SLOT_MACHINE
    [](MessageWidget& w, int theMessageStyle)
    {
    			w.mDuration = 750;
    },  // 16 MESSAGE_STYLE_SLOT_MACHINE
    &MsgDurationMessageStyleHintLong,  // 17 MESSAGE_STYLE_ZEN_GARDEN_LONG（共体）
    // 原 case MESSAGE_STYLE_ACHIEVEMENT
    [](MessageWidget& w, int theMessageStyle)
    {
    // @Patoke: implemented
    			w.mDuration = 250;
    },  // 18 MESSAGE_STYLE_ACHIEVEMENT
};
static_assert(sizeof(kMessageDurations) / sizeof(kMessageDurations[0]) ==
    (int)MessageStyle::MESSAGE_STYLE_ACHIEVEMENT + 1, "kMessageDurations 槽位数须与 MessageStyle 枚举同步");
}  // namespace

//0x459010
__declspec(noinline) void MessageWidget::SetLabel_B(const SexyString& theNewLabel, MessageStyle theMessageStyle)
{
    SexyString aLabel = EntityTranslate(theNewLabel);

    if (mReanimType != ReanimationType::REANIM_NONE && mDuration > 0)
    {
        mMessageStyleNext = theMessageStyle;
        CopyMessageLabel(mLabelNext, aLabel);
        ClearLabel();
    }
    else
    {
        ClearReanim();
        CopyMessageLabel(mLabel, aLabel);
        mMessageStyle = theMessageStyle;
        mReanimType = ReanimationType::REANIM_NONE;

        // C 形态 -> 匿名 lambda 函数指针表：行序 = MessageStyle 枚举序（0..18，
        // 无 NUM 哨兵=末值 ACHIEVEMENT 锚定）；default（TOD_ASSERT）具名并被
        // 缺槽/越界复用。
        const unsigned aStyleIndex = static_cast<unsigned>(theMessageStyle);
        if (aStyleIndex <= static_cast<unsigned>(MessageStyle::MESSAGE_STYLE_ACHIEVEMENT))
        {
            kMessageDurations[aStyleIndex](*this, (int)theMessageStyle);
        }
        else
        {
            MsgDurationDefault(*this, (int)theMessageStyle);
        }


        if (mReanimType != ReanimationType::REANIM_NONE)
        {
            LayoutReanimText();
        }
        mDisplayTime = mDuration;
    }
}

// ============================ main ============================
static MessageWidget g_msg;
static Board g_board;
static LawnApp g_app;
static Challenge g_chal;
static CutScene g_cut;
static Graphics g_gfx;
static SexyString gNewLabel("ZOMBIES WON!");

static void ResetMsg(const R3Input& in)
{
    g_msg.mApp = &g_app;
    g_msg.mBoard = &g_board;
    g_app.mBoard = &g_board;
    g_board.mApp = &g_app;
    g_board.mChallenge = &g_chal;
    g_board.mCutScene = &g_cut;
    g_board.mMainCounter = (int)(in.a % 3000);
    g_board.mX = (int)(in.b % 40);
    g_msg.mMessageStyle = (MessageStyle)(1 + in.c % 18);   // 1..18（OFF 不可达：原 default 断言）
    g_msg.mDuration = (int)(in.d % 2000) + 1;              // >0 触发绘制路径
    g_msg.mReanimType = (in.a % 4 == 0) ? ReanimationType::REANIM_TEXT_FADE_ON : ReanimationType::REANIM_NONE;
    g_msg.mLabel = "LABEL";
}

int main()
{
    int rc = 0;
    {
        auto reset = []() { gLabelStr.clear(); };
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetMsg(g_inputs[i]);
                g_msg.Draw_A(&g_gfx);
                g_msg.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetMsg(g_inputs[i]);
                g_msg.Draw_B(&g_gfx);
                g_msg.HashFold(ck);
            }
        };
        rc |= R3BenchMain("t19_MessageWidget_Draw_kStyleDraw", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetMsg(g_inputs[i]);
                g_msg.mDuration = 0;
                g_msg.mReanimType = ReanimationType::REANIM_NONE;
                g_msg.SetLabel_A(gNewLabel, (MessageStyle)(1 + g_inputs[i].c % 18));
                g_msg.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetMsg(g_inputs[i]);
                g_msg.mDuration = 0;
                g_msg.mReanimType = ReanimationType::REANIM_NONE;
                g_msg.SetLabel_B(gNewLabel, (MessageStyle)(1 + g_inputs[i].c % 18));
                g_msg.HashFold(ck);
            }
        };
        rc |= R3BenchMain("b20_MessageWidget_SetLabel_kMessageDurations", reset, pa, pb);
    }
    return rc;
}
