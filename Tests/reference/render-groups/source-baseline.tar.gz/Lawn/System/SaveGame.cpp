#include "Music.h"
#include "SaveGame.h"
#include "LevelSaveFormat.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include "../CursorObject.h"
#include "../../Resources.h"
#include "../../ConstEnums.h"
#include "../MessageWidget.h"
#include "../../Sexy.TodLib/Trail.h"
#include <zlib.h>
#include "../../Sexy.TodLib/Attachment.h"
#include "../../Sexy.TodLib/Reanimator.h"
#include "../../Sexy.TodLib/TodParticle.h"
#include "../../Sexy.TodLib/EffectSystem.h"

#include <climits>
#include <cstdint>
#include <cstring>
#include <memory>
#include <vector>

// 1073 stores the CRC32 of this exact, intentionally space-less build string.
// "Feb 16 200923:03:38" belongs to the older executable and produces a
// different header, so a 1073 in-progress save is rejected before its board is
// even inspected if that value leaks into Legacy.
static const char* FILE_COMPILE_TIME_STRING = "Jul  2 201011:47:03";
static const unsigned int SAVE_FILE_MAGIC_NUMBER = 0xFEEDDEAD;
static const unsigned int SAVE_FILE_VERSION = 2U;
static unsigned int SAVE_FILE_DATE = crc32(0, (Bytef*)FILE_COMPILE_TIME_STRING, strlen(FILE_COMPILE_TIME_STRING));  //[0x6AA7EC]

namespace
{
using LegacyByte = unsigned char;

template <typename T>
LegacyByte* ObjectBytes(T& theObject)
{
	return reinterpret_cast<LegacyByte*>(&theObject);
}

template <typename T>
const LegacyByte* ObjectBytes(const T& theObject)
{
	return reinterpret_cast<const LegacyByte*>(&theObject);
}

void CopyFromLegacy(
	void* theNativeDestination,
	const LegacyByte* theLegacySource,
	size_t theLegacyOffset,
	size_t theLength)
{
	std::memcpy(theNativeDestination, theLegacySource + theLegacyOffset, theLength);
}

void CopyToLegacy(
	LegacyByte* theLegacyDestination,
	size_t theLegacyOffset,
	const void* theNativeSource,
	size_t theLength)
{
	std::memcpy(theLegacyDestination + theLegacyOffset, theNativeSource, theLength);
}

template <typename T>
void ClearNativeObject(T& theObject)
{
	std::memset(ObjectBytes(theObject), 0, sizeof(T));
}

template <typename T>
struct Legacy1073Layout;

// GameObject has two pointers in front of 28 bytes of fixed-width state. On
// x64 the derived object starts at 48 rather than 36 because the base has an
// additional four bytes of tail padding. All classes using this helper have a
// pointer-free derived tail in the 1073 save image.
template <typename T>
void ReadGameObjectLayout(
	T& theObject,
	const LegacyByte* theLegacy,
	size_t theLegacySize,
	void* theFirstDerivedField)
{
	ClearNativeObject(theObject);
	CopyFromLegacy(&theObject.mX, theLegacy, 8, 28);
	CopyFromLegacy(theFirstDerivedField, theLegacy, 36, theLegacySize - 36);
}

template <typename T>
void WriteGameObjectLayout(
	LegacyByte* theLegacy,
	size_t theLegacySize,
	const T& theObject,
	const void* theFirstDerivedField)
{
	CopyToLegacy(theLegacy, 8, &theObject.mX, 28);
	CopyToLegacy(theLegacy, 36, theFirstDerivedField, theLegacySize - 36);
}

template <>
struct Legacy1073Layout<Zombie>
{
	static constexpr size_t SIZE = 356;
	static void Read(Zombie& v, const LegacyByte* p)
	{
		ReadGameObjectLayout(v, p, SIZE, &v.mZombieType);
	}
	static void Write(LegacyByte* p, const Zombie& v)
	{
		WriteGameObjectLayout(p, SIZE, v, &v.mZombieType);
	}
};

template <>
struct Legacy1073Layout<Plant>
{
	static constexpr size_t SIZE = 328;
	static void Read(Plant& v, const LegacyByte* p)
	{
		ReadGameObjectLayout(v, p, SIZE, &v.mSeedType);
	}
	static void Write(LegacyByte* p, const Plant& v)
	{
		WriteGameObjectLayout(p, SIZE, v, &v.mSeedType);
	}
};

template <>
struct Legacy1073Layout<Projectile>
{
	static constexpr size_t SIZE = 144;
	static void Read(Projectile& v, const LegacyByte* p)
	{
		ReadGameObjectLayout(v, p, SIZE, &v.mFrame);
	}
	static void Write(LegacyByte* p, const Projectile& v)
	{
		WriteGameObjectLayout(p, SIZE, v, &v.mFrame);
	}
};

template <>
struct Legacy1073Layout<Coin>
{
	static constexpr size_t SIZE = 208;
	static void Read(Coin& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mX, p, 8, 28);
		CopyFromLegacy(&v.mPosX, p, 36, 72);
		// PottedPlant is 8-byte aligned in x86 but follows immediately after
		// mUsableSeedType in the x64 class. Its own 88-byte layout is stable.
		CopyFromLegacy(&v.mPottedPlantSpec, p, 112, 96);
	}
	static void Write(LegacyByte* p, const Coin& v)
	{
		CopyToLegacy(p, 8, &v.mX, 28);
		CopyToLegacy(p, 36, &v.mPosX, 72);
		CopyToLegacy(p, 112, &v.mPottedPlantSpec, 96);
	}
};

template <>
struct Legacy1073Layout<LawnMower>
{
	static constexpr size_t SIZE = 68;
	static void Read(LawnMower& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mPosX, p, 8, SIZE - 8);
	}
	static void Write(LegacyByte* p, const LawnMower& v)
	{
		CopyToLegacy(p, 8, &v.mPosX, SIZE - 8);
	}
};

template <>
struct Legacy1073Layout<GridItem>
{
	static constexpr size_t SIZE = 232;
	static void Read(GridItem& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mGridItemType, p, 8, SIZE - 8);
	}
	static void Write(LegacyByte* p, const GridItem& v)
	{
		CopyToLegacy(p, 8, &v.mGridItemType, SIZE - 8);
	}
};

template <>
struct Legacy1073Layout<TodParticleSystem>
{
	static constexpr size_t SIZE = 40;
	static void Read(TodParticleSystem& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mEffectType, p, 0, 4);
		CopyFromLegacy(&v.mDead, p, 28, 12);
	}
	static void Write(LegacyByte* p, const TodParticleSystem& v)
	{
		CopyToLegacy(p, 0, &v.mEffectType, 4);
		CopyToLegacy(p, 28, &v.mDead, 12);
	}
};

template <>
struct Legacy1073Layout<TodParticleEmitter>
{
	static constexpr size_t SIZE = 172;
	static void Read(TodParticleEmitter& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mSpawnAccum, p, 24, 60);
		CopyFromLegacy(&v.mCrossFadeEmitterID, p, 88, 84);
	}
	static void Write(LegacyByte* p, const TodParticleEmitter& v)
	{
		CopyToLegacy(p, 24, &v.mSpawnAccum, 60);
		CopyToLegacy(p, 88, &v.mCrossFadeEmitterID, 84);
	}
};

template <>
struct Legacy1073Layout<TodParticle>
{
	static constexpr size_t SIZE = 156;
	static void Read(TodParticle& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mParticleDuration, p, 4, SIZE - 4);
	}
	static void Write(LegacyByte* p, const TodParticle& v)
	{
		CopyToLegacy(p, 4, &v.mParticleDuration, SIZE - 4);
	}
};

template <>
struct Legacy1073Layout<Reanimation>
{
	static constexpr size_t SIZE = 156;
	static void Read(Reanimation& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mReanimationType, p, 0, 12);
		CopyFromLegacy(&v.mLoopType, p, 16, 72);
		CopyFromLegacy(&v.mLoopCount, p, 92, 4);
		CopyFromLegacy(&v.mIsAttachment, p, 100, 56);
	}
	static void Write(LegacyByte* p, const Reanimation& v)
	{
		CopyToLegacy(p, 0, &v.mReanimationType, 12);
		CopyToLegacy(p, 16, &v.mLoopType, 72);
		CopyToLegacy(p, 92, &v.mLoopCount, 4);
		CopyToLegacy(p, 100, &v.mIsAttachment, 56);
	}
};

template <>
struct Legacy1073Layout<Trail>
{
	static constexpr size_t SIZE = 232;
	static void Read(Trail& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mTrailPoints, p, 0, 180);
		CopyFromLegacy(&v.mTrailInterp, p, 188, 44);
	}
	static void Write(LegacyByte* p, const Trail& v)
	{
		CopyToLegacy(p, 0, &v.mTrailPoints, 180);
		CopyToLegacy(p, 188, &v.mTrailInterp, 44);
	}
};

template <>
struct Legacy1073Layout<Attachment>
{
	static constexpr size_t SIZE = 776;
	static void Read(Attachment& v, const LegacyByte* p)
	{
		std::memcpy(&v, p, SIZE);
	}
	static void Write(LegacyByte* p, const Attachment& v)
	{
		std::memcpy(p, &v, SIZE);
	}
};

template <>
struct Legacy1073Layout<CursorObject>
{
	static constexpr size_t SIZE = 76;
	static void Read(CursorObject& v, const LegacyByte* p)
	{
		ReadGameObjectLayout(v, p, SIZE, &v.mSeedBankIndex);
	}
	static void Write(LegacyByte* p, const CursorObject& v)
	{
		WriteGameObjectLayout(p, SIZE, v, &v.mSeedBankIndex);
	}
};

template <>
struct Legacy1073Layout<CursorPreview>
{
	static constexpr size_t SIZE = 44;
	static void Read(CursorPreview& v, const LegacyByte* p)
	{
		ReadGameObjectLayout(v, p, SIZE, &v.mGridX);
	}
	static void Write(LegacyByte* p, const CursorPreview& v)
	{
		WriteGameObjectLayout(p, SIZE, v, &v.mGridX);
	}
};

template <>
struct Legacy1073Layout<MessageWidget>
{
	static constexpr size_t SIZE = 796;
	static void Read(MessageWidget& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mLabel, p, 4, SIZE - 4);
	}
	static void Write(LegacyByte* p, const MessageWidget& v)
	{
		CopyToLegacy(p, 4, &v.mLabel, SIZE - 4);
	}
};

template <>
struct Legacy1073Layout<SeedPacket>
{
	static constexpr size_t SIZE = 80;
	static void Read(SeedPacket& v, const LegacyByte* p)
	{
		ReadGameObjectLayout(v, p, SIZE, &v.mRefreshCounter);
	}
	static void Write(LegacyByte* p, const SeedPacket& v)
	{
		WriteGameObjectLayout(p, SIZE, v, &v.mRefreshCounter);
	}
};

template <>
struct Legacy1073Layout<SeedBank>
{
	static constexpr size_t SIZE = 848;
	static void Read(SeedBank& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mX, p, 8, 28);
		CopyFromLegacy(&v.mNumPackets, p, 36, 4);
		for (int i = 0; i < SEEDBANK_MAX; ++i)
		{
			Legacy1073Layout<SeedPacket>::Read(
				v.mSeedPackets[i],
				p + 40 + i * Legacy1073Layout<SeedPacket>::SIZE);
		}
		CopyFromLegacy(&v.mCutSceneDarken, p, 840, 8);
	}
	static void Write(LegacyByte* p, const SeedBank& v)
	{
		CopyToLegacy(p, 8, &v.mX, 28);
		CopyToLegacy(p, 36, &v.mNumPackets, 4);
		for (int i = 0; i < SEEDBANK_MAX; ++i)
		{
			Legacy1073Layout<SeedPacket>::Write(
				p + 40 + i * Legacy1073Layout<SeedPacket>::SIZE,
				v.mSeedPackets[i]);
		}
		CopyToLegacy(p, 840, &v.mCutSceneDarken, 8);
	}
};

template <>
struct Legacy1073Layout<Challenge>
{
	static constexpr size_t SIZE = 188;
	static void Read(Challenge& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mBeghouledMouseCapture, p, 8, SIZE - 8);
	}
	static void Write(LegacyByte* p, const Challenge& v)
	{
		CopyToLegacy(p, 8, &v.mBeghouledMouseCapture, SIZE - 8);
	}
};

template <>
struct Legacy1073Layout<Music>
{
	static constexpr size_t SIZE = 76;
	static void Read(Music& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mCurMusicTune, p, 8, SIZE - 8);
	}
	static void Write(LegacyByte* p, const Music& v)
	{
		CopyToLegacy(p, 8, &v.mCurMusicTune, SIZE - 8);
	}
};

template <>
struct Legacy1073Layout<ReanimatorTrackInstance>
{
	static constexpr size_t SIZE = 96;
	static void Read(ReanimatorTrackInstance& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		CopyFromLegacy(&v.mBlendCounter, p, 0, 40);
		CopyFromLegacy(&v.mShakeOverride, p, 52, 16);
		CopyFromLegacy(&v.mRenderGroup, p, 72, 24);
	}
	static void Write(LegacyByte* p, const ReanimatorTrackInstance& v)
	{
		CopyToLegacy(p, 0, &v.mBlendCounter, 40);
		CopyToLegacy(p, 52, &v.mShakeOverride, 16);
		CopyToLegacy(p, 72, &v.mRenderGroup, 24);
	}
};

template <typename T>
struct Dat64Layout;

template <typename T, LevelSaveFormat::RecordKind Kind>
struct MappedDat64Layout
{
	static constexpr auto& RECORD = LevelSaveFormat::GetRecordLayout(Kind);
	static constexpr size_t SIZE = RECORD.mDat64Size;

	static void Read(T& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		for (size_t i = 0; i < RECORD.mSegmentCount; ++i)
		{
			const auto& aSegment = RECORD.mSegments[i];
			std::memcpy(
				ObjectBytes(v) + aSegment.mDat64Offset,
				p + aSegment.mDat64Offset,
				aSegment.mSize);
		}
	}

	static void Write(LegacyByte* p, const T& v)
	{
		for (size_t i = 0; i < RECORD.mSegmentCount; ++i)
		{
			const auto& aSegment = RECORD.mSegments[i];
			std::memcpy(
				p + aSegment.mDat64Offset,
				ObjectBytes(v) + aSegment.mDat64Offset,
				aSegment.mSize);
		}
	}
};

#define DECLARE_DAT64_LAYOUT(Type, KindName) \
	template <> \
	struct Dat64Layout<Type> \
		: MappedDat64Layout<Type, LevelSaveFormat::RecordKind::KindName> \
	{};

DECLARE_DAT64_LAYOUT(Zombie, Zombie);
DECLARE_DAT64_LAYOUT(Plant, Plant);
DECLARE_DAT64_LAYOUT(Projectile, Projectile);
DECLARE_DAT64_LAYOUT(Coin, Coin);
DECLARE_DAT64_LAYOUT(LawnMower, LawnMower);
DECLARE_DAT64_LAYOUT(GridItem, GridItem);
DECLARE_DAT64_LAYOUT(TodParticleSystem, ParticleSystem);
DECLARE_DAT64_LAYOUT(TodParticleEmitter, ParticleEmitter);
DECLARE_DAT64_LAYOUT(TodParticle, Particle);
DECLARE_DAT64_LAYOUT(Reanimation, Reanimation);
DECLARE_DAT64_LAYOUT(Trail, Trail);
DECLARE_DAT64_LAYOUT(Attachment, Attachment);
DECLARE_DAT64_LAYOUT(CursorObject, CursorObject);
DECLARE_DAT64_LAYOUT(CursorPreview, CursorPreview);
DECLARE_DAT64_LAYOUT(MessageWidget, MessageWidget);
DECLARE_DAT64_LAYOUT(SeedPacket, SeedPacket);
DECLARE_DAT64_LAYOUT(Challenge, Challenge);
DECLARE_DAT64_LAYOUT(Music, Music);
DECLARE_DAT64_LAYOUT(ReanimatorTrackInstance, ReanimatorTrackInstance);

#undef DECLARE_DAT64_LAYOUT

template <>
struct Dat64Layout<SeedBank>
{
	static constexpr size_t SIZE = LevelSaveFormat::DAT64_SEED_BANK_SIZE;

	static void Read(SeedBank& v, const LegacyByte* p)
	{
		ClearNativeObject(v);
		std::memcpy(ObjectBytes(v) + 16, p + 16, 28);
		std::memcpy(ObjectBytes(v) + 48, p + 48, 4);
		for (size_t i = 0; i < LevelSaveFormat::SEED_BANK_PACKET_COUNT; ++i)
		{
			Dat64Layout<SeedPacket>::Read(
				v.mSeedPackets[i],
				p + LevelSaveFormat::DAT64_SEED_BANK_PACKET_OFFSET +
					i * Dat64Layout<SeedPacket>::SIZE);
		}
		std::memcpy(
			&v.mCutSceneDarken,
			p + LevelSaveFormat::DAT64_SEED_BANK_TAIL_OFFSET,
			LevelSaveFormat::SEED_BANK_TAIL_SIZE);
	}

	static void Write(LegacyByte* p, const SeedBank& v)
	{
		std::memcpy(p + 16, ObjectBytes(v) + 16, 28);
		std::memcpy(p + 48, ObjectBytes(v) + 48, 4);
		for (size_t i = 0; i < LevelSaveFormat::SEED_BANK_PACKET_COUNT; ++i)
		{
			Dat64Layout<SeedPacket>::Write(
				p + LevelSaveFormat::DAT64_SEED_BANK_PACKET_OFFSET +
					i * Dat64Layout<SeedPacket>::SIZE,
				v.mSeedPackets[i]);
		}
		std::memcpy(
			p + LevelSaveFormat::DAT64_SEED_BANK_TAIL_OFFSET,
			&v.mCutSceneDarken,
			LevelSaveFormat::SEED_BANK_TAIL_SIZE);
	}
};

static_assert(sizeof(Zombie) == 368);
static_assert(sizeof(Plant) == 344);
static_assert(sizeof(Projectile) == 160);
static_assert(sizeof(Coin) == 216);
static_assert(sizeof(LawnMower) == 80);
static_assert(sizeof(GridItem) == 240);
static_assert(sizeof(TodParticleSystem) == 72);
static_assert(sizeof(TodParticleEmitter) == 208);
static_assert(sizeof(TodParticle) == 160);
static_assert(sizeof(Reanimation) == 176);
static_assert(sizeof(Trail) == 248);
static_assert(sizeof(Attachment) == 776);
static_assert(sizeof(CursorObject) == 88);
static_assert(sizeof(CursorPreview) == 56);
static_assert(sizeof(MessageWidget) == 800);
static_assert(sizeof(SeedPacket) == 96);
static_assert(sizeof(SeedBank) == 1024);
static_assert(sizeof(Challenge) == 200);
static_assert(sizeof(Music) == 88);
static_assert(sizeof(ReanimatorTrackInstance) == 112);
static_assert(sizeof(typename DataArray<Zombie>::DataArrayItem) == 376);
static_assert(sizeof(typename DataArray<Plant>::DataArrayItem) == 352);
static_assert(sizeof(typename DataArray<Projectile>::DataArrayItem) == 168);
static_assert(sizeof(typename DataArray<Coin>::DataArrayItem) == 224);
static_assert(sizeof(typename DataArray<LawnMower>::DataArrayItem) == 88);
static_assert(sizeof(typename DataArray<GridItem>::DataArrayItem) == 248);
static_assert(sizeof(typename DataArray<TodParticleSystem>::DataArrayItem) == 80);
static_assert(sizeof(typename DataArray<TodParticleEmitter>::DataArrayItem) == 216);
static_assert(sizeof(typename DataArray<TodParticle>::DataArrayItem) == 168);
static_assert(sizeof(typename DataArray<Reanimation>::DataArrayItem) == 184);
static_assert(sizeof(typename DataArray<Trail>::DataArrayItem) == 256);
static_assert(sizeof(typename DataArray<Attachment>::DataArrayItem) == 780);

template <typename T>
inline constexpr size_t LEGACY_1073_DATA_ARRAY_ITEM_SIZE =
	Legacy1073Layout<T>::SIZE + sizeof(uint32_t);

// Coin contains PottedPlant's 64-bit timestamps. MSVC x86 gives Coin 8-byte
// alignment, so DataArray<Coin>::DataArrayItem has four tail-padding bytes
// after its 32-bit ID. The official game3_13.dat confirms 216-byte slots.
template <>
inline constexpr size_t LEGACY_1073_DATA_ARRAY_ITEM_SIZE<Coin> = 216;
}

//0x4813D0
void SaveGameContext::SyncBytes(void* theDest, int theReadSize)
{
	int aReadSize = theReadSize;
	if (mReading)
	{
		if ((unsigned long)ByteLeftToRead() < 4)
		{
			mFailed = true;
		}

		aReadSize = mFailed ? 0 : mBuffer.ReadLong();
	}
	else
	{
		mBuffer.WriteLong(theReadSize);
	}

	if (mReading)
	{
		if (aReadSize != theReadSize || ByteLeftToRead() < theReadSize)
		{
			mFailed = true;
		}

		if (mFailed)
		{
			memset(theDest, 0, theReadSize);
		}
		else
		{
			mBuffer.ReadBytes((uchar*)theDest, theReadSize);
		}
	}
	else
	{
		mBuffer.WriteBytes((uchar*)theDest, theReadSize);
	}
}

//0x481470
void SaveGameContext::SyncInt(int& theInt)
{
	if (mReading)
	{
		if ((unsigned long)ByteLeftToRead() < 4)
		{
			mFailed = true;
		}

		theInt = mFailed ? 0 : mBuffer.ReadLong();
	}
	else
	{
		mBuffer.WriteLong(theInt);
	}
}

namespace
{
template <typename T>
void SyncLegacy1073Object(SaveGameContext& theContext, T& theObject)
{
	std::vector<LegacyByte> aLegacyBytes(Legacy1073Layout<T>::SIZE, 0);
	if (!theContext.mReading)
	{
		Legacy1073Layout<T>::Write(aLegacyBytes.data(), theObject);
	}

	theContext.SyncBytes(
		aLegacyBytes.data(),
		static_cast<int>(aLegacyBytes.size()));
	if (theContext.mReading && !theContext.mFailed)
	{
		Legacy1073Layout<T>::Read(theObject, aLegacyBytes.data());
	}
}

template <typename T>
void SyncDat64Object(SaveGameContext& theContext, T& theObject)
{
	static_assert(Dat64Layout<T>::SIZE == sizeof(T));
	std::vector<LegacyByte> aDat64Bytes(Dat64Layout<T>::SIZE, 0);
	if (!theContext.mReading)
	{
		Dat64Layout<T>::Write(aDat64Bytes.data(), theObject);
	}

	theContext.SyncBytes(
		aDat64Bytes.data(),
		static_cast<int>(aDat64Bytes.size()));
	if (theContext.mReading && !theContext.mFailed)
	{
		Dat64Layout<T>::Read(theObject, aDat64Bytes.data());
	}
}

template <typename T>
void SyncLegacy1073DataArray(
	SaveGameContext& theContext,
	DataArray<T>& theDataArray)
{
	theContext.SyncUint(theDataArray.mFreeListHead);
	theContext.SyncUint(theDataArray.mMaxUsedCount);
	theContext.SyncUint(theDataArray.mSize);

	constexpr size_t aLegacyItemSize = LEGACY_1073_DATA_ARRAY_ITEM_SIZE<T>;
	if (theDataArray.mMaxUsedCount > theDataArray.mMaxSize ||
		theDataArray.mSize > theDataArray.mMaxUsedCount ||
		theDataArray.mFreeListHead > theDataArray.mMaxUsedCount ||
		theDataArray.mMaxUsedCount > static_cast<size_t>(INT_MAX) / aLegacyItemSize)
	{
		theContext.mFailed = true;
		return;
	}

	const size_t aLegacyBlockSize =
		static_cast<size_t>(theDataArray.mMaxUsedCount) * aLegacyItemSize;
	std::vector<LegacyByte> aLegacyBlock(aLegacyBlockSize, 0);
	LegacyByte anEmptyBlockByte = 0;
	if (!theContext.mReading)
	{
		for (unsigned int i = 0; i < theDataArray.mMaxUsedCount; ++i)
		{
			auto& aNativeItem = theDataArray.mBlock[i];
			LegacyByte* aLegacyItem = aLegacyBlock.data() + i * aLegacyItemSize;
			if (aNativeItem.mID & DATA_ARRAY_KEY_MASK)
			{
				Legacy1073Layout<T>::Write(aLegacyItem, aNativeItem.mItem);
			}
			std::memcpy(
				aLegacyItem + Legacy1073Layout<T>::SIZE,
				&aNativeItem.mID,
				sizeof(aNativeItem.mID));
		}
	}

	theContext.SyncBytes(
		aLegacyBlock.empty() ? &anEmptyBlockByte : aLegacyBlock.data(),
		static_cast<int>(aLegacyBlock.size()));
	if (!theContext.mReading || theContext.mFailed)
	{
		return;
	}

	for (unsigned int i = 0; i < theDataArray.mMaxUsedCount; ++i)
	{
		auto& aNativeItem = theDataArray.mBlock[i];
		const LegacyByte* aLegacyItem =
			aLegacyBlock.data() + i * aLegacyItemSize;
		std::memcpy(
			&aNativeItem.mID,
			aLegacyItem + Legacy1073Layout<T>::SIZE,
			sizeof(aNativeItem.mID));
		if (aNativeItem.mID & DATA_ARRAY_KEY_MASK)
		{
			Legacy1073Layout<T>::Read(aNativeItem.mItem, aLegacyItem);
		}
		else
		{
			ClearNativeObject(aNativeItem.mItem);
		}
	}
}

template <typename T>
void SyncDat64DataArray(
	SaveGameContext& theContext,
	DataArray<T>& theDataArray)
{
	static_assert(Dat64Layout<T>::SIZE == sizeof(T));
	using DataArrayItem = typename DataArray<T>::DataArrayItem;

	theContext.SyncUint(theDataArray.mFreeListHead);
	theContext.SyncUint(theDataArray.mMaxUsedCount);
	theContext.SyncUint(theDataArray.mSize);

	constexpr size_t aDat64ItemSize = sizeof(DataArrayItem);
	if (theDataArray.mMaxUsedCount > theDataArray.mMaxSize ||
		theDataArray.mSize > theDataArray.mMaxUsedCount ||
		theDataArray.mFreeListHead > theDataArray.mMaxUsedCount ||
		theDataArray.mMaxUsedCount > static_cast<size_t>(INT_MAX) / aDat64ItemSize)
	{
		theContext.mFailed = true;
		return;
	}

	const size_t aDat64BlockSize =
		static_cast<size_t>(theDataArray.mMaxUsedCount) * aDat64ItemSize;
	std::vector<LegacyByte> aDat64Block(aDat64BlockSize, 0);
	LegacyByte anEmptyBlockByte = 0;
	if (!theContext.mReading)
	{
		for (unsigned int i = 0; i < theDataArray.mMaxUsedCount; ++i)
		{
			auto& aNativeItem = theDataArray.mBlock[i];
			LegacyByte* aDat64Item = aDat64Block.data() + i * aDat64ItemSize;
			if (aNativeItem.mID & DATA_ARRAY_KEY_MASK)
			{
				Dat64Layout<T>::Write(aDat64Item, aNativeItem.mItem);
			}
			std::memcpy(
				aDat64Item + Dat64Layout<T>::SIZE,
				&aNativeItem.mID,
				sizeof(aNativeItem.mID));
		}
	}

	theContext.SyncBytes(
		aDat64Block.empty() ? &anEmptyBlockByte : aDat64Block.data(),
		static_cast<int>(aDat64Block.size()));
	if (!theContext.mReading || theContext.mFailed)
	{
		return;
	}

	for (unsigned int i = 0; i < theDataArray.mMaxUsedCount; ++i)
	{
		auto& aNativeItem = theDataArray.mBlock[i];
		const LegacyByte* aDat64Item =
			aDat64Block.data() + i * aDat64ItemSize;
		std::memcpy(
			&aNativeItem.mID,
			aDat64Item + Dat64Layout<T>::SIZE,
			sizeof(aNativeItem.mID));
		if (aNativeItem.mID & DATA_ARRAY_KEY_MASK)
		{
			Dat64Layout<T>::Read(aNativeItem.mItem, aDat64Item);
		}
		else
		{
			ClearNativeObject(aNativeItem.mItem);
		}
	}
}

void SyncLegacy1073BoardState(
	SaveGameContext& theContext,
	Board& theBoard)
{
	static constexpr size_t LEGACY_BOARD_STATE_SIZE = 22108;
	static constexpr size_t LEGACY_GAME_ID_OFFSET = 22076;
	static constexpr size_t LEGACY_AFTER_GAME_ID_OFFSET = 22080;
	static constexpr size_t LEGACY_AFTER_GAME_ID_SIZE = 28;

	std::vector<LegacyByte> aLegacyBytes(LEGACY_BOARD_STATE_SIZE, 0);
	LegacyByte* aNativeStart = reinterpret_cast<LegacyByte*>(&theBoard.mPaused);
	const size_t aNativeSize =
		reinterpret_cast<LegacyByte*>(&theBoard + 1) - aNativeStart;
	if (aNativeSize != 22120)
	{
		theContext.mFailed = true;
		return;
	}

	if (!theContext.mReading)
	{
		std::memcpy(
			aLegacyBytes.data(),
			aNativeStart,
			LEGACY_GAME_ID_OFFSET);
		const int32_t aLegacyGameID = static_cast<int32_t>(theBoard.mGameID);
		std::memcpy(
			aLegacyBytes.data() + LEGACY_GAME_ID_OFFSET,
			&aLegacyGameID,
			sizeof(aLegacyGameID));
		std::memcpy(
			aLegacyBytes.data() + LEGACY_AFTER_GAME_ID_OFFSET,
			&theBoard.mGravesCleared,
			LEGACY_AFTER_GAME_ID_SIZE);
	}

	theContext.SyncBytes(
		aLegacyBytes.data(),
		static_cast<int>(aLegacyBytes.size()));
	if (!theContext.mReading || theContext.mFailed)
	{
		return;
	}

	std::memset(aNativeStart, 0, aNativeSize);
	std::memcpy(
		aNativeStart,
		aLegacyBytes.data(),
		LEGACY_GAME_ID_OFFSET);
	int32_t aLegacyGameID = 0;
	std::memcpy(
		&aLegacyGameID,
		aLegacyBytes.data() + LEGACY_GAME_ID_OFFSET,
		sizeof(aLegacyGameID));
	theBoard.mGameID = static_cast<intptr_t>(aLegacyGameID);
	std::memcpy(
		&theBoard.mGravesCleared,
		aLegacyBytes.data() + LEGACY_AFTER_GAME_ID_OFFSET,
		LEGACY_AFTER_GAME_ID_SIZE);
}

void SyncDat64BoardState(
	SaveGameContext& theContext,
	Board& theBoard)
{
	LegacyByte* aNativeStart = reinterpret_cast<LegacyByte*>(&theBoard.mPaused);
	const size_t aNativeSize =
		reinterpret_cast<LegacyByte*>(&theBoard + 1) - aNativeStart;
	if (aNativeSize != LevelSaveFormat::DAT64_BOARD_STATE_SIZE)
	{
		theContext.mFailed = true;
		return;
	}

	std::vector<LegacyByte> aDat64Bytes(aNativeSize, 0);
	if (!theContext.mReading)
	{
		std::memcpy(aDat64Bytes.data(), aNativeStart, aNativeSize);
		// x64 aligns intptr_t mGameID to eight bytes.  The four bytes before it
		// are schema padding, not game state, and must be deterministic so the
		// standalone converter can reject pointer/padding contamination.
		std::memset(
			aDat64Bytes.data() + LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET,
			0,
			LevelSaveFormat::DAT64_BOARD_GAME_ID_OFFSET -
				LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET);
	}

	theContext.SyncBytes(
		aDat64Bytes.data(),
		static_cast<int>(aDat64Bytes.size()));
	if (theContext.mReading && !theContext.mFailed)
	{
		std::memset(aNativeStart, 0, aNativeSize);
		std::memcpy(aNativeStart, aDat64Bytes.data(), aNativeSize);
	}
}

void SyncLegacy1073TrackInstances(
	SaveGameContext& theContext,
	ReanimatorTrackInstance* theTrackInstances,
	int theTrackCount)
{
	if (theTrackCount < 0 ||
		static_cast<size_t>(theTrackCount) >
			static_cast<size_t>(INT_MAX) / Legacy1073Layout<ReanimatorTrackInstance>::SIZE)
	{
		theContext.mFailed = true;
		return;
	}

	const size_t aLegacySize = static_cast<size_t>(theTrackCount) *
		Legacy1073Layout<ReanimatorTrackInstance>::SIZE;
	std::vector<LegacyByte> aLegacyBytes(aLegacySize, 0);
	if (!theContext.mReading)
	{
		for (int i = 0; i < theTrackCount; ++i)
		{
			Legacy1073Layout<ReanimatorTrackInstance>::Write(
				aLegacyBytes.data() +
					i * Legacy1073Layout<ReanimatorTrackInstance>::SIZE,
				theTrackInstances[i]);
		}
	}

	theContext.SyncBytes(
		aLegacyBytes.data(),
		static_cast<int>(aLegacyBytes.size()));
	if (!theContext.mReading || theContext.mFailed)
	{
		return;
	}

	for (int i = 0; i < theTrackCount; ++i)
	{
		Legacy1073Layout<ReanimatorTrackInstance>::Read(
			theTrackInstances[i],
			aLegacyBytes.data() +
				i * Legacy1073Layout<ReanimatorTrackInstance>::SIZE);
	}
}

void SyncDat64TrackInstances(
	SaveGameContext& theContext,
	ReanimatorTrackInstance* theTrackInstances,
	int theTrackCount)
{
	if (theTrackCount < 0 ||
		static_cast<size_t>(theTrackCount) >
			static_cast<size_t>(INT_MAX) / Dat64Layout<ReanimatorTrackInstance>::SIZE)
	{
		theContext.mFailed = true;
		return;
	}

	const size_t aDat64Size = static_cast<size_t>(theTrackCount) *
		Dat64Layout<ReanimatorTrackInstance>::SIZE;
	std::vector<LegacyByte> aDat64Bytes(aDat64Size, 0);
	if (!theContext.mReading)
	{
		for (int i = 0; i < theTrackCount; ++i)
		{
			Dat64Layout<ReanimatorTrackInstance>::Write(
				aDat64Bytes.data() +
					i * Dat64Layout<ReanimatorTrackInstance>::SIZE,
				theTrackInstances[i]);
		}
	}

	theContext.SyncBytes(
		aDat64Bytes.data(),
		static_cast<int>(aDat64Bytes.size()));
	if (!theContext.mReading || theContext.mFailed)
	{
		return;
	}

	for (int i = 0; i < theTrackCount; ++i)
	{
		Dat64Layout<ReanimatorTrackInstance>::Read(
			theTrackInstances[i],
			aDat64Bytes.data() +
				i * Dat64Layout<ReanimatorTrackInstance>::SIZE);
	}
}
}

//0x4814C0
void SaveGameContext::SyncReanimationDef(ReanimatorDefinition*& theDefinition)
{
	if (mReading)
	{
		int aReanimType;
		SyncInt(aReanimType);
		if (aReanimType == (int)ReanimationType::REANIM_NONE)
		{
			theDefinition = nullptr;
		}
		else if (aReanimType >= 0 && aReanimType < (int)ReanimationType::NUM_REANIMS)
		{
			ReanimatorEnsureDefinitionLoaded((ReanimationType)aReanimType, true);
			theDefinition = &gReanimatorDefArray[aReanimType];
		}
		else
		{
			mFailed = true;
		}
	}
	else
	{
		int aReanimType = (int)ReanimationType::REANIM_NONE;
		for (int i = 0; i < (int)ReanimationType::NUM_REANIMS; i++)
		{
			ReanimatorDefinition* aDef = &gReanimatorDefArray[i];
			if (theDefinition == aDef)
			{
				aReanimType = i;
				break;
			}
		}
		SyncInt(aReanimType);
	}
}

//0x481560
void SaveGameContext::SyncParticleDef(TodParticleDefinition*& theDefinition)
{
	if (mReading)
	{
		int aParticleType;
		SyncInt(aParticleType);
		if (aParticleType == (int)ParticleEffect::PARTICLE_NONE)
		{
			theDefinition = nullptr;
		}
		else if (aParticleType >= 0 && aParticleType < (int)ParticleEffect::NUM_PARTICLES)
		{
			theDefinition = &gParticleDefArray[aParticleType];
		}
		else
		{
			mFailed = true;
		}
	}
	else
	{
		int aParticleType = (int)ParticleEffect::PARTICLE_NONE;
		for (int i = 0; i < (int)ParticleEffect::NUM_PARTICLES; i++)
		{
			TodParticleDefinition* aDef = &gParticleDefArray[i];
			if (theDefinition == aDef)
			{
				aParticleType = i;
				break;
			}
		}
		SyncInt(aParticleType);
	}
}

//0x4815F0
void SaveGameContext::SyncTrailDef(TrailDefinition*& theDefinition)
{
	if (mReading)
	{
		int aTrailType;
		SyncInt(aTrailType);
		if (aTrailType == TrailType::TRAIL_NONE)
		{
			theDefinition = nullptr;
		}
		else if (aTrailType >= 0 && aTrailType < TrailType::NUM_TRAILS)
		{
			theDefinition = &gTrailDefArray[aTrailType];
		}
		else
		{
			mFailed = true;
		}
	}
	else
	{
		int aTrailType = TrailType::TRAIL_NONE;
		for (int i = 0; i < TrailType::NUM_TRAILS; i++)
		{
			TrailDefinition* aDef = &gTrailDefArray[i];
			if (theDefinition == aDef)
			{
				aTrailType = i;
				break;
			}
		}
		SyncInt(aTrailType);
	}
}

//0x481690
void SaveGameContext::SyncImage(Image*& theImage)
{
	if (mReading)
	{
		ResourceId aResID;
		SyncInt((int&)aResID);
		if (aResID == Sexy::ResourceId::RESOURCE_ID_MAX)
		{
			theImage = nullptr;
		}
		else if (static_cast<int>(aResID) >= 0 &&
			static_cast<int>(aResID) < static_cast<int>(Sexy::ResourceId::RESOURCE_ID_MAX))
		{
			theImage = GetImageById(aResID);
		}
		else
		{
			mFailed = true;
			theImage = nullptr;
		}
	}
	else
	{
		ResourceId aResID;
		if (theImage != nullptr)
		{
			aResID = GetIdByImage(theImage);
		}
		else
		{
			aResID = Sexy::ResourceId::RESOURCE_ID_MAX;
		}
		SyncInt((int&)aResID);
	}
}

//0x481710
void SyncDataIDList(TodList<unsigned int>* theDataIDList, SaveGameContext& theContext, TodAllocator* theAllocator)
{
	try
	{
		if (theDataIDList == nullptr)
		{
			theContext.mFailed = true;
			return;
		}
		if (theContext.mReading)
		{
			theDataIDList->mHead = nullptr;
			theDataIDList->mTail = nullptr;
			theDataIDList->mSize = 0;
			theDataIDList->SetAllocator(theAllocator);

			int aCount;
			theContext.SyncInt(aCount);
			if (theContext.mFailed || aCount < 0 || aCount > 1024 ||
				static_cast<unsigned long>(theContext.ByteLeftToRead()) <
					static_cast<unsigned long>(aCount) * 8UL)
			{
				theContext.mFailed = true;
				return;
			}
			for (int i = 0; i < aCount; i++)
			{
				unsigned int aDataID;
				theContext.SyncBytes(&aDataID, sizeof(aDataID));
				if (theContext.mFailed)
				{
					return;
				}
				theDataIDList->AddTail(aDataID);
			}
		}
		else
		{
			int aCount = theDataIDList->mSize;
			theContext.SyncInt(aCount);
			for (TodListNode<unsigned int>* aNode = theDataIDList->mHead; aNode != nullptr; aNode = aNode->mNext)
			{
				unsigned int aDataID = aNode->mValue;
				theContext.SyncBytes(&aDataID, sizeof(aDataID));
			}
		}
	}
	catch (const std::exception&)
	{
		theContext.mFailed = true;
		return;
	}
}

//0x4817C0
void SyncParticleEmitter(TodParticleSystem* theParticleSystem, TodParticleEmitter* theParticleEmitter, SaveGameContext& theContext)
{
	int aEmitterDefIndex = 0;
	if (theContext.mReading)
	{
		theContext.SyncInt(aEmitterDefIndex);
		if (theContext.mFailed || theParticleSystem == nullptr ||
			theParticleSystem->mParticleDef == nullptr ||
			aEmitterDefIndex < 0 ||
			aEmitterDefIndex >= theParticleSystem->mParticleDef->mEmitterDefCount)
		{
			theContext.mFailed = true;
			return;
		}
		theParticleEmitter->mParticleSystem = theParticleSystem;
		theParticleEmitter->mEmitterDef = &theParticleSystem->mParticleDef->mEmitterDefs[aEmitterDefIndex];
	}
	else
	{
		aEmitterDefIndex = ((intptr_t)theParticleEmitter->mEmitterDef - (intptr_t)theParticleSystem->mParticleDef->mEmitterDefs) / sizeof(TodEmitterDefinition);
		theContext.SyncInt(aEmitterDefIndex);
	}

	theContext.SyncImage(theParticleEmitter->mImageOverride);
	SyncDataIDList((TodList<unsigned int>*)&theParticleEmitter->mParticleList, theContext, &theParticleSystem->mParticleHolder->mParticleListNodeAllocator);
	for (TodListNode<ParticleID>* aNode = theParticleEmitter->mParticleList.mHead; aNode != nullptr; aNode = aNode->mNext)
	{
		TodParticle* aParticle = theParticleSystem->mParticleHolder->mParticles.DataArrayTryToGet((unsigned int)aNode->mValue);
		if (aParticle == nullptr)
		{
			theContext.mFailed = true;
			return;
		}
		if (theContext.mReading)
		{
			aParticle->mParticleEmitter = theParticleEmitter;
		}
	}
}

//0x481880
void SyncParticleSystem(Board* theBoard, TodParticleSystem* theParticleSystem, SaveGameContext& theContext)
{
	theContext.SyncParticleDef(theParticleSystem->mParticleDef);
	if (theContext.mFailed || theParticleSystem->mParticleDef == nullptr)
	{
		theContext.mFailed = true;
		return;
	}
	if (theContext.mReading)
	{
		theParticleSystem->mParticleHolder = theBoard->mApp->mEffectSystem->mParticleHolder;
	}

	SyncDataIDList((TodList<unsigned int>*)&theParticleSystem->mEmitterList, theContext, &theParticleSystem->mParticleHolder->mEmitterListNodeAllocator);
	for (TodListNode<ParticleEmitterID>* aNode = theParticleSystem->mEmitterList.mHead; aNode != nullptr; aNode = aNode->mNext)
	{
		TodParticleEmitter* aEmitter = theParticleSystem->mParticleHolder->mEmitters.DataArrayTryToGet((unsigned int)aNode->mValue);
		if (aEmitter == nullptr)
		{
			theContext.mFailed = true;
			return;
		}
		SyncParticleEmitter(theParticleSystem, aEmitter, theContext);
		if (theContext.mFailed)
		{
			return;
		}
	}
}

//0x4818F0
void SyncReanimation(Board* theBoard, Reanimation* theReanimation, SaveGameContext& theContext)
{
	theContext.SyncReanimationDef(theReanimation->mDefinition);
	if (theContext.mFailed || theReanimation->mDefinition == nullptr)
	{
		theContext.mFailed = true;
		return;
	}
	if (theContext.mReading)
	{
		theReanimation->mReanimationHolder = theBoard->mApp->mEffectSystem->mReanimationHolder;
	}

	if (theReanimation->mDefinition->mTracks.count != 0)
	{
		const int aTrackCount = theReanimation->mDefinition->mTracks.count;
		if (theContext.mReading)
		{
			const size_t aNativeSize =
				static_cast<size_t>(aTrackCount) * sizeof(ReanimatorTrackInstance);
			if (aNativeSize > static_cast<size_t>(INT_MAX))
			{
				theContext.mFailed = true;
				return;
			}
			theReanimation->mTrackInstances =
				(ReanimatorTrackInstance*)FindGlobalAllocator(
					static_cast<int>(aNativeSize))->Calloc(
					static_cast<int>(aNativeSize));
		}
		if (theContext.mEncoding == LevelSaveEncoding::Dat64V1)
		{
			SyncDat64TrackInstances(
				theContext,
				theReanimation->mTrackInstances,
				aTrackCount);
		}
		else
		{
			SyncLegacy1073TrackInstances(
				theContext,
				theReanimation->mTrackInstances,
				aTrackCount);
		}
		if (theContext.mFailed)
		{
			return;
		}

		for (int aTrackIndex = 0; aTrackIndex < aTrackCount; aTrackIndex++)
		{
			ReanimatorTrackInstance& aTrackInstance = theReanimation->mTrackInstances[aTrackIndex];
			theContext.SyncImage(aTrackInstance.mImageOverride);

			if (theContext.mReading)
			{
				aTrackInstance.mBlendTransform.mText = "";
				TOD_ASSERT(aTrackInstance.mBlendTransform.mFont == nullptr);
				TOD_ASSERT(aTrackInstance.mBlendTransform.mImage == nullptr);
			}
			else
			{
				TOD_ASSERT(aTrackInstance.mBlendTransform.mText[0] == NULL);
				TOD_ASSERT(aTrackInstance.mBlendTransform.mFont == nullptr);
				TOD_ASSERT(aTrackInstance.mBlendTransform.mImage == nullptr);
			}
		}
	}
}

void SyncTrail(Board* theBoard, Trail* theTrail, SaveGameContext& theContext)
{
	theContext.SyncTrailDef(theTrail->mDefinition);
	if (theContext.mFailed || theTrail->mDefinition == nullptr)
	{
		theContext.mFailed = true;
		return;
	}
	if (theContext.mReading)
	{
		theTrail->mTrailHolder = theBoard->mApp->mEffectSystem->mTrailHolder;
	}
}

//0x4819D0
void SyncBoard(SaveGameContext& theContext, Board* theBoard)
{
	if (theContext.mEncoding == LevelSaveEncoding::Dat64V1)
	{
		SyncDat64BoardState(theContext, *theBoard);
		SyncDat64DataArray(theContext, theBoard->mZombies);
		SyncDat64DataArray(theContext, theBoard->mPlants);
		SyncDat64DataArray(theContext, theBoard->mProjectiles);
		SyncDat64DataArray(theContext, theBoard->mCoins);
		SyncDat64DataArray(theContext, theBoard->mLawnMowers);
		SyncDat64DataArray(theContext, theBoard->mGridItems);
		SyncDat64DataArray(theContext, theBoard->mApp->mEffectSystem->mParticleHolder->mParticleSystems);
		SyncDat64DataArray(theContext, theBoard->mApp->mEffectSystem->mParticleHolder->mEmitters);
		SyncDat64DataArray(theContext, theBoard->mApp->mEffectSystem->mParticleHolder->mParticles);
		SyncDat64DataArray(theContext, theBoard->mApp->mEffectSystem->mReanimationHolder->mReanimations);
		SyncDat64DataArray(theContext, theBoard->mApp->mEffectSystem->mTrailHolder->mTrails);
		SyncDat64DataArray(theContext, theBoard->mApp->mEffectSystem->mAttachmentHolder->mAttachments);
	}
	else
	{
		SyncLegacy1073BoardState(theContext, *theBoard);
		SyncLegacy1073DataArray(theContext, theBoard->mZombies);									//0x482190
		SyncLegacy1073DataArray(theContext, theBoard->mPlants);										//0x482280
		SyncLegacy1073DataArray(theContext, theBoard->mProjectiles);								//0x482370
		SyncLegacy1073DataArray(theContext, theBoard->mCoins);										//0x482460
		SyncLegacy1073DataArray(theContext, theBoard->mLawnMowers);								//0x482550
		SyncLegacy1073DataArray(theContext, theBoard->mGridItems);									//0x482650
		SyncLegacy1073DataArray(theContext, theBoard->mApp->mEffectSystem->mParticleHolder->mParticleSystems);	//0x482740
		SyncLegacy1073DataArray(theContext, theBoard->mApp->mEffectSystem->mParticleHolder->mEmitters);			//0x482830
		SyncLegacy1073DataArray(theContext, theBoard->mApp->mEffectSystem->mParticleHolder->mParticles);			//0x482920
		SyncLegacy1073DataArray(theContext, theBoard->mApp->mEffectSystem->mReanimationHolder->mReanimations);	//0x482920
		SyncLegacy1073DataArray(theContext, theBoard->mApp->mEffectSystem->mTrailHolder->mTrails);					//0x482650
		SyncLegacy1073DataArray(theContext, theBoard->mApp->mEffectSystem->mAttachmentHolder->mAttachments);		//0x482A10
	}
	if (theContext.mFailed)
	{
		return;
	}

	{
		TodParticleSystem* aParticle = nullptr;
		while (theBoard->mApp->mEffectSystem->mParticleHolder->mParticleSystems.IterateNext(aParticle))
		{
			SyncParticleSystem(theBoard, aParticle, theContext);
			if (theContext.mFailed)
			{
				return;
			}
		}
	}
	{
		Reanimation* aReanimation = nullptr;
		while (theBoard->mApp->mEffectSystem->mReanimationHolder->mReanimations.IterateNext(aReanimation))
		{
			SyncReanimation(theBoard, aReanimation, theContext);
			if (theContext.mFailed)
			{
				return;
			}
		}
	}
	{
		Trail* aTrail = nullptr;
		while (theBoard->mApp->mEffectSystem->mTrailHolder->mTrails.IterateNext(aTrail))
		{
			SyncTrail(theBoard, aTrail, theContext);
			if (theContext.mFailed)
			{
				return;
			}
		}
	}

	if (theContext.mEncoding == LevelSaveEncoding::Dat64V1)
	{
		SyncDat64Object(theContext, *theBoard->mCursorObject);
		SyncDat64Object(theContext, *theBoard->mCursorPreview);
		SyncDat64Object(theContext, *theBoard->mAdvice);
		SyncDat64Object(theContext, *theBoard->mSeedBank);
		SyncDat64Object(theContext, *theBoard->mChallenge);
		SyncDat64Object(theContext, *theBoard->mApp->mMusic);

		std::uint64_t anEndMarker = LevelSaveFormat::DAT64_END_MARKER;
		theContext.SyncBytes(&anEndMarker, sizeof(anEndMarker));
		if (theContext.mReading && anEndMarker != LevelSaveFormat::DAT64_END_MARKER)
		{
			theContext.mFailed = true;
		}
	}
	else
	{
		SyncLegacy1073Object(theContext, *theBoard->mCursorObject);
		SyncLegacy1073Object(theContext, *theBoard->mCursorPreview);
		SyncLegacy1073Object(theContext, *theBoard->mAdvice);
		SyncLegacy1073Object(theContext, *theBoard->mSeedBank);
		SyncLegacy1073Object(theContext, *theBoard->mChallenge);
		SyncLegacy1073Object(theContext, *theBoard->mApp->mMusic);

		if (theContext.mReading)
		{
			if ((unsigned long)theContext.ByteLeftToRead() < 4)
			{
				theContext.mFailed = true;
			}

			if (theContext.mFailed || (unsigned int)theContext.mBuffer.ReadLong() != SAVE_FILE_MAGIC_NUMBER)
			{
				theContext.mFailed = true;
			}
		}
		else
		{
			theContext.mBuffer.WriteLong(SAVE_FILE_MAGIC_NUMBER);
		}
	}
}

//0x481CE0
void FixBoardAfterLoad(Board* theBoard)
{
	{
		Plant* aPlant = nullptr;
		while (theBoard->mPlants.IterateNext(aPlant))
		{
			aPlant->mApp = theBoard->mApp;
			aPlant->mBoard = theBoard;
		}
	}
	{
		Zombie* aZombie = nullptr;
		while (theBoard->mZombies.IterateNext(aZombie))
		{
			aZombie->mApp = theBoard->mApp;
			aZombie->mBoard = theBoard;
		}
	}
	{
		Projectile* aProjectile = nullptr;
		while (theBoard->mProjectiles.IterateNext(aProjectile))
		{
			aProjectile->mApp = theBoard->mApp;
			aProjectile->mBoard = theBoard;
		}
	}
	{
		Coin* aCoin = nullptr;
		while (theBoard->mCoins.IterateNext(aCoin))
		{
			aCoin->mApp = theBoard->mApp;
			aCoin->mBoard = theBoard;
		}
	}
	{
		LawnMower* aLawnMower = nullptr;
		while (theBoard->mLawnMowers.IterateNext(aLawnMower))
		{
			aLawnMower->mApp = theBoard->mApp;
			aLawnMower->mBoard = theBoard;
		}
	}
	{
		GridItem* aGridItem = nullptr;
		while (theBoard->mGridItems.IterateNext(aGridItem))
		{
			aGridItem->mApp = theBoard->mApp;
			aGridItem->mBoard = theBoard;
		}
	}

	theBoard->mAdvice->mApp = theBoard->mApp;
	theBoard->mCursorObject->mApp = theBoard->mApp;
	theBoard->mCursorObject->mBoard = theBoard;
	theBoard->mCursorPreview->mApp = theBoard->mApp;
	theBoard->mCursorPreview->mBoard = theBoard;
	theBoard->mSeedBank->mApp = theBoard->mApp;
	theBoard->mSeedBank->mBoard = theBoard;
	for (int i = 0; i < SEEDBANK_MAX; i++)
	{
		theBoard->mSeedBank->mSeedPackets[i].mApp = theBoard->mApp;
		theBoard->mSeedBank->mSeedPackets[i].mBoard = theBoard;
	}
	theBoard->mChallenge->mApp = theBoard->mApp;
	theBoard->mChallenge->mBoard = theBoard;
	theBoard->mApp->mMusic->mApp = theBoard->mApp;
	theBoard->mApp->mMusic->mMusicInterface = theBoard->mApp->mMusicInterface;
}

//0x481FE0
// GOTY @Patoke: 0x48CBC0
bool LawnLoadGame(Board* theBoard, const std::string& theFilePath)
{
	Buffer aFileBuffer;
	if (!gSexyAppBase->ReadBufferFromFile(theFilePath, &aFileBuffer, false))
	{
		return false;
	}

	const auto ReadU32 = [](const LegacyByte* p) -> std::uint32_t
	{
		return static_cast<std::uint32_t>(p[0]) |
			(static_cast<std::uint32_t>(p[1]) << 8) |
			(static_cast<std::uint32_t>(p[2]) << 16) |
			(static_cast<std::uint32_t>(p[3]) << 24);
	};
	const auto ReadU64 = [&ReadU32](const LegacyByte* p) -> std::uint64_t
	{
		return static_cast<std::uint64_t>(ReadU32(p)) |
			(static_cast<std::uint64_t>(ReadU32(p + 4)) << 32);
	};

	const int aFileSize = aFileBuffer.GetDataLen();
	const LegacyByte* aFileData = aFileBuffer.GetDataPtr();
	if (aFileSize < static_cast<int>(LevelSaveFormat::DAT64_HEADER_SIZE) ||
		std::memcmp(
			aFileData,
			LevelSaveFormat::DAT64_MAGIC.data(),
			LevelSaveFormat::DAT64_MAGIC.size()) != 0)
	{
		TodTraceAndLog("DAT64_HEADER_REJECT file=%s reason=magic-or-size", theFilePath.c_str());
		return false;
	}

	const std::uint32_t aVersion = ReadU32(aFileData + 8);
	const std::uint32_t aHeaderSize = ReadU32(aFileData + 12);
	const std::uint32_t anAuthorityBuild = ReadU32(aFileData + 16);
	const std::uint32_t aFlags = ReadU32(aFileData + 20);
	const std::uint64_t aPayloadSize = ReadU64(aFileData + 24);
	const std::uint32_t aStoredCRC = ReadU32(aFileData + 32);
	const std::uint32_t aSchemaID = ReadU32(aFileData + 36);
	const std::uint64_t aReserved = ReadU64(aFileData + 40);
	if (aVersion != LevelSaveFormat::DAT64_VERSION ||
		aHeaderSize != LevelSaveFormat::DAT64_HEADER_SIZE ||
		anAuthorityBuild != LevelSaveFormat::DAT64_AUTHORITY_BUILD ||
		aFlags != LevelSaveFormat::DAT64_FLAGS ||
		aSchemaID != LevelSaveFormat::DAT64_SCHEMA_ID ||
		aReserved != 0 ||
		aPayloadSize != static_cast<std::uint64_t>(aFileSize - aHeaderSize) ||
		aPayloadSize > static_cast<std::uint64_t>(INT_MAX))
	{
		TodTraceAndLog(
			"DAT64_HEADER_REJECT file=%s version=%u header=%u authority=%u flags=%08X schema=%08X payload=%llu",
			theFilePath.c_str(),
			aVersion,
			aHeaderSize,
			anAuthorityBuild,
			aFlags,
			aSchemaID,
			static_cast<unsigned long long>(aPayloadSize));
		return false;
	}

	const LegacyByte* aPayload = aFileData + aHeaderSize;
	const std::uint32_t anActualCRC = crc32(
		0,
		const_cast<Bytef*>(reinterpret_cast<const Bytef*>(aPayload)),
		static_cast<uInt>(aPayloadSize));
	if (anActualCRC != aStoredCRC)
	{
		TodTraceAndLog(
			"DAT64_CRC_REJECT file=%s stored=%08X actual=%08X",
			theFilePath.c_str(),
			aStoredCRC,
			anActualCRC);
		return false;
	}

	SaveGameContext aContext;
	aContext.mFailed = false;
	aContext.mReading = true;
	aContext.mEncoding = LevelSaveEncoding::Dat64V1;
	aContext.mBuffer.SetData(
		const_cast<LegacyByte*>(aPayload),
		static_cast<int>(aPayloadSize));

	SyncBoard(aContext, theBoard);
	if (aContext.mFailed || aContext.ByteLeftToRead() != 0)
	{
		TodTraceAndLog(
			"DAT64_BOARD_REJECT file=%s failed=%d left=%lu",
			theFilePath.c_str(),
			aContext.mFailed ? 1 : 0,
			static_cast<unsigned long>(aContext.ByteLeftToRead()));
		return false;
	}
	TodTraceAndLog(
		"DAT64_BOARD_STATE file=%s gameId=%lld background=%d wave=%d/%d survivalStage=%d musicTune=%d paused=%d bpm=%d speed=%d",
		theFilePath.c_str(),
		static_cast<long long>(theBoard->mGameID),
		static_cast<int>(theBoard->mBackground),
		theBoard->mCurrentWave,
		theBoard->mNumWaves,
		theBoard->mChallenge ? theBoard->mChallenge->mSurvivalStage : -1,
		static_cast<int>(theBoard->mApp->mMusic->mCurMusicTune),
		theBoard->mApp->mMusic->mPaused ? 1 : 0,
		theBoard->mApp->mMusic->mBaseBPM,
		theBoard->mApp->mMusic->mBaseModSpeed);

	TodTrace("Loaded save game");
	FixBoardAfterLoad(theBoard);
	theBoard->mApp->mGameScene = GameScenes::SCENE_PLAYING;
	return true;
}

//0x4820D0
bool LawnSaveGame(Board* theBoard, const std::string& theFilePath)
{
	SaveGameContext aContext;
	aContext.mFailed = false;
	aContext.mReading = false;
	aContext.mEncoding = LevelSaveEncoding::Dat64V1;
	SyncBoard(aContext, theBoard);
	if (aContext.mFailed)
	{
		return false;
	}

	const auto WriteU32 = [](Buffer& theBuffer, std::uint32_t theValue)
	{
		LegacyByte aBytes[4] = {
			static_cast<LegacyByte>(theValue),
			static_cast<LegacyByte>(theValue >> 8),
			static_cast<LegacyByte>(theValue >> 16),
			static_cast<LegacyByte>(theValue >> 24)
		};
		theBuffer.WriteBytes(aBytes, sizeof(aBytes));
	};
	const auto WriteU64 = [&WriteU32](Buffer& theBuffer, std::uint64_t theValue)
	{
		WriteU32(theBuffer, static_cast<std::uint32_t>(theValue));
		WriteU32(theBuffer, static_cast<std::uint32_t>(theValue >> 32));
	};

	const int aPayloadSize = aContext.mBuffer.GetDataLen();
	const std::uint32_t aPayloadCRC = crc32(
		0,
		const_cast<Bytef*>(reinterpret_cast<const Bytef*>(aContext.mBuffer.GetDataPtr())),
		static_cast<uInt>(aPayloadSize));

	Buffer aFileBuffer;
	aFileBuffer.WriteBytes(
		LevelSaveFormat::DAT64_MAGIC.data(),
		static_cast<int>(LevelSaveFormat::DAT64_MAGIC.size()));
	WriteU32(aFileBuffer, LevelSaveFormat::DAT64_VERSION);
	WriteU32(aFileBuffer, LevelSaveFormat::DAT64_HEADER_SIZE);
	WriteU32(aFileBuffer, LevelSaveFormat::DAT64_AUTHORITY_BUILD);
	WriteU32(aFileBuffer, LevelSaveFormat::DAT64_FLAGS);
	WriteU64(aFileBuffer, static_cast<std::uint64_t>(aPayloadSize));
	WriteU32(aFileBuffer, aPayloadCRC);
	WriteU32(aFileBuffer, LevelSaveFormat::DAT64_SCHEMA_ID);
	WriteU64(aFileBuffer, 0);
	TOD_ASSERT(aFileBuffer.GetDataLen() == LevelSaveFormat::DAT64_HEADER_SIZE);
	aFileBuffer.WriteBytes(aContext.mBuffer.GetDataPtr(), aPayloadSize);

	return gSexyAppBase->WriteBufferToFile(theFilePath, &aFileBuffer);
}
