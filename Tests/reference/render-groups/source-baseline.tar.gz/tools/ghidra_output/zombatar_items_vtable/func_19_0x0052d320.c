
void thunk_FUN_00549150(void)

{
  FUN_00549150();
  return;
}

