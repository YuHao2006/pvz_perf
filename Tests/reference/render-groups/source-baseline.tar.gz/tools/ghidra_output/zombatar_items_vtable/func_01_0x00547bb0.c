
undefined4 __thiscall FUN_00547bb0(int param_1,undefined4 param_2)

{
  FUN_00401a90(*(undefined4 *)(param_1 + 0x48),*(undefined4 *)(param_1 + 0x4c));
  return param_2;
}

