// bench_t01 — kHelmDamageImages 10x2 -> Zombie::TakeHelmDamage（事件：冰冻/黄油期每帧）
#include "zb_common.h"
#define TOD_ASSERT(x) ((void)0)

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) int Zombie::TakeHelmDamage_A(int theDamage, unsigned int theDamageFlags)
{
    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
    {
        mJustGotShotCounter = 25;
    }

    int aDamageIndexBeforeDamage = GetHelmDamageIndex();
    int aDamageActual = std::min(mHelmHealth, theDamage);
    int aDamageRemaining = theDamage - aDamageActual;
    mHelmHealth -= aDamageActual;
    if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_FREEZE))
    {
        ApplyChill(false);
    }
    if (mHelmHealth == 0)
    {
        DropHelm(theDamageFlags);
        return aDamageRemaining;
    }

    int aDamageIndexAfterDamage = GetHelmDamageIndex();
    if (aDamageIndexBeforeDamage != aDamageIndexAfterDamage)
    {
        Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
        if (mHelmType == HelmType::HELMTYPE_TRAFFIC_CONE && aDamageIndexAfterDamage == 1 && aBodyReanim)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_cone, IMAGE_REANIM_ZOMBIE_CONE2);
        }
        else if (mHelmType == HelmType::HELMTYPE_TRAFFIC_CONE && aDamageIndexAfterDamage == 2 && aBodyReanim)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_cone, IMAGE_REANIM_ZOMBIE_CONE3);
        }
        else if (mHelmType == HelmType::HELMTYPE_PAIL && aDamageIndexAfterDamage == 1)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_bucket, IMAGE_REANIM_ZOMBIE_BUCKET2);
        }
        else if (mHelmType == HelmType::HELMTYPE_PAIL && aDamageIndexAfterDamage == 2)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_bucket, IMAGE_REANIM_ZOMBIE_BUCKET3);
        }
        else if (mHelmType == HelmType::HELMTYPE_DIGGER && aDamageIndexAfterDamage == 1)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_digger_hardhat, IMAGE_REANIM_ZOMBIE_DIGGER_HARDHAT2);
        }
        else if (mHelmType == HelmType::HELMTYPE_DIGGER && aDamageIndexAfterDamage == 2)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_digger_hardhat, IMAGE_REANIM_ZOMBIE_DIGGER_HARDHAT3);
        }
        else if (mHelmType == HelmType::HELMTYPE_FOOTBALL && aDamageIndexAfterDamage == 1)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::zombie_football_helmet, IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2);
        }
        else if (mHelmType == HelmType::HELMTYPE_FOOTBALL && aDamageIndexAfterDamage == 2)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::zombie_football_helmet, IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3);
        }
        else if (mHelmType == HelmType::HELMTYPE_WALLNUT && aDamageIndexAfterDamage == 1)
        {
            Reanimation* aHeadReanim = mApp->ReanimationGet(mSpecialHeadReanimID);
            aHeadReanim->SetImageOverride(ReanimTrackId::anim_face, IMAGE_REANIM_WALLNUT_CRACKED1);
        }
        else if (mHelmType == HelmType::HELMTYPE_WALLNUT && aDamageIndexAfterDamage == 2)
        {
            Reanimation* aHeadReanim = mApp->ReanimationGet(mSpecialHeadReanimID);
            aHeadReanim->SetImageOverride(ReanimTrackId::anim_face, IMAGE_REANIM_WALLNUT_CRACKED2);
        }
        else if (mHelmType == HelmType::HELMTYPE_TALLNUT && aDamageIndexAfterDamage == 1)
        {
            Reanimation* aHeadReanim = mApp->ReanimationGet(mSpecialHeadReanimID);
            aHeadReanim->SetImageOverride(ReanimTrackId::anim_idle, IMAGE_REANIM_TALLNUT_CRACKED1);
        }
        else if (mHelmType == HelmType::HELMTYPE_TALLNUT && aDamageIndexAfterDamage == 2)
        {
            Reanimation* aHeadReanim = mApp->ReanimationGet(mSpecialHeadReanimID);
            aHeadReanim->SetImageOverride(ReanimTrackId::anim_idle, IMAGE_REANIM_TALLNUT_CRACKED2);
        }
    }
    return aDamageRemaining;
}

// ==================== FormB：HEAD 逐字（函数内 constexpr struct 表——HEAD 即无 static，照抄） ====================
__declspec(noinline) int Zombie::TakeHelmDamage_B(int theDamage, unsigned int theDamageFlags)
{
    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
    {
        mJustGotShotCounter = 25;
    }

    int aDamageIndexBeforeDamage = GetHelmDamageIndex();
    int aDamageActual = std::min(mHelmHealth, theDamage);
    int aDamageRemaining = theDamage - aDamageActual;
    mHelmHealth -= aDamageActual;
    if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_FREEZE))
    {
        ApplyChill(false);
    }
    if (mHelmHealth == 0)
    {
        DropHelm(theDamageFlags);
        return aDamageRemaining;
    }

    int aDamageIndexAfterDamage = GetHelmDamageIndex();
    if (aDamageIndexBeforeDamage != aDamageIndexAfterDamage)
    {
        Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
        // B 形态 -> 常量二维表 kHelmDamageImages（原 12 支链合并）：行序 =
        // HelmType 枚举序 0..9（count_last=HELMTYPE_TALLNUT 锚定，无 NUM 哨兵），
        // 列序 = 损伤档 1..2；mImage=nullptr = 无 case 槽（default 无操作）。
        constexpr struct
        {
            ReanimTrackId mTrack;
            Image* const* mImage;      // nullptr = 无 case 槽
            bool mUseHeadReanim;       // WALLNUT/TALLNUT：作用于头部 reanim
            bool mGuardNullBody;       // TRAFFIC_CONE：原链带 && aBodyReanim 判空
        } kHelmDamageImages[(int)HelmType::HELMTYPE_TALLNUT + 1][2] = {
            /* [0] HELMTYPE_NONE       */ { { ReanimTrackId::None, nullptr, false, false }, { ReanimTrackId::None, nullptr, false, false } },
            /* [1] HELMTYPE_TRAFFIC_CONE */ { { ReanimTrackId::anim_cone, &IMAGE_REANIM_ZOMBIE_CONE2, false, true },
                                              { ReanimTrackId::anim_cone, &IMAGE_REANIM_ZOMBIE_CONE3, false, true } },
            /* [2] HELMTYPE_PAIL       */ { { ReanimTrackId::anim_bucket, &IMAGE_REANIM_ZOMBIE_BUCKET2, false, false },
                                              { ReanimTrackId::anim_bucket, &IMAGE_REANIM_ZOMBIE_BUCKET3, false, false } },
            /* [3] HELMTYPE_FOOTBALL   */ { { ReanimTrackId::zombie_football_helmet, &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2, false, false },
                                              { ReanimTrackId::zombie_football_helmet, &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3, false, false } },
            /* [4] HELMTYPE_DIGGER     */ { { ReanimTrackId::Zombie_digger_hardhat, &IMAGE_REANIM_ZOMBIE_DIGGER_HARDHAT2, false, false },
                                              { ReanimTrackId::Zombie_digger_hardhat, &IMAGE_REANIM_ZOMBIE_DIGGER_HARDHAT3, false, false } },
            /* [5] HELMTYPE_REDEYES    */ { { ReanimTrackId::None, nullptr, false, false }, { ReanimTrackId::None, nullptr, false, false } },
            /* [6] HELMTYPE_HEADBAND   */ { { ReanimTrackId::None, nullptr, false, false }, { ReanimTrackId::None, nullptr, false, false } },
            /* [7] HELMTYPE_BOBSLED    */ { { ReanimTrackId::None, nullptr, false, false }, { ReanimTrackId::None, nullptr, false, false } },
            /* [8] HELMTYPE_WALLNUT    */ { { ReanimTrackId::anim_face, &IMAGE_REANIM_WALLNUT_CRACKED1, true, false },
                                              { ReanimTrackId::anim_face, &IMAGE_REANIM_WALLNUT_CRACKED2, true, false } },
            /* [9] HELMTYPE_TALLNUT    */ { { ReanimTrackId::anim_idle, &IMAGE_REANIM_TALLNUT_CRACKED1, true, false },
                                              { ReanimTrackId::anim_idle, &IMAGE_REANIM_TALLNUT_CRACKED2, true, false } },
        };
        static_assert(sizeof(kHelmDamageImages) / sizeof(kHelmDamageImages[0]) ==
            (int)HelmType::HELMTYPE_TALLNUT + 1, "kHelmDamageImages 槽位须与 HelmType 枚举尾同步");

        const unsigned aHelmIndex = static_cast<unsigned>(mHelmType);
        const unsigned aDamageSlot = static_cast<unsigned>(aDamageIndexAfterDamage) - 1;
        if (aHelmIndex < sizeof(kHelmDamageImages) / sizeof(kHelmDamageImages[0]) &&
            aDamageSlot < 2 && kHelmDamageImages[aHelmIndex][aDamageSlot].mImage != nullptr &&
            (!kHelmDamageImages[aHelmIndex][aDamageSlot].mGuardNullBody || aBodyReanim != nullptr))
        {
            if (kHelmDamageImages[aHelmIndex][aDamageSlot].mUseHeadReanim)
            {
                Reanimation* aHeadReanim = mApp->ReanimationGet(mSpecialHeadReanimID);
                aHeadReanim->SetImageOverride(kHelmDamageImages[aHelmIndex][aDamageSlot].mTrack,
                    *kHelmDamageImages[aHelmIndex][aDamageSlot].mImage);
            }
            else
            {
                TOD_ASSERT(aBodyReanim);
                aBodyReanim->SetImageOverride(kHelmDamageImages[aHelmIndex][aDamageSlot].mTrack,
                    *kHelmDamageImages[aHelmIndex][aDamageSlot].mImage);
            }
        }
    }
    return aDamageRemaining;
}

static Zombie g_z;
static void ResetHelm(const ZBInput& in, int& dmg, unsigned& flags)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    g_z.mHelmType = (HelmType)(in.a % 10);
    g_z.mHelmMaxHealth = 270;
    g_z.mHelmHealth = (int)(in.b % 271);
    g_z.mJustGotShotCounter = (int)(in.c % 7) - 2;
    g_z.mBodyReanimID = (in.b % 7 == 0) ? (ReanimationID)0 : (ReanimationID)(1 + in.b % 2);
    g_z.mSpecialHeadReanimID = (ReanimationID)(1 + in.a % 2);
    dmg = (int)(in.c % 40) + 1;
    flags = (in.d & ((1u << 2) | (1u << 3))) | ((in.d >> 8) & 1u);
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            int dmg; unsigned fl;
            ResetHelm(g_zb_inputs[i], dmg, fl);
            int r = g_z.TakeHelmDamage_A(dmg, fl);
            g_z.HashFold(ck);
            ck = ZBMixU64(ck, (uint64_t)(uint32_t)r);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            int dmg; unsigned fl;
            ResetHelm(g_zb_inputs[i], dmg, fl);
            int r = g_z.TakeHelmDamage_B(dmg, fl);
            g_z.HashFold(ck);
            ck = ZBMixU64(ck, (uint64_t)(uint32_t)r);
        }
    };
    return ZBenchMain("t01_TakeHelmDamage", passA, passB);
}
