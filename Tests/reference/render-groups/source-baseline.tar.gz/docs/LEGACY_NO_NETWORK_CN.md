# Legacy 网络依赖清理记录

## 结论

Legacy 是离线程序。运行时不创建 Winsock/HTTP 连接，不打开浏览器，不提交崩溃报告，也不连接 PopCap 的注册、广告、更新或 SexyCache 服务。

资源、存档、音频和诊断全部走本地文件：

- 资源只挂载 `main.pak64`；
- 存档位于程序目录的 `data`；
- 原版兼容运行日志位于 `data/log.txt`；
- 诊断日志和本地崩溃转储位于程序目录的 `log`。

## 已移除的代码路径

- 删除 `HTTPTransfer`（Winsock `WSAStartup/socket/connect/send/recv` 等实现）及其 CMake 源文件；
- 删除 `ws2_32`/`wsock32` 链接依赖；
- 删除 `SexyAppBase` 的 URL 状态字段、超时回调、`OpenURL`/`URLOpen*` 和 URL 相关消息循环分支；
- 删除注册页、HTML 模板、更新 URL、更新查询和 Zylom/广告入口；
- 删除 `SexyCache` 缓冲写入和旧的浏览器窗口清理代码；
- 删除 `SEHCatcher` 的上传线程、HTTP multipart 构造、服务器地址和“Send Report”按钮。

`SEHCatcher` 仍保留异常捕获、符号/栈信息生成、剪贴板复制和 `log/crash.txt` 写入；这些都是本地诊断，不会联网。

## 验证结果

Release 构建命令：

```text
cmake --build out/legacy-msvc2 --config Release --parallel 1
```

已通过。最终 EXE 的导入表只包含本地图形、音频、系统运行库；没有：

```text
WS2_32.dll
WSOCK32.dll
WININET.dll
URLMON.dll
WINHTTP.dll
DNSAPI.dll
IPHLPAPI.dll
```

同时对 `SexyAppFramework.exe` 的 ASCII 字符串做了检查，以下标识均为 0 次：

```text
HTTPTransfer
SexyCache
www.popcap.com
deluxe_error.php
BASS_StreamCreateURL
```

`bass.h` 中已移除 BASS URL 流函数声明；Legacy 音乐只使用 `BASS_StreamCreateFile`。
