#include "AdditiveBlend.h"

#include <cstdint>
#include <cstdlib>
#include <iostream>

namespace
{

void Require(bool theCondition, const char* theMessage)
{
	if (!theCondition)
	{
		std::cerr << "FAILED: " << theMessage << '\n';
		std::exit(EXIT_FAILURE);
	}
}

void Test888ScalesAndSaturates()
{
	Require(
		Sexy::SWTriAdditive::Blend888(0xFF102030U, 0xFF643219U, 255, false) == 0xFF735148U,
		"888 additive blend must scale source alpha with the legacy 8-bit convention");
	Require(
		Sexy::SWTriAdditive::Blend888(0xFFF0F8FEU, 0xFF804020U, 255, false) == 0xFFFFFFFFU,
		"888 additive blend must saturate each color channel independently");
	Require(
		Sexy::SWTriAdditive::Blend888(0xFF102030U, 0xFF804020U, 128, false) == 0xFF504040U,
		"888 additive blend must honor partial source alpha");
}

void Test888PremultipliedInput()
{
	Require(
		Sexy::SWTriAdditive::Blend888(0xFF102030U, 0xFF402010U, 37, true) == 0xFF504040U,
		"linear-filtered additive input must not be alpha-scaled twice");
}

void Test565ScalesAndSaturates()
{
	Require(
		Sexy::SWTriAdditive::Blend565(0x2104U, 0xFF804020U, 128, false) == 0x6206U,
		"565 additive blend must add independently quantized channels");
	Require(
		Sexy::SWTriAdditive::Blend565(0xFFFFU, 0xFFFFFFFFU, 255, false) == 0xFFFFU,
		"565 additive blend must saturate without carrying into adjacent channels");
}

}

int main()
{
	Test888ScalesAndSaturates();
	Test888PremultipliedInput();
	Test565ScalesAndSaturates();
	return EXIT_SUCCESS;
}
