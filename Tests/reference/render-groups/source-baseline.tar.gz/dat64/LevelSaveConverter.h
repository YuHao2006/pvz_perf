#ifndef PVZ_DAT64_LEVEL_SAVE_CONVERTER_H
#define PVZ_DAT64_LEVEL_SAVE_CONVERTER_H

#include <filesystem>
#include <string>

namespace PvzDat64
{
enum class Format
{
    Legacy1073Dat,
    Dat64V1
};

struct ConversionResult
{
    Format mSourceFormat;
    Format mTargetFormat;
    std::filesystem::path mSourcePath;
    std::filesystem::path mTargetPath;
    std::uintmax_t mSourceSize;
    std::uintmax_t mTargetSize;
};

Format DetectFormat(const std::filesystem::path& thePath);
std::filesystem::path DefaultOutputPath(
    const std::filesystem::path& theInput,
    Format theInputFormat);
ConversionResult ConvertFile(
    const std::filesystem::path& theInput,
    const std::filesystem::path& theOutput);
const char* FormatName(Format theFormat);
}

#endif
