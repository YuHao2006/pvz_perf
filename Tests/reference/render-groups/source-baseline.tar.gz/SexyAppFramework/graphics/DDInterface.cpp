#include "DDInterface.h"
#include "DDImage.h"
#include "D3DInterface.h"
#include "D3DTester.h"
#include "Graphics.h"
#include "SexyAppBase.h"
#include "misc/AutoCrit.h"

#include <algorithm>

using namespace Sexy;

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
DDInterface::DDInterface(SexyAppBase* theApp)
	: mApp(theApp),
	mD3DInterface(NULL),
	mD3DTester(NULL),
	mIs3D(false),
	mInRedraw(false),
	mWidth(640),
	mHeight(480),
	mIsWidescreen(false),
	mDisplayWidth(640),
	mDisplayHeight(480),
	mFullscreenBits(32),
	mRefreshRate(60),
	mMillisecondsPerFrame(16),
	mScanLineFailCount(0),
	mRedAddTable(NULL),
	mGreenAddTable(NULL),
	mBlueAddTable(NULL),
	mInitialized(false),
	mHWnd(NULL),
	mIsWindowed(true),
	mScreenImage(NULL),
	mVideoOnlyDraw(false),
	mInitCount(0),
	mCursorWidth(32),
	mCursorHeight(32),
	mNextCursorX(0),
	mNextCursorY(0),
	mCursorX(0),
	mCursorY(0),
	mCursorImage(NULL),
	mHasOldCursorArea(false)
{
	mD3DInterface = new D3DInterface;
	mRGBBits = 32;
	mRedMask = 0xFF0000;
	mGreenMask = 0x00FF00;
	mBlueMask = 0x0000FF;
	mRedBits = 8;
	mGreenBits = 8;
	mBlueBits = 8;
	mRedShift = 23;
	mGreenShift = 15;
	mBlueShift = 7;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
DDInterface::~DDInterface()
{
	Cleanup();
	delete mD3DInterface;
	delete mD3DTester;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
DDImage* DDInterface::GetScreenImage()
{
	return mScreenImage;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::SetVideoOnlyDraw(bool videoOnlyDraw)
{
	mVideoOnlyDraw = videoOnlyDraw;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::SetCursorPos(int theX, int theY)
{
	mNextCursorX = theX;
	mNextCursorY = theY;
	mCursorX = theX;
	mCursorY = theY;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool DDInterface::SetCursorImage(Image* theImage)
{
	AutoCrit anAutoCrit(mCritSect);
	if (mCursorImage != theImage)
	{
		mCursorImage = theImage;
		return true;
	}
	return false;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool DDInterface::Redraw(Rect* theClipRect)
{
	(void)theClipRect;
	AutoCrit anAutoCrit(mCritSect);
	if (!mInitialized)
		return false;

	mInRedraw = true;
	if (mIs3D)
	{
		if (!mD3DInterface->mErrorString.empty())
		{
			// D3D11 is the only renderer in Legacy.  Do not turn a present error
			// into a software-mode transition; leave mIs3D unchanged so the caller
			// can report/reinitialize the actual failure.
			mInRedraw = false;
			return false;
		}
		mD3DInterface->Flush();
		mInRedraw = false;
		return true;
	}
	mInRedraw = false;
	return false;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::RemapMouse(int& theX, int& theY)
{
	if (mInitialized)
	{
		// 3D is always on, so mIsWindowed is always true; the present can
		// still letterbox (fullscreen 4:3 fit, custom-scale fit). Always
		// recover the visible game rectangle from the presentation rect.
		const double aScaleX = (double)mPresentationRect.mWidth / (double)mWidth;
		const double aScaleY = (double)mPresentationRect.mHeight / (double)mHeight;
		const double aScale = aScaleX < aScaleY ? aScaleX : aScaleY;
		const int aViewW = (int)((double)mWidth * aScale);
		const int aViewH = (int)((double)mHeight * aScale);
		const int aViewX = mPresentationRect.mX + (mPresentationRect.mWidth - aViewW) / 2;
		const int aViewY = mPresentationRect.mY + (mPresentationRect.mHeight - aViewH) / 2;
		theX = (theX - aViewX) * mWidth / std::max(1, aViewW);
		theY = (theY - aViewY) * mHeight / std::max(1, aViewH);
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
ulong DDInterface::GetColorRef(ulong theRGB)
{
	return theRGB;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::AddDDImage(DDImage* theDDImage)
{
	AutoCrit anAutoCrit(mCritSect);
	mDDImageSet.insert(theDDImage);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::RemoveDDImage(DDImage* theDDImage)
{
	AutoCrit anAutoCrit(mCritSect);
	DDImageSet::iterator anItr = mDDImageSet.find(theDDImage);
	if (anItr != mDDImageSet.end())
		mDDImageSet.erase(anItr);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::Remove3DData(MemoryImage* theImage)
{
	mD3DInterface->RemoveMemoryImage(theImage);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool DDInterface::GotDXError(HRESULT theResult, const char *theContext)
{
	if (SUCCEEDED(theResult))
		return false;
	FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
	if (aLog != NULL)
	{
		fprintf(aLog, "DX error hr=0x%08lx context=%s\n",
			(unsigned long)theResult, theContext != NULL ? theContext : "");
		fclose(aLog);
	}
	mErrorString = theContext != NULL ? theContext : "D3D11 call failed";
	return true;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool DDInterface::Do3DTest(HWND theHWND)
{
	(void)theHWND;
	if (mD3DTester == NULL)
	{
		mD3DTester = new D3DTester;
		mD3DTester->SetVidMemoryConstraints(mApp->mMinVidMemory3D, mApp->mRecommendedVidMemory3D);
		mD3DTester->TestD3D(theHWND, NULL);
		if (mApp->mAutoEnable3D && mD3DTester->Is3DRecommended())
			mIs3D = true;
		// Legacy has no software renderer and the active backend is D3D11;
		// results from the historical D3D7 capability probe must not turn the
		// live renderer off.  A real D3D11 creation failure is reported by Init.
		mIs3D = true;
		return true;
	}
	return false;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void DDInterface::Cleanup()
{
	AutoCrit anAutoCrit(mCritSect);

	mInitialized = false;
	if (mD3DInterface != NULL)
		mD3DInterface->Cleanup();

	if (mScreenImage != NULL)
	{
		delete mScreenImage;
		mScreenImage = NULL;
	}

	delete [] mRedAddTable;
	mRedAddTable = NULL;
	delete [] mGreenAddTable;
	mGreenAddTable = NULL;
	delete [] mBlueAddTable;
	mBlueAddTable = NULL;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
int DDInterface::Init(HWND theWindow, bool IsWindowed)
{
	AutoCrit anAutoCrit(mCritSect);

	mInitialized = false;
	Cleanup();

	mHWnd = theWindow;
	mWidth = mApp->mWidth;
	mHeight = mApp->mHeight;
	mAspect.Set(mWidth, mHeight);
	mDesktopWidth = GetSystemMetrics(SM_CXSCREEN);
	mDesktopHeight = GetSystemMetrics(SM_CYSCREEN);
	mDesktopAspect.Set(mDesktopWidth, mDesktopHeight);
	mDisplayWidth = mWidth;
	mDisplayHeight = mHeight;
	mDisplayAspect = mAspect;
	mPresentationRect = Rect(0, 0, mWidth, mHeight);
	mVisibleGameRect = mPresentationRect;
	mApp->mScreenBounds = mPresentationRect;
	mFullscreenBits = mApp->mFullscreenBits;

	// 3D (D3D11) is always on, so the physical window stays windowed; a
	// fullscreen request becomes a borderless window and the swapchain fills
	// it. DirectDraw display-mode changes are gone.
	mIsWindowed = IsWindowed || mIs3D;
	const bool aFullscreenBorderless = !IsWindowed && mIs3D;
	mHasOldCursorArea = false;

	if (IsWindowed)
	{
		if (aFullscreenBorderless)
		{
			mDisplayWidth = mDesktopWidth;
			mDisplayHeight = mDesktopHeight;
			mDisplayAspect = mDesktopAspect;
			mIsWidescreen = false;
			mPresentationRect = Rect(0, 0, mDisplayWidth, mDisplayHeight);
		}
		else if (mApp->mEnableWindowAspect && mAspect < mApp->mWindowAspect)
		{
			mIsWidescreen = true;
			mDisplayWidth = mHeight * mApp->mWindowAspect;
			mDisplayHeight = mHeight;
			mDisplayAspect = mApp->mWindowAspect;

			RECT rc;
			POINT pt;
			WINDOWINFO info;
			::GetWindowInfo(theWindow, &info);
			::GetClientRect(theWindow, &rc);
			pt.x = rc.left;
			pt.y = rc.top;
			::ClientToScreen(theWindow, &pt);
			rc.left = pt.x - (mDisplayWidth - mWidth) / 2;
			rc.top = pt.y - (mDisplayHeight - mHeight) / 2;
			rc.right = rc.left + mDisplayWidth;
			rc.bottom = rc.top + mDisplayHeight;
			::AdjustWindowRectEx(&rc, info.dwStyle, false, info.dwExStyle);
			::MoveWindow(theWindow, std::max((LONG)0, rc.left), std::max((LONG)0, rc.top), rc.right - rc.left, rc.bottom - rc.top, false);

			if (mApp->mWidescreenAware)
			{
				mWidth = mDisplayWidth;
				mHeight = mDisplayHeight;
				mAspect = mDisplayAspect;
				mPresentationRect.mWidth = mDisplayWidth;
				mPresentationRect.mHeight = mDisplayHeight;
				mPresentationRect.mX = 0;
				mPresentationRect.mY = 0;
			}
			else
			{
				mPresentationRect.mWidth = mWidth;
				mPresentationRect.mHeight = mHeight;
				mPresentationRect.mX = (mDisplayWidth - mPresentationRect.mWidth) / 2;
				mPresentationRect.mY = 0;
			}
		}

		if (mApp->mWindowScale > 1 && !aFullscreenBorderless)
		{
			mDisplayWidth = mWidth * mApp->mWindowScale;
			mDisplayHeight = mHeight * mApp->mWindowScale;
			mDisplayAspect = mAspect;

			RECT rc;
			POINT pt;
			WINDOWINFO info;
			::GetWindowInfo(theWindow, &info);
			::GetClientRect(theWindow, &rc);
			pt.x = rc.left;
			pt.y = rc.top;
			::ClientToScreen(theWindow, &pt);
			rc.left = pt.x - (mDisplayWidth - mWidth) / 2;
			rc.top = pt.y - (mDisplayHeight - mHeight) / 2;
			rc.right = rc.left + mDisplayWidth;
			rc.bottom = rc.top + mDisplayHeight;
			::AdjustWindowRectEx(&rc, info.dwStyle, false, info.dwExStyle);
			::MoveWindow(theWindow, std::max((LONG)0, rc.left), std::max((LONG)0, rc.top), rc.right - rc.left, rc.bottom - rc.top, false);

			mPresentationRect.mWidth = mDisplayWidth;
			mPresentationRect.mHeight = mDisplayHeight;
			mPresentationRect.mX = 0;
			mPresentationRect.mY = 0;
		}
		else if (!aFullscreenBorderless)
		{
			// Custom scale disabled: restore the native window size.
			mDisplayWidth = mWidth;
			mDisplayHeight = mHeight;
			mDisplayAspect = mAspect;
			mPresentationRect = Rect(0, 0, mWidth, mHeight);

			RECT aClientRect;
			::GetClientRect(theWindow, &aClientRect);
			if (aClientRect.right != mWidth || aClientRect.bottom != mHeight)
			{
				RECT aFrameRect = { 0, 0, mWidth, mHeight };
				::AdjustWindowRectEx(
					&aFrameRect,
					(DWORD)::GetWindowLongPtr(theWindow, GWL_STYLE),
					FALSE,
					(DWORD)::GetWindowLongPtr(theWindow, GWL_EXSTYLE));
				RECT aWinRect;
				::GetWindowRect(theWindow, &aWinRect);
				::MoveWindow(
					theWindow,
					aWinRect.left,
					aWinRect.top,
					aFrameRect.right - aFrameRect.left,
					aFrameRect.bottom - aFrameRect.top,
					FALSE);
			}
		}
	}
	else
	{
		// Borderless fullscreen without DirectDraw: fill the desktop.
		mDisplayWidth = mDesktopWidth;
		mDisplayHeight = mDesktopHeight;
		mDisplayAspect = mDesktopAspect;
		mIsWidescreen = false;
		mPresentationRect = Rect(0, 0, mDisplayWidth, mDisplayHeight);
	}

	RECT aLogRect;
	::GetClientRect(theWindow, &aLogRect);
	FILE* aScaleLog = fopen(GetLogFilePath("ddscale.log").c_str(), "w");
	if (aScaleLog != nullptr)
	{
		fprintf(
			aScaleLog,
			"windowScale=%d mW=%d mH=%d disp=%dx%d client=%ldx%ld presentation=%dx%d\n",
			mApp->mWindowScale,
			mWidth,
			mHeight,
			mDisplayWidth,
			mDisplayHeight,
			(long)(aLogRect.right - aLogRect.left),
			(long)(aLogRect.bottom - aLogRect.top),
			mPresentationRect.mWidth,
			mPresentationRect.mHeight);
		fclose(aScaleLog);
	}

	// Refresh rate from the OS display settings (no DirectDraw).
	mRefreshRate = 60;
	DEVMODEW aDevMode;
	ZeroMemory(&aDevMode, sizeof(aDevMode));
	aDevMode.dmSize = sizeof(aDevMode);
	if (EnumDisplaySettingsW(NULL, ENUM_CURRENT_SETTINGS, &aDevMode) && aDevMode.dmDisplayFrequency > 0)
		mRefreshRate = aDevMode.dmDisplayFrequency;
	if (mRefreshRate < 60)
		mRefreshRate = 60;
	else if (mRefreshRate > 100)
		mRefreshRate = 100;
	mMillisecondsPerFrame = 1000 / mRefreshRate;

	// 32-bit color conversion tables (desktop is assumed 32-bit).
	mRGBBits = 32;
	mRedMask = 0xFF0000;
	mGreenMask = 0x00FF00;
	mBlueMask = 0x0000FF;
	mRedBits = 8;
	mGreenBits = 8;
	mBlueBits = 8;
	mRedShift = 23;
	mGreenShift = 15;
	mBlueShift = 7;

	delete [] mRedAddTable;
	delete [] mGreenAddTable;
	delete [] mBlueAddTable;
	mRedAddTable = new int[256];
	mGreenAddTable = new int[256];
	mBlueAddTable = new int[256];
	for (int i = 0; i < 256; i++)
	{
		mRedAddTable[i] = i;
		mGreenAddTable[i] = i;
		mBlueAddTable[i] = i;
		mRedConvTable[i] = (ulong)((i * mRedMask) / 255) & mRedMask;
		mGreenConvTable[i] = (ulong)((i * mGreenMask) / 255) & mGreenMask;
		mBlueConvTable[i] = (ulong)((i * mBlueMask) / 255) & mBlueMask;
	}

	mScreenImage = new DDImage(this);
	mScreenImage->mWidth = mWidth;
	mScreenImage->mHeight = mHeight;
	mScreenImage->SetImageMode(false, false);

	if (mIs3D)
	{
		if (!mD3DInterface->InitFromDDInterface(this))
		{
			mErrorString = "3D init error: ";
			mErrorString += D3DInterface::mErrorString;
			return RESULT_3D_FAIL;
		}
	}

	// 4:3 fit rect inside the presentation area (letterbox bars excluded).
	{
		const double aScaleX = (double)mPresentationRect.mWidth / (double)mWidth;
		const double aScaleY = (double)mPresentationRect.mHeight / (double)mHeight;
		const double aScale = aScaleX < aScaleY ? aScaleX : aScaleY;
		mVisibleGameRect.mWidth = (int)((double)mWidth * aScale);
		mVisibleGameRect.mHeight = (int)((double)mHeight * aScale);
		mVisibleGameRect.mX = mPresentationRect.mX + (mPresentationRect.mWidth - mVisibleGameRect.mWidth) / 2;
		mVisibleGameRect.mY = mPresentationRect.mY + (mPresentationRect.mHeight - mVisibleGameRect.mHeight) / 2;
	}

	mInitCount++;
	mInitialized = true;
	return RESULT_OK;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
int DDInterface::ApplyScreenMode(HWND theWindow, bool wantWindowed)
{
	AutoCrit anAutoCrit(mCritSect);

	mHWnd = theWindow;
	mWidth = mApp->mWidth;
	mHeight = mApp->mHeight;
	mAspect.Set(mWidth, mHeight);
	mDesktopWidth = GetSystemMetrics(SM_CXSCREEN);
	mDesktopHeight = GetSystemMetrics(SM_CYSCREEN);
	mDesktopAspect.Set(mDesktopWidth, mDesktopHeight);
	mFullscreenBits = mApp->mFullscreenBits;

	// Same layout rules as Init(): the window has already been resized by the
	// app, so derive the presentation area from the new mode. The scene stays
	// at the logical game size; only the present (swapchain) size changes.
	mIsWindowed = wantWindowed || mIs3D;
	const bool aFullscreenBorderless = !wantWindowed && mIs3D;

	if (aFullscreenBorderless)
	{
		mDisplayWidth = mDesktopWidth;
		mDisplayHeight = mDesktopHeight;
		mDisplayAspect = mDesktopAspect;
		mIsWidescreen = false;
		mPresentationRect = Rect(0, 0, mDisplayWidth, mDisplayHeight);
	}
	else if (mApp->mWindowScale > 1)
	{
		mDisplayWidth = mWidth * mApp->mWindowScale;
		mDisplayHeight = mHeight * mApp->mWindowScale;
		mDisplayAspect = mAspect;
		mIsWidescreen = false;
		mPresentationRect = Rect(0, 0, mDisplayWidth, mDisplayHeight);
	}
	else
	{
		mDisplayWidth = mWidth;
		mDisplayHeight = mHeight;
		mDisplayAspect = mAspect;
		mIsWidescreen = false;
		mPresentationRect = Rect(0, 0, mWidth, mHeight);
	}

	if (mScreenImage != NULL)
	{
		delete mScreenImage;
		mScreenImage = NULL;
	}
	mScreenImage = new DDImage(this);
	mScreenImage->mWidth = mWidth;
	mScreenImage->mHeight = mHeight;
	mScreenImage->SetImageMode(false, false);

	if (mD3DInterface != NULL)
	{
		if (!mD3DInterface->ResizePresent(mDisplayWidth, mDisplayHeight))
		{
			mErrorString = "3D resize error: ";
			mErrorString += D3DInterface::mErrorString;
			return RESULT_3D_FAIL;
		}
	}

	// 4:3 fit rect inside the presentation area (letterbox bars excluded),
	// used to remap mouse input so bars never map into game space.
	{
		const double aScaleX = (double)mPresentationRect.mWidth / (double)mWidth;
		const double aScaleY = (double)mPresentationRect.mHeight / (double)mHeight;
		const double aScale = aScaleX < aScaleY ? aScaleX : aScaleY;
		mVisibleGameRect.mWidth = (int)((double)mWidth * aScale);
		mVisibleGameRect.mHeight = (int)((double)mHeight * aScale);
		mVisibleGameRect.mX = mPresentationRect.mX + (mPresentationRect.mWidth - mVisibleGameRect.mWidth) / 2;
		mVisibleGameRect.mY = mPresentationRect.mY + (mPresentationRect.mHeight - mVisibleGameRect.mHeight) / 2;
	}

	mInitCount++;
	mInitialized = true;
	return RESULT_OK;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
std::string DDInterface::ResultToString(int theResult)
{
	switch (theResult)
	{
	case RESULT_OK: return "OK";
	case RESULT_FAIL: return "FAIL";
	case RESULT_DD_CREATE_FAIL: return "DD_CREATE_FAIL";
	case RESULT_SURFACE_FAIL: return "SURFACE_FAIL";
	case RESULT_EXCLUSIVE_FAIL: return "EXCLUSIVE_FAIL";
	case RESULT_DISPCHANGE_FAIL: return "DISPCHANGE_FAIL";
	case RESULT_INVALID_COLORDEPTH: return "INVALID_COLORDEPTH";
	case RESULT_3D_FAIL: return "3D_FAIL";
	default: return "UNKNOWN";
	}
}
