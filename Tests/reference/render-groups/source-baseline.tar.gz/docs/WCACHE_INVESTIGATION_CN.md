# 1073 `userdata/WCache` 调查

## 结论

`WCache` 不是玩家存档，也不是 `cached` 音频目录，更不是 `compiled64-v1`。它是一组采用 Chromium 旧式 **block-file disk cache** 布局的缓存数据库文件：`index` 负责索引，`data_0` 到 `data_3` 分别保存缓存元数据、条目和不同大小的缓存块。这个布局本身是通用的键值/资源缓存格式；不能仅凭文件格式断言每个条目都是浏览器网页。

Chromium 的公开格式说明明确规定了这组文件的组成：一个 `index` 加四个 block 文件；`data_0`/`data_1` 通常用于 rankings/entry，`data_2`/`data_3` 用于 1 KiB/4 KiB 数据块，较大的数据另存为 `f_xxx` 文件。[Chromium Disk Cache 设计文档](https://www.chromium.org/developers/design-documents/network-stack/disk-cache/) 和对应的 `disk_format.h` 给出了相同的 magic、版本和字段定义。[Chromium `disk_format.h`](https://chromium.googlesource.com/experimental/chromium/src/+/45.0.2413.1/net/disk_cache/blockfile/disk_format.h)

调查对象：

```text
C:\ProgramData\PopCap Games\PlantsVsZombies\userdata\WCache
```

## 文件对应关系

| 文件 | 当前大小 | 文件头/作用 |
| --- | ---: | --- |
| `index` | 262,512 B | magic `0xC103CAC3`，版本 `0x00020000`（2.0）；哈希表、条目计数、字节计数和 LRU 索引 |
| `data_0` | 45,056 B | magic `0xC104CAC3`；每块 36 B，存 rankings/LRU 节点 |
| `data_1` | 270,336 B | magic `0xC104CAC3`；每块 256 B，存 EntryStore（键、哈希、数据流地址） |
| `data_2` | 8,192 B | 每块 1,024 B 的数据区，目前只有 8 KiB 头部 |
| `data_3` | 8,192 B | 每块 4,096 B 的数据区，目前只有 8 KiB 头部 |

block 文件的 8 KiB 头部包含分配位图和文件链信息；所以文件大小大于“实际缓存内容”并不代表里面已经存了同等大小的资源。

## 本机这份 WCache 的实际内容

对当前文件做了逐字节检查：

- `index` 的 `num_entries = 0`；`num_bytes = 0`。
- `index` 头部之后的 65,536 项哈希表全部为零，没有可达的活动条目。
- `data_0` 除头部外全为零。
- `data_1` 除头部外只有第一个 256 字节块的前 6 个字节非零；它没有被 `index` 指向，属于残留的分配或未完成更新痕迹，不能当作有效缓存条目。
- `data_2`、`data_3` 除头部外全为零。
- 目录中没有 `f_xxx` 外部大对象文件。

因此，这一份 WCache 目前实际上是“已初始化、没有活动缓存条目”的空缓存数据库。它里面没有能直接对应到 URL、资源 buffer、用户名、成就、关卡进度或 `game*.dat` 的内容。

## 为什么 1073 会有它

1073 可执行文件中仍保留了 Sexy Framework 的开发缓存接口和 IPC 字符串：

```text
SexyCache
SexyCache.exe
SexyCacheMessage
SexyCacheReq#%d
SexyCacheData#%d
```

反汇编可见，这套接口通过 `OpenFileMappingA`/`MapViewOfFile` 打开共享内存，并通过注册的窗口消息与独立的 `SexyCache.exe` 通信；它不是普通的 `game*.dat` 存档读写。`LawnApp::Init` 中的调用还被 `-tod` 调试开关包围：调试模式可以询问是否启动 `SexyCache.exe`，普通模式如果发现已连接的缓存服务则断开。

`WCache` 目录本身没有在 1073 主程序中以明文字符串出现，说明真正创建/维护磁盘数据库的更可能是外部 SexyCache 服务或其缓存组件，而不是游戏主循环直接写文件。仅凭主程序不能把某一个缓存键映射到当前这份空库；这部分要在 SexyCache 服务运行时做文件访问跟踪才能进一步确认。

1073 还保留了 `WININET.dll`、注册/HTTP 相关代码和 PopCap URL。它们是联网/注册/崩溃提交一侧的旧功能；不能把这些 URL 字符串误认为存档格式，也不能据此推断 Legacy 必须联网。

## 与项目中其它目录的区别

| 路径/文件 | 内容 | Legacy 是否依赖 |
| --- | --- | --- |
| `userdata/game*.dat`, `user*.dat` | 关卡中途状态、用户资料、成就等 | 是，项目改为程序同级 `./data` |
| `cached\sounds` | 1073 DirectSound/BASS 旧音频 PCM 缓存 | 否；Legacy 直接从无加密 `main.pak64` 读取音频 |
| `compiled64-v1` | 早期项目的 x64 定义缓存 | 发行版不依赖，定义已预编译进 `main.pak64` |
| `WCache` | SexyCache/资源 buffer 的 block-file 缓存数据库 | 否 |

## Legacy 的处理决定

Legacy 不创建、不读取、不清理 `WCache`，也不启动 `SexyCache.exe`。源码中
SexyCache 缓冲写入、共享缓存初始化和相关 IPC/HTTP 实现已经删除，不是
“保留后再禁用”。
- 运行时资源只从 `main.pak64`、普通文件和程序同级 `data` 读取。

对当前 `out\legacy-msvc2\Release\SexyAppFramework.exe` 做了导入表检查：没有
`WININET.dll`、`WSOCK32.dll` 或 `URLMON.dll`，`SHELL32.dll` 只保留拖放相关函数，
没有 `ShellExecute`。因此 Legacy 不会因为这条路径偷偷启动网页缓存或联网组件。

因此，Legacy 没有 `WCache` 是预期行为，不是缺少资源。不要为了“兼容”它而引入 ProgramData、WinINet 或外部缓存服务依赖。

如果只清理磁盘空间，在原版及其它 PopCap 程序都退出后可以备份再删除整个 `WCache`；它是可重建缓存，不应作为存档迁移的一部分。若要继续精确追踪是谁创建它，应在启动 1073 的 `-tod`/SexyCache 服务时监控 `WCache\index` 的 `CreateFile/WriteFile` 调用，而不是修改 Legacy 的资源读取器。
