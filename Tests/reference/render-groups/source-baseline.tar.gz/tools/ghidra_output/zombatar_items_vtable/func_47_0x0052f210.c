
void __fastcall FUN_0052f210(int *param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined1 local_7c [112];
  void *pvStack_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c6b90;
  pvStack_c = ExceptionList;
  iVar4 = param_1[0x3d7];
  if (iVar4 != 0) {
    if (iVar4 == 3) {
      iVar4 = param_1[0x34];
      if (((*(char *)(iVar4 + 0x18) == '\0') || (*(char *)(iVar4 + 0x1a) != '\0')) ||
         (*(char *)(iVar4 + 0xfd) != '\0')) {
        iVar4 = param_1[0x35];
        ExceptionList = &pvStack_c;
        if (((*(char *)(iVar4 + 0x18) != '\0') &&
            (ExceptionList = &pvStack_c, *(char *)(iVar4 + 0x1a) == '\0')) &&
           (ExceptionList = &pvStack_c, *(char *)(iVar4 + 0xfd) == '\0')) {
          ExceptionList = &pvStack_c;
          (**(code **)(*param_1 + 0x118))(0x3eb);
        }
      }
      else {
        ExceptionList = &pvStack_c;
        (**(code **)(*param_1 + 0x118))(0x3ea);
      }
    }
    else {
      ExceptionList = &pvStack_c;
      if (iVar4 == 4) {
        iVar4 = param_1[0x36];
        if (((*(char *)(iVar4 + 0x18) == '\0') || (*(char *)(iVar4 + 0x1a) != '\0')) ||
           (*(char *)(iVar4 + 0xfd) != '\0')) {
          iVar4 = param_1[0x37];
          if (((*(char *)(iVar4 + 0x18) == '\0') || (*(char *)(iVar4 + 0x1a) != '\0')) ||
             (*(char *)(iVar4 + 0xfd) != '\0')) {
            ExceptionList = &pvStack_c;
            cVar1 = FUN_0044af30();
            if (cVar1 == '\x01') {
              (**(code **)(*param_1 + 0x118))(0x3ee);
            }
            else if (*(char *)((int)param_1 + 0xf6f) == '\x01') {
              FUN_004021f0(&DAT_006e346c);
              local_4 = 0;
              uVar2 = FUN_00523c40();
              local_4._0_1_ = 1;
              uVar3 = FUN_00523c40();
              local_4 = CONCAT31(local_4._1_3_,2);
              (**(code **)(*(int *)param_1[0x28] + 0x120))(0x36,0,uVar3,uVar2,local_7c,2);
              FUN_00401b00();
              FUN_00401b00();
              local_4 = 0xffffffff;
              FUN_00401b00();
              uVar2 = FUN_00523c40();
              local_4 = 3;
              FUN_00401c60(uVar2,0,0xffffffff);
              local_4 = 0xffffffff;
              FUN_00401b00();
            }
          }
          else {
            ExceptionList = &pvStack_c;
            (**(code **)(*param_1 + 0x118))(0x3ed);
          }
        }
        else {
          ExceptionList = &pvStack_c;
          (**(code **)(*param_1 + 0x118))(0x3ec);
        }
      }
    }
    goto LAB_0052f5cb;
  }
  iVar4 = param_1[0x29];
  if (((*(char *)(iVar4 + 0x18) == '\0') || (*(char *)(iVar4 + 0x1a) != '\0')) ||
     (*(char *)(iVar4 + 0xfd) != '\0')) {
    iVar4 = param_1[0x2a];
    if (((*(char *)(iVar4 + 0x18) != '\0') && (*(char *)(iVar4 + 0x1a) == '\0')) &&
       (*(char *)(iVar4 + 0xfd) == '\0')) {
      uVar2 = 1000;
      ExceptionList = &pvStack_c;
      goto LAB_0052f561;
    }
    ExceptionList = &pvStack_c;
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f9;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f6;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f5;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f3;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f2;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f8;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f7;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f1;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f4;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3eb;
      goto LAB_0052f561;
    }
    cVar1 = FUN_0044af30();
    if (cVar1 == '\x01') {
      uVar2 = 0x3f0;
      goto LAB_0052f561;
    }
  }
  else {
    uVar2 = 0x3e9;
    ExceptionList = &pvStack_c;
LAB_0052f561:
    (**(code **)(*param_1 + 0x118))(uVar2);
  }
  iVar4 = FUN_0052fbf0(&stack0x00000004,&stack0x00000008);
  param_1[0x3c3] = iVar4;
  if (iVar4 != -1) {
    if (param_1[iVar4 * 7 + 0x41] == 0) {
      param_1[param_1[0x3c4] + 0x3ce] = -1;
    }
    else {
      param_1[param_1[0x3c4] + 0x3ce] = iVar4;
    }
    FUN_0052fda0();
    *(undefined1 *)(param_1 + 0x3db) = 1;
  }
LAB_0052f5cb:
  iVar4 = param_1[0x39];
  if (((*(char *)(iVar4 + 0x18) != '\0') && (*(char *)(iVar4 + 0x1a) == '\0')) &&
     (*(char *)(iVar4 + 0xfd) == '\0')) {
    (**(code **)(*param_1 + 0x118))(0x3ef);
  }
  ExceptionList = pvStack_c;
  return;
}

