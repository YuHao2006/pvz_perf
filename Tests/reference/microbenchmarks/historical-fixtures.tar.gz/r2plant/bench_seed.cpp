// bench_seed.cpp — SeedPacket.cpp 2 目标段表性能对拍（第二轮补测）
//   #17 kSeedNeedsAdvice 8      -> SeedPacket::MouseDown 用种建议（命名空间级 constexpr，照抄 HEAD）
//   #18 kTutorialAdvanceCases 31-> SeedPacket::MouseDown 教程推进（命名空间级 constexpr，照抄）
// FormA = 403c1968^ 原函数（MouseDown 全函数逐字，两目标共用函数体、不同输入分布
// 分别压各自分发区）。
#include "r2_stub.h"

inline unsigned Rand(unsigned n) { MixCk(0x1090ULL, n); return n ? RngNext() % n : 0u; }

#define SEEDPKT_MEMBERS                                                          \
    SeedType mPacketType = SEED_PEASHOOTER;                                      \
    SeedType mImitaterType = SEED_NONE;                                          \
    int mIndex = 0;                                                              \
    bool mActive = true;                                                         \
    int mTimesUsed = 0;                                                          \
    Board* mBoard = &g_board;                                                    \
    LawnApp* mApp = &g_app;                                                      \
                                                                                  \
    void Deactivate() { MixCk(0x6000ULL); mActive = false; }                     \
    __declspec(noinline) void MouseDown(int x, int y, int theClickCount);

// ================================================================= FormA
namespace FA {

struct SeedPacket
{
    SEEDPKT_MEMBERS
};

// ---- MouseDown（A：8 支建议链 + 4 支教程链）
void SeedPacket::MouseDown(int x, int y, int theClickCount)
{
    (void)x;(void)y;(void)theClickCount;
    if (mBoard->mPaused || mApp->mGameScene != GameScenes::SCENE_PLAYING || mPacketType == SeedType::SEED_NONE)
    {
        return;
    }

    if (mApp->IsSlotMachineLevel())
    {
        if (!mBoard->mAdvice->IsBeingDisplayed())
        {
            mBoard->DisplayAdvice(gStr.ADVICE_SLOT_MACHINE_PULL, MessageStyle::MESSAGE_STYLE_HINT_TALL_FAST, AdviceType::ADVICE_NONE);
        }
        mBoard->mChallenge->mSlotMachineRollCount = std::min(mBoard->mChallenge->mSlotMachineRollCount, 2);
        return;
    }

    SeedType aUseSeedType = mPacketType;
    if (mPacketType == SeedType::SEED_IMITATER && mImitaterType != SeedType::SEED_NONE)
    {
        aUseSeedType = mImitaterType;
    }

    if (!mApp->mEasyPlantingCheat)
    {
        if (!mActive)
        {
            mApp->PlaySample(SOUND_BUZZER);
            if (mApp->IsFirstTimeAdventureMode() && mBoard->mLevel == 1 && mBoard->mHelpDisplayed[(int)AdviceType::ADVICE_CLICK_ON_SUN])
            {
                mBoard->DisplayAdvice(gStr.ADVICE_SEED_REFRESH, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1, AdviceType::ADVICE_SEED_REFRESH);
            }
            return;
        }

        int aCost = mBoard->GetCurrentPlantCost(mPacketType, mImitaterType);
        if (!mBoard->CanTakeSunMoney(aCost) && !mBoard->HasConveyorBeltSeedBank())
        {
            mApp->PlaySample(SOUND_BUZZER);
            mBoard->mOutOfMoneyCounter = 70;
            if (mApp->IsFirstTimeAdventureMode() && mBoard->mLevel == 1 && mBoard->mHelpDisplayed[(int)AdviceType::ADVICE_CLICK_ON_SUN])
            {
                mBoard->DisplayAdvice(gStr.ADVICE_CANT_AFFORD_PLANT, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1, AdviceType::ADVICE_CANT_AFFORD_PLANT);
            }
            return;
        }

        if (!mBoard->Met(aUseSeedType))
        {
            mApp->PlaySample(SOUND_BUZZER);
            if (aUseSeedType == SeedType::SEED_GATLINGPEA)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_REPEATER, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_REPEATER);
            }
            else if (aUseSeedType == SeedType::SEED_WINTERMELON)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_MELONPULT, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_MELONPULT);
            }
            else if (aUseSeedType == SeedType::SEED_TWINSUNFLOWER)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_SUNFLOWER, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_SUNFLOWER);
            }
            else if (aUseSeedType == SeedType::SEED_SPIKEROCK)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_SPIKEWEED, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_SPIKEWEED);
            }
            else if (aUseSeedType == SeedType::SEED_COBCANNON)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_KERNELPULT, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_KERNELPULT);
            }
            else if (aUseSeedType == SeedType::SEED_GOLD_MAGNET)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_MAGNETSHROOM, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_MAGNETSHROOM);
            }
            else if (aUseSeedType == SeedType::SEED_GLOOMSHROOM)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_FUMESHROOM, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_FUMESHROOM);
            }
            else if (aUseSeedType == SeedType::SEED_CATTAIL)
            {
                mBoard->DisplayAdvice(gStr.ADVICE_PLANT_NEEDS_LILYPAD, MessageStyle::MESSAGE_STYLE_HINT_LONG, AdviceType::ADVICE_PLANT_NEEDS_LILYPAD);
            }
            else
            {
                TOD_ASSERT(false);
            }

            return;
        }
    }

    mBoard->ClearAdvice(AdviceType::ADVICE_CANT_AFFORD_PLANT);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_REPEATER);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_MELONPULT);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_SUNFLOWER);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_KERNELPULT);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_SPIKEWEED);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_MAGNETSHROOM);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_FUMESHROOM);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_LILYPAD);

    if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED || mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST)
    {
        mBoard->mChallenge->BeghouledPacketClicked(this);
    }
    else if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_ZOMBIQUARIUM)
    {
        mBoard->mChallenge->ZombiquariumPacketClicked(this);
    }
    else
    {
        mBoard->mCursorObject->mType = mPacketType;
        mBoard->mCursorObject->mImitaterType = mImitaterType;
        mBoard->mCursorObject->mCursorType = CursorType::CURSOR_TYPE_PLANT_FROM_BANK;
        mBoard->mCursorObject->mSeedBankIndex = mIndex;
        mApp->PlaySample(SOUND_SEEDLIFT);

        if (mBoard->mTutorialState == TutorialState::TUTORIAL_LEVEL_1_PICK_UP_PEASHOOTER)
        {
            mBoard->SetTutorialState(TutorialState::TUTORIAL_LEVEL_1_PLANT_PEASHOOTER);
        }
        else if (mBoard->mTutorialState == TutorialState::TUTORIAL_LEVEL_2_PICK_UP_SUNFLOWER)
        {
            if (mPacketType == SeedType::SEED_SUNFLOWER)
            {
                mBoard->SetTutorialState(TutorialState::TUTORIAL_LEVEL_2_PLANT_SUNFLOWER);
            }
            else
            {
                mBoard->SetTutorialState(TutorialState::TUTORIAL_LEVEL_2_REFRESH_SUNFLOWER);
            }
        }
        else if (mBoard->mTutorialState == TutorialState::TUTORIAL_MORESUN_PICK_UP_SUNFLOWER)
        {
            if (mPacketType == SeedType::SEED_SUNFLOWER)
            {
                mBoard->SetTutorialState(TutorialState::TUTORIAL_MORESUN_PLANT_SUNFLOWER);
            }
            else
            {
                mBoard->SetTutorialState(TutorialState::TUTORIAL_MORESUN_REFRESH_SUNFLOWER);
            }
        }
        else if (mBoard->mTutorialState == TutorialState::TUTORIAL_WHACK_A_ZOMBIE_PICK_SEED || mBoard->mTutorialState == TutorialState::TUTORIAL_WHACK_A_ZOMBIE_BEFORE_PICK_SEED)
        {
            mBoard->SetTutorialState(TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED);
        }

        Deactivate();
    }
}

} // namespace FA

// ================================================================= FormB
namespace FB {

struct SeedPacket
{
    SEEDPKT_MEMBERS
};

namespace
{
// SeedPacket::MouseDown 升级种子未达成提示表：下标 = aUseSeedType - SEED_GATLINGPEA，
// 行序 = 升级种子连续枚举段 40..47（8 槽全满）。
constexpr struct { const std::string* mStr; AdviceType mAdvice; } kSeedNeedsAdvice[
    (int)SeedType::SEED_COBCANNON - (int)SeedType::SEED_GATLINGPEA + 1] = {
    { &g_strValues[0],  AdviceType::ADVICE_PLANT_NEEDS_REPEATER },      // 40 SEED_GATLINGPEA
    { &g_strValues[1],  AdviceType::ADVICE_PLANT_NEEDS_SUNFLOWER },     // 41 SEED_TWINSUNFLOWER
    { &g_strValues[2],  AdviceType::ADVICE_PLANT_NEEDS_FUMESHROOM },    // 42 SEED_GLOOMSHROOM
    { &g_strValues[3],  AdviceType::ADVICE_PLANT_NEEDS_LILYPAD },       // 43 SEED_CATTAIL
    { &g_strValues[4],  AdviceType::ADVICE_PLANT_NEEDS_MELONPULT },     // 44 SEED_WINTERMELON
    { &g_strValues[5],  AdviceType::ADVICE_PLANT_NEEDS_MAGNETSHROOM },  // 45 SEED_GOLD_MAGNET
    { &g_strValues[6],  AdviceType::ADVICE_PLANT_NEEDS_SPIKEWEED },     // 46 SEED_SPIKEROCK
    { &g_strValues[7],  AdviceType::ADVICE_PLANT_NEEDS_KERNELPULT },    // 47 SEED_COBCANNON
};
static_assert(sizeof(kSeedNeedsAdvice) / sizeof(kSeedNeedsAdvice[0]) ==
    (int)SeedType::SEED_COBCANNON - (int)SeedType::SEED_GATLINGPEA + 1,
    "kSeedNeedsAdvice 槽位须与升级种子枚举段同步");

// SeedPacket::MouseDown 教程推进表：nullptr 槽 = 原链不匹配。
using TutorialAdvanceFn = void (*)(SeedPacket&);

constexpr TutorialAdvanceFn kTutorialAdvanceCases[(int)TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED + 1] = {
    nullptr,  // 0 TUTORIAL_OFF
    [](SeedPacket& p)
    {
        p.mBoard->SetTutorialState(TutorialState::TUTORIAL_LEVEL_1_PLANT_PEASHOOTER);
    },  // 1 TUTORIAL_LEVEL_1_PICK_UP_PEASHOOTER
    nullptr,  // 2
    nullptr,  // 3
    nullptr,  // 4
    [](SeedPacket& p)
    {
        if (p.mPacketType == SeedType::SEED_SUNFLOWER)
        {
            p.mBoard->SetTutorialState(TutorialState::TUTORIAL_LEVEL_2_PLANT_SUNFLOWER);
        }
        else
        {
            p.mBoard->SetTutorialState(TutorialState::TUTORIAL_LEVEL_2_REFRESH_SUNFLOWER);
        }
    },  // 5 TUTORIAL_LEVEL_2_PICK_UP_SUNFLOWER
    nullptr,  // 6
    nullptr,  // 7
    nullptr,  // 8
    [](SeedPacket& p)
    {
        if (p.mPacketType == SeedType::SEED_SUNFLOWER)
        {
            p.mBoard->SetTutorialState(TutorialState::TUTORIAL_MORESUN_PLANT_SUNFLOWER);
        }
        else
        {
            p.mBoard->SetTutorialState(TutorialState::TUTORIAL_MORESUN_REFRESH_SUNFLOWER);
        }
    },  // 9 TUTORIAL_MORESUN_PICK_UP_SUNFLOWER
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,  // 10..19
    nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,  // 20..27
    [](SeedPacket& p)
    {
        p.mBoard->SetTutorialState(TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED);
    },  // 28 TUTORIAL_WHACK_A_ZOMBIE_BEFORE_PICK_SEED
    [](SeedPacket& p)
    {
        p.mBoard->SetTutorialState(TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED);
    },  // 29 TUTORIAL_WHACK_A_ZOMBIE_PICK_SEED（共体）
    nullptr,  // 30 TUTORIAL_WHACK_A_ZOMBIE_COMPLETED
};
static_assert(sizeof(kTutorialAdvanceCases) / sizeof(kTutorialAdvanceCases[0]) ==
    (int)TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED + 1,
    "kTutorialAdvanceCases 槽位数须与 TutorialState 枚举同步");
}

// ---- MouseDown（B：kSeedNeedsAdvice 8 槽 + kTutorialAdvanceCases 31 槽——照抄）
void SeedPacket::MouseDown(int x, int y, int theClickCount)
{
    (void)x;(void)y;(void)theClickCount;
    if (mBoard->mPaused || mApp->mGameScene != GameScenes::SCENE_PLAYING || mPacketType == SeedType::SEED_NONE)
    {
        return;
    }

    if (mApp->IsSlotMachineLevel())
    {
        if (!mBoard->mAdvice->IsBeingDisplayed())
        {
            mBoard->DisplayAdvice(gStr.ADVICE_SLOT_MACHINE_PULL, MessageStyle::MESSAGE_STYLE_HINT_TALL_FAST, AdviceType::ADVICE_NONE);
        }
        mBoard->mChallenge->mSlotMachineRollCount = std::min(mBoard->mChallenge->mSlotMachineRollCount, 2);
        return;
    }

    SeedType aUseSeedType = mPacketType;
    if (mPacketType == SeedType::SEED_IMITATER && mImitaterType != SeedType::SEED_NONE)
    {
        aUseSeedType = mImitaterType;
    }

    if (!mApp->mEasyPlantingCheat)
    {
        if (!mActive)
        {
            mApp->PlaySample(SOUND_BUZZER);
            if (mApp->IsFirstTimeAdventureMode() && mBoard->mLevel == 1 && mBoard->mHelpDisplayed[(int)AdviceType::ADVICE_CLICK_ON_SUN])
            {
                mBoard->DisplayAdvice(gStr.ADVICE_SEED_REFRESH, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1, AdviceType::ADVICE_SEED_REFRESH);
            }
            return;
        }

        int aCost = mBoard->GetCurrentPlantCost(mPacketType, mImitaterType);
        if (!mBoard->CanTakeSunMoney(aCost) && !mBoard->HasConveyorBeltSeedBank())
        {
            mApp->PlaySample(SOUND_BUZZER);
            mBoard->mOutOfMoneyCounter = 70;
            if (mApp->IsFirstTimeAdventureMode() && mBoard->mLevel == 1 && mBoard->mHelpDisplayed[(int)AdviceType::ADVICE_CLICK_ON_SUN])
            {
                mBoard->DisplayAdvice(gStr.ADVICE_CANT_AFFORD_PLANT, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1, AdviceType::ADVICE_CANT_AFFORD_PLANT);
            }
            return;
        }

        if (!mBoard->Met(aUseSeedType))
        {
            mApp->PlaySample(SOUND_BUZZER);

            // B 形态 -> 常量表（上方 kSeedNeedsAdvice）：下标平移
            const int anUpgradeIndex = (int)aUseSeedType - (int)SeedType::SEED_GATLINGPEA;
            if ((unsigned)anUpgradeIndex < sizeof(kSeedNeedsAdvice) / sizeof(kSeedNeedsAdvice[0]))
            {
                mBoard->DisplayAdvice(*kSeedNeedsAdvice[anUpgradeIndex].mStr,
                    MessageStyle::MESSAGE_STYLE_HINT_LONG, kSeedNeedsAdvice[anUpgradeIndex].mAdvice);
            }
            else
            {
                TOD_ASSERT(false);
            }

            return;
        }
    }

    mBoard->ClearAdvice(AdviceType::ADVICE_CANT_AFFORD_PLANT);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_REPEATER);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_MELONPULT);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_SUNFLOWER);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_KERNELPULT);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_SPIKEWEED);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_MAGNETSHROOM);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_FUMESHROOM);
    mBoard->ClearAdvice(AdviceType::ADVICE_PLANT_NEEDS_LILYPAD);

    if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED || mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST)
    {
        mBoard->mChallenge->BeghouledPacketClicked(this);
    }
    else if (mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_ZOMBIQUARIUM)
    {
        mBoard->mChallenge->ZombiquariumPacketClicked(this);
    }
    else
    {
        mBoard->mCursorObject->mType = mPacketType;
        mBoard->mCursorObject->mImitaterType = mImitaterType;
        mBoard->mCursorObject->mCursorType = CursorType::CURSOR_TYPE_PLANT_FROM_BANK;
        mBoard->mCursorObject->mSeedBankIndex = mIndex;
        mApp->PlaySample(SOUND_SEEDLIFT);

        // C 形态 -> 匿名 lambda 表（上方 kTutorialAdvanceCases）
        const unsigned aTutorialIndex = static_cast<unsigned>(mBoard->mTutorialState);
        if (aTutorialIndex <= static_cast<unsigned>(TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED) &&
            kTutorialAdvanceCases[aTutorialIndex] != nullptr)
        {
            kTutorialAdvanceCases[aTutorialIndex](*this);
        }

        Deactivate();
    }
}

} // namespace FB

// ================================================================= 驱动
static FA::SeedPacket g_objA[NOBJ], g_pristineA[NOBJ];
static FB::SeedPacket g_objB[NOBJ], g_pristineB[NOBJ];
static In g_in[NIN];

void A_Down(FA::SeedPacket* p) { p->MouseDown(0, 0, 1); }
void B_Down(FB::SeedPacket* p) { p->MouseDown(0, 0, 1); }

int main()
{
    InitZombiePool();
    gSexyAppBase = &g_app;
    g_app.mGameMode = GAMEMODE_ADVENTURE;
    g_app.mGameScene = SCENE_PLAYING;
    g_app.mEasyPlantingCheat = false;
    g_board.mPaused = false;

    printf("%-30s | %19s | %19s | %8s | %s\n", "target(SeedPacket)", "A ns r1/r2", "B ns r1/r2", "diff%", "checksum A/B");

    // ---- #17 用种建议：mPacketType 36..52（升级段 40..47 为主，邻域走 TOD_ASSERT else）
    GenInputs(g_in, NIN, 0xB001, 53, 1, 1, 1);
    {
        auto prepA = [](FA::SeedPacket& p, const In& in) {
            p.mPacketType = (SeedType)in.a; p.mImitaterType = SEED_NONE; p.mActive = true; p.mIndex = 3;
            g_metFlag = false;
            g_board.mTutorialState = TUTORIAL_OFF;
        };
        auto prepB = [](FB::SeedPacket& p, const In& in) {
            p.mPacketType = (SeedType)in.a; p.mImitaterType = SEED_NONE; p.mActive = true; p.mIndex = 3;
            g_metFlag = false;
            g_board.mTutorialState = TUTORIAL_OFF;
        };
        RunTarget("17 kSeedNeedsAdvice 8", A_Down, B_Down,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    // ---- #18 教程推进：Met=true 走到底，mTutorialState 0..30 全宽
    GenInputs(g_in, NIN, 0xB002, 31, 53, 1, 1);
    {
        auto prepA = [](FA::SeedPacket& p, const In& in) {
            p.mPacketType = (SeedType)in.b; p.mImitaterType = SEED_NONE; p.mActive = true; p.mIndex = 3;
            g_metFlag = true;
            g_board.mTutorialState = (TutorialState)in.a;
        };
        auto prepB = [](FB::SeedPacket& p, const In& in) {
            p.mPacketType = (SeedType)in.b; p.mImitaterType = SEED_NONE; p.mActive = true; p.mIndex = 3;
            g_metFlag = true;
            g_board.mTutorialState = (TutorialState)in.a;
        };
        RunTarget("18 kTutorialAdvanceCases 31", A_Down, B_Down,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    return 0;
}
