// bench_t08 — kDolphinPhaseCases 6 -> UpdateZombieDolphinRider（海豚期每帧）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::UpdateZombieDolphinRider_A()
{
    if (IsTangleKelpTarget())
        return;

    bool aBackwards = IsWalkingBackwards();
    if (mZombiePhase == ZombiePhase::PHASE_DOLPHIN_WALKING && !aBackwards)
    {
        if (mX > 700 && mX <= 720)
        {
            mZombiePhase = ZombiePhase::PHASE_DOLPHIN_INTO_POOL;
            PlayZombieReanim(ReanimTrackId::anim_jumpinpool, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 16.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DOLPHIN_INTO_POOL)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aBodyReanim->ShouldTriggerTimedEvent(0.56f))
        {
            Reanimation* aSplashReanim = mApp->AddReanimation(mX - 83, mY + 73, mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
            aSplashReanim->OverrideScale(1.2f, 0.8f);
            mApp->AddTodParticle(mX - 46, mY + 115, mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
            mApp->PlayFoley(FoleyType::FOLEY_ZOMBIE_ENTERING_WATER);
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            mPosX -= 70.0f;
            mZombiePhase = ZombiePhase::PHASE_DOLPHIN_RIDING;
            mInPool = true;
            mZombieAttackRect = Rect(-29, 0, 70, 115);
            PlayZombieReanim(ReanimTrackId::anim_ride, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DOLPHIN_RIDING)
    {
        if (mX <= 10)
        {
            mAltitude = -40.0f;
            mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;
            mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING;

            PoolSplash(false);
            PlayZombieReanim(ReanimTrackId::anim_walkdolphin, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
            PickRandomSpeed();
            return;
        }

        if (mHasHead && !IsTanglekelpTarget())
        {
            Plant* aPlant = FindPlantTarget(ZombieAttackType::ATTACKTYPE_VAULT);
            if (aPlant)
            {
                mApp->PlayFoley(FoleyType::FOLEY_DOLPHIN_BEFORE_JUMPING);
                mApp->PlayFoley(FoleyType::FOLEY_PLANT_WATER);

                mVelX = 0.5f;
                mZombiePhase = ZombiePhase::PHASE_DOLPHIN_IN_JUMP;
                mPhaseCounter = DOLPHIN_JUMP_TIME;
                PlayZombieReanim(ReanimTrackId::anim_dolphinjump, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 10.0f);
            }
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DOLPHIN_IN_JUMP)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        mAltitude = TodAnimateCurveFloat(DOLPHIN_JUMP_TIME, 0, mPhaseCounter, 0.0f, 10.0f, Curves::Linear);

        bool aJumpEnds = false;
        if (aBodyReanim->ShouldTriggerTimedEvent(0.3f))
        {
            Plant* aPlant = FindPlantTarget(ZombieAttackType::ATTACKTYPE_VAULT);
            if (aPlant && aPlant->mSeedType == SeedType::SEED_TALLNUT)
            {
                mApp->PlayFoley(FoleyType::FOLEY_BONK);
                aJumpEnds = true;
                mApp->AddTodParticle(aPlant->mX + 60, aPlant->mY - 20, mRenderOrder + 1, ParticleEffect::PARTICLE_TALL_NUT_BLOCK);

                mZombieHeight = ZombieHeight::HEIGHT_FALLING;
                mPosX = aPlant->mX + 25.0f;
                mAltitude = 30.0f;
            }
        }
        else if (aBodyReanim->ShouldTriggerTimedEvent(0.49f))
        {
            Reanimation* aSplashReanim = mApp->AddReanimation(mX - 63, mY + 73, mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
            aSplashReanim->OverrideScale(1.2f, 0.8f);
            mApp->AddTodParticle(mX - 26, mY + 115, mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
            mApp->PlayFoley(FoleyType::FOLEY_ZOMBIE_ENTERING_WATER);
            mVelX = 0.0f;
        }
        else if (aBodyReanim->mLoopCount > 0)
        {
            aJumpEnds = true;
            mPosX -= 94.0f;
            mAltitude = 0.0f;
        }

        if (aJumpEnds)
        {
            mZombieAttackRect = Rect(30, 0, 30, 115);
            mZombieRect = Rect(20, 0, 42, 115);
            mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL;
            StartWalkAnim(0);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL)
    {
        if ((mX <= 10 && !aBackwards) || (mX > 680 && aBackwards))
        {
            mAltitude = -40.0f;
            mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;
            mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING_WITHOUT_DOLPHIN;

            PoolSplash(false);
            PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
            PickRandomSpeed();
        }
    }
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::UpdateZombieDolphinRider_B()
{
    if (IsTangleKelpTarget())
        return;

    // C 形态 -> 匿名 lambda 函数指针表 kDolphinPhaseCases（仿 kBossPhaseCases
    // 范式）：行序 = ZombiePhase 枚举序 PHASE_DOLPHIN_WALKING..
    // PHASE_DOLPHIN_WALKING_WITHOUT_DOLPHIN（6 相位连续）；WALKING_WITHOUT_
    // DOLPHIN 槽 nullptr（原无 case）。原链首两支的 aBackwards 判别移入对应
    // lambda（IsWalkingBackwards() 纯查询，分发前后无状态突变，取值等价）；
    // RIDING 支的 early return 在 lambda 内回归（分派即函数尾，语义等价）。
    using DolphinPhaseFn = void (*)(Zombie&);
    static constexpr DolphinPhaseFn kDolphinPhaseCases[(int)ZombiePhase::PHASE_DOLPHIN_WALKING_WITHOUT_DOLPHIN - (int)ZombiePhase::PHASE_DOLPHIN_WALKING + 1] = {
        // 原 if PHASE_DOLPHIN_WALKING && !aBackwards
        [](Zombie& z)
        {
            if (!z.IsWalkingBackwards())
            {
                if (z.mX > 700 && z.mX <= 720)
                {
                    z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_INTO_POOL;
                    z.PlayZombieReanim(ReanimTrackId::anim_jumpinpool, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 16.0f);
                }
            }
        },  // PHASE_DOLPHIN_WALKING
        // 原 else-if PHASE_DOLPHIN_INTO_POOL
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (aBodyReanim->ShouldTriggerTimedEvent(0.56f))
            {
                Reanimation* aSplashReanim = z.mApp->AddReanimation(z.mX - 83, z.mY + 73, z.mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
                aSplashReanim->OverrideScale(1.2f, 0.8f);
                z.mApp->AddTodParticle(z.mX - 46, z.mY + 115, z.mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
                z.mApp->PlayFoley(FoleyType::FOLEY_ZOMBIE_ENTERING_WATER);
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.mPosX -= 70.0f;
                z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_RIDING;
                z.mInPool = true;
                z.mZombieAttackRect = Rect(-29, 0, 70, 115);
                z.PlayZombieReanim(ReanimTrackId::anim_ride, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
            }
        },  // PHASE_DOLPHIN_INTO_POOL
        // 原 else-if PHASE_DOLPHIN_RIDING
        [](Zombie& z)
        {
            if (z.mX <= 10)
            {
                z.mAltitude = -40.0f;
                z.mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;
                z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING;

                z.PoolSplash(false);
                z.PlayZombieReanim(ReanimTrackId::anim_walkdolphin, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
                z.PickRandomSpeed();
                return;  // 原 UpdateZombieDolphinRider 早退：分派为函数尾，等价
            }

            if (z.mHasHead && !z.IsTanglekelpTarget())
            {
                Plant* aPlant = z.FindPlantTarget(ZombieAttackType::ATTACKTYPE_VAULT);
                if (aPlant)
                {
                    z.mApp->PlayFoley(FoleyType::FOLEY_DOLPHIN_BEFORE_JUMPING);
                    z.mApp->PlayFoley(FoleyType::FOLEY_PLANT_WATER);

                    z.mVelX = 0.5f;
                    z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_IN_JUMP;
                    z.mPhaseCounter = DOLPHIN_JUMP_TIME;
                    z.PlayZombieReanim(ReanimTrackId::anim_dolphinjump, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 10.0f);
                }
            }
        },  // PHASE_DOLPHIN_RIDING
        // 原 else-if PHASE_DOLPHIN_IN_JUMP
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            z.mAltitude = TodAnimateCurveFloat(DOLPHIN_JUMP_TIME, 0, z.mPhaseCounter, 0.0f, 10.0f, Curves::Linear);

            bool aJumpEnds = false;
            if (aBodyReanim->ShouldTriggerTimedEvent(0.3f))
            {
                Plant* aPlant = z.FindPlantTarget(ZombieAttackType::ATTACKTYPE_VAULT);
                if (aPlant && aPlant->mSeedType == SeedType::SEED_TALLNUT)
                {
                    z.mApp->PlayFoley(FoleyType::FOLEY_BONK);
                    aJumpEnds = true;
                    z.mApp->AddTodParticle(aPlant->mX + 60, aPlant->mY - 20, z.mRenderOrder + 1, ParticleEffect::PARTICLE_TALL_NUT_BLOCK);

                    z.mZombieHeight = ZombieHeight::HEIGHT_FALLING;
                    z.mPosX = aPlant->mX + 25.0f;
                    z.mAltitude = 30.0f;
                }
            }
            else if (aBodyReanim->ShouldTriggerTimedEvent(0.49f))
            {
                Reanimation* aSplashReanim = z.mApp->AddReanimation(z.mX - 63, z.mY + 73, z.mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
                aSplashReanim->OverrideScale(1.2f, 0.8f);
                z.mApp->AddTodParticle(z.mX - 26, z.mY + 115, z.mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
                z.mApp->PlayFoley(FoleyType::FOLEY_ZOMBIE_ENTERING_WATER);
                z.mVelX = 0.0f;
            }
            else if (aBodyReanim->mLoopCount > 0)
            {
                aJumpEnds = true;
                z.mPosX -= 94.0f;
                z.mAltitude = 0.0f;
            }

            if (aJumpEnds)
            {
                z.mZombieAttackRect = Rect(30, 0, 30, 115);
                z.mZombieRect = Rect(20, 0, 42, 115);
                z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL;
                z.StartWalkAnim(0);
            }
        },  // PHASE_DOLPHIN_IN_JUMP
        // 原 else-if PHASE_DOLPHIN_WALKING_IN_POOL
        [](Zombie& z)
        {
            bool aBackwards = z.IsWalkingBackwards();
            if ((z.mX <= 10 && !aBackwards) || (z.mX > 680 && aBackwards))
            {
                z.mAltitude = -40.0f;
                z.mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;
                z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING_WITHOUT_DOLPHIN;

                z.PoolSplash(false);
                z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
                z.PickRandomSpeed();
            }
        },  // PHASE_DOLPHIN_WALKING_IN_POOL
        nullptr,  // PHASE_DOLPHIN_WALKING_WITHOUT_DOLPHIN（原无 case）
    };
    static_assert(sizeof(kDolphinPhaseCases) / sizeof(kDolphinPhaseCases[0]) ==
        (int)ZombiePhase::PHASE_DOLPHIN_WALKING_WITHOUT_DOLPHIN - (int)ZombiePhase::PHASE_DOLPHIN_WALKING + 1,
        "kDolphinPhaseCases 槽位须与 ZombiePhase DOLPHIN 段同步");

    const unsigned aPhaseIndex = static_cast<unsigned>(mZombiePhase) - static_cast<unsigned>(ZombiePhase::PHASE_DOLPHIN_WALKING);
    if (aPhaseIndex < sizeof(kDolphinPhaseCases) / sizeof(kDolphinPhaseCases[0]) &&
        kDolphinPhaseCases[aPhaseIndex] != nullptr)
    {
        kDolphinPhaseCases[aPhaseIndex](*this);
    }
}

static Zombie g_z;
static void ResetDolphin(const ZBInput& in)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    // 段前 1 值 .. 段后 1 值
    g_z.mZombiePhase = (ZombiePhase)((int)ZombiePhase::PHASE_DOLPHIN_WALKING + (int)(in.a % 8) - 1);
    g_z.mVelX = ((in.b & 1) ? -1.0f : 1.0f) * (0.3f + (in.b % 11) * 0.05f);
    g_z.mX = (int)(in.b % 780);
    g_z.mY = (int)(in.c % 600);
    g_z.mPosX = (float)(in.b % 780);
    g_z.mPosY = (float)(in.c % 600);
    g_z.mHasHead = (in.c % 12) != 0;
    g_z.mInPool = (in.d & 1) != 0;
    g_z.mZombieHeight = (in.d & 2) ? ZombieHeight::HEIGHT_DRAGGED_UNDER : ZombieHeight::HEIGHT_ZOMBIE_NORMAL;
    g_z.mPhaseCounter = (int)(in.c % (DOLPHIN_JUMP_TIME + 1));
    g_z.mRenderOrder = (int)(in.d % 1000);
    g_z.mAltitude = 5.0f;
    g_z.mRow = (int)(in.a % 5);
    g_z.mBodyReanimID = (ReanimationID)(1 + in.a % 2);
    g_zb_reanimA.mAnimTime = (in.a % 100) / 100.0f;
    g_zb_reanimA.mLoopCount = (int)(in.a % 3);
    g_zb_reanimB.mAnimTime = (in.b % 100) / 100.0f;
    g_zb_reanimB.mLoopCount = (int)(in.b % 3);
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetDolphin(g_zb_inputs[i]);
            g_z.UpdateZombieDolphinRider_A();
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetDolphin(g_zb_inputs[i]);
            g_z.UpdateZombieDolphinRider_B();
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t08_DolphinPhase", passA, passB);
}
