#include "pvz/time/fixed_step_clock.hpp"

#include <GLFW/glfw3.h>
#include <vulkan/vulkan.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <vector>

namespace {

constexpr std::uint32_t kFramesInFlight = 2;

struct SwapchainBundle
{
    VkSwapchainKHR swapchain{VK_NULL_HANDLE};
    VkFormat format{VK_FORMAT_UNDEFINED};
    VkExtent2D extent{};
    std::vector<VkImage> images;
    std::vector<VkImageView> views;
    std::vector<VkFramebuffer> framebuffers;
};

class VulkanShell
{
public:
    VulkanShell(GLFWwindow* window)
        : window_(window)
    {
        create_instance();
        create_surface();
        pick_device();
        create_device();
        create_swapchain();
        create_render_pass();
        create_framebuffers();
        create_command_objects();
        create_sync_objects();
    }

    ~VulkanShell()
    {
        vkDeviceWaitIdle(device_);
        destroy_sync_objects();
        vkDestroyCommandPool(device_, command_pool_, nullptr);
        for (VkFramebuffer framebuffer : swapchain_.framebuffers)
            vkDestroyFramebuffer(device_, framebuffer, nullptr);
        for (VkImageView view : swapchain_.views)
            vkDestroyImageView(device_, view, nullptr);
        vkDestroyRenderPass(device_, render_pass_, nullptr);
        vkDestroySwapchainKHR(device_, swapchain_.swapchain, nullptr);
        vkDestroyDevice(device_, nullptr);
        vkDestroySurfaceKHR(instance_, surface_, nullptr);
        vkDestroyInstance(instance_, nullptr);
    }

    void draw(std::uint64_t tick)
    {
        if (extent_changed())
        {
            recreate_swapchain();
            return;
        }

        vkWaitForFences(device_, 1, &in_flight_fences_[frame_index_], VK_TRUE, UINT64_MAX);

        std::uint32_t image_index = 0;
        VkResult acquire = vkAcquireNextImageKHR(
            device_,
            swapchain_.swapchain,
            UINT64_MAX,
            image_available_[frame_index_],
            VK_NULL_HANDLE,
            &image_index);
        if (acquire == VK_ERROR_OUT_OF_DATE_KHR || acquire == VK_SUBOPTIMAL_KHR)
        {
            recreate_swapchain();
            return;
        }
        if (acquire != VK_SUCCESS)
            throw std::runtime_error("vkAcquireNextImageKHR failed");

        vkResetFences(device_, 1, &in_flight_fences_[frame_index_]);
        vkResetCommandBuffer(command_buffers_[frame_index_], 0);
        record_command_buffer(command_buffers_[frame_index_], image_index, tick);

        VkPipelineStageFlags wait_stage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        submit.waitSemaphoreCount = 1;
        submit.pWaitSemaphores = &image_available_[frame_index_];
        submit.pWaitDstStageMask = &wait_stage;
        submit.commandBufferCount = 1;
        submit.pCommandBuffers = &command_buffers_[frame_index_];
        submit.signalSemaphoreCount = 1;
        submit.pSignalSemaphores = &render_finished_[frame_index_];
        if (vkQueueSubmit(graphics_queue_, 1, &submit, in_flight_fences_[frame_index_]) != VK_SUCCESS)
            throw std::runtime_error("vkQueueSubmit failed");

        VkPresentInfoKHR present{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
        present.waitSemaphoreCount = 1;
        present.pWaitSemaphores = &render_finished_[frame_index_];
        present.swapchainCount = 1;
        present.pSwapchains = &swapchain_.swapchain;
        present.pImageIndices = &image_index;
        VkResult present_result = vkQueuePresentKHR(present_queue_, &present);
        if (present_result == VK_ERROR_OUT_OF_DATE_KHR || present_result == VK_SUBOPTIMAL_KHR)
            recreate_swapchain();
        else if (present_result != VK_SUCCESS)
            throw std::runtime_error("vkQueuePresentKHR failed");

        frame_index_ = (frame_index_ + 1) % kFramesInFlight;
    }

private:
    void create_instance()
    {
        std::uint32_t extension_count = 0;
        const char** extensions = glfwGetRequiredInstanceExtensions(&extension_count);
        if (extensions == nullptr)
            throw std::runtime_error("Vulkan is not available on this GLFW build");

        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        app.pApplicationName = "Modern PvZ Vulkan Shell";
        app.applicationVersion = VK_MAKE_API_VERSION(0, 0, 1, 0);
        app.pEngineName = "ModernPVZ";
        app.apiVersion = VK_API_VERSION_1_0;

        VkInstanceCreateInfo info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        info.pApplicationInfo = &app;
        info.enabledExtensionCount = extension_count;
        info.ppEnabledExtensionNames = extensions;
        if (vkCreateInstance(&info, nullptr, &instance_) != VK_SUCCESS)
            throw std::runtime_error("vkCreateInstance failed");
    }

    void create_surface()
    {
        if (glfwCreateWindowSurface(instance_, window_, nullptr, &surface_) != VK_SUCCESS)
            throw std::runtime_error("glfwCreateWindowSurface failed");
    }

    void pick_device()
    {
        std::uint32_t count = 0;
        vkEnumeratePhysicalDevices(instance_, &count, nullptr);
        std::vector<VkPhysicalDevice> devices(count);
        vkEnumeratePhysicalDevices(instance_, &count, devices.data());
        for (VkPhysicalDevice device : devices)
        {
            VkPhysicalDeviceProperties props{};
            vkGetPhysicalDeviceProperties(device, &props);
            if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU ||
                props.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU)
            {
                physical_device_ = device;
                return;
            }
        }
        if (!devices.empty())
            physical_device_ = devices.front();
        if (physical_device_ == VK_NULL_HANDLE)
            throw std::runtime_error("no Vulkan physical device");
    }

    std::uint32_t graphics_queue_family() const
    {
        std::uint32_t count = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(physical_device_, &count, nullptr);
        std::vector<VkQueueFamilyProperties> families(count);
        vkGetPhysicalDeviceQueueFamilyProperties(physical_device_, &count, families.data());
        for (std::uint32_t i = 0; i < count; ++i)
        {
            if (families[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)
                return i;
        }
        throw std::runtime_error("no graphics queue family");
    }

    void create_device()
    {
        const float priority = 1.0f;
        VkDeviceQueueCreateInfo queue{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        queue.queueFamilyIndex = graphics_queue_family();
        queue.queueCount = 1;
        queue.pQueuePriorities = &priority;

        const char* extension = VK_KHR_SWAPCHAIN_EXTENSION_NAME;
        VkDeviceCreateInfo info{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        info.queueCreateInfoCount = 1;
        info.pQueueCreateInfos = &queue;
        info.enabledExtensionCount = 1;
        info.ppEnabledExtensionNames = &extension;
        if (vkCreateDevice(physical_device_, &info, nullptr, &device_) != VK_SUCCESS)
            throw std::runtime_error("vkCreateDevice failed");
        vkGetDeviceQueue(device_, queue.queueFamilyIndex, 0, &graphics_queue_);
        present_queue_ = graphics_queue_;
    }

    bool extent_changed() const
    {
        int width = 0;
        int height = 0;
        glfwGetFramebufferSize(window_, &width, &height);
        return width <= 0 || height <= 0 ||
            static_cast<std::uint32_t>(width) != swapchain_.extent.width ||
            static_cast<std::uint32_t>(height) != swapchain_.extent.height;
    }

    void create_swapchain()
    {
        VkSurfaceCapabilitiesKHR caps{};
        vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physical_device_, surface_, &caps);
        if (caps.currentExtent.width != UINT32_MAX)
        {
            swapchain_.extent = caps.currentExtent;
        }
        else
        {
            int width = 0;
            int height = 0;
            glfwGetFramebufferSize(window_, &width, &height);
            swapchain_.extent = {
                std::clamp(static_cast<std::uint32_t>(width), caps.minImageExtent.width, caps.maxImageExtent.width),
                std::clamp(static_cast<std::uint32_t>(height), caps.minImageExtent.height, caps.maxImageExtent.height)};
        }

        std::uint32_t format_count = 0;
        vkGetPhysicalDeviceSurfaceFormatsKHR(physical_device_, surface_, &format_count, nullptr);
        std::vector<VkSurfaceFormatKHR> formats(format_count);
        vkGetPhysicalDeviceSurfaceFormatsKHR(physical_device_, surface_, &format_count, formats.data());
        swapchain_.format = formats[0].format;
        for (const auto& format : formats)
        {
            if (format.format == VK_FORMAT_B8G8R8A8_UNORM)
                swapchain_.format = format.format;
        }

        VkSwapchainCreateInfoKHR info{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
        info.surface = surface_;
        info.minImageCount = std::max(2u, caps.minImageCount);
        info.imageFormat = swapchain_.format;
        info.imageColorSpace = formats[0].colorSpace;
        info.imageExtent = swapchain_.extent;
        info.imageArrayLayers = 1;
        info.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        info.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
        info.preTransform = caps.currentTransform;
        info.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        info.presentMode = VK_PRESENT_MODE_FIFO_KHR;
        info.clipped = VK_TRUE;
        if (vkCreateSwapchainKHR(device_, &info, nullptr, &swapchain_.swapchain) != VK_SUCCESS)
            throw std::runtime_error("vkCreateSwapchainKHR failed");

        std::uint32_t image_count = 0;
        vkGetSwapchainImagesKHR(device_, swapchain_.swapchain, &image_count, nullptr);
        swapchain_.images.resize(image_count);
        swapchain_.views.resize(image_count);
        vkGetSwapchainImagesKHR(device_, swapchain_.swapchain, &image_count, swapchain_.images.data());

        for (std::uint32_t i = 0; i < image_count; ++i)
        {
            VkImageViewCreateInfo view{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
            view.image = swapchain_.images[i];
            view.viewType = VK_IMAGE_VIEW_TYPE_2D;
            view.format = swapchain_.format;
            view.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
            if (vkCreateImageView(device_, &view, nullptr, &swapchain_.views[i]) != VK_SUCCESS)
                throw std::runtime_error("vkCreateImageView failed");
        }
    }

    void create_render_pass()
    {
        VkAttachmentDescription attachment{};
        attachment.format = swapchain_.format;
        attachment.samples = VK_SAMPLE_COUNT_1_BIT;
        attachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        attachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        attachment.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        attachment.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;

        VkAttachmentReference color_ref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        VkSubpassDescription subpass{};
        subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
        subpass.colorAttachmentCount = 1;
        subpass.pColorAttachments = &color_ref;

        VkRenderPassCreateInfo info{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
        info.attachmentCount = 1;
        info.pAttachments = &attachment;
        info.subpassCount = 1;
        info.pSubpasses = &subpass;
        if (vkCreateRenderPass(device_, &info, nullptr, &render_pass_) != VK_SUCCESS)
            throw std::runtime_error("vkCreateRenderPass failed");
    }

    void create_framebuffers()
    {
        swapchain_.framebuffers.resize(swapchain_.views.size());
        for (std::size_t i = 0; i < swapchain_.views.size(); ++i)
        {
            VkFramebufferCreateInfo info{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
            info.renderPass = render_pass_;
            info.attachmentCount = 1;
            info.pAttachments = &swapchain_.views[i];
            info.width = swapchain_.extent.width;
            info.height = swapchain_.extent.height;
            info.layers = 1;
            if (vkCreateFramebuffer(device_, &info, nullptr, &swapchain_.framebuffers[i]) != VK_SUCCESS)
                throw std::runtime_error("vkCreateFramebuffer failed");
        }
    }

    void create_command_objects()
    {
        VkCommandPoolCreateInfo pool{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pool.queueFamilyIndex = graphics_queue_family();
        pool.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        if (vkCreateCommandPool(device_, &pool, nullptr, &command_pool_) != VK_SUCCESS)
            throw std::runtime_error("vkCreateCommandPool failed");

        command_buffers_.resize(kFramesInFlight);
        VkCommandBufferAllocateInfo allocate{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        allocate.commandPool = command_pool_;
        allocate.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        allocate.commandBufferCount = kFramesInFlight;
        if (vkAllocateCommandBuffers(device_, &allocate, command_buffers_.data()) != VK_SUCCESS)
            throw std::runtime_error("vkAllocateCommandBuffers failed");
    }

    void create_sync_objects()
    {
        image_available_.resize(kFramesInFlight);
        render_finished_.resize(kFramesInFlight);
        in_flight_fences_.resize(kFramesInFlight);
        VkSemaphoreCreateInfo semaphore{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VkFenceCreateInfo fence{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        fence.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        for (std::uint32_t i = 0; i < kFramesInFlight; ++i)
        {
            vkCreateSemaphore(device_, &semaphore, nullptr, &image_available_[i]);
            vkCreateSemaphore(device_, &semaphore, nullptr, &render_finished_[i]);
            vkCreateFence(device_, &fence, nullptr, &in_flight_fences_[i]);
        }
    }

    void record_command_buffer(VkCommandBuffer buffer, std::uint32_t image_index, std::uint64_t tick)
    {
        VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        vkBeginCommandBuffer(buffer, &begin);

        VkClearValue clear{};
        clear.color = {
            static_cast<float>((tick % 255) / 255.0),
            0.08f,
            0.12f,
            1.0f};

        VkRenderPassBeginInfo pass{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
        pass.renderPass = render_pass_;
        pass.framebuffer = swapchain_.framebuffers[image_index];
        pass.renderArea = {{0, 0}, swapchain_.extent};
        pass.clearValueCount = 1;
        pass.pClearValues = &clear;
        vkCmdBeginRenderPass(buffer, &pass, VK_SUBPASS_CONTENTS_INLINE);
        vkCmdEndRenderPass(buffer);
        vkEndCommandBuffer(buffer);
    }

    void recreate_swapchain()
    {
        vkDeviceWaitIdle(device_);
        for (VkFramebuffer framebuffer : swapchain_.framebuffers)
            vkDestroyFramebuffer(device_, framebuffer, nullptr);
        for (VkImageView view : swapchain_.views)
            vkDestroyImageView(device_, view, nullptr);
        swapchain_.framebuffers.clear();
        swapchain_.views.clear();
        swapchain_.images.clear();
        vkDestroySwapchainKHR(device_, swapchain_.swapchain, nullptr);
        swapchain_.swapchain = VK_NULL_HANDLE;
        create_swapchain();
        create_framebuffers();
    }

    void destroy_sync_objects()
    {
        for (std::uint32_t i = 0; i < kFramesInFlight; ++i)
        {
            vkDestroyFence(device_, in_flight_fences_[i], nullptr);
            vkDestroySemaphore(device_, render_finished_[i], nullptr);
            vkDestroySemaphore(device_, image_available_[i], nullptr);
        }
    }

    GLFWwindow* window_{nullptr};
    VkInstance instance_{VK_NULL_HANDLE};
    VkSurfaceKHR surface_{VK_NULL_HANDLE};
    VkPhysicalDevice physical_device_{VK_NULL_HANDLE};
    VkDevice device_{VK_NULL_HANDLE};
    VkQueue graphics_queue_{VK_NULL_HANDLE};
    VkQueue present_queue_{VK_NULL_HANDLE};
    SwapchainBundle swapchain_;
    VkRenderPass render_pass_{VK_NULL_HANDLE};
    VkCommandPool command_pool_{VK_NULL_HANDLE};
    std::vector<VkCommandBuffer> command_buffers_;
    std::vector<VkSemaphore> image_available_;
    std::vector<VkSemaphore> render_finished_;
    std::vector<VkFence> in_flight_fences_;
    std::uint32_t frame_index_{0};
};

} // namespace

int main()
{
    if (glfwInit() != GLFW_TRUE)
        return 1;
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    GLFWwindow* window = glfwCreateWindow(1068, 600, "Modern PvZ Vulkan Shell", nullptr, nullptr);
    if (window == nullptr)
    {
        glfwTerminate();
        return 1;
    }

    try
    {
        VulkanShell shell(window);
        pvz::time::FixedStepClock clock(
            pvz::time::ClockConfig{
                .simulation_hz = 100,
                .semantic_hz = 100,
                .max_steps_per_advance = 64,
                .max_frame_delta = std::chrono::milliseconds{250},
            });

        auto previous = std::chrono::steady_clock::now();
        while (!glfwWindowShouldClose(window))
        {
            glfwPollEvents();
            const auto now = std::chrono::steady_clock::now();
            const auto elapsed = now - previous;
            previous = now;
            clock.advance(elapsed);
            shell.draw(clock.total_ticks());
        }
    }
    catch (const std::exception& error)
    {
        std::fprintf(stderr, "%s\n", error.what());
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
