
undefined1 __fastcall FUN_0054c740(int param_1)

{
  return *(undefined1 *)(param_1 + 0x95);
}

