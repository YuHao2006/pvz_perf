// Compile as MSVC x86 with /d1reportSingleClassLayout<ClassName> to audit
// the native layouts embedded verbatim in 1.2.0.1073 level saves.
#include "../Lawn/Board.h"
#include "../Lawn/Challenge.h"
#include "../Lawn/CursorObject.h"
#include "../Lawn/MessageWidget.h"
#include "../Lawn/SeedPacket.h"
#include "../Lawn/System/Music.h"
#include "../Sexy.TodLib/Attachment.h"
#include "../Sexy.TodLib/Reanimator.h"
#include "../Sexy.TodLib/TodParticle.h"
#include "../Sexy.TodLib/Trail.h"

int main()
{
	return 0;
}
