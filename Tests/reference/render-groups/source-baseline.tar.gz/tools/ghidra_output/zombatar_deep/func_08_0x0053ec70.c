
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053ec70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 unaff_EBX;
  int *unaff_EDI;
  undefined4 uVar5;
  undefined1 local_a4 [12];
  float local_98;
  float local_8c;
  undefined1 local_88 [8];
  float local_80;
  float local_7c;
  void *local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006ca96b;
  local_c = ExceptionList;
  if ((unaff_EDI[0x19] != 9) &&
     ((ExceptionList = &local_c, FUN_0053e350(), *(int *)(*unaff_EDI + 0x91c) != 4 ||
      (cVar1 = FUN_00544a70(), cVar1 != '\0')))) {
    if (0 < unaff_EDI[0x2d]) {
      FUN_0053e990(0);
    }
    if ((*(int *)(*unaff_EDI + 0x918) != 0x15) || (unaff_EDI[0x1b] == -3)) {
      if (unaff_EDI[0x46] == 0) {
        FUN_0053c760(unaff_EBX,local_a4);
      }
      else {
        FUN_0053d950(unaff_EBX,local_a4,0);
      }
    }
    if (0 < unaff_EDI[0x2d]) {
      FUN_0053e990(1);
    }
    if (0 < unaff_EDI[0x2c]) {
      FUN_0053ead0(unaff_EBX);
    }
    if (unaff_EDI[0x44] != 0) {
      FUN_00597fa0(unaff_EBX);
      local_4 = 0;
      local_80 = local_80 - (float)unaff_EDI[2];
      local_7c = (local_7c - (float)unaff_EDI[3]) + local_98;
      if ((float)_DAT_006fdc70 < local_8c) {
        uVar2 = FUN_006ba960();
        uVar5 = 0x398;
        uVar3 = FUN_006ba960(0x398,uVar2);
        uVar4 = FUN_006ba960(uVar3);
        FUN_005994c0(uVar4,uVar3,uVar5,uVar2);
      }
      FUN_00406000(local_88,0);
      FUN_005981a0();
    }
    FUN_005993a0();
  }
  ExceptionList = local_c;
  return;
}

