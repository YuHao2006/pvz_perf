
void __thiscall FUN_0054c700(int *param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*param_1 + 0xa0))(param_2,param_3,param_1[0x12],param_1[0x13]);
  return;
}

