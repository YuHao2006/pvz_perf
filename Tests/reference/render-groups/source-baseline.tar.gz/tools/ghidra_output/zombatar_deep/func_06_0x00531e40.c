
void __thiscall FUN_00531e40(int *param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_00549210(param_2);
  iVar1 = param_1[0x62];
  if (iVar1 != 0) {
    FUN_005422f0();
    FUN_00699e4a(iVar1);
    param_1[0x62] = 0;
  }
  if (param_1[0x65] != 0) {
    (**(code **)(*param_1 + 0x10))(param_1[0x65]);
  }
  return;
}

