// bench_t06 — kSnorkelPhaseCases 6 -> UpdateZombieSnorkel（游泳期每帧）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::UpdateZombieSnorkel_A()
{
    bool aBackwards = IsWalkingBackwards();
    if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING && !aBackwards)
    {
        if (mX > 700 && mX <= 720)
        {
            mVelX = 0.2f;
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_INTO_POOL;
            PlayZombieReanim(ReanimTrackId::anim_jumpinpool, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 16.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_INTO_POOL)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        mAltitude = TodAnimateCurveFloat(0, 1000, aBodyReanim->mAnimTime * 1000, 0.0f, 10.0f, Curves::Linear);

        if (aBodyReanim->ShouldTriggerTimedEvent(0.83f))
        {
            Reanimation* aSplashReanim = mApp->AddReanimation(mX - 47, mY + 73, mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
            aSplashReanim->OverrideScale(1.2f, 0.8f);
            mApp->AddTodParticle(mX - 10, mY + 115, mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
            mApp->PlayFoley(FoleyType::FOLEY_ZOMBIE_ENTERING_WATER);
        }

        if (aBodyReanim->mLoopCount > 0)
        {
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL;
            mInPool = true;
            PlayZombieReanim(ReanimTrackId::anim_swim, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL)
    {
        if (!mHasHead)
        {
            TakeDamage(1800, 9U);
        }
        else if (mX <= 25 && !aBackwards)
        {
            mAltitude = -90.0f;
            mPosX -= 15.0f;
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
            mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;

            PoolSplash(false);
            StartWalkAnim(0);
        }
        else if (mX > 640 && aBackwards)
        {
            mAltitude = -90.0f;
            mPosX += 15.0f;
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
            mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;

            PoolSplash(false);
            StartWalkAnim(0);
        }
        else if (mIsEating)
        {
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_UP_TO_EAT;
            PlayZombieReanim(ReanimTrackId::anim_uptoeat, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 24.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_UP_TO_EAT)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (!mIsEating)
        {
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT;
            PlayZombieReanim(ReanimTrackId::anim_uptoeat, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, -24.0f);
        }
        else if (aBodyReanim->mLoopCount > 0)
        {
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_EATING_IN_POOL;
            PlayZombieReanim(ReanimTrackId::anim_eat, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_EATING_IN_POOL)
    {
        if (!mIsEating)
        {
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT;
            PlayZombieReanim(ReanimTrackId::anim_uptoeat, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, -24.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aBodyReanim->mLoopCount > 0)
        {
            mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL;
            PlayZombieReanim(ReanimTrackId::anim_swim, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 0.0f);
            PickRandomSpeed();
        }
    }
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::UpdateZombieSnorkel_B()
{
    // C 形态 -> 匿名 lambda 函数指针表 kSnorkelPhaseCases（仿 kBossPhaseCases
    // 范式）：行序 = ZombiePhase 枚举序 PHASE_SNORKEL_WALKING..
    // PHASE_SNORKEL_DOWN_FROM_EAT（6 相位连续，全覆盖无空槽）。原链首支的
    // !aBackwards 判别与第三支的 aBackwards 判别移入对应 lambda
    //（IsWalkingBackwards() 纯查询，分发前后无状态突变，取值等价）。
    using SnorkelPhaseFn = void (*)(Zombie&);
    static constexpr SnorkelPhaseFn kSnorkelPhaseCases[(int)ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT - (int)ZombiePhase::PHASE_SNORKEL_WALKING + 1] = {
        // 原 if PHASE_SNORKEL_WALKING && !aBackwards
        [](Zombie& z)
        {
            if (!z.IsWalkingBackwards())
            {
                if (z.mX > 700 && z.mX <= 720)
                {
                    z.mVelX = 0.2f;
                    z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_INTO_POOL;
                    z.PlayZombieReanim(ReanimTrackId::anim_jumpinpool, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 16.0f);
                }
            }
        },  // PHASE_SNORKEL_WALKING
        // 原 else-if PHASE_SNORKEL_INTO_POOL
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            z.mAltitude = TodAnimateCurveFloat(0, 1000, aBodyReanim->mAnimTime * 1000, 0.0f, 10.0f, Curves::Linear);

            if (aBodyReanim->ShouldTriggerTimedEvent(0.83f))
            {
                Reanimation* aSplashReanim = z.mApp->AddReanimation(z.mX - 47, z.mY + 73, z.mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
                aSplashReanim->OverrideScale(1.2f, 0.8f);
                z.mApp->AddTodParticle(z.mX - 10, z.mY + 115, z.mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
                z.mApp->PlayFoley(FoleyType::FOLEY_ZOMBIE_ENTERING_WATER);
            }

            if (aBodyReanim->mLoopCount > 0)
            {
                z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL;
                z.mInPool = true;
                z.PlayZombieReanim(ReanimTrackId::anim_swim, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
            }
        },  // PHASE_SNORKEL_INTO_POOL
        // 原 else-if PHASE_SNORKEL_WALKING_IN_POOL
        [](Zombie& z)
        {
            if (!z.mHasHead)
            {
                z.TakeDamage(1800, 9U);
            }
            else
            {
                bool aBackwards = z.IsWalkingBackwards();
                if (z.mX <= 25 && !aBackwards)
                {
                    z.mAltitude = -90.0f;
                    z.mPosX -= 15.0f;
                    z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
                    z.mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;

                    z.PoolSplash(false);
                    z.StartWalkAnim(0);
                }
                else if (z.mX > 640 && aBackwards)
                {
                    z.mAltitude = -90.0f;
                    z.mPosX += 15.0f;
                    z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
                    z.mZombieHeight = ZombieHeight::HEIGHT_OUT_OF_POOL;

                    z.PoolSplash(false);
                    z.StartWalkAnim(0);
                }
                else if (z.mIsEating)
                {
                    z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_UP_TO_EAT;
                    z.PlayZombieReanim(ReanimTrackId::anim_uptoeat, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 24.0f);
                }
            }
        },  // PHASE_SNORKEL_WALKING_IN_POOL
        // 原 else-if PHASE_SNORKEL_UP_TO_EAT
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (!z.mIsEating)
            {
                z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT;
                z.PlayZombieReanim(ReanimTrackId::anim_uptoeat, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, -24.0f);
            }
            else if (aBodyReanim->mLoopCount > 0)
            {
                z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_EATING_IN_POOL;
                z.PlayZombieReanim(ReanimTrackId::anim_eat, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
            }
        },  // PHASE_SNORKEL_UP_TO_EAT
        // 原 else-if PHASE_SNORKEL_EATING_IN_POOL
        [](Zombie& z)
        {
            if (!z.mIsEating)
            {
                z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT;
                z.PlayZombieReanim(ReanimTrackId::anim_uptoeat, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, -24.0f);
            }
        },  // PHASE_SNORKEL_EATING_IN_POOL
        // 原 else-if PHASE_SNORKEL_DOWN_FROM_EAT
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (aBodyReanim->mLoopCount > 0)
            {
                z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING_IN_POOL;
                z.PlayZombieReanim(ReanimTrackId::anim_swim, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 0.0f);
                z.PickRandomSpeed();
            }
        },  // PHASE_SNORKEL_DOWN_FROM_EAT
    };
    static_assert(sizeof(kSnorkelPhaseCases) / sizeof(kSnorkelPhaseCases[0]) ==
        (int)ZombiePhase::PHASE_SNORKEL_DOWN_FROM_EAT - (int)ZombiePhase::PHASE_SNORKEL_WALKING + 1,
        "kSnorkelPhaseCases 槽位须与 ZombiePhase SNORKEL 段同步");

    const unsigned aPhaseIndex = static_cast<unsigned>(mZombiePhase) - static_cast<unsigned>(ZombiePhase::PHASE_SNORKEL_WALKING);
    if (aPhaseIndex < sizeof(kSnorkelPhaseCases) / sizeof(kSnorkelPhaseCases[0]))
    {
        kSnorkelPhaseCases[aPhaseIndex](*this);
    }
}

static Zombie g_z;
static void ResetSnorkel(const ZBInput& in)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    // 段前 1 值 .. 段后 1 值（越界走无操作）
    g_z.mZombiePhase = (ZombiePhase)((int)ZombiePhase::PHASE_SNORKEL_WALKING + (int)(in.a % 8) - 1);
    g_z.mVelX = ((in.b & 1) ? -1.0f : 1.0f) * (0.3f + (in.b % 13) * 0.05f);
    g_z.mX = (int)(in.b % 780);
    g_z.mY = (int)(in.c % 600);
    g_z.mHasHead = (in.c % 12) != 0;
    g_z.mIsEating = (in.d & 2) != 0;
    g_z.mInPool = (in.d & 1) != 0;
    g_z.mZombieHeight = ZombieHeight::HEIGHT_ZOMBIE_NORMAL;
    g_z.mRenderOrder = (int)(in.d % 1000);
    g_z.mPosX = (float)(in.b % 780);
    g_z.mAltitude = 0.0f;
    g_z.mBodyReanimID = (ReanimationID)(1 + in.a % 2);
    g_zb_reanimA.mAnimTime = (in.a % 100) / 100.0f;
    g_zb_reanimA.mLoopCount = (int)(in.a % 3);
    g_zb_reanimB.mAnimTime = (in.b % 100) / 100.0f;
    g_zb_reanimB.mLoopCount = (int)(in.b % 3);
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetSnorkel(g_zb_inputs[i]);
            g_z.UpdateZombieSnorkel_A();
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetSnorkel(g_zb_inputs[i]);
            g_z.UpdateZombieSnorkel_B();
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t06_SnorkelPhase", passA, passB);
}
