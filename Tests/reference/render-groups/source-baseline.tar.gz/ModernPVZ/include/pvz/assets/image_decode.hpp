#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

namespace pvz::assets {

enum class ImageColorSpace {
    linear,
    srgb,
};

struct DecodedImage {
    std::uint32_t width{0};
    std::uint32_t height{0};
    std::uint32_t row_pitch_bytes{0};
    ImageColorSpace color_space{ImageColorSpace::srgb};
    std::vector<std::byte> rgba8;
};

[[nodiscard]] DecodedImage decode_image_rgba8(
    std::span<const std::uint8_t> encoded,
    ImageColorSpace color_space = ImageColorSpace::srgb);

} // namespace pvz::assets
