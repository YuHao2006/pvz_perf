#pragma once

#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace Sexy
{

// User PARAMETER values supplied by scale.xml.  When an effect is compiled,
// these values are resolved against the MagpieFX defaults and emitted as HLSL
// static constants (Magpie's InlineParams mode).
typedef std::map<std::string, float> ScaleEffectParams;

struct ScaleEffectParamDesc
{
	std::string	mName;
	bool		mIsInt = false;
	float		mDefault = 0.0f;
	float		mMin = 0.0f;
	float		mMax = 0.0f;
	float		mStep = 0.0f;
};

struct ScaleEffectTextureDesc
{
	std::string	mName;
	std::string	mWidthExpr;
	std::string	mHeightExpr;
	std::string	mFormat;
};

struct ScaleEffectSamplerDesc
{
	std::string	mName;
	std::string	mFilter;
	std::string	mAddress;
};

struct ScaleEffectPassDesc
{
	int						mIndex;
	std::string				mDesc;
	bool					mPSStyle;
	std::vector<std::string> mInputs;
	std::vector<std::string> mOutputs;
	int						mBlockWidth;
	int						mBlockHeight;
	int						mNumThreadsX;
	int						mNumThreadsY;
	int						mNumThreadsZ;
	std::string				mCode;
};

struct ScaleEffectDesc
{
	std::string							mName;		// "Anime4K/Anime4K_Upscale_L" (relative, no .hlsl)
	std::string							mSourcePath; // "effects/Anime4K/Anime4K_Upscale_L.hlsl"
	std::vector<ScaleEffectParamDesc>	mParams;
	std::vector<ScaleEffectTextureDesc>	mTextures;
	std::vector<ScaleEffectSamplerDesc>	mSamplers;
	std::vector<std::string>			mCommonBlocks;
	std::vector<ScaleEffectPassDesc>	mPasses;
	std::vector<std::vector<uint8_t>>	mCompiledCSOs;	// per pass, cs_5_0 bytecode
	// Canonical, complete PARAMETER set embedded into mCompiledCSOs.  It
	// includes defaults for values omitted from scale.xml and uses the exact
	// declaration names from the effect source.
	ScaleEffectParams					mInlineParams;
	bool								mInlineParamsEnabled = false;
	bool								mCompiled = false;
	std::string							mError;
};

// MagpieFX (Magpie v4 format) compiler: scans effects/*.hlsl, parses the
// //!MAGPIE EFFECT metadata blocks, generates one cs_5_0 compute shader per
// PASS and compiles it with D3DCompile.  PARAMETER values use Magpie's
// InlineParams semantics: they become HLSL static constants rather than
// runtime constant-buffer members. Logs to effects-compile.log.
class ScaleEffectCompiler
{
public:
	// Scans theEffectsDir ("effects") for *.hlsl, parses and compiles each.
	// Returns false if any referenced/available effect failed to compile.
	bool CompileAll(const std::string& theEffectsDir, std::vector<ScaleEffectDesc>& outEffects);

	// Parse + compile a single effect file (thePath is relative to cwd, e.g.
	// "effects/Anime4K/Anime4K_Upscale_L.hlsl").
	bool CompileEffect(const std::string& thePath, ScaleEffectDesc& outDesc);
	bool CompileEffect(
		const std::string& thePath,
		const ScaleEffectParams& theInlineParams,
		ScaleEffectDesc& outDesc);

	// Resolve case-insensitive overrides, validate names/ranges and round int
	// parameters exactly once before shader generation.  Exposed so the app can
	// select the compiled variant belonging to each scale.xml pipeline entry.
	static bool ResolveInlineParams(
		const ScaleEffectDesc& theDesc,
		const ScaleEffectParams& theOverrides,
		ScaleEffectParams& outResolved,
		std::string& outError);

private:
	bool ParseEffect(const std::string& thePath, ScaleEffectDesc& ioDesc);
	bool GenerateAndCompilePasses(ScaleEffectDesc& ioDesc);
};

}
