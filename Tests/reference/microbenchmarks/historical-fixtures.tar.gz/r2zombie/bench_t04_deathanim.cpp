// bench_t04 — kDeathAnimRateCases 34 -> Zombie::PlayDeathAnim（死亡期一次）
#include "zb_common.h"
#define TOD_ASSERT(x) ((void)0)

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::PlayDeathAnim_A(unsigned int theDamageFlags)
{
    if (mZombiePhase == ZombiePhase::PHASE_ZOMBIE_DYING || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_BURNED || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED)
        return;

    Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
    if (aBodyReanim == nullptr || !aBodyReanim->TrackExists(ReanimTrackId::anim_death))
    {
        DieNoLoot();
        return;
    }
    if (mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER && mZombiePhase != ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL)
    {
        DieNoLoot();
        return;
    }
    if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_INTO_POOL || mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING)
    {
        DieNoLoot();
        return;
    }

    if (mIceTrapCounter > 0)
    {
        AddAttachedParticle(75, 106, ParticleEffect::PARTICLE_ICE_TRAP_RELEASE);
        mIceTrapCounter = 0;
    }
    if (mButteredCounter > 0)
    {
        mButteredCounter = 0;
    }
    if (mYuckyFace)
    {
        ShowYuckyFace(false);
        mYuckyFace = false;
        mYuckyFaceCounter = 0;
    }

    if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_LEAVE_BODY))
    {
        if (mZombieType != ZombieType::ZOMBIE_BOSS && mZombieType != ZombieType::ZOMBIE_GARGANTUAR && mZombieType != ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
        {
            DieNoLoot();
            return;
        }
    }

    if (mZombieType == ZombieType::ZOMBIE_POGO)
    {
        mAltitude = 0.0f;
    }

    AttachmentReanimTypeDie(mAttachmentID, ReanimationType::REANIM_ZOMBIE_SURPRISE);
    StopEating();

    if (mShieldType != ShieldType::SHIELDTYPE_NONE)
    {
        DropShield(1U);
    }
    if (mZombieType == ZombieType::ZOMBIE_SQUASH_HEAD && !mHasHead)
    {
        mApp->RemoveReanimation(mSpecialHeadReanimID);
        mSpecialHeadReanimID = ReanimationID::REANIMATIONID_NULL;
    }

    mVelX = 0.0f;
    mZombiePhase = ZombiePhase::PHASE_ZOMBIE_DYING;
    if (mZombieHeight == ZombieHeight::HEIGHT_ZOMBIQUARIUM)
    {
        PlayZombieReanim(ReanimTrackId::anim_aquarium_death, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 14.0f);
        return;
    }
    if (mZombieHeight == ZombieHeight::HEIGHT_UP_LADDER)
    {
        mZombieHeight = ZombieHeight::HEIGHT_FALLING;
    }

    float aDeathAnimRate;
    if (mZombieType == ZombieType::ZOMBIE_FOOTBALL)
    {
        aDeathAnimRate = 24.0f;
    }
    else if (mZombieType == ZombieType::ZOMBIE_GARGANTUAR || mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
    {
        aDeathAnimRate = 14.0f;
        mApp->PlayFoley(FoleyType::FOLEY_GARGANTUDEATH);
    }
    else if (mZombieType == ZombieType::ZOMBIE_SNORKEL)
    {
        aDeathAnimRate = 14.0f;
    }
    else if (mZombieType == ZombieType::ZOMBIE_DIGGER)
    {
        aDeathAnimRate = 18.0f;
    }
    else if (mZombieType == ZombieType::ZOMBIE_YETI)
    {
        aDeathAnimRate = 14.0f;
    }
    else if (mZombieType == ZombieType::ZOMBIE_BOSS)
    {
        aDeathAnimRate = 18.0f;

        BossDie();
        Reanimation* aHeadReanim = mApp->ReanimationGet(mSpecialHeadReanimID);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_death, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, aDeathAnimRate);
    }
    else
    {
        aDeathAnimRate = RandRangeFloat(24.0f, 30.0f);
    }

    ReanimTrackId aDeathTrackName = ReanimTrackId::anim_death;
    int aDeathAnimHit = Rand(100);
    bool aCanDoSuperLongDeath = mApp->HasFinishedAdventure() || mBoard->mLevel > 5;
    if (mInPool && aBodyReanim->TrackExists(ReanimTrackId::anim_waterdeath))
    {
        aDeathTrackName = ReanimTrackId::anim_waterdeath;
        ReanimIgnoreClipRect(ReanimTrackId::Zombie_duckytube, false);
    }
    else if (aDeathAnimHit == 99 && aBodyReanim->TrackExists(ReanimTrackId::anim_superlongdeath) && aCanDoSuperLongDeath && mChilledCounter == 0 && mBoard->CountZombiesOnScreen() <= 5)
    {
        aDeathAnimRate = 14.0f;
        aDeathTrackName = ReanimTrackId::anim_superlongdeath;
    }
    else if (aDeathAnimHit > 50 && aBodyReanim->TrackExists(ReanimTrackId::anim_death2))
    {
        aDeathTrackName = ReanimTrackId::anim_death2;
    }

    PlayZombieReanim(aDeathTrackName, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, aDeathAnimRate);
    ReanimShowRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_HIDDEN);
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::PlayDeathAnim_B(unsigned int theDamageFlags)
{
    if (mZombiePhase == ZombiePhase::PHASE_ZOMBIE_DYING || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_BURNED || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED)
        return;

    Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
    if (aBodyReanim == nullptr || !aBodyReanim->TrackExists(ReanimTrackId::anim_death))
    {
        DieNoLoot();
        return;
    }
    if (mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER && mZombiePhase != ZombiePhase::PHASE_DOLPHIN_WALKING_IN_POOL)
    {
        DieNoLoot();
        return;
    }
    if (mZombiePhase == ZombiePhase::PHASE_SNORKEL_INTO_POOL || mZombiePhase == ZombiePhase::PHASE_SNORKEL_WALKING)
    {
        DieNoLoot();
        return;
    }

    if (mIceTrapCounter > 0)
    {
        AddAttachedParticle(75, 106, ParticleEffect::PARTICLE_ICE_TRAP_RELEASE);
        mIceTrapCounter = 0;
    }
    if (mButteredCounter > 0)
    {
        mButteredCounter = 0;
    }
    if (mYuckyFace)
    {
        ShowYuckyFace(false);
        mYuckyFace = false;
        mYuckyFaceCounter = 0;
    }

    if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_LEAVE_BODY))
    {
        if (mZombieType != ZombieType::ZOMBIE_BOSS && mZombieType != ZombieType::ZOMBIE_GARGANTUAR && mZombieType != ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
        {
            DieNoLoot();
            return;
        }
    }

    if (mZombieType == ZombieType::ZOMBIE_POGO)
    {
        mAltitude = 0.0f;
    }

    AttachmentReanimTypeDie(mAttachmentID, ReanimationType::REANIM_ZOMBIE_SURPRISE);
    StopEating();

    if (mShieldType != ShieldType::SHIELDTYPE_NONE)
    {
        DropShield(1U);
    }
    if (mZombieType == ZombieType::ZOMBIE_SQUASH_HEAD && !mHasHead)
    {
        mApp->RemoveReanimation(mSpecialHeadReanimID);
        mSpecialHeadReanimID = ReanimationID::REANIMATIONID_NULL;
    }

    mVelX = 0.0f;
    mZombiePhase = ZombiePhase::PHASE_ZOMBIE_DYING;
    if (mZombieHeight == ZombieHeight::HEIGHT_ZOMBIQUARIUM)
    {
        PlayZombieReanim(ReanimTrackId::anim_aquarium_death, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 14.0f);
        return;
    }
    if (mZombieHeight == ZombieHeight::HEIGHT_UP_LADDER)
    {
        mZombieHeight = ZombieHeight::HEIGHT_FALLING;
    }

    // C 形态 -> 匿名 lambda 函数指针表 kDeathAnimRateCases（仿 kIceTrapAdjusts
    // 范式）：行序 = ZombieType 枚举序 0..33；无 case 槽 = 原 else 支（随机
    // 死亡速率，constexpr 指针变量填满）。GARGANTUAR/REDEYE 共体（速率 14 +
    // 巨人死亡音效）。速率经 float& 出参回写。
    using DeathAnimRateFn = void (*)(Zombie&, float&);
    static constexpr DeathAnimRateFn kDeathAnimRateRandom = [](Zombie& z, float& theRate)
    {
        theRate = RandRangeFloat(24.0f, 30.0f);
    };
    static constexpr DeathAnimRateFn kDeathAnimRateGargantuar = [](Zombie& z, float& theRate)
    {
        theRate = 14.0f;
        z.mApp->PlayFoley(FoleyType::FOLEY_GARGANTUDEATH);
    };
    static constexpr DeathAnimRateFn kDeathAnimRateCases[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
        kDeathAnimRateRandom,  // 0 ZOMBIE_NORMAL（原 else）
        kDeathAnimRateRandom,  // 1 ZOMBIE_FLAG（原 else）
        kDeathAnimRateRandom,  // 2 ZOMBIE_TRAFFIC_CONE（原 else）
        kDeathAnimRateRandom,  // 3 ZOMBIE_POLEVAULTER（原 else）
        kDeathAnimRateRandom,  // 4 ZOMBIE_PAIL（原 else）
        kDeathAnimRateRandom,  // 5 ZOMBIE_NEWSPAPER（原 else）
        kDeathAnimRateRandom,  // 6 ZOMBIE_DOOR（原 else）
        // 原 if ZOMBIE_FOOTBALL
        [](Zombie& z, float& theRate) { theRate = 24.0f; },  // 7 ZOMBIE_FOOTBALL
        kDeathAnimRateRandom,  // 8 ZOMBIE_DANCER（原 else）
        kDeathAnimRateRandom,  // 9 ZOMBIE_BACKUP_DANCER（原 else）
        kDeathAnimRateRandom,  // 10 ZOMBIE_DUCKY_TUBE（原 else）
        [](Zombie& z, float& theRate) { theRate = 14.0f; },  // 11 ZOMBIE_SNORKEL
        kDeathAnimRateRandom,  // 12 ZOMBIE_ZAMBONI（原 else）
        kDeathAnimRateRandom,  // 13 ZOMBIE_BOBSLED（原 else）
        kDeathAnimRateRandom,  // 14 ZOMBIE_DOLPHIN_RIDER（原 else）
        kDeathAnimRateRandom,  // 15 ZOMBIE_JACK_IN_THE_BOX（原 else）
        kDeathAnimRateRandom,  // 16 ZOMBIE_BALLOON（原 else）
        [](Zombie& z, float& theRate) { theRate = 18.0f; },  // 17 ZOMBIE_DIGGER
        kDeathAnimRateRandom,  // 18 ZOMBIE_POGO（原 else）
        [](Zombie& z, float& theRate) { theRate = 14.0f; },  // 19 ZOMBIE_YETI
        kDeathAnimRateRandom,  // 20 ZOMBIE_BUNGEE（原 else）
        kDeathAnimRateRandom,  // 21 ZOMBIE_LADDER（原 else）
        kDeathAnimRateRandom,  // 22 ZOMBIE_CATAPULT（原 else）
        kDeathAnimRateGargantuar,  // 23 ZOMBIE_GARGANTUAR（共体）
        kDeathAnimRateRandom,  // 24 ZOMBIE_IMP（原 else）
        // 原 else-if ZOMBIE_BOSS
        [](Zombie& z, float& theRate)
        {
            theRate = 18.0f;

            z.BossDie();
            Reanimation* aHeadReanim = z.mApp->ReanimationGet(z.mSpecialHeadReanimID);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_death, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, theRate);
        },  // 25 ZOMBIE_BOSS
        kDeathAnimRateRandom,  // 26 ZOMBIE_PEA_HEAD（原 else）
        kDeathAnimRateRandom,  // 27 ZOMBIE_WALLNUT_HEAD（原 else）
        kDeathAnimRateRandom,  // 28 ZOMBIE_JALAPENO_HEAD（原 else）
        kDeathAnimRateRandom,  // 29 ZOMBIE_GATLING_HEAD（原 else）
        kDeathAnimRateRandom,  // 30 ZOMBIE_SQUASH_HEAD（原 else）
        kDeathAnimRateRandom,  // 31 ZOMBIE_TALLNUT_HEAD（原 else）
        kDeathAnimRateGargantuar,  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
        kDeathAnimRateRandom,  // 33 ZOMBIE_ZOMBATAR（原 else）
    };
    static_assert(sizeof(kDeathAnimRateCases) / sizeof(kDeathAnimRateCases[0]) ==
        (int)ZombieType::NUM_ZOMBIE_TYPES, "kDeathAnimRateCases 槽位须与 ZombieType 枚举同步");

    float aDeathAnimRate = 0.0f;
    const unsigned aTypeIndex = static_cast<unsigned>(mZombieType);
    if (aTypeIndex < sizeof(kDeathAnimRateCases) / sizeof(kDeathAnimRateCases[0]))
    {
        kDeathAnimRateCases[aTypeIndex](*this, aDeathAnimRate);
    }
    else
    {
        aDeathAnimRate = RandRangeFloat(24.0f, 30.0f);  // 原 else 支（哨兵越界等价）
    }

    ReanimTrackId aDeathTrackName = ReanimTrackId::anim_death;
    int aDeathAnimHit = Rand(100);
    bool aCanDoSuperLongDeath = mApp->HasFinishedAdventure() || mBoard->mLevel > 5;
    if (mInPool && aBodyReanim->TrackExists(ReanimTrackId::anim_waterdeath))
    {
        aDeathTrackName = ReanimTrackId::anim_waterdeath;
        ReanimIgnoreClipRect(ReanimTrackId::Zombie_duckytube, false);
    }
    else if (aDeathAnimHit == 99 && aBodyReanim->TrackExists(ReanimTrackId::anim_superlongdeath) && aCanDoSuperLongDeath && mChilledCounter == 0 && mBoard->CountZombiesOnScreen() <= 5)
    {
        aDeathAnimRate = 14.0f;
        aDeathTrackName = ReanimTrackId::anim_superlongdeath;
    }
    else if (aDeathAnimHit > 50 && aBodyReanim->TrackExists(ReanimTrackId::anim_death2))
    {
        aDeathTrackName = ReanimTrackId::anim_death2;
    }

    PlayZombieReanim(aDeathTrackName, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, aDeathAnimRate);
    ReanimShowRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_HIDDEN);
}

static Zombie g_z;
static void ResetDeath(const ZBInput& in, unsigned& flags)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    g_z.mZombieType = (ZombieType)(in.a % 34);
    // 相位避开 DYING/BURNED/MOWERED/SNORKEL 两早退（专门取正常带相位段）
    g_z.mZombiePhase = (ZombiePhase)(4 + in.b % 12);
    g_z.mZombieHeight = (ZombieHeight)(in.c % 9);
    g_z.mIceTrapCounter = (int)(in.c % 4) - 1;
    g_z.mButteredCounter = (int)(in.a % 4) - 1;
    g_z.mYuckyFace = (in.b % 5) == 0;
    g_z.mYuckyFaceCounter = g_z.mYuckyFace ? 3 : 0;
    g_z.mShieldType = (ShieldType)(in.d % 4);
    g_z.mHasHead = (in.c % 16) != 0;
    g_z.mInPool = (in.d & 1) != 0;
    g_z.mChilledCounter = (int)(in.b % 3);
    g_z.mAltitude = 1.0f;
    g_z.mVelX = 0.5f;
    g_z.mBodyReanimID = (in.b % 9 == 0) ? (ReanimationID)0 : (ReanimationID)(1 + in.b % 2);
    g_z.mSpecialHeadReanimID = (ReanimationID)(1 + in.a % 2);
    g_z.mBoard->mLevel = (int)(in.a % 14);
    flags = (in.d & (1u << 4)) ? 0u : 1u;
    g_z.mApp->mBoard = g_z.mBoard;
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            unsigned fl;
            ResetDeath(g_zb_inputs[i], fl);
            g_z.PlayDeathAnim_A(fl);
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            unsigned fl;
            ResetDeath(g_zb_inputs[i], fl);
            g_z.PlayDeathAnim_B(fl);
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t04_PlayDeathAnim", passA, passB);
}
