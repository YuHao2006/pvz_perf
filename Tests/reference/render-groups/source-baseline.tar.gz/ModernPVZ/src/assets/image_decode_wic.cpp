#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <wincodec.h>
#include <wrl/client.h>

#include "pvz/assets/image_decode.hpp"

#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string>

namespace pvz::assets {
namespace {

using Microsoft::WRL::ComPtr;

void check(const HRESULT result, const char* operation)
{
    if (FAILED(result))
        throw std::runtime_error(std::string(operation) + " failed with HRESULT " + std::to_string(result));
}

class ComApartment {
public:
    ComApartment()
    {
        result_ = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        if (FAILED(result_) && result_ != RPC_E_CHANGED_MODE)
            check(result_, "CoInitializeEx");
    }

    ~ComApartment()
    {
        if (result_ == S_OK || result_ == S_FALSE)
            CoUninitialize();
    }

private:
    HRESULT result_{E_FAIL};
};

[[nodiscard]] ComPtr<IWICImagingFactory> create_factory()
{
    ComPtr<IWICImagingFactory> factory;
    HRESULT result = CoCreateInstance(
        CLSID_WICImagingFactory2,
        nullptr,
        CLSCTX_INPROC_SERVER,
        IID_PPV_ARGS(&factory));
    if (FAILED(result)) {
        result = CoCreateInstance(
            CLSID_WICImagingFactory,
            nullptr,
            CLSCTX_INPROC_SERVER,
            IID_PPV_ARGS(&factory));
    }
    check(result, "CoCreateInstance(WIC factory)");
    return factory;
}

} // namespace

DecodedImage decode_image_rgba8(
    const std::span<const std::uint8_t> encoded,
    const ImageColorSpace color_space)
{
    if (encoded.empty())
        throw std::invalid_argument("encoded image is empty");
    if (encoded.size() > std::numeric_limits<DWORD>::max())
        throw std::length_error("encoded image exceeds the WIC memory-stream limit");

    const ComApartment apartment;
    const auto factory = create_factory();

    ComPtr<IWICStream> stream;
    check(factory->CreateStream(&stream), "IWICImagingFactory::CreateStream");
    check(stream->InitializeFromMemory(
              const_cast<BYTE*>(reinterpret_cast<const BYTE*>(encoded.data())),
              static_cast<DWORD>(encoded.size())),
          "IWICStream::InitializeFromMemory");

    ComPtr<IWICBitmapDecoder> decoder;
    check(factory->CreateDecoderFromStream(
              stream.Get(),
              nullptr,
              WICDecodeMetadataCacheOnLoad,
              &decoder),
          "IWICImagingFactory::CreateDecoderFromStream");

    ComPtr<IWICBitmapFrameDecode> frame;
    check(decoder->GetFrame(0, &frame), "IWICBitmapDecoder::GetFrame");
    UINT width = 0;
    UINT height = 0;
    check(frame->GetSize(&width, &height), "IWICBitmapSource::GetSize");
    if (width == 0 || height == 0)
        throw std::runtime_error("decoded image has an empty extent");
    if (width > std::numeric_limits<std::uint32_t>::max() / 4)
        throw std::overflow_error("decoded image row pitch overflows 32 bits");

    WICPixelFormatGUID source_format{};
    check(frame->GetPixelFormat(&source_format), "IWICBitmapSource::GetPixelFormat");
    ComPtr<IWICFormatConverter> converter;
    check(factory->CreateFormatConverter(&converter), "IWICImagingFactory::CreateFormatConverter");
    BOOL can_convert = FALSE;
    check(converter->CanConvert(source_format, GUID_WICPixelFormat32bppRGBA, &can_convert),
          "IWICFormatConverter::CanConvert");
    if (!can_convert)
        throw std::runtime_error("WIC cannot convert the image to RGBA8");
    check(converter->Initialize(
              frame.Get(),
              GUID_WICPixelFormat32bppRGBA,
              WICBitmapDitherTypeNone,
              nullptr,
              0.0,
              WICBitmapPaletteTypeCustom),
          "IWICFormatConverter::Initialize");

    const std::uint32_t row_pitch = width * 4;
    const std::uint64_t byte_count_64 = static_cast<std::uint64_t>(row_pitch) * height;
    if (byte_count_64 > std::numeric_limits<UINT>::max() ||
        byte_count_64 > std::numeric_limits<std::size_t>::max())
        throw std::overflow_error("decoded image exceeds WIC output limits");

    DecodedImage result;
    result.width = width;
    result.height = height;
    result.row_pitch_bytes = row_pitch;
    result.color_space = color_space;
    result.rgba8.resize(static_cast<std::size_t>(byte_count_64));
    check(converter->CopyPixels(
              nullptr,
              row_pitch,
              static_cast<UINT>(byte_count_64),
              reinterpret_cast<BYTE*>(result.rgba8.data())),
          "IWICBitmapSource::CopyPixels");
    return result;
}

} // namespace pvz::assets
