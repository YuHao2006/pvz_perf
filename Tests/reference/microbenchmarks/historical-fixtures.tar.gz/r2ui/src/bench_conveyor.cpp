// bench_conveyor.cpp -- 目标9 kConveyorSeedsPerLevel/PerMode + kConveyorRows
//                    Challenge::UpdateConveyorBelt（传送带关每帧，热）
// FormA = 36a066a7^ 逐字（14 支链体逐值赋值，支序照抄）；FormB = HEAD 逐字（14 组序列表）。
// 谓词语义按游戏实际派生：冒险 ⇒ mode=0、level=1..50；非冒险 ⇒ level=0。
// 重定向谓词 ≡（模式 || 冒险关卡 X）由驱动统一派生存 stub 字段，两侧同读——
// HEAD 表把重定向烘焙进关卡槽（5/25/45/50），槽值推导即依赖这些等价式。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// SeedType 直值（0..50 摘录所用）
static const int ST_PEASHOOTER = 0, ST_CHERRYBOMB = 2, ST_WALLNUT = 3, ST_POTATOMINE = 4, ST_SNOWPEA = 5,
ST_CHOMPER = 6, ST_REPEATER = 7, ST_PUFFSHROOM = 9, ST_GRAVEBUSTER = 11, ST_HYPNOSHROOM = 12,
ST_SCAREDYSHROOM = 13, ST_ICESHROOM = 14, ST_DOOMSHROOM = 15, ST_LILYPAD = 16, ST_SQUASH = 17,
ST_THREEPEATER = 18, ST_TANGLEKELP = 19, ST_JALAPENO = 20, ST_SPIKEWEED = 21, ST_TORCHWOOD = 22,
ST_TALLNUT = 23, ST_BLOVER = 27, ST_CACTUS = 26, ST_FUMESHROOM = 10, ST_SEASHROOM = 8, ST_SPLITPEA = 28, ST_STARFRUIT = 29,
ST_PUMPKINSHELL = 30, ST_MAGNETSHROOM = 31, ST_CABBAGEPULT = 32, ST_FLOWERPOT = 33, ST_KERNELPULT = 34,
ST_MELONPULT = 39, ST_EXPLODE_O_NUT = 49, ST_GIANT_WALLNUT = 50;

struct TodWeightedArray { int mItem; int mWeight; };

// GameMode 摘录值
static const int GM_ADVENTURE = 0, GM_SHOVEL = 8, GM_BOWLING = 29, GM_STORMY = 30, GM_BOWLING2 = 31,
GM_LITTLE_TROUBLE = 32, GM_PORTAL = 33, GM_INVISIGHOUL = 34, GM_COLUMN = 35, GM_BUNGEE = 36, GM_FINALBOSS = 50;

static int g_seedsOnConveyor, g_countInBank;
struct SeedBankStub {
    void UpdateConveyorBelt() { CS(400); }
    int GetNumSeedsOnConveyorBelt() { return g_seedsOnConveyor; }
    int CountOfTypeOnConveyorBelt(int) { return g_countInBank; }
    void AddSeed(int t) { CS(401); CS((uint64_t)t); }
};
struct BossZombieStub { int mZombiePhase; };
struct BoardStubC {
    bool mHasLevelAwardDropped;
    int mLevel;
    int mGraveStonesCount, mCountByType, mEmptyPots;
    SeedBankStub* mSeedBank;
    BossZombieStub* mBossZombie;
    bool HasLevelAwardDropped() { return mHasLevelAwardDropped; }
    int CountPlantByType(int) { return mCountByType; }
    int GetGraveStonesCount() { return mGraveStonesCount; }
    int CountEmptyPotsOrLilies(int) { return mEmptyPots; }
};
struct AppStubC {
    int mGameMode;
    bool mFinalBoss, mShovel, mAdventure;
    bool mWallnutBowling, mLittleTrouble, mStormy, mBungeeBlitz;
    bool IsFinalBossLevel() { return mFinalBoss; }
    bool IsShovelLevel() { return mShovel; }
    bool IsAdventureMode() { return mAdventure; }
};
struct ChallengeStubC {
    AppStubC* mApp; BoardStubC* mBoard;
    int mConveyorBeltCounter, mLastConveyorSeedType;
};

static int TodAnimateCurveI(int a, int b, int v, int c, int d)
{
    float t = (float)(v - a) / (float)(b - a); if (t < 0) t = 0; if (t > 1) t = 1;
    return (int)(c + (d - c) * t);
}
static int TodPickFromWeightedArray(TodWeightedArray* arr, int count)
{
    CS(402); CS((uint64_t)count);
    if (count <= 0) { CS(999999); return -1; }
    uint64_t sum = 0;
    for (int i = 0; i < count; i++) { sum += (uint64_t)arr[i].mWeight; CS((uint64_t)arr[i].mItem * 100 + arr[i].mWeight); }
    return arr[sum % count].mItem;
}

// ---- 共用种子调整尾段（两侧逐字同）----
#define CONVEYOR_TAIL(m) \
    for (int i = 0; i < aSeedPickCount; i++) \
    { \
        TodWeightedArray& aSeedPick = aSeedPickArray[i]; \
        int aSeedType = aSeedPick.mItem; \
        int aCountInBank = m.mBoard->mSeedBank->CountOfTypeOnConveyorBelt(aSeedType); \
        int aTotalCount = m.mBoard->CountPlantByType(aSeedType) + aCountInBank; \
        if (aSeedType == ST_GRAVEBUSTER) \
        { \
            if (m.mBoard->GetGraveStonesCount() <= aTotalCount) { aSeedPick.mWeight = 0; continue; } \
        } \
        else if (aSeedType == ST_LILYPAD) \
        { \
            aSeedPick.mWeight = TodAnimateCurveI(0, 18, aTotalCount, aSeedPick.mWeight, 1); \
        } \
        else if (aSeedType == ST_FLOWERPOT) \
        { \
            aSeedPick.mWeight = TodAnimateCurveI(0, m.mApp->mGameMode == GM_COLUMN ? 45 : 35, aTotalCount, aSeedPick.mWeight, 1); \
        } \
        if (m.mApp->IsFinalBossLevel()) \
        { \
            if (aSeedType == ST_MELONPULT || aSeedType == ST_KERNELPULT || aSeedType == ST_CABBAGEPULT) \
            { \
                int aEmptyPots = m.mBoard->CountEmptyPotsOrLilies(ST_FLOWERPOT); \
                if (aEmptyPots <= 2) aSeedPick.mWeight /= 5; \
                else if (aEmptyPots <= 5) aSeedPick.mWeight /= 3; \
            } \
            if (aSeedType == ST_FLOWERPOT && m.mBoard->mBossZombie->mZombiePhase == 3) { aSeedPick.mWeight = 500; } \
        } \
        if (aSeedPickCount > 2) \
        { \
            if (aCountInBank >= 4) aSeedPick.mWeight = 1; \
            else if (aCountInBank >= 3) aSeedPick.mWeight = 5; \
            else if (aSeedType == m.mLastConveyorSeedType) aSeedPick.mWeight /= 2; \
        } \
    } \
    do { } while (0)

// ================= FormA (36a066a7^) =================
namespace FormA {
__declspec(noinline) void UpdateConveyorBelt(ChallengeStubC& m)
{
    if (m.mBoard->HasLevelAwardDropped())
        return;

    m.mBoard->mSeedBank->UpdateConveyorBelt();
    m.mConveyorBeltCounter--;
    if (m.mConveyorBeltCounter > 0)
        return;

    float aConveyorSpeedMultiplier = 1;
    if (m.mApp->IsFinalBossLevel())
        aConveyorSpeedMultiplier = 0.875f;
    else if (m.mApp->IsShovelLevel() || m.mApp->mGameMode == GM_PORTAL)
        aConveyorSpeedMultiplier = 1.5f;
    else if (m.mApp->mGameMode == GM_INVISIGHOUL)
        aConveyorSpeedMultiplier = 2.0f;
    else if (m.mApp->mGameMode == GM_COLUMN)
        aConveyorSpeedMultiplier = 3.0f;
    int aNumSeedsOnConveyor = m.mBoard->mSeedBank->GetNumSeedsOnConveyorBelt();
    m.mConveyorBeltCounter = (int)(aConveyorSpeedMultiplier * (aNumSeedsOnConveyor > 8 ? 1000 : aNumSeedsOnConveyor > 6 ? 500 : aNumSeedsOnConveyor > 4 ? 425 : 400));

    TodWeightedArray aSeedPickArray[20];
    int aSeedPickCount = 0;
    if (m.mBoard->mLevel == 10)
    {
        aSeedPickCount = 7;
        aSeedPickArray[0].mItem = ST_PEASHOOTER; aSeedPickArray[0].mWeight = 20;
        aSeedPickArray[1].mItem = ST_CHERRYBOMB; aSeedPickArray[1].mWeight = 20;
        aSeedPickArray[2].mItem = ST_WALLNUT; aSeedPickArray[2].mWeight = 15;
        aSeedPickArray[3].mItem = ST_REPEATER; aSeedPickArray[3].mWeight = 20;
        aSeedPickArray[4].mItem = ST_SNOWPEA; aSeedPickArray[4].mWeight = 10;
        aSeedPickArray[5].mItem = ST_CHOMPER; aSeedPickArray[5].mWeight = 5;
        aSeedPickArray[6].mItem = ST_POTATOMINE; aSeedPickArray[6].mWeight = 10;
    }
    else if (m.mBoard->mLevel == 20)
    {
        aSeedPickCount = 7;
        aSeedPickArray[0].mItem = ST_GRAVEBUSTER; aSeedPickArray[0].mWeight = 20;
        aSeedPickArray[1].mItem = ST_ICESHROOM; aSeedPickArray[1].mWeight = 15;
        aSeedPickArray[2].mItem = ST_DOOMSHROOM; aSeedPickArray[2].mWeight = 15;
        aSeedPickArray[3].mItem = ST_HYPNOSHROOM; aSeedPickArray[3].mWeight = 10;
        aSeedPickArray[4].mItem = ST_SCAREDYSHROOM; aSeedPickArray[4].mWeight = 15;
        aSeedPickArray[5].mItem = ST_FUMESHROOM; aSeedPickArray[5].mWeight = 15;
        aSeedPickArray[6].mItem = ST_PUFFSHROOM; aSeedPickArray[6].mWeight = 10;
    }
    else if (m.mBoard->mLevel == 30)
    {
        aSeedPickCount = 8;
        aSeedPickArray[0].mItem = ST_LILYPAD; aSeedPickArray[0].mWeight = 25;
        aSeedPickArray[1].mItem = ST_SQUASH; aSeedPickArray[1].mWeight = 5;
        aSeedPickArray[2].mItem = ST_THREEPEATER; aSeedPickArray[2].mWeight = 25;
        aSeedPickArray[3].mItem = ST_TANGLEKELP; aSeedPickArray[3].mWeight = 5;
        aSeedPickArray[4].mItem = ST_JALAPENO; aSeedPickArray[4].mWeight = 10;
        aSeedPickArray[5].mItem = ST_SPIKEWEED; aSeedPickArray[5].mWeight = 10;
        aSeedPickArray[6].mItem = ST_TORCHWOOD; aSeedPickArray[6].mWeight = 10;
        aSeedPickArray[7].mItem = ST_TALLNUT; aSeedPickArray[7].mWeight = 10;
    }
    else if (m.mBoard->mLevel == 40)
    {
        aSeedPickCount = 8;
        aSeedPickArray[0].mItem = ST_LILYPAD; aSeedPickArray[0].mWeight = 25;
        aSeedPickArray[1].mItem = ST_SEASHROOM; aSeedPickArray[1].mWeight = 10;
        aSeedPickArray[2].mItem = ST_MAGNETSHROOM; aSeedPickArray[2].mWeight = 5;
        aSeedPickArray[3].mItem = ST_BLOVER; aSeedPickArray[3].mWeight = 5;
        aSeedPickArray[4].mItem = ST_CACTUS; aSeedPickArray[4].mWeight = 15;
        aSeedPickArray[5].mItem = ST_STARFRUIT; aSeedPickArray[5].mWeight = 25;
        aSeedPickArray[6].mItem = ST_SPLITPEA; aSeedPickArray[6].mWeight = 5;
        aSeedPickArray[7].mItem = ST_PUMPKINSHELL; aSeedPickArray[7].mWeight = 10;
    }
    else if (m.mApp->IsFinalBossLevel())
    {
        aSeedPickCount = 6;
        aSeedPickArray[0].mItem = ST_FLOWERPOT; aSeedPickArray[0].mWeight = 55;
        aSeedPickArray[1].mItem = ST_MELONPULT; aSeedPickArray[1].mWeight = 10;
        aSeedPickArray[2].mItem = ST_JALAPENO; aSeedPickArray[2].mWeight = 12;
        aSeedPickArray[3].mItem = ST_CABBAGEPULT; aSeedPickArray[3].mWeight = 10;
        aSeedPickArray[4].mItem = ST_KERNELPULT; aSeedPickArray[4].mWeight = 5;
        aSeedPickArray[5].mItem = ST_ICESHROOM; aSeedPickArray[5].mWeight = 8;
    }
    else if (m.mApp->IsShovelLevel())
    {
        aSeedPickCount = 1;
        aSeedPickArray[0].mItem = ST_PEASHOOTER; aSeedPickArray[0].mWeight = 100;
    }
    else if (m.mApp->mGameMode == GM_BOWLING2)
    {
        aSeedPickCount = 3;
        aSeedPickArray[0].mItem = ST_WALLNUT; aSeedPickArray[0].mWeight = 85;
        aSeedPickArray[1].mItem = ST_EXPLODE_O_NUT; aSeedPickArray[1].mWeight = 15;
        aSeedPickArray[2].mItem = ST_GIANT_WALLNUT; aSeedPickArray[2].mWeight = 15;
    }
    else if (m.mApp->mWallnutBowling) // IsWallnutBowlingLevel()
    {
        aSeedPickCount = 2;
        aSeedPickArray[0].mItem = ST_WALLNUT; aSeedPickArray[0].mWeight = 85;
        aSeedPickArray[1].mItem = ST_EXPLODE_O_NUT; aSeedPickArray[1].mWeight = 15;
    }
    else if (m.mApp->mLittleTrouble) // IsLittleTroubleLevel()
    {
        aSeedPickCount = 4;
        aSeedPickArray[0].mItem = ST_LILYPAD; aSeedPickArray[0].mWeight = 25;
        aSeedPickArray[1].mItem = ST_WALLNUT; aSeedPickArray[1].mWeight = 15;
        aSeedPickArray[2].mItem = ST_PEASHOOTER; aSeedPickArray[2].mWeight = 25;
        aSeedPickArray[3].mItem = ST_CHERRYBOMB; aSeedPickArray[3].mWeight = 35;
    }
    else if (m.mApp->mStormy) // IsStormyNightLevel()
    {
        aSeedPickCount = 5;
        aSeedPickArray[0].mItem = ST_LILYPAD; aSeedPickArray[0].mWeight = 30;
        aSeedPickArray[1].mItem = ST_CACTUS; aSeedPickArray[1].mWeight = 10;
        aSeedPickArray[2].mItem = ST_PEASHOOTER; aSeedPickArray[2].mWeight = 20;
        aSeedPickArray[3].mItem = ST_PUFFSHROOM; aSeedPickArray[3].mWeight = 15;
        aSeedPickArray[4].mItem = ST_CHERRYBOMB; aSeedPickArray[4].mWeight = 25;
    }
    else if (m.mApp->mBungeeBlitz) // IsBungeeBlitzLevel()
    {
        aSeedPickCount = 4;
        aSeedPickArray[0].mItem = ST_FLOWERPOT; aSeedPickArray[0].mWeight = 50;
        aSeedPickArray[1].mItem = ST_CHOMPER; aSeedPickArray[1].mWeight = 25;
        aSeedPickArray[2].mItem = ST_PUMPKINSHELL; aSeedPickArray[2].mWeight = 15;
        aSeedPickArray[3].mItem = ST_CHERRYBOMB; aSeedPickArray[3].mWeight = 10;
    }
    else if (m.mApp->mGameMode == GM_PORTAL)
    {
        aSeedPickCount = 6;
        aSeedPickArray[0].mItem = ST_PEASHOOTER; aSeedPickArray[0].mWeight = 25;
        aSeedPickArray[1].mItem = ST_REPEATER; aSeedPickArray[1].mWeight = 20;
        aSeedPickArray[2].mItem = ST_TORCHWOOD; aSeedPickArray[2].mWeight = 10;
        aSeedPickArray[3].mItem = ST_CACTUS; aSeedPickArray[3].mWeight = 15;
        aSeedPickArray[4].mItem = ST_WALLNUT; aSeedPickArray[4].mWeight = 15;
        aSeedPickArray[5].mItem = ST_CHERRYBOMB; aSeedPickArray[5].mWeight = 15;
    }
    else if (m.mApp->mGameMode == GM_COLUMN)
    {
        aSeedPickCount = 6;
        aSeedPickArray[0].mItem = ST_FLOWERPOT; aSeedPickArray[0].mWeight = 155;
        aSeedPickArray[1].mItem = ST_MELONPULT; aSeedPickArray[1].mWeight = 5;
        aSeedPickArray[2].mItem = ST_CHOMPER; aSeedPickArray[2].mWeight = 5;
        aSeedPickArray[3].mItem = ST_PUMPKINSHELL; aSeedPickArray[3].mWeight = 15;
        aSeedPickArray[4].mItem = ST_JALAPENO; aSeedPickArray[4].mWeight = 10;
        aSeedPickArray[5].mItem = ST_SQUASH; aSeedPickArray[5].mWeight = 10;
    }
    else if (m.mApp->mGameMode == GM_INVISIGHOUL)
    {
        aSeedPickCount = 6;
        aSeedPickArray[0].mItem = ST_PEASHOOTER; aSeedPickArray[0].mWeight = 25;
        aSeedPickArray[1].mItem = ST_WALLNUT; aSeedPickArray[1].mWeight = 15;
        aSeedPickArray[2].mItem = ST_KERNELPULT; aSeedPickArray[2].mWeight = 5;
        aSeedPickArray[3].mItem = ST_SQUASH; aSeedPickArray[3].mWeight = 15;
        aSeedPickArray[4].mItem = ST_LILYPAD; aSeedPickArray[4].mWeight = 30;
        aSeedPickArray[5].mItem = ST_ICESHROOM; aSeedPickArray[5].mWeight = 10;
    }

    CONVEYOR_TAIL(m);

    int aSeedType = TodPickFromWeightedArray(aSeedPickArray, aSeedPickCount);
    m.mBoard->mSeedBank->AddSeed(aSeedType);
    m.mLastConveyorSeedType = aSeedType;
}
} // namespace FormA

// ================= FormB (HEAD) =================
namespace FormB {
namespace {
struct ConveyorSeedRow { int mSeed; int mWeight; };
struct ConveyorSeedSet { const ConveyorSeedRow* mRows; int mCount; };

constexpr ConveyorSeedRow kConveyorRowsLevel10[] = {
    { ST_PEASHOOTER, 20 }, { ST_CHERRYBOMB, 20 }, { ST_WALLNUT, 15 },
    { ST_REPEATER, 20 }, { ST_SNOWPEA, 10 }, { ST_CHOMPER, 5 }, { ST_POTATOMINE, 10 },
};
constexpr ConveyorSeedRow kConveyorRowsLevel20[] = {
    { ST_GRAVEBUSTER, 20 }, { ST_ICESHROOM, 15 }, { ST_DOOMSHROOM, 15 },
    { ST_HYPNOSHROOM, 10 }, { ST_SCAREDYSHROOM, 15 }, { ST_FUMESHROOM, 15 }, { ST_PUFFSHROOM, 10 },
};
constexpr ConveyorSeedRow kConveyorRowsLevel30[] = {
    { ST_LILYPAD, 25 }, { ST_SQUASH, 5 }, { ST_THREEPEATER, 25 },
    { ST_TANGLEKELP, 5 }, { ST_JALAPENO, 10 }, { ST_SPIKEWEED, 10 },
    { ST_TORCHWOOD, 10 }, { ST_TALLNUT, 10 },
};
constexpr ConveyorSeedRow kConveyorRowsLevel40[] = {
    { ST_LILYPAD, 25 }, { ST_SEASHROOM, 10 }, { ST_MAGNETSHROOM, 5 },
    { ST_BLOVER, 5 }, { ST_CACTUS, 15 }, { ST_STARFRUIT, 25 },
    { ST_SPLITPEA, 5 }, { ST_PUMPKINSHELL, 10 },
};
constexpr ConveyorSeedRow kConveyorRowsFinalBoss[] = {
    { ST_FLOWERPOT, 55 }, { ST_MELONPULT, 10 }, { ST_JALAPENO, 12 },
    { ST_CABBAGEPULT, 10 }, { ST_KERNELPULT, 5 }, { ST_ICESHROOM, 8 },
};
constexpr ConveyorSeedRow kConveyorRowsShovel[] = { { ST_PEASHOOTER, 100 } };
constexpr ConveyorSeedRow kConveyorRowsBowling2[] = {
    { ST_WALLNUT, 85 }, { ST_EXPLODE_O_NUT, 15 }, { ST_GIANT_WALLNUT, 15 },
};
constexpr ConveyorSeedRow kConveyorRowsBowling[] = { { ST_WALLNUT, 85 }, { ST_EXPLODE_O_NUT, 15 } };
constexpr ConveyorSeedRow kConveyorRowsLittleTrouble[] = {
    { ST_LILYPAD, 25 }, { ST_WALLNUT, 15 }, { ST_PEASHOOTER, 25 }, { ST_CHERRYBOMB, 35 },
};
constexpr ConveyorSeedRow kConveyorRowsStormyNight[] = {
    { ST_LILYPAD, 30 }, { ST_CACTUS, 10 }, { ST_PEASHOOTER, 20 },
    { ST_PUFFSHROOM, 15 }, { ST_CHERRYBOMB, 25 },
};
constexpr ConveyorSeedRow kConveyorRowsBungeeBlitz[] = {
    { ST_FLOWERPOT, 50 }, { ST_CHOMPER, 25 }, { ST_PUMPKINSHELL, 15 }, { ST_CHERRYBOMB, 10 },
};
constexpr ConveyorSeedRow kConveyorRowsPortalCombat[] = {
    { ST_PEASHOOTER, 25 }, { ST_REPEATER, 20 }, { ST_TORCHWOOD, 10 },
    { ST_CACTUS, 15 }, { ST_WALLNUT, 15 }, { ST_CHERRYBOMB, 15 },
};
constexpr ConveyorSeedRow kConveyorRowsColumn[] = {
    { ST_FLOWERPOT, 155 }, { ST_MELONPULT, 5 }, { ST_CHOMPER, 5 },
    { ST_PUMPKINSHELL, 15 }, { ST_JALAPENO, 10 }, { ST_SQUASH, 10 },
};
constexpr ConveyorSeedRow kConveyorRowsInvisighoul[] = {
    { ST_PEASHOOTER, 25 }, { ST_WALLNUT, 15 }, { ST_KERNELPULT, 5 },
    { ST_SQUASH, 15 }, { ST_LILYPAD, 30 }, { ST_ICESHROOM, 10 },
};

constexpr int FINAL_LEVEL = 50;
constexpr ConveyorSeedSet kConveyorSeedsPerLevel[FINAL_LEVEL] = {
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsBowling, 2 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsLevel10, 7 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsLevel20, 7 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsLittleTrouble, 4 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsLevel30, 8 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsLevel40, 8 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsBungeeBlitz, 4 },
    { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 }, { nullptr, 0 },
    { kConveyorRowsFinalBoss, 6 },
};
constexpr int NUM_GAME_MODES = 51;
constexpr ConveyorSeedSet kConveyorSeedsPerMode[NUM_GAME_MODES] = {
    /*[0]*/ { nullptr, 0 }, /*[1]*/ { nullptr, 0 }, /*[2]*/ { nullptr, 0 }, /*[3]*/ { nullptr, 0 }, /*[4]*/ { nullptr, 0 }, /*[5]*/ { nullptr, 0 }, /*[6]*/ { nullptr, 0 }, /*[7]*/ { nullptr, 0 }, /*[8]*/ { kConveyorRowsShovel, 1 }, /*[9]*/ { nullptr, 0 },
    /*[10]*/ { nullptr, 0 }, /*[11]*/ { nullptr, 0 }, /*[12]*/ { nullptr, 0 }, /*[13]*/ { nullptr, 0 }, /*[14]*/ { nullptr, 0 }, /*[15]*/ { nullptr, 0 }, /*[16]*/ { nullptr, 0 }, /*[17]*/ { nullptr, 0 }, /*[18]*/ { nullptr, 0 }, /*[19]*/ { nullptr, 0 },
    /*[20]*/ { nullptr, 0 }, /*[21]*/ { nullptr, 0 }, /*[22]*/ { nullptr, 0 }, /*[23]*/ { nullptr, 0 }, /*[24]*/ { nullptr, 0 }, /*[25]*/ { nullptr, 0 }, /*[26]*/ { nullptr, 0 }, /*[27]*/ { nullptr, 0 }, /*[28]*/ { nullptr, 0 }, /*[29]*/ { kConveyorRowsBowling, 2 },
    /*[30]*/ { kConveyorRowsStormyNight, 5 }, /*[31]*/ { kConveyorRowsBowling2, 3 }, /*[32]*/ { kConveyorRowsLittleTrouble, 4 }, /*[33]*/ { kConveyorRowsPortalCombat, 6 }, /*[34]*/ { kConveyorRowsInvisighoul, 6 }, /*[35]*/ { kConveyorRowsColumn, 6 }, /*[36]*/ { kConveyorRowsBungeeBlitz, 4 }, /*[37]*/ { nullptr, 0 }, /*[38]*/ { nullptr, 0 }, /*[39]*/ { nullptr, 0 },
    /*[40]*/ { nullptr, 0 }, /*[41]*/ { nullptr, 0 }, /*[42]*/ { nullptr, 0 }, /*[43]*/ { nullptr, 0 }, /*[44]*/ { nullptr, 0 }, /*[45]*/ { nullptr, 0 }, /*[46]*/ { nullptr, 0 }, /*[47]*/ { nullptr, 0 }, /*[48]*/ { nullptr, 0 }, /*[49]*/ { nullptr, 0 },
    /*[50]*/ { kConveyorRowsFinalBoss, 6 },
};
} // namespace

__declspec(noinline) void UpdateConveyorBelt(ChallengeStubC& m)
{
    if (m.mBoard->HasLevelAwardDropped())
        return;

    m.mBoard->mSeedBank->UpdateConveyorBelt();
    m.mConveyorBeltCounter--;
    if (m.mConveyorBeltCounter > 0)
        return;

    float aConveyorSpeedMultiplier = 1;
    if (m.mApp->IsFinalBossLevel())
        aConveyorSpeedMultiplier = 0.875f;
    else if (m.mApp->IsShovelLevel() || m.mApp->mGameMode == GM_PORTAL)
        aConveyorSpeedMultiplier = 1.5f;
    else if (m.mApp->mGameMode == GM_INVISIGHOUL)
        aConveyorSpeedMultiplier = 2.0f;
    else if (m.mApp->mGameMode == GM_COLUMN)
        aConveyorSpeedMultiplier = 3.0f;
    int aNumSeedsOnConveyor = m.mBoard->mSeedBank->GetNumSeedsOnConveyorBelt();
    m.mConveyorBeltCounter = (int)(aConveyorSpeedMultiplier * (aNumSeedsOnConveyor > 8 ? 1000 : aNumSeedsOnConveyor > 6 ? 500 : aNumSeedsOnConveyor > 4 ? 425 : 400));

    TodWeightedArray aSeedPickArray[20];
    int aSeedPickCount = 0;
    const ConveyorSeedSet* aSeedSet = nullptr;
    if (m.mApp->IsAdventureMode())
    {
        int aLevelIndex = m.mBoard->mLevel - 1;
        if ((unsigned)aLevelIndex < (unsigned)(sizeof(kConveyorSeedsPerLevel) / sizeof(kConveyorSeedsPerLevel[0])))
        {
            aSeedSet = &kConveyorSeedsPerLevel[aLevelIndex];
        }
    }
    else
    {
        int aMode = (int)m.mApp->mGameMode;
        if ((unsigned)aMode < (unsigned)(sizeof(kConveyorSeedsPerMode) / sizeof(kConveyorSeedsPerMode[0])))
        {
            aSeedSet = &kConveyorSeedsPerMode[aMode];
        }
    }
    if (aSeedSet != nullptr && aSeedSet->mRows != nullptr)
    {
        aSeedPickCount = aSeedSet->mCount;
        for (int i = 0; i < aSeedPickCount; i++)
        {
            aSeedPickArray[i].mItem = aSeedSet->mRows[i].mSeed;
            aSeedPickArray[i].mWeight = aSeedSet->mRows[i].mWeight;
        }
    }

    CONVEYOR_TAIL(m);

    int aSeedType = TodPickFromWeightedArray(aSeedPickArray, aSeedPickCount);
    m.mBoard->mSeedBank->AddSeed(aSeedType);
    m.mLastConveyorSeedType = aSeedType;
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];
static ChallengeStubC g_ch;
static SeedBankStub g_bank;
static BoardStubC g_board;
static AppStubC g_app;
static BossZombieStub g_boss;

typedef void (*ConvFn)(ChallengeStubC&);
static uint64_t RunConv(ConvFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    static const int modes[12] = { GM_ADVENTURE, GM_SHOVEL, GM_BOWLING, GM_STORMY, GM_BOWLING2,
        GM_LITTLE_TROUBLE, GM_PORTAL, GM_INVISIGHOUL, GM_COLUMN, GM_BUNGEE, GM_FINALBOSS, 2 };
    for (int i = 0; i < N; i++)
    {
        uint32_t v = g_in[i];
        bool adventure = ((v >> 0) & 1) != 0;
        int mode = adventure ? GM_ADVENTURE : modes[(v >> 7) % 12];
        int level = adventure ? (int)((v >> 12) % 50) + 1 : 0;
        g_app.mAdventure = adventure;
        g_app.mGameMode = mode;
        // 谓词派生（与游戏语义一致，两侧同读）
        g_app.mFinalBoss = (mode == GM_FINALBOSS) || (adventure && level == 50);
        g_app.mShovel = (mode == GM_SHOVEL);
        g_app.mWallnutBowling = (mode == GM_BOWLING || mode == GM_BOWLING2) || (adventure && level == 5);
        g_app.mLittleTrouble = (mode == GM_LITTLE_TROUBLE) || (adventure && level == 25);
        g_app.mStormy = (mode == GM_STORMY) || (adventure && level == 40);
        g_app.mBungeeBlitz = (mode == GM_BUNGEE) || (adventure && level == 45);

        g_board.mHasLevelAwardDropped = false;
        g_ch.mConveyorBeltCounter = 0;
        g_board.mLevel = level;
        g_seedsOnConveyor = (int)((v >> 2) & 15);
        g_countInBank = (int)((v >> 6) & 7);
        g_board.mCountByType = (int)((v >> 9) & 31);
        g_board.mGraveStonesCount = (int)((v >> 14) & 31);
        g_board.mEmptyPots = (int)((v >> 19) & 7);
        g_boss.mZombiePhase = (int)((v >> 22) & 7);
        g_ch.mLastConveyorSeedType = (int)((v >> 25) & 63);
        fn(g_ch);
    }
    return g_cs;
}

int main()
{
    LCG rng{ 0xA4093822299F31D0ULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();
    g_ch.mApp = &g_app; g_ch.mBoard = &g_board;
    g_board.mSeedBank = &g_bank; g_board.mBossZombie = &g_boss;

    uint64_t csA = RunConv(FormA::UpdateConveyorBelt), csB = RunConv(FormB::UpdateConveyorBelt);
    double r[2][2] = {};
    for (int rd = 0; rd < 2; rd++)
    {
        r[rd][0] = TimeMin5([] { RunConv(FormA::UpdateConveyorBelt); }) / N * 1e9;
        r[rd][1] = TimeMin5([] { RunConv(FormB::UpdateConveyorBelt); }) / N * 1e9;
    }
    printf("t9 kConveyorSeedsPerLevel/PerMode+Rows UpdateConveyorBelt | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        r[0][0], r[1][0], r[0][1], r[1][1],
        (r[0][0] - r[0][1]) / r[0][0] * 100.0, (r[1][0] - r[1][1]) / r[1][0] * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
    return 0;
}
