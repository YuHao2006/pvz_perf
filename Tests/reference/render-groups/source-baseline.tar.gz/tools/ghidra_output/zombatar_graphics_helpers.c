/* 005981d0 FUN_005981d0 */

void __fastcall FUN_005981d0(int param_1)

{
  int local_cc;
  undefined1 local_50 [76];
  
  FUN_00401ab0();
  FUN_00561490();
  FUN_005b6550(local_50);
  if (param_1 == 0) {
    local_cc = 0;
  }
  else {
    local_cc = param_1 + 4;
  }
  FUN_005dcd60(local_cc);
  FUN_00597ea0(local_cc);
  return;
}



/* 00598250 FUN_00598250 */

void __fastcall FUN_00598250(int param_1)

{
  undefined4 uVar1;
  
  if (*(int *)(param_1 + 0x74) != 0) {
    uVar1 = FUN_005dcd60();
    FUN_00597ea0(uVar1);
    FUN_005b65c0();
  }
  return;
}



/* 00599070 FUN_00599070 */

void __thiscall
FUN_00599070(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 *local_30;
  undefined1 local_24 [16];
  undefined1 local_14 [16];
  
  FUN_006ba960(param_5,param_6);
  FUN_006ba960();
  FUN_00401a90(param_5,param_6);
  FUN_00401a90(*(undefined4 *)(param_2 + 0x24),*(undefined4 *)(param_2 + 0x28));
  if (*(char *)(param_1 + 0x48) == '\0') {
    local_30 = &DAT_007a23e0;
  }
  else {
    local_30 = (undefined4 *)(param_1 + 0x30);
  }
  (**(code **)(**(int **)(param_1 + 4) + 0x30))
            (param_2,local_14,local_24,param_1 + 0x20,local_30,*(undefined4 *)(param_1 + 0x44),
             *(undefined1 *)(param_1 + 0x49));
  return;
}



/* 0059aba0 FUN_0059aba0 */

undefined4 __fastcall FUN_0059aba0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x24);
}



/* 0059abc0 FUN_0059abc0 */

undefined4 __fastcall FUN_0059abc0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x28);
}



/* 005983e0 FUN_005983e0 */

void __thiscall FUN_005983e0(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x48) = param_2;
  return;
}



/* 005615d0 FUN_005615d0 */

undefined4 * __thiscall
FUN_005615d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  return param_1;
}



