// bench_variation.cpp — 目标1：ReanimatorCache::UpdateReanimationForVariation
// FormA = ac447d19^ 改造前（6 case switch + default）
// FormB = HEAD 终态（kVariationApplyCases 18 槽 lambda 表 + 越界守卫）
// 输入：2M 均匀分布 DrawVariation(0..17)，固定种子，两形态消费同一数组。
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <random>

// ---------------- harness ----------------
static uint64_t g_cs = 0;
static inline void CsMix(uint64_t v) { g_cs = g_cs * 0x9E3779B97F4A7C15ull + v; }

static uint64_t QpcFreq() { static uint64_t f = 0; if (!f) { LARGE_INTEGER li; QueryPerformanceFrequency(&li); f = (uint64_t)li.QuadPart; } return f; }
static uint64_t QpcNow() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (uint64_t)c.QuadPart; }
static double QpcToNs(uint64_t ticks) { return (double)ticks * 1e9 / (double)QpcFreq(); }

#define TOD_ASSERT(...) ((void)0)
#define LENGTH(a) (sizeof(a) / sizeof((a)[0]))

// ---------------- game type stubs ----------------
enum DrawVariation
{
    VARIATION_NORMAL,
    VARIATION_IMITATER,
    VARIATION_MARIGOLD_WHITE,
    VARIATION_MARIGOLD_MAGENTA,
    VARIATION_MARIGOLD_ORANGE,
    VARIATION_MARIGOLD_PINK,
    VARIATION_MARIGOLD_LIGHT_BLUE,
    VARIATION_MARIGOLD_RED,
    VARIATION_MARIGOLD_BLUE,
    VARIATION_MARIGOLD_VIOLET,
    VARIATION_MARIGOLD_LAVENDER,
    VARIATION_MARIGOLD_YELLOW,
    VARIATION_MARIGOLD_LIGHT_GREEN,
    VARIATION_ZEN_GARDEN,
    VARIATION_ZEN_GARDEN_WATER,
    VARIATION_SPROUT_NO_FLOWER,
    VARIATION_IMITATER_LESS,
    VARIATION_AQUARIUM
};
enum FilterEffect
{
    FILTER_EFFECT_NONE = -1,
    FILTER_EFFECT_WASHED_OUT,
    FILTER_EFFECT_LESS_WASHED_OUT,
    FILTER_EFFECT_WHITE,
    NUM_FILTER_EFFECTS
};
enum ReanimTrackId { None = 0, Marigold_petals, anim_normal, anim_tricked, anim_zengarden, anim_waterplants, anim_idle_noflower, anim_idle_aquarium };

class Color
{
public:
    int mRed, mGreen, mBlue, mAlpha;
    Color() : mRed(0), mGreen(0), mBlue(0), mAlpha(255) {}
    Color(int theRed, int theGreen, int theBlue) : mRed(theRed), mGreen(theGreen), mBlue(theBlue), mAlpha(255) {}
};

class ReanimatorTrackInstance { public: Color mTrackColor; };

class Reanimation
{
public:
    FilterEffect mFilterEffect;
    ReanimTrackId mLastLayer;
    ReanimatorTrackInstance mTracks[8];

    ReanimatorTrackInstance* GetTrackInstanceByName(ReanimTrackId theTrackId) { CsMix(11); return &mTracks[theTrackId & 7]; }
    void SetFramesForLayer(ReanimTrackId theTrackId) { CsMix(12); CsMix((uint64_t)theTrackId); mLastLayer = theTrackId; }
};

class ReanimatorCache
{
public:
    void UpdateReanimationForVariation_A(Reanimation* theReanim, DrawVariation theDrawVariation);
    void UpdateReanimationForVariation_B(Reanimation* theReanim, DrawVariation theDrawVariation);
};

// ================= FormA：改造前（ac447d19^ 逐字） =================
__declspec(noinline) void ReanimatorCache::UpdateReanimationForVariation_A(Reanimation* theReanim, DrawVariation theDrawVariation)
{
	if (theDrawVariation >= DrawVariation::VARIATION_MARIGOLD_WHITE && theDrawVariation <= DrawVariation::VARIATION_MARIGOLD_LIGHT_GREEN)
	{
		size_t aVariationIndex = (size_t)theDrawVariation - (size_t)DrawVariation::VARIATION_MARIGOLD_WHITE;
		Color MARIGOLD_VARIATIONS[] = {
			Color(255, 255, 255),
			Color(230, 30, 195),
			Color(250, 125, 5),
			Color(255, 145, 215),
			Color(160, 255, 245),
			Color(230, 30, 30),
			Color(5, 130, 255),
			Color(195, 55, 235),
			Color(235, 210, 255),
			Color(255, 245, 55),
			Color(180, 255, 105)
		};

		TOD_ASSERT(aVariationIndex >= 0 && aVariationIndex < LENGTH(MARIGOLD_VARIATIONS));
		theReanim->GetTrackInstanceByName(ReanimTrackId::Marigold_petals)->mTrackColor = MARIGOLD_VARIATIONS[aVariationIndex];
	}
	else
	{
		switch (theDrawVariation)
		{
		case DrawVariation::VARIATION_IMITATER:
			theReanim->mFilterEffect = FilterEffect::FILTER_EFFECT_WASHED_OUT;
			break;
		case DrawVariation::VARIATION_IMITATER_LESS:
			theReanim->mFilterEffect = FilterEffect::FILTER_EFFECT_LESS_WASHED_OUT;
			break;
		case DrawVariation::VARIATION_ZEN_GARDEN:
			theReanim->SetFramesForLayer(ReanimTrackId::anim_zengarden);
			break;
		case DrawVariation::VARIATION_ZEN_GARDEN_WATER:
			theReanim->SetFramesForLayer(ReanimTrackId::anim_waterplants);
			break;
		case DrawVariation::VARIATION_AQUARIUM:
			theReanim->SetFramesForLayer(ReanimTrackId::anim_idle_aquarium);
			break;
		case DrawVariation::VARIATION_SPROUT_NO_FLOWER:
			theReanim->SetFramesForLayer(ReanimTrackId::anim_idle_noflower);
			break;
		default:
			TOD_ASSERT(false);
			break;
		}
	}
}

// ================= FormB：当前终态（HEAD 逐字） =================
namespace
{
using VariationApplyCaseFn = void (*)(Reanimation*);

void VariationApplyDefault(Reanimation* theReanim)
{
    			TOD_ASSERT(false);
}

constexpr VariationApplyCaseFn kVariationApplyCases[(int)DrawVariation::VARIATION_AQUARIUM + 1] = {
    &VariationApplyDefault,  // 0 VARIATION_NORMAL（原 default）
    [](Reanimation* theReanim)
    {
    			theReanim->mFilterEffect = FilterEffect::FILTER_EFFECT_WASHED_OUT;
    },  // 1 VARIATION_IMITATER
    &VariationApplyDefault,  // 2 VARIATION_MARIGOLD_WHITE（原 default）
    &VariationApplyDefault,  // 3 VARIATION_MARIGOLD_MAGENTA（原 default）
    &VariationApplyDefault,  // 4 VARIATION_MARIGOLD_ORANGE（原 default）
    &VariationApplyDefault,  // 5 VARIATION_MARIGOLD_PINK（原 default）
    &VariationApplyDefault,  // 6 VARIATION_MARIGOLD_LIGHT_BLUE（原 default）
    &VariationApplyDefault,  // 7 VARIATION_MARIGOLD_RED（原 default）
    &VariationApplyDefault,  // 8 VARIATION_MARIGOLD_BLUE（原 default）
    &VariationApplyDefault,  // 9 VARIATION_MARIGOLD_VIOLET（原 default）
    &VariationApplyDefault,  // 10 VARIATION_MARIGOLD_LAVENDER（原 default）
    &VariationApplyDefault,  // 11 VARIATION_MARIGOLD_YELLOW（原 default）
    &VariationApplyDefault,  // 12 VARIATION_MARIGOLD_LIGHT_GREEN（原 default）
    [](Reanimation* theReanim)
    {
    			theReanim->SetFramesForLayer(ReanimTrackId::anim_zengarden);
    },  // 13 VARIATION_ZEN_GARDEN
    [](Reanimation* theReanim)
    {
    			theReanim->SetFramesForLayer(ReanimTrackId::anim_waterplants);
    },  // 14 VARIATION_ZEN_GARDEN_WATER
    [](Reanimation* theReanim)
    {
    			theReanim->SetFramesForLayer(ReanimTrackId::anim_idle_noflower);
    },  // 15 VARIATION_SPROUT_NO_FLOWER
    [](Reanimation* theReanim)
    {
    			theReanim->mFilterEffect = FilterEffect::FILTER_EFFECT_LESS_WASHED_OUT;
    },  // 16 VARIATION_IMITATER_LESS
    [](Reanimation* theReanim)
    {
    			theReanim->SetFramesForLayer(ReanimTrackId::anim_idle_aquarium);
    },  // 17 VARIATION_AQUARIUM
};
static_assert(sizeof(kVariationApplyCases) / sizeof(kVariationApplyCases[0]) ==
    (int)DrawVariation::VARIATION_AQUARIUM + 1, "kVariationApplyCases 槽位数须与 DrawVariation 枚举同步");
}  // namespace

__declspec(noinline) void ReanimatorCache::UpdateReanimationForVariation_B(Reanimation* theReanim, DrawVariation theDrawVariation)
{
	if (theDrawVariation >= DrawVariation::VARIATION_MARIGOLD_WHITE && theDrawVariation <= DrawVariation::VARIATION_MARIGOLD_LIGHT_GREEN)
	{
		size_t aVariationIndex = (size_t)theDrawVariation - (size_t)DrawVariation::VARIATION_MARIGOLD_WHITE;
		Color MARIGOLD_VARIATIONS[] = {
			Color(255, 255, 255),
			Color(230, 30, 195),
			Color(250, 125, 5),
			Color(255, 145, 215),
			Color(160, 255, 245),
			Color(230, 30, 30),
			Color(5, 130, 255),
			Color(195, 55, 235),
			Color(235, 210, 255),
			Color(255, 245, 55),
			Color(180, 255, 105)
		};

		TOD_ASSERT(aVariationIndex >= 0 && aVariationIndex < LENGTH(MARIGOLD_VARIATIONS));
		theReanim->GetTrackInstanceByName(ReanimTrackId::Marigold_petals)->mTrackColor = MARIGOLD_VARIATIONS[aVariationIndex];
	}
	else
	{
		const unsigned aVariationIndex = static_cast<unsigned>(theDrawVariation);
		if (aVariationIndex <= static_cast<unsigned>(DrawVariation::VARIATION_AQUARIUM))
		{
			kVariationApplyCases[aVariationIndex](theReanim);
		}
		else
		{
			VariationApplyDefault(theReanim);
		}

	}
}

// ---------------- bench driver ----------------
static const int N = 2000000;
static int g_input[N];

static void MixReanim(const Reanimation& r)
{
    CsMix((uint64_t)r.mFilterEffect);
    CsMix((uint64_t)r.mLastLayer);
    CsMix((uint64_t)r.mTracks[Marigold_petals & 7].mTrackColor.mRed * 65536 + r.mTracks[Marigold_petals & 7].mTrackColor.mGreen * 256 + r.mTracks[Marigold_petals & 7].mTrackColor.mBlue);
}

int main()
{
    std::mt19937 rng(20261002);
    std::uniform_int_distribution<int> dist(0, (int)DrawVariation::VARIATION_AQUARIUM);
    for (int k = 0; k < N; k++) g_input[k] = dist(rng);

    ReanimatorCache rc;
    Reanimation reanimA, reanimB;

    // ---- checksum pass ----
    reanimA = Reanimation(); reanimB = Reanimation();
    g_cs = 0;
    for (int k = 0; k < N; k++) rc.UpdateReanimationForVariation_A(&reanimA, (DrawVariation)g_input[k]);
    MixReanim(reanimA);
    uint64_t csA = g_cs;

    g_cs = 0;
    for (int k = 0; k < N; k++) rc.UpdateReanimationForVariation_B(&reanimB, (DrawVariation)g_input[k]);
    MixReanim(reanimB);
    uint64_t csB = g_cs;

    bool csOK = (csA == csB);

    // ---- warmup ----
    for (int k = 0; k < 10000; k++) { rc.UpdateReanimationForVariation_A(&reanimA, (DrawVariation)g_input[k]); rc.UpdateReanimationForVariation_B(&reanimB, (DrawVariation)g_input[k]); }

    // ---- timing：min-of-5，A/B 交错 ----
    uint64_t aMin = UINT64_MAX, bMin = UINT64_MAX;
    volatile uint64_t sink = 0;
    for (int rep = 0; rep < 5; rep++)
    {
        uint64_t t0 = QpcNow();
        for (int k = 0; k < N; k++) rc.UpdateReanimationForVariation_A(&reanimA, (DrawVariation)g_input[k]);
        uint64_t t1 = QpcNow();
        uint64_t t2 = QpcNow();
        for (int k = 0; k < N; k++) rc.UpdateReanimationForVariation_B(&reanimB, (DrawVariation)g_input[k]);
        uint64_t t3 = QpcNow();
        if (t1 - t0 < aMin) aMin = t1 - t0;
        if (t3 - t2 < bMin) bMin = t3 - t2;
    }
    sink = csA ^ csB;

    double nsA = QpcToNs(aMin) / N;
    double nsB = QpcToNs(bMin) / N;
    double diff = (nsB - nsA) / nsA * 100.0;
    printf("UpdateReanimationForVariation | before %.2f ns | after %.2f ns | diff %+.2f%% | checksum=%s (A=%016llx B=%016llx) sink=%llu\n",
        nsA, nsB, diff, csOK ? "OK" : "FAIL", (unsigned long long)csA, (unsigned long long)csB, (unsigned long long)sink);
    return csOK ? 0 : 1;
}
