// bench_cutscene.cpp -- 目标10 kCrazyDaveDialogPerLevel(50) CutScene::StartLevelIntro 戴夫开场白段（开场一次，冷）
//                      目标11 kFlowerPotColumnsPerLevel(50)  CutScene::AddFlowerPots（装载一次，冷）
// FormA = 36a066a7^ 逐字；FormB = HEAD 逐字。
// 模式谓词按游戏语义派生（冒险 ⇒ mode=ADVENTURE、level=1..50；非冒险 ⇒ 关卡重定向谓词仅由模式决定）。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

enum GameModeCS { GM_ADVENTURE = 0, GM_WALLNUT_BOWLING = 29, GM_STORMY_NIGHT = 30, GM_WALLNUT_BOWLING_2 = 31,
    GM_LITTLE_TROUBLE = 32, GM_SCARY_POTTER_1 = 36, GM_BUNGEE_BLITZ = 45, GM_FINAL_BOSS = 50, GM_I_ZOMBIE_1 = 51, GM_TREE_OF_WISDOM = 52, GM_OTHER = 2 };

struct ChallengeCS { bool mShowBowlingLine; };
struct StoreButtonCS { bool mBtnNoDraw; };
struct BoardCS {
    int mLevel;
    int mPrevBoardResult; // 0=lost/restart 组合桩输入
    bool mShowShovel;
    ChallengeCS* mChallenge;
    StoreButtonCS mStoreButton;
};
struct CutSceneAppStub {
    GameModeCS mGameMode;
    bool mAdventure;
    bool mFirstTimeAdventure;
    int mPurchasesTreeFood;
    bool mHasBeatenScaryPotter1;
    // 派生谓词（由驱动按游戏语义算好）
    bool mWallnutBowling, mWhackAZombie, mLittleTrouble, mScaryPotter, mStormyNight, mBungeeBlitz, mFinalBoss;
    bool mCanPacketUpgrade, mCanSecondPacketUpgrade;

    bool IsAdventureMode() { return mAdventure; }
    bool IsFirstTimeAdventureMode() { return mFirstTimeAdventure; }
    bool IsWallnutBowlingLevel() { return mWallnutBowling; }
    bool IsWhackAZombieLevel() { return mWhackAZombie; }
    bool IsLittleTroubleLevel() { return mLittleTrouble; }
    bool IsScaryPotterLevel() { return mScaryPotter; }
    bool IsStormyNightLevel() { return mStormyNight; }
    bool IsBungeeBlitzLevel() { return mBungeeBlitz; }
    bool IsFinalBossLevel() { return mFinalBoss; }
    bool HasBeatenChallenge(GameModeCS) { return mHasBeatenScaryPotter1; }
};
struct CutSceneStub {
    CutSceneAppStub* mApp;
    BoardCS* mBoard;
    int mCrazyDaveDialogStart;
    bool CanGetPacketUpgrade() { return mApp->mCanPacketUpgrade; }
    bool CanGetSecondPacketUpgrade() { return mApp->mCanSecondPacketUpgrade; }
};

// ================= t10 FormA (36a066a7^) =================
namespace FormA {
__declspec(noinline) void StartLevelIntroDave(CutSceneStub& s)
{
    int aLevel = s.mBoard->mLevel;
    bool isRestart = s.mBoard->mPrevBoardResult != 0;

    if (s.mApp->IsFirstTimeAdventureMode() && aLevel == 11)
    {
        s.mCrazyDaveDialogStart = 201;
    }
    else if (s.mApp->IsFirstTimeAdventureMode() && aLevel == 12)
    {
        s.mCrazyDaveDialogStart = 1401;
    }
    else if (s.mApp->IsFirstTimeAdventureMode() && aLevel >= 13 && aLevel <= 24 && aLevel != 15 && aLevel != 20 && aLevel != 21 && s.CanGetPacketUpgrade())
    {
        s.mCrazyDaveDialogStart = 1501;
    }
    else if (s.mApp->IsFirstTimeAdventureMode() && aLevel >= 16 && aLevel <= 24 && aLevel != 20 && aLevel != 21 && s.CanGetSecondPacketUpgrade())
    {
        s.mCrazyDaveDialogStart = 1551;
    }
    else if (s.mApp->IsWallnutBowlingLevel() && s.mApp->IsAdventureMode())
    {
        if (s.mApp->IsFirstTimeAdventureMode())
        {
            s.mCrazyDaveDialogStart = 2400;
        }
        else
        {
            s.mCrazyDaveDialogStart = 2411;
            s.mBoard->mChallenge->mShowBowlingLine = true;
        }
        s.mBoard->mShowShovel = true;
    }
    else if (s.mApp->IsFirstTimeAdventureMode() && aLevel == 21)
    {
        s.mCrazyDaveDialogStart = 501;
    }
    else if (s.mApp->IsWhackAZombieLevel() && s.mApp->IsAdventureMode())
    {
        s.mCrazyDaveDialogStart = 401;
    }
    else if (s.mApp->IsLittleTroubleLevel() && s.mApp->IsAdventureMode())
    {
        s.mCrazyDaveDialogStart = 701;
    }
    else if (s.mApp->IsFirstTimeAdventureMode() && aLevel == 31)
    {
        s.mCrazyDaveDialogStart = 801;
    }
    else if (s.mApp->IsScaryPotterLevel() && s.mApp->IsAdventureMode())
    {
        s.mCrazyDaveDialogStart = 2500;
    }
    else if (s.mApp->IsStormyNightLevel() && s.mApp->IsAdventureMode())
    {
        s.mCrazyDaveDialogStart = 1101;
    }
    else if (s.mApp->IsFirstTimeAdventureMode() && aLevel == 41)
    {
        s.mCrazyDaveDialogStart = 1201;
    }
    else if (s.mApp->IsBungeeBlitzLevel() && s.mApp->IsAdventureMode())
    {
        s.mCrazyDaveDialogStart = s.mApp->IsFirstTimeAdventureMode() ? 1301 : 1304;
    }
    else if (!s.mApp->IsFirstTimeAdventureMode() && aLevel == 1)
    {
        s.mCrazyDaveDialogStart = 1601;
    }
    else if (s.mApp->mGameMode == GM_I_ZOMBIE_1)
    {
        s.mCrazyDaveDialogStart = 2200;
    }
    else if (s.mApp->mGameMode == GM_SCARY_POTTER_1 && !s.mApp->HasBeatenChallenge(GM_SCARY_POTTER_1))
    {
        s.mCrazyDaveDialogStart = 3000;
    }
    else if (s.mApp->IsFinalBossLevel() && s.mApp->IsAdventureMode() && !isRestart)
    {
        s.mCrazyDaveDialogStart = 2300;
    }
    else if (s.mApp->mGameMode == GM_TREE_OF_WISDOM)
    {
        if (s.mApp->mPurchasesTreeFood < 100)
        {
            s.mCrazyDaveDialogStart = 3200;
            s.mBoard->mStoreButton.mBtnNoDraw = true;
        }
    }
    CS(100); CS((uint64_t)s.mCrazyDaveDialogStart);
}
} // namespace FormA

// ================= t10 FormB (HEAD) =================
namespace FormB {
namespace {
using CrazyDaveDialogFn = void (*)(CutSceneStub&, bool);

void CrazyDaveDialogPacketUpgrade(CutSceneStub& aCutScene, bool)
{
    if (aCutScene.mApp->IsFirstTimeAdventureMode() && aCutScene.CanGetPacketUpgrade())
    {
        aCutScene.mCrazyDaveDialogStart = 1501;
    }
}
void CrazyDaveDialogPacketOrSecond(CutSceneStub& aCutScene, bool)
{
    if (aCutScene.mApp->IsFirstTimeAdventureMode())
    {
        if (aCutScene.CanGetPacketUpgrade())
        {
            aCutScene.mCrazyDaveDialogStart = 1501;
        }
        else if (aCutScene.CanGetSecondPacketUpgrade())
        {
            aCutScene.mCrazyDaveDialogStart = 1551;
        }
    }
}

constexpr CrazyDaveDialogFn kCrazyDaveDialogPerLevel[50] = {
    [](CutSceneStub& s, bool)
    {
        if (!s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 1601; }
    },
    nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool)
    {
        if (s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 2400; }
        else
        {
            s.mCrazyDaveDialogStart = 2411;
            s.mBoard->mChallenge->mShowBowlingLine = true;
        }
        s.mBoard->mShowShovel = true;
    },
    nullptr, nullptr, nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool)
    {
        if (s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 201; }
    },
    [](CutSceneStub& s, bool)
    {
        if (s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 1401; }
    },
    &CrazyDaveDialogPacketUpgrade,
    &CrazyDaveDialogPacketUpgrade,
    [](CutSceneStub& s, bool) { s.mCrazyDaveDialogStart = 401; },
    &CrazyDaveDialogPacketOrSecond, &CrazyDaveDialogPacketOrSecond, &CrazyDaveDialogPacketOrSecond, &CrazyDaveDialogPacketOrSecond,
    nullptr,
    [](CutSceneStub& s, bool)
    {
        if (s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 501; }
    },
    &CrazyDaveDialogPacketOrSecond, &CrazyDaveDialogPacketOrSecond, &CrazyDaveDialogPacketOrSecond,
    [](CutSceneStub& s, bool) { s.mCrazyDaveDialogStart = 701; },
    nullptr, nullptr, nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool)
    {
        if (s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 801; }
    },
    nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool) { s.mCrazyDaveDialogStart = 2500; },
    nullptr, nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool) { s.mCrazyDaveDialogStart = 1101; },
    [](CutSceneStub& s, bool)
    {
        if (s.mApp->IsFirstTimeAdventureMode()) { s.mCrazyDaveDialogStart = 1201; }
    },
    nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool) { s.mCrazyDaveDialogStart = s.mApp->IsFirstTimeAdventureMode() ? 1301 : 1304; },
    nullptr, nullptr, nullptr, nullptr,
    [](CutSceneStub& s, bool aIsRestart)
    {
        if (!aIsRestart) { s.mCrazyDaveDialogStart = 2300; }
    },
};
} // namespace

__declspec(noinline) void StartLevelIntroDave(CutSceneStub& s)
{
    int aLevel = s.mBoard->mLevel;
    bool isRestart = s.mBoard->mPrevBoardResult != 0;

    // C 形态 -> 函数指针表（kCrazyDaveDialogPerLevel）：冒险按 mLevel-1 直下标
    if (s.mApp->IsAdventureMode())
    {
        int aLevelIndex = aLevel - 1;
        if ((unsigned)aLevelIndex < (unsigned)(sizeof(kCrazyDaveDialogPerLevel) / sizeof(kCrazyDaveDialogPerLevel[0])))
        {
            CrazyDaveDialogFn aDialogFn = kCrazyDaveDialogPerLevel[aLevelIndex];
            if (aDialogFn != nullptr)
            {
                aDialogFn(s, isRestart);
            }
        }
    }

    // 表外保留（混排）：3 支纯模式支按原链序
    if (s.mApp->mGameMode == GM_I_ZOMBIE_1)
    {
        s.mCrazyDaveDialogStart = 2200;
    }
    else if (s.mApp->mGameMode == GM_SCARY_POTTER_1 && !s.mApp->HasBeatenChallenge(GM_SCARY_POTTER_1))
    {
        s.mCrazyDaveDialogStart = 3000;
    }
    else if (s.mApp->mGameMode == GM_TREE_OF_WISDOM)
    {
        if (s.mApp->mPurchasesTreeFood < 100)
        {
            s.mCrazyDaveDialogStart = 3200;
            s.mBoard->mStoreButton.mBtnNoDraw = true;
        }
    }
    CS(100); CS((uint64_t)s.mCrazyDaveDialogStart);
}
} // namespace FormB

// ---------------- t11 AddFlowerPots ----------------
static const GameModeCS GM_CHALLENGE_COLUMN = (GameModeCS)35;
static bool g_hasRoof; // StageHasRoof() 输入驱动桩
static bool g_canPlantResult;
static void NewPlantCS(int x, int y)
{
    CS(101); CS((uint64_t)x); CS((uint64_t)y);
    if (g_canPlantResult) { CS(102); CS((uint64_t)x); CS((uint64_t)y); } // CanPlantAt OK -> NewPlant
}

namespace FormA {
__declspec(noinline) void AddFlowerPots(CutSceneStub& s)
{
    int aPotColumns = 0;
    if (s.mBoard->mLevel == 41)
    {
        aPotColumns = 5;
    }
    else if (s.mBoard->mLevel == 42)
    {
        aPotColumns = 4;
    }
    else if (s.mBoard->mLevel >= 43 && s.mBoard->mLevel <= 50)
    {
        aPotColumns = 3;
    }
    else if (s.mApp->mGameMode == GM_CHALLENGE_COLUMN)
    {
        aPotColumns = 8;
    }
    else if (g_hasRoof)
    {
        aPotColumns = 3;
    }

    for (int x = 0; x < aPotColumns; x++)
    {
        for (int y = 0; y < 5; y++)
        {
            NewPlantCS(x, y);
        }
    }
    CS(103); CS((uint64_t)aPotColumns);
}
} // namespace FormA

namespace FormB {
namespace {
constexpr int kFlowerPotColumnsPerLevel[50] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    5,
    4,
    3, 3, 3, 3, 3, 3, 3, 3,
};
} // namespace

__declspec(noinline) void AddFlowerPots(CutSceneStub& s)
{
    int aPotColumns = 0;
    // B 形态 -> 常量表（kFlowerPotColumnsPerLevel）：mLevel-1 直下标
    int aLevelIndex = s.mBoard->mLevel - 1;
    if ((unsigned)aLevelIndex < (unsigned)(sizeof(kFlowerPotColumnsPerLevel) / sizeof(kFlowerPotColumnsPerLevel[0])))
    {
        aPotColumns = kFlowerPotColumnsPerLevel[aLevelIndex];
    }
    if (aPotColumns == 0)
    {
        if (s.mApp->mGameMode == GM_CHALLENGE_COLUMN)
        {
            aPotColumns = 8;
        }
        else if (g_hasRoof)
        {
            aPotColumns = 3;
        }
    }

    for (int x = 0; x < aPotColumns; x++)
    {
        for (int y = 0; y < 5; y++)
        {
            NewPlantCS(x, y);
        }
    }
    CS(103); CS((uint64_t)aPotColumns);
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];
static CutSceneAppStub g_app;
static BoardCS g_boardCs;
static ChallengeCS g_chal;
static CutSceneStub g_cutscene;

typedef void (*DaveFn)(CutSceneStub&);
typedef void (*PotFn)(CutSceneStub&);

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    LCG rng{ 0x1C29CA101C9EE74CULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();
    g_cutscene.mApp = &g_app; g_cutscene.mBoard = &g_boardCs; g_boardCs.mChallenge = &g_chal;

    // t10
    {
        static const GameModeCS modes[8] = { GM_ADVENTURE, GM_WALLNUT_BOWLING, GM_WALLNUT_BOWLING_2,
            GM_SCARY_POTTER_1, GM_I_ZOMBIE_1, GM_TREE_OF_WISDOM, GM_FINAL_BOSS, GM_OTHER };
        auto prep = [&](uint32_t v) {
            bool adventure = ((v >> 0) & 1) != 0;
            GameModeCS mode = adventure ? GM_ADVENTURE : modes[(v >> 20) % 8];
            int level = adventure ? (int)((v >> 2) % 50) + 1 : 0;
            bool ftam = ((v >> 8) & 1) != 0;
            g_app.mAdventure = adventure;
            g_app.mGameMode = mode;
            g_app.mFirstTimeAdventure = ftam;
            g_app.mPurchasesTreeFood = (int)((v >> 10) & 1) ? 105 : 0;
            g_app.mHasBeatenScaryPotter1 = ((v >> 11) & 1) != 0;
            // 派生谓词（游戏语义：重定向谓词 = 模式 || (冒险 && 关卡 X)）
            g_app.mWallnutBowling = (mode == GM_WALLNUT_BOWLING || mode == GM_WALLNUT_BOWLING_2) || (adventure && level == 5);
            g_app.mWhackAZombie = (adventure && level == 15);
            g_app.mLittleTrouble = (mode == GM_LITTLE_TROUBLE) || (adventure && level == 25);
            g_app.mScaryPotter = (mode == GM_SCARY_POTTER_1) || (adventure && level == 35);
            g_app.mStormyNight = (mode == GM_STORMY_NIGHT) || (adventure && level == 40);
            g_app.mBungeeBlitz = (mode == GM_BUNGEE_BLITZ) || (adventure && level == 45);
            g_app.mFinalBoss = (mode == GM_FINAL_BOSS) || (adventure && level == 50);
            g_app.mCanPacketUpgrade = ((v >> 12) & 1) != 0;
            g_app.mCanSecondPacketUpgrade = ((v >> 13) & 1) != 0;
            g_boardCs.mLevel = level;
            g_boardCs.mPrevBoardResult = (int)((v >> 14) & 1);
            g_boardCs.mShowShovel = false;
            g_chal.mShowBowlingLine = false;
            g_boardCs.mStoreButton.mBtnNoDraw = false;
            g_cutscene.mCrazyDaveDialogStart = -1;
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::StartLevelIntroDave(g_cutscene); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::StartLevelIntroDave(g_cutscene); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t10 kCrazyDaveDialogPerLevel(50) StartLevelIntro dave", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t11
    {
        auto prep = [&](uint32_t v) {
            bool adventure = ((v >> 0) & 1) != 0;
            g_app.mAdventure = adventure;
            g_app.mGameMode = adventure ? GM_ADVENTURE : (((v >> 1) & 1) ? GM_CHALLENGE_COLUMN : GM_OTHER);
            g_boardCs.mLevel = adventure ? (int)((v >> 2) % 52) : 0; // 51 = 越界
            g_hasRoof = ((v >> 9) & 1) != 0;
            g_canPlantResult = ((v >> 10) & 1) != 0;
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::AddFlowerPots(g_cutscene); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::AddFlowerPots(g_cutscene); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t11 kFlowerPotColumnsPerLevel(50) AddFlowerPots", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
