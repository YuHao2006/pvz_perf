#include "pvz/time/fixed_step_clock.hpp"
#include "pvz/time/simulation_rate_policy.hpp"

#include <chrono>
#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <stdexcept>

namespace {

using namespace std::chrono_literals;
using pvz::time::ClockConfig;
using pvz::time::FixedStepClock;
using pvz::time::RatePolicyConfig;
using pvz::time::SimulationRatePolicy;

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void require_near(const double actual, const double expected, const char* message)
{
    require(std::abs(actual - expected) < 1e-9, message);
}

void test_200_hz_scheduling_and_semantic_boundaries()
{
    FixedStepClock clock;
    require(clock.tick_interval() == 5ms, "200 Hz must use a 5 ms interval");

    const auto first = clock.advance(16ms);
    require(first.first_tick == 1, "first batch must start at tick 1");
    require(first.tick_count == 3, "16 ms must schedule three 200 Hz ticks");
    require(!first.is_semantic_tick(0), "tick 1 is not a 100 Hz boundary");
    require(first.is_semantic_tick(1), "tick 2 is a 100 Hz boundary");
    require(!first.is_semantic_tick(2), "tick 3 is not a 100 Hz boundary");
    require_near(first.interpolation_alpha, 0.2, "one millisecond must remain for interpolation");

    const auto second = clock.advance(4ms);
    require(second.first_tick == 4, "second batch must continue at tick 4");
    require(second.tick_count == 1, "four more milliseconds must complete one tick");
    require(second.is_semantic_tick(0), "tick 4 is a 100 Hz boundary");
    require_near(second.interpolation_alpha, 0.0, "accumulator must be empty");
}

void test_1000_hz_render_independence()
{
    ClockConfig config;
    config.simulation_hz = 1000;
    FixedStepClock clock{config};

    const auto batch = clock.advance(16'666'667ns);
    require(batch.tick_count == 16, "a 60 Hz render interval must schedule 16 full 1000 Hz ticks");
    require(batch.ticks_per_semantic_tick == 10, "1000 Hz must expose every tenth tick as semantic");
    require(batch.is_semantic_tick(9), "tick 10 must be a semantic boundary");
    require_near(batch.interpolation_alpha, 0.666667, "sub-tick remainder must drive rendering interpolation");
}

void test_every_supported_rate_commits_once_per_ten_milliseconds()
{
    constexpr std::array<std::uint32_t, 5> rates{100, 200, 400, 500, 1000};
    for (const std::uint32_t rate : rates) {
        ClockConfig config;
        config.simulation_hz = rate;
        FixedStepClock clock{config};
        const auto batch = clock.advance(10ms);
        require(batch.tick_count == rate / 100, "each tier must schedule its exact ten-millisecond substep count");

        std::uint32_t semantic_count = 0;
        for (std::uint32_t offset = 0; offset < batch.tick_count; ++offset) {
            if (batch.is_semantic_tick(offset))
                ++semantic_count;
        }
        require(semantic_count == 1, "every supported tier must commit semantics exactly once per ten milliseconds");
        require(batch.is_semantic_tick(batch.tick_count - 1), "the final substep must be the semantic boundary");
    }
}

void test_backlog_is_bounded()
{
    ClockConfig config;
    config.max_steps_per_advance = 2;
    FixedStepClock clock{config};

    const auto batch = clock.advance(100ms);
    require(batch.tick_count == 2, "catch-up work must respect the configured limit");
    require(batch.discarded_time == 90ms, "excess complete ticks must be discarded explicitly");
    require(clock.total_discarded_time() == 90ms, "discarded time must be observable for diagnostics");
}

void test_invalid_rates_are_rejected()
{
    bool rejected = false;
    try {
        ClockConfig config;
        config.simulation_hz = 240;
        [[maybe_unused]] FixedStepClock clock{config};
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "untested simulation rates must be rejected");
}

void test_negative_elapsed_time_is_ignored()
{
    FixedStepClock clock;
    const auto batch = clock.advance(-5ms);
    require(batch.tick_count == 0, "negative elapsed time must not run simulation");
    require_near(batch.interpolation_alpha, 0.0, "negative elapsed time must not change interpolation");
}

void test_rate_policy_selects_requested_fallback_tiers()
{
    RatePolicyConfig config;
    config.requested_hz = 1000;
    config.cpu_budget_percent = 85;
    SimulationRatePolicy policy{config};

    require(policy.decision().selected_hz == 1000, "unmeasured policy must preserve the requested tier");

    policy.observe_tick_cost(500us);
    require(policy.decision().selected_hz == 1000, "a 500 microsecond substep must sustain 1000 Hz");

    policy.reset();
    policy.observe_tick_cost(1ms);
    require(policy.decision().selected_hz == 500, "a 1 ms substep must fall back to 500 Hz");

    policy.reset();
    policy.observe_tick_cost(2ms);
    require(policy.decision().selected_hz == 400, "a 2 ms substep must fall back to 400 Hz");

    policy.reset();
    policy.observe_tick_cost(3ms);
    require(policy.decision().selected_hz == 200, "a 3 ms substep must fall back to 200 Hz");

    policy.reset();
    policy.observe_tick_cost(5ms);
    require(policy.decision().selected_hz == 100, "a 5 ms substep must fall back to the 100 Hz floor");

    policy.reset();
    policy.observe_tick_cost(20ms);
    require(policy.decision().selected_hz == 100, "an overloaded floor must remain the safest available tier");
    require(!policy.decision().within_budget, "an overloaded floor must be reported as over budget");
}

void test_rate_policy_uses_integer_budget_and_rejects_invalid_config()
{
    RatePolicyConfig config;
    config.requested_hz = 500;
    config.minimum_hz = 200;
    config.cpu_budget_percent = 80;
    SimulationRatePolicy policy{config};
    policy.observe_tick_cost(1ms);
    require(policy.decision().selected_hz == 500, "the requested tier must fit an 80 percent budget at 1 ms");
    require(policy.observed_samples() == 1, "one positive cost must produce one observation");
    policy.observe_tick_cost(0ns);
    require(policy.observed_samples() == 1, "zero cost must not distort the moving average");

    bool rejected = false;
    try {
        RatePolicyConfig invalid;
        invalid.requested_hz = 200;
        invalid.minimum_hz = 500;
        [[maybe_unused]] SimulationRatePolicy ignored{invalid};
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "a minimum tier above the requested tier must be rejected");
}

void test_rate_changes_preserve_semantic_boundaries()
{
    ClockConfig config;
    config.simulation_hz = 500;
    FixedStepClock clock{config};

    const auto partial = clock.advance(2ms);
    require(partial.tick_count == 1, "500 Hz must schedule one tick in two milliseconds");
    require(!partial.is_semantic_tick(0), "a partial semantic interval must not commit early");

    bool rejected = false;
    try {
        clock.set_simulation_rate(400);
    } catch (const std::logic_error&) {
        rejected = true;
    }
    require(rejected, "rate changes during a semantic interval must be rejected");

    const auto boundary = clock.advance(8ms);
    require(boundary.tick_count == 4, "the remaining 500 Hz ticks must reach the boundary");
    require(boundary.is_semantic_tick(3), "the fifth 500 Hz tick must be the semantic boundary");
    clock.set_simulation_rate(400);
    require(clock.config().simulation_hz == 400, "a boundary rate change must take effect");
    require(clock.tick_interval() == 2500us, "400 Hz must use a 2.5 ms interval");

    const auto new_rate = clock.advance(10ms);
    require(new_rate.tick_count == 4, "400 Hz must schedule four ticks in ten milliseconds");
    require(!new_rate.is_semantic_tick(0), "the first tick after a rate change must start a new phase");
    require(new_rate.is_semantic_tick(3), "the fourth 400 Hz tick must commit semantics");
}

} // namespace

int main()
{
    test_200_hz_scheduling_and_semantic_boundaries();
    test_1000_hz_render_independence();
    test_every_supported_rate_commits_once_per_ten_milliseconds();
    test_backlog_is_bounded();
    test_invalid_rates_are_rejected();
    test_negative_elapsed_time_is_ignored();
    test_rate_policy_selects_requested_fallback_tiers();
    test_rate_policy_uses_integer_budget_and_rejects_invalid_config();
    test_rate_changes_preserve_semantic_boundaries();
    return EXIT_SUCCESS;
}
