// 验证 GetProjectileRect A/B 差异槽位：逐 type 对比
#define NIN_DBG 64
#include "r2_stub.h"
struct Plant { int mPlantCol, mRow; PlantState mState; int mPlantHealth; int mEatenFlashCountdown; void DoSpecial() {} };
inline Plant g_plantPool[4];
inline int g_pFindPlant = 0, g_pFindZombie = 0;
inline unsigned Rand(unsigned n) { return n ? RngNext() % n : 0u; }
#include "bench_proj_bodies.h"

int main()
{
    for (int t = 0; t <= 15; t++)
    {
        FA::Projectile a; FB::Projectile b;
        for (int k = 0; k < 4; k++)
        {
            a.mX = b.mX = 200 + k * 37; a.mY = b.mY = 150 + k * 53;
            a.mWidth = b.mWidth = 30 + k * 9; a.mHeight = b.mHeight = 40 + k * 7;
            a.mProjectileType = (ProjectileType)t; b.mProjectileType = (ProjectileType)t;
            Rect ra = a.GetProjectileRect(), rb = b.GetProjectileRect();
            if (ra.mX != rb.mX || ra.mY != rb.mY || ra.mWidth != rb.mWidth || ra.mHeight != rb.mHeight)
                printf("type %2d variant %d: A=(%d,%d,%d,%d) B=(%d,%d,%d,%d)  DIFF\n",
                    t, k, ra.mX, ra.mY, ra.mWidth, ra.mHeight, rb.mX, rb.mY, rb.mWidth, rb.mHeight);
        }
    }
    printf("slot scan done\n");
    return 0;
}
