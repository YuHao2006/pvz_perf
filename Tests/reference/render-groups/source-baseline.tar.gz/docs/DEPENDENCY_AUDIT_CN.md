# 外部依赖审计

审计日期：2026-08-24。

本文区分源码中的默认版本、`out/legacy-msvc2` 当前配置实际使用的版本，以及官方最新稳定版。Legacy 的依赖升级必须服从 1073 行为一致性，不能只因为版本号较新就替换。

## 生产路径

| 依赖 | 当前成品 | 官方稳定版 | 实际用途 | 结论 |
|---|---:|---:|---|---|
| Jpegli | Google jpegli `031a007`（2026-06-01） | 同上 | 读取 pak64 中的 JPG；兼容 `jpeglib` API；导出接口可复用 | 已接入 x64 静态端口；不链接 libjpeg-turbo 的实现代码 |
| libjpeg-turbo | 3.2.0（仅头文件兼容依赖） | 3.2.0 | 为 Jpegli 生成兼容的 `jpeglib.h/jconfig.h/jmorecfg.h` | 不作为运行时 JPEG 编解码器；由 jpegli 端口传递依赖 |
| libspng | 0.7.4 | 0.7.4 | 读取和写出 PNG | 已替换 libpng；显式 RGBA8 转换，不依赖旧的隐式 BGR 变换 |
| zlib | 1.3.2 | 1.3.2 | libspng 的 DEFLATE；定义文件模式的 CRC32 | 已是最新 |
| BASS x64 | 2.4.17 | 2.4.18.3 | MO3/OGG 音乐播放 | 保留程序同目录的 x64 `bass.dll` 动态依赖；不做静态链接或 vcpkg 端口。可以升级，但必须连同官方 `bass.h` 一起做音频专项回归 |
| GLFW | 3.4 | 3.4 | Legacy/Modern 的窗口与消息处理 | 已是最新 |
| Tremor | 约 2003 年源码快照 | 无稳定版本号 | DirectSound 音效路径解码 pak64 中的 OGG | Legacy 暂不替换，保持 1073 音效 PCM/时序语义 |
| Highway（构建/运行库） | 1.4.0 | 1.4.0 | Jpegli 的 x64 SIMD 分派 | 由 jpegli overlay port 自动接入 |

当前 pak64 含 2372 个 PNG、71 个 JPG、8 个 GIF、167 个 OGG、2 个 AU 和 2 个 MO3。因此 JPEG、PNG 和 Tremor 都不是可直接删除的死依赖。GIF 和 XML 由项目内置代码处理，不是外部库。

大头贴导出已改为无损 PNG（`Desktop/Zombatar_n.png`）。这只改变导出文件，不改变 pak64 中官方 JPG 资源的读取格式。

## 可升级但需要隔离验证

### Jpegli 031a007

项目仍调用传统 `jpeglib` API，但实际符号来自 Jpegli 的静态实现。Jpegli 保持
JPEG 标准和 libjpeg ABI 兼容，使用更精确的浮点 DCT/色彩转换、自适应量化和
现代 SIMD（Google Highway）。因此 pak64 中的老 JPG 不需要转换，运行时也不需要
新的 DLL。

Jpegli 没有独立的“Guetzli 解码器”：Guetzli 是仅编码器，输出仍是普通 JPEG。
Jpegli 同时提供编码和解码，解码速度目标接近传统 SIMD JPEG 实现，适合本项目
的运行时读图；Guetzli 需要约每 MPix 一分钟 CPU 和约 300 MB/MPix 内存，只适合
离线一次性压缩，故不接入游戏。

验证门槛：

1. 解码 pak64 中全部 71 个 JPG，逐像素 CRC 与旧版本结果比较。
2. 验证渐进式、灰度和普通三通道路径。
3. 验证 Zombatar 导出能成功，并单独校对 1073 的量化表、采样方式和颜色转换语义。库升级不能替代这项 1073 一致性工作。

### libspng 0.7.4

libspng 不是新的 PNG 文件格式；PNG 仍使用标准行滤波器和 DEFLATE。它提供更
小的显式 API，并针对常见真彩色/索引色图片做了解码优化。项目固定使用
`SPNG_FMT_RGBA8`，在边界处检查尺寸溢出，不启用 gamma 变换，以避免改变 1073
资源颜色语义。本机 vcpkg 已有官方 libspng 端口，无需自建端口。

### BASS 2.4.18.3

BASS 是动态加载的。项目决策是保留程序同目录的单个 x64 `bass.dll`，不再尝试静态链接，也不为 BASS 制作 vcpkg overlay port。2.4 系列 API 兼容使升级可行，但它直接位于音乐状态机下面。升级时必须同步官方 DLL 和头文件，并验证：

- 启动、失焦和退出不会修改系统主音量；
- 暂停后从原位置恢复；
- MO3 主音乐、Credits OGG、淡入淡出和无尽模式音轨正确；
- `BASS_GetVersion()` 在启动时与编译头的 `BASSVERSION` 匹配。

已核对 2.4.18.3 x64 DLL 的导出表：当前 `BassLoader` 请求的函数全部仍然存在，
所以二进制 API 层面可替换。官方新 `bass.h` 与仓库内头文件有较多差异，且仓库
头文件包含本项目适配，升级时应合并而不是直接覆盖。

音效目前不是 BASS：`DSoundManager` 使用 Windows DirectSound，OGG 音效由内置 Tremor 解码后写入 DirectSound buffer。

## Modern 构建依赖

Modern 使用 Windows WIC、Vulkan SDK 和 GLFW。GLFW 3.4 已是最新版。机器当前选择 Vulkan SDK 1.4.350.0，官方最新 Windows SDK 为 1.4.357.0；可以更新，但这只影响 Modern 的编译工具、头文件和验证层，不应改变 Legacy，也不应把 SDK DLL 当作游戏运行时捆绑。

## 不应按“升级库”处理的项目

- DirectSound、D3D11、DXGI、D3DCompiler_47、WinMM、Shell32、ImageHlp/DbgHelp、WIC、UCRT 和 VC Runtime 是 Windows/Windows SDK 组件，不是仓库内可跟随 Git tag 更新的第三方库。
- FMOD 源码路径默认不可达，且没有发布 `fmod.dll`；应在确认无 1073 调用后删除，而不是升级。
- DXGL 0.5.27 仅为默认关闭的研究路径，不属于 Legacy 发行物；无需为生产版升级。
- CMake 中的 `d8vk` imported target 没有被链接，是残留声明；应在独立清理中删除。

## 构建可复现性

稳定版本必须固定 tag 或带 SHA-256 的官方源码包，不能跟踪 `main`/`master`。
本项目的 Jpegli overlay 固定到 commit `031a0077...` 并校验 SHA-512；libspng
使用 vcpkg 的固定 0.7.4 版本。

官方来源：

- https://github.com/google/jpegli/commit/031a0077f5799a6041004267fc12b956c1f52a20
- https://github.com/randy408/libspng/releases/tag/v0.7.4
- https://github.com/madler/zlib/releases/tag/v1.3.2
- https://github.com/glfw/glfw/releases/tag/3.4
- https://www.un4seen.com/bass.html
- https://vulkan.lunarg.com/sdk/home
