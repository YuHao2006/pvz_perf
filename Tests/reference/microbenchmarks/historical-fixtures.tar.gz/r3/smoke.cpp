#include "r3_entities.h"
int main()
{
    ZBInitImages(); R3InitZombieDefs(); R3InitFonts(); R3InitInputs();
    printf("smoke ok defs=%d img=%d\n", (int)gZombieDefs[3].mReanimationType, IMAGE_ICETRAP->mId);
    return 0;
}
