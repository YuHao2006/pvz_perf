// bench_credit.cpp -- 目标4/19/20 CreditScreen::UpdateMovie（影片每帧，3 形态归因）
//                    目标21 kKeyJumpRows(17) CreditScreen::KeyChar（按键，冷）
//                    目标22 kMusicOffsetLadder(15) CreditScreen::JumpToFrame（跳转，冷）
// A0 = 403c1968^（相位/音素/脑子全 if-else）；A1 = 36a066a7^（相位 lambda 表 + 音素裸
// constexpr 表，脑子 if-else）；B = HEAD（三表 + 音素补 static）。
// 应触发长链逐字保留（MAIN2 36 项 / MAIN3 13 项）；桩两形态共用、编号入 checksum。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

enum class CreditsPhase { CREDITS_MAIN1 = 0, CREDITS_MAIN2, CREDITS_MAIN3, CREDITS_END };
enum class CreditBrainType { BRAIN_FLY_ON = 0, BRAIN_FAST_ON, BRAIN_NEXT_WORD, BRAIN_FAST_OFF, BRAIN_FLY_OFF, BRAIN_OFF };
enum class CreditWordType { WORD_AA = 0, WORD_EE, WORD_AW, WORD_OH, WORD_OFF };

struct Image { int id; };
static Image g_imgC[16];
static Image* const IMAGE_REANIM_SUNFLOWER_HEAD_WINK = &g_imgC[1];
static Image* const g_SunHeadImgs[6] = { nullptr, &g_imgC[2], &g_imgC[3], &g_imgC[4], &g_imgC[5], &g_imgC[6] };

struct ReanimatorTrackInstance { int mTrackColor; float mShakeOverride; };
struct TodParticleSystem { int mEffectType; void ParticleSystemDie() { CS(200); } void SystemMove(float x, float y) { CS(201); CS((uint64_t)(int)x); } };

struct Reanimation {
    int mLoopCount; float mAnimTime; float mAnimRate; int mFrameCount; int mUpdateTick;
    float mTrigA, mTrigB;
    bool ShouldTriggerTimedEvent(float t) { bool r = mTrigA > t; mTrigA = mTrigB; return r; }
    void Update() { mUpdateTick++; CS(100); }
    ReanimatorTrackInstance* GetTrackInstanceByName(int id) { CS(101); CS((uint64_t)id); static ReanimatorTrackInstance t[8]; return &t[id & 7]; }
    void SetImageOverride(int track, Image* img) { CS(102); CS((uint64_t)track); CS(img ? (uint64_t)img->id : 9999); }
    int FindTrackIndex(int id) { CS(103); return id; }
    void GetCurrentTransform(int idx, void* t) { CS(104); }
};

struct CreditsTiming { CreditBrainType mBrainType; CreditWordType mWordType; float mWordX; float mFrame; };
struct EffectSystem { void Update() { CS(105); } void EffectSystemFreeAll() { CS(106); } };
struct PoolEffect { void PoolEffectUpdate() { CS(107); } };
struct MusicSystem { void PlayFromOffset(int file, int off, float rate) { CS(108); CS((uint64_t)off); } };
struct Button { void SetVisible(bool v) { CS(109); CS(v); } };
struct Timer { void SetStartTime(int ms) { CS(110); CS((uint64_t)ms); } };

struct AppStub {
    EffectSystem* mEffectSystem; PoolEffect* mPoolEffect; MusicSystem* mMusic;
    TodParticleSystem* mParticles; int mParticleCount;
    void AddTodParticle(float x, float y, int layer, int effect) { CS(111); CS((uint64_t)effect); CS((uint64_t)(int)x); }
    void PlayFoley(int f) { CS(112); CS((uint64_t)f); }
    void StopFoley(int f) { CS(117); }
    Reanimation* FindSubReanim(Reanimation* r, int type) { CS(113); return (r->mLoopCount & 1) ? r : nullptr; }
    TodParticleSystem* ParticleTryToGet(int id) { CS(120); return (id & 1) ? mParticles : nullptr; }
    int ParticleGetID(TodParticleSystem* p) { CS(119); return p->mEffectType & 1; }
};

struct CreditScreenStub {
    AppStub* mApp;
    CreditsPhase mCreditsPhase; int mCreditsPhaseCounter;
    float mBrainPosX, mBrainPosY; bool mDrawBrain;
    bool mCreditsPaused, mDontSync;
    Button* mMainMenuButton; Button* mReplayButton;
    Timer mTimerSinceStart;
    int mCreditsReanimID; int mFogParticleID;
    Reanimation* mReanimPool; // ReanimationGet 返回
    Reanimation* PlayReanim(int idx) { CS(114); CS((uint64_t)idx); return mReanimPool; }
    void UpdateBlink() { CS(115); }
    void TurnOffTongues(Reanimation* r, int p) { CS(116); }
    Reanimation* GetReanim() { return mReanimPool; }
    void GetTiming(CreditsTiming** before, CreditsTiming** after, float* frac);
};

namespace Curves { enum E { Linear, EaseInOut, BounceFastMiddle }; }
static float CurveFn(int c, float t)
{
    if (c == Curves::EaseInOut) { return t < 0.5f ? 2 * t * t : 1 - 2 * (1 - t) * (1 - t); }
    if (c == Curves::BounceFastMiddle) { return t * t * (3 - 2 * t); }
    return t;
}
static float TodAnimateCurveFloatTime(float a, float b, float v, float c, float d, int curve)
{
    float t = (v - a) / (b - a); if (t < 0) t = 0; if (t > 1) t = 1;
    return c + (d - c) * CurveFn(curve, t);
}
static float g_fracInput;
static CreditsTiming g_timingIn[2];
void CreditScreenStub::GetTiming(CreditsTiming** before, CreditsTiming** after, float* frac)
{
    *before = &g_timingIn[0]; *after = &g_timingIn[1]; *frac = g_fracInput;
}

#define BOARD_WIDTH 800
#define BOARD_HEIGHT 600

// ============ A0 = 403c1968^ UpdateMovie ============
namespace A0 {
__declspec(noinline) void UpdateMovie(CreditScreenStub& s)
{
    s.UpdateBlink();
    Reanimation* aCreditsReanim = s.GetReanim();
    float aFrameFactor = 1.0f / 17.0f;
    aCreditsReanim->Update();
    s.mApp->mEffectSystem->Update();
    s.mApp->mPoolEffect->PoolEffectUpdate();
    s.TurnOffTongues(aCreditsReanim, 0);

    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN1 && aCreditsReanim->mLoopCount > 0)
    { aCreditsReanim = s.PlayReanim(2); s.mCreditsPhase = CreditsPhase::CREDITS_MAIN2; }
    else if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 && aCreditsReanim->mLoopCount > 0)
    { aCreditsReanim = s.PlayReanim(3); s.mCreditsPhase = CreditsPhase::CREDITS_MAIN3; }
    else if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mLoopCount > 0)
    { s.mCreditsPhase = CreditsPhase::CREDITS_END; }
    else if (s.mCreditsPhase == CreditsPhase::CREDITS_END)
    {
        s.mCreditsPhaseCounter++;
        if (s.mCreditsPhaseCounter == 50) { s.mMainMenuButton->SetVisible(true); s.mReplayButton->SetVisible(true); }
    }

    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN1)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 128.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 130.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 132.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 134.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 138.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 140.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 142.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.5f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 22); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 330.0f))
        { s.mApp->PlayFoley(3); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        { s.mApp->StopFoley(3); }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 || s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        ReanimatorTrackInstance* aTrackWords1 = aCreditsReanim->GetTrackInstanceByName(1);
        ReanimatorTrackInstance* aTrackWords2 = aCreditsReanim->GetTrackInstanceByName(2);
        if (aCreditsReanim->mAnimTime < aFrameFactor * 124.0f) { aTrackWords1->mTrackColor = 0; aTrackWords2->mTrackColor = 0; }
        else { aTrackWords1->mTrackColor = 1; aTrackWords2->mTrackColor = 1; }
        Reanimation* aUndeadReanim = s.mApp->FindSubReanim(aCreditsReanim, 4);
        if (aUndeadReanim)
        {
            ReanimatorTrackInstance* u1 = aUndeadReanim->GetTrackInstanceByName(5);
            ReanimatorTrackInstance* u2 = aUndeadReanim->GetTrackInstanceByName(6);
            ReanimatorTrackInstance* u3 = aUndeadReanim->GetTrackInstanceByName(7);
            u1->mTrackColor = 0; u2->mTrackColor = 0; u3->mTrackColor = 0;
            ReanimatorTrackInstance* shk = aUndeadReanim->GetTrackInstanceByName(8);
            if (aCreditsReanim->mAnimTime > aFrameFactor * 112.0f) shk->mShakeOverride = 2.0f;
            else shk->mShakeOverride = 0.0f;
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 120.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 23); }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 125.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 127.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 131.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 135.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 139.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 143.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 147.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 151.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 155.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 159.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 163.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 167.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 171.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 175.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 179.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 183.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 187.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 191.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 195.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 199.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 203.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 207.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 211.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 215.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.5f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 332.75f))
        { s.mApp->AddTodParticle(678.0f, 352.0f, 3, 24); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        { CS(118); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 342.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        int aBackground2Index = aCreditsReanim->FindTrackIndex(9);
        ReanimatorTrackInstance aTransformBackground2{};
        aCreditsReanim->GetCurrentTransform(aBackground2Index, &aTransformBackground2);
        float aFogPosX = 856.0f;
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 188.0f))
        { TodParticleSystem* p = s.mApp->mParticles; s.mFogParticleID = s.mApp->ParticleGetID(p); }
        TodParticleSystem* aFogParticle = s.mApp->ParticleTryToGet(s.mFogParticleID);
        if (aFogParticle)
        {
            if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 248.0f))
            { aFogParticle->ParticleSystemDie(); s.mFogParticleID = 0; }
            else
            { aFogParticle->SystemMove(aFogPosX, 230.0f); }
        }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 65.0f))
        { s.mApp->PlayFoley(4); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 247.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
    }

    float aFraction;
    CreditsTiming* aBeforeTiming; CreditsTiming* aAfterTiming;
    s.GetTiming(&aBeforeTiming, &aAfterTiming, &aFraction);
    int aSunflowerFrame = 0;
    s.mDrawBrain = false;
    if (aBeforeTiming && aAfterTiming)
    {
        if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, -50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aAfterTiming->mWordX - 50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 485.0f, 505.0f, Curves::EaseInOut);
            s.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_OFF)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, 850.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_OFF)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aBeforeTiming->mWordX + 25.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::EaseInOut);
            s.mDrawBrain = true;
        }
        else if (aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_NEXT_WORD)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }

        float aFramesForWord = aAfterTiming->mFrame - aBeforeTiming->mFrame;
        float aFramesTillEnd = (1.0f - aFraction) * aFramesForWord;
        if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesForWord * aFraction < 0.2f)
            aSunflowerFrame = 1;
        else if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesTillEnd < 0.4f)
            aSunflowerFrame = 1;
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_AA)
            aSunflowerFrame = 2;
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_EE)
            aSunflowerFrame = 3;
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_AW)
            aSunflowerFrame = 4;
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_OH)
            aSunflowerFrame = 5;
    }

    Reanimation* aSunFlowerReanim = s.mApp->FindSubReanim(aCreditsReanim, 10);
    if (aSunFlowerReanim)
    {
        if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mAnimTime > aFrameFactor * 255.0f)
        {
            aSunFlowerReanim->SetImageOverride(11, IMAGE_REANIM_SUNFLOWER_HEAD_WINK);
            aSunFlowerReanim->mAnimTime -= 0.01f;
            CS(118);
        }
        else
        {
            Image* aHeadOverride = static_cast<unsigned>(aSunflowerFrame) < static_cast<unsigned>(6)
                ? g_SunHeadImgs[aSunflowerFrame] : nullptr;
            aSunFlowerReanim->SetImageOverride(11, aHeadOverride);
        }
    }
    CS((uint64_t)(aSunflowerFrame + 1000));
    CS((uint64_t)(int)(s.mBrainPosX * 1000.0f));
    CS((uint64_t)(int)(s.mBrainPosY * 1000.0f));
}
} // namespace A0

// ============ 共用：A1/B 的前段（相位段起）与尾段差异在各自命名空间 ============
// A1 = 36a066a7^：相位 lambda 表 + 音素裸 constexpr 表 + 脑子 if-else
namespace A1 {
namespace {
using CreditsPhaseFn = void (*)(CreditScreenStub&, Reanimation*&);
constexpr CreditsPhaseFn kCreditsPhaseCases[(int)CreditsPhase::CREDITS_END + 1] = {
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0) { aCreditsReanim = s.PlayReanim(2); s.mCreditsPhase = CreditsPhase::CREDITS_MAIN2; }
    },
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0) { aCreditsReanim = s.PlayReanim(3); s.mCreditsPhase = CreditsPhase::CREDITS_MAIN3; }
    },
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0) { s.mCreditsPhase = CreditsPhase::CREDITS_END; }
    },
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        (void)aCreditsReanim;
        s.mCreditsPhaseCounter++;
        if (s.mCreditsPhaseCounter == 50) { s.mMainMenuButton->SetVisible(true); s.mReplayButton->SetVisible(true); }
    },
};
} // namespace

__declspec(noinline) void UpdateMovie(CreditScreenStub& s)
{
    s.UpdateBlink();
    Reanimation* aCreditsReanim = s.GetReanim();
    float aFrameFactor = 1.0f / 17.0f;
    aCreditsReanim->Update();
    s.mApp->mEffectSystem->Update();
    s.mApp->mPoolEffect->PoolEffectUpdate();
    s.TurnOffTongues(aCreditsReanim, 0);

    const unsigned aPhaseIndex = static_cast<unsigned>(s.mCreditsPhase);
    if (aPhaseIndex <= static_cast<unsigned>(CreditsPhase::CREDITS_END))
    {
        kCreditsPhaseCases[aPhaseIndex](s, aCreditsReanim);
    }

    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN1)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 128.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 130.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 132.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 134.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 138.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 140.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 142.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.5f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 22); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 330.0f))
        { s.mApp->PlayFoley(3); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        { s.mApp->StopFoley(3); }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 || s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        ReanimatorTrackInstance* aTrackWords1 = aCreditsReanim->GetTrackInstanceByName(1);
        ReanimatorTrackInstance* aTrackWords2 = aCreditsReanim->GetTrackInstanceByName(2);
        if (aCreditsReanim->mAnimTime < aFrameFactor * 124.0f) { aTrackWords1->mTrackColor = 0; aTrackWords2->mTrackColor = 0; }
        else { aTrackWords1->mTrackColor = 1; aTrackWords2->mTrackColor = 1; }
        Reanimation* aUndeadReanim = s.mApp->FindSubReanim(aCreditsReanim, 4);
        if (aUndeadReanim)
        {
            ReanimatorTrackInstance* u1 = aUndeadReanim->GetTrackInstanceByName(5);
            ReanimatorTrackInstance* u2 = aUndeadReanim->GetTrackInstanceByName(6);
            ReanimatorTrackInstance* u3 = aUndeadReanim->GetTrackInstanceByName(7);
            u1->mTrackColor = 0; u2->mTrackColor = 0; u3->mTrackColor = 0;
            ReanimatorTrackInstance* shk = aUndeadReanim->GetTrackInstanceByName(8);
            if (aCreditsReanim->mAnimTime > aFrameFactor * 112.0f) shk->mShakeOverride = 2.0f;
            else shk->mShakeOverride = 0.0f;
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 120.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 23); }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 125.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 127.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 131.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 135.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 139.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 143.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 147.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 151.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 155.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 159.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 163.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 167.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 171.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 175.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 179.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 183.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 187.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 191.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 195.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 199.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 203.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 207.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 211.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 215.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.5f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 332.75f))
        { s.mApp->AddTodParticle(678.0f, 352.0f, 3, 24); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        { CS(118); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 342.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        int aBackground2Index = aCreditsReanim->FindTrackIndex(9);
        ReanimatorTrackInstance aTransformBackground2{};
        aCreditsReanim->GetCurrentTransform(aBackground2Index, &aTransformBackground2);
        float aFogPosX = 856.0f;
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 188.0f))
        { TodParticleSystem* p = s.mApp->mParticles; s.mFogParticleID = s.mApp->ParticleGetID(p); }
        TodParticleSystem* aFogParticle = s.mApp->ParticleTryToGet(s.mFogParticleID);
        if (aFogParticle)
        {
            if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 248.0f))
            { aFogParticle->ParticleSystemDie(); s.mFogParticleID = 0; }
            else
            { aFogParticle->SystemMove(aFogPosX, 230.0f); }
        }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 65.0f))
        { s.mApp->PlayFoley(4); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 247.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
    }

    float aFraction;
    CreditsTiming* aBeforeTiming; CreditsTiming* aAfterTiming;
    s.GetTiming(&aBeforeTiming, &aAfterTiming, &aFraction);
    int aSunflowerFrame = 0;
    s.mDrawBrain = false;
    if (aBeforeTiming && aAfterTiming)
    {
        if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, -50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aAfterTiming->mWordX - 50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 485.0f, 505.0f, Curves::EaseInOut);
            s.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_OFF)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, 850.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_OFF)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aBeforeTiming->mWordX + 25.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::EaseInOut);
            s.mDrawBrain = true;
        }
        else if (aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_NEXT_WORD)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }

        float aFramesForWord = aAfterTiming->mFrame - aBeforeTiming->mFrame;
        float aFramesTillEnd = (1.0f - aFraction) * aFramesForWord;
        constexpr uint8_t kWordPhonemeFrames[(int)CreditWordType::WORD_OFF + 1] = {
            2, 3, 4, 5, 0,
        };
        if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesForWord * aFraction < 0.2f)
            aSunflowerFrame = 1;
        else if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesTillEnd < 0.4f)
            aSunflowerFrame = 1;
        else if ((unsigned)aBeforeTiming->mWordType <= (unsigned)CreditWordType::WORD_OFF)
        {
            aSunflowerFrame = kWordPhonemeFrames[(int)aBeforeTiming->mWordType];
        }
    }

    Reanimation* aSunFlowerReanim = s.mApp->FindSubReanim(aCreditsReanim, 10);
    if (aSunFlowerReanim)
    {
        if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mAnimTime > aFrameFactor * 255.0f)
        {
            aSunFlowerReanim->SetImageOverride(11, IMAGE_REANIM_SUNFLOWER_HEAD_WINK);
            aSunFlowerReanim->mAnimTime -= 0.01f;
            CS(118);
        }
        else
        {
            Image* aHeadOverride = static_cast<unsigned>(aSunflowerFrame) < static_cast<unsigned>(6)
                ? g_SunHeadImgs[aSunflowerFrame] : nullptr;
            aSunFlowerReanim->SetImageOverride(11, aHeadOverride);
        }
    }
    CS((uint64_t)(aSunflowerFrame + 1000));
    CS((uint64_t)(int)(s.mBrainPosX * 1000.0f));
    CS((uint64_t)(int)(s.mBrainPosY * 1000.0f));
}
} // namespace A1

// B = HEAD：相位 lambda 表 + 音素 static constexpr 表 + 脑子 lambda 表
namespace B {
namespace {
using CreditsPhaseFn = void (*)(CreditScreenStub&, Reanimation*&);
constexpr CreditsPhaseFn kCreditsPhaseCases[(int)CreditsPhase::CREDITS_END + 1] = {
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0) { aCreditsReanim = s.PlayReanim(2); s.mCreditsPhase = CreditsPhase::CREDITS_MAIN2; }
    },
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0) { aCreditsReanim = s.PlayReanim(3); s.mCreditsPhase = CreditsPhase::CREDITS_MAIN3; }
    },
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0) { s.mCreditsPhase = CreditsPhase::CREDITS_END; }
    },
    [](CreditScreenStub& s, Reanimation*& aCreditsReanim)
    {
        (void)aCreditsReanim;
        s.mCreditsPhaseCounter++;
        if (s.mCreditsPhaseCounter == 50) { s.mMainMenuButton->SetVisible(true); s.mReplayButton->SetVisible(true); }
    },
};
using BrainMoveFn = void (*)(CreditScreenStub&, const CreditsTiming*, const CreditsTiming*, float);
constexpr BrainMoveFn kBrainMoveCases[(int)CreditBrainType::BRAIN_OFF + 1] = {
    [](CreditScreenStub& s, const CreditsTiming*, const CreditsTiming* aAfterTiming, float aFraction)
    {
        s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, -50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
        s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
        s.mDrawBrain = true;
    },
    [](CreditScreenStub& s, const CreditsTiming*, const CreditsTiming* aAfterTiming, float aFraction)
    {
        s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aAfterTiming->mWordX - 50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
        s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 485.0f, 505.0f, Curves::EaseInOut);
        s.mDrawBrain = true;
    },
    nullptr,
    [](CreditScreenStub& s, const CreditsTiming* aBeforeTiming, const CreditsTiming*, float aFraction)
    {
        s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aBeforeTiming->mWordX + 25.0f, Curves::EaseInOut);
        s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::EaseInOut);
        s.mDrawBrain = true;
    },
    [](CreditScreenStub& s, const CreditsTiming* aBeforeTiming, const CreditsTiming*, float aFraction)
    {
        s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, 850.0f, Curves::EaseInOut);
        s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
        s.mDrawBrain = true;
    },
    nullptr,
};
} // namespace

__declspec(noinline) void UpdateMovie(CreditScreenStub& s)
{
    s.UpdateBlink();
    Reanimation* aCreditsReanim = s.GetReanim();
    float aFrameFactor = 1.0f / 17.0f;
    aCreditsReanim->Update();
    s.mApp->mEffectSystem->Update();
    s.mApp->mPoolEffect->PoolEffectUpdate();
    s.TurnOffTongues(aCreditsReanim, 0);

    const unsigned aPhaseIndex = static_cast<unsigned>(s.mCreditsPhase);
    if (aPhaseIndex <= static_cast<unsigned>(CreditsPhase::CREDITS_END))
    {
        kCreditsPhaseCases[aPhaseIndex](s, aCreditsReanim);
    }

    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN1)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 128.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 130.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 132.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 134.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 138.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 140.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 142.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.5f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 22); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 330.0f))
        { s.mApp->PlayFoley(3); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        { s.mApp->StopFoley(3); }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 || s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        ReanimatorTrackInstance* aTrackWords1 = aCreditsReanim->GetTrackInstanceByName(1);
        ReanimatorTrackInstance* aTrackWords2 = aCreditsReanim->GetTrackInstanceByName(2);
        if (aCreditsReanim->mAnimTime < aFrameFactor * 124.0f) { aTrackWords1->mTrackColor = 0; aTrackWords2->mTrackColor = 0; }
        else { aTrackWords1->mTrackColor = 1; aTrackWords2->mTrackColor = 1; }
        Reanimation* aUndeadReanim = s.mApp->FindSubReanim(aCreditsReanim, 4);
        if (aUndeadReanim)
        {
            ReanimatorTrackInstance* u1 = aUndeadReanim->GetTrackInstanceByName(5);
            ReanimatorTrackInstance* u2 = aUndeadReanim->GetTrackInstanceByName(6);
            ReanimatorTrackInstance* u3 = aUndeadReanim->GetTrackInstanceByName(7);
            u1->mTrackColor = 0; u2->mTrackColor = 0; u3->mTrackColor = 0;
            ReanimatorTrackInstance* shk = aUndeadReanim->GetTrackInstanceByName(8);
            if (aCreditsReanim->mAnimTime > aFrameFactor * 112.0f) shk->mShakeOverride = 2.0f;
            else shk->mShakeOverride = 0.0f;
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 120.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 23); }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN2)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 125.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 127.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 131.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 135.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 139.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 143.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 147.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 151.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 155.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 159.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 163.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 167.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 171.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 175.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 179.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 183.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 187.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 191.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 195.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 199.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 203.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 207.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 211.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 215.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.5f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 332.75f))
        { s.mApp->AddTodParticle(678.0f, 352.0f, 3, 24); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        { CS(118); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 342.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
        int aBackground2Index = aCreditsReanim->FindTrackIndex(9);
        ReanimatorTrackInstance aTransformBackground2{};
        aCreditsReanim->GetCurrentTransform(aBackground2Index, &aTransformBackground2);
        float aFogPosX = 856.0f;
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 188.0f))
        { TodParticleSystem* p = s.mApp->mParticles; s.mFogParticleID = s.mApp->ParticleGetID(p); }
        TodParticleSystem* aFogParticle = s.mApp->ParticleTryToGet(s.mFogParticleID);
        if (aFogParticle)
        {
            if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 248.0f))
            { aFogParticle->ParticleSystemDie(); s.mFogParticleID = 0; }
            else
            { aFogParticle->SystemMove(aFogPosX, 230.0f); }
        }
    }
    if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 65.0f))
        { s.mApp->PlayFoley(4); }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 247.0f))
        { s.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, 3, 21); }
    }

    float aFraction;
    CreditsTiming* aBeforeTiming; CreditsTiming* aAfterTiming;
    s.GetTiming(&aBeforeTiming, &aAfterTiming, &aFraction);
    int aSunflowerFrame = 0;
    s.mDrawBrain = false;
    if (aBeforeTiming && aAfterTiming)
    {
        BrainMoveFn aBrainMove = nullptr;
        const unsigned anAfterBrainIndex = (unsigned)aAfterTiming->mBrainType;
        if (anAfterBrainIndex < sizeof(kBrainMoveCases) / sizeof(kBrainMoveCases[0]))
        {
            aBrainMove = kBrainMoveCases[anAfterBrainIndex];
        }
        if (aBrainMove != nullptr)
        {
            aBrainMove(s, aBeforeTiming, aAfterTiming, aFraction);
        }
        else if (aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON ||
            aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON ||
            aBeforeTiming->mBrainType == CreditBrainType::BRAIN_NEXT_WORD)
        {
            s.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            s.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            s.mDrawBrain = true;
        }

        float aFramesForWord = aAfterTiming->mFrame - aBeforeTiming->mFrame;
        float aFramesTillEnd = (1.0f - aFraction) * aFramesForWord;
        static constexpr uint8_t kWordPhonemeFrames[(int)CreditWordType::WORD_OFF + 1] = {
            2, 3, 4, 5, 0,
        };
        if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesForWord * aFraction < 0.2f)
            aSunflowerFrame = 1;
        else if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesTillEnd < 0.4f)
            aSunflowerFrame = 1;
        else if ((unsigned)aBeforeTiming->mWordType <= (unsigned)CreditWordType::WORD_OFF)
        {
            aSunflowerFrame = kWordPhonemeFrames[(int)aBeforeTiming->mWordType];
        }
    }

    Reanimation* aSunFlowerReanim = s.mApp->FindSubReanim(aCreditsReanim, 10);
    if (aSunFlowerReanim)
    {
        if (s.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mAnimTime > aFrameFactor * 255.0f)
        {
            aSunFlowerReanim->SetImageOverride(11, IMAGE_REANIM_SUNFLOWER_HEAD_WINK);
            aSunFlowerReanim->mAnimTime -= 0.01f;
            CS(118);
        }
        else
        {
            Image* aHeadOverride = static_cast<unsigned>(aSunflowerFrame) < static_cast<unsigned>(6)
                ? g_SunHeadImgs[aSunflowerFrame] : nullptr;
            aSunFlowerReanim->SetImageOverride(11, aHeadOverride);
        }
    }
    CS((uint64_t)(aSunflowerFrame + 1000));
    CS((uint64_t)(int)(s.mBrainPosX * 1000.0f));
    CS((uint64_t)(int)(s.mBrainPosY * 1000.0f));
}
} // namespace B

// ============ KeyChar / JumpToFrame（before = A0 403c1968^, after = B HEAD）============
namespace A0 {
__declspec(noinline) void JumpToFrame(CreditScreenStub& s, CreditsPhase thePhase, float theFrame)
{
    s.mMainMenuButton->SetVisible(false);
    s.mReplayButton->SetVisible(false);
    s.mCreditsPhaseCounter = 0;
    s.mApp->mEffectSystem->EffectSystemFreeAll();
    Reanimation* aReanim;
    if (thePhase == CreditsPhase::CREDITS_END) aReanim = s.PlayReanim(3);
    else aReanim = s.PlayReanim((int)thePhase + 1);
    float aFrameFactor = 1.0f / 17.0f;
    int aMusicOffset = (int)(theFrame * 12142.0f);
    int aJumpMilliseconds = (int)(theFrame * 1000.0f / 7.0f);
    if (thePhase == CreditsPhase::CREDITS_MAIN1)
    {
        if (theFrame >= 368.0f) aMusicOffset = (int)(12142.0f * (theFrame - 368.0f) + 4634474.0f);
        else if (theFrame >= 340.0f) aMusicOffset = (int)(12142.0f * (theFrame - 340.0f) + 4280738.0f);
        else if (theFrame >= 304.0f) aMusicOffset = (int)(12142.0f * (theFrame - 304.0f) + 3825710.0f);
        else if (theFrame >= 272.0f) aMusicOffset = (int)(12142.0f * (theFrame - 272.0f) + 3421764.0f);
        else if (theFrame >= 144.0f) aMusicOffset = (int)(12142.0f * (theFrame - 144.0f) + 1805688.0f);
        else if (theFrame >= 128.0f) aMusicOffset = (int)(12142.0f * (theFrame - 128.0f) + 1603662.0f);
    }
    else if (thePhase == CreditsPhase::CREDITS_MAIN2)
    {
        if (theFrame >= 320.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 320.0f) + 9069118.0f); aJumpMilliseconds += 57142; }
        else if (theFrame >= 248.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 248.0f) + 8159850.0f); aJumpMilliseconds += 57142; }
        else if (theFrame >= 188.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 188.0f) + 7401454.0f); aJumpMilliseconds += 57142; }
        else if (theFrame >= 124.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 124.0f) + 6593548.0f); aJumpMilliseconds += 57142; }
        else { aMusicOffset = (int)(12142.0f * theFrame + 5026370.0f); aJumpMilliseconds += 57142; }
    }
    else if (thePhase == CreditsPhase::CREDITS_MAIN3)
    {
        if (theFrame >= 240.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 240.0f) + 12897822.0f); aJumpMilliseconds += 112000; }
        else if (theFrame >= 216.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 216.0f) + 12594510.0f); aJumpMilliseconds += 112000; }
        else if (theFrame >= 124.0f) { aMusicOffset = (int)(12142.0f * (theFrame - 124.0f) + 11434414.0f); aJumpMilliseconds += 112000; }
        else { aMusicOffset = (int)(12142.0f * theFrame + 9864866.0f); aJumpMilliseconds += 112000; }
    }
    else if (thePhase == CreditsPhase::CREDITS_END)
    {
        aMusicOffset = 14047138;
        aJumpMilliseconds += 159142;
    }
    s.mApp->mMusic->PlayFromOffset(1, aMusicOffset - 900, 1.0f);
    if (thePhase == CreditsPhase::CREDITS_END) aReanim->mAnimTime = 1.0f;
    else aReanim->mAnimTime = aFrameFactor * theFrame;
    s.mCreditsPhase = thePhase;
    s.mTimerSinceStart.SetStartTime(aJumpMilliseconds);
}
__declspec(noinline) void KeyChar(CreditScreenStub& s, char theChar)
{
    if (s.mCreditsPaused) return;
    if (theChar == ('1')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 0.0f); return; }
    else if (theChar == ('2')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 128.0f); return; }
    else if (theChar == ('3')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 144.0f); return; }
    else if (theChar == ('4')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 272.0f); return; }
    else if (theChar == ('5')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 304.0f); return; }
    else if (theChar == ('6')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 340.0f); return; }
    else if (theChar == ('7')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN1, 368.0f); return; }
    else if (theChar == ('q')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN2, 0.0f); return; }
    else if (theChar == ('w')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN2, 124.0f); return; }
    else if (theChar == ('e')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN2, 188.0f); return; }
    else if (theChar == ('r')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN2, 248.0f); return; }
    else if (theChar == ('t')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN2, 320.0f); return; }
    else if (theChar == ('a')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN3, 0.0f); return; }
    else if (theChar == ('s')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN3, 124.0f); return; }
    else if (theChar == ('d')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN3, 216.0f); return; }
    else if (theChar == ('f')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN3, 240.0f); return; }
    else if (theChar == ('g')) { JumpToFrame(s, CreditsPhase::CREDITS_MAIN3, 324.0f); return; }
    else if (theChar == ('n')) { s.mDontSync = !s.mDontSync; }
}
} // namespace A0

namespace B {
__declspec(noinline) void JumpToFrame(CreditScreenStub& s, CreditsPhase thePhase, float theFrame)
{
    s.mMainMenuButton->SetVisible(false);
    s.mReplayButton->SetVisible(false);
    s.mCreditsPhaseCounter = 0;
    s.mApp->mEffectSystem->EffectSystemFreeAll();
    Reanimation* aReanim;
    if (thePhase == CreditsPhase::CREDITS_END) aReanim = s.PlayReanim(3);
    else aReanim = s.PlayReanim((int)thePhase + 1);
    float aFrameFactor = 1.0f / 17.0f;
    int aMusicOffset = (int)(theFrame * 12142.0f);
    int aJumpMilliseconds = (int)(theFrame * 1000.0f / 7.0f);
    static constexpr struct { CreditsPhase mPhase; float mAnchor; float mBase; int mJumpAdd; } kMusicOffsetLadder[] = {
        { CreditsPhase::CREDITS_MAIN1, 368.0f, 4634474.0f, 0 },
        { CreditsPhase::CREDITS_MAIN1, 340.0f, 4280738.0f, 0 },
        { CreditsPhase::CREDITS_MAIN1, 304.0f, 3825710.0f, 0 },
        { CreditsPhase::CREDITS_MAIN1, 272.0f, 3421764.0f, 0 },
        { CreditsPhase::CREDITS_MAIN1, 144.0f, 1805688.0f, 0 },
        { CreditsPhase::CREDITS_MAIN1, 128.0f, 1603662.0f, 0 },
        { CreditsPhase::CREDITS_MAIN2, 320.0f, 9069118.0f, 57142 },
        { CreditsPhase::CREDITS_MAIN2, 248.0f, 8159850.0f, 57142 },
        { CreditsPhase::CREDITS_MAIN2, 188.0f, 7401454.0f, 57142 },
        { CreditsPhase::CREDITS_MAIN2, 124.0f, 6593548.0f, 57142 },
        { CreditsPhase::CREDITS_MAIN2, 0.0f,   5026370.0f, 57142 },
        { CreditsPhase::CREDITS_MAIN3, 240.0f, 12897822.0f, 112000 },
        { CreditsPhase::CREDITS_MAIN3, 216.0f, 12594510.0f, 112000 },
        { CreditsPhase::CREDITS_MAIN3, 124.0f, 11434414.0f, 112000 },
        { CreditsPhase::CREDITS_MAIN3, 0.0f,   9864866.0f, 112000 },
    };
    if (thePhase == CreditsPhase::CREDITS_END)
    {
        aMusicOffset = 14047138;
        aJumpMilliseconds += 159142;
    }
    else
    {
        for (const auto& aRow : kMusicOffsetLadder)
        {
            if (aRow.mPhase == thePhase && theFrame >= aRow.mAnchor)
            {
                aMusicOffset = (int)(12142.0f * (theFrame - aRow.mAnchor) + aRow.mBase);
                aJumpMilliseconds += aRow.mJumpAdd;
                break;
            }
        }
    }
    s.mApp->mMusic->PlayFromOffset(1, aMusicOffset - 900, 1.0f);
    if (thePhase == CreditsPhase::CREDITS_END) aReanim->mAnimTime = 1.0f;
    else aReanim->mAnimTime = aFrameFactor * theFrame;
    s.mCreditsPhase = thePhase;
    s.mTimerSinceStart.SetStartTime(aJumpMilliseconds);
}
__declspec(noinline) void KeyChar(CreditScreenStub& s, char theChar)
{
    if (s.mCreditsPaused) return;
    static constexpr struct { char mChar; CreditsPhase mPhase; float mFrame; } kKeyJumpRows[] = {
        { '1', CreditsPhase::CREDITS_MAIN1,   0.0f },
        { '2', CreditsPhase::CREDITS_MAIN1, 128.0f },
        { '3', CreditsPhase::CREDITS_MAIN1, 144.0f },
        { '4', CreditsPhase::CREDITS_MAIN1, 272.0f },
        { '5', CreditsPhase::CREDITS_MAIN1, 304.0f },
        { '6', CreditsPhase::CREDITS_MAIN1, 340.0f },
        { '7', CreditsPhase::CREDITS_MAIN1, 368.0f },
        { 'q', CreditsPhase::CREDITS_MAIN2,   0.0f },
        { 'w', CreditsPhase::CREDITS_MAIN2, 124.0f },
        { 'e', CreditsPhase::CREDITS_MAIN2, 188.0f },
        { 'r', CreditsPhase::CREDITS_MAIN2, 248.0f },
        { 't', CreditsPhase::CREDITS_MAIN2, 320.0f },
        { 'a', CreditsPhase::CREDITS_MAIN3,   0.0f },
        { 's', CreditsPhase::CREDITS_MAIN3, 124.0f },
        { 'd', CreditsPhase::CREDITS_MAIN3, 216.0f },
        { 'f', CreditsPhase::CREDITS_MAIN3, 240.0f },
        { 'g', CreditsPhase::CREDITS_MAIN3, 324.0f },
    };
    for (const auto& aRow : kKeyJumpRows)
    {
        if (aRow.mChar == theChar)
        {
            B::JumpToFrame(s, aRow.mPhase, aRow.mFrame);
            return;
        }
    }
    if (theChar == ('n'))
    {
        s.mDontSync = !s.mDontSync;
    }
}
} // namespace B

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];

static void PrepInputs()
{
    LCG rng{ 0x243F6A8885A308D3ULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();
}

static CreditScreenStub g_scr;
static Reanimation g_reanim;

static void SetupScr()
{
    static EffectSystem es; static PoolEffect pe; static MusicSystem ms;
    static TodParticleSystem parts[2];
    static Button mb, rb;
    parts[0].mEffectType = 21; parts[1].mEffectType = 22;
    static AppStub app;
    app.mEffectSystem = &es; app.mPoolEffect = &pe; app.mMusic = &ms;
    app.mParticles = parts; app.mParticleCount = 2;
    g_scr.mApp = &app;
    g_scr.mMainMenuButton = &mb; g_scr.mReplayButton = &rb;
    g_scr.mReanimPool = &g_reanim;
    g_scr.mFogParticleID = 1;
}

typedef void (*UpdateMovieFn)(CreditScreenStub&);
static uint64_t RunMovie(UpdateMovieFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++)
    {
        uint32_t v = g_in[i];
        g_scr.mCreditsPhase = (CreditsPhase)((v >> 2) & 3);
        g_scr.mCreditsPhaseCounter = (int)(v >> 4) % 49;
        g_reanim.mLoopCount = (int)((v >> 9) & 3);
        g_reanim.mAnimTime = (float)((v >> 11) & 255) * 0.004f;
        g_reanim.mTrigA = (float)((v >> 19) & 255) * 0.02f;
        g_reanim.mTrigB = (float)((v >> 27) & 255) * 0.02f;
        g_timingIn[0].mBrainType = (CreditBrainType)((v >> 5) % 6);
        g_timingIn[1].mBrainType = (CreditBrainType)((v >> 8) % 6);
        g_timingIn[0].mWordType = (CreditWordType)((v >> 14) % 5);
        g_timingIn[1].mWordType = (CreditWordType)((v >> 17) % 5);
        g_timingIn[0].mWordX = (float)((v >> 3) & 63) * 8.0f;
        g_timingIn[1].mWordX = (float)((v >> 6) & 63) * 9.0f + 5.0f;
        g_timingIn[0].mFrame = (float)((v >> 12) & 63);
        g_timingIn[1].mFrame = (float)((v >> 15) & 63) + 40.0f;
        g_fracInput = (float)((v >> 21) & 63) / 64.0f;
        fn(g_scr);
    }
    return g_cs;
}

typedef void (*KeyCharFn)(CreditScreenStub&, char);
static uint64_t RunKey(KeyCharFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    static const char keys[22] = { '1','2','3','4','5','6','7','q','w','e','r','t','a','s','d','f','g','n','x','z','1','w' };
    for (int i = 0; i < N; i++)
    {
        g_scr.mCreditsPaused = ((g_in[i] >> 31) & 1) != 0;
        fn(g_scr, keys[g_in[i] % 22]);
    }
    return g_cs;
}

typedef void (*JumpFn)(CreditScreenStub&, CreditsPhase, float);
static uint64_t RunJump(JumpFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++)
    {
        uint32_t v = g_in[i];
        fn(g_scr, (CreditsPhase)(v & 3), (float)((v >> 2) & 511) * 1.0f);
    }
    return g_cs;
}

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    for (int k = 0; k < 16; k++) g_imgC[k].id = k;
    PrepInputs();
    SetupScr();

    // t19/20: A0 -> A1（相位表 + 音素表）
    {
        uint64_t csA = RunMovie(A0::UpdateMovie), csB = RunMovie(A1::UpdateMovie);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunMovie(A0::UpdateMovie); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunMovie(A1::UpdateMovie); }) / N * 1e9;
        }
        Report("t19+t20 kWordPhoneme/kCreditsPhaseCases UpdateMovie A0->A1", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t4: A1 -> B（脑子表 + 音素补 static）
    {
        uint64_t csA = RunMovie(A1::UpdateMovie), csB = RunMovie(B::UpdateMovie);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunMovie(A1::UpdateMovie); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunMovie(B::UpdateMovie); }) / N * 1e9;
        }
        Report("t4 kBrainMoveCases UpdateMovie A1->B", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t21: KeyChar
    {
        uint64_t csA = RunKey(A0::KeyChar), csB = RunKey(B::KeyChar);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunKey(A0::KeyChar); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunKey(B::KeyChar); }) / N * 1e9;
        }
        Report("t21 kKeyJumpRows(17) CreditScreen::KeyChar", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t22: JumpToFrame
    {
        uint64_t csA = RunJump(A0::JumpToFrame), csB = RunJump(B::JumpToFrame);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunJump(A0::JumpToFrame); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunJump(B::JumpToFrame); }) / N * 1e9;
        }
        Report("t22 kMusicOffsetLadder(15) CreditScreen::JumpToFrame", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
