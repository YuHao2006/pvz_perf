#include "pvz/assets/pak_archive.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <fstream>
#include <limits>
#include <stdexcept>

namespace pvz::assets {
namespace {

constexpr std::uint8_t kEncryptionKey = 0xF7;
constexpr std::uint32_t kMagic = 0xBAC04AC0;
constexpr std::uint8_t kEndFlag = 0x80;
constexpr std::size_t kMaximumEntryCount = 1'000'000;

class HeaderReader {
public:
    explicit HeaderReader(const std::filesystem::path& path)
        : input_(path, std::ios::binary)
    {
        if (!input_)
            throw std::runtime_error("unable to open PAK archive");
    }

    [[nodiscard]] std::uint8_t read_u8()
    {
        char value = 0;
        input_.read(&value, 1);
        if (!input_)
            throw std::runtime_error("unexpected end of PAK header");
        return static_cast<std::uint8_t>(static_cast<unsigned char>(value) ^ kEncryptionKey);
    }

    [[nodiscard]] std::uint32_t read_u32()
    {
        std::uint32_t result = 0;
        for (unsigned shift = 0; shift < 32; shift += 8)
            result |= static_cast<std::uint32_t>(read_u8()) << shift;
        return result;
    }

    [[nodiscard]] std::uint64_t read_u64()
    {
        std::uint64_t result = 0;
        for (unsigned shift = 0; shift < 64; shift += 8)
            result |= static_cast<std::uint64_t>(read_u8()) << shift;
        return result;
    }

    [[nodiscard]] std::string read_string(const std::size_t size)
    {
        std::string result(size, '\0');
        for (char& value : result)
            value = static_cast<char>(read_u8());
        return result;
    }

    [[nodiscard]] std::uint64_t position()
    {
        const auto position = input_.tellg();
        if (position < 0)
            throw std::runtime_error("unable to determine PAK header position");
        return static_cast<std::uint64_t>(position);
    }

private:
    std::ifstream input_;
};

[[nodiscard]] char normalized_path_character(const char value) noexcept
{
    if (value == '/')
        return '\\';
    return static_cast<char>(std::tolower(static_cast<unsigned char>(value)));
}

[[nodiscard]] bool paths_equal(const std::string_view left, const std::string_view right) noexcept
{
    return left.size() == right.size() && std::ranges::equal(
        left,
        right,
        [](const char a, const char b) {
            return normalized_path_character(a) == normalized_path_character(b);
        });
}

} // namespace

PakArchive PakArchive::open(const std::filesystem::path& path)
{
    HeaderReader reader{path};
    if (reader.read_u32() != kMagic)
        throw std::runtime_error("invalid PAK magic");
    if (reader.read_u32() != 0)
        throw std::runtime_error("unsupported PAK version");

    PakArchive archive;
    archive.path_ = path;
    std::uint64_t relative_data_offset = 0;

    while (true) {
        const auto flags = reader.read_u8();
        if ((flags & kEndFlag) != 0)
            break;
        if (archive.entries_.size() >= kMaximumEntryCount)
            throw std::runtime_error("PAK entry count exceeds safety limit");

        const auto name_size = reader.read_u8();
        if (name_size == 0)
            throw std::runtime_error("PAK entry has an empty path");

        PakEntry entry;
        entry.path = reader.read_string(name_size);
        entry.size = reader.read_u32();
        entry.windows_file_time = reader.read_u64();
        entry.data_offset = relative_data_offset;
        relative_data_offset += entry.size;
        archive.entries_.push_back(std::move(entry));
    }

    const auto data_start = reader.position();
    const auto archive_size = std::filesystem::file_size(path);
    if (relative_data_offset > archive_size || data_start > archive_size - relative_data_offset)
        throw std::runtime_error("PAK entry data exceeds archive size");

    for (auto& entry : archive.entries_)
        entry.data_offset += data_start;

    return archive;
}

const std::filesystem::path& PakArchive::path() const noexcept
{
    return path_;
}

std::span<const PakEntry> PakArchive::entries() const noexcept
{
    return entries_;
}

std::optional<std::reference_wrapper<const PakEntry>> PakArchive::find(
    const std::string_view path) const noexcept
{
    const auto found = std::ranges::find_if(entries_, [path](const PakEntry& entry) {
        return paths_equal(entry.path, path);
    });
    if (found == entries_.end())
        return std::nullopt;
    return std::cref(*found);
}

std::vector<std::uint8_t> PakArchive::read(
    const PakEntry& entry,
    const std::uint64_t offset,
    const std::size_t size) const
{
    if (offset > entry.size || size > static_cast<std::uint64_t>(entry.size) - offset)
        throw std::out_of_range("PAK read exceeds entry bounds");
    if (size > static_cast<std::size_t>(std::numeric_limits<std::streamsize>::max()))
        throw std::length_error("PAK read is too large for the host stream API");

    std::ifstream input{path_, std::ios::binary};
    if (!input)
        throw std::runtime_error("unable to reopen PAK archive");

    input.seekg(static_cast<std::streamoff>(entry.data_offset + offset));
    if (!input)
        throw std::runtime_error("unable to seek to PAK entry data");

    std::vector<std::uint8_t> result(size);
    input.read(reinterpret_cast<char*>(result.data()), static_cast<std::streamsize>(size));
    if (input.gcount() != static_cast<std::streamsize>(size))
        throw std::runtime_error("unexpected end of PAK entry data");

    for (auto& value : result)
        value ^= kEncryptionKey;
    return result;
}

std::vector<std::uint8_t> PakArchive::read(const PakEntry& entry) const
{
    return read(entry, 0, entry.size);
}

} // namespace pvz::assets
