
void __fastcall FUN_00549330(int param_1)

{
  if (*(int *)(param_1 + 0x24) == 0) {
    *(undefined1 *)(param_1 + 0x3c) = 1;
  }
  else {
    (**(code **)(**(int **)(param_1 + 0x24) + 0x48))(param_1);
  }
  return;
}

