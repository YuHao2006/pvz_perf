#include "LevelSaveConverter.h"

#include "ConstEnums.h"
#include "Lawn/System/LevelSaveFormat.h"
#include "Resources.h"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <limits>
#include <optional>
#include <set>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#ifdef _WIN32
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#endif

namespace PvzDat64
{
namespace
{
using Byte = std::uint8_t;
using LevelSaveFormat::RecordKind;
using LevelSaveFormat::RecordLayout;

constexpr std::uint32_t LEGACY_MAGIC = 0xFEEDDEADU;
constexpr std::uint32_t LEGACY_VERSION = 2U;
constexpr std::uint32_t LEGACY_DATE = 0xAC9B80ACU;
constexpr std::uint32_t DATA_ARRAY_KEY_MASK = 0xFFFF0000U;
constexpr std::uint32_t DATA_ARRAY_INDEX_MASK = 0x0000FFFFU;
constexpr std::uint32_t LEGACY_FIXED_TAIL_SIZE = 2056U;
constexpr std::uint32_t DAT64_FIXED_TAIL_SIZE = 2292U;
constexpr int NUM_TRAIL_DEFINITIONS_1073 = 1;

struct ArrayDescriptor
{
    RecordKind mKind;
    const char* mName;
    std::uint32_t mCapacity;
};

constexpr std::array<ArrayDescriptor, 12> ARRAY_DESCRIPTORS = {{
    {RecordKind::Zombie, "Zombie", 1024},
    {RecordKind::Plant, "Plant", 1024},
    {RecordKind::Projectile, "Projectile", 1024},
    {RecordKind::Coin, "Coin", 1024},
    {RecordKind::LawnMower, "LawnMower", 32},
    {RecordKind::GridItem, "GridItem", 128},
    {RecordKind::ParticleSystem, "ParticleSystem", 1024},
    {RecordKind::ParticleEmitter, "ParticleEmitter", 1024},
    {RecordKind::Particle, "Particle", 1024},
    {RecordKind::Reanimation, "Reanimation", 1024},
    {RecordKind::Trail, "Trail", 1024},
    {RecordKind::Attachment, "Attachment", 1024},
}};

[[noreturn]] void Fail(
    std::size_t theOffset,
    const std::string& theField,
    const std::string& theReason)
{
    std::ostringstream aMessage;
    aMessage << "偏移 0x" << std::uppercase << std::hex << theOffset
             << "，字段 " << theField << "：" << theReason;
    throw std::runtime_error(aMessage.str());
}

[[noreturn]] void Fail(const std::string& theReason)
{
    throw std::runtime_error(theReason);
}

class Reader
{
public:
    explicit Reader(std::span<const Byte> theData)
        : mData(theData), mPosition(0)
    {
    }

    std::size_t Position() const { return mPosition; }
    std::size_t Size() const { return mData.size(); }
    std::size_t Remaining() const { return mData.size() - mPosition; }
    std::span<const Byte> Data() const { return mData; }

    void SetPosition(std::size_t thePosition, const std::string& theField)
    {
        if (thePosition > mData.size())
        {
            Fail(mPosition, theField, "目标位置越过文件末尾");
        }
        mPosition = thePosition;
    }

    std::uint32_t U32(const std::string& theField)
    {
        Require(4, theField);
        const std::uint32_t aValue =
            static_cast<std::uint32_t>(mData[mPosition]) |
            (static_cast<std::uint32_t>(mData[mPosition + 1]) << 8) |
            (static_cast<std::uint32_t>(mData[mPosition + 2]) << 16) |
            (static_cast<std::uint32_t>(mData[mPosition + 3]) << 24);
        mPosition += 4;
        return aValue;
    }

    std::int32_t I32(const std::string& theField)
    {
        return std::bit_cast<std::int32_t>(U32(theField));
    }

    std::uint64_t U64(const std::string& theField)
    {
        const std::uint64_t aLow = U32(theField + ".low");
        const std::uint64_t aHigh = U32(theField + ".high");
        return aLow | (aHigh << 32);
    }

    std::span<const Byte> Bytes(std::size_t theSize, const std::string& theField)
    {
        Require(theSize, theField);
        const auto aResult = mData.subspan(mPosition, theSize);
        mPosition += theSize;
        return aResult;
    }

    std::span<const Byte> SyncBytes(
        std::size_t theExpectedSize,
        const std::string& theField)
    {
        const std::size_t aLengthOffset = mPosition;
        const std::uint32_t anActualSize = U32(theField + ".size");
        if (anActualSize != theExpectedSize)
        {
            std::ostringstream aReason;
            aReason << "SyncBytes 长度为 " << anActualSize
                    << "，应为 " << theExpectedSize;
            Fail(aLengthOffset, theField, aReason.str());
        }
        return Bytes(theExpectedSize, theField);
    }

private:
    void Require(std::size_t theSize, const std::string& theField) const
    {
        if (theSize > mData.size() - mPosition)
        {
            std::ostringstream aReason;
            aReason << "需要 " << theSize << " 字节，只剩 "
                    << (mData.size() - mPosition) << " 字节";
            Fail(mPosition, theField, aReason.str());
        }
    }

    std::span<const Byte> mData;
    std::size_t mPosition;
};

class Writer
{
public:
    std::size_t Position() const { return mData.size(); }
    const std::vector<Byte>& Data() const { return mData; }

    void U32(std::uint32_t theValue)
    {
        mData.push_back(static_cast<Byte>(theValue));
        mData.push_back(static_cast<Byte>(theValue >> 8));
        mData.push_back(static_cast<Byte>(theValue >> 16));
        mData.push_back(static_cast<Byte>(theValue >> 24));
    }

    void I32(std::int32_t theValue)
    {
        U32(std::bit_cast<std::uint32_t>(theValue));
    }

    void U64(std::uint64_t theValue)
    {
        U32(static_cast<std::uint32_t>(theValue));
        U32(static_cast<std::uint32_t>(theValue >> 32));
    }

    void Bytes(std::span<const Byte> theBytes)
    {
        mData.insert(mData.end(), theBytes.begin(), theBytes.end());
    }

    void SyncBytes(std::span<const Byte> theBytes)
    {
        if (theBytes.size() > std::numeric_limits<std::uint32_t>::max())
        {
            Fail("内部错误：SyncBytes 块大于 4 GiB");
        }
        U32(static_cast<std::uint32_t>(theBytes.size()));
        Bytes(theBytes);
    }

private:
    std::vector<Byte> mData;
};

std::uint32_t ReadU32At(std::span<const Byte> theData, std::size_t theOffset)
{
    return static_cast<std::uint32_t>(theData[theOffset]) |
        (static_cast<std::uint32_t>(theData[theOffset + 1]) << 8) |
        (static_cast<std::uint32_t>(theData[theOffset + 2]) << 16) |
        (static_cast<std::uint32_t>(theData[theOffset + 3]) << 24);
}

std::int32_t ReadI32At(std::span<const Byte> theData, std::size_t theOffset)
{
    return std::bit_cast<std::int32_t>(ReadU32At(theData, theOffset));
}

std::uint64_t ReadU64At(std::span<const Byte> theData, std::size_t theOffset)
{
    return static_cast<std::uint64_t>(ReadU32At(theData, theOffset)) |
        (static_cast<std::uint64_t>(ReadU32At(theData, theOffset + 4)) << 32);
}

void WriteU32At(std::span<Byte> theData, std::size_t theOffset, std::uint32_t theValue)
{
    theData[theOffset] = static_cast<Byte>(theValue);
    theData[theOffset + 1] = static_cast<Byte>(theValue >> 8);
    theData[theOffset + 2] = static_cast<Byte>(theValue >> 16);
    theData[theOffset + 3] = static_cast<Byte>(theValue >> 24);
}

void WriteU64At(std::span<Byte> theData, std::size_t theOffset, std::uint64_t theValue)
{
    WriteU32At(theData, theOffset, static_cast<std::uint32_t>(theValue));
    WriteU32At(theData, theOffset + 4, static_cast<std::uint32_t>(theValue >> 32));
}

float ReadFloatAt(std::span<const Byte> theData, std::size_t theOffset)
{
    return std::bit_cast<float>(ReadU32At(theData, theOffset));
}

std::uint32_t Crc32(std::span<const Byte> theData)
{
    std::uint32_t aCrc = 0xFFFFFFFFU;
    for (const Byte aByte : theData)
    {
        aCrc ^= aByte;
        for (int aBit = 0; aBit < 8; ++aBit)
        {
            const std::uint32_t aMask = 0U - (aCrc & 1U);
            aCrc = (aCrc >> 1) ^ (0xEDB88320U & aMask);
        }
    }
    return aCrc ^ 0xFFFFFFFFU;
}

std::vector<Byte> ReadFileFully(const std::filesystem::path& thePath)
{
    std::ifstream aFile(thePath, std::ios::binary | std::ios::ate);
    if (!aFile)
    {
        Fail("无法打开输入文件：" + thePath.string());
    }
    const std::streamoff aSize = aFile.tellg();
    if (aSize < 0 || static_cast<std::uint64_t>(aSize) >
            static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
    {
        Fail("输入文件大小无效：" + thePath.string());
    }
    std::vector<Byte> aData(static_cast<std::size_t>(aSize));
    aFile.seekg(0);
    if (!aData.empty())
    {
        aFile.read(reinterpret_cast<char*>(aData.data()), aSize);
    }
    if (!aFile)
    {
        Fail("读取输入文件失败：" + thePath.string());
    }
    return aData;
}

void ValidateBool(
    std::span<const Byte> theRecord,
    std::size_t theOffset,
    std::size_t theFileOffset,
    const std::string& theField)
{
    if (theRecord[theOffset] > 1)
    {
        Fail(theFileOffset + theOffset, theField, "bool 不是 0 或 1");
    }
}

void ValidateFinite(
    std::span<const Byte> theRecord,
    std::size_t theOffset,
    std::size_t theFileOffset,
    const std::string& theField)
{
    if (!std::isfinite(ReadFloatAt(theRecord, theOffset)))
    {
        Fail(theFileOffset + theOffset, theField, "浮点值为 NaN 或无穷大");
    }
}

void ValidateI32Range(
    std::span<const Byte> theRecord,
    std::size_t theOffset,
    std::int32_t theMinimum,
    std::int32_t theMaximum,
    std::size_t theFileOffset,
    const std::string& theField)
{
    const std::int32_t aValue = ReadI32At(theRecord, theOffset);
    if (aValue < theMinimum || aValue > theMaximum)
    {
        std::ostringstream aReason;
        aReason << "值 " << aValue << " 超出 [" << theMinimum
                << ", " << theMaximum << "]";
        Fail(theFileOffset + theOffset, theField, aReason.str());
    }
}

bool KindHasGameObjectBase(RecordKind theKind)
{
    switch (theKind)
    {
    case RecordKind::Zombie:
    case RecordKind::Plant:
    case RecordKind::Projectile:
    case RecordKind::Coin:
    case RecordKind::CursorObject:
    case RecordKind::CursorPreview:
    case RecordKind::SeedPacket:
        return true;
    default:
        return false;
    }
}

void ValidateCanonicalRecord(
    RecordKind theKind,
    std::span<const Byte> theRecord,
    std::size_t theFileOffset,
    const std::string& theName)
{
    const RecordLayout& aLayout = LevelSaveFormat::GetRecordLayout(theKind);
    if (theRecord.size() != aLayout.mDat64Size)
    {
        Fail(theFileOffset, theName, "内部记录大小与 dat64 schema 不一致");
    }

    if (KindHasGameObjectBase(theKind))
    {
        ValidateBool(theRecord, 32, theFileOffset, theName + ".mVisible");
    }

    const auto finiteList = [&](std::initializer_list<std::size_t> theOffsets)
    {
        for (const std::size_t anOffset : theOffsets)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".float");
        }
    };
    const auto boolList = [&](std::initializer_list<std::size_t> theOffsets)
    {
        for (const std::size_t anOffset : theOffsets)
        {
            ValidateBool(theRecord, anOffset, theFileOffset, theName + ".bool");
        }
    };

    switch (theKind)
    {
    case RecordKind::Zombie:
        ValidateI32Range(theRecord, 48, 0, NUM_ZOMBIE_TYPES - 1, theFileOffset, theName + ".mZombieType");
        ValidateI32Range(theRecord, 208, 0, 9, theFileOffset, theName + ".mHelmType");
        ValidateI32Range(theRecord, 228, 0, 3, theFileOffset, theName + ".mShieldType");
        finiteList({56, 60, 64, 144, 296, 300, 304});
        boolList({92, 93, 124, 132, 148, 196, 197, 198, 199, 200, 201, 202, 203,
                  248, 272, 348, 360});
        break;
    case RecordKind::Plant:
        ValidateI32Range(theRecord, 48, 0, NUM_SEED_TYPES - 1, theFileOffset, theName + ".mSeedType");
        ValidateI32Range(theRecord, 324, -1, NUM_SEED_TYPES - 1, theFileOffset, theName + ".mImitaterType");
        finiteList({204, 208});
        for (std::size_t item = 0; item < 5; ++item)
        {
            const std::size_t aBase = 212 + item * 20;
            finiteList({aBase, aBase + 4, aBase + 8, aBase + 12});
        }
        boolList({332, 333, 334, 335, 336, 337});
        break;
    case RecordKind::Projectile:
        ValidateI32Range(theRecord, 104, 0, NUM_PROJECTILES - 1, theFileOffset, theName + ".mProjectileType");
        finiteList({60, 64, 68, 72, 76, 80, 84, 88, 116, 120, 140});
        boolList({92, 124});
        break;
    case RecordKind::Coin:
        finiteList({48, 52, 56, 60, 64, 76, 80, 112});
        boolList({68, 92, 208, 209, 210});
        break;
    case RecordKind::LawnMower:
        ValidateI32Range(theRecord, 60, 0, NUM_MOWER_TYPES - 1, theFileOffset, theName + ".mMowerType");
        finiteList({16, 20, 64});
        boolList({56, 57});
        break;
    case RecordKind::GridItem:
        ValidateI32Range(theRecord, 16, 0, 12, theFileOffset, theName + ".mGridItemType");
        finiteList({44, 48, 52, 56});
        for (std::size_t anOffset = 92; anOffset < 236; anOffset += 4)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".mMotionTrailFrames");
        }
        boolList({40, 80});
        break;
    case RecordKind::ParticleSystem:
        ValidateI32Range(theRecord, 0, 0, NUM_PARTICLES - 1, theFileOffset, theName + ".mEffectType");
        boolList({56, 57, 64});
        break;
    case RecordKind::ParticleEmitter:
        finiteList({48, 52, 56, 72, 76, 104});
        for (std::size_t anOffset = 132; anOffset < 204; anOffset += 4)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".interpolation");
        }
        boolList({80, 100});
        break;
    case RecordKind::Particle:
        for (const std::size_t anOffset : {16U, 20U, 24U, 28U, 32U, 36U, 40U, 48U, 52U})
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".float");
        }
        for (std::size_t anOffset = 64; anOffset < 160; anOffset += 4)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".interpolation");
        }
        break;
    case RecordKind::Reanimation:
        ValidateI32Range(theRecord, 0, 0, NUM_REANIMS - 1, theFileOffset, theName + ".mReanimationType");
        finiteList({4, 8, 44, 48, 52, 56, 60, 64, 68, 72, 76, 168});
        boolList({28, 120, 144, 164});
        break;
    case RecordKind::Trail:
        for (std::size_t anOffset = 0; anOffset < 160; anOffset += 4)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".mTrailPoints");
        }
        for (std::size_t anOffset = 200; anOffset <= 220; anOffset += 4)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".float");
        }
        boolList({164, 224});
        break;
    case RecordKind::Attachment:
    {
        const std::int32_t aCount = ReadI32At(theRecord, 768);
        if (aCount < 0 || aCount > 16)
        {
            Fail(theFileOffset + 768, theName + ".mNumEffects", "不在 0..16");
        }
        for (int i = 0; i < aCount; ++i)
        {
            const std::size_t aBase = static_cast<std::size_t>(i) * 48;
            ValidateI32Range(theRecord, aBase + 4, 0, 4, theFileOffset, theName + ".mEffectType");
            for (std::size_t anOffset = aBase + 8; anOffset < aBase + 44; anOffset += 4)
            {
                ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".mOffset");
            }
            boolList({aBase + 44, aBase + 45});
        }
        ValidateBool(theRecord, 772, theFileOffset, theName + ".mDead");
        break;
    }
    case RecordKind::CursorObject:
    case RecordKind::CursorPreview:
        break;
    case RecordKind::MessageWidget:
        break;
    case RecordKind::SeedPacket:
        ValidateI32Range(theRecord, 64, -1, 80, theFileOffset, theName + ".mPacketType");
        ValidateI32Range(theRecord, 68, -1, NUM_SEED_TYPES - 1, theFileOffset, theName + ".mImitaterType");
        ValidateFinite(theRecord, 80, theFileOffset, theName + ".mSlotMachiningPosition");
        boolList({84, 85});
        break;
    case RecordKind::Challenge:
        for (std::size_t anOffset = 28; anOffset < 82; ++anOffset)
        {
            ValidateBool(theRecord, anOffset, theFileOffset, theName + ".mBeghouledEated");
        }
        for (std::size_t anOffset = 82; anOffset < 85; ++anOffset)
        {
            ValidateBool(theRecord, anOffset, theFileOffset, theName + ".mBeghouledPurchasedUpgrade");
        }
        break;
    case RecordKind::Music:
        ValidateI32Range(theRecord, 16, -1, 13, theFileOffset, theName + ".mCurMusicTune");
        for (const std::size_t anOffset : {20U, 24U, 28U})
        {
            ValidateI32Range(theRecord, anOffset, -1, 4, theFileOffset, theName + ".MusicFile");
        }
        ValidateI32Range(theRecord, 32, -1, 2, theFileOffset, theName + ".mBurstOverride");
        ValidateI32Range(theRecord, 36, 1, 1000, theFileOffset, theName + ".mBaseBPM");
        ValidateI32Range(theRecord, 40, 1, 100, theFileOffset, theName + ".mBaseModSpeed");
        ValidateI32Range(theRecord, 44, 0, 3, theFileOffset, theName + ".mMusicBurstState");
        ValidateI32Range(theRecord, 52, 0, 4, theFileOffset, theName + ".mMusicDrumsState");
        boolList({72, 73});
        break;
    case RecordKind::ReanimatorTrackInstance:
        for (std::size_t anOffset = 8; anOffset < 40; anOffset += 4)
        {
            ValidateFinite(theRecord, anOffset, theFileOffset, theName + ".mBlendTransform");
        }
        finiteList({64, 68, 72});
        boolList({108, 109, 110, 111});
        break;
    }
}

std::vector<Byte> ToCanonicalRecord(
    std::span<const Byte> theSource,
    Format theSourceFormat,
    RecordKind theKind,
    std::size_t theFileOffset,
    const std::string& theName)
{
    const RecordLayout& aLayout = LevelSaveFormat::GetRecordLayout(theKind);
    const std::size_t anExpectedSize = theSourceFormat == Format::Legacy1073Dat
        ? aLayout.mLegacySize
        : aLayout.mDat64Size;
    if (theSource.size() != anExpectedSize)
    {
        Fail(theFileOffset, theName, "对象长度与 schema 不符");
    }

    std::vector<Byte> aCanonical(aLayout.mDat64Size, 0);
    std::vector<bool> aSemanticMask(aLayout.mDat64Size, false);
    for (std::size_t i = 0; i < aLayout.mSegmentCount; ++i)
    {
        const auto& aSegment = aLayout.mSegments[i];
        const std::size_t aSourceOffset = theSourceFormat == Format::Legacy1073Dat
            ? aSegment.mLegacyOffset
            : aSegment.mDat64Offset;
        std::memcpy(
            aCanonical.data() + aSegment.mDat64Offset,
            theSource.data() + aSourceOffset,
            aSegment.mSize);
        std::fill(
            aSemanticMask.begin() + aSegment.mDat64Offset,
            aSemanticMask.begin() + aSegment.mDat64Offset + aSegment.mSize,
            true);
    }

    if (theSourceFormat == Format::Dat64V1)
    {
        for (std::size_t i = 0; i < theSource.size(); ++i)
        {
            if (!aSemanticMask[i] && theSource[i] != 0)
            {
                Fail(theFileOffset + i, theName + ".reserved", "指针/保留字节必须为零");
            }
        }
    }

    ValidateCanonicalRecord(theKind, aCanonical, theFileOffset, theName);
    return aCanonical;
}

std::vector<Byte> FromCanonicalRecord(
    std::span<const Byte> theCanonical,
    Format theTargetFormat,
    RecordKind theKind)
{
    const RecordLayout& aLayout = LevelSaveFormat::GetRecordLayout(theKind);
    const std::size_t aTargetSize = theTargetFormat == Format::Legacy1073Dat
        ? aLayout.mLegacySize
        : aLayout.mDat64Size;
    std::vector<Byte> aTarget(aTargetSize, 0);
    for (std::size_t i = 0; i < aLayout.mSegmentCount; ++i)
    {
        const auto& aSegment = aLayout.mSegments[i];
        const std::size_t aTargetOffset = theTargetFormat == Format::Legacy1073Dat
            ? aSegment.mLegacyOffset
            : aSegment.mDat64Offset;
        std::memcpy(
            aTarget.data() + aTargetOffset,
            theCanonical.data() + aSegment.mDat64Offset,
            aSegment.mSize);
    }
    return aTarget;
}

std::vector<Byte> BoardToCanonical(
    std::span<const Byte> theSource,
    Format theSourceFormat,
    std::size_t theFileOffset)
{
    const std::size_t anExpected = theSourceFormat == Format::Legacy1073Dat
        ? LevelSaveFormat::LEGACY_BOARD_STATE_SIZE
        : LevelSaveFormat::DAT64_BOARD_STATE_SIZE;
    if (theSource.size() != anExpected)
    {
        Fail(theFileOffset, "Board", "棋盘固定块长度错误");
    }

    std::vector<Byte> aCanonical(LevelSaveFormat::DAT64_BOARD_STATE_SIZE, 0);
    if (theSourceFormat == Format::Legacy1073Dat)
    {
        std::memcpy(aCanonical.data(), theSource.data(),
            LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET);
        const std::int64_t aGameID = ReadI32At(
            theSource,
            LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET);
        WriteU64At(
            aCanonical,
            LevelSaveFormat::DAT64_BOARD_GAME_ID_OFFSET,
            std::bit_cast<std::uint64_t>(aGameID));
        std::memcpy(
            aCanonical.data() + LevelSaveFormat::DAT64_BOARD_AFTER_GAME_ID_OFFSET,
            theSource.data() + LevelSaveFormat::LEGACY_BOARD_AFTER_GAME_ID_OFFSET,
            LevelSaveFormat::BOARD_AFTER_GAME_ID_SIZE);
    }
    else
    {
        aCanonical.assign(theSource.begin(), theSource.end());
        for (std::size_t i = LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET;
             i < LevelSaveFormat::DAT64_BOARD_GAME_ID_OFFSET;
             ++i)
        {
            if (aCanonical[i] != 0)
            {
                Fail(theFileOffset + i, "Board.paddingBeforeGameID", "必须为零");
            }
        }
    }

    const auto aBoard = std::span<const Byte>(aCanonical);
    ValidateBool(aBoard, 0, theFileOffset, "Board.mPaused");
    for (std::size_t i = 0; i < 54; ++i)
    {
        ValidateI32Range(aBoard, 4 + i * 4, 0, 4, theFileOffset, "Board.mGridSquareType");
    }
    ValidateBool(aBoard, 1120, theFileOffset, "Board.mEnableGraveStones");
    ValidateFinite(aBoard, 1132, theFileOffset, "Board.mFogOffset");
    for (std::size_t row = 0; row < 6; ++row)
    {
        const std::size_t aBase = 1264 + row * 16;
        ValidateFinite(aBoard, aBase + 4, theFileOffset, "Board.mRowPickingArray.mWeight");
        ValidateFinite(aBoard, aBase + 8, theFileOffset, "Board.mRowPickingArray.mLastPicked");
        ValidateFinite(aBoard, aBase + 12, theFileOffset, "Board.mRowPickingArray.mSecondLastPicked");
    }
    for (std::size_t i = 0; i < 5000; ++i)
    {
        ValidateI32Range(
            aBoard,
            1360 + i * 4,
            -1,
            NUM_ZOMBIE_TYPES - 1,
            theFileOffset,
            "Board.mZombiesInWave");
    }
    for (std::size_t i = 0; i < 100; ++i)
    {
        ValidateBool(aBoard, 21360 + i, theFileOffset, "Board.mZombieAllowed");
    }
    ValidateI32Range(aBoard, 0x53E8, 0, 9, theFileOffset, "Board.mBackground");
    for (std::size_t i = 0; i < 68; ++i)
    {
        ValidateBool(aBoard, 21572 + i, theFileOffset, "Board.mHelpDisplayed");
    }
    for (const std::size_t anOffset : {
             21644U, 21645U, 21656U, 21672U, 21992U,
             22012U, 22013U, 22014U, 22015U, 22016U, 22017U, 22018U, 22019U,
             22024U, 22025U, 22036U, 22037U})
    {
        ValidateBool(aBoard, anOffset, theFileOffset, "Board.bool");
    }
    ValidateFinite(aBoard, 22068, theFileOffset, "Board.mMinFPS");
    return aCanonical;
}

std::vector<Byte> BoardFromCanonical(
    std::span<const Byte> theCanonical,
    Format theTargetFormat)
{
    if (theTargetFormat == Format::Dat64V1)
    {
        return std::vector<Byte>(theCanonical.begin(), theCanonical.end());
    }

    const std::int64_t aGameID = std::bit_cast<std::int64_t>(
        ReadU64At(theCanonical, LevelSaveFormat::DAT64_BOARD_GAME_ID_OFFSET));
    if (aGameID < std::numeric_limits<std::int32_t>::min() ||
        aGameID > std::numeric_limits<std::int32_t>::max())
    {
        Fail("Board.mGameID 超出 1073 的 int32 范围，不能反向转换为 .dat");
    }

    std::vector<Byte> aLegacy(LevelSaveFormat::LEGACY_BOARD_STATE_SIZE, 0);
    std::memcpy(aLegacy.data(), theCanonical.data(),
        LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET);
    WriteU32At(
        aLegacy,
        LevelSaveFormat::LEGACY_BOARD_GAME_ID_OFFSET,
        std::bit_cast<std::uint32_t>(static_cast<std::int32_t>(aGameID)));
    std::memcpy(
        aLegacy.data() + LevelSaveFormat::LEGACY_BOARD_AFTER_GAME_ID_OFFSET,
        theCanonical.data() + LevelSaveFormat::DAT64_BOARD_AFTER_GAME_ID_OFFSET,
        LevelSaveFormat::BOARD_AFTER_GAME_ID_SIZE);
    return aLegacy;
}

std::vector<Byte> SeedBankToCanonical(
    std::span<const Byte> theSource,
    Format theSourceFormat,
    std::size_t theFileOffset)
{
    const std::size_t anExpected = theSourceFormat == Format::Legacy1073Dat
        ? LevelSaveFormat::LEGACY_SEED_BANK_SIZE
        : LevelSaveFormat::DAT64_SEED_BANK_SIZE;
    if (theSource.size() != anExpected)
    {
        Fail(theFileOffset, "SeedBank", "长度错误");
    }

    std::vector<Byte> aCanonical(LevelSaveFormat::DAT64_SEED_BANK_SIZE, 0);
    const std::size_t aBaseSource = theSourceFormat == Format::Legacy1073Dat ? 8 : 16;
    const std::size_t aNumSource = theSourceFormat == Format::Legacy1073Dat ? 36 : 48;
    std::memcpy(aCanonical.data() + 16, theSource.data() + aBaseSource, 28);
    std::memcpy(aCanonical.data() + 48, theSource.data() + aNumSource, 4);

    const RecordLayout& aPacketLayout =
        LevelSaveFormat::GetRecordLayout(RecordKind::SeedPacket);
    const std::size_t aPacketSourceOffset = theSourceFormat == Format::Legacy1073Dat
        ? LevelSaveFormat::LEGACY_SEED_BANK_PACKET_OFFSET
        : LevelSaveFormat::DAT64_SEED_BANK_PACKET_OFFSET;
    const std::size_t aPacketSourceSize = theSourceFormat == Format::Legacy1073Dat
        ? aPacketLayout.mLegacySize
        : aPacketLayout.mDat64Size;
    for (std::size_t i = 0; i < LevelSaveFormat::SEED_BANK_PACKET_COUNT; ++i)
    {
        const std::size_t aSourceOffset = aPacketSourceOffset + i * aPacketSourceSize;
        const std::vector<Byte> aPacket = ToCanonicalRecord(
            theSource.subspan(aSourceOffset, aPacketSourceSize),
            theSourceFormat,
            RecordKind::SeedPacket,
            theFileOffset + aSourceOffset,
            "SeedBank.mSeedPackets[" + std::to_string(i) + "]");
        std::memcpy(
            aCanonical.data() + LevelSaveFormat::DAT64_SEED_BANK_PACKET_OFFSET +
                i * aPacketLayout.mDat64Size,
            aPacket.data(),
            aPacket.size());
    }

    const std::size_t aTailSource = theSourceFormat == Format::Legacy1073Dat
        ? LevelSaveFormat::LEGACY_SEED_BANK_TAIL_OFFSET
        : LevelSaveFormat::DAT64_SEED_BANK_TAIL_OFFSET;
    std::memcpy(
        aCanonical.data() + LevelSaveFormat::DAT64_SEED_BANK_TAIL_OFFSET,
        theSource.data() + aTailSource,
        LevelSaveFormat::SEED_BANK_TAIL_SIZE);

    if (theSourceFormat == Format::Dat64V1)
    {
        std::vector<Byte> aNormalized = aCanonical;
        if (!std::equal(aNormalized.begin(), aNormalized.end(), theSource.begin()))
        {
            for (std::size_t i = 0; i < theSource.size(); ++i)
            {
                if (aNormalized[i] != theSource[i])
                {
                    Fail(theFileOffset + i, "SeedBank.reserved", "指针/保留字节必须为零");
                }
            }
        }
    }
    return aCanonical;
}

std::vector<Byte> SeedBankFromCanonical(
    std::span<const Byte> theCanonical,
    Format theTargetFormat)
{
    if (theTargetFormat == Format::Dat64V1)
    {
        return std::vector<Byte>(theCanonical.begin(), theCanonical.end());
    }

    std::vector<Byte> aLegacy(LevelSaveFormat::LEGACY_SEED_BANK_SIZE, 0);
    std::memcpy(aLegacy.data() + 8, theCanonical.data() + 16, 28);
    std::memcpy(aLegacy.data() + 36, theCanonical.data() + 48, 4);
    const RecordLayout& aPacketLayout =
        LevelSaveFormat::GetRecordLayout(RecordKind::SeedPacket);
    for (std::size_t i = 0; i < LevelSaveFormat::SEED_BANK_PACKET_COUNT; ++i)
    {
        const auto aPacket = FromCanonicalRecord(
            theCanonical.subspan(
                LevelSaveFormat::DAT64_SEED_BANK_PACKET_OFFSET +
                    i * aPacketLayout.mDat64Size,
                aPacketLayout.mDat64Size),
            Format::Legacy1073Dat,
            RecordKind::SeedPacket);
        std::memcpy(
            aLegacy.data() + LevelSaveFormat::LEGACY_SEED_BANK_PACKET_OFFSET +
                i * aPacketLayout.mLegacySize,
            aPacket.data(),
            aPacket.size());
    }
    std::memcpy(
        aLegacy.data() + LevelSaveFormat::LEGACY_SEED_BANK_TAIL_OFFSET,
        theCanonical.data() + LevelSaveFormat::DAT64_SEED_BANK_TAIL_OFFSET,
        LevelSaveFormat::SEED_BANK_TAIL_SIZE);
    return aLegacy;
}

struct SlotSnapshot
{
    std::vector<Byte> mCanonicalRecord;
    std::uint32_t mID{};
    bool operator==(const SlotSnapshot&) const = default;
};

struct ArraySnapshot
{
    RecordKind mKind{};
    std::uint32_t mFreeListHead{};
    std::uint32_t mMaxUsedCount{};
    std::uint32_t mSize{};
    std::vector<SlotSnapshot> mSlots;
    bool operator==(const ArraySnapshot&) const = default;
};

struct EmitterSupplement
{
    std::int32_t mDefinitionIndex{};
    std::int32_t mImageResourceID{};
    std::vector<std::uint32_t> mParticleIDs;
    bool operator==(const EmitterSupplement&) const = default;
};

struct ParticleSystemSupplement
{
    std::int32_t mDefinitionID{};
    std::vector<std::uint32_t> mEmitterIDs;
    std::vector<EmitterSupplement> mEmitters;
    bool operator==(const ParticleSystemSupplement&) const = default;
};

struct ReanimationSupplement
{
    std::int32_t mDefinitionID{};
    std::vector<std::vector<Byte>> mCanonicalTracks;
    std::vector<std::int32_t> mImageResourceIDs;
    bool operator==(const ReanimationSupplement&) const = default;
};

struct Document
{
    std::vector<Byte> mCanonicalBoard;
    std::array<ArraySnapshot, 12> mArrays;
    std::vector<ParticleSystemSupplement> mParticleSystems;
    std::vector<ReanimationSupplement> mReanimations;
    std::vector<std::int32_t> mTrailDefinitionIDs;
    std::vector<Byte> mCursorObject;
    std::vector<Byte> mCursorPreview;
    std::vector<Byte> mMessageWidget;
    std::vector<Byte> mSeedBank;
    std::vector<Byte> mChallenge;
    std::vector<Byte> mMusic;
    bool operator==(const Document&) const = default;
};

std::vector<std::uint32_t> LiveIDs(const ArraySnapshot& theArray)
{
    std::vector<std::uint32_t> aResult;
    for (const SlotSnapshot& aSlot : theArray.mSlots)
    {
        if (aSlot.mID & DATA_ARRAY_KEY_MASK)
        {
            aResult.push_back(aSlot.mID);
        }
    }
    return aResult;
}

void ValidateFreeList(
    const ArraySnapshot& theArray,
    const ArrayDescriptor& theDescriptor,
    std::size_t theFileOffset)
{
    std::vector<bool> aFree(theArray.mMaxUsedCount, false);
    std::uint32_t aCursor = theArray.mFreeListHead;
    while (aCursor != theArray.mMaxUsedCount)
    {
        if (aCursor >= theArray.mMaxUsedCount)
        {
            Fail(theFileOffset, std::string(theDescriptor.mName) + ".mFreeListHead", "自由链索引越界");
        }
        if (aFree[aCursor])
        {
            Fail(theFileOffset, std::string(theDescriptor.mName) + ".freeList", "自由链存在环");
        }
        const SlotSnapshot& aSlot = theArray.mSlots[aCursor];
        if (aSlot.mID & DATA_ARRAY_KEY_MASK)
        {
            Fail(theFileOffset, std::string(theDescriptor.mName) + ".freeList", "自由链指向存活对象");
        }
        aFree[aCursor] = true;
        aCursor = aSlot.mID;
    }

    std::uint32_t aLiveCount = 0;
    for (std::uint32_t i = 0; i < theArray.mMaxUsedCount; ++i)
    {
        const bool isLive = (theArray.mSlots[i].mID & DATA_ARRAY_KEY_MASK) != 0;
        if (isLive)
        {
            ++aLiveCount;
            if ((theArray.mSlots[i].mID & DATA_ARRAY_INDEX_MASK) != i)
            {
                Fail(theFileOffset, std::string(theDescriptor.mName) + ".mID", "存活 ID 的低 16 位不等于槽索引");
            }
        }
        else if (!aFree[i])
        {
            Fail(theFileOffset, std::string(theDescriptor.mName) + ".freeList", "空闲槽没有出现在自由链中");
        }
    }
    if (aLiveCount != theArray.mSize)
    {
        Fail(theFileOffset, std::string(theDescriptor.mName) + ".mSize", "存活槽计数与 mSize 不一致");
    }
}

ArraySnapshot ReadArray(
    Reader& theReader,
    Format theFormat,
    const ArrayDescriptor& theDescriptor)
{
    const std::size_t aHeaderOffset = theReader.Position();
    ArraySnapshot aResult;
    aResult.mKind = theDescriptor.mKind;
    aResult.mFreeListHead = theReader.U32(std::string(theDescriptor.mName) + ".mFreeListHead");
    aResult.mMaxUsedCount = theReader.U32(std::string(theDescriptor.mName) + ".mMaxUsedCount");
    aResult.mSize = theReader.U32(std::string(theDescriptor.mName) + ".mSize");
    if (aResult.mMaxUsedCount > theDescriptor.mCapacity ||
        aResult.mSize > aResult.mMaxUsedCount ||
        aResult.mFreeListHead > aResult.mMaxUsedCount)
    {
        Fail(aHeaderOffset, theDescriptor.mName, "DataArray 元数据越界");
    }

    const RecordLayout& aLayout = LevelSaveFormat::GetRecordLayout(theDescriptor.mKind);
    const std::uint32_t aSlotSize = theFormat == Format::Legacy1073Dat
        ? aLayout.mLegacyArraySlotSize
        : aLayout.mDat64ArraySlotSize;
    const std::uint32_t anObjectSize = theFormat == Format::Legacy1073Dat
        ? aLayout.mLegacySize
        : aLayout.mDat64Size;
    const std::uint64_t aBlockSize64 =
        static_cast<std::uint64_t>(aResult.mMaxUsedCount) * aSlotSize;
    if (aBlockSize64 > std::numeric_limits<std::uint32_t>::max())
    {
        Fail(aHeaderOffset, theDescriptor.mName, "DataArray 块过大");
    }
    const std::size_t aBlockOffset = theReader.Position() + 4;
    const auto aBlock = theReader.SyncBytes(
        static_cast<std::uint32_t>(aBlockSize64),
        std::string(theDescriptor.mName) + ".slots");

    aResult.mSlots.reserve(aResult.mMaxUsedCount);
    for (std::uint32_t i = 0; i < aResult.mMaxUsedCount; ++i)
    {
        const std::size_t aSlotOffset = static_cast<std::size_t>(i) * aSlotSize;
        const auto aSlotBytes = aBlock.subspan(aSlotOffset, aSlotSize);
        SlotSnapshot aSlot;
        aSlot.mID = ReadU32At(aSlotBytes, anObjectSize);
        if (aSlot.mID & DATA_ARRAY_KEY_MASK)
        {
            aSlot.mCanonicalRecord = ToCanonicalRecord(
                aSlotBytes.first(anObjectSize),
                theFormat,
                theDescriptor.mKind,
                aBlockOffset + aSlotOffset,
                std::string(theDescriptor.mName) + "[" + std::to_string(i) + "]");
        }
        else
        {
            aSlot.mCanonicalRecord.assign(aLayout.mDat64Size, 0);
        }

        if (theFormat == Format::Dat64V1)
        {
            for (std::size_t p = anObjectSize + 4; p < aSlotSize; ++p)
            {
                if (aSlotBytes[p] != 0)
                {
                    Fail(aBlockOffset + aSlotOffset + p,
                        std::string(theDescriptor.mName) + ".slotPadding",
                        "必须为零");
                }
            }
        }
        aResult.mSlots.push_back(std::move(aSlot));
    }

    ValidateFreeList(aResult, theDescriptor, aHeaderOffset);
    return aResult;
}

std::vector<std::uint32_t> ReadIDList(
    Reader& theReader,
    const std::string& theField)
{
    const std::size_t aCountOffset = theReader.Position();
    const std::int32_t aCount = theReader.I32(theField + ".count");
    if (aCount < 0 || aCount > 1024)
    {
        Fail(aCountOffset, theField, "ID 列表数量不在 0..1024");
    }
    std::vector<std::uint32_t> aResult;
    aResult.reserve(aCount);
    for (int i = 0; i < aCount; ++i)
    {
        const auto anID = theReader.SyncBytes(4, theField + "[" + std::to_string(i) + "]");
        aResult.push_back(ReadU32At(anID, 0));
    }
    return aResult;
}

void ValidateResourceID(
    std::int32_t theResourceID,
    std::size_t theOffset,
    const std::string& theField)
{
    const int aMaximum = static_cast<int>(Sexy::ResourceId::RESOURCE_ID_MAX);
    if (theResourceID < 0 || theResourceID > aMaximum)
    {
        Fail(theOffset, theField, "资源 ID 越界");
    }
}

struct ReanimationChoiceKey
{
    std::uint32_t mIndex;
    std::size_t mPosition;
    bool operator==(const ReanimationChoiceKey&) const = default;
};

struct ReanimationChoiceHash
{
    std::size_t operator()(const ReanimationChoiceKey& theKey) const noexcept
    {
        return std::hash<std::size_t>{}(theKey.mPosition) ^
            (static_cast<std::size_t>(theKey.mIndex) * 0x9E3779B97F4A7C15ULL);
    }
};

std::vector<ReanimationSupplement> ReadReanimations(
    Reader& theReader,
    Format theFormat,
    std::uint32_t theCount,
    std::size_t theEnd)
{
    const auto aData = theReader.Data();
    const std::size_t aStart = theReader.Position();
    const RecordLayout& aTrackLayout =
        LevelSaveFormat::GetRecordLayout(RecordKind::ReanimatorTrackInstance);
    const std::size_t aTrackSize = theFormat == Format::Legacy1073Dat
        ? aTrackLayout.mLegacySize
        : aTrackLayout.mDat64Size;
    const std::size_t aTrackBoolOffset = theFormat == Format::Legacy1073Dat ? 92 : 108;
    const int aResourceMaximum = static_cast<int>(Sexy::ResourceId::RESOURCE_ID_MAX);

    std::unordered_map<ReanimationChoiceKey, int, ReanimationChoiceHash> aMemo;
    std::function<bool(std::uint32_t, std::size_t)> Solve =
        [&](std::uint32_t theIndex, std::size_t thePosition) -> bool
    {
        const ReanimationChoiceKey aKey{theIndex, thePosition};
        if (const auto anIt = aMemo.find(aKey); anIt != aMemo.end())
        {
            return anIt->second >= 0;
        }
        if (theIndex == theCount)
        {
            const bool isDone = thePosition == theEnd;
            aMemo.emplace(aKey, isDone ? 0 : -2);
            return isDone;
        }
        if (thePosition + 4 > theEnd)
        {
            aMemo.emplace(aKey, -2);
            return false;
        }
        const std::int32_t aDefinition = ReadI32At(aData, thePosition);
        if (aDefinition < 0 || aDefinition >= NUM_REANIMS)
        {
            aMemo.emplace(aKey, -2);
            return false;
        }

        if (thePosition + 8 <= theEnd)
        {
            const std::uint32_t aByteCount = ReadU32At(aData, thePosition + 4);
            if (aByteCount > 0 && aByteCount % aTrackSize == 0)
            {
                const std::uint32_t aTrackCount = aByteCount / static_cast<std::uint32_t>(aTrackSize);
                const std::size_t aTrackStart = thePosition + 8;
                const std::size_t anImageStart = aTrackStart + aByteCount;
                const std::size_t aNext = anImageStart + static_cast<std::size_t>(aTrackCount) * 4;
                bool isPlausible = aTrackCount <= 4096 && aNext <= theEnd;
                for (std::uint32_t i = 0; isPlausible && i < aTrackCount; ++i)
                {
                    const std::size_t aTrack = aTrackStart + static_cast<std::size_t>(i) * aTrackSize;
                    for (std::size_t b = 0; b < 4; ++b)
                    {
                        if (aData[aTrack + aTrackBoolOffset + b] > 1)
                        {
                            isPlausible = false;
                            break;
                        }
                    }
                    const std::int32_t aResource = ReadI32At(aData, anImageStart + i * 4);
                    if (aResource < 0 || aResource > aResourceMaximum)
                    {
                        isPlausible = false;
                    }
                }
                if (isPlausible && Solve(theIndex + 1, aNext))
                {
                    aMemo[aKey] = static_cast<int>(aTrackCount);
                    return true;
                }
            }
        }

        if (Solve(theIndex + 1, thePosition + 4))
        {
            aMemo[aKey] = 0;
            return true;
        }
        aMemo[aKey] = -2;
        return false;
    };

    if (!Solve(0, aStart))
    {
        Fail(aStart, "Reanimation supplements", "无法按全部字段解析到固定尾块");
    }

    std::vector<ReanimationSupplement> aResult;
    aResult.reserve(theCount);
    for (std::uint32_t index = 0; index < theCount; ++index)
    {
        const std::size_t aDefinitionOffset = theReader.Position();
        ReanimationSupplement aReanimation;
        aReanimation.mDefinitionID = theReader.I32("Reanimation.definition");
        if (aReanimation.mDefinitionID < 0 || aReanimation.mDefinitionID >= NUM_REANIMS)
        {
            Fail(aDefinitionOffset, "Reanimation.definition", "定义 ID 越界");
        }
        const ReanimationChoiceKey aKey{index, aDefinitionOffset};
        const int aTrackCount = aMemo.at(aKey);
        if (aTrackCount > 0)
        {
            const std::size_t aTrackBlockOffset = theReader.Position() + 4;
            const auto aTrackBlock = theReader.SyncBytes(
                static_cast<std::size_t>(aTrackCount) * aTrackSize,
                "Reanimation.tracks");
            aReanimation.mCanonicalTracks.reserve(aTrackCount);
            aReanimation.mImageResourceIDs.reserve(aTrackCount);
            for (int track = 0; track < aTrackCount; ++track)
            {
                aReanimation.mCanonicalTracks.push_back(ToCanonicalRecord(
                    aTrackBlock.subspan(static_cast<std::size_t>(track) * aTrackSize, aTrackSize),
                    theFormat,
                    RecordKind::ReanimatorTrackInstance,
                    aTrackBlockOffset + static_cast<std::size_t>(track) * aTrackSize,
                    "Reanimation.track[" + std::to_string(track) + "]"));
            }
            for (int track = 0; track < aTrackCount; ++track)
            {
                const std::size_t anImageOffset = theReader.Position();
                const std::int32_t anImage = theReader.I32("Reanimation.trackImage");
                ValidateResourceID(anImage, anImageOffset, "Reanimation.trackImage");
                aReanimation.mImageResourceIDs.push_back(anImage);
            }
        }
        aResult.push_back(std::move(aReanimation));
    }
    if (theReader.Position() != theEnd)
    {
        Fail(theReader.Position(), "Reanimation supplements", "没有正好结束在 Trail 定义之前");
    }
    return aResult;
}

void ValidateReferences(const Document& theDocument)
{
    const std::vector<std::uint32_t> anEmitterIDs = LiveIDs(theDocument.mArrays[7]);
    const std::vector<std::uint32_t> aParticleIDs = LiveIDs(theDocument.mArrays[8]);
    const std::unordered_set<std::uint32_t> anEmitterSet(anEmitterIDs.begin(), anEmitterIDs.end());
    const std::unordered_set<std::uint32_t> aParticleSet(aParticleIDs.begin(), aParticleIDs.end());
    std::unordered_set<std::uint32_t> seenEmitters;
    std::unordered_set<std::uint32_t> seenParticles;

    for (const ParticleSystemSupplement& aSystem : theDocument.mParticleSystems)
    {
        for (const std::uint32_t anEmitterID : aSystem.mEmitterIDs)
        {
            if (!anEmitterSet.contains(anEmitterID))
            {
                Fail("粒子系统引用了不存在的 ParticleEmitter ID");
            }
            if (!seenEmitters.insert(anEmitterID).second)
            {
                Fail("同一个 ParticleEmitter ID 被多个粒子系统重复拥有");
            }
        }
        for (const EmitterSupplement& anEmitter : aSystem.mEmitters)
        {
            for (const std::uint32_t aParticleID : anEmitter.mParticleIDs)
            {
                if (!aParticleSet.contains(aParticleID))
                {
                    Fail("粒子发射器引用了不存在的 Particle ID");
                }
                if (!seenParticles.insert(aParticleID).second)
                {
                    Fail("同一个 Particle ID 被多个发射器重复拥有");
                }
            }
        }
    }
    if (seenEmitters.size() != anEmitterSet.size())
    {
        Fail("存在没有归属粒子系统的存活 ParticleEmitter");
    }
    if (seenParticles.size() != aParticleSet.size())
    {
        Fail("存在没有归属发射器的存活 Particle");
    }
}

Document ParsePayload(Reader& theReader, Format theFormat)
{
    Document aDocument;
    const std::size_t aBoardOffset = theReader.Position() + 4;
    const std::size_t aBoardSize = theFormat == Format::Legacy1073Dat
        ? LevelSaveFormat::LEGACY_BOARD_STATE_SIZE
        : LevelSaveFormat::DAT64_BOARD_STATE_SIZE;
    const auto aBoard = theReader.SyncBytes(aBoardSize, "Board");
    aDocument.mCanonicalBoard = BoardToCanonical(aBoard, theFormat, aBoardOffset);

    for (std::size_t i = 0; i < ARRAY_DESCRIPTORS.size(); ++i)
    {
        aDocument.mArrays[i] = ReadArray(theReader, theFormat, ARRAY_DESCRIPTORS[i]);
    }

    const std::vector<std::uint32_t> aParticleSystemIDs = LiveIDs(aDocument.mArrays[6]);
    aDocument.mParticleSystems.reserve(aParticleSystemIDs.size());
    for (std::size_t system = 0; system < aParticleSystemIDs.size(); ++system)
    {
        ParticleSystemSupplement aSystem;
        const std::size_t aDefinitionOffset = theReader.Position();
        aSystem.mDefinitionID = theReader.I32("ParticleSystem.definition");
        if (aSystem.mDefinitionID < 0 || aSystem.mDefinitionID >= NUM_PARTICLES)
        {
            Fail(aDefinitionOffset, "ParticleSystem.definition", "定义 ID 越界");
        }
        aSystem.mEmitterIDs = ReadIDList(theReader, "ParticleSystem.emitters");
        aSystem.mEmitters.reserve(aSystem.mEmitterIDs.size());
        for (std::size_t emitter = 0; emitter < aSystem.mEmitterIDs.size(); ++emitter)
        {
            EmitterSupplement anEmitter;
            const std::size_t anEmitterDefOffset = theReader.Position();
            anEmitter.mDefinitionIndex = theReader.I32("ParticleEmitter.definitionIndex");
            if (anEmitter.mDefinitionIndex < 0 || anEmitter.mDefinitionIndex >= 4096)
            {
                Fail(anEmitterDefOffset, "ParticleEmitter.definitionIndex", "索引越界");
            }
            const std::size_t anImageOffset = theReader.Position();
            anEmitter.mImageResourceID = theReader.I32("ParticleEmitter.imageOverride");
            ValidateResourceID(anEmitter.mImageResourceID, anImageOffset, "ParticleEmitter.imageOverride");
            anEmitter.mParticleIDs = ReadIDList(theReader, "ParticleEmitter.particles");
            aSystem.mEmitters.push_back(std::move(anEmitter));
        }
        aDocument.mParticleSystems.push_back(std::move(aSystem));
    }

    const std::size_t aFixedTailSize = theFormat == Format::Legacy1073Dat
        ? LEGACY_FIXED_TAIL_SIZE
        : DAT64_FIXED_TAIL_SIZE;
    if (theReader.Size() < aFixedTailSize)
    {
        Fail(theReader.Position(), "fixedTail", "文件短于固定尾块");
    }
    const std::size_t aFixedTailOffset = theReader.Size() - aFixedTailSize;
    const std::uint32_t aTrailCount = aDocument.mArrays[10].mSize;
    if (aFixedTailOffset < static_cast<std::size_t>(aTrailCount) * 4 ||
        aFixedTailOffset - static_cast<std::size_t>(aTrailCount) * 4 < theReader.Position())
    {
        Fail(theReader.Position(), "dynamicTail", "动态块与固定尾块重叠");
    }
    const std::size_t aReanimationEnd =
        aFixedTailOffset - static_cast<std::size_t>(aTrailCount) * 4;
    aDocument.mReanimations = ReadReanimations(
        theReader,
        theFormat,
        aDocument.mArrays[9].mSize,
        aReanimationEnd);

    aDocument.mTrailDefinitionIDs.reserve(aTrailCount);
    for (std::uint32_t i = 0; i < aTrailCount; ++i)
    {
        const std::size_t anOffset = theReader.Position();
        const std::int32_t aDefinition = theReader.I32("Trail.definition");
        if (aDefinition < 0 || aDefinition >= NUM_TRAIL_DEFINITIONS_1073)
        {
            Fail(anOffset, "Trail.definition", "定义 ID 越界");
        }
        aDocument.mTrailDefinitionIDs.push_back(aDefinition);
    }
    if (theReader.Position() != aFixedTailOffset)
    {
        Fail(theReader.Position(), "fixedTail", "Trail 定义没有正好到达固定尾块");
    }

    const auto ReadFixed = [&](RecordKind theKind, const std::string& theName)
    {
        const RecordLayout& aLayout = LevelSaveFormat::GetRecordLayout(theKind);
        const std::size_t aSize = theFormat == Format::Legacy1073Dat
            ? aLayout.mLegacySize
            : aLayout.mDat64Size;
        const std::size_t anOffset = theReader.Position() + 4;
        return ToCanonicalRecord(
            theReader.SyncBytes(aSize, theName),
            theFormat,
            theKind,
            anOffset,
            theName);
    };

    aDocument.mCursorObject = ReadFixed(RecordKind::CursorObject, "CursorObject");
    aDocument.mCursorPreview = ReadFixed(RecordKind::CursorPreview, "CursorPreview");
    aDocument.mMessageWidget = ReadFixed(RecordKind::MessageWidget, "MessageWidget");

    const std::size_t aSeedBankSize = theFormat == Format::Legacy1073Dat
        ? LevelSaveFormat::LEGACY_SEED_BANK_SIZE
        : LevelSaveFormat::DAT64_SEED_BANK_SIZE;
    const std::size_t aSeedBankOffset = theReader.Position() + 4;
    aDocument.mSeedBank = SeedBankToCanonical(
        theReader.SyncBytes(aSeedBankSize, "SeedBank"),
        theFormat,
        aSeedBankOffset);

    aDocument.mChallenge = ReadFixed(RecordKind::Challenge, "Challenge");
    aDocument.mMusic = ReadFixed(RecordKind::Music, "Music");

    if (theFormat == Format::Legacy1073Dat)
    {
        const std::size_t anEndOffset = theReader.Position();
        if (theReader.U32("legacy.endMarker") != LEGACY_MAGIC)
        {
            Fail(anEndOffset, "legacy.endMarker", "不是 0xFEEDDEAD");
        }
    }
    else
    {
        const auto anEnd = theReader.SyncBytes(8, "dat64.endMarker");
        if (ReadU64At(anEnd, 0) != LevelSaveFormat::DAT64_END_MARKER)
        {
            Fail(theReader.Position() - 8, "dat64.endMarker", "结束标记错误");
        }
    }
    if (theReader.Remaining() != 0)
    {
        Fail(theReader.Position(), "file", "结束标记后仍有多余字节");
    }

    ValidateReferences(aDocument);
    return aDocument;
}

Document ParseLegacy(std::span<const Byte> theFile)
{
    Reader aReader(theFile);
    const auto aHeader = aReader.SyncBytes(12, "legacy.header");
    if (ReadU32At(aHeader, 0) != LEGACY_MAGIC ||
        ReadU32At(aHeader, 4) != LEGACY_VERSION ||
        ReadU32At(aHeader, 8) != LEGACY_DATE)
    {
        Fail(4, "legacy.header", "不是 PvZ 1.2.0.1073 关卡存档");
    }
    return ParsePayload(aReader, Format::Legacy1073Dat);
}

Document ParseDat64(std::span<const Byte> theFile)
{
    if (theFile.size() < LevelSaveFormat::DAT64_HEADER_SIZE)
    {
        Fail(0, "dat64.header", "文件短于 48 字节头部");
    }
    if (!std::equal(
            LevelSaveFormat::DAT64_MAGIC.begin(),
            LevelSaveFormat::DAT64_MAGIC.end(),
            theFile.begin()))
    {
        Fail(0, "dat64.magic", "不是 PVZDAT64");
    }
    if (ReadU32At(theFile, 8) != LevelSaveFormat::DAT64_VERSION ||
        ReadU32At(theFile, 12) != LevelSaveFormat::DAT64_HEADER_SIZE ||
        ReadU32At(theFile, 16) != LevelSaveFormat::DAT64_AUTHORITY_BUILD ||
        ReadU32At(theFile, 20) != LevelSaveFormat::DAT64_FLAGS ||
        ReadU32At(theFile, 36) != LevelSaveFormat::DAT64_SCHEMA_ID ||
        ReadU64At(theFile, 40) != 0)
    {
        Fail(8, "dat64.header", "版本、权威版本、flags、schema 或保留字段错误");
    }
    const std::uint64_t aPayloadSize = ReadU64At(theFile, 24);
    if (aPayloadSize != theFile.size() - LevelSaveFormat::DAT64_HEADER_SIZE)
    {
        Fail(24, "dat64.payloadSize", "与实际文件长度不一致");
    }
    const auto aPayload = theFile.subspan(LevelSaveFormat::DAT64_HEADER_SIZE);
    const std::uint32_t aStoredCRC = ReadU32At(theFile, 32);
    const std::uint32_t anActualCRC = Crc32(aPayload);
    if (aStoredCRC != anActualCRC)
    {
        std::ostringstream aReason;
        aReason << "CRC32 为 0x" << std::hex << anActualCRC
                << "，头部记录 0x" << aStoredCRC;
        Fail(32, "dat64.payloadCRC32", aReason.str());
    }
    Reader aReader(aPayload);
    return ParsePayload(aReader, Format::Dat64V1);
}

Document Parse(std::span<const Byte> theFile, Format theFormat)
{
    return theFormat == Format::Legacy1073Dat
        ? ParseLegacy(theFile)
        : ParseDat64(theFile);
}

void WriteIDList(Writer& theWriter, const std::vector<std::uint32_t>& theIDs)
{
    theWriter.I32(static_cast<std::int32_t>(theIDs.size()));
    for (const std::uint32_t anID : theIDs)
    {
        std::array<Byte, 4> aBytes{};
        WriteU32At(aBytes, 0, anID);
        theWriter.SyncBytes(aBytes);
    }
}

void WriteArray(
    Writer& theWriter,
    const ArraySnapshot& theArray,
    Format theFormat)
{
    const RecordLayout& aLayout = LevelSaveFormat::GetRecordLayout(theArray.mKind);
    const std::size_t aSlotSize = theFormat == Format::Legacy1073Dat
        ? aLayout.mLegacyArraySlotSize
        : aLayout.mDat64ArraySlotSize;
    const std::size_t anObjectSize = theFormat == Format::Legacy1073Dat
        ? aLayout.mLegacySize
        : aLayout.mDat64Size;
    theWriter.U32(theArray.mFreeListHead);
    theWriter.U32(theArray.mMaxUsedCount);
    theWriter.U32(theArray.mSize);
    std::vector<Byte> aBlock(static_cast<std::size_t>(theArray.mMaxUsedCount) * aSlotSize, 0);
    for (std::size_t i = 0; i < theArray.mSlots.size(); ++i)
    {
        const SlotSnapshot& aSlot = theArray.mSlots[i];
        Byte* aDestination = aBlock.data() + i * aSlotSize;
        if (aSlot.mID & DATA_ARRAY_KEY_MASK)
        {
            const std::vector<Byte> aRecord = FromCanonicalRecord(
                aSlot.mCanonicalRecord,
                theFormat,
                theArray.mKind);
            std::memcpy(aDestination, aRecord.data(), aRecord.size());
        }
        WriteU32At(
            std::span<Byte>(aDestination, aSlotSize),
            anObjectSize,
            aSlot.mID);
    }
    theWriter.SyncBytes(aBlock);
}

std::vector<Byte> WritePayload(const Document& theDocument, Format theFormat)
{
    Writer aWriter;
    const std::vector<Byte> aBoard = BoardFromCanonical(theDocument.mCanonicalBoard, theFormat);
    aWriter.SyncBytes(aBoard);
    for (const ArraySnapshot& anArray : theDocument.mArrays)
    {
        WriteArray(aWriter, anArray, theFormat);
    }

    for (const ParticleSystemSupplement& aSystem : theDocument.mParticleSystems)
    {
        aWriter.I32(aSystem.mDefinitionID);
        WriteIDList(aWriter, aSystem.mEmitterIDs);
        for (const EmitterSupplement& anEmitter : aSystem.mEmitters)
        {
            aWriter.I32(anEmitter.mDefinitionIndex);
            aWriter.I32(anEmitter.mImageResourceID);
            WriteIDList(aWriter, anEmitter.mParticleIDs);
        }
    }

    for (const ReanimationSupplement& aReanimation : theDocument.mReanimations)
    {
        aWriter.I32(aReanimation.mDefinitionID);
        if (!aReanimation.mCanonicalTracks.empty())
        {
            const RecordLayout& aLayout =
                LevelSaveFormat::GetRecordLayout(RecordKind::ReanimatorTrackInstance);
            const std::size_t aTrackSize = theFormat == Format::Legacy1073Dat
                ? aLayout.mLegacySize
                : aLayout.mDat64Size;
            std::vector<Byte> aTrackBlock(
                aReanimation.mCanonicalTracks.size() * aTrackSize,
                0);
            for (std::size_t track = 0; track < aReanimation.mCanonicalTracks.size(); ++track)
            {
                const std::vector<Byte> aTrack = FromCanonicalRecord(
                    aReanimation.mCanonicalTracks[track],
                    theFormat,
                    RecordKind::ReanimatorTrackInstance);
                std::memcpy(
                    aTrackBlock.data() + track * aTrackSize,
                    aTrack.data(),
                    aTrack.size());
            }
            aWriter.SyncBytes(aTrackBlock);
            for (const std::int32_t anImageID : aReanimation.mImageResourceIDs)
            {
                aWriter.I32(anImageID);
            }
        }
    }
    for (const std::int32_t aTrailDefinition : theDocument.mTrailDefinitionIDs)
    {
        aWriter.I32(aTrailDefinition);
    }

    const auto WriteFixed = [&](RecordKind theKind, const std::vector<Byte>& theRecord)
    {
        aWriter.SyncBytes(FromCanonicalRecord(theRecord, theFormat, theKind));
    };
    WriteFixed(RecordKind::CursorObject, theDocument.mCursorObject);
    WriteFixed(RecordKind::CursorPreview, theDocument.mCursorPreview);
    WriteFixed(RecordKind::MessageWidget, theDocument.mMessageWidget);
    aWriter.SyncBytes(SeedBankFromCanonical(theDocument.mSeedBank, theFormat));
    WriteFixed(RecordKind::Challenge, theDocument.mChallenge);
    WriteFixed(RecordKind::Music, theDocument.mMusic);

    if (theFormat == Format::Legacy1073Dat)
    {
        aWriter.U32(LEGACY_MAGIC);
    }
    else
    {
        std::array<Byte, 8> anEnd{};
        WriteU64At(anEnd, 0, LevelSaveFormat::DAT64_END_MARKER);
        aWriter.SyncBytes(anEnd);
    }
    return aWriter.Data();
}

std::vector<Byte> WriteFileImage(const Document& theDocument, Format theFormat)
{
    const std::vector<Byte> aPayload = WritePayload(theDocument, theFormat);
    Writer aFile;
    if (theFormat == Format::Legacy1073Dat)
    {
        std::array<Byte, 12> aHeader{};
        WriteU32At(aHeader, 0, LEGACY_MAGIC);
        WriteU32At(aHeader, 4, LEGACY_VERSION);
        WriteU32At(aHeader, 8, LEGACY_DATE);
        aFile.SyncBytes(aHeader);
    }
    else
    {
        aFile.Bytes(LevelSaveFormat::DAT64_MAGIC);
        aFile.U32(LevelSaveFormat::DAT64_VERSION);
        aFile.U32(LevelSaveFormat::DAT64_HEADER_SIZE);
        aFile.U32(LevelSaveFormat::DAT64_AUTHORITY_BUILD);
        aFile.U32(LevelSaveFormat::DAT64_FLAGS);
        aFile.U64(aPayload.size());
        aFile.U32(Crc32(aPayload));
        aFile.U32(LevelSaveFormat::DAT64_SCHEMA_ID);
        aFile.U64(0);
        if (aFile.Position() != LevelSaveFormat::DAT64_HEADER_SIZE)
        {
            Fail("内部错误：dat64 头部不是 48 字节");
        }
    }
    aFile.Bytes(aPayload);
    return aFile.Data();
}

void AtomicWrite(
    const std::filesystem::path& theOutput,
    std::span<const Byte> theData)
{
    const std::filesystem::path aParent = theOutput.parent_path();
    if (!aParent.empty() && !std::filesystem::is_directory(aParent))
    {
        Fail("输出目录不存在：" + aParent.string());
    }
    std::filesystem::path aTemporary = theOutput;
#ifdef _WIN32
    aTemporary += ".tmp." + std::to_string(GetCurrentProcessId());
#else
    aTemporary += ".tmp";
#endif
    if (std::filesystem::exists(aTemporary))
    {
        std::filesystem::remove(aTemporary);
    }

    try
    {
        std::ofstream aFile(aTemporary, std::ios::binary | std::ios::trunc);
        if (!aFile)
        {
            Fail("无法创建临时输出文件：" + aTemporary.string());
        }
        if (!theData.empty())
        {
            aFile.write(
                reinterpret_cast<const char*>(theData.data()),
                static_cast<std::streamsize>(theData.size()));
        }
        aFile.flush();
        if (!aFile)
        {
            Fail("写入临时输出文件失败：" + aTemporary.string());
        }
        aFile.close();

#ifdef _WIN32
        if (!MoveFileExW(
                aTemporary.c_str(),
                theOutput.c_str(),
                MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
        {
            const DWORD anError = GetLastError();
            std::ostringstream aReason;
            aReason << "原子替换目标文件失败，Win32 错误 " << anError;
            Fail(aReason.str());
        }
#else
        std::filesystem::rename(aTemporary, theOutput);
#endif
    }
    catch (...)
    {
        std::error_code anIgnored;
        std::filesystem::remove(aTemporary, anIgnored);
        throw;
    }
}
}

const char* FormatName(Format theFormat)
{
    return theFormat == Format::Legacy1073Dat
        ? "PvZ 1.2.0.1073 game*.dat"
        : "Legacy dat64 v1";
}

Format DetectFormat(const std::filesystem::path& thePath)
{
    const std::vector<Byte> aData = ReadFileFully(thePath);
    if (aData.size() >= LevelSaveFormat::DAT64_MAGIC.size() &&
        std::equal(
            LevelSaveFormat::DAT64_MAGIC.begin(),
            LevelSaveFormat::DAT64_MAGIC.end(),
            aData.begin()))
    {
        ParseDat64(aData);
        return Format::Dat64V1;
    }
    if (aData.size() >= 16 && ReadU32At(aData, 0) == 12 &&
        ReadU32At(aData, 4) == LEGACY_MAGIC)
    {
        ParseLegacy(aData);
        return Format::Legacy1073Dat;
    }
    Fail(0, "file.magic", "既不是 1073 game*.dat，也不是 PVZDAT64");
}

std::filesystem::path DefaultOutputPath(
    const std::filesystem::path& theInput,
    Format theInputFormat)
{
    std::filesystem::path aResult = theInput;
    aResult.replace_extension(
        theInputFormat == Format::Legacy1073Dat ? ".dat64" : ".dat");
    return aResult;
}

ConversionResult ConvertFile(
    const std::filesystem::path& theInput,
    const std::filesystem::path& theOutput)
{
    const std::filesystem::path anInput = std::filesystem::absolute(theInput).lexically_normal();
    const std::filesystem::path anOutput = std::filesystem::absolute(theOutput).lexically_normal();
    if (anInput == anOutput)
    {
        Fail("输入和输出不能是同一个文件");
    }

    const std::vector<Byte> aSource = ReadFileFully(anInput);
    Format aSourceFormat;
    if (aSource.size() >= LevelSaveFormat::DAT64_MAGIC.size() &&
        std::equal(
            LevelSaveFormat::DAT64_MAGIC.begin(),
            LevelSaveFormat::DAT64_MAGIC.end(),
            aSource.begin()))
    {
        aSourceFormat = Format::Dat64V1;
    }
    else if (aSource.size() >= 16 && ReadU32At(aSource, 0) == 12 &&
             ReadU32At(aSource, 4) == LEGACY_MAGIC)
    {
        aSourceFormat = Format::Legacy1073Dat;
    }
    else
    {
        Fail(0, "file.magic", "既不是 1073 game*.dat，也不是 PVZDAT64");
    }

    // Full parse and validation happens before any output file is opened.
    const Document aDocument = Parse(aSource, aSourceFormat);
    const Format aTargetFormat = aSourceFormat == Format::Legacy1073Dat
        ? Format::Dat64V1
        : Format::Legacy1073Dat;
    const std::vector<Byte> aTarget = WriteFileImage(aDocument, aTargetFormat);

    // Parse the generated target with the opposite grammar and compare every
    // canonical field before the atomic write.
    const Document aRoundTrip = Parse(aTarget, aTargetFormat);
    if (aRoundTrip != aDocument)
    {
        Fail("内部错误：生成文件虽能解析，但逐字段语义与输入不一致");
    }

    AtomicWrite(anOutput, aTarget);
    return {
        aSourceFormat,
        aTargetFormat,
        anInput,
        anOutput,
        aSource.size(),
        aTarget.size()
    };
}
}
