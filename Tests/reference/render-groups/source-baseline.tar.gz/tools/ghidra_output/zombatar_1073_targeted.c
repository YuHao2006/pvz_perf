/* 0052f6a0 FUN_0052f6a0 */

void FUN_0052f6a0(int param_1)

{
  bool bVar1;
  bool bVar2;
  bool bVar3;
  int *in_EAX;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int unaff_ESI;
  int *piVar10;
  int local_34;
  int local_30;
  int local_2c;
  int local_28;
  int local_1c;
  int local_18;
  uint *local_14;
  
  *(int *)(unaff_ESI + 0xfc) = *in_EAX;
  *(undefined4 *)(unaff_ESI + 0xf08) = 0xffffffff;
  *(undefined4 *)(unaff_ESI + 0xf0c) = 0xffffffff;
  *(undefined4 *)(unaff_ESI + 0xf0) = 1;
  *(undefined4 *)(unaff_ESI + 0xf4) = 1;
  FUN_0052fda0();
  if ((param_1 == 0) || (*in_EAX == 0)) {
    *(undefined4 *)(unaff_ESI + 0x100) = 0;
    return;
  }
  iVar9 = *(int *)(unaff_ESI + 0xf8);
  iVar4 = FUN_0059aba0();
  iVar4 = (*(int *)(unaff_ESI + 0x48) + (iVar4 + iVar9) * -6) / 2 + 0x32;
  local_30 = iVar9 * 2 + 0x78;
  local_18 = 0;
  local_2c = 0;
  bVar3 = false;
  bVar2 = false;
  local_28 = 0;
  if (0 < *(int *)(unaff_ESI + 0xfc)) {
    local_1c = param_1;
    local_14 = (uint *)(param_1 + 0x1c);
    piVar10 = (int *)(unaff_ESI + 0x11c);
    local_34 = iVar4;
    do {
      if (bVar2) {
        piVar10[-5] = local_34;
        piVar10[-4] = local_30;
        piVar10[-6] = 0;
        bVar2 = false;
      }
      else {
        if ((*(int *)(unaff_ESI + 0xf10) != 8) &&
           ((local_28 == *(int *)(unaff_ESI + 0xfc) + -1 || ((local_28 + 1) % 0x11 == 0)))) {
          bVar2 = true;
          *(int *)(unaff_ESI + 0xfc) = *(int *)(unaff_ESI + 0xfc) + 1;
        }
        piVar10[-5] = local_34;
        piVar10[-4] = local_30;
        piVar10[-6] = local_1c;
        iVar8 = FUN_0059aba0();
        iVar5 = FUN_0059abc0();
        iVar6 = FUN_0059aba0();
        iVar9 = *(int *)(unaff_ESI + 0xf04);
        iVar7 = FUN_0059abc0();
        bVar1 = (float)iVar5 <= (float)(iVar7 + *(int *)(unaff_ESI + 0xf04) * -2);
        if (((float)iVar8 <= (float)(iVar6 + iVar9 * -2)) || ((!bVar1 && (iVar8 < iVar5)))) {
          if (bVar1) {
            piVar10[-1] = iVar8;
            iVar9 = FUN_0059aba0();
            *piVar10 = iVar5;
            piVar10[-3] = (iVar9 - piVar10[-1]) / 2;
            goto LAB_0052f930;
          }
          iVar9 = FUN_0059abc0();
          *piVar10 = iVar9 + *(int *)(unaff_ESI + 0xf04) * -2;
          piVar10[-2] = *(int *)(unaff_ESI + 0xf04);
          iVar9 = FUN_006ba960();
          piVar10[-1] = iVar9;
          iVar9 = FUN_0059aba0();
          piVar10[-3] = (iVar9 - piVar10[-1]) / 2;
        }
        else {
          iVar9 = FUN_0059aba0();
          piVar10[-1] = iVar9 + *(int *)(unaff_ESI + 0xf04) * -2;
          piVar10[-3] = *(int *)(unaff_ESI + 0xf04);
          iVar9 = FUN_006ba960();
          *piVar10 = iVar9;
LAB_0052f930:
          iVar9 = FUN_0059abc0();
          piVar10[-2] = (iVar9 - *piVar10) / 2;
        }
        if ((*local_14 & 2) == 0) {
          if ((*local_14 & 4) != 0) {
            iVar9 = FUN_0059abc0();
            piVar10[-2] = (iVar9 - *(int *)(unaff_ESI + 0xf04)) - *piVar10;
          }
        }
        else {
          piVar10[-2] = *(int *)(unaff_ESI + 0xf04);
        }
        if ((*local_14 & 8) == 0) {
          if ((*local_14 & 0x10) != 0) {
            iVar9 = FUN_0059aba0();
            piVar10[-3] = (iVar9 - *(int *)(unaff_ESI + 0xf04)) - piVar10[-1];
          }
        }
        else {
          piVar10[-3] = *(int *)(unaff_ESI + 0xf04);
        }
        local_1c = local_1c + 0x28;
      }
      local_2c = local_2c + 1;
      if (local_2c < 6) {
        iVar9 = FUN_0059aba0();
        local_34 = local_34 + iVar9 + *(int *)(unaff_ESI + 0xf8);
      }
      else {
        iVar9 = *(int *)(unaff_ESI + 0xf8);
        iVar8 = FUN_0059abc0();
        local_30 = local_30 + 3 + iVar8 + iVar9;
        local_18 = local_18 + 1;
        local_2c = 0;
        local_34 = iVar4;
        if ((2 < local_18) && (local_28 < *(int *)(unaff_ESI + 0xfc) + -1)) {
          *(int *)(unaff_ESI + 0xf4) = *(int *)(unaff_ESI + 0xf4) + 1;
          local_30 = iVar9 * 2 + 0x78;
          local_2c = 0;
          local_18 = 0;
          if (!bVar3) {
            *(int *)(unaff_ESI + 0x100) = local_28 + 1;
            bVar3 = true;
          }
        }
      }
      local_14 = local_14 + 10;
      local_28 = local_28 + 1;
      piVar10 = piVar10 + 7;
    } while (local_28 < *(int *)(unaff_ESI + 0xfc));
    if (bVar3) goto LAB_0052fa6a;
  }
  *(undefined4 *)(unaff_ESI + 0x100) = *(undefined4 *)(unaff_ESI + 0xfc);
LAB_0052fa6a:
  *(undefined1 *)(*(int *)(unaff_ESI + 0xa4) + 0x1a) = 1;
  if (1 < *(int *)(unaff_ESI + 0xf4)) {
    *(undefined1 *)(*(int *)(unaff_ESI + 0xa8) + 0x1a) = 0;
    return;
  }
  *(undefined1 *)(*(int *)(unaff_ESI + 0xa8) + 0x1a) = 1;
  return;
}



/* 0052fbf0 FUN_0052fbf0 */

int FUN_0052fbf0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int unaff_ESI;
  int *piVar4;
  int local_4;
  
  if (unaff_ESI == -0x104) {
    return -1;
  }
  local_4 = (*(int *)(unaff_ESI + 0xf0) + -1) * *(int *)(unaff_ESI + 0x100);
  iVar3 = 0;
  if (0 < *(int *)(unaff_ESI + 0x100)) {
    piVar4 = (int *)(unaff_ESI + 0x10c + local_4 * 0x1c);
    do {
      if (*(int *)(unaff_ESI + 0xfc) <= local_4) {
        return -1;
      }
      if (*(int *)(unaff_ESI + 0xf04) + piVar4[-1] <= *param_1) {
        iVar2 = *(int *)(unaff_ESI + 0xf04);
        iVar1 = FUN_0059aba0();
        if (((*param_1 <= iVar1 + (piVar4[-1] - iVar2)) && (*piVar4 + iVar2 <= *param_2)) &&
           (iVar2 = FUN_0059abc0(), *param_2 <= iVar2 + (*piVar4 - *(int *)(unaff_ESI + 0xf04)))) {
          return local_4;
        }
      }
      local_4 = local_4 + 1;
      iVar3 = iVar3 + 1;
      piVar4 = piVar4 + 7;
      if (*(int *)(unaff_ESI + 0x100) <= iVar3) {
        return -1;
      }
    } while( true );
  }
  return -1;
}



/* 0052fcd0 FUN_0052fcd0 */

undefined ** __fastcall FUN_0052fcd0(int param_1)

{
  int *in_EAX;
  uint uVar1;
  undefined **ppuVar2;
  
  uVar1 = *(uint *)(param_1 + 0x24 + *in_EAX * 4);
  ppuVar2 = (undefined **)0x0;
  if (uVar1 != 0xffffffff) {
    if (0x10 < (int)uVar1) {
      uVar1 = uVar1 - uVar1 / 0x11;
    }
    switch(*in_EAX) {
    case 1:
      return &PTR_DAT_0071ca68 + uVar1 * 10;
    case 2:
      return &PTR_DAT_0071c5b8 + uVar1 * 10;
    case 3:
      return &PTR_DAT_0071cc48 + uVar1 * 10;
    case 4:
      return &PTR_DAT_0071c1f8 + uVar1 * 10;
    case 5:
      return &PTR_DAT_0071bf78 + uVar1 * 10;
    case 6:
      return &PTR_DAT_0071c7e8 + uVar1 * 10;
    case 7:
      return &PTR_DAT_0071cea0 + uVar1 * 10;
    case 8:
      ppuVar2 = &PTR_DAT_0071d0d0 + uVar1 * 10;
    }
  }
  return ppuVar2;
}



/* 0052fda0 FUN_0052fda0 */

void FUN_0052fda0(void)

{
  int in_EAX;
  int iVar1;
  int iVar2;
  
  if (*(int *)(in_EAX + 0xfc) == 0) {
    *(undefined4 *)(*(int *)(in_EAX + 0xec) + 0xd8) = 0;
    FUN_0052d3b0();
    return;
  }
  if (*(int *)(in_EAX + 0xf38 + *(int *)(in_EAX + 0xf10) * 4) == -1) {
    *(undefined4 *)(*(int *)(in_EAX + 0xec) + 0xd8) = 3;
    FUN_0052d3b0();
    return;
  }
  iVar1 = FUN_0052fcd0();
  if (*(int *)(iVar1 + 0x18) == 4) {
    *(undefined4 *)(*(int *)(in_EAX + 0xec) + 0xd8) = 4;
    FUN_0052d3b0();
    return;
  }
  iVar1 = *(int *)(in_EAX + 0xec);
  iVar2 = FUN_0052fcd0();
  *(undefined4 *)(iVar1 + 0xd8) = *(undefined4 *)(iVar2 + 0x18);
  FUN_0052d3b0();
  return;
}



/* 0052fe90 FUN_0052fe90 */

void FUN_0052fe90(int param_1)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  int iVar5;
  CRect *pCVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  CMFCCaptionButtonEx *unaff_ESI;
  int *piVar11;
  undefined4 uVar12;
  int local_98;
  int local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  uint local_6c;
  uint local_64;
  undefined4 local_54;
  uint local_50;
  uint local_48;
  undefined4 local_38;
  uint local_34;
  void *pvStack_10;
  void *pvStack_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c804b;
  pvStack_c = ExceptionList;
  ExceptionList = &pvStack_c;
  FUN_00598a60(DAT_00727080,0x7f,100);
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xac));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xb0));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xb4));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xb8));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xbc));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xc0));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xc4));
  FUN_0044aac0(*(undefined4 *)(param_1 + 200));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xcc));
  if (*(int *)(param_1 + 0xfc) == 0) {
    iVar5 = *(int *)(param_1 + 0x48);
    local_50 = 0xf;
    local_54 = 0;
    local_64 = local_64 & 0xffffff00;
    FUN_004020c0("[ZOMBATAR_START_TEXT]",0x15);
    local_4 = 1;
    FUN_005615d0(0xfe,0xe3,0,0xaf);
    FUN_00523b90();
    local_4 = CONCAT31(local_4._1_3_,2);
    local_80 = 0xa0;
    local_7c = 500;
    local_78 = 100;
    local_84 = iVar5 / 2 + -200;
    FUN_005241c0();
    if (0xf < local_34) {
      FUN_00699e4a(local_48);
    }
    local_4 = 0xffffffff;
    local_34 = 0xf;
    local_38 = 0;
    local_48 = local_48 & 0xffffff00;
    if (0xf < local_50) {
      FUN_00699e4a(local_64);
    }
    local_50 = 0xf;
    local_54 = 0;
    local_64 = local_64 & 0xffffff00;
  }
  else {
    iVar5 = (*(int *)(param_1 + 0xf0) + -1) * *(int *)(param_1 + 0x100);
    local_98 = 0;
    if (0 < *(int *)(param_1 + 0x100)) {
      piVar11 = (int *)(param_1 + 0x10c + iVar5 * 0x1c);
      do {
        if (*(int *)(param_1 + 0xfc) <= iVar5) break;
        if ((*(int *)(param_1 + 0xf08) == -1) || (bVar3 = true, *(int *)(param_1 + 0xf08) != iVar5))
        {
          bVar3 = false;
        }
        iVar1 = *(int *)(param_1 + 0xf38 + *(int *)(param_1 + 0xf10) * 4);
        bVar2 = false;
        bVar4 = false;
        if ((iVar1 != -1) && (iVar1 == iVar5)) {
          bVar4 = true;
          bVar2 = true;
        }
        if ((bVar3) || (bVar2)) {
          FUN_005983e0(0);
          uVar12 = DAT_00727318;
          if (!bVar2) goto LAB_0053002b;
        }
        else {
          pCVar6 = (CRect *)FUN_005615d0(0x80,0x80,0x80,0x80);
          CMFCCaptionButtonEx::SetRect(unaff_ESI,pCVar6);
          FUN_005983e0(1);
LAB_0053002b:
          uVar12 = DAT_00726a64;
        }
        FUN_00598a60(uVar12,piVar11[-1],*piVar11);
        if (piVar11[-2] == 0) {
          FUN_00598a60(DAT_00726f80,piVar11[-1],*piVar11);
        }
        else {
          if (*(int *)(param_1 + 0xf10) == 1) {
            FUN_005981d0();
            iVar1 = *(int *)(param_1 + 0xf04);
            iVar7 = FUN_0059abc0();
            iVar7 = iVar7 - *(int *)(param_1 + 0xf04);
            iVar8 = FUN_0059aba0(iVar7);
            FUN_005993f0(piVar11[-1] + iVar1,*piVar11 + iVar1,iVar8 - iVar1,iVar7);
            if (*(int *)(param_1 + 0xf14) == -1) {
              puVar9 = &DAT_007a2300;
            }
            else {
              puVar9 = (undefined4 *)(&DAT_007a2010 + *(int *)(param_1 + 0xf14) * 0x10);
            }
            if ((bVar3) || (bVar4)) {
              uVar12 = 0xff;
            }
            else {
              uVar12 = 0x80;
            }
            pCVar6 = (CRect *)FUN_005615d0(*puVar9,puVar9[1],puVar9[2],uVar12);
            CMFCCaptionButtonEx::SetRect(unaff_ESI,pCVar6);
            FUN_005983e0(1);
            uVar12 = FUN_0059abc0();
            uVar10 = FUN_0059aba0(uVar12);
            FUN_00599070(DAT_00726778,piVar11[-1] + -10,*piVar11 + -10,uVar10,uVar12);
            FUN_005983e0(0);
            uVar12 = FUN_0059abc0();
            uVar10 = FUN_0059aba0(uVar12);
            FUN_00599070(DAT_00727150,piVar11[-1] + -10,*piVar11 + -10,uVar10,uVar12);
            FUN_00598250();
          }
          if (*(int *)(piVar11[-2] + 4) != 0) {
            FUN_0059aba0();
            FUN_0059abc0();
            iVar1 = piVar11[-2];
            FUN_0059abc0();
            uVar12 = FUN_006ba960();
            FUN_0059aba0(uVar12);
            uVar10 = FUN_006ba960();
            iVar7 = FUN_006ba960(uVar10);
            iVar7 = iVar7 + piVar11[2] + *piVar11;
            iVar8 = FUN_006ba960(iVar7);
            FUN_00599070(**(undefined4 **)(iVar1 + 4),iVar8 + piVar11[1] + piVar11[-1],iVar7,uVar10,
                         uVar12);
          }
          FUN_00599070(**(undefined4 **)piVar11[-2],piVar11[1] + piVar11[-1],piVar11[2] + *piVar11,
                       piVar11[3],piVar11[4]);
        }
        iVar5 = iVar5 + 1;
        local_98 = local_98 + 1;
        piVar11 = piVar11 + 7;
      } while (local_98 < *(int *)(param_1 + 0x100));
    }
    FUN_005983e0(0);
    if (1 < *(int *)(param_1 + 0xf4)) {
      if (*(char *)(*(int *)(param_1 + 0xa4) + 0x1a) == '\x01') {
        FUN_005983e0(1);
        pCVar6 = (CRect *)FUN_005615d0(0x6c,0x6d,0x8c,0x28);
        CMFCCaptionButtonEx::SetRect(unaff_ESI,pCVar6);
        FUN_0044aac0(*(undefined4 *)(param_1 + 0xa4));
        FUN_005983e0(0);
      }
      else {
        FUN_0044aac0(*(int *)(param_1 + 0xa4));
      }
      if (*(char *)(*(int *)(param_1 + 0xa8) + 0x1a) == '\x01') {
        FUN_005983e0(1);
        pCVar6 = (CRect *)FUN_005615d0(0x6c,0x6d,0x8c,0x28);
        CMFCCaptionButtonEx::SetRect(unaff_ESI,pCVar6);
        FUN_0044aac0(*(undefined4 *)(param_1 + 0xa8));
        FUN_005983e0(0);
      }
      else {
        FUN_0044aac0(*(int *)(param_1 + 0xa8));
      }
      FUN_00598330(DAT_00726e60);
      FUN_00600ff0(&local_84,"Page %d / %d",*(undefined4 *)(param_1 + 0xf0),
                   *(undefined4 *)(param_1 + 0xf4));
      local_4 = 0;
      iVar5 = *(int *)(param_1 + 0xa4);
      FUN_00598a10(&local_84,
                   (*(int *)(*(int *)(param_1 + 0xa8) + 8) - *(int *)(iVar5 + 8)) / 2 + -0xf +
                   *(int *)(iVar5 + 8),*(int *)(iVar5 + 0x14) / 2 + 0x32 + *(int *)(iVar5 + 0xc));
      local_4 = 0xffffffff;
      if (0xf < local_6c) {
        FUN_00699e4a(local_80);
      }
    }
  }
  FUN_0052fac0();
  (**(code **)(**(int **)(param_1 + 0xec) + 0x68))();
  ExceptionList = pvStack_10;
  return;
}



/* 00530550 FUN_00530550 */

void FUN_00530550(void)

{
  int in_EAX;
  
                    /* WARNING: Could not recover jumptable at 0x00530551. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&PTR_LAB_00530878)[in_EAX])();
  return;
}



/* 00530890 FUN_00530890 */

void FUN_00530890(void)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int unaff_ESI;
  
  *(undefined4 *)(unaff_ESI + 0xf10) = 0;
  *(undefined4 *)(unaff_ESI + 0xfc) = 0;
  *(undefined4 *)(unaff_ESI + 0xf08) = 0xffffffff;
  *(undefined4 *)(unaff_ESI + 0xf0c) = 0xffffffff;
  *(undefined4 *)(unaff_ESI + 0xf0) = 1;
  *(undefined4 *)(unaff_ESI + 0xf4) = 1;
  FUN_0052fda0();
  *(undefined4 *)(unaff_ESI + 0x100) = 0;
  uVar2 = 0;
  do {
    if (uVar2 == 8) {
      *(undefined4 *)(unaff_ESI + 0xf58) = 4;
      *(undefined4 *)(unaff_ESI + 0xf34) = 0x2f;
    }
    else {
      *(undefined4 *)(unaff_ESI + 0xf38 + uVar2 * 4) = 0xffffffff;
      if (uVar2 == 0) {
        *(undefined4 *)(unaff_ESI + 0xf14) = 0;
      }
      else {
        *(undefined4 *)(unaff_ESI + 0xf14 + uVar2 * 4) = 0xffffffff;
      }
    }
    uVar2 = uVar2 + 1;
  } while (uVar2 < 9);
  *(undefined4 *)(*(int *)(unaff_ESI + 0xec) + 0xd8) = 0;
  FUN_0052d3b0();
  uVar3 = FUN_0059abc0();
  uVar4 = FUN_0059aba0();
  iVar1 = *(int *)(unaff_ESI + 0xd4);
  *(undefined4 *)(iVar1 + 0x14) = uVar3;
  *(undefined4 *)(iVar1 + 8) = 0x1a4;
  *(undefined4 *)(iVar1 + 0xc) = 0x1bf;
  *(undefined4 *)(iVar1 + 0x10) = uVar4;
  *(undefined1 *)(unaff_ESI + 0xf6c) = 1;
  return;
}



/* 00530c90 FUN_00530c90 */

void __fastcall FUN_00530c90(undefined4 param_1,int param_2,uint param_3)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  int *piVar5;
  char ****ppppcVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  char ***local_40 [4];
  undefined4 local_30;
  uint local_2c;
  char ***local_24 [4];
  undefined4 local_14;
  uint local_10;
  void *local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c97c0;
  local_c = ExceptionList;
  iVar9 = (*(uint *)(param_2 + 0x148) & 0xffff) * 0xa0 + **(int **)(*(int *)(param_3 + 0x940) + 8);
  uVar8 = 0;
  ExceptionList = &local_c;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_DAT_0071bf98 + uVar8),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_DAT_0071bf98 + uVar8);
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 0;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    cVar2 = FUN_004779e0(ppppcVar6);
    if (cVar2 != '\0') {
      ppppcVar6 = (char ****)local_40[0];
      if (local_2c < 0x10) {
        ppppcVar6 = local_40;
      }
      FUN_00478120(ppppcVar6,0xffffffff);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    uVar8 = uVar8 + 0x28;
  } while (uVar8 < 0x280);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_facialHair_00_0071c218 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_facialHair_00_0071c218 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 1;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(*piVar5 + iVar7),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 0x3c0);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_eyeWear_00_0071c808 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_eyeWear_00_0071c808 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 2;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(*piVar5 + iVar7),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 0x280);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_tidBits_00_0071c5d8 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_tidBits_00_0071c5d8 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 3;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(iVar7 + *piVar5),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 0x230);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_s_accessories_00_0071cc68 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_s_accessories_00_0071cc68 + param_3);
    iVar7 = 0;
    local_2c = 0xf;
    local_30 = 0;
    local_40[0] = (char ***)((uint)local_40[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 4;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_40[0];
    if (local_2c < 0x10) {
      ppppcVar6 = local_40;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(iVar7 + *piVar5),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_40[0];
          if (local_2c < 0x10) {
            ppppcVar6 = local_40;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_2c) {
      FUN_00699e4a(local_40[0]);
    }
    param_3 = param_3 + 0x28;
  } while (param_3 < 600);
  param_3 = 0;
  do {
    FUN_00478120(*(undefined4 *)((int)&PTR_DAT_0071cec0 + param_3),0xffffffff);
    pcVar1 = *(char **)((int)&PTR_DAT_0071cec0 + param_3);
    iVar7 = 0;
    local_10 = 0xf;
    local_14 = 0;
    local_24[0] = (char ***)((uint)local_24[0] & 0xffffff00);
    pcVar3 = pcVar1;
    do {
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar2 != '\0');
    FUN_004020c0(pcVar1,(int)pcVar3 - (int)(pcVar1 + 1));
    local_4 = 5;
    FUN_00409ad0("_line",5);
    ppppcVar6 = (char ****)local_24[0];
    if (local_10 < 0x10) {
      ppppcVar6 = local_24;
    }
    piVar5 = *(int **)(iVar9 + 0xc);
    iVar10 = 0;
    if (0 < piVar5[1]) {
      do {
        iVar4 = __stricmp(*(char **)(iVar7 + *piVar5),(char *)ppppcVar6);
        if (iVar4 == 0) {
          ppppcVar6 = (char ****)local_24[0];
          if (local_10 < 0x10) {
            ppppcVar6 = local_24;
          }
          FUN_00478120(ppppcVar6,0xffffffff);
          break;
        }
        piVar5 = *(int **)(iVar9 + 0xc);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 0xc;
      } while (iVar10 < piVar5[1]);
    }
    local_4 = 0xffffffff;
    if (0xf < local_10) {
      FUN_00699e4a(local_24[0]);
    }
    param_3 = param_3 + 0x28;
    if (0x22f < param_3) {
      ExceptionList = local_c;
      return;
    }
  } while( true );
}



/* 005313f0 FUN_005313f0 */

/* WARNING: Type propagation algorithm not settling */

void __fastcall FUN_005313f0(int param_1)

{
  longlong lVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *_Dst;
  int local_d8 [2];
  undefined1 auStack_d0 [4];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  uint uStack_c0;
  undefined4 *******apppppppuStack_bc [3];
  undefined4 uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint auStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  undefined1 auStack_88 [120];
  void *pvStack_10;
  void *pvStack_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c38da;
  pvStack_c = ExceptionList;
  ExceptionList = &pvStack_c;
  local_d8[0] = FUN_00699ed2(0x6c);
  local_4 = 0;
  if (local_d8[0] == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    piVar2 = (int *)FUN_005a56b0();
  }
  local_4 = 0xffffffff;
  iVar3 = FUN_0059aba0();
  piVar2[9] = iVar3;
  iVar3 = FUN_0059abc0();
  piVar2[10] = iVar3;
  iVar3 = FUN_0059aba0();
  iVar4 = FUN_0059abc0();
  lVar1 = (ulonglong)(iVar3 * iVar4 + 1) * 4;
  _Dst = (void *)FUN_00688c17(-(uint)((int)((ulonglong)lVar1 >> 0x20) != 0) | (uint)lVar1);
  piVar2[0xe] = (int)_Dst;
  *(undefined1 *)((int)piVar2 + 0x52) = 1;
  *(undefined1 *)((int)piVar2 + 0x51) = 1;
  _memset(_Dst,0,piVar2[10] * piVar2[9] * 4);
  *(undefined4 *)(piVar2[0xe] + piVar2[10] * piVar2[9] * 4) = 0x4beefade;
  FUN_00598040(piVar2);
  local_4 = 1;
  local_d8[1] = 0;
  local_d8[0] = 0;
  FUN_00530970(auStack_88,param_1 + 0xf14,local_d8,local_d8 + 1);
  FUN_0062c0b0();
  local_4._0_1_ = 2;
  uStack_cc = FUN_0059aba0();
  uStack_c8 = FUN_0059abc0();
  uStack_c4 = (**(code **)(*piVar2 + 0x7c))();
  FUN_005db270(&uStack_c0);
  local_4._0_1_ = 3;
  if (uStack_a8 < 0x10) {
    apppppppuStack_bc[0] = apppppppuStack_bc;
  }
  FUN_00600ff0(auStack_a4,"%s\\Zombatar_%d.jpg",apppppppuStack_bc[0],
               *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xa0) + 0x94c) + 0x4840));
  local_4 = CONCAT31(local_4._1_3_,4);
  FUN_0062d6e0(auStack_a4,auStack_d0,0x28);
  uStack_c4 = 0;
  (**(code **)*piVar2)(1);
  if (0xf < uStack_90) {
    FUN_00699e4a(auStack_a4[0]);
  }
  uStack_90 = 0xf;
  uStack_94 = 0;
  auStack_a4[0] = auStack_a4[0] & 0xffffff00;
  if (0xf < uStack_ac) {
    FUN_00699e4a(uStack_c0);
  }
  uStack_ac = 0xf;
  uStack_b0 = 0;
  uStack_c0 = uStack_c0 & 0xffffff00;
  FUN_0062c120();
  FUN_005981a0();
  ExceptionList = pvStack_10;
  return;
}



/* 00531680 FUN_00531680 */

void FUN_00531680(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 local_7c [4];
  uint local_78;
  undefined4 local_68;
  uint local_64;
  undefined1 local_60 [4];
  uint local_5c;
  undefined4 local_4c;
  uint local_48;
  uint uStack_40;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_24;
  uint uStack_10;
  void *local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c6b60;
  local_c = ExceptionList;
  iVar1 = *(int *)(*(int *)(param_1 + 0xa0) + 0x94c);
  if ((iVar1 != 0) && (*(char *)(iVar1 + 0x37c) == '\0')) {
    local_48 = 0xf;
    local_4c = 0;
    local_5c = local_5c & 0xffffff00;
    ExceptionList = &local_c;
    FUN_004020c0(&DAT_006e346c,0);
    local_4 = 0;
    local_64 = 0xf;
    local_68 = 0;
    local_78 = local_78 & 0xffffff00;
    FUN_004020c0(&DAT_006e346c,0);
    local_4._0_1_ = 1;
    uVar2 = FUN_00523c40();
    local_4 = CONCAT31(local_4._1_3_,2);
    (**(code **)(**(int **)(param_1 + 0xa0) + 0x120))(0x37,0,local_7c,uVar2,local_60,3);
    if (0xf < uStack_2c) {
      FUN_00699e4a(uStack_40);
    }
    uStack_2c = 0xf;
    uStack_30 = 0;
    uStack_40 = uStack_40 & 0xffffff00;
    if (0xf < local_64) {
      FUN_00699e4a(local_78);
    }
    local_4 = 0xffffffff;
    local_64 = 0xf;
    local_68 = 0;
    local_78 = local_78 & 0xffffff00;
    if (0xf < local_48) {
      FUN_00699e4a(local_5c);
    }
    local_48 = 0xf;
    local_4c = 0;
    local_5c = local_5c & 0xffffff00;
    uVar2 = FUN_00523c40();
    local_4 = 3;
    FUN_00401c60(uVar2,0,0xffffffff);
    if (0xf < uStack_10) {
      FUN_00699e4a(uStack_24);
    }
  }
  ExceptionList = local_c;
  return;
}



