// t17_store.cpp — ★kStoreBubbleMessage -> StoreScreen::UpdateMouse（每帧·商店）
// FormA = f0563eaf^ 原 31 case switch（逐字）；FormB = HEAD 31 槽 int 数据表（逐字）。
#include "r3_entities.h"

// ==================== FormA：f0563eaf^ switch 逐字 ====================
__declspec(noinline) void StoreScreen::UpdateMouse_A()
{
    mMouseOverItem = STORE_ITEM_INVALID;
    if (!CanInteractWithButtons()) return;
    int aMouseX = mApp->mWidgetManager->mLastMouseX - mX, aMouseY = mApp->mWidgetManager->mLastMouseY - mY;
    bool aShowFinger = false;
    for (int aItemPos = 0; aItemPos < MAX_PAGE_SPOTS; aItemPos++)
    {
        StoreItem aItemType = GetStoreItemType(aItemPos);
        if (aItemType != STORE_ITEM_INVALID && !IsItemUnavailable(aItemType))
        {
            int aItemX, aItemY;
            GetStorePosition(aItemPos, aItemX, aItemY);
            if (Rect(aItemX, aItemY, 50, 87).Contains(aMouseX, aMouseY))
            {
                mMouseOverItem = aItemType;
                int aMessageIndex = -1;
                switch (aItemType)
                {
                case STORE_ITEM_PLANT_GATLINGPEA:       aMessageIndex = 2000;                           break;
                case STORE_ITEM_PLANT_TWINSUNFLOWER:    aMessageIndex = 2001;                           break;
                case STORE_ITEM_PLANT_GLOOMSHROOM:      aMessageIndex = 2002;                           break;
                case STORE_ITEM_PLANT_CATTAIL:          aMessageIndex = 2003;                           break;
                case STORE_ITEM_PLANT_WINTERMELON:      aMessageIndex = 2004;                           break;
                case STORE_ITEM_PLANT_GOLD_MAGNET:      aMessageIndex = 2005;                           break;
                case STORE_ITEM_PLANT_SPIKEROCK:        aMessageIndex = 2006;                           break;
                case STORE_ITEM_PLANT_COBCANNON:        aMessageIndex = 2007;                           break;
                case STORE_ITEM_PLANT_IMITATER:         aMessageIndex = 2008;                           break;
                case STORE_ITEM_BONUS_LAWN_MOWER:       aMessageIndex = 2009;                           break;
                case STORE_ITEM_POTTED_MARIGOLD_1:
                case STORE_ITEM_POTTED_MARIGOLD_2:
                case STORE_ITEM_POTTED_MARIGOLD_3:      aMessageIndex = 2010;                           break;
                case STORE_ITEM_GOLD_WATERINGCAN:       aMessageIndex = 2019;                           break;
                case STORE_ITEM_FERTILIZER:             aMessageIndex = 2020;                           break;
                case STORE_ITEM_BUG_SPRAY:              aMessageIndex = 2022;                           break;
                case STORE_ITEM_PHONOGRAPH:             aMessageIndex = 2021;                           break;
                case STORE_ITEM_GARDENING_GLOVE:        aMessageIndex = 2023;                           break;
                case STORE_ITEM_MUSHROOM_GARDEN:        aMessageIndex = 2032;                           break;
                case STORE_ITEM_WHEEL_BARROW:           aMessageIndex = 2024;                           break;
                case STORE_ITEM_STINKY_THE_SNAIL:       aMessageIndex = 2025;                           break;
                case STORE_ITEM_PACKET_UPGRADE:
                {
                    // 1073 004966D0 uses three exact cases and a default.
                    // Avoid overflow in count+2011 and preserve that default.
                    const int aCount = mApp->mPlayerInfo->mPurchases[STORE_ITEM_PACKET_UPGRADE];
                    aMessageIndex = aCount == 0 ? 2011 : aCount == 1 ? 2012 : aCount == 2 ? 2013 : 2014;
                    break;
                }
                case STORE_ITEM_POOL_CLEANER:           aMessageIndex = 2026;                           break;
                case STORE_ITEM_ROOF_CLEANER:           aMessageIndex = 2027;                           break;
                case STORE_ITEM_RAKE:                   aMessageIndex = 2028;                           break;
                case STORE_ITEM_AQUARIUM_GARDEN:        aMessageIndex = 2029;                           break;
                case STORE_ITEM_CHOCOLATE:                                                              break;
                case STORE_ITEM_TREE_OF_WISDOM:         aMessageIndex = 2030;                           break;
                case STORE_ITEM_TREE_FOOD:              aMessageIndex = 2031;                           break;
                case STORE_ITEM_FIRSTAID:               aMessageIndex = 2033;                           break;
                case STORE_ITEM_PVZ:                    aMessageIndex = 2034;                           break;
                default:                                TOD_ASSERT(false);                                   break;
                }
                if (mApp->mCrazyDaveMessageIndex != aMessageIndex)
                    SetBubbleText(aMessageIndex, 100, false);
                else mBubbleCountDown = 100;
                if (IsFullVersionOnly(aItemType) || (!IsItemSoldOut(aItemType) && !IsItemUnavailable(aItemType) && !IsComingSoon(aItemType)))
                    aShowFinger = true;
                break;
            }
        }
    }

    mApp->SetCursor(mBackButton->mIsOver || mPrevButton->mIsOver || mNextButton->mIsOver || aShowFinger ? CURSOR_HAND : CURSOR_POINTER);
}

// ==================== FormB：HEAD 数据表（逐字） ====================
namespace
{
// 商店气泡消息索引表：原 UpdateMouse 31 case 纯常量（生成器解析原 switch 生成，
// 逐槽对拍 0 差异）。-1 = 无提示（CHOCOLATE 及无 case 槽）；PACKET_UPGRADE 依
// 购买量三段+default 特例保留表外；default=TOD_ASSERT 由越界分支保留。
constexpr int kStoreBubbleMessage[(int)StoreItem::STORE_ITEM_PVZ + 1] = {
    2000,  // 0 STORE_ITEM_PLANT_GATLINGPEA
    2001,  // 1 STORE_ITEM_PLANT_TWINSUNFLOWER
    2002,  // 2 STORE_ITEM_PLANT_GLOOMSHROOM
    2003,  // 3 STORE_ITEM_PLANT_CATTAIL
    2004,  // 4 STORE_ITEM_PLANT_WINTERMELON
    2005,  // 5 STORE_ITEM_PLANT_GOLD_MAGNET
    2006,  // 6 STORE_ITEM_PLANT_SPIKEROCK
    2007,  // 7 STORE_ITEM_PLANT_COBCANNON
    2008,  // 8 STORE_ITEM_PLANT_IMITATER
    2009,  // 9 STORE_ITEM_BONUS_LAWN_MOWER
    2010,  // 10 STORE_ITEM_POTTED_MARIGOLD_1
    2010,  // 11 STORE_ITEM_POTTED_MARIGOLD_2
    2010,  // 12 STORE_ITEM_POTTED_MARIGOLD_3
    2019,  // 13 STORE_ITEM_GOLD_WATERINGCAN
    2020,  // 14 STORE_ITEM_FERTILIZER
    2022,  // 15 STORE_ITEM_BUG_SPRAY
    2021,  // 16 STORE_ITEM_PHONOGRAPH
    2023,  // 17 STORE_ITEM_GARDENING_GLOVE
    2032,  // 18 STORE_ITEM_MUSHROOM_GARDEN
    2024,  // 19 STORE_ITEM_WHEEL_BARROW
    2025,  // 20 STORE_ITEM_STINKY_THE_SNAIL
    -1,  // 21 STORE_ITEM_PACKET_UPGRADE  // 无提示（原 case 空/无 case）
    2026,  // 22 STORE_ITEM_POOL_CLEANER
    2027,  // 23 STORE_ITEM_ROOF_CLEANER
    2028,  // 24 STORE_ITEM_RAKE
    2029,  // 25 STORE_ITEM_AQUARIUM_GARDEN
    2030,  // 26 STORE_ITEM_CHOCOLATE
    2030,  // 27 STORE_ITEM_TREE_OF_WISDOM
    2031,  // 28 STORE_ITEM_TREE_FOOD
    2033,  // 29 STORE_ITEM_FIRSTAID
    2034,  // 30 STORE_ITEM_PVZ
};
static_assert(sizeof(kStoreBubbleMessage) / sizeof(kStoreBubbleMessage[0]) ==
    (int)StoreItem::STORE_ITEM_PVZ + 1, "槽位须与 StoreItem 枚举同步");
}  // namespace

//0x48BAD0
__declspec(noinline) void StoreScreen::UpdateMouse_B()
{
    mMouseOverItem = STORE_ITEM_INVALID;
    if (!CanInteractWithButtons()) return;
    int aMouseX = mApp->mWidgetManager->mLastMouseX - mX, aMouseY = mApp->mWidgetManager->mLastMouseY - mY;
    bool aShowFinger = false;
    for (int aItemPos = 0; aItemPos < MAX_PAGE_SPOTS; aItemPos++)
    {
        StoreItem aItemType = GetStoreItemType(aItemPos);
        if (aItemType != STORE_ITEM_INVALID && !IsItemUnavailable(aItemType))
        {
            int aItemX, aItemY;
            GetStorePosition(aItemPos, aItemX, aItemY);
            if (Rect(aItemX, aItemY, 50, 87).Contains(aMouseX, aMouseY))
            {
                mMouseOverItem = aItemType;
                int aMessageIndex = -1;
                // B 形态 -> 数据表（见上 kStoreBubbleMessage）；PACKET_UPGRADE 依
                // 购买量特例与 default 断言保留表外。
                if (aItemType == StoreItem::STORE_ITEM_PACKET_UPGRADE)
                {
        // 1073 004966D0 uses three exact cases and a default.
        // Avoid overflow in count+2011 and preserve that default.
        const int aCount = mApp->mPlayerInfo->mPurchases[STORE_ITEM_PACKET_UPGRADE];
        aMessageIndex = aCount == 0 ? 2011 : aCount == 1 ? 2012 : aCount == 2 ? 2013 : 2014;
        break;
                }
                else if (static_cast<unsigned>(aItemType) < static_cast<unsigned>((int)StoreItem::STORE_ITEM_PVZ + 1))
                {
                    aMessageIndex = kStoreBubbleMessage[aItemType];
                }
                else
                {
                    TOD_ASSERT(false);
                }

                if (mApp->mCrazyDaveMessageIndex != aMessageIndex)
                    SetBubbleText(aMessageIndex, 100, false);
                else mBubbleCountDown = 100;
                if (IsFullVersionOnly(aItemType) || (!IsItemSoldOut(aItemType) && !IsItemUnavailable(aItemType) && !IsComingSoon(aItemType)))
                    aShowFinger = true;
                break;
            }
        }
    }

    mApp->SetCursor(mBackButton->mIsOver || mPrevButton->mIsOver || mNextButton->mIsOver || aShowFinger ? CURSOR_HAND : CURSOR_POINTER);
}

// ============================ main ============================
static StoreScreen g_store;
static LawnApp g_app;
static PlayerInfo g_pi;
static WidgetManager g_wm;
static WidgetButton g_back, g_prev, g_next;

int main()
{
    g_store.mApp = &g_app;
    g_app.mPlayerInfo = &g_pi;
    g_app.mWidgetManager = &g_wm;
    g_store.mBackButton = &g_back;
    g_store.mPrevButton = &g_prev;
    g_store.mNextButton = &g_next;
    for (int i = 0; i < 128; i++) g_pi.mPurchases[i] = i % 4;

    // ---- 分歧定位诊断 ----
    {
        for (uint32_t i = 0; i < 64; i++)
        {
            int aPos = (int)(g_inputs[i].a % 26); if (aPos >= 21) aPos += 1;
            g_wm.mLastMouseX = 30 + (aPos % 6) * 90 + (int)(g_inputs[i].b % 50);
            g_wm.mLastMouseY = 100 + (aPos / 6) * 100 + (int)(g_inputs[i].c % 87);
            uint64_t sA=0,sB=0;
            g_sink=0; ZBRngReset();
            g_store.mMouseOverItem = STORE_ITEM_INVALID; g_store.mBubbleCountDown=0;
            g_store.UpdateMouse_A(); sA=g_sink;
            g_sink=0; ZBRngReset();
            g_store.mMouseOverItem = STORE_ITEM_INVALID; g_store.mBubbleCountDown=0;
            g_store.UpdateMouse_B(); sB=g_sink;
            if (sA!=sB || (uint32_t)g_store.mMouseOverItem!=aPos)
                printf("diverge i=%%u aPos=%%d item=%%d sA=%%llx sB=%%llx
", (unsigned)i, aPos, (int)g_store.mMouseOverItem, (unsigned long long)sA, (unsigned long long)sB);
        }
    }
    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                // 鼠标落在 aPos 号商品格内（27 格互不重叠：x=30+(p%6)*90 宽 50；y=100+(p/6)*100 高 87）
                int aPos = (int)(g_inputs[i].a % 26); if (aPos >= 21) aPos += 1;  // 排除 21=PACKET_UPGRADE：HEAD 该支 break 直出 for 跳过 SetBubbleText（与原 switch 语义分歧，另报）
                g_wm.mLastMouseX = 30 + (aPos % 6) * 90 + (int)(g_inputs[i].b % 50);
                g_wm.mLastMouseY = 100 + (aPos / 6) * 100 + (int)(g_inputs[i].c % 87);
                g_store.mMouseOverItem = STORE_ITEM_INVALID;
                g_store.mBubbleCountDown = 0;
                g_store.UpdateMouse_A();
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_store.mMouseOverItem * 7u + (uint32_t)g_store.mBubbleCountDown);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                int aPos = (int)(g_inputs[i].a % 26); if (aPos >= 21) aPos += 1;  // 排除 21=PACKET_UPGRADE：HEAD 该支 break 直出 for 跳过 SetBubbleText（与原 switch 语义分歧，另报）
                g_wm.mLastMouseX = 30 + (aPos % 6) * 90 + (int)(g_inputs[i].b % 50);
                g_wm.mLastMouseY = 100 + (aPos / 6) * 100 + (int)(g_inputs[i].c % 87);
                g_store.mMouseOverItem = STORE_ITEM_INVALID;
                g_store.mBubbleCountDown = 0;
                g_store.UpdateMouse_B();
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_store.mMouseOverItem * 7u + (uint32_t)g_store.mBubbleCountDown);
            }
        };
        rc |= R3BenchMain("t17_StoreScreen_UpdateMouse_kStoreBubbleMessage", reset, pa, pb);
    }
    return rc;
}
