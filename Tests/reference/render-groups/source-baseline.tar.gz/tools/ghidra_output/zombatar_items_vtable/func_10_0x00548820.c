
void __thiscall FUN_00548820(int param_1,int *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined1 local_44 [4];
  undefined4 local_40;
  undefined1 local_3c [8];
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined1 local_24 [4];
  undefined4 local_20;
  undefined1 local_1c [8];
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  uVar5 = *(undefined4 *)(param_1 + 0x18);
  iVar4 = param_1;
  FUN_00420ae0();
  local_10 = uVar5;
  if (param_1 == -4) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  puVar6 = &param_2;
  uVar5 = local_10;
  puVar3 = (undefined4 *)FUN_005b75d0(local_1c);
  FUN_0055a680(&local_c,*puVar3,puVar3[1],local_14,uVar5,puVar6);
  uVar5 = *(undefined4 *)(iVar4 + 0x18);
  iVar7 = iVar4;
  FUN_00420ae0();
  local_20 = uVar5;
  if (iVar4 == -4) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  cVar2 = FUN_006143c0(local_24);
  if (cVar2 == '\0') {
    cVar2 = FUN_006143c0(iVar7 + 0x2c);
    if (cVar2 != '\0') {
      uVar5 = *(undefined4 *)(iVar7 + 0x2c);
      uVar1 = *(undefined4 *)(iVar7 + 0x30);
      FUN_00614350();
      *(undefined1 *)(iVar7 + 0x28) = 1;
      local_2c = uVar5;
      local_28 = uVar1;
    }
    local_34 = local_c;
    local_30 = local_8;
    FUN_00556e50(local_3c,local_c,local_8);
    iVar4 = iVar7 + 4;
    uVar5 = *(undefined4 *)(iVar7 + 0x18);
    FUN_00420ae0(iVar7,iVar4,uVar5);
    local_40 = uVar5;
    if (iVar4 == 0) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    FUN_005484e0(local_44,param_2);
    (**(code **)(*param_2 + 0x78))();
  }
  return;
}

