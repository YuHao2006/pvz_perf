// bench_t03 — kShieldDamageImages 4x2 -> Zombie::TakeShieldDamage（事件）
#include "zb_common.h"
#define TOD_ASSERT(x) ((void)0)

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) int Zombie::TakeShieldDamage_A(int theDamage, unsigned int theDamageFlags)
{
    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
    {
        mShieldJustGotShotCounter = 25;
        if (mJustGotShotCounter < 0)
        {
            mJustGotShotCounter = 0;
        }
    }

    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH) && !TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_HITS_SHIELD_AND_BODY))
    {
        mShieldRecoilCounter = 12;
        if (mShieldType == ShieldType::SHIELDTYPE_DOOR || mShieldType == ShieldType::SHIELDTYPE_LADDER)
        {
            mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
        }
    }

    int aDamageIndexBeforeDamage = GetShieldDamageIndex();
    int aDamageActual = std::min(mShieldHealth, theDamage);
    int aDamageRemaining = theDamage - aDamageActual;
    mShieldHealth -= aDamageActual;
    if (mShieldHealth == 0)
    {
        DropShield(theDamageFlags);
        return aDamageRemaining;
    }

    int aDamageIndexAfterDamage = GetShieldDamageIndex();
    if (aDamageIndexAfterDamage != aDamageIndexBeforeDamage)
    {
        Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
        if (mShieldType == ShieldType::SHIELDTYPE_DOOR && aDamageIndexAfterDamage == 1)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_screendoor, IMAGE_REANIM_ZOMBIE_SCREENDOOR2);
        }
        else if (mShieldType == ShieldType::SHIELDTYPE_DOOR && aDamageIndexAfterDamage == 2)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_screendoor, IMAGE_REANIM_ZOMBIE_SCREENDOOR3);
        }
        else if (mShieldType == ShieldType::SHIELDTYPE_NEWSPAPER && aDamageIndexAfterDamage == 1)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_paper_paper, IMAGE_REANIM_ZOMBIE_PAPER_PAPER2);
        }
        else if (mShieldType == ShieldType::SHIELDTYPE_NEWSPAPER && aDamageIndexAfterDamage == 2)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_paper_paper, IMAGE_REANIM_ZOMBIE_PAPER_PAPER3);
        }
        else if (mShieldType == ShieldType::SHIELDTYPE_LADDER && aDamageIndexAfterDamage == 1)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_ladder_1, IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1);
        }
        else if (mShieldType == ShieldType::SHIELDTYPE_LADDER && aDamageIndexAfterDamage == 2)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_ladder_1, IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2);
        }
    }

    return aDamageRemaining;
}

// ==================== FormB：HEAD 逐字（函数内 constexpr struct 表——HEAD 即无 static，照抄） ====================
__declspec(noinline) int Zombie::TakeShieldDamage_B(int theDamage, unsigned int theDamageFlags)
{
    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
    {
        mShieldJustGotShotCounter = 25;
        if (mJustGotShotCounter < 0)
        {
            mJustGotShotCounter = 0;
        }
    }

    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH) && !TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_HITS_SHIELD_AND_BODY))
    {
        mShieldRecoilCounter = 12;
        if (mShieldType == ShieldType::SHIELDTYPE_DOOR || mShieldType == ShieldType::SHIELDTYPE_LADDER)
        {
            mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
        }
    }

    int aDamageIndexBeforeDamage = GetShieldDamageIndex();
    int aDamageActual = std::min(mShieldHealth, theDamage);
    int aDamageRemaining = theDamage - aDamageActual;
    mShieldHealth -= aDamageActual;
    if (mShieldHealth == 0)
    {
        DropShield(theDamageFlags);
        return aDamageRemaining;
    }

    int aDamageIndexAfterDamage = GetShieldDamageIndex();
    if (aDamageIndexAfterDamage != aDamageIndexBeforeDamage)
    {
        Reanimation* aBodyReanim = mApp->ReanimationTryToGet(mBodyReanimID);
        // B 形态 -> 常量二维表 kShieldDamageImages（原 6 支链合并）：行序 =
        // ShieldType 枚举序 0..3（count_last=SHIELDTYPE_LADDER 锚定，无 NUM
        // 哨兵），列序 = 损伤档 1..2；mImage=nullptr = 无 case 槽（default 无
        // 操作）。六支原均带 TOD_ASSERT(aBodyReanim)，统一保留一处。
        constexpr struct
        {
            ReanimTrackId mTrack;
            Image* const* mImage;  // nullptr = 无 case 槽
        } kShieldDamageImages[(int)ShieldType::SHIELDTYPE_LADDER + 1][2] = {
            /* [0] SHIELDTYPE_NONE      */ { { ReanimTrackId::None, nullptr }, { ReanimTrackId::None, nullptr } },
            /* [1] SHIELDTYPE_DOOR  dmg1 */ { { ReanimTrackId::anim_screendoor, &IMAGE_REANIM_ZOMBIE_SCREENDOOR2 },
                                              /*                     dmg2 */   { ReanimTrackId::anim_screendoor, &IMAGE_REANIM_ZOMBIE_SCREENDOOR3 } },
            /* [2] SHIELDTYPE_NEWSPAPER  */ { { ReanimTrackId::Zombie_paper_paper, &IMAGE_REANIM_ZOMBIE_PAPER_PAPER2 },
                                              /*                     dmg2 */   { ReanimTrackId::Zombie_paper_paper, &IMAGE_REANIM_ZOMBIE_PAPER_PAPER3 } },
            /* [3] SHIELDTYPE_LADDER     */ { { ReanimTrackId::Zombie_ladder_1, &IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1 },
                                              /*                     dmg2 */   { ReanimTrackId::Zombie_ladder_1, &IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2 } },
        };
        static_assert(sizeof(kShieldDamageImages) / sizeof(kShieldDamageImages[0]) ==
            (int)ShieldType::SHIELDTYPE_LADDER + 1, "kShieldDamageImages 槽位须与 ShieldType 枚举尾同步");

        const unsigned aShieldIndex = static_cast<unsigned>(mShieldType);
        const unsigned aDamageSlot = static_cast<unsigned>(aDamageIndexAfterDamage) - 1;
        if (aShieldIndex < sizeof(kShieldDamageImages) / sizeof(kShieldDamageImages[0]) &&
            aDamageSlot < 2 && kShieldDamageImages[aShieldIndex][aDamageSlot].mImage != nullptr)
        {
            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetImageOverride(kShieldDamageImages[aShieldIndex][aDamageSlot].mTrack,
                *kShieldDamageImages[aShieldIndex][aDamageSlot].mImage);
        }
    }

    return aDamageRemaining;
}

static Zombie g_z;
static void ResetShield(const ZBInput& in, int& dmg, unsigned& flags)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    g_z.mShieldType = (ShieldType)(in.a % 4);
    g_z.mShieldMaxHealth = 180;
    g_z.mShieldHealth = (int)(in.b % 181);
    g_z.mJustGotShotCounter = (int)(in.c % 7) - 2;
    g_z.mShieldJustGotShotCounter = 0;
    g_z.mShieldRecoilCounter = 0;
    g_z.mBodyReanimID = (in.b % 7 == 0) ? (ReanimationID)0 : (ReanimationID)(1 + in.b % 2);
    dmg = (int)(in.c % 30) + 1;
    flags = (in.d & ((1u << 0) | (1u << 1) | (1u << 3)));
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            int dmg; unsigned fl;
            ResetShield(g_zb_inputs[i], dmg, fl);
            int r = g_z.TakeShieldDamage_A(dmg, fl);
            g_z.HashFold(ck);
            ck = ZBMixU64(ck, (uint64_t)(uint32_t)r);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            int dmg; unsigned fl;
            ResetShield(g_zb_inputs[i], dmg, fl);
            int r = g_z.TakeShieldDamage_B(dmg, fl);
            g_z.HashFold(ck);
            ck = ZBMixU64(ck, (uint64_t)(uint32_t)r);
        }
    };
    return ZBenchMain("t03_TakeShieldDamage", passA, passB);
}
