#include "DDImage.h"
#include "DDInterface.h"
#include "D3DInterface.h"
#include "Graphics.h"
#include "TriVertex.h"
#include <cstdio>

using namespace Sexy;

namespace
{
void FailNonScreen(const char* theOp)
{
	// No software fallback: drawing to a DDImage that is not the D3D11 screen
	// image is unsupported and must not silently rasterize on the CPU.
	FILE* aLog = fopen(GetLogFilePath("d3d11.log").c_str(), "a");
	if (aLog != nullptr)
	{
		fprintf(aLog, "DDImage %s on non-screen target (unsupported)\n", theOp);
		fclose(aLog);
	}
}
}

DDImage::DDImage()
	: mDDInterface(nullptr)
{
}

DDImage::DDImage(DDInterface* theDDInterface)
	: mDDInterface(theDDInterface)
{
}

DDImage::~DDImage()
{
}

bool DDImage::Check3D(Image *theImage)
{
	DDImage *anImage = dynamic_cast<DDImage*>(theImage);
	return anImage != nullptr && Check3D(anImage);
}

bool DDImage::Check3D(DDImage *theImage)
{
	return theImage->mDDInterface != nullptr &&
		theImage->mDDInterface->mIs3D &&
		theImage == theImage->mDDInterface->mScreenImage;
}

bool DDImage::LockSurface()
{
	// No DirectDraw surface; the 3D screen image never needs locking.
	return false;
}

bool DDImage::UnlockSurface()
{
	return true;
}

ulong* DDImage::GetBits()
{
	return MemoryImage::GetBits();
}

void DDImage::FillRect(const Rect& theRect, const Color& theColor, int theDrawMode)
{
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->FillRect(theRect, theColor, theDrawMode);
		return;
	}
	FailNonScreen("FillRect");
}

void DDImage::DrawLine(double theStartX, double theStartY, double theEndX, double theEndY, const Color& theColor, int theDrawMode)
{
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->DrawLine(theStartX, theStartY, theEndX, theEndY, theColor, theDrawMode);
		return;
	}
	FailNonScreen("DrawLine");
}

void DDImage::DrawLineAA(double theStartX, double theStartY, double theEndX, double theEndY, const Color& theColor, int theDrawMode)
{
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->DrawLine(theStartX, theStartY, theEndX, theEndY, theColor, theDrawMode);
		return;
	}
	FailNonScreen("DrawLineAA");
}

bool DDImage::PolyFill3D(const Point theVertices[], int theNumVertices, const Rect *theClipRect, const Color &theColor, int theDrawMode, int tx, int ty)
{
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->FillPoly(theVertices, theNumVertices, theClipRect, theColor, theDrawMode, tx, ty);
		return true;
	}
	FailNonScreen("PolyFill3D");
	return false;
}

void DDImage::Blt(Image* theImage, int theX, int theY, const Rect& theSrcRect, const Color& theColor, int theDrawMode)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->Blt(theImage, (float)theX, (float)theY, theSrcRect, theColor, theDrawMode);
		return;
	}
	FailNonScreen("Blt");
}

void DDImage::BltF(Image* theImage, float theX, float theY, const Rect& theSrcRect, const Rect &theClipRect, const Color& theColor, int theDrawMode)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		FRect aClipRect(theClipRect.mX, theClipRect.mY, theClipRect.mWidth, theClipRect.mHeight);
		FRect aDestRect(theX, theY, (float)theSrcRect.mWidth, (float)theSrcRect.mHeight);
		FRect anIntersect = aDestRect.Intersection(aClipRect);
		if (anIntersect.mWidth != aDestRect.mWidth || anIntersect.mHeight != aDestRect.mHeight)
		{
			if (anIntersect.mWidth != 0 && anIntersect.mHeight != 0)
				mDDInterface->mD3DInterface->BltClipF(theImage, theX, theY, theSrcRect, &theClipRect, theColor, theDrawMode);
		}
		else
			mDDInterface->mD3DInterface->Blt(theImage, theX, theY, theSrcRect, theColor, theDrawMode, true);
		return;
	}
	FailNonScreen("BltF");
}

void DDImage::BltRotated(Image* theImage, float theX, float theY, const Rect &theSrcRect, const Rect& theClipRect, const Color& theColor, int theDrawMode, double theRot, float theRotCenterX, float theRotCenterY)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->BltRotated(theImage, theX, theY, &theClipRect, theColor, theDrawMode, theRot, theRotCenterX, theRotCenterY, theSrcRect);
		return;
	}
	FailNonScreen("BltRotated");
}

void DDImage::StretchBlt(Image* theImage, const Rect& theDestRect, const Rect& theSrcRect, const Rect& theClipRect, const Color& theColor, int theDrawMode, bool fastStretch)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->StretchBlt(theImage, theDestRect, theSrcRect, &theClipRect, theColor, theDrawMode, fastStretch);
		return;
	}
	FailNonScreen("StretchBlt");
}

void DDImage::BltMatrix(Image* theImage, float x, float y, const SexyMatrix3 &theMatrix, const Rect& theClipRect, const Color& theColor, int theDrawMode, const Rect &theSrcRect, bool blend)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->BltTransformed(theImage, &theClipRect, theColor, theDrawMode, theSrcRect, theMatrix, blend, x, y, true);
		return;
	}
	FailNonScreen("BltMatrix");
}

void DDImage::BltTrianglesTex(Image *theTexture, const TriVertex theVertices[][3], int theNumTriangles, const Rect& theClipRect, const Color &theColor, int theDrawMode, float tx, float ty, bool blend)
{
	theTexture->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->DrawTrianglesTex(theVertices, theNumTriangles, theColor, theDrawMode, theTexture, tx, ty, blend);
		return;
	}
	FailNonScreen("BltTrianglesTex");
}

void DDImage::BltMirror(Image* theImage, int theX, int theY, const Rect& theSrcRect, const Color& theColor, int theDrawMode)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->BltMirror(theImage, (float)theX, (float)theY, theSrcRect, theColor, theDrawMode);
		return;
	}
	FailNonScreen("BltMirror");
}

void DDImage::StretchBltMirror(Image* theImage, const Rect& theDestRectOrig, const Rect& theSrcRect, const Rect& theClipRect, const Color& theColor, int theDrawMode, bool fastStretch)
{
	theImage->mDrawn = true;
	if (Check3D(this))
	{
		mDDInterface->mD3DInterface->StretchBlt(theImage, theDestRectOrig, theSrcRect, &theClipRect, theColor, theDrawMode, fastStretch, true);
		return;
	}
	FailNonScreen("StretchBltMirror");
}

void DDImage::FillScanLinesWithCoverage(Span* theSpans, int theSpanCount, const Color& theColor, int theDrawMode, const BYTE* theCoverage, int theCoverX, int theCoverY, int theCoverWidth, int theCoverHeight)
{
	if (Check3D(this))
	{
		MemoryImage::FillScanLinesWithCoverage(theSpans, theSpanCount, theColor, theDrawMode, theCoverage, theCoverX, theCoverY, theCoverWidth, theCoverHeight);
		return;
	}
	FailNonScreen("FillScanLinesWithCoverage");
}
