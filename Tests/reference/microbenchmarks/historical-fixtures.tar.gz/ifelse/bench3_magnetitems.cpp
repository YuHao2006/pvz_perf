// bench3_magnetitems.cpp - 目标3: Plant::DrawMagnetItems 19 支 -> kMagnetItems 22 槽（image+scale+cel）
// 每次调用消费 5 个输入（MAX_MAGNET_ITEMS=5），kN 输入 => kN/5 次调用、kN 个物品分派
#include "bench_common.h"

#define MAX_MAGNET_ITEMS 5

enum SeedType { SEED_MAGNETSHROOM_DUMMY = 0 };
enum MagnetItemType
{
    MAGNET_ITEM_NONE,
    MAGNET_ITEM_PAIL_1,
    MAGNET_ITEM_PAIL_2,
    MAGNET_ITEM_PAIL_3,
    MAGNET_ITEM_FOOTBALL_HELMET_1,
    MAGNET_ITEM_FOOTBALL_HELMET_2,
    MAGNET_ITEM_FOOTBALL_HELMET_3,
    MAGNET_ITEM_DOOR_1,
    MAGNET_ITEM_DOOR_2,
    MAGNET_ITEM_DOOR_3,
    MAGNET_ITEM_POGO_1,
    MAGNET_ITEM_POGO_2,
    MAGNET_ITEM_POGO_3,
    MAGNET_ITEM_JACK_IN_THE_BOX,
    MAGNET_ITEM_LADDER_1,
    MAGNET_ITEM_LADDER_2,
    MAGNET_ITEM_LADDER_3,
    MAGNET_ITEM_LADDER_PLACED,
    MAGNET_ITEM_SILVER_COIN,
    MAGNET_ITEM_GOLD_COIN,
    MAGNET_ITEM_DIAMOND,
    MAGNET_ITEM_PICK_AXE
};

struct Image { int id; };
#define DEF_IMG(name, val) static Image g_##name{ val }; static Image* const name = &g_##name;
DEF_IMG(IMAGE_REANIM_ZOMBIE_BUCKET1, 201)
DEF_IMG(IMAGE_REANIM_ZOMBIE_BUCKET2, 202)
DEF_IMG(IMAGE_REANIM_ZOMBIE_BUCKET3, 203)
DEF_IMG(IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET, 204)
DEF_IMG(IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2, 205)
DEF_IMG(IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3, 206)
DEF_IMG(IMAGE_REANIM_ZOMBIE_SCREENDOOR1, 207)
DEF_IMG(IMAGE_REANIM_ZOMBIE_SCREENDOOR2, 208)
DEF_IMG(IMAGE_REANIM_ZOMBIE_SCREENDOOR3, 209)
DEF_IMG(IMAGE_ZOMBIEPOGO, 210)
DEF_IMG(IMAGE_REANIM_ZOMBIE_LADDER_1, 211)
DEF_IMG(IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1, 212)
DEF_IMG(IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2, 213)
DEF_IMG(IMAGE_REANIM_ZOMBIE_LADDER_5, 214)
DEF_IMG(IMAGE_REANIM_ZOMBIE_JACKBOX_BOX, 215)
DEF_IMG(IMAGE_REANIM_ZOMBIE_DIGGER_PICKAXE, 216)
DEF_IMG(IMAGE_REANIM_COIN_SILVER_DOLLAR, 217)
DEF_IMG(IMAGE_REANIM_COIN_GOLD_DOLLAR, 218)
DEF_IMG(IMAGE_REANIM_DIAMOND, 219)
#undef DEF_IMG

struct Graphics { int dummy; };  // 占位（仅作指针传递，绘制走同签名空桩）

// 同签名空桩：绘制调用 -> 编号入 checksum
static void DrawImageCelStub(Image* theImage, float x, float y, int theCelCol, int theCelRow, uint64_t tag)
{
    Mix(tag); MixI(theImage ? theImage->id : -1); MixF(x); MixF(y); MixI(theCelCol); MixI(theCelRow);
}
static void TodDrawImageCelScaledFStub(Graphics* g, Image* theImage, float x, float y, int theCelCol, int theCelRow, float sx, float sy, uint64_t tag)
{
    (void)g;
    Mix(tag); MixI(theImage ? theImage->id : -1); MixF(x); MixF(y); MixI(theCelCol); MixI(theCelRow); MixF(sx); MixF(sy);
}

struct MagnetItem
{
    float mPosX, mPosY;
    MagnetItemType mItemType;
};
struct Plant  // 最小桩：仅本函数用到的字段
{
    MagnetItem mMagnetItems[MAX_MAGNET_ITEMS];
    int mX, mY;
};

// PlantDrawHeightOffset 前置调用桩（两形态共同，确定性）
static float PlantDrawHeightOffsetStub(uint32_t inp) { return BitsToF(inp, 24); }

static int gCursor = 0;
static Plant gPlant;

// ---------------- FormA：原 19 支链（逐字） ----------------
__declspec(noinline) void OneA()
{
    // 共同准备（对称计时）：5 槽类型/坐标从输入流取
    uint32_t inp0 = gInput[(gCursor + 0) % kN];
    uint32_t inp1 = gInput[(gCursor + 1) % kN];
    uint32_t inp2 = gInput[(gCursor + 2) % kN];
    uint32_t inp3 = gInput[(gCursor + 3) % kN];
    uint32_t inp4 = gInput[(gCursor + 4) % kN];
    gCursor = (gCursor + MAX_MAGNET_ITEMS) % kN;
    uint32_t inps[MAX_MAGNET_ITEMS] = { inp0, inp1, inp2, inp3, inp4 };
    for (int j = 0; j < MAX_MAGNET_ITEMS; j++)
    {
        gPlant.mMagnetItems[j].mItemType = (MagnetItemType)(inps[j] % 22u);
        gPlant.mMagnetItems[j].mPosX = BitsToF(inps[j], 8);
        gPlant.mMagnetItems[j].mPosY = BitsToF(inps[j], 16);
    }
    gPlant.mX = 40; gPlant.mY = 50;

    Graphics* g = nullptr;  // 仅作占位传递
    float aOffsetX = 0.0f;
    float aOffsetY = PlantDrawHeightOffsetStub(inp0);

    for (int i = 0; i < MAX_MAGNET_ITEMS; i++)
    {
        MagnetItem* aMagnetItem = &gPlant.mMagnetItems[i];
        if (aMagnetItem->mItemType != MagnetItemType::MAGNET_ITEM_NONE)
        {
            int aCelRow = 0, aCelCol = 0;
            Image* aImage = nullptr;
            float aScale = 0.8f;

            if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_PAIL_1)
            {
                aImage = IMAGE_REANIM_ZOMBIE_BUCKET1;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_PAIL_2)
            {
                aImage = IMAGE_REANIM_ZOMBIE_BUCKET2;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_PAIL_3)
            {
                aImage = IMAGE_REANIM_ZOMBIE_BUCKET3;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_FOOTBALL_HELMET_1)
            {
                aImage = IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_FOOTBALL_HELMET_2)
            {
                aImage = IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_FOOTBALL_HELMET_3)
            {
                aImage = IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_DOOR_1)
            {
                aImage = IMAGE_REANIM_ZOMBIE_SCREENDOOR1;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_DOOR_2)
            {
                aImage = IMAGE_REANIM_ZOMBIE_SCREENDOOR2;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_DOOR_3)
            {
                aImage = IMAGE_REANIM_ZOMBIE_SCREENDOOR3;
            }
            else if (aMagnetItem->mItemType >= MagnetItemType::MAGNET_ITEM_POGO_1 && aMagnetItem->mItemType <= MagnetItemType::MAGNET_ITEM_POGO_3)
            {
                aCelCol = (int)aMagnetItem->mItemType - (int)MagnetItemType::MAGNET_ITEM_POGO_1;
                aImage = IMAGE_ZOMBIEPOGO;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_LADDER_1)
            {
                aImage = IMAGE_REANIM_ZOMBIE_LADDER_1;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_LADDER_2)
            {
                aImage = IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_LADDER_3)
            {
                aImage = IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_LADDER_PLACED)
            {
                aImage = IMAGE_REANIM_ZOMBIE_LADDER_5;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_JACK_IN_THE_BOX)
            {
                aImage = IMAGE_REANIM_ZOMBIE_JACKBOX_BOX;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_PICK_AXE)
            {
                aImage = IMAGE_REANIM_ZOMBIE_DIGGER_PICKAXE;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_SILVER_COIN)
            {
                aScale = 1.0f;
                aImage = IMAGE_REANIM_COIN_SILVER_DOLLAR;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_GOLD_COIN)
            {
                aScale = 1.0f;
                aImage = IMAGE_REANIM_COIN_GOLD_DOLLAR;
            }
            else if (aMagnetItem->mItemType == MagnetItemType::MAGNET_ITEM_DIAMOND)
            {
                aScale = 1.0f;
                aImage = IMAGE_REANIM_DIAMOND;
            }
            else
            {
                TOD_ASSERT(false);
            }

            if (aScale == 1.0f)
            {
                DrawImageCelStub(aImage, aMagnetItem->mPosX - gPlant.mX + aOffsetX, aMagnetItem->mPosY - gPlant.mY + aOffsetY, aCelCol, aCelRow, 0xA001u);
            }
            else
            {
                TodDrawImageCelScaledFStub(g, aImage, aMagnetItem->mPosX - gPlant.mX + aOffsetX, aMagnetItem->mPosY - gPlant.mY + aOffsetY, aCelCol, aCelRow, aScale, aScale, 0xA002u);
            }
        }
    }
}

// ---------------- FormB：当前表形态（逐字） ----------------
__declspec(noinline) void OneB()
{
    uint32_t inp0 = gInput[(gCursor + 0) % kN];
    uint32_t inp1 = gInput[(gCursor + 1) % kN];
    uint32_t inp2 = gInput[(gCursor + 2) % kN];
    uint32_t inp3 = gInput[(gCursor + 3) % kN];
    uint32_t inp4 = gInput[(gCursor + 4) % kN];
    gCursor = (gCursor + MAX_MAGNET_ITEMS) % kN;
    uint32_t inps[MAX_MAGNET_ITEMS] = { inp0, inp1, inp2, inp3, inp4 };
    for (int j = 0; j < MAX_MAGNET_ITEMS; j++)
    {
        gPlant.mMagnetItems[j].mItemType = (MagnetItemType)(inps[j] % 22u);
        gPlant.mMagnetItems[j].mPosX = BitsToF(inps[j], 8);
        gPlant.mMagnetItems[j].mPosY = BitsToF(inps[j], 16);
    }
    gPlant.mX = 40; gPlant.mY = 50;

    Graphics* g = nullptr;
    float aOffsetX = 0.0f;
    float aOffsetY = PlantDrawHeightOffsetStub(inp0);

    for (int i = 0; i < MAX_MAGNET_ITEMS; i++)
    {
        MagnetItem* aMagnetItem = &gPlant.mMagnetItems[i];
        if (aMagnetItem->mItemType != MagnetItemType::MAGNET_ITEM_NONE)
        {
            constexpr struct { Image* const* mImage; uint8_t mCelCol; float mScale; } kMagnetItems[] = {
                { nullptr,                               0, 0.8f },  // 0 MAGNET_ITEM_NONE
                { &IMAGE_REANIM_ZOMBIE_BUCKET1,          0, 0.8f },  // 1
                { &IMAGE_REANIM_ZOMBIE_BUCKET2,          0, 0.8f },  // 2
                { &IMAGE_REANIM_ZOMBIE_BUCKET3,          0, 0.8f },  // 3
                { &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET,  0, 0.8f },  // 4
                { &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2, 0, 0.8f },  // 5
                { &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3, 0, 0.8f },  // 6
                { &IMAGE_REANIM_ZOMBIE_SCREENDOOR1,      0, 0.8f },  // 7
                { &IMAGE_REANIM_ZOMBIE_SCREENDOOR2,      0, 0.8f },  // 8
                { &IMAGE_REANIM_ZOMBIE_SCREENDOOR3,      0, 0.8f },  // 9
                { &IMAGE_ZOMBIEPOGO,                     0, 0.8f },  // 10
                { &IMAGE_ZOMBIEPOGO,                     1, 0.8f },  // 11
                { &IMAGE_ZOMBIEPOGO,                     2, 0.8f },  // 12
                { &IMAGE_REANIM_ZOMBIE_JACKBOX_BOX,      0, 0.8f },  // 13
                { &IMAGE_REANIM_ZOMBIE_LADDER_1,         0, 0.8f },  // 14
                { &IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1, 0, 0.8f },  // 15
                { &IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2, 0, 0.8f },  // 16
                { &IMAGE_REANIM_ZOMBIE_LADDER_5,         0, 0.8f },  // 17
                { &IMAGE_REANIM_COIN_SILVER_DOLLAR,      0, 1.0f },  // 18
                { &IMAGE_REANIM_COIN_GOLD_DOLLAR,        0, 1.0f },  // 19
                { &IMAGE_REANIM_DIAMOND,                 0, 1.0f },  // 20
                { &IMAGE_REANIM_ZOMBIE_DIGGER_PICKAXE,   0, 0.8f },  // 21
            };
            static_assert(sizeof(kMagnetItems) / sizeof(kMagnetItems[0]) == (int)MagnetItemType::MAGNET_ITEM_PICK_AXE + 1,
                "kMagnetItems 槽位须与 MagnetItemType 枚举同步");

            int aCelRow = 0;
            Image* aImage = nullptr;
            float aScale = 0.8f;
            int aCelCol = 0;
            const unsigned aItemType = (unsigned)aMagnetItem->mItemType;
            if (aItemType < sizeof(kMagnetItems) / sizeof(kMagnetItems[0]) && kMagnetItems[aItemType].mImage != nullptr)
            {
                aImage = *kMagnetItems[aItemType].mImage;
                aCelCol = kMagnetItems[aItemType].mCelCol;
                aScale = kMagnetItems[aItemType].mScale;
            }
            else
            {
                TOD_ASSERT(false);  // 原 else 兜底
            }

            if (aScale == 1.0f)
            {
                DrawImageCelStub(aImage, aMagnetItem->mPosX - gPlant.mX + aOffsetX, aMagnetItem->mPosY - gPlant.mY + aOffsetY, aCelCol, aCelRow, 0xA001u);
            }
            else
            {
                TodDrawImageCelScaledFStub(g, aImage, aMagnetItem->mPosX - gPlant.mX + aOffsetX, aMagnetItem->mPosY - gPlant.mY + aOffsetY, aCelCol, aCelRow, aScale, aScale, 0xA002u);
            }
        }
    }
}

// ---------------- FormC：FormB 逐字 + static constexpr（诊断：免每次调用栈物化） ----------------
__declspec(noinline) void OneC()
{
    uint32_t inp0 = gInput[(gCursor + 0) % kN];
    uint32_t inp1 = gInput[(gCursor + 1) % kN];
    uint32_t inp2 = gInput[(gCursor + 2) % kN];
    uint32_t inp3 = gInput[(gCursor + 3) % kN];
    uint32_t inp4 = gInput[(gCursor + 4) % kN];
    gCursor = (gCursor + MAX_MAGNET_ITEMS) % kN;
    uint32_t inps[MAX_MAGNET_ITEMS] = { inp0, inp1, inp2, inp3, inp4 };
    for (int j = 0; j < MAX_MAGNET_ITEMS; j++)
    {
        gPlant.mMagnetItems[j].mItemType = (MagnetItemType)(inps[j] % 22u);
        gPlant.mMagnetItems[j].mPosX = BitsToF(inps[j], 8);
        gPlant.mMagnetItems[j].mPosY = BitsToF(inps[j], 16);
    }
    gPlant.mX = 40; gPlant.mY = 50;

    Graphics* g = nullptr;
    float aOffsetX = 0.0f;
    float aOffsetY = PlantDrawHeightOffsetStub(inp0);

    for (int i = 0; i < MAX_MAGNET_ITEMS; i++)
    {
        MagnetItem* aMagnetItem = &gPlant.mMagnetItems[i];
        if (aMagnetItem->mItemType != MagnetItemType::MAGNET_ITEM_NONE)
        {
            constexpr struct { Image* const* mImage; uint8_t mCelCol; float mScale; } kMagnetItems[] = {
                { nullptr,                               0, 0.8f },  // 0 MAGNET_ITEM_NONE
                { &IMAGE_REANIM_ZOMBIE_BUCKET1,          0, 0.8f },  // 1
                { &IMAGE_REANIM_ZOMBIE_BUCKET2,          0, 0.8f },  // 2
                { &IMAGE_REANIM_ZOMBIE_BUCKET3,          0, 0.8f },  // 3
                { &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET,  0, 0.8f },  // 4
                { &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET2, 0, 0.8f },  // 5
                { &IMAGE_REANIM_ZOMBIE_FOOTBALL_HELMET3, 0, 0.8f },  // 6
                { &IMAGE_REANIM_ZOMBIE_SCREENDOOR1,      0, 0.8f },  // 7
                { &IMAGE_REANIM_ZOMBIE_SCREENDOOR2,      0, 0.8f },  // 8
                { &IMAGE_REANIM_ZOMBIE_SCREENDOOR3,      0, 0.8f },  // 9
                { &IMAGE_ZOMBIEPOGO,                     0, 0.8f },  // 10
                { &IMAGE_ZOMBIEPOGO,                     1, 0.8f },  // 11
                { &IMAGE_ZOMBIEPOGO,                     2, 0.8f },  // 12
                { &IMAGE_REANIM_ZOMBIE_JACKBOX_BOX,      0, 0.8f },  // 13
                { &IMAGE_REANIM_ZOMBIE_LADDER_1,         0, 0.8f },  // 14
                { &IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE1, 0, 0.8f },  // 15
                { &IMAGE_REANIM_ZOMBIE_LADDER_1_DAMAGE2, 0, 0.8f },  // 16
                { &IMAGE_REANIM_ZOMBIE_LADDER_5,         0, 0.8f },  // 17
                { &IMAGE_REANIM_COIN_SILVER_DOLLAR,      0, 1.0f },  // 18
                { &IMAGE_REANIM_COIN_GOLD_DOLLAR,        0, 1.0f },  // 19
                { &IMAGE_REANIM_DIAMOND,                 0, 1.0f },  // 20
                { &IMAGE_REANIM_ZOMBIE_DIGGER_PICKAXE,   0, 0.8f },  // 21
            };
            static_assert(sizeof(kMagnetItems) / sizeof(kMagnetItems[0]) == (int)MagnetItemType::MAGNET_ITEM_PICK_AXE + 1,
                "kMagnetItems 槽位须与 MagnetItemType 枚举同步");

            int aCelRow = 0;
            Image* aImage = nullptr;
            float aScale = 0.8f;
            int aCelCol = 0;
            const unsigned aItemType = (unsigned)aMagnetItem->mItemType;
            if (aItemType < sizeof(kMagnetItems) / sizeof(kMagnetItems[0]) && kMagnetItems[aItemType].mImage != nullptr)
            {
                aImage = *kMagnetItems[aItemType].mImage;
                aCelCol = kMagnetItems[aItemType].mCelCol;
                aScale = kMagnetItems[aItemType].mScale;
            }
            else
            {
                TOD_ASSERT(false);  // 原 else 兜底
            }

            if (aScale == 1.0f)
            {
                DrawImageCelStub(aImage, aMagnetItem->mPosX - gPlant.mX + aOffsetX, aMagnetItem->mPosY - gPlant.mY + aOffsetY, aCelCol, aCelRow, 0xA001u);
            }
            else
            {
                TodDrawImageCelScaledFStub(g, aImage, aMagnetItem->mPosX - gPlant.mX + aOffsetX, aMagnetItem->mPosY - gPlant.mY + aOffsetY, aCelCol, aCelRow, aScale, aScale, 0xA002u);
            }
        }
    }
}

static void RunA() { int save = gCursor; gCursor = 0; for (int i = 0; i < kN / MAX_MAGNET_ITEMS; i++) OneA(); gCursor = save; }
static void RunB() { int save = gCursor; gCursor = 0; for (int i = 0; i < kN / MAX_MAGNET_ITEMS; i++) OneB(); gCursor = save; }
static void RunC() { int save = gCursor; gCursor = 0; for (int i = 0; i < kN / MAX_MAGNET_ITEMS; i++) OneC(); gCursor = save; }

int main()
{
    GenInput();
    uint64_t ca = CheckOnly(RunA);
    uint64_t cb = CheckOnly(RunB);
    uint64_t cc = CheckOnly(RunC);
    double a = TimePerIterNs(RunA, kN);   // 每个输入元素（=每个物品槽）的 ns
    double b = TimePerIterNs(RunB, kN);
    double c = TimePerIterNs(RunC, kN);
    printf("bench3 DrawMagnetItems | before %.2f ns | after %.2f ns | diff %.1f%% | C(static) %.2f ns | checksum=%s (A=%016llX B=%016llX C=%016llX)\n",
        a, b, (a - b) / a * 100.0, c, ca == cb && cb == cc ? "OK" : "MISMATCH", (unsigned long long)ca, (unsigned long long)cb, (unsigned long long)cc);
    return (ca == cb && cb == cc) ? 0 : 1;
}
