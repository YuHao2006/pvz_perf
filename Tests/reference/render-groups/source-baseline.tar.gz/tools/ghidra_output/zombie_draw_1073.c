/* 0053d950 FUN_0053d950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0053d950(int *param_1,int param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  float fVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined1 local_59;
  float local_58;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  int local_3c;
  undefined4 local_30;
  int local_2c;
  
  uVar1 = param_1[0x46];
  if (*(int *)(*param_1 + 0x940) == 0) {
    return;
  }
  piVar2 = *(int **)(*(int *)(*param_1 + 0x940) + 8);
  if (uVar1 == 0) {
    return;
  }
  if ((uint)piVar2[2] <= (uVar1 & 0xffff)) {
    return;
  }
  iVar10 = (uVar1 & 0xffff) * 0xa0 + *piVar2;
  if (*(uint *)(iVar10 + 0x9c) != uVar1) {
    return;
  }
  if ((float)_DAT_006fdc70 < *(float *)(param_3 + 0x18)) {
    uVar5 = FUN_006ba960();
    uVar11 = 0x208;
    uVar6 = FUN_006ba960(0x208,uVar5);
    uVar7 = FUN_006ba960(uVar6);
    FUN_005993f0(uVar7,uVar6,uVar11,uVar5);
  }
  local_58 = 3.57331e-43;
  if (-1 < param_1[0x1d]) {
    iVar3 = (param_1[0x1d] * 0xff) / 10;
    if (iVar3 < 1) {
      local_58 = 0.0;
    }
    else {
      local_58 = 3.57331e-43;
      if (iVar3 < 0xff) {
        local_58 = (float)iVar3;
      }
    }
  }
  FUN_005615d0(0xff,0xff,0xff,local_58);
  local_30 = DAT_007a23f8;
  local_2c = DAT_007a23fc;
  local_59 = 0;
  if (param_1[10] == 2) {
    puVar8 = (undefined4 *)FUN_005615d0(0,0,0,local_58);
    local_48 = *puVar8;
    local_44 = puVar8[1];
    local_40 = puVar8[2];
    local_3c = puVar8[3];
    local_30 = DAT_007a23f8;
    local_2c = DAT_007a23fc;
    local_59 = 0;
    uVar6 = DAT_007a23f4;
    uVar5 = DAT_007a23f0;
  }
  else if (((param_1[9] == 0x19) && (param_1[10] != 1)) && (param_1[0x32] < param_1[0x33] / 10)) {
    uVar5 = FUN_0051bea0(0x9b,0xff,9);
    if ((param_1[0x2b] < 1) && (param_1[0x2d] < 1)) {
      puVar8 = (undefined4 *)FUN_005615d0(uVar5,uVar5,uVar5,local_58);
      local_48 = *puVar8;
      local_44 = puVar8[1];
      local_40 = puVar8[2];
      local_3c = puVar8[3];
    }
    else {
      uVar6 = FUN_0051bea0(0x41,0x4b,9);
      puVar8 = (undefined4 *)FUN_005615d0(uVar6,uVar6,uVar5,local_58);
      local_48 = *puVar8;
      local_44 = puVar8[1];
      local_40 = puVar8[2];
      local_3c = puVar8[3];
    }
    local_59 = 0;
    uVar6 = DAT_007a23f4;
    uVar5 = DAT_007a23f0;
    local_30 = DAT_007a23f8;
    local_2c = DAT_007a23fc;
  }
  else if ((char)param_1[0x2e] == '\0') {
    if ((param_1[0x2b] < 1) && (param_1[0x2d] < 1)) {
      uVar6 = DAT_007a23f4;
      uVar5 = DAT_007a23f0;
      if ((param_1[0x19] != 10) || (99 < param_1[0x32])) goto LAB_0053dcd1;
      uVar7 = 0x19;
      uVar6 = 0x96;
      uVar5 = 100;
    }
    else {
      uVar7 = 0xff;
      uVar6 = 0x4b;
      uVar5 = 0x4b;
    }
    puVar8 = (undefined4 *)FUN_005615d0(uVar5,uVar6,uVar7,local_58);
    local_48 = *puVar8;
    local_44 = puVar8[1];
    local_40 = puVar8[2];
    local_3c = puVar8[3];
    local_2c = puVar8[3];
    local_30 = puVar8[2];
    uVar6 = puVar8[1];
    uVar5 = *puVar8;
    local_59 = 1;
  }
  else {
    local_48 = DAT_007a2310;
    local_44 = DAT_007a2314;
    local_40 = DAT_007a2318;
    local_3c = (int)local_58;
    local_30 = DAT_007a2318;
    local_2c = (int)local_58;
    local_59 = 1;
    uVar6 = DAT_007a2314;
    uVar5 = DAT_007a2310;
  }
LAB_0053dcd1:
  iVar3 = param_1[0x15];
  if ((0 < iVar3) && (iVar9 = FUN_00545110(), iVar9 == -1)) {
    iVar3 = iVar3 * 10;
    FUN_005615d0(iVar3,iVar3,iVar3,0xff);
    puVar8 = (undefined4 *)FUN_0051d320();
    local_30 = puVar8[2];
    local_2c = puVar8[3];
    uVar5 = *puVar8;
    uVar6 = puVar8[1];
    local_59 = 1;
  }
  *(undefined4 *)(iVar10 + 0x48) = local_48;
  *(undefined4 *)(iVar10 + 0x4c) = local_44;
  *(undefined4 *)(iVar10 + 0x50) = local_40;
  *(undefined4 *)(iVar10 + 0x6c) = uVar5;
  *(undefined4 *)(iVar10 + 0x70) = uVar6;
  *(undefined4 *)(iVar10 + 0x74) = local_30;
  *(int *)(iVar10 + 0x54) = local_3c;
  *(int *)(iVar10 + 0x78) = local_2c;
  *(undefined1 *)(iVar10 + 0x7c) = local_59;
  iVar3 = param_1[9];
  if (iVar3 == 0xd) {
    FUN_0053cfd0(param_2,param_3);
    FUN_00477550(param_2,param_4);
    FUN_0053cfd0(param_2,param_3);
  }
  else if (iVar3 == 0x14) {
    FUN_0053d390(param_2);
  }
  else if (iVar3 == 8) {
    FUN_0053d710(param_1);
  }
  else {
    FUN_00477550(param_2,param_4);
  }
  if (param_1[0x36] == 0) goto LAB_0053df7e;
  if (param_1[10] == 2) {
    uVar12 = 0;
    uVar11 = 0;
    uVar7 = 0;
LAB_0053de83:
    puVar8 = (undefined4 *)FUN_005615d0(uVar7,uVar11,uVar12,local_58);
    *(undefined4 *)(iVar10 + 0x48) = *puVar8;
    *(undefined4 *)(iVar10 + 0x4c) = puVar8[1];
    *(undefined4 *)(iVar10 + 0x50) = puVar8[2];
    *(undefined4 *)(iVar10 + 0x54) = puVar8[3];
    *(undefined4 *)(iVar10 + 0x6c) = DAT_007a23f0;
    *(undefined4 *)(iVar10 + 0x70) = DAT_007a23f4;
    *(undefined4 *)(iVar10 + 0x74) = DAT_007a23f8;
    iVar3 = DAT_007a23fc;
    *(undefined1 *)(iVar10 + 0x7c) = 0;
    *(int *)(iVar10 + 0x78) = iVar3;
  }
  else {
    if (param_1[0x16] < 1) {
      uVar12 = 0xff;
      uVar11 = 0xff;
      uVar7 = 0xff;
      goto LAB_0053de83;
    }
    iVar3 = param_1[0x16] * 10;
    puVar8 = (undefined4 *)FUN_005615d0(0xff,0xff,0xff,local_58);
    *(undefined4 *)(iVar10 + 0x48) = *puVar8;
    *(undefined4 *)(iVar10 + 0x4c) = puVar8[1];
    *(undefined4 *)(iVar10 + 0x50) = puVar8[2];
    *(undefined4 *)(iVar10 + 0x54) = puVar8[3];
    puVar8 = (undefined4 *)FUN_005615d0(iVar3,iVar3,iVar3,0xff);
    *(undefined4 *)(iVar10 + 0x6c) = *puVar8;
    *(undefined4 *)(iVar10 + 0x70) = puVar8[1];
    *(undefined4 *)(iVar10 + 0x74) = puVar8[2];
    *(undefined4 *)(iVar10 + 0x78) = puVar8[3];
    *(undefined1 *)(iVar10 + 0x7c) = 1;
  }
  local_58 = 0.0;
  if (0 < param_1[0x17]) {
    fVar4 = (float)(param_1[0x17] + -0xc) / (float)_DAT_006fe8b0;
    if (fVar4 < 0.0 == (fVar4 == 0.0)) {
      local_58 = 0.0;
      if (1.0 < fVar4 == (fVar4 == 1.0)) {
        local_58 = (float)_DAT_006fdb38 + (0.0 - (float)_DAT_006fdb38) * fVar4;
      }
    }
    else {
      local_58 = _DAT_006fe174;
    }
  }
  *(float *)(param_2 + 8) = *(float *)(param_2 + 8) + local_58;
  FUN_00477550(param_2,1);
  *(float *)(param_2 + 8) = *(float *)(param_2 + 8) - local_58;
LAB_0053df7e:
  iVar3 = param_1[0x36];
  if (((iVar3 == 2) || (iVar3 == 1)) || (iVar3 == 3)) {
    *(undefined4 *)(iVar10 + 0x48) = local_48;
    *(undefined4 *)(iVar10 + 0x4c) = local_44;
    *(undefined4 *)(iVar10 + 0x50) = local_40;
    *(undefined4 *)(iVar10 + 0x6c) = uVar5;
    *(undefined4 *)(iVar10 + 0x70) = uVar6;
    *(undefined4 *)(iVar10 + 0x74) = local_30;
    *(int *)(iVar10 + 0x54) = local_3c;
    *(int *)(iVar10 + 0x78) = local_2c;
    *(undefined1 *)(iVar10 + 0x7c) = local_59;
    FUN_00477550(param_2,3);
  }
  if (param_1[9] == 0x21) {
    *(undefined4 *)(iVar10 + 0x48) = local_48;
    *(undefined4 *)(iVar10 + 0x4c) = local_44;
    *(undefined4 *)(iVar10 + 0x50) = local_40;
    *(undefined4 *)(iVar10 + 0x6c) = uVar5;
    *(undefined4 *)(iVar10 + 0x70) = uVar6;
    *(undefined4 *)(iVar10 + 0x74) = local_30;
    *(int *)(iVar10 + 0x54) = local_3c;
    *(int *)(iVar10 + 0x78) = local_2c;
    *(undefined1 *)(iVar10 + 0x7c) = local_59;
    FUN_00477550(param_2,3);
    FUN_00477550(param_2,4);
  }
  FUN_005993a0();
  return;
}



