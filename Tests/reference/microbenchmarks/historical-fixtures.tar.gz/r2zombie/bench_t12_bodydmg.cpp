// bench_t12 — kBodyDamageCases 34 -> Zombie::TakeBodyDamage（受击事件热）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::TakeBodyDamage_A(int theDamage, unsigned int theDamageFlags)
{
    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
    {
        mJustGotShotCounter = 25;
    }

    if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_FREEZE))
    {
        ApplyChill(false);
    }

    int aBodyHealthOrigin = mBodyHealth;
    int aDamageIndexBeforeDamage = GetBodyDamageIndex();
    mBodyHealth -= theDamage;
    int aDamageIndexAfterDamage = GetBodyDamageIndex();
    if (mZombieType == ZombieType::ZOMBIE_ZAMBONI)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
        {
            mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
        }

        if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_SPIKE))
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_1, IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE2);
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_2, IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE2);
            ZamboniDeath(theDamageFlags);
        }
        else if (mBodyHealth <= 0)
        {
            ZamboniDeath(theDamageFlags);
        }
        else if (aDamageIndexBeforeDamage != aDamageIndexAfterDamage)
        {
            if (aDamageIndexAfterDamage == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_1, IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE1);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_2, IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE1);
            }
            else if (aDamageIndexAfterDamage == 2)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_1, IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_2, IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE2);
                AddAttachedParticle(27, 72, ParticleEffect::PARTICLE_ZAMBONI_SMOKE);
            }
        }
    }
    else if (mZombieType == ZombieType::ZOMBIE_CATAPULT)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_SPIKE) || mBodyHealth <= 0)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_catapult_siding, IMAGE_REANIM_ZOMBIE_CATAPULT_SIDING_DAMAGE);
            CatapultDeath(theDamageFlags);
        }
        else if (aDamageIndexBeforeDamage != aDamageIndexAfterDamage)
        {
            if (aDamageIndexAfterDamage == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_catapult_siding, IMAGE_REANIM_ZOMBIE_CATAPULT_SIDING_DAMAGE);
            }
            else if (aDamageIndexAfterDamage == 2)
            {
                AddAttachedParticle(47, 77, ParticleEffect::PARTICLE_ZAMBONI_SMOKE);
            }
        }
    }
    else if (mZombieType == ZombieType::ZOMBIE_GARGANTUAR || mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aDamageIndexBeforeDamage != aDamageIndexAfterDamage)
        {
            if (aDamageIndexAfterDamage == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantua_body1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_BODY1_2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_outerarm_lower, IMAGE_REANIM_ZOMBIE_GARGANTUAR_OUTERARM_LOWER2);
            }
            else if (aDamageIndexAfterDamage == 2)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantua_body1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_BODY1_3);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_outerleg_foot, IMAGE_REANIM_ZOMBIE_GARGANTUAR_FOOT2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_outerarm_lower, IMAGE_REANIM_ZOMBIE_GARGANTUAR_OUTERARM_LOWER2);
                if (mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD2_REDEYE);
                }
                else
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD2);
                }
            }
        }
    }
    else if (mZombieType == ZombieType::ZOMBIE_BOSS)
    {
        if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
        {
            mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
        }

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aDamageIndexBeforeDamage != aDamageIndexAfterDamage)
        {
            if (aDamageIndexAfterDamage == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_head, IMAGE_REANIM_ZOMBIE_BOSS_HEAD_DAMAGE1);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_jaw, IMAGE_REANIM_ZOMBIE_BOSS_JAW_DAMAGE1);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_hand, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_HAND_DAMAGE1);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_thumb2, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_THUMB_DAMAGE1);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_innerleg_foot, IMAGE_REANIM_ZOMBIE_BOSS_FOOT_DAMAGE1);
            }
            else if (aDamageIndexAfterDamage == 2)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_head, IMAGE_REANIM_ZOMBIE_BOSS_HEAD_DAMAGE2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_jaw, IMAGE_REANIM_ZOMBIE_BOSS_JAW_DAMAGE2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_hand, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_HAND_DAMAGE2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_thumb2, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_THUMB_DAMAGE2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerleg_foot, IMAGE_REANIM_ZOMBIE_BOSS_FOOT_DAMAGE2);
                ApplyBossSmokeParticles(true);
            }
        }

        if (aBodyHealthOrigin >= mBodyMaxHealth / BOSS_FLASH_HEALTH_FRACTION && mBodyHealth < mBodyMaxHealth / BOSS_FLASH_HEALTH_FRACTION)
        {
            mApp->AddTodParticle(770.0f, 260.0f, Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_TOP, 0, 0), ParticleEffect::PARTICLE_BOSS_EXPLOSION);
            mApp->PlayFoley(FoleyType::FOLEY_BOSS_EXPLOSION_SMALL);
            ApplyBossSmokeParticles(true);
        }

        if (mBodyHealth <= 0)
        {
            mBodyHealth = 1;
        }
    }
    else
    {
        UpdateDamageStates(theDamageFlags);
    }

    if (mBodyHealth <= 0)
    {
        mBodyHealth = 0;
        PlayDeathAnim(theDamageFlags);
        DropLoot();
    }
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::TakeBodyDamage_B(int theDamage, unsigned int theDamageFlags)
{
    if (!TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
    {
        mJustGotShotCounter = 25;
    }

    if (TestBit(theDamageFlags, (int)DamageFlags::DAMAGE_FREEZE))
    {
        ApplyChill(false);
    }

    int aBodyHealthOrigin = mBodyHealth;
    int aDamageIndexBeforeDamage = GetBodyDamageIndex();
    mBodyHealth -= theDamage;
    int aDamageIndexAfterDamage = GetBodyDamageIndex();
    // C 形态 -> 匿名 lambda 函数指针表 kBodyDamageCases（仿 kIceTrapAdjusts
    // 范式）：行序 = ZombieType 枚举序 0..33；原 4 支异构大体积支整体入槽，
    // 无 case 槽 = nullptr（落空走原 else 支 UpdateDamageStates）。
    // GARGANTUAR/REDEYE 共体（constexpr 指针变量复用，内含 REDEYE 头像分叉）。
    // 四个链前局部经 BodyDamageLocals 传递。
    struct BodyDamageLocals
    {
        unsigned int mDamageFlags;
        int mBodyHealthOrigin;
        int mIndexBeforeDamage;
        int mIndexAfterDamage;
    };
    using BodyDamageCaseFn = void (*)(Zombie&, const BodyDamageLocals&);
    static constexpr BodyDamageCaseFn kBodyDamageCaseGargantuar = [](Zombie& z, const BodyDamageLocals& lc)
    {
        Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
        if (lc.mIndexBeforeDamage != lc.mIndexAfterDamage)
        {
            if (lc.mIndexAfterDamage == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantua_body1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_BODY1_2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_outerarm_lower, IMAGE_REANIM_ZOMBIE_GARGANTUAR_OUTERARM_LOWER2);
            }
            else if (lc.mIndexAfterDamage == 2)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantua_body1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_BODY1_3);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_outerleg_foot, IMAGE_REANIM_ZOMBIE_GARGANTUAR_FOOT2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_outerarm_lower, IMAGE_REANIM_ZOMBIE_GARGANTUAR_OUTERARM_LOWER2);
                if (z.mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD2_REDEYE);
                }
                else
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD2);
                }
            }
        }
    };
    static constexpr BodyDamageCaseFn kBodyDamageCases[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
        nullptr,  // 0 ZOMBIE_NORMAL（原 default：UpdateDamageStates）
        nullptr,  // 1 ZOMBIE_FLAG（原 default）
        nullptr,  // 2 ZOMBIE_TRAFFIC_CONE（原 default）
        nullptr,  // 3 ZOMBIE_POLEVAULTER（原 default）
        nullptr,  // 4 ZOMBIE_PAIL（原 default）
        nullptr,  // 5 ZOMBIE_NEWSPAPER（原 default）
        nullptr,  // 6 ZOMBIE_DOOR（原 default）
        nullptr,  // 7 ZOMBIE_FOOTBALL（原 default）
        nullptr,  // 8 ZOMBIE_DANCER（原 default）
        nullptr,  // 9 ZOMBIE_BACKUP_DANCER（原 default）
        nullptr,  // 10 ZOMBIE_DUCKY_TUBE（原 default）
        nullptr,  // 11 ZOMBIE_SNORKEL（原 default）
        // 原 if ZOMBIE_ZAMBONI
        [](Zombie& z, const BodyDamageLocals& lc)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (!TestBit(lc.mDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
            {
                z.mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
            }

            if (TestBit(lc.mDamageFlags, (int)DamageFlags::DAMAGE_SPIKE))
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_1, IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE2);
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_2, IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE2);
                z.ZamboniDeath(lc.mDamageFlags);
            }
            else if (z.mBodyHealth <= 0)
            {
                z.ZamboniDeath(lc.mDamageFlags);
            }
            else if (lc.mIndexBeforeDamage != lc.mIndexAfterDamage)
            {
                if (lc.mIndexAfterDamage == 1)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_1, IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE1);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_2, IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE1);
                }
                else if (lc.mIndexAfterDamage == 2)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_1, IMAGE_REANIM_ZOMBIE_ZAMBONI_1_DAMAGE2);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_zamboni_2, IMAGE_REANIM_ZOMBIE_ZAMBONI_2_DAMAGE2);
                    z.AddAttachedParticle(27, 72, ParticleEffect::PARTICLE_ZAMBONI_SMOKE);
                }
            }
        },  // 12 ZOMBIE_ZAMBONI
        nullptr,  // 13 ZOMBIE_BOBSLED（原 default）
        nullptr,  // 14 ZOMBIE_DOLPHIN_RIDER（原 default）
        nullptr,  // 15 ZOMBIE_JACK_IN_THE_BOX（原 default）
        nullptr,  // 16 ZOMBIE_BALLOON（原 default）
        nullptr,  // 17 ZOMBIE_DIGGER（原 default）
        nullptr,  // 18 ZOMBIE_POGO（原 default）
        nullptr,  // 19 ZOMBIE_YETI（原 default）
        nullptr,  // 20 ZOMBIE_BUNGEE（原 default）
        nullptr,  // 21 ZOMBIE_LADDER（原 default）
        // 原 else-if ZOMBIE_CATAPULT
        [](Zombie& z, const BodyDamageLocals& lc)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (TestBit(lc.mDamageFlags, (int)DamageFlags::DAMAGE_SPIKE) || z.mBodyHealth <= 0)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_catapult_siding, IMAGE_REANIM_ZOMBIE_CATAPULT_SIDING_DAMAGE);
                z.CatapultDeath(lc.mDamageFlags);
            }
            else if (lc.mIndexBeforeDamage != lc.mIndexAfterDamage)
            {
                if (lc.mIndexAfterDamage == 1)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_catapult_siding, IMAGE_REANIM_ZOMBIE_CATAPULT_SIDING_DAMAGE);
                }
                else if (lc.mIndexAfterDamage == 2)
                {
                    z.AddAttachedParticle(47, 77, ParticleEffect::PARTICLE_ZAMBONI_SMOKE);
                }
            }
        },  // 22 ZOMBIE_CATAPULT
        kBodyDamageCaseGargantuar,  // 23 ZOMBIE_GARGANTUAR（共体）
        nullptr,  // 24 ZOMBIE_IMP（原 default）
        // 原 else-if ZOMBIE_BOSS
        [](Zombie& z, const BodyDamageLocals& lc)
        {
            if (!TestBit(lc.mDamageFlags, (int)DamageFlags::DAMAGE_DOESNT_CAUSE_FLASH))
            {
                z.mApp->PlayFoley(FoleyType::FOLEY_SHIELD_HIT);
            }

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (lc.mIndexBeforeDamage != lc.mIndexAfterDamage)
            {
                if (lc.mIndexAfterDamage == 1)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_head, IMAGE_REANIM_ZOMBIE_BOSS_HEAD_DAMAGE1);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_jaw, IMAGE_REANIM_ZOMBIE_BOSS_JAW_DAMAGE1);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_hand, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_HAND_DAMAGE1);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_thumb2, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_THUMB_DAMAGE1);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_innerleg_foot, IMAGE_REANIM_ZOMBIE_BOSS_FOOT_DAMAGE1);
                }
                else if (lc.mIndexAfterDamage == 2)
                {
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_head, IMAGE_REANIM_ZOMBIE_BOSS_HEAD_DAMAGE2);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_jaw, IMAGE_REANIM_ZOMBIE_BOSS_JAW_DAMAGE2);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_hand, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_HAND_DAMAGE2);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerarm_thumb2, IMAGE_REANIM_ZOMBIE_BOSS_OUTERARM_THUMB_DAMAGE2);
                    aBodyReanim->SetImageOverride(ReanimTrackId::Boss_outerleg_foot, IMAGE_REANIM_ZOMBIE_BOSS_FOOT_DAMAGE2);
                    z.ApplyBossSmokeParticles(true);
                }
            }

            if (lc.mBodyHealthOrigin >= z.mBodyMaxHealth / BOSS_FLASH_HEALTH_FRACTION && z.mBodyHealth < z.mBodyMaxHealth / BOSS_FLASH_HEALTH_FRACTION)
            {
                z.mApp->AddTodParticle(770.0f, 260.0f, Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_TOP, 0, 0), ParticleEffect::PARTICLE_BOSS_EXPLOSION);
                z.mApp->PlayFoley(FoleyType::FOLEY_BOSS_EXPLOSION_SMALL);
                z.ApplyBossSmokeParticles(true);
            }

            if (z.mBodyHealth <= 0)
            {
                z.mBodyHealth = 1;
            }
        },  // 25 ZOMBIE_BOSS
        nullptr,  // 26 ZOMBIE_PEA_HEAD（原 default）
        nullptr,  // 27 ZOMBIE_WALLNUT_HEAD（原 default）
        nullptr,  // 28 ZOMBIE_JALAPENO_HEAD（原 default）
        nullptr,  // 29 ZOMBIE_GATLING_HEAD（原 default）
        nullptr,  // 30 ZOMBIE_SQUASH_HEAD（原 default）
        nullptr,  // 31 ZOMBIE_TALLNUT_HEAD（原 default）
        kBodyDamageCaseGargantuar,  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
        nullptr,  // 33 ZOMBIE_ZOMBATAR（原 default）
    };
    static_assert(sizeof(kBodyDamageCases) / sizeof(kBodyDamageCases[0]) ==
        (int)ZombieType::NUM_ZOMBIE_TYPES, "kBodyDamageCases 槽位须与 ZombieType 枚举同步");

    const BodyDamageLocals aLocals{theDamageFlags, aBodyHealthOrigin, aDamageIndexBeforeDamage, aDamageIndexAfterDamage};
    const unsigned aTypeIndex = static_cast<unsigned>(mZombieType);
    const BodyDamageCaseFn aCase =
        aTypeIndex < sizeof(kBodyDamageCases) / sizeof(kBodyDamageCases[0]) ? kBodyDamageCases[aTypeIndex] : nullptr;
    if (aCase != nullptr)
    {
        aCase(*this, aLocals);
    }
    else
    {
        UpdateDamageStates(theDamageFlags);
    }

    if (mBodyHealth <= 0)
    {
        mBodyHealth = 0;
        PlayDeathAnim(theDamageFlags);
        DropLoot();
    }
}

static Zombie g_z;
static void ResetBodyDmg(const ZBInput& in, int& dmg, unsigned& flags)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    g_z.mZombieType = (ZombieType)(in.a % 34);
    g_z.mZombiePhase = ZombiePhase::PHASE_ZOMBIE_NORMAL;
    g_z.mBodyMaxHealth = 270;
    g_z.mBodyHealth = (int)(in.b % 271);
    g_z.mJustGotShotCounter = 0;
    g_z.mBodyReanimID = (ReanimationID)(1 + in.a % 2);
    dmg = (int)(in.c % 40) + 1;
    flags = (in.d & ((1u << 2) | (1u << 3) | (1u << 5)));
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            int dmg; unsigned fl;
            ResetBodyDmg(g_zb_inputs[i], dmg, fl);
            g_z.TakeBodyDamage_A(dmg, fl);
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            int dmg; unsigned fl;
            ResetBodyDmg(g_zb_inputs[i], dmg, fl);
            g_z.TakeBodyDamage_B(dmg, fl);
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t12_TakeBodyDamage", passA, passB);
}
