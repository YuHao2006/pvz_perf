#include "pvz/time/simulation_rate_policy.hpp"

#include <array>
#include <limits>
#include <stdexcept>

namespace pvz::time {
namespace {

constexpr std::array<std::uint32_t, 5> kRates{100, 200, 400, 500, 1000};
constexpr std::int64_t kNanosecondsPerSecond = 1'000'000'000;

[[nodiscard]] bool fits_budget(
    const std::uint32_t hz,
    const std::chrono::nanoseconds cost,
    const std::uint32_t budget_percent) noexcept
{
    // Compare as integers to keep rate selection independent of floating point mode.
    const auto maximum_cost =
        (kNanosecondsPerSecond * static_cast<std::int64_t>(budget_percent)) /
        (static_cast<std::int64_t>(hz) * 100);
    return cost.count() <= maximum_cost;
}

} // namespace

SimulationRatePolicy::SimulationRatePolicy(const RatePolicyConfig config)
    : config_(config)
{
    if (!is_supported_simulation_rate(config_.requested_hz))
        throw std::invalid_argument("unsupported requested simulation rate");
    if (!is_supported_simulation_rate(config_.minimum_hz) || config_.minimum_hz > config_.requested_hz)
        throw std::invalid_argument("minimum simulation rate must be a supported tier no higher than requested rate");
    if (config_.cpu_budget_percent == 0 || config_.cpu_budget_percent > 100)
        throw std::invalid_argument("CPU budget must be between 1 and 100 percent");
}

void SimulationRatePolicy::observe_tick_cost(const std::chrono::nanoseconds cost) noexcept
{
    if (cost <= std::chrono::nanoseconds::zero())
        return;

    if (observed_samples_ == 0) {
        average_tick_cost_ = cost;
    } else {
        const auto old_count = average_tick_cost_.count();
        const auto new_count = cost.count();
        if (old_count > (std::numeric_limits<std::int64_t>::max() - new_count) / 3) {
            average_tick_cost_ = cost;
        } else {
            average_tick_cost_ = std::chrono::nanoseconds{(old_count * 3 + new_count) / 4};
        }
    }
    ++observed_samples_;
}

void SimulationRatePolicy::reset() noexcept
{
    average_tick_cost_ = std::chrono::nanoseconds::zero();
    observed_samples_ = 0;
}

const RatePolicyConfig& SimulationRatePolicy::config() const noexcept
{
    return config_;
}

RateDecision SimulationRatePolicy::decision() const noexcept
{
    RateDecision result;
    result.requested_hz = config_.requested_hz;
    result.selected_hz = config_.requested_hz;
    result.sustainable_hz = config_.requested_hz;
    result.average_tick_cost = average_tick_cost_;
    if (observed_samples_ == 0)
        return result;

    result.sustainable_hz = config_.minimum_hz;
    for (const std::uint32_t rate : kRates) {
        if (rate < config_.minimum_hz || rate > config_.requested_hz)
            continue;
        if (fits_budget(rate, average_tick_cost_, config_.cpu_budget_percent))
            result.sustainable_hz = rate;
    }
    result.selected_hz = result.sustainable_hz;
    result.within_budget = fits_budget(
        result.selected_hz,
        average_tick_cost_,
        config_.cpu_budget_percent);
    return result;
}

std::uint64_t SimulationRatePolicy::observed_samples() const noexcept
{
    return observed_samples_;
}

} // namespace pvz::time
