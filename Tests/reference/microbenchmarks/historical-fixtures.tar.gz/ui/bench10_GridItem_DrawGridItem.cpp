// bench10 | GridItem::DrawGridItem | 12 case switch -> kGridItemDraws 13-slot member-function-pointer table
// FormA = ac447d19^, FormB = HEAD. Draw targets are real member functions of the stub class (member-pointer
// call overhead preserved). Discriminant mGridItemType uniform over 0..12.
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

static const int kN = 2000000;
static uint32_t g_raw[kN];

enum GridItemTypeG {
    GRIDITEM_NONE = 0, GRIDITEM_GRAVESTONE = 1, GRIDITEM_CRATER = 2, GRIDITEM_LADDER = 3,
    GRIDITEM_PORTAL_CIRCLE = 4, GRIDITEM_PORTAL_SQUARE = 5, GRIDITEM_BRAIN = 6, GRIDITEM_SCARY_POT = 7,
    GRIDITEM_SQUIRREL = 8, GRIDITEM_ZEN_TOOL = 9, GRIDITEM_STINKY = 10, GRIDITEM_RAKE = 11,
    GRIDITEM_IZOMBIE_BRAIN = 12
};

static inline void TOD_ASSERT_IMPL(bool) {}
#define TOD_ASSERT(x) TOD_ASSERT_IMPL((x))

static int g_pos = 0;
static inline uint32_t NextVal() { uint32_t v = g_raw[g_pos % kN]; g_pos++; return v; }

struct ImageStub { int id; };
static ImageStub g_imgBrain{ 5 };
struct GraphicsStub {
    void DrawImageF(ImageStub* img, float x, float y) { Mix(80); Mix((uint64_t)img->id * 31 + (uint64_t)(x * 10) + (uint64_t)(y * 10)); }
};
static GraphicsStub g_gfx;

struct ReanimationStub { void Draw(GraphicsStub*) { Mix(81); } };
struct TodParticleSystemStub { void Draw(GraphicsStub*) { Mix(82); } };
static ReanimationStub g_reanim;
static TodParticleSystemStub g_particle;
struct AppStub {
    ReanimationStub* ReanimationTryToGet(int id) { Mix(83); return (NextVal() & 1) ? &g_reanim : nullptr; }
    TodParticleSystemStub* ParticleTryToGet(int id) { Mix(84); return (NextVal() & 1) ? &g_particle : nullptr; }
};
static AppStub g_app;

struct GridItem {
    GridItemTypeG mGridItemType;
    float mPosX, mPosY;
    int mGridItemReanimID;
    int mGridItemParticleID;
    AppStub* mApp;

    void DrawGraveStone(GraphicsStub* g)   { (void)g; Mix(90); }
    void DrawCrater(GraphicsStub* g)       { (void)g; Mix(91); }
    void DrawLadder(GraphicsStub* g)       { (void)g; Mix(92); }
    void DrawScaryPot(GraphicsStub* g)     { (void)g; Mix(93); }
    void DrawStinky(GraphicsStub* g)       { (void)g; Mix(94); }
    void DrawIZombieBrain(GraphicsStub* g) { (void)g; Mix(95); }
};
static GridItem g_item;

// ================= FormA: verbatim switch (ac447d19^) =================
static void DrawGridItemA(GraphicsStub* g)
{
    switch (g_item.mGridItemType)
    {
    case GridItemTypeG::GRIDITEM_GRAVESTONE:    g_item.DrawGraveStone(g);                                  break;
    case GridItemTypeG::GRIDITEM_CRATER:        g_item.DrawCrater(g);                                      break;
    case GridItemTypeG::GRIDITEM_LADDER:        g_item.DrawLadder(g);                                      break;
    case GridItemTypeG::GRIDITEM_PORTAL_CIRCLE:                                                             break;
    case GridItemTypeG::GRIDITEM_PORTAL_SQUARE:                                                             break;
    case GridItemTypeG::GRIDITEM_ZEN_TOOL:                                                                  break;
    case GridItemTypeG::GRIDITEM_RAKE:                                                                      break;
    case GridItemTypeG::GRIDITEM_BRAIN:         g->DrawImageF(&g_imgBrain, g_item.mPosX, g_item.mPosY);    break;
    case GridItemTypeG::GRIDITEM_SCARY_POT:     g_item.DrawScaryPot(g);                                    break;
    case GridItemTypeG::GRIDITEM_SQUIRREL:                                                                  break;
    case GridItemTypeG::GRIDITEM_STINKY:        g_item.DrawStinky(g);                                      break;
    case GridItemTypeG::GRIDITEM_IZOMBIE_BRAIN: g_item.DrawIZombieBrain(g);                                break;
    default:                                    TOD_ASSERT(false);                                         break;
    }

    ReanimationStub* aGridItemReanim = g_item.mApp->ReanimationTryToGet(g_item.mGridItemReanimID);
    if (aGridItemReanim)
    {
        aGridItemReanim->Draw(g);
    }

    TodParticleSystemStub* aGridItemParticle = g_item.mApp->ParticleTryToGet(g_item.mGridItemParticleID);
    if (aGridItemParticle)
    {
        aGridItemParticle->Draw(g);
    }
}

// ================= FormB: HEAD member-pointer table =================
namespace {
using GridItemDrawFn = void (GridItem::*)(GraphicsStub*);
constexpr GridItemDrawFn kGridItemDraws[(int)GridItemTypeG::GRIDITEM_IZOMBIE_BRAIN + 1] = {
    nullptr,                     // 0 GRIDITEM_NONE（原 default 断言）
    &GridItem::DrawGraveStone,   // 1 GRIDITEM_GRAVESTONE
    &GridItem::DrawCrater,       // 2 GRIDITEM_CRATER
    &GridItem::DrawLadder,       // 3 GRIDITEM_LADDER
    nullptr,                     // 4 GRIDITEM_PORTAL_CIRCLE（空操作）
    nullptr,                     // 5 GRIDITEM_PORTAL_SQUARE（空操作）
    nullptr,                     // 6 GRIDITEM_BRAIN（表外特例：分发点内联绘制）
    &GridItem::DrawScaryPot,     // 7
    nullptr,
    nullptr,
    &GridItem::DrawStinky,
    nullptr,
    &GridItem::DrawIZombieBrain,
};
}  // namespace

static void DrawGridItemB(GraphicsStub* g)
{
    if (g_item.mGridItemType == GridItemTypeG::GRIDITEM_BRAIN)
    {
        g->DrawImageF(&g_imgBrain, g_item.mPosX, g_item.mPosY);
    }
    else
    {
        const int aTypeIndex = (int)g_item.mGridItemType;
        if (aTypeIndex >= 1 && aTypeIndex <= (int)GridItemTypeG::GRIDITEM_IZOMBIE_BRAIN)
        {
            const GridItemDrawFn aDrawFn = kGridItemDraws[aTypeIndex];
            if (aDrawFn != nullptr)
            {
                (g_item.*aDrawFn)(g);
            }
        }
        else
        {
            TOD_ASSERT(false);
        }
    }

    ReanimationStub* aGridItemReanim = g_item.mApp->ReanimationTryToGet(g_item.mGridItemReanimID);
    if (aGridItemReanim)
    {
        aGridItemReanim->Draw(g);
    }

    TodParticleSystemStub* aGridItemParticle = g_item.mApp->ParticleTryToGet(g_item.mGridItemParticleID);
    if (aGridItemParticle)
    {
        aGridItemParticle->Draw(g);
    }
}

// ---------------- harness ----------------
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    uint32_t v = g_raw[i];
    g_item.mGridItemType = (GridItemTypeG)(v % 13);
    g_item.mPosX = (float)((v >> 4) % 700);
    g_item.mPosY = (float)((v >> 8) % 400);
    g_item.mGridItemReanimID = 11;
    g_item.mGridItemParticleID = 22;
    g_item.mApp = &g_app;
    g_pos = 0;
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); DrawGridItemA(&g_gfx); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum; g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); DrawGridItemB(&g_gfx); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("GridItem::DrawGridItem | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
