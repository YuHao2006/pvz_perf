
void __thiscall FUN_0054c280(int *param_1,undefined4 param_2)

{
  (**(code **)(*param_1 + 0xb0))(param_2);
  return;
}

