#include "pvz/assets/image_decode.hpp"

#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace {

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void write_u16(std::vector<std::uint8_t>& bytes, const std::size_t offset, const std::uint16_t value)
{
    bytes[offset] = static_cast<std::uint8_t>(value & 0xFFU);
    bytes[offset + 1] = static_cast<std::uint8_t>((value >> 8U) & 0xFFU);
}

void write_u32(std::vector<std::uint8_t>& bytes, const std::size_t offset, const std::uint32_t value)
{
    for (std::uint32_t index = 0; index < 4; ++index)
        bytes[offset + index] = static_cast<std::uint8_t>((value >> (index * 8U)) & 0xFFU);
}

[[nodiscard]] std::vector<std::uint8_t> make_two_pixel_bmp()
{
    constexpr std::uint32_t pixel_offset = 54;
    constexpr std::uint32_t pixel_bytes = 8;
    std::vector<std::uint8_t> bytes(pixel_offset + pixel_bytes);
    bytes[0] = 'B';
    bytes[1] = 'M';
    write_u32(bytes, 2, static_cast<std::uint32_t>(bytes.size()));
    write_u32(bytes, 10, pixel_offset);
    write_u32(bytes, 14, 40);
    write_u32(bytes, 18, 2);
    write_u32(bytes, 22, 1);
    write_u16(bytes, 26, 1);
    write_u16(bytes, 28, 24);
    write_u32(bytes, 34, pixel_bytes);

    // BMP stores 24-bit pixels as BGR. The single row is red then green.
    bytes[pixel_offset + 0] = 0;
    bytes[pixel_offset + 1] = 0;
    bytes[pixel_offset + 2] = 255;
    bytes[pixel_offset + 3] = 0;
    bytes[pixel_offset + 4] = 255;
    bytes[pixel_offset + 5] = 0;
    return bytes;
}

void test_wic_decodes_to_straight_rgba8()
{
    const auto encoded = make_two_pixel_bmp();
    const auto image = pvz::assets::decode_image_rgba8(encoded);
    require(image.width == 2 && image.height == 1, "decoded extent must match the BMP header");
    require(image.row_pitch_bytes == 8, "RGBA8 output must use a tight four-byte pixel stride");
    require(image.rgba8.size() == 8, "decoded payload must contain both RGBA pixels");
    require(
        image.rgba8[0] == std::byte{255} && image.rgba8[1] == std::byte{0} &&
            image.rgba8[2] == std::byte{0} && image.rgba8[3] == std::byte{255},
        "first decoded pixel must be opaque red");
    require(
        image.rgba8[4] == std::byte{0} && image.rgba8[5] == std::byte{255} &&
            image.rgba8[6] == std::byte{0} && image.rgba8[7] == std::byte{255},
        "second decoded pixel must be opaque green");
}

void test_empty_input_is_rejected()
{
    bool rejected = false;
    try {
        static_cast<void>(pvz::assets::decode_image_rgba8({}));
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "empty encoded images must be rejected");
}

} // namespace

int main()
{
    test_wic_decodes_to_straight_rgba8();
    test_empty_input_is_rejected();
    return EXIT_SUCCESS;
}
