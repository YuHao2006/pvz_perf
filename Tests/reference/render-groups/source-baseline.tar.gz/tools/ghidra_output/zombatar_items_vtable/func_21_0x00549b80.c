
void __thiscall FUN_00549b80(int *param_1,uint *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  uint local_58;
  undefined1 local_30 [4];
  int local_2c;
  undefined1 local_28 [8];
  int *local_20;
  uint *local_1c;
  uint local_18;
  uint local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_006bd428;
  local_10 = ExceptionList;
  uVar3 = DAT_00717ee4 ^ (uint)&stack0xfffffffc;
  ExceptionList = &local_10;
  local_1c = param_2;
  local_18 = *param_2;
  local_14 = param_2[1];
  *param_2 = (*param_2 | param_1[0x15]) & ~param_1[0x16];
  param_2[1] = (param_2[1] | param_1[0x15]) & ~param_1[0x16];
  local_8 = 0;
  if ((char)param_2[2] == '\0') {
    local_58 = param_2[1];
  }
  else {
    local_58 = *param_2;
  }
  if ((local_58 & 1) != 0) {
    (**(code **)(*param_1 + 0x60))(param_3,uVar3);
  }
  piVar4 = (int *)FUN_005b75d0(local_28);
  iVar1 = piVar4[1];
  param_1[0xb] = *piVar4;
  param_1[0xc] = iVar1;
  while( true ) {
    iVar1 = param_1[6];
    FUN_00420ae0();
    local_2c = iVar1;
    if (param_1 == (int *)0xfffffffc) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    cVar2 = FUN_006143c0(local_30);
    if (cVar2 != '\0') break;
    *(undefined1 *)(param_1 + 10) = 0;
    local_20 = (int *)FUN_005e2150();
    local_20 = (int *)*local_20;
    if (local_20 == *(int **)(param_1[8] + 0xac)) {
      *(undefined1 *)(param_2 + 2) = 1;
    }
    (**(code **)(*local_20 + 100))(param_2,param_3);
    if ((char)param_1[10] == '\0') {
      FUN_00614350();
    }
  }
  *(undefined1 *)(param_1 + 10) = 1;
  *local_1c = local_18;
  local_1c[1] = local_14;
  ExceptionList = local_10;
  return;
}

