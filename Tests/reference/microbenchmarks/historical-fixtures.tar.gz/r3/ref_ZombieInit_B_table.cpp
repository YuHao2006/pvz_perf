struct ZombieInitLocals
{
    RenderLayer mRenderLayer;
    int mRenderOffset;
    ReanimationType mBodyReanimType;
    Zombie* mParentZombie;
    int mFromWave;
};
using ZombieInitCaseFn = void (*)(Zombie&, ZombieInitLocals&);

// 尾部公共逻辑（原 switch 后至函数尾逐句迁移）：各槽位结尾直呼——尾部固定，
// 无需回调传参；case 内 return 原样保留——不调即跳过尾部（=原 return 跳过
// 的同一段）；哨兵/越界由分发点 else 直调。置于共体函数与表之前（引用者
// 须后置）。
void ZombieInitializeTail(Zombie& z, ZombieInitLocals& lc)
{


        if (z.IsOnBoard() && z.mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_ZOMBIQUARIUM)
        {
            float aAnimRate = RandRangeFloat(8.0f, 10.0f);
            z.PlayZombieReanim(ReanimTrackId::anim_aquarium_swim, ReanimLoopType::REANIM_LOOP, 0, aAnimRate);

            z.mZombieHeight = ZombieHeight::HEIGHT_ZOMBIQUARIUM;
            z.mZombiePhase = ZombiePhase::PHASE_ZOMBIQUARIUM_DRIFT;
            z.mPhaseCounter = 200;
            z.mBodyHealth = 200;
            z.mSummonCounter = RandRangeInt(200, 400);
        }

        if (z.mApp->IsLittleTroubleLevel() && (z.IsOnBoard() || lc.mFromWave == Zombie::ZOMBIE_WAVE_CUTSCENE))
        {
            z.mScaleZombie = 0.5f;
            z.mBodyHealth /= 4;
            z.mHelmHealth /= 4;
            z.mShieldHealth /= 4;
            z.mFlyingHealth /= 4;
        }

        z.UpdateAnimSpeed();
        if (z.mVariant)
        {
            z.ReanimShowRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_NORMAL);
        }

        z.mHelmMaxHealth = z.mHelmHealth;
        z.mBodyMaxHealth = z.mBodyHealth;
        z.mShieldMaxHealth = z.mShieldHealth;
        z.mFlyingMaxHealth = z.mFlyingHealth;
        z.mDead = false;
        z.mX = (int)z.mPosX;
        z.mY = (int)z.mPosY;
        z.mRenderOrder = Board::MakeRenderOrder(lc.mRenderLayer, z.mRow, lc.mRenderOffset);
        if (z.mZombieHeight == ZombieHeight::HEIGHT_ZOMBIQUARIUM)
        {
            z.mBodyMaxHealth = 300;
        }

        if (z.IsOnBoard())
        {
            z.PlayZombieAppearSound();
            z.StartZombieSound();
        }

        z.UpdateReanim();

}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case ZOMBIE_NORMAL, ZOMBIE_DUCKY_TUBE
void ZombieInitNormal(Zombie& z, ZombieInitLocals& lc)
{
            z.LoadPlainZombieReanim();
            ZombieInitializeTail(z, lc);
}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case ZOMBIE_GARGANTUAR, ZOMBIE_REDEYE_GARGANTUAR
void ZombieInitGargantuar(Zombie& z, ZombieInitLocals& lc)
{
            z.mWidth = 180;
            z.mHeight = 180;
            z.mBodyHealth = 3000;
            z.mAnimFrames = 24;
            z.mAnimTicksPerFrame = 8;
            z.mPosX = WIDE_BOARD_WIDTH + 45 + Rand(10);
            z.mZombieRect = Rect(-17, -38, 125, 154);
            z.mZombieAttackRect = Rect(-30, -38, 89, 154);
            z.mVariant = false;
            lc.mRenderOffset = 8;
            z.mHasObject = true;

            int aPoleHit = Rand(100);
            int aPoleVariant;
            if (!z.IsOnBoard() || z.mBoard->mLevel == 48)
            {
                aPoleVariant = 0;
            }
            else
            {
                aPoleVariant = aPoleHit < 10 ? 2 : aPoleHit < 35 ? 1 : 0;
            }

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (aPoleVariant == 2)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_telephonepole, IMAGE_REANIM_ZOMBIE_GARGANTUAR_ZOMBIE);
            }
            else if (aPoleVariant == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_telephonepole, IMAGE_REANIM_ZOMBIE_GARGANTUAR_DUCKXING);
            }

            if (z.mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD_REDEYE);
                z.mBodyHealth = 6000;
            }
            ZombieInitializeTail(z, lc);
}

// 匿名 lambda 函数指针表，行序 = ZombieType 枚举值序（0..33）；
// 哨兵（CACHED/NUM/INVALID）在表外，由分发守卫拦下 = 原 default 无操作，
// 尾部仍由 else 分支直调。
constexpr ZombieInitCaseFn kZombieInitCases[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
    &ZombieInitNormal,  // 0 ZOMBIE_NORMAL（共体）
    // 原 case ZOMBIE_FLAG
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mHasObject = true;
            z.LoadPlainZombieReanim();

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            Reanimation* aFlagReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FLAG);
            aFlagReanim->PlayReanim(ReanimTrackId::Zombie_flag, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aFlagReanim);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_flaghand);
            AttachReanim(aTrackInstance->mAttachmentID, aFlagReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;

            z.mPosX = WIDE_BOARD_WIDTH;
            ZombieInitializeTail(z, lc);
    },  // 1 ZOMBIE_FLAG
    // 原 case ZOMBIE_TRAFFIC_CONE
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_cone, RENDER_GROUP_NORMAL);
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.mHelmType = HelmType::HELMTYPE_TRAFFIC_CONE;
            z.mHelmHealth = 370;
            ZombieInitializeTail(z, lc);
    },  // 2 ZOMBIE_TRAFFIC_CONE
    // 原 case ZOMBIE_POLEVAULTER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mAnimTicksPerFrame = 6;
            z.mZombiePhase = ZombiePhase::PHASE_POLEVAULTER_PRE_VAULT;
            z.mHasObject = true;
            z.mVariant = false;
            z.mPosX = WIDE_BOARD_WIDTH + 70 + Rand(10);
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_run, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
                z.PickRandomSpeed();
            }
            if (z.mApp->IsWallnutBowlingLevel())
            {
                z.mZombieAttackRect = Rect(-229, 0, 270, 115);
            }
            else
            {
                z.mZombieAttackRect = Rect(-29, 0, 70, 115);
            }
            ZombieInitializeTail(z, lc);
    },  // 3 ZOMBIE_POLEVAULTER
    // 原 case ZOMBIE_PAIL
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_bucket, RENDER_GROUP_NORMAL);
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.mHelmType = HelmType::HELMTYPE_PAIL;
            z.mHelmHealth = 1100;
            ZombieInitializeTail(z, lc);
    },  // 4 ZOMBIE_PAIL
    // 原 case ZOMBIE_NEWSPAPER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mZombieAttackRect = Rect(20, 0, 50, 115);
            z.mZombiePhase = ZombiePhase::PHASE_NEWSPAPER_READING;
            z.mShieldType = ShieldType::SHIELDTYPE_NEWSPAPER;
            z.mShieldHealth = 150;
            z.mVariant = false;
            z.AttachShield();
            ZombieInitializeTail(z, lc);
    },  // 5 ZOMBIE_NEWSPAPER
    // 原 case ZOMBIE_DOOR
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mShieldType = ShieldType::SHIELDTYPE_DOOR;
            z.mShieldHealth = 1100;
            z.LoadPlainZombieReanim();
            z.AttachShield();
            ZombieInitializeTail(z, lc);
    },  // 6 ZOMBIE_DOOR
    // 原 case ZOMBIE_FOOTBALL
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mZombieRect = Rect(50, 0, 57, 115);
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.mHelmType = HelmType::HELMTYPE_FOOTBALL;
            z.mHelmHealth = 1400;
            z.mAnimTicksPerFrame = 6;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 7 ZOMBIE_FOOTBALL
    // 原 case ZOMBIE_DANCER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            // @Patoke: add scaling for new assets
            z.mScaleZombie = 0.8f;
            if (!z.IsOnBoard())
            {
                // @Patoke: oops
                z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            else
            {
                z.mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_IN;
                z.mVelX = 0.5f;
                z.mPhaseCounter = 300 + Rand(12);
                z.PlayZombieReanim(ReanimTrackId::anim_moonwalk, ReanimLoopType::REANIM_LOOP, 0, 24.0f);
            }
            z.mBodyHealth = 500;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 8 ZOMBIE_DANCER
    // 原 case ZOMBIE_BACKUP_DANCER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            // @Patoke: add scaling for new assets
            z.mScaleZombie = 0.8f;
            if (!z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            z.mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_LEFT;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 9 ZOMBIE_BACKUP_DANCER
    &ZombieInitNormal,  // 10 ZOMBIE_DUCKY_TUBE（共体）
    // 原 case ZOMBIE_SNORKEL
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mZombieRect = Rect(12, 0, 62, 115);
            z.mZombieAttackRect = Rect(-5, 0, 55, 115);
            z.SetupWaterTrack(ReanimTrackId::Zombie_snorkle_whitewater);
            z.SetupWaterTrack(ReanimTrackId::Zombie_snorkle_whitewater2);
            z.mVariant = false;
            z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
            ZombieInitializeTail(z, lc);
    },  // 11 ZOMBIE_SNORKEL
    // 原 case ZOMBIE_ZAMBONI
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 1350;
            z.mAnimFrames = 2;
            z.mAnimTicksPerFrame = 8;
            z.mPosX = WIDE_BOARD_WIDTH + Rand(10);
            lc.mRenderOffset = 8;
            z.PlayZombieReanim(ReanimTrackId::anim_drive, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            z.mZombieRect = Rect(0, -13, 153, 140);
            z.mZombieAttackRect = Rect(10, -13, 133, 140);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 12 ZOMBIE_ZAMBONI
    // 原 case ZOMBIE_BOBSLED
    [](Zombie& z, ZombieInitLocals& lc)
    {
            lc.mRenderOffset = 3;

            if (lc.mParentZombie)
            {
                int aPosition = 0;
                while (aPosition < NUM_BOBSLED_FOLLOWERS && lc.mParentZombie->mFollowerZombieID[aPosition] != ZombieID::ZOMBIEID_NULL)
                {
                    aPosition++;
                }
                TOD_ASSERT(aPosition < 3);
                lc.mParentZombie->mFollowerZombieID[aPosition] = z.mBoard->ZombieGetID(&z);
                z.mRelatedZombieID = z.mBoard->ZombieGetID(lc.mParentZombie);

                z.mPosX = lc.mParentZombie->mPosX + (aPosition + 1) * 50;
                if (aPosition == 0)
                {
                    lc.mRenderOffset = 1;
                    z.mAltitude = 9.0f;
                }
                else if (aPosition == 1)
                {
                    lc.mRenderOffset = 2;
                    z.mAltitude = -7.0f;
                }
                else
                {
                    lc.mRenderOffset = 0;
                    z.mAltitude = 9.0f;
                }
            }
            else
            {
                z.mPosX = WIDE_BOARD_WIDTH + 80;
                z.mZombieRect = Rect(-50, 0, 275, 115);
                z.mHelmType = HelmType::HELMTYPE_BOBSLED;
                z.mHelmHealth = 300;
                z.mAltitude = -10.0f;
            }

            z.mVelX = 0.6f;
            z.mZombiePhase = ZombiePhase::PHASE_BOBSLED_SLIDING;
            z.mPhaseCounter = 500;
            z.mVariant = false;

            if (z.mFromWave == Zombie::ZOMBIE_WAVE_CUTSCENE)
            {
                z.PlayZombieReanim(ReanimTrackId::anim_jump, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 20.0f);
                z.mApp->ReanimationGet(z.mBodyReanimID)->mAnimTime = 1.0f;
                z.mAltitude = 18.0f;
            }
            else if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_push, ReanimLoopType::REANIM_LOOP, 0, 30.0f);
            }
            ZombieInitializeTail(z, lc);
    },  // 13 ZOMBIE_BOBSLED
    // 原 case ZOMBIE_DOLPHIN_RIDER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mAnimTicksPerFrame = 6;
            z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING;
            z.mVariant = false;
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_walkdolphin, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
                z.PickRandomSpeed();
            }
            z.SetupWaterTrack(ReanimTrackId::Zombie_dolphinrider_whitewater);
            z.SetupWaterTrack(ReanimTrackId::Zombie_dolphinrider_dolphininwater);
            ZombieInitializeTail(z, lc);
    },  // 14 ZOMBIE_DOLPHIN_RIDER
    // 原 case ZOMBIE_JACK_IN_THE_BOX
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mAnimTicksPerFrame = 6;

            int aDistance = 450 + Rand(300);
            if (Rand(20) == 0)  // 早爆的概率
            {
                aDistance /= 3;
            }
            z.mPhaseCounter = (int)(aDistance / z.mVelX) * ZOMBIE_LIMP_SPEED_FACTOR;
            z.mZombieAttackRect = Rect(20, 0, 50, 115);

            if (z.mApp->IsScaryPotterLevel())
            {
                z.mPhaseCounter = 10;
            }
            if (z.IsOnBoard())
            {
                z.mZombiePhase = ZombiePhase::PHASE_JACK_IN_THE_BOX_RUNNING;
            }
            ZombieInitializeTail(z, lc);
    },  // 15 ZOMBIE_JACK_IN_THE_BOX
    // 原 case ZOMBIE_BALLOON
    [](Zombie& z, ZombieInitLocals& lc)
    {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            aBodyReanim->SetTruncateDisappearingFramesAll( false);

            if (z.IsOnBoard())
            {
                z.mAltitude = 25.0f;
                z.mZombiePhase = ZombiePhase::PHASE_BALLOON_FLYING;
                z.PlayZombieReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, aBodyReanim->mAnimRate);
            }
            else
            {
                float aAnimRate = RandRangeFloat(8.0f, 10.0f);
                z.SetAnimRate(aAnimRate);
            }

            Reanimation* aPropellerReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, lc.mBodyReanimType);
            aPropellerReanim->SetFramesForLayer(ReanimTrackId::propeller);
            aPropellerReanim->mLoopType = ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME;
            aPropellerReanim->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::hat);

            z.mFlyingHealth = 20;
            z.mZombieRect = Rect(36, 30, 42, 115);
            z.mZombieAttackRect = Rect(20, 30, 50, 115);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 16 ZOMBIE_BALLOON
    // 原 case ZOMBIE_DIGGER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mHelmType = HelmType::HELMTYPE_DIGGER;
            z.mHelmHealth = 100;
            z.mVariant = false;
            z.mHasObject = true;
            z.mZombieRect = Rect(50, 0, 28, 115);
        
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            aBodyReanim->SetTruncateDisappearingFramesAll( false);
        
            if (!z.IsOnBoard())
            {
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_CUTSCENE;
            }
            else
            {
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_TUNNELING;
                z.AddAttachedParticle(60, 100, ParticleEffect::PARTICLE_DIGGER_TUNNEL);
                lc.mRenderOffset = 7;
                z.PlayZombieReanim(ReanimTrackId::anim_dig, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
                z.PickRandomSpeed();
            }
            ZombieInitializeTail(z, lc);
    },  // 17 ZOMBIE_DIGGER
    // 原 case ZOMBIE_POGO
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mVariant = false;
            z.mZombiePhase = ZombiePhase::PHASE_POGO_BOUNCING;
            z.mPhaseCounter = Rand(POGO_BOUNCE_TIME) + 1;
            z.mHasObject = true;
            z.mBodyHealth = 500;
            z.mZombieAttackRect = Rect(10, 0, 30, 115);
            z.PlayZombieReanim(ReanimTrackId::anim_pogo, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 40.0f);
            z.mApp->ReanimationGet(z.mBodyReanimID)->mAnimTime = 1.0f;
            ZombieInitializeTail(z, lc);
    },  // 18 ZOMBIE_POGO
    // 原 case ZOMBIE_YETI
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 1350;
            z.mPhaseCounter = RandRangeInt(1500, 2000);
            z.mHasObject = true;
            z.mZombieAttackRect = Rect(20, 0, 50, 115);
            ZombieInitializeTail(z, lc);
    },  // 19 ZOMBIE_YETI
    // 原 case ZOMBIE_BUNGEE
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 450;
            z.mAnimFrames = 4;
            z.mAltitude = BUNGEE_ZOMBIE_HEIGHT + RandRangeInt(0, 150);
            z.mVelX = 0.0f;

            if (z.IsOnBoard())
            {
                z.PickBungeeZombieTarget(-1);
            
                if (z.mDead)
                {
                    return;
                }

                z.mZombiePhase = ZombiePhase::PHASE_BUNGEE_DIVING;
            }
            else
            {
                z.mZombiePhase = ZombiePhase::PHASE_BUNGEE_CUTSCENE;
                z.mPhaseCounter = RandRangeInt(0, 200);
            }

            z.PlayZombieReanim(ReanimTrackId::anim_drop, ReanimLoopType::REANIM_LOOP, 0, 24.0f);
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_rightarm_lower2, RENDER_GROUP_ARMS);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_rightarm_hand2, RENDER_GROUP_ARMS);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_leftarm_lower2, RENDER_GROUP_ARMS);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_leftarm_hand2, RENDER_GROUP_ARMS);
            aBodyReanim->SetTruncateDisappearingFramesAll( false);

            lc.mRenderLayer = RenderLayer::RENDER_LAYER_GRAVE_STONE;
            lc.mRenderOffset = 7;
            z.mZombieRect = Rect(-20, 22, 110, 94);
            z.mZombieAttackRect = Rect(0, 0, 0, 0);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 20 ZOMBIE_BUNGEE
    // 原 case ZOMBIE_LADDER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mShieldHealth = 500;
            z.mShieldType = ShieldType::SHIELDTYPE_LADDER;
            z.mZombieAttackRect = Rect(10, 0, 50, 115);
            if (z.IsOnBoard())
            {
                z.mZombiePhase = ZombiePhase::PHASE_LADDER_CARRYING;
                z.StartWalkAnim(0);
            }
            z.AttachShield();
            ZombieInitializeTail(z, lc);
    },  // 21 ZOMBIE_LADDER
    // 原 case ZOMBIE_CATAPULT
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 850;
            z.mPosX = WIDE_BOARD_WIDTH + 25 + Rand(10);
            z.mSummonCounter = 20;
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 5.5f);
            }
            else
            {
                z.PlayZombieReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 8.0f);
            }
            z.mZombieRect = Rect(0, -13, 153, 140);
            z.mZombieAttackRect = Rect(10, -13, 133, 140);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 22 ZOMBIE_CATAPULT
    &ZombieInitGargantuar,  // 23 ZOMBIE_GARGANTUAR（共体）
    // 原 case ZOMBIE_IMP
    [](Zombie& z, ZombieInitLocals& lc)
    {
            if (!z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            if (z.mApp->IsIZombieLevel())
            {
                z.mBodyHealth = 70;
            }
            ZombieInitializeTail(z, lc);
    },  // 24 ZOMBIE_IMP
    // 原 case ZOMBIE_BOSS
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mPosX = 0.0f;
            z.mPosY = 0.0f;
            z.mZombieRect = Rect(700, 80, 90, 430);
            z.mZombieAttackRect = Rect(0, 0, 0, 0);
            lc.mRenderLayer = RenderLayer::RENDER_LAYER_TOP;
            z.mBodyHealth = z.mApp->IsAdventureMode() ? 40000 : 60000;
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_enter, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
                z.mSummonCounter = 500;
                z.mBossHeadCounter = 5000;
                z.mZombiePhase = ZombiePhase::PHASE_BOSS_ENTER;
            }
            else
            {
                z.PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            z.BossSetupReanim();
            ZombieInitializeTail(z, lc);
    },  // 25 ZOMBIE_BOSS
    // 原 case ZOMBIE_PEA_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aTrackInstance->mImageOverride = IMAGE_BLANK;
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_PEASHOOTER);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 65.0f, -5.0f, 0.2f, -1.0f, 1.0f);

            z.mPhaseCounter = 150;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 26 ZOMBIE_PEA_HEAD
    // 原 case ZOMBIE_WALLNUT_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_WALLNUT);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 50.0f, 0.0f, 0.2f, -0.8f, 0.8f);

            z.mHelmType = HelmType::HELMTYPE_WALLNUT;
            z.mHelmHealth = 1100;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 27 ZOMBIE_WALLNUT_HEAD
    // 原 case ZOMBIE_JALAPENO_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_JALAPENO);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 55.0f, -5.0f, 0.2f, -1.0f, 1.0f);

            z.mVariant = false;
            z.mBodyHealth = 500;
            int aDistance = 275 + Rand(175);
            z.mPhaseCounter = (int)(aDistance / z.mVelX) * ZOMBIE_LIMP_SPEED_FACTOR;
            ZombieInitializeTail(z, lc);
    },  // 28 ZOMBIE_JALAPENO_HEAD
    // 原 case ZOMBIE_GATLING_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aTrackInstance->mImageOverride = IMAGE_BLANK;
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_GATLINGPEA);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 65.0f, -5.0f, 0.2f, -1.0f, 1.0f);

            z.mPhaseCounter = 150;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 29 ZOMBIE_GATLING_HEAD
    // 原 case ZOMBIE_SQUASH_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aTrackInstance->mImageOverride = IMAGE_BLANK;
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SQUASH);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 55.0f, -15.0f, 0.2f, -0.75f, 0.75f);

            z.mZombiePhase = ZombiePhase::PHASE_SQUASH_PRE_LAUNCH;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 30 ZOMBIE_SQUASH_HEAD
    // 原 case ZOMBIE_TALLNUT_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_TALLNUT);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 37.0f, 0.0f, 0.2f, -0.8f, 0.8f);

            z.mHelmType = HelmType::HELMTYPE_TALLNUT;
            z.mHelmHealth = 2200;
            z.mVariant = false;
            z.mPosX += 30.0f;
            ZombieInitializeTail(z, lc);
    },  // 31 ZOMBIE_TALLNUT_HEAD
    &ZombieInitGargantuar,  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
    // 原 case ZOMBIE_ZOMBATAR
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mHasObject = true;
            z.LoadPlainZombieReanim();

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            Reanimation* aFlagReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FLAG);
            aFlagReanim->PlayReanim(ReanimTrackId::Zombie_flag, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aFlagReanim);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_flaghand);
            AttachReanim(aTrackInstance->mAttachmentID, aFlagReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;

            z.mPosX = WIDE_BOARD_WIDTH;

            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aHeadTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aHeadTrackInstance->mImageOverride = IMAGE_BLANK;

            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_ZOMBATAR_HEAD);
            // zombatar_zombie_head 无 anim_head_idle 轨道：原版此查询必 miss，
            // 靠"查不到回退轨道 0"落到 anim_head1（该定义轨道 0）。回退语义已删
            // 除，这里显式点名等效轨道，行为不变。
            aHeadReanim->PlayReanim(ReanimTrackId::anim_head1, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            aHeadReanim->AssignRenderGroupToTrack(ReanimTrackId::anim_hair, RENDER_GROUP_HIDDEN);

            z.mZombatarHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aHeadTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
    		aBodyReanim->mFrameBasePose = 0; // @Patoke: should &z be aBodyReanim? &z could be a bug in the original code

            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, M(-20.0f), M(-1.0f), M(0.2f), 1.0f, 1.0f);

            z.ResetZombatarHead(z.mApp);

            z.mPhaseCounter = 150;
            z.mVariant = false;

            if (z.mHasZombatar)
            {
    			z.ApplyZombatarHead(z.mApp, &z.mApp->mPlayerInfo->mZombatars[z.mZombatarIndex]);
            }
            ZombieInitializeTail(z, lc);
    },  // 33 ZOMBIE_ZOMBATAR
};
