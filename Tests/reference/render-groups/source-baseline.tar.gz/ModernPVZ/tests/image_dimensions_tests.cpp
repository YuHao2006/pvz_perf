#include "pvz/assets/image_dimensions.hpp"

#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

namespace {

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void test_png()
{
    const std::vector<std::uint8_t> bytes{
        0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A,
        0, 0, 0, 13, 'I', 'H', 'D', 'R',
        0, 0, 4, 44, 0, 0, 2, 88,
    };
    const auto dimensions = pvz::assets::inspect_image_dimensions(bytes);
    require(dimensions.has_value(), "PNG dimensions must be detected");
    require(dimensions->width == 1068 && dimensions->height == 600, "PNG dimensions must be big endian");
    require(dimensions->format == pvz::assets::ImageFormat::png, "PNG format must be reported");
}

void test_gif()
{
    const std::vector<std::uint8_t> bytes{'G', 'I', 'F', '8', '9', 'a', 0x20, 0x03, 0x58, 0x02};
    const auto dimensions = pvz::assets::inspect_image_dimensions(bytes);
    require(dimensions.has_value(), "GIF dimensions must be detected");
    require(dimensions->width == 800 && dimensions->height == 600, "GIF dimensions must be little endian");
}

void test_jpeg()
{
    const std::vector<std::uint8_t> bytes{
        0xFF, 0xD8,
        0xFF, 0xE0, 0x00, 0x04, 0x00, 0x00,
        0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x02, 0x58, 0x04, 0x2C, 0x03, 0x01, 0x11, 0x00,
    };
    const auto dimensions = pvz::assets::inspect_image_dimensions(bytes);
    require(dimensions.has_value(), "JPEG dimensions must be detected");
    require(dimensions->width == 1068 && dimensions->height == 600, "JPEG SOF dimensions must be parsed");
    require(dimensions->format == pvz::assets::ImageFormat::jpeg, "JPEG format must be reported");
}

void test_unknown_data()
{
    const std::vector<std::uint8_t> bytes{1, 2, 3, 4};
    require(!pvz::assets::inspect_image_dimensions(bytes), "unknown data must not be reported as an image");
}

} // namespace

int main()
{
    test_png();
    test_gif();
    test_jpeg();
    test_unknown_data();
    return EXIT_SUCCESS;
}
