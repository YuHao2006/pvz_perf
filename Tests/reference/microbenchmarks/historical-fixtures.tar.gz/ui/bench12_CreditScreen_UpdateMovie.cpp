// bench12 | CreditScreen::UpdateMovie | two rounds: kSunflowerHeadOverride + kCreditsPhaseCases + kWordPhonemeFrames
// FormA = ac447d19^ (pre-first-conversion: phase if-chain + wordType if-chain + sunflower switch)
// FormB = HEAD (phase lambda table + phoneme table + head-override table).
// Discriminants: mCreditsPhase uniform 0..3; mWordType uniform 0..4 (both via stream-driven GetTiming).
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

static const int kN = 2000000;
static uint32_t g_raw[kN];
static int g_pos = 0;
static inline uint32_t NextVal() { uint32_t v = g_raw[g_pos % kN]; g_pos++; return v; }

enum CreditsPhase { CREDITS_MAIN1 = 0, CREDITS_MAIN2 = 1, CREDITS_MAIN3 = 2, CREDITS_END = 3 };
enum CreditWordType { WORD_AA = 0, WORD_EE = 1, WORD_AW = 2, WORD_OH = 3, WORD_OFF = 4 };
enum CreditBrainType { BRAIN_FLY_ON = 0, BRAIN_FAST_ON = 1, BRAIN_NEXT_WORD = 2, BRAIN_FAST_OFF = 3, BRAIN_FLY_OFF = 4, BRAIN_OFF = 5 };
enum ReanimTrackIdC { Words = 1, Words2 = 2, bubbletext1 = 3, bubbletext2 = 4, bubbletext3 = 5, ShakyText = 6, Background2 = 7, anim_idle = 8 };
enum ReanimationTypeC { REANIM_CREDITS_WEARETHEUNDEAD = 1, REANIM_SUNFLOWER = 2, REANIM_CREDITS_STAGE = 3 };
enum RenderLayerC { RENDER_LAYER_TOP = 3 };
enum ParticleEffectC { PARTICLE_CREDIT_STROBE = 1, PARTICLE_CREDITS_RAYSWIPE = 2, PARTICLE_CREDITS_ZOMBIEHEADWIPE = 3, PARTICLE_MELONSPLASH = 4, PARTICLE_CREDITS_FOG = 5, PARTICLE_DOLPHIN = 6 };
enum FoleyTypeC { FOLEY_SCREAM = 1, FOLEY_DOLPHIN_APPEARS = 2 };
namespace Curves { enum C { Linear = 0, EaseInOut = 1, BounceFastMiddle = 2 }; }
const int BOARD_WIDTH = 800, BOARD_HEIGHT = 600;
const float SECONDS_PER_UPDATE = 0.01f;
const int Color_Black = 1, Color_White = 2;

// ---------------- stub types ----------------
struct TransformList { int count; };
struct TrackArray { TransformList mTransforms; };
struct DefTracksHolder { TrackArray* tracks; };
struct ReanimDefinition { DefTracksHolder mTracks; };
static TrackArray g_trackArray{ { 260} };
static ReanimDefinition g_definition{ &g_trackArray };

struct ReanimatorTrackInstance { int mTrackColor; float mShakeOverride; };
static ReanimatorTrackInstance g_trackInst[8];

struct ReanimatorTransform { float mTransX; };

struct ImageC { int id; };
static ImageC g_imgWink{ 1 }, g_imgSing1{ 2 }, g_imgSing2{ 3 }, g_imgSing3{ 4 }, g_imgSing4{ 5 }, g_imgSing5{ 6 };

struct Reanimation {
    ReanimDefinition* mDefinition;
    int mLoopCount;
    float mAnimTime;
    float mAnimRate;
    int mFrameCount;

    void Update() { Mix(200); }
    bool ShouldTriggerTimedEvent(float t) { Mix(201); Mix((uint64_t)(t * 100.0f)); return (NextVal() & 1) != 0; }
    ReanimatorTrackInstance* GetTrackInstanceByName(ReanimTrackIdC t) { Mix(202); Mix(t); return &g_trackInst[t & 7]; }
    int FindTrackIndex(ReanimTrackIdC t) { Mix(203); Mix(t); return (int)t; }
    void GetCurrentTransform(int idx, ReanimatorTransform* out) { Mix(204); out->mTransX = (float)idx * 2.5f; }
    void SetImageOverride(ReanimTrackIdC t, ImageC* img) { Mix(205); Mix(t); Mix(img ? (uint64_t)img->id * 31 : 7); }
};
static Reanimation g_reanim{ &g_definition, 1, 0.5f, 20.0f, 300 };
static Reanimation g_subReanim{ &g_definition, 0, 0.2f, 10.0f, 200 };

struct TodParticleSystem {
    int mEffectType;
    void ParticleSystemDie() { Mix(206); }
    void SystemMove(float x, float y) { Mix(207); Mix((uint64_t)(x * 10 + y)); }
};
static TodParticleSystem g_psys1{ 4 }, g_psys2{ 1 };
struct ParticleList {
    int mIterState;
    bool IterateNext(TodParticleSystem*& out) {
        Mix(208);
        if (mIterState == 0) { out = &g_psys1; mIterState = 1; return true; }
        if (mIterState == 1) { out = &g_psys2; mIterState = 2; return true; }
        return false;
    }
};
struct ParticleHolder { ParticleList mParticleSystems; };
static ParticleHolder g_particleHolder;
struct EffectSystemStub { void Update() { Mix(209); } ParticleHolder* mParticleHolder; };
static EffectSystemStub g_effectSystem{ &g_particleHolder };
struct PoolEffectStub { void PoolEffectUpdate() { Mix(210); } };
static PoolEffectStub g_poolEffect;
struct SoundSystemStub { void StopFoley(FoleyTypeC f) { Mix(211); Mix(f); } };
static SoundSystemStub g_soundSystem;

struct AppStub {
    EffectSystemStub* mEffectSystem;
    PoolEffectStub* mPoolEffect;
    SoundSystemStub* mSoundSystem;
    Reanimation* ReanimationGet(int id) { Mix(212); (void)id; return &g_reanim; }
    void AddTodParticle(int x, int y, int layer, ParticleEffectC e) { Mix(213); Mix((uint64_t)(unsigned)x + (unsigned)y + (unsigned)layer + (unsigned)e); }
    void PlayFoley(FoleyTypeC f) { Mix(214); Mix(f); }
    int ParticleGetID(TodParticleSystem*) { Mix(215); return 77; }
    TodParticleSystem* ParticleTryToGet(int id) { Mix(216); (void)id; return (NextVal() & 1) ? &g_psys1 : nullptr; }
};
static AppStub g_app{ &g_effectSystem, &g_poolEffect, &g_soundSystem };

struct ButtonStub { void SetVisible(bool v) { Mix(217); (void)v; } };
static ButtonStub g_mainMenuButton, g_replayButton;

struct CreditsTiming {
    int mBrainType;
    int mWordType;
    float mWordX;
    float mFrame;
};
static CreditsTiming g_timingBefore, g_timingAfter;
static float g_timingFraction;

struct CreditScreen {
    CreditsPhase mCreditsPhase;
    int mCreditsPhaseCounter;
    int mCreditsReanimID;
    int mFogParticleID;
    bool mDrawBrain;
    float mBrainPosX, mBrainPosY;
    AppStub* mApp;
    ButtonStub* mMainMenuButton;
    ButtonStub* mReplayButton;

    void UpdateBlink() { Mix(218); }
    Reanimation* PlayReanim(int n) { Mix(219); Mix((uint64_t)n); return &g_reanim; }
    void GetTiming(CreditsTiming** before, CreditsTiming** after, float* fraction) {
        Mix(220);
        *before = &g_timingBefore; *after = &g_timingAfter; *fraction = g_timingFraction;
    }
};
static CreditScreen g_screen;
static Reanimation* FindSubReanim(Reanimation* r, ReanimationTypeC t) { Mix(221); Mix(t); (void)r; return &g_subReanim; }
static float TodAnimateCurveFloatTime(float a, float b, float c, float d, float e, Curves::C f) {
    Mix(222); return a + c * (d - e) + (float)f;
}
static void TurnOffTongues(Reanimation* r, int n) { Mix(223); (void)r; (void)n; }

// ================= FormA: ac447d19^ verbatim (phase if-chain / wordType if-chain / sunflower switch) =================
static void UpdateMovieA()
{
    g_screen.UpdateBlink();

    Reanimation* aCreditsReanim = g_screen.mApp->ReanimationGet(g_screen.mCreditsReanimID);
    float aFrameFactor = 1.0f / (aCreditsReanim->mDefinition->mTracks.tracks->mTransforms.count - 1);

    aCreditsReanim->Update();
    g_screen.mApp->mEffectSystem->Update();
    g_screen.mApp->mPoolEffect->PoolEffectUpdate();
    TurnOffTongues(aCreditsReanim, 0);

    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN1 && aCreditsReanim->mLoopCount > 0)
    {
        aCreditsReanim = g_screen.PlayReanim(2);
        g_screen.mCreditsPhase = CreditsPhase::CREDITS_MAIN2;
    }
    else if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 && aCreditsReanim->mLoopCount > 0)
    {
        aCreditsReanim = g_screen.PlayReanim(3);
        g_screen.mCreditsPhase = CreditsPhase::CREDITS_MAIN3;
    }
    else if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mLoopCount > 0)
    {
        g_screen.mCreditsPhase = CreditsPhase::CREDITS_END;
    }
    else if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_END)
    {
        g_screen.mCreditsPhaseCounter++;
        if (g_screen.mCreditsPhaseCounter == 50)
        {
            g_screen.mMainMenuButton->SetVisible(true);
            g_screen.mReplayButton->SetVisible(true);
        }
    }

    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN1)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 128.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 130.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 132.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 134.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 138.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 140.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 142.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.5f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDITS_RAYSWIPE);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 330.0f))
        {
            g_screen.mApp->PlayFoley(FoleyTypeC::FOLEY_SCREAM);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        {
            g_screen.mApp->mSoundSystem->StopFoley(FoleyTypeC::FOLEY_SCREAM);
        }
    }
    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 || g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        ReanimatorTrackInstance* aTrackWords1 = aCreditsReanim->GetTrackInstanceByName(ReanimTrackIdC::Words);
        ReanimatorTrackInstance* aTrackWords2 = aCreditsReanim->GetTrackInstanceByName(ReanimTrackIdC::Words2);
        if (aCreditsReanim->mAnimTime < aFrameFactor * 124.0f)
        {
            aTrackWords1->mTrackColor = Color_Black;
            aTrackWords2->mTrackColor = Color_Black;
        }
        else
        {
            aTrackWords1->mTrackColor = Color_White;
            aTrackWords2->mTrackColor = Color_White;
        }

        Reanimation* aUndeadReanim = FindSubReanim(aCreditsReanim, ReanimationTypeC::REANIM_CREDITS_WEARETHEUNDEAD);
        if (aUndeadReanim)
        {
            ReanimatorTrackInstance* aTrackWordsUndead1 = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::bubbletext1);
            ReanimatorTrackInstance* aTrackWordsUndead2 = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::bubbletext2);
            ReanimatorTrackInstance* aTrackWordsUndead3 = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::bubbletext3);
            aTrackWordsUndead1->mTrackColor = Color_Black;
            aTrackWordsUndead2->mTrackColor = Color_Black;
            aTrackWordsUndead3->mTrackColor = Color_Black;

            ReanimatorTrackInstance* aTrackWordsShake = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::ShakyText);
            if (aCreditsReanim->mAnimTime > aFrameFactor * 112.0f)
            {
                aTrackWordsShake->mShakeOverride = 2.0f;
            }
            else
            {
                aTrackWordsShake->mShakeOverride = 0.0f;
            }
        }

        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 120.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDITS_ZOMBIEHEADWIPE);
        }
    }
    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN2)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 125.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 127.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 131.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 135.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 139.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 143.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 147.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 151.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 155.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 159.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 163.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 167.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 171.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 175.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 179.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 183.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 187.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 191.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 195.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 199.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 203.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 207.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 211.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 215.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.5f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 332.75f))
        {
            g_screen.mApp->AddTodParticle(678, 352, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_MELONSPLASH);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        {
            TodParticleSystem* aParticle = nullptr;
            while (g_screen.mApp->mEffectSystem->mParticleHolder->mParticleSystems.IterateNext(aParticle))
            {
                if (aParticle->mEffectType == ParticleEffectC::PARTICLE_MELONSPLASH)
                {
                    aParticle->ParticleSystemDie();
                }
            }
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 342.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }

        int aBackground2Index = aCreditsReanim->FindTrackIndex(ReanimTrackIdC::Background2);
        ReanimatorTransform aTransformBackground2;
        aCreditsReanim->GetCurrentTransform(aBackground2Index, &aTransformBackground2);

        float aFogPosX = aTransformBackground2.mTransX + 856.0f;
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 188.0f))
        {
            TodParticleSystem* aFogParticle = &g_psys1;  // AddTodParticle returns void in stub; model via ptr
            g_screen.mFogParticleID = g_screen.mApp->ParticleGetID(aFogParticle);
        }
        TodParticleSystem* aFogParticle = g_screen.mApp->ParticleTryToGet(g_screen.mFogParticleID);
        if (aFogParticle)
        {
            if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 248.0f))
            {
                aFogParticle->ParticleSystemDie();
                g_screen.mFogParticleID = 0;
            }
            else
            {
                aFogParticle->SystemMove(aFogPosX, 230.0f);
            }
        }
    }
    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 65.0f))
        {
            g_screen.mApp->PlayFoley(FoleyTypeC::FOLEY_DOLPHIN_APPEARS);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 247.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }
    }

    float aFraction;
    CreditsTiming* aBeforeTiming;
    CreditsTiming* aAfterTiming;
    g_screen.GetTiming(&aBeforeTiming, &aAfterTiming, &aFraction);

    int aSunflowerFrame = 0;
    g_screen.mDrawBrain = false;
    if (aBeforeTiming && aAfterTiming)
    {
        if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, -50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            g_screen.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aAfterTiming->mWordX - 50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 485.0f, 505.0f, Curves::EaseInOut);
            g_screen.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_OFF)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, 850.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            g_screen.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_OFF)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aBeforeTiming->mWordX + 25.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::EaseInOut);
            g_screen.mDrawBrain = true;
        }
        else if (aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_NEXT_WORD)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            g_screen.mDrawBrain = true;
        }

        float aFramesForWord = aAfterTiming->mFrame - aBeforeTiming->mFrame;
        float aFramesTillEnd = (1.0f - aFraction) * aFramesForWord;
        if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesForWord * aFraction < 0.2f)
        {
            aSunflowerFrame = 1;
        }
        else if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesTillEnd < 0.4f)
        {
            aSunflowerFrame = 1;
        }
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_AA)
        {
            aSunflowerFrame = 2;
        }
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_EE)
        {
            aSunflowerFrame = 3;
        }
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_AW)
        {
            aSunflowerFrame = 4;
        }
        else if (aBeforeTiming->mWordType == CreditWordType::WORD_OH)
        {
            aSunflowerFrame = 5;
        }
    }

    Reanimation* aSunFlowerReanim = FindSubReanim(aCreditsReanim, ReanimationTypeC::REANIM_SUNFLOWER);
    if (aSunFlowerReanim)
    {
        if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mAnimTime > aFrameFactor * 255.0f)
        {
            aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgWink);
            Reanimation* aStageReanim = FindSubReanim(aCreditsReanim, ReanimationTypeC::REANIM_CREDITS_STAGE);
            aSunFlowerReanim->mAnimTime -= aSunFlowerReanim->mAnimRate * SECONDS_PER_UPDATE / aSunFlowerReanim->mFrameCount;
            aStageReanim->mAnimTime -= aStageReanim->mAnimRate * SECONDS_PER_UPDATE / aStageReanim->mFrameCount;
        }
        else
        {
            switch (aSunflowerFrame)
            {
            case 1:     aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgSing1);    break;
            case 2:     aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgSing2);    break;
            case 3:     aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgSing3);    break;
            case 4:     aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgSing4);    break;
            case 5:     aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgSing5);    break;
            default:    aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, nullptr);        break;
            }
        }
    }
}

// ================= FormB: HEAD (three tables) =================
namespace {
constexpr ImageC* const kSunflowerHeadOverride[6] = {
    nullptr,
    &g_imgSing1,
    &g_imgSing2,
    &g_imgSing3,
    &g_imgSing4,
    &g_imgSing5,
};
static_assert(sizeof(kSunflowerHeadOverride) / sizeof(kSunflowerHeadOverride[0]) == 6, "head slots");

using CreditsPhaseFn = void (*)(CreditScreen&, Reanimation*&);
constexpr CreditsPhaseFn kCreditsPhaseCases[(int)CreditsPhase::CREDITS_END + 1] = {
    [](CreditScreen& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0)
        {
            aCreditsReanim = s.PlayReanim(2);
            s.mCreditsPhase = CreditsPhase::CREDITS_MAIN2;
        }
    },  // 0 CREDITS_MAIN1
    [](CreditScreen& s, Reanimation*& aCreditsReanim)
    {
        if (aCreditsReanim->mLoopCount > 0)
        {
            aCreditsReanim = s.PlayReanim(3);
            s.mCreditsPhase = CreditsPhase::CREDITS_MAIN3;
        }
    },  // 1 CREDITS_MAIN2
    [](CreditScreen& s, Reanimation*& aCreditsReanim)
    {
        (void)aCreditsReanim;
        if (aCreditsReanim->mLoopCount > 0)
        {
            s.mCreditsPhase = CreditsPhase::CREDITS_END;
        }
    },  // 2 CREDITS_MAIN3
    [](CreditScreen& s, Reanimation*& aCreditsReanim)
    {
        (void)aCreditsReanim;
        s.mCreditsPhaseCounter++;
        if (s.mCreditsPhaseCounter == 50)
        {
            s.mMainMenuButton->SetVisible(true);
            s.mReplayButton->SetVisible(true);
        }
    },  // 3 CREDITS_END
};
static_assert(sizeof(kCreditsPhaseCases) / sizeof(kCreditsPhaseCases[0]) == (int)CreditsPhase::CREDITS_END + 1, "phase slots");

constexpr uint8_t kWordPhonemeFrames[(int)CreditWordType::WORD_OFF + 1] = {
    2,  // 0 WORD_AA
    3,  // 1 WORD_EE
    4,  // 2 WORD_AW
    5,  // 3 WORD_OH
    0,  // 4 WORD_OFF
};
static_assert(sizeof(kWordPhonemeFrames) / sizeof(kWordPhonemeFrames[0]) == (int)CreditWordType::WORD_OFF + 1, "word slots");
}  // namespace

static void UpdateMovieB()
{
    g_screen.UpdateBlink();

    Reanimation* aCreditsReanim = g_screen.mApp->ReanimationGet(g_screen.mCreditsReanimID);
    float aFrameFactor = 1.0f / (aCreditsReanim->mDefinition->mTracks.tracks->mTransforms.count - 1);

    aCreditsReanim->Update();
    g_screen.mApp->mEffectSystem->Update();
    g_screen.mApp->mPoolEffect->PoolEffectUpdate();
    TurnOffTongues(aCreditsReanim, 0);

    const unsigned aPhaseIndex = static_cast<unsigned>(g_screen.mCreditsPhase);
    if (aPhaseIndex <= static_cast<unsigned>(CreditsPhase::CREDITS_END))
    {
        kCreditsPhaseCases[aPhaseIndex](g_screen, aCreditsReanim);
    }

    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN1)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 128.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 130.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 132.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 134.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 138.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 140.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 142.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 136.5f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDITS_RAYSWIPE);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 330.0f))
        {
            g_screen.mApp->PlayFoley(FoleyTypeC::FOLEY_SCREAM);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        {
            g_screen.mApp->mSoundSystem->StopFoley(FoleyTypeC::FOLEY_SCREAM);
        }
    }
    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN2 || g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        ReanimatorTrackInstance* aTrackWords1 = aCreditsReanim->GetTrackInstanceByName(ReanimTrackIdC::Words);
        ReanimatorTrackInstance* aTrackWords2 = aCreditsReanim->GetTrackInstanceByName(ReanimTrackIdC::Words2);
        if (aCreditsReanim->mAnimTime < aFrameFactor * 124.0f)
        {
            aTrackWords1->mTrackColor = Color_Black;
            aTrackWords2->mTrackColor = Color_Black;
        }
        else
        {
            aTrackWords1->mTrackColor = Color_White;
            aTrackWords2->mTrackColor = Color_White;
        }

        Reanimation* aUndeadReanim = FindSubReanim(aCreditsReanim, ReanimationTypeC::REANIM_CREDITS_WEARETHEUNDEAD);
        if (aUndeadReanim)
        {
            ReanimatorTrackInstance* aTrackWordsUndead1 = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::bubbletext1);
            ReanimatorTrackInstance* aTrackWordsUndead2 = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::bubbletext2);
            ReanimatorTrackInstance* aTrackWordsUndead3 = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::bubbletext3);
            aTrackWordsUndead1->mTrackColor = Color_Black;
            aTrackWordsUndead2->mTrackColor = Color_Black;
            aTrackWordsUndead3->mTrackColor = Color_Black;

            ReanimatorTrackInstance* aTrackWordsShake = aUndeadReanim->GetTrackInstanceByName(ReanimTrackIdC::ShakyText);
            if (aCreditsReanim->mAnimTime > aFrameFactor * 112.0f)
            {
                aTrackWordsShake->mShakeOverride = 2.0f;
            }
            else
            {
                aTrackWordsShake->mShakeOverride = 0.0f;
            }
        }

        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 120.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDITS_ZOMBIEHEADWIPE);
        }
    }
    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN2)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 125.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 127.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 131.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 135.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 139.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 143.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 147.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 151.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 155.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 159.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 163.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 167.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 171.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 175.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 179.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 183.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 187.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 191.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 195.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 199.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 203.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 207.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 211.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 215.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.5f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.5f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 332.75f))
        {
            g_screen.mApp->AddTodParticle(678, 352, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_MELONSPLASH);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 336.0f))
        {
            TodParticleSystem* aParticle = nullptr;
            while (g_screen.mApp->mEffectSystem->mParticleHolder->mParticleSystems.IterateNext(aParticle))
            {
                if (aParticle->mEffectType == ParticleEffectC::PARTICLE_MELONSPLASH)
                {
                    aParticle->ParticleSystemDie();
                }
            }
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 342.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }

        int aBackground2Index = aCreditsReanim->FindTrackIndex(ReanimTrackIdC::Background2);
        ReanimatorTransform aTransformBackground2;
        aCreditsReanim->GetCurrentTransform(aBackground2Index, &aTransformBackground2);

        float aFogPosX = aTransformBackground2.mTransX + 856.0f;
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 188.0f))
        {
            TodParticleSystem* aFogParticle = &g_psys1;
            g_screen.mFogParticleID = g_screen.mApp->ParticleGetID(aFogParticle);
        }
        TodParticleSystem* aFogParticle = g_screen.mApp->ParticleTryToGet(g_screen.mFogParticleID);
        if (aFogParticle)
        {
            if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 248.0f))
            {
                aFogParticle->ParticleSystemDie();
                g_screen.mFogParticleID = 0;
            }
            else
            {
                aFogParticle->SystemMove(aFogPosX, 230.0f);
            }
        }
    }
    if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3)
    {
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 65.0f))
        {
            g_screen.mApp->PlayFoley(FoleyTypeC::FOLEY_DOLPHIN_APPEARS);
        }
        if (aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 111.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 115.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 119.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 121.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 123.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 219.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 223.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 227.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 231.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 235.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 239.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 243.0f) ||
            aCreditsReanim->ShouldTriggerTimedEvent(aFrameFactor * 247.0f))
        {
            g_screen.mApp->AddTodParticle(BOARD_WIDTH / 2, BOARD_HEIGHT / 2, (int)RenderLayerC::RENDER_LAYER_TOP, ParticleEffectC::PARTICLE_CREDIT_STROBE);
        }
    }

    float aFraction;
    CreditsTiming* aBeforeTiming;
    CreditsTiming* aAfterTiming;
    g_screen.GetTiming(&aBeforeTiming, &aAfterTiming, &aFraction);

    int aSunflowerFrame = 0;
    g_screen.mDrawBrain = false;
    if (aBeforeTiming && aAfterTiming)
    {
        if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, -50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            g_screen.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aAfterTiming->mWordX - 50.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 485.0f, 505.0f, Curves::EaseInOut);
            g_screen.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FLY_OFF)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, 850.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            g_screen.mDrawBrain = true;
        }
        else if (aAfterTiming->mBrainType == CreditBrainType::BRAIN_FAST_OFF)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aBeforeTiming->mWordX + 25.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::EaseInOut);
            g_screen.mDrawBrain = true;
        }
        else if (aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FLY_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_FAST_ON || aBeforeTiming->mBrainType == CreditBrainType::BRAIN_NEXT_WORD)
        {
            g_screen.mBrainPosX = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, aBeforeTiming->mWordX - 15.0f, aAfterTiming->mWordX - 15.0f, Curves::EaseInOut);
            g_screen.mBrainPosY = TodAnimateCurveFloatTime(0.0f, 1.0f, aFraction, 505.0f, 485.0f, Curves::BounceFastMiddle);
            g_screen.mDrawBrain = true;
        }

        float aFramesForWord = aAfterTiming->mFrame - aBeforeTiming->mFrame;
        float aFramesTillEnd = (1.0f - aFraction) * aFramesForWord;

        if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesForWord * aFraction < 0.2f)
        {
            aSunflowerFrame = 1;
        }
        else if (aBeforeTiming->mWordType != CreditWordType::WORD_OFF && aFramesTillEnd < 0.4f)
        {
            aSunflowerFrame = 1;
        }
        else if ((unsigned)aBeforeTiming->mWordType <= (unsigned)CreditWordType::WORD_OFF)
        {
            aSunflowerFrame = kWordPhonemeFrames[(int)aBeforeTiming->mWordType];
        }
    }

    Reanimation* aSunFlowerReanim = FindSubReanim(aCreditsReanim, ReanimationTypeC::REANIM_SUNFLOWER);
    if (aSunFlowerReanim)
    {
        if (g_screen.mCreditsPhase == CreditsPhase::CREDITS_MAIN3 && aCreditsReanim->mAnimTime > aFrameFactor * 255.0f)
        {
            aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, &g_imgWink);
            Reanimation* aStageReanim = FindSubReanim(aCreditsReanim, ReanimationTypeC::REANIM_CREDITS_STAGE);
            aSunFlowerReanim->mAnimTime -= aSunFlowerReanim->mAnimRate * SECONDS_PER_UPDATE / aSunFlowerReanim->mFrameCount;
            aStageReanim->mAnimTime -= aStageReanim->mAnimRate * SECONDS_PER_UPDATE / aStageReanim->mFrameCount;
        }
        else
        {
            ImageC* aHeadOverride = static_cast<unsigned>(aSunflowerFrame) < static_cast<unsigned>(6) &&
                    kSunflowerHeadOverride[aSunflowerFrame] != nullptr
                ? kSunflowerHeadOverride[aSunflowerFrame]
                : nullptr;
            aSunFlowerReanim->SetImageOverride(ReanimTrackIdC::anim_idle, aHeadOverride);
        }
    }
}

// ---------------- harness ----------------
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    uint32_t v = g_raw[i];
    g_screen.mCreditsPhase = (CreditsPhase)(v % 4);
    g_screen.mCreditsPhaseCounter = 49;
    g_screen.mCreditsReanimID = 5;
    g_screen.mFogParticleID = 77;
    g_screen.mDrawBrain = false;
    g_screen.mBrainPosX = 0.0f; g_screen.mBrainPosY = 0.0f;
    g_screen.mApp = &g_app;
    g_screen.mMainMenuButton = &g_mainMenuButton;
    g_screen.mReplayButton = &g_replayButton;
    g_reanim.mLoopCount = (int)((v >> 3) & 1);
    g_reanim.mAnimTime = ((v >> 4) & 1) ? 3.0f : 0.5f;
    g_reanim.mAnimRate = 20.0f;
    g_reanim.mFrameCount = 300;
    g_subReanim.mAnimTime = 0.2f;
    g_subReanim.mAnimRate = 10.0f;
    g_subReanim.mFrameCount = 200;
    g_timingBefore.mBrainType = (int)((v >> 5) % 6);
    g_timingBefore.mWordType = (int)((v >> 7) % 5);
    g_timingBefore.mWordX = 100.0f + (v % 50);
    g_timingBefore.mFrame = 10.0f;
    g_timingAfter.mBrainType = (int)((v >> 9) % 6);
    g_timingAfter.mWordType = (int)((v >> 11) % 5);
    g_timingAfter.mWordX = 200.0f + (v % 60);
    g_timingAfter.mFrame = ((v >> 13) & 1) ? 30.0f : 10.05f;  // word windows sometimes hit timing arms
    g_timingFraction = (float)((v % 100) / 100.0);
    for (int k = 0; k < 8; k++) { g_trackInst[k].mTrackColor = 0; g_trackInst[k].mShakeOverride = 0.0f; }
    g_particleHolder.mParticleSystems.mIterState = 0;
    g_psys1.mEffectType = 4; g_psys2.mEffectType = 1;
    g_pos = 0;
}

static inline void MixOutputs()
{
    Mix(g_screen.mCreditsPhase); Mix(g_screen.mCreditsPhaseCounter); Mix(g_screen.mFogParticleID);
    Mix(g_screen.mDrawBrain); Mix((uint64_t)(g_screen.mBrainPosX * 100)); Mix((uint64_t)(g_screen.mBrainPosY * 100));
    Mix((uint64_t)(g_reanim.mAnimTime * 1000)); Mix((uint64_t)(g_subReanim.mAnimTime * 1000));
    for (int k = 0; k < 8; k++) { Mix(g_trackInst[k].mTrackColor); Mix((uint64_t)(g_trackInst[k].mShakeOverride * 100)); }
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); UpdateMovieA(); MixOutputs(); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum; g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); UpdateMovieB(); MixOutputs(); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("CreditScreen::UpdateMovie | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
