
undefined * FUN_0054c560(int param_1)

{
  int iVar1;
  undefined *puVar2;
  
  if ((DAT_007dc660 & 1) == 0) {
    DAT_007dc660 = DAT_007dc660 | 1;
    FUN_00561490();
  }
  iVar1 = FUN_00432890();
  if (param_1 < iVar1) {
    puVar2 = (undefined *)FUN_00432870();
  }
  else {
    puVar2 = &DAT_007dc650;
  }
  return puVar2;
}

