
void __thiscall FUN_00549930(int *param_1,uint *param_2)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  uint local_60;
  uint local_5c;
  undefined1 local_34 [4];
  int local_30;
  undefined1 local_2c [8];
  int *local_24;
  uint *local_20;
  uint local_1c;
  uint local_18;
  int local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_006bd458;
  local_10 = ExceptionList;
  uVar3 = DAT_00717ee4 ^ (uint)&stack0xfffffffc;
  ExceptionList = &local_10;
  local_20 = param_2;
  local_1c = *param_2;
  local_18 = param_2[1];
  *param_2 = (*param_2 | param_1[0x15]) & ~param_1[0x16];
  param_2[1] = (param_2[1] | param_1[0x15]) & ~param_1[0x16];
  local_8 = 0;
  if ((char)param_2[2] == '\0') {
    local_5c = param_2[1];
  }
  else {
    local_5c = *param_2;
  }
  if ((local_5c & 2) != 0) {
    (**(code **)(*param_1 + 0x44))(uVar3);
  }
  local_14 = param_1[8];
  if (local_14 == 0) {
    *local_20 = local_1c;
    local_20[1] = local_18;
  }
  else {
    if ((char)param_2[2] == '\0') {
      local_60 = param_2[1];
    }
    else {
      local_60 = *param_2;
    }
    if (((local_60 & 1) != 0) && (param_1[0xd] != *(int *)(param_1[8] + 0x38))) {
      param_1[0xd] = *(int *)(param_1[8] + 0x38);
      (**(code **)(*param_1 + 0x58))();
    }
    piVar4 = (int *)FUN_005b75d0(local_2c);
    iVar1 = piVar4[1];
    param_1[0xb] = *piVar4;
    param_1[0xc] = iVar1;
    while( true ) {
      iVar1 = param_1[6];
      FUN_00420ae0();
      local_30 = iVar1;
      if (param_1 == (int *)0xfffffffc) {
        FUN_0069a6f2();
      }
      FUN_0040a150();
      cVar2 = FUN_006143c0(local_34);
      if (cVar2 != '\0') break;
      *(undefined1 *)(param_1 + 10) = 0;
      local_24 = (int *)FUN_005e2150();
      local_24 = (int *)*local_24;
      if (local_24 == *(int **)(local_14 + 0xac)) {
        *(undefined1 *)(param_2 + 2) = 1;
      }
      (**(code **)(*local_24 + 0x5c))(param_2);
      if ((char)param_1[10] == '\0') {
        FUN_00614350();
      }
    }
    *(undefined1 *)(param_1 + 10) = 1;
    *local_20 = local_1c;
    local_20[1] = local_18;
  }
  ExceptionList = local_10;
  return;
}

