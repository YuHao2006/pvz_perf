# PAK64 生成语义审计（Legacy / PvZ 1073）

审计日期：2026-08-22

这份报告审计的是“转换出来的 `pak64` 是否表达了官方 1073 加载器的定义”，而
不是只检查文件能否被程序打开。审计对象是官方英文年度版 1.2.0.1073 的
`main.pak`，目标包是：

`C:\Users\Administrator\CLionProjects\codex\PlantsVsZombies\out\legacy-msvc2\Release\main.pak64`

官方 x64 compiled 参照目录是：

`C:\Users\Administrator\CLionProjects\codex\pak64\compiled64-v1`

## 结论

正式包结果：

| 检查项 | 结果 |
|---|---:|
| 官方 oracle 定义 | 251 |
| 与 oracle 同名的定义 | 251 |
| oracle 逐字段/逐位语义不一致 | 0 |
| 包内 compiled 定义 | 259 |
| compiled 结构错误 | 0 |
| ZIP 条目 | 3203 |
| ZIP 加密条目 | 0 |
| ZIP 压缩条目 | 0 |
| 重复（不区分大小写）路径 | 0 |

251 条有官方 x64 参照的定义已经逐字段一致；另外 8 条没有官方 compiled 参照的
XML 定义也通过了 schema、长度、深层数据消费和路径对应检查。它们不能声称与官方
字节相同，但不会以损坏的 x64 布局进入包。

当前正式包 SHA-256：

`E8287F5E85749F28AC46BD21295ADB256FCEF09B6FD404765AC421E5C3F75641`

## 权威边界

本审计以 1073 年度版为第一权威。Steam 1096 的额外成就和存档布局不参与本次定义
生成审计。`compiled64-v1` 只作为“官方 1073 定义在 x64 上实际如何序列化”的
oracle，不把 32 位指针值拿来比较。

## PAK64 容器语义

`pak64` 是普通 ZIP 容器，所有条目都使用 Stored（不压缩）方式，没有 XOR、密码或
其它加密，也不携带 1073 的 `cached` 音频目录。把后缀改成 `.zip` 后可以直接解压。
Legacy 运行时只挂载这个 ZIP；compiled 读取失败时不会回退 XML，也不会偷偷生成
32 位缓存。

每个新的定义记录使用：

```text
u32 cookie       = 0xDEADFED5
u32 payloadSize
byte[payloadSize] raw x64 definition
```

raw 的第一个 `u32` 是 DefMap schema hash，随后是 native x64 的浅层结构和
`DefMapWriteToCache` 顺序写出的深层数据。旧 1073 的 `0xDEADFED4 + zlib` 只在
离线转换输入时读取，不会写回 PAK64。

## 官方 DefMap 字段顺序

### Reanim

`gReanimatorDefMap` 顺序：

1. `track` 数组
2. `fps`

每个 track：

1. `name`
2. `t` 数组

每个 transform 的字段顺序：

`x, y, kx, ky, sx, sy, f, a, i, font, text`

前八个是语义浮点值（32 字节）；x64 浅层 transform 总大小为 56 字节。深层顺序为：

```text
image-id, font-id, text
```

缺少数值字段时，官方构造函数使用 `-10000.0f` 占位；缺少 `i/font/text` 时使用
空值。审计器比较八个浮点的原始 IEEE-754 位，而不是比较格式化后的十进制文本。

### Particle

`TodParticleDefinition` 是 `Emitter` 数组；x64 emitter 浅层元素为 688 字节。其
DefMap 顺序为：

```text
Image, ImageRow, ImageCol, ImageFrames, Animated,
ParticleFlags, EmitterType, Name,
SystemDuration, OnDuration, CrossFadeDuration, SpawnRate,
SpawnMinActive, SpawnMaxActive, SpawnMaxLaunched, EmitterRadius,
EmitterOffsetX, EmitterOffsetY, EmitterBoxX, EmitterBoxY,
EmitterPath, EmitterSkewX, EmitterSkewY, ParticleDuration,
SystemRed, SystemGreen, SystemBlue, SystemAlpha, SystemBrightness,
LaunchSpeed, LaunchAngle, Field, SystemField,
ParticleRed, ParticleGreen, ParticleBlue, ParticleAlpha,
ParticleBrightness, ParticleSpinAngle, ParticleSpinSpeed, ParticleScale,
ParticleStretch, CollisionReflect, CollisionSpin, ClipTop, ClipBottom,
ClipLeft, ClipRight, AnimationRate
```

`Field` 和 `SystemField` 的元素顺序是 `FieldType, x, y`，x64 原生元素为 40 字节。
数组深层数据先写元素大小和浅层数组，再按元素顺序写类型、x 轨道、y 轨道。

粒子 flag 不是“出现标签就为真”：官方读取 `%f`，再转换为 `int`，非零设置对应位，
零清除对应位。因此 `RandomLaunchSpin=0` 必须清除位。`<ParticleFlags>` 不是可
直接写入的位掩码；官方只接受各个 flag symbol（例如 `<Additive>1</Additive>`）。

### Trail

`gTrailDefMap` 顺序：

```text
Image, MaxPoints, MinPointDistance, TrailFlags,
WidthOverLength, WidthOverTime, AlphaOverLength, AlphaOverTime,
TrailDuration
```

之前转换器把 `TrailDuration` 放在轨道开头，导致 `IceTrail` 深层数据错位；现在已按
上面的顺序写入。`TrailFlags` 的合法 symbol 是 `Loops`。

## Float track 的官方规则

官方反编译函数为 `DefinitionReadFloatTrackField`。转换器遵循以下规则：

- 相邻数字是相邻节点，例如 `0 740` 是两个值，不是“曲线名 740”；只有后续 token
  真的是官方曲线名时才消费曲线。
- 显式时间是百分数：先读为 `float`，再执行 `float * 0.01` 的 double literal
  提升，最后存回 float。使用 `0.01f` 会产生可观察的位级差异。
- 未指定时间的节点按官方区间规则补齐：

  ```text
  high * interp + low * (1 - interp)
  ```

  第一段单节点时间为 0，后续区间单节点时间为区间末端。
- 范围语法保留官方解析器的实际行为。原文件中的 `[.3.8]` 会跳过第二个点并把高值
  读成 `8`，不会被猜成 `0.8`。
- 曲线名匹配遵循官方 `strncmp` 的大小写敏感行为；字段名和枚举名仍遵循官方的不
  区分大小写查找。
- XMLParser 的命名实体和空白折叠已复现：例如 `&amp;` 变成 `&`，连续空白变成一个
  空格，首尾格式空白被丢弃。

## 本轮发现并修复的语义偏差

1. **数字被误判成曲线名**：修复 `SodRoll` 的 `SystemPosition`，避免草卷粒子停在
   小推车附近。
2. **隐式时间算法错误**：修复 `ScreenFlash` 的衰减，避免 Intro 白屏保持过亮。
3. **float/double 提升顺序错误**：改为官方的 `* 0.01`。
4. **范围特殊语法错误**：保留 `[.3.8]` 的官方实际解析结果。
5. **flag=0 被错误当成 true**：现在先转 `int` 再测试，和官方一致。
6. **Trail 深层顺序错误**：修复 `IceTrail` 的五条轨道顺序。
7. **XML 实体、空白未复现**：修复 Credits 文本（例如 `Music & Sound`）。
8. **资源标识大小写不一致**：对 `IMAGE_`/`FONT_` ID 使用 manifest 约定的大写形式。
9. **旧 compiled 残留**：源权威转换前先移除旧的 `compiled/reanim` 和
   `compiled/particles`，再为当前 XML 全量生成，避免删除 XML 后仍携带旧定义。
10. **错误输入静默默认**：未知字段、未知枚举、坏数字、显式空轨道现在令转换失败，
    不再静默写入构造函数默认值。缺失字段仍保留官方构造函数默认值。

## 审计器检查内容

脚本：[tools/audit_pak64_semantics.py](../tools/audit_pak64_semantics.py)

它会：

- 解开旧 `0xDEADFED4 + zlib` oracle 和新 `0xDEADFED5 + raw` 记录；
- 比较 schema hash、浅层数组数量/元素大小、native scalar、轨道节点的原始
  float/int 位、字符串和字段顺序；
- 对 251 条 oracle 记录逐一比较；
- 检查包内每个 compiled 的 cookie、声明长度、schema hash 和深层 payload 是否被完整
  消费；
- 检查 XML 定义与 compiled 是否一一对应、是否有重复路径、加密/压缩条目、旧
  `cached` 目录或路径穿越。

运行：

```powershell
python C:\Users\Administrator\CLionProjects\codex\PlantsVsZombies\tools\audit_pak64_semantics.py `
  C:\Users\Administrator\CLionProjects\codex\PlantsVsZombies\out\legacy-msvc2\Release\main.pak64
```

最后一次输出：

```text
oracle records: 251
common records: 251
package compiled records: 259
mismatches: 0
structural errors: 0
```

## 8 条没有 oracle 的 XML 定义

1073 XML 有 146 条 Reanim 和 113 条 Particle/Trail，共 259 条；官方 x64 oracle 只有
251 条。差出的 8 条是编辑器、调试或遗留定义：

```text
particles/ArtChallengePlant.xml
particles/CircleEvenSpacing.xml
particles/KernelSplat.xml
particles/PerfTest.xml
particles/SeedPacketPickup.xml
particles/SimpleParticle.xml
reanim/Zombie_dancer.reanim
reanim/Zombie_Jackson.reanim
```

完整转换器会生成它们，因为改版作者可能主动调用；Legacy 正式包也保留完整 XML 和
compiled，避免错误删除共享依赖。它们通过结构/ABI 审计，但不属于“官方逐位 oracle
通过”的 251 条。

## 审计边界与后续门槛

- 指针字段不参与字节比较：地址由进程、ASLR 和分配顺序决定，不是定义语义。其余
  native scalar、数组计数、元素大小、轨道位和深层字符串均参与比较。
- 资源图片的最终解析仍遵循 Legacy 运行时的 `ResourceManager` 加载和 1073 的
  `gDefLoadResPaths` 回退路径；审计不把“指针地址”误当成资源内容差异。
- 未来若修改 DefMap、x64 结构或 XML 编译器，必须重新运行脚本；任何
  `mismatches > 0` 或 `structural errors > 0` 都不能发布包。
- 转换器 Release 链接目前仍有既有 zlib CRT 混用警告（LNK4098）。它没有改变本次
  已生成的定义字节，但在发布转换器本身前应单独重建统一 CRT 的 zlib，并把警告降为
  零；这是工具链可靠性门槛，不应被“游戏能启动”掩盖。
