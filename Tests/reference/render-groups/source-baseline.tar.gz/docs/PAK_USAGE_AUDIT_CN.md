# PAK64 资源调用与懒构建审计

审计基准是官方 1073 的代码路径与 `main.pak`，不是仅凭文件名猜测。

## 1. 定义文件的调用关系

Legacy 在 `_WIN64` 下调用 `DefinitionCompileAndLoad` 时只读取
`compiled\...`。compiled 打开失败、ABI 校验失败或深层资源失败都会立即报错退出，
不再读取 XML，也不再创建 `data\compiled64-v1` 回退缓存。

因此，以下原始定义虽然随完整包保留，但只用于改版/审计，不是正常启动路径：

- `reanim\*.reanim`：146 个；
- `particles\*.xml` / `particles\*.trail`：113 个。

通用转换包和当前 Legacy Release 都保留这些源定义，方便改版作者继续修改和审计；
正式运行路径只使用同包内的 x64 compiled。转换器不提供 slim 模式，任何精简必须在
生成完整包并通过依赖检查后单独进行。

当前已经完成一次独立精简并固定保存于：

`C:\Users\Administrator\CLionProjects\codex\PlantsVsZombies\distribution\legacy1073-slim\legacy1073-slim.pak64`

该快照不是转换器的默认输出；它由 `tools/build_legacy_slim_pak64.py` 从完整包裁剪，
并通过 `audit_pak64_semantics.py --trimmed`。它保留 251 条官方 compiled，删除 8 条
未调用定义和全部源定义，同时保留被 `Zombie_disco` 共享的
`reanim\zombie_dancer__head.png`。

## 2. 1051/1073 中容易混淆的 8 个定义

这里的“8 个”是资源审计里最容易被混在一起的八项，不代表八项都未使用。
1051 的 `main.pak` 实际只有 `Award.xml.compiled`、`Zombie_dancer` 和
`Zombie_Jackson` 的 compiled；1073 则有 `Award.xml.compiled`、正式的
`Zombie_disco.reanim.compiled`，同时保留若干旧 XML。逐项结论如下：

| XML | 证据 |
|---|---|
| `particles/Award.xml` | **实际使用**。`TodParticle.cpp` 把 `PARTICLE_SEED_PACKET_PICKUP` 映射到它；`Lawn/Coin.cpp` 在获得种子包且开启 3D 时创建该粒子。 |
| `particles/SeedPacketPickup.xml` | 没有 `ParticleEffect` 路径；官方使用的是 `Award.xml`，不是这个同名 XML。 |
| `particles/ArtChallengePlant.xml` | `gLawnParticleArray` 没有该路径，未发现直接加载。 |
| `particles/CircleEvenSpacing.xml` | 只作为 `EmitterType` 枚举值，不是独立粒子定义。 |
| `particles/KernelSplat.xml` | 没有 `ParticleEffect` 或直接加载调用。 |
| `particles/PerfTest.xml` | Almanac 的性能测试创建僵尸数组，不加载这个粒子定义。 |
| `particles/SimpleParticle.xml` | 没有粒子参数表或直接加载调用。 |
| `reanim/Zombie_dancer.reanim` / `reanim/Zombie_Jackson.reanim` | 1051 包含它们的正式 compiled；1073 保留旧 XML，但当前 Legacy 的 `REANIM_DANCER` 使用 `reanim/Zombie_disco.reanim`，没有走这两个旧 XML。 |

因此，真正“没有调用”的是 `SeedPacketPickup` 加上另外五个粒子 XML；
`Award.xml` 不能从通用转换结果删除。通用转换器按 XML 生成全部 259 个 compiled，
因为改版可能新增调用；当前发行包暂不删除这 8 项，避免把共享资源误判为遗留资源。

## 3. ReanimAtlas 的懒构建

`ReanimationCreateAtlas` 只在定义第一次使用且没有 `REANIM_NO_ATLAS` 标志时调用
`ReanimAtlas::ReanimAtlasCreate`。从 `Reanimator.cpp` 的 144 个正式定义中：

- 104 个启用图集，可能在第一次进入对应植物、僵尸、金币、关卡过场或特效时懒构建；
- 40 个显式禁用图集，直接使用原图或特殊绘制路径；
- 104 个图集定义引用 1178 个不同的 `IMAGE_REANIM_*` 名称；
- 1-1 草卷 `SodRoll` 图集引用 `IMAGE_REANIM_SODROLL` 和
  `IMAGE_REANIM_SODROLLCAP`。

此外还有两个相关的懒操作：

- `TodSandImageIfNeeded`：首次绘制前修复透明边缘像素；
- D3D11 `TextureData::CheckCreateTextures`：首次真正绘制时创建 GPU 纹理。

所以不能把“首次进入页面卡顿”简单归因于单个 PNG。安全做法是保留 Reanim 源图
CPU 像素直到图集创建完成；普通静态资源仍可在上传后 purge。

本次只增加一个可验证的懒构建观测点：`ReanimationCreateAtlas` 现在写入
`build-reanim-atlas` 事件。第一次让 1-1 的卷草（`SodRoll.reanim`）出现时，
日志会记录 `file=reanim\\SodRoll.reanim`、tick、关卡和耗时；同一进程后续再
画卷草不会重复构建。这一次测试足以证明“定义已加载”和“Atlas 首次构建”是两
个不同阶段，不需要把所有关卡都跑一遍。

启用一次性 CSV 观察的方法（更新后的 Legacy 重启后执行）：

```powershell
$env:PVZ_RUNTIME_TRACE = "$PWD\data\lazy-atlas.csv"
& "$PWD\out\legacy-msvc2\Release\SexyAppFramework.exe"
```

进入 1-1，等卷草滚完后正常退出，再查看 `data\lazy-atlas.csv` 中的
`build-reanim-atlas` 行即可。若不设置 `PVZ_RUNTIME_TRACE`，不会产生这类日志。

## 4. 当前不建议直接删除的资源

上述 8 个只在本项目精简 Release 中删除定义源和 compiled；不能据此直接删除其
PNG。除此之外，也不能直接删除 PNG、字体、音效或 OGG：资源清单、Reanim 深层字段、粒子图片字段、Zombatar
部件和音乐表都存在间接引用。后续若要继续瘦身，应先记录一次完整冷启动的
`p_fopen`/资源命中集合，再以运行时命中集合反向生成裁剪包。
