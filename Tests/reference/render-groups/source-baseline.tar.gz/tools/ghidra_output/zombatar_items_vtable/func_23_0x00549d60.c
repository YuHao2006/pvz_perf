
void __thiscall FUN_00549d60(int *param_1,uint *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  uint local_d8;
  uint local_d4;
  uint local_d0;
  undefined1 local_a8 [4];
  int local_a4;
  undefined1 local_a0 [120];
  int *local_28;
  uint *local_24;
  uint local_20;
  uint local_1c;
  undefined1 local_18 [8];
  void *local_10;
  undefined1 *puStack_c;
  int local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_006bfcc3;
  local_10 = ExceptionList;
  uVar3 = DAT_00717ee4 ^ (uint)&stack0xfffffffc;
  ExceptionList = &local_10;
  if (*(int *)(param_1[8] + 0x98) < param_1[0x17]) {
    FUN_0054a670(param_1[0x17]);
  }
  local_24 = param_2;
  local_20 = *param_2;
  local_1c = param_2[1];
  *param_2 = (*param_2 | param_1[0x15]) & ~param_1[0x16];
  param_2[1] = (param_2[1] | param_1[0x15]) & ~param_1[0x16];
  local_8 = 0;
  if (*(char *)((int)param_1 + 0x51) != '\0') {
    if ((char)param_2[2] == '\0') {
      local_d0 = param_2[1];
    }
    else {
      local_d0 = *param_2;
    }
    if ((local_d0 & 8) != 0) {
      FUN_005994c0(0,0,param_1[0x12],param_1[0x13]);
    }
  }
  if (param_1[7] == 0) {
    if ((char)param_2[2] == '\0') {
      local_d4 = param_2[1];
    }
    else {
      local_d4 = *param_2;
    }
    if ((local_d4 & 4) != 0) {
      (**(code **)(*param_1 + 0x68))(param_3);
    }
    *local_24 = local_20;
    local_24[1] = local_1c;
  }
  else {
    if ((char)param_2[2] == '\0') {
      local_d8 = param_2[1];
    }
    else {
      local_d8 = *param_2;
    }
    if ((local_d8 & 4) != 0) {
      FUN_005981d0(uVar3);
      (**(code **)(*param_1 + 0x68))(param_3);
      FUN_00598250();
    }
    FUN_005b75d0(local_18);
    while( true ) {
      iVar1 = param_1[6];
      FUN_00420ae0();
      local_a4 = iVar1;
      if (param_1 == (int *)0xfffffffc) {
        FUN_0069a6f2();
      }
      FUN_0040a150();
      cVar2 = FUN_006143c0(local_a8);
      if (cVar2 != '\0') break;
      local_28 = (int *)FUN_005e2150();
      local_28 = (int *)*local_28;
      if ((char)local_28[0x19] != '\0') {
        if (local_28 == *(int **)(param_1[8] + 0xac)) {
          *(undefined1 *)(param_2 + 2) = 1;
        }
        FUN_00597fa0(param_3);
        local_8._0_1_ = 1;
        FUN_00599570(local_28[0x10],local_28[0x11]);
        (**(code **)(*local_28 + 0x6c))(param_2,local_a0);
        *(undefined1 *)(local_28 + 0xf) = 0;
        local_8 = (uint)local_8._1_3_ << 8;
        FUN_005981a0();
      }
      FUN_00614350();
    }
    *local_24 = local_20;
    local_24[1] = local_1c;
  }
  ExceptionList = local_10;
  return;
}

