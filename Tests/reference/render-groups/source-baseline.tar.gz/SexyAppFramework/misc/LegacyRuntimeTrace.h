#ifndef __LEGACYRUNTIMETRACE_H__
#define __LEGACYRUNTIMETRACE_H__

#include <cstdint>

namespace Sexy
{

bool LegacyRuntimeTraceEnabled();
std::uint64_t LegacyRuntimeTraceNowMicroseconds();
void LegacyRuntimeTraceInstant(const char* theEvent, int theUpdateCount, const char* theFormat = nullptr, ...);
void LegacyRuntimeTraceDuration(
	const char* theEvent,
	int theUpdateCount,
	std::uint64_t theStartMicroseconds,
	std::uint64_t theEndMicroseconds);

class LegacyRuntimeTraceScope
{
public:
	LegacyRuntimeTraceScope(const char* theEvent, int theUpdateCount);
	~LegacyRuntimeTraceScope();

private:
	const char*		mEvent;
	int				mUpdateCount;
	std::uint64_t	mStartMicroseconds;
};

}

#endif
