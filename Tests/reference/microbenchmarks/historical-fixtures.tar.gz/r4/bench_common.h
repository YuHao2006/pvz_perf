// bench_common.h - r4：static 形态确认对拍（早期裸 constexpr 表时代的 PERF 数字复测）
// 铁律：仅存在于 _shared/bench35/r4，不触碰游戏仓库。
// 口径同 ifelse 轮：FormA = 表引入提交的父版链形（逐字），FormB = 当前 HEAD（表带 static），
// noinline 两侧一致，2M 均匀固定种子同数组，QPC min-of-5，进程两遍。
#pragma once
#ifndef _WIN32_LEAN_AND_MEAN
#define _WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>

// ---------------- 计时 ----------------
static double NowSec()
{
    LARGE_INTEGER c, f;
    QueryPerformanceCounter(&c);
    QueryPerformanceFrequency(&f);
    return (double)c.QuadPart / (double)f.QuadPart;
}

// ---------------- checksum ----------------
static uint64_t gChecksum = 0;
static inline void Mix(uint64_t v) { gChecksum = gChecksum * 1099511628211ULL + v; }
static inline void MixF(float f) { uint32_t u; memcpy(&u, &f, 4); Mix(u); }
static inline void MixI(int v) { Mix((uint64_t)(int64_t)v); }

#define TOD_ASSERT(x) ((void)0)

// ---------------- 输入 ----------------
static const int kN = 2000000;
static uint32_t gInput[kN];
static void GenInput()
{
    uint32_t s = 0x12345678u;
    for (int i = 0; i < kN; i++)
    {
        s ^= s << 13; s ^= s >> 17; s ^= s << 5;
        gInput[i] = s ? s : 0x9E3779B9u;
    }
}
static inline float BitsToF(uint32_t u, int shift) { return ((u >> shift) & 0xFF) * (1.0f / 128.0f) + 0.25f; }

// ---------------- 计时运行器：min-of-5 ----------------
template <class F>
static double TimePerIterNs(F&& fn, int iters)
{
    fn();  // 预热
    double best = 1e30;
    for (int r = 0; r < 5; r++)
    {
        gChecksum = 0;
        double t0 = NowSec();
        fn();
        double t1 = NowSec();
        double d = t1 - t0;
        if (d < best) best = d;
    }
    return best / (double)iters * 1e9;
}

template <class F>
static uint64_t CheckOnly(F&& fn)
{
    gChecksum = 0;
    fn();
    return gChecksum;
}
