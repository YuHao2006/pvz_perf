
void __fastcall FUN_005492f0(int param_1)

{
  if (*(int *)(param_1 + 0x24) == 0) {
    *(undefined1 *)(param_1 + 0x3c) = 1;
  }
  else {
    (**(code **)(**(int **)(param_1 + 0x24) + 0x40))(param_1);
  }
  return;
}

