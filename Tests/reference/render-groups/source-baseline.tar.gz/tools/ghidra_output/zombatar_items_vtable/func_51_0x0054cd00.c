
/* Library Function - Single Match
    public: virtual int __thiscall CDialog::CreateIndirect(struct DLGTEMPLATE const *,class CWnd
   *,void *)
   
   Libraries: Visual Studio 2003 Debug, Visual Studio 2005 Debug, Visual Studio 2008 Debug, Visual
   Studio 2010 Debug */

int __thiscall
CDialog::CreateIndirect(CDialog *this,DLGTEMPLATE *param_1,CWnd *param_2,void *param_3)

{
  int iVar1;
  undefined4 in_stack_00000010;
  
  iVar1 = FUN_0059a770(param_2,param_3,in_stack_00000010,0);
  return iVar1;
}

