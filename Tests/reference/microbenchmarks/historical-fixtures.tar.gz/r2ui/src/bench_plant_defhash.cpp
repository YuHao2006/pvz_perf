// bench_plant_defhash.cpp -- 目标8  kPlantPreloadExtras(53x2) Plant::PreloadPlantResources（装载，冷）
//                            目标26 kDefMapPrecomputedHashes(6)  Definition::DefinitionCalcHash（装载，冷）
// FormA = 36a066a7^ / 403c1968^ 逐字；FormB = HEAD 逐字。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// ---------------- t8 PreloadPlantResources ----------------
enum ReanimationTypeP { REANIM_NONE = 0, REANIM_ZOMBIE_CHARRED = 100, REANIM_JALAPENO_FIRE = 101, REANIM_FIRE_PEA = 102, REANIM_SLEEPING = 103, REANIM_PLANT_BASE = 200 };
static const int NUM_SEED_TYPES = 53;
static void ReanimatorEnsureDefinitionLoaded(ReanimationTypeP t, bool queue)
{
    CS(110); CS((uint64_t)t); CS(queue);
}
struct PlantDefinition { ReanimationTypeP mReanimationType; };
static PlantDefinition g_plantDefs[NUM_SEED_TYPES];
static bool PlantIsNocturnal(int theSeedType)
{
    // 夜行性集合（与表注释一致：9,10,12,13,14,15,16,25,32,43 按下表行注释枚举序）
    switch (theSeedType)
    {
    case 9: case 10: case 12: case 13: case 14: case 15: case 25: case 32: case 43:
        return true;
    default:
        return false;
    }
}

namespace FormA {
__declspec(noinline) void PreloadPlantResources(int theSeedType)
{
    const PlantDefinition& aPlantDef = g_plantDefs[theSeedType];
    if (aPlantDef.mReanimationType != REANIM_NONE)
    {
        ReanimatorEnsureDefinitionLoaded(aPlantDef.mReanimationType, true);
    }

    if (theSeedType == 2) // SEED_CHERRYBOMB
    {
        ReanimatorEnsureDefinitionLoaded(REANIM_ZOMBIE_CHARRED, true);
    }
    else if (theSeedType == 20) // SEED_JALAPENO
    {
        ReanimatorEnsureDefinitionLoaded(REANIM_JALAPENO_FIRE, true);
    }
    else if (theSeedType == 22) // SEED_TORCHWOOD
    {
        ReanimatorEnsureDefinitionLoaded(REANIM_FIRE_PEA, true);
        ReanimatorEnsureDefinitionLoaded(REANIM_JALAPENO_FIRE, true);
    }
    else if (PlantIsNocturnal(theSeedType))
    {
        ReanimatorEnsureDefinitionLoaded(REANIM_SLEEPING, true);
    }
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void PreloadPlantResources(int theSeedType)
{
    const PlantDefinition& aPlantDef = g_plantDefs[theSeedType];
    if (aPlantDef.mReanimationType != REANIM_NONE)
    {
        ReanimatorEnsureDefinitionLoaded(aPlantDef.mReanimationType, true);
    }

    // B 形态 -> 常量二维表 kPlantPreloadExtras（原 3 支种子等值链合并）
    static constexpr ReanimationTypeP kPlantPreloadExtras[NUM_SEED_TYPES][2] = {
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_ZOMBIE_CHARRED, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_JALAPENO_FIRE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_FIRE_PEA, REANIM_JALAPENO_FIRE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE }, { REANIM_NONE, REANIM_NONE },
        { REANIM_NONE, REANIM_NONE },
    };

    const unsigned aSeedIndex = static_cast<unsigned>(theSeedType);
    if (aSeedIndex < (int)NUM_SEED_TYPES)
    {
        for (ReanimationTypeP anExtra : kPlantPreloadExtras[aSeedIndex])
        {
            if (anExtra != REANIM_NONE)
            {
                ReanimatorEnsureDefinitionLoaded(anExtra, true);
            }
        }
    }

    // 表外特例：IsNocturnal 谓词支（菇类集合）
    if (PlantIsNocturnal(theSeedType))
    {
        ReanimatorEnsureDefinitionLoaded(REANIM_SLEEPING, true);
    }
}
} // namespace FormB

// ---------------- t26 DefinitionCalcHash ----------------
struct DefMap { int id; };
static DefMap gParticleFieldDefMap{ 1 }, gEmitterDefMap{ 2 }, gParticleDefMap{ 3 },
gReanimatorTransformDefMap{ 4 }, gReanimatorTrackDefMap{ 5 }, gReanimatorDefMap{ 6 },
gExtraDefMap1{ 7 }, gExtraDefMap2{ 8 };
static const uint32_t kParticleFieldDefMapHash = 0x11111111, kEmitterDefMapHash = 0x22222222,
kParticleDefMapHash = 0x33333333, kReanimatorTransformDefMapHash = 0x44444444,
kReanimatorTrackDefMapHash = 0x55555555, kReanimatorDefMapHash = 0x66666666;

// 运行期链（zlib crc32 链代理：与命中常量对拍用同一确定性函数）
static uint32_t DefinitionCalcHashDefMapProxy(uint32_t h, const DefMap* m)
{
    uint32_t v = h + (uint32_t)m->id * 2654435761u;
    for (int i = 0; i < 4; i++) v = (v >> 1) | (v << 31);
    return v;
}

namespace FormA {
__declspec(noinline) uint32_t DefinitionCalcHash(DefMap* theDefMap)
{
    uint32_t aPrecomputed;
    if (theDefMap == &gParticleFieldDefMap)
        aPrecomputed = kParticleFieldDefMapHash;
    else if (theDefMap == &gEmitterDefMap)
        aPrecomputed = kEmitterDefMapHash;
    else if (theDefMap == &gParticleDefMap)
        aPrecomputed = kParticleDefMapHash;
    else if (theDefMap == &gReanimatorTransformDefMap)
        aPrecomputed = kReanimatorTransformDefMapHash;
    else if (theDefMap == &gReanimatorTrackDefMap)
        aPrecomputed = kReanimatorTrackDefMapHash;
    else if (theDefMap == &gReanimatorDefMap)
        aPrecomputed = kReanimatorDefMapHash;
    else
    {
        uint32_t aResult = DefinitionCalcHashDefMapProxy(1, theDefMap);
        CS(120); CS(aResult);
        return aResult;
    }
    CS(121); CS(aPrecomputed);
    return aPrecomputed;
}
} // namespace FormA

namespace FormB {
__declspec(noinline) uint32_t DefinitionCalcHash(DefMap* theDefMap)
{
    // B 形态 -> 常量对表 kDefMapPrecomputedHashes（原 6 支链合并；未列映射落运行期链 else）
    static constexpr struct { const DefMap* mDefMap; uint32_t mHash; } kDefMapPrecomputedHashes[] = {
        { &gParticleFieldDefMap, kParticleFieldDefMapHash },
        { &gEmitterDefMap, kEmitterDefMapHash },
        { &gParticleDefMap, kParticleDefMapHash },
        { &gReanimatorTransformDefMap, kReanimatorTransformDefMapHash },
        { &gReanimatorTrackDefMap, kReanimatorTrackDefMapHash },
        { &gReanimatorDefMap, kReanimatorDefMapHash },
    };

    uint32_t aPrecomputed = 0;
    bool aFoundPrecomputed = false;
    for (const auto& aRow : kDefMapPrecomputedHashes)
    {
        if (aRow.mDefMap == theDefMap)
        {
            aPrecomputed = aRow.mHash;
            aFoundPrecomputed = true;
            break;
        }
    }

    if (!aFoundPrecomputed)
    {
        uint32_t aResult = DefinitionCalcHashDefMapProxy(1, theDefMap);
        CS(120); CS(aResult);
        return aResult;
    }
    CS(121); CS(aPrecomputed);
    return aPrecomputed;
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];

typedef void (*PreloadFn)(int);
typedef uint32_t (*HashFn)(DefMap*);

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    LCG rng{ 0x27BB2EE687B0B0FDULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();
    for (int k = 0; k < NUM_SEED_TYPES; k++)
        g_plantDefs[k].mReanimationType = (k % 3 == 0) ? (ReanimationTypeP)(REANIM_PLANT_BASE + k) : REANIM_NONE;

    // t8
    {
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { int seed = (int)(g_in[i] % 55); if (seed < NUM_SEED_TYPES) FormA::PreloadPlantResources(seed); else { CS(130); CS((uint64_t)seed); } } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { int seed = (int)(g_in[i] % 55); if (seed < NUM_SEED_TYPES) FormB::PreloadPlantResources(seed); else { CS(130); CS((uint64_t)seed); } } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t8 kPlantPreloadExtras(53x2) PreloadPlantResources", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t26
    {
        static DefMap* maps[8] = { &gParticleFieldDefMap, &gEmitterDefMap, &gParticleDefMap, &gReanimatorTransformDefMap,
            &gReanimatorTrackDefMap, &gReanimatorDefMap, &gExtraDefMap1, &gExtraDefMap2 };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; uint32_t acc = 0; for (int i = 0; i < N; i++) { acc = acc * 31 + FormA::DefinitionCalcHash(maps[g_in[i] % 8]); } CS(acc); return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; uint32_t acc = 0; for (int i = 0; i < N; i++) { acc = acc * 31 + FormB::DefinitionCalcHash(maps[g_in[i] % 8]); } CS(acc); return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t26 kDefMapPrecomputedHashes(6) DefinitionCalcHash", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
