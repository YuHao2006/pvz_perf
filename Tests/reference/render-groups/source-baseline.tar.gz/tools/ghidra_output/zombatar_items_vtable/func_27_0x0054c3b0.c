
void __thiscall FUN_0054c3b0(int *param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined1 local_40 [8];
  undefined1 local_38 [8];
  undefined4 local_30;
  undefined4 local_2c;
  undefined1 local_28 [8];
  undefined4 local_20;
  undefined4 local_1c;
  int local_8;
  
  piVar3 = param_1 + 0x1b;
  puVar1 = (undefined4 *)FUN_00615d10(local_28);
  local_20 = *puVar1;
  local_1c = puVar1[1];
  puVar1 = (undefined4 *)FUN_0060e080(local_38);
  local_30 = *puVar1;
  local_2c = puVar1[1];
  FUN_005585d0(local_40,local_30,local_2c,local_20,local_1c);
  for (local_8 = 0; local_8 < param_3; local_8 = local_8 + 1) {
    uVar2 = FUN_005615d0(*(undefined4 *)(param_2 + local_8 * 0x10),
                         *(undefined4 *)(param_2 + 4 + local_8 * 0x10),
                         *(undefined4 *)(param_2 + 8 + local_8 * 0x10),
                         *(undefined4 *)(param_2 + 0xc + local_8 * 0x10));
    (**(code **)(*param_1 + 0x88))(local_8,uVar2);
  }
  (**(code **)(*param_1 + 0x44))(param_1,piVar3);
  return;
}

