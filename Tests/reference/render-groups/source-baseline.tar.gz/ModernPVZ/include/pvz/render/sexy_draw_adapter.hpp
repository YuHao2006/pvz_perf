#pragma once

#include "pvz/render/draw_command_recorder.hpp"

#include <cstdint>
#include <span>

namespace pvz::render {

// This is a semantic port of the 1073 Sexy 2D calls. It intentionally has no
// DirectDraw, Direct3D, COM, or platform-window types in its interface.
class SexyDrawCommandAdapter final {
public:
    explicit SexyDrawCommandAdapter(DrawCommandRecorder& recorder) noexcept
        : recorder_(recorder)
    {
    }

    // Mirrors the small piece of DX7 texture-stage state used by PoolEffect:
    // later draws observe the selected U/V addressing until it is changed.
    void set_texture_address_modes(
        TextureAddressMode address_u,
        TextureAddressMode address_v) noexcept;
    void set_filter(TextureFilter filter) noexcept;
    [[nodiscard]] SamplingState sampling_state() const noexcept;

    void blt(
        const TextureRegion& source,
        Point2D top_left,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        bool linear_filter = false);

    void blt_mirror(
        const TextureRegion& source,
        Point2D top_left,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        bool linear_filter = false);

    void stretch_blt(
        const TextureRegion& source,
        Rect2D destination,
        Rect2D source_pixels,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        bool fast_stretch = false,
        bool mirror_x = false);

    void blt_rotated(
        const TextureRegion& source,
        Point2D top_left,
        double radians,
        Point2D rotation_center,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {});

    void fill_rect(
        Rect2D destination,
        std::uint32_t rgba,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {});

    void draw_triangles_tex(
        TextureHandle texture,
        std::span<const Vertex2D> vertices,
        std::uint32_t rgba = 0xFFFFFFFF,
        BlendMode blend_mode = BlendMode::alpha,
        Rect2D logical_scissor = {},
        bool linear_filter = false);

private:
    [[nodiscard]] SamplingState sampling_for(bool linear_filter) const noexcept;

    DrawCommandRecorder& recorder_;
    SamplingState sampling_state_;
};

} // namespace pvz::render
