// t08_backdrop.cpp — ★kBackgrounds -> Board::DrawBackdrop（每帧·背景消费）
// ECS↔OOP 数据布局专题首例：FormA=4f4f43e7^ 三张平行表（kBackgroundImages/
// kBackgroundRows/kBackgroundResources），FormB=HEAD 合并结构体 kBackgrounds。
// 三个消费点分开计时：DrawBackdrop（贴图·每帧）/ InitLevel 行型段 / LoadBackgroundImages（资源组）。
// DrawBackdrop 双输入模式：fixed（真实每帧=背景不变，纯 cache line 驻留）与
// varying（均匀换背景，量 locality 差）。
#include "r3_entities.h"

// 附加图像
namespace Sexy { inline Image* IMAGE_NIGHT_GRAVE_GRAPHIC = ::ZBImg(180); }

// Board 查询补充桩（两形态共享）
__declspec(noinline) bool StageHasPoolStub(Board* b) { return b->mBackground == BackgroundType::BACKGROUND_3_POOL || b->mBackground == BackgroundType::BACKGROUND_4_FOG || b->mBackground == BackgroundType::BACKGROUND_ZOMBIQUARIUM; }

// ==================== FormA：4f4f43e7^ 三张平行表（逐字） ====================
namespace
{
// 背景资源装载表：{主资源组, 叠加资源组}，按 BackgroundType 直下标。
constexpr struct
{
    const char* mMain;
    const char* mOverlay;
} kBackgroundResources[] = {
    /* BACKGROUND_1_DAY           */ { "DelayLoad_Background1", nullptr },
    /* BACKGROUND_2_NIGHT         */ { "DelayLoad_Background2", nullptr },
    /* BACKGROUND_3_POOL          */ { "DelayLoad_Background3", nullptr },
    /* BACKGROUND_4_FOG           */ { "DelayLoad_Background4", nullptr },
    /* BACKGROUND_5_ROOF          */ { "DelayLoad_Background5", nullptr },
    /* BACKGROUND_6_BOSS          */ { "DelayLoad_Background6", nullptr },
    /* BACKGROUND_MUSHROOM_GARDEN */ { "DelayLoad_MushroomGarden", nullptr },
    /* BACKGROUND_GREENHOUSE      */ { "DelayLoad_GreenHouseGarden", "DelayLoad_GreenHouseOverlay" },
    /* BACKGROUND_ZOMBIQUARIUM    */ { "DelayLoad_Zombiquarium", "DelayLoad_GreenHouseOverlay" },
    /* BACKGROUND_TREEOFWISDOM    */ { nullptr, nullptr },
};
static_assert(sizeof(kBackgroundResources) / sizeof(kBackgroundResources[0]) == (int)BackgroundType::BACKGROUND_TREEOFWISDOM + 1,
    "背景资源槽位须与 BackgroundType 枚举尾同步");

// 背景行型表：背景 → 六行种植行类型。
constexpr PlantRowType kBackgroundRows[][MAX_GRID_SIZE_Y] = {
    /* BACKGROUND_1_DAY           */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
    /* BACKGROUND_2_NIGHT         */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
    /* BACKGROUND_3_POOL          */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL },
    /* BACKGROUND_4_FOG           */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL },
    /* BACKGROUND_5_ROOF          */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
    /* BACKGROUND_6_BOSS          */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
    /* BACKGROUND_MUSHROOM_GARDEN */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
    /* BACKGROUND_GREENHOUSE      */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
    /* BACKGROUND_ZOMBIQUARIUM    */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL },
    /* BACKGROUND_TREEOFWISDOM    */ { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT },
};
static_assert(sizeof(kBackgroundRows) / sizeof(kBackgroundRows[0]) == (int)BackgroundType::BACKGROUND_TREEOFWISDOM + 1,
    "背景行型槽位须与 BackgroundType 枚举尾同步");

// 背景贴图表（每帧热路径）：BackgroundType → 运行期装载全局地址（Image* const*），
// 用时一次解引用；树智慧行 = nullptr（原 case 显式置空）。
constexpr Image* const* kBackgroundImages[] = {
    /* BACKGROUND_1_DAY             */ &Sexy::IMAGE_BACKGROUND1,
    /* BACKGROUND_2_NIGHT           */ &Sexy::IMAGE_BACKGROUND2,
    /* BACKGROUND_3_POOL            */ &Sexy::IMAGE_BACKGROUND3,
    /* BACKGROUND_4_FOG             */ &Sexy::IMAGE_BACKGROUND4,
    /* BACKGROUND_5_ROOF            */ &Sexy::IMAGE_BACKGROUND5,
    /* BACKGROUND_6_BOSS            */ &Sexy::IMAGE_BACKGROUND6BOSS,
    /* BACKGROUND_MUSHROOM_GARDEN   */ &Sexy::IMAGE_BACKGROUND_MUSHROOMGARDEN,
    /* BACKGROUND_GREENHOUSE        */ &Sexy::IMAGE_BACKGROUND_GREENHOUSE,
    /* BACKGROUND_ZOMBIQUARIUM      */ &Sexy::IMAGE_AQUARIUM1,
    /* BACKGROUND_TREEOFWISDOM      */ nullptr,
};
static_assert(sizeof(kBackgroundImages) / sizeof(kBackgroundImages[0]) == (int)BackgroundType::BACKGROUND_TREEOFWISDOM + 1,
    "背景贴图槽位须与 BackgroundType 枚举尾同步");
}  // namespace

// ==================== FormB：HEAD 合并结构体 kBackgrounds（逐字） ====================
struct BackgroundInfo
{
    Image* const* mTopImage;               // DrawBackdrop 直取（运行期装载全局地址）
    PlantRowType mRows[MAX_GRID_SIZE_Y];   // 行型
    const char* mMainResource;             // 装载资源组
    const char* mOverlayResource;          // 叠加装载组（nullptr = 无）
};
constexpr BackgroundInfo kBackgrounds[] = {
    /* BACKGROUND_1_DAY           */ { &Sexy::IMAGE_BACKGROUND1,    { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, "DelayLoad_Background1", nullptr },
    /* BACKGROUND_2_NIGHT         */ { &Sexy::IMAGE_BACKGROUND2,    { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, "DelayLoad_Background2", nullptr },
    /* BACKGROUND_3_POOL          */ { &Sexy::IMAGE_BACKGROUND3,    { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL }, "DelayLoad_Background3", nullptr },
    /* BACKGROUND_4_FOG           */ { &Sexy::IMAGE_BACKGROUND4,    { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL }, "DelayLoad_Background4", nullptr },
    /* BACKGROUND_5_ROOF          */ { &Sexy::IMAGE_BACKGROUND5,    { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, "DelayLoad_Background5", nullptr },
    /* BACKGROUND_6_BOSS          */ { &Sexy::IMAGE_BACKGROUND6BOSS,{ PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, "DelayLoad_Background6", nullptr },
    /* BACKGROUND_MUSHROOM_GARDEN */ { &Sexy::IMAGE_BACKGROUND_MUSHROOMGARDEN, { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, "DelayLoad_MushroomGarden", nullptr },
    /* BACKGROUND_GREENHOUSE      */ { &Sexy::IMAGE_BACKGROUND_GREENHOUSE,     { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, "DelayLoad_GreenHouseGarden", "DelayLoad_GreenHouseOverlay" },
    /* BACKGROUND_ZOMBIQUARIUM    */ { &Sexy::IMAGE_AQUARIUM1,      { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_POOL,   PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL }, "DelayLoad_Zombiquarium", "DelayLoad_GreenHouseOverlay" },
    /* BACKGROUND_TREEOFWISDOM    */ { nullptr,                      { PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_NORMAL, PlantRowType::PLANTROW_DIRT }, nullptr, nullptr },
};
static_assert(sizeof(kBackgrounds) / sizeof(kBackgrounds[0]) == (int)BackgroundType::BACKGROUND_TREEOFWISDOM + 1,
    "背景信息表槽位须与 BackgroundType 枚举尾同步");

// ==================== 消费点 1：DrawBackdrop（★每帧） ====================
// FormA：4f4f43e7^ 逐字（kBackgroundImages）
__declspec(noinline) void Board::DrawBackdrop_A(Graphics* g)
{
    Image* aBgImage = nullptr;
    int aBgType = (int)mBackground;
    if ((unsigned)aBgType < (unsigned)(sizeof(kBackgroundImages) / sizeof(kBackgroundImages[0])))
    {
        aBgImage = kBackgroundImages[aBgType] ? *kBackgroundImages[aBgType] : nullptr;
    }
    else
    {
        TOD_ASSERT(false);
    }

    if (mLevel == 1 && mApp->IsFirstTimeAdventureMode())
    {
        g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);
        int aWidth = TodAnimateCurve(0, 1000, mSodPosition, 0, Sexy::IMAGE_SOD1ROW->GetWidth(), Curves::Linear);
        Rect aSrcRect(0, 0, aWidth, Sexy::IMAGE_SOD1ROW->GetHeight());
        g->DrawImage(Sexy::IMAGE_SOD1ROW, 239 - BOARD_OFFSET, 265, aSrcRect);
    }
    else if (((mLevel == 2 || mLevel == 3) && mApp->IsFirstTimeAdventureMode()) || mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_RESODDED)
    {
        g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);
        g->DrawImage(Sexy::IMAGE_SOD1ROW, 239 - BOARD_OFFSET, 265);
        int aWidth = TodAnimateCurve(0, 1000, mSodPosition, 0, Sexy::IMAGE_SOD3ROW->GetWidth(), Curves::Linear);
        Rect aSrcRect(0, 0, aWidth, Sexy::IMAGE_SOD3ROW->GetHeight());
        g->DrawImage(Sexy::IMAGE_SOD3ROW, 235 - BOARD_OFFSET, 149, aSrcRect);
    }
    else if (mLevel == 4 && mApp->IsFirstTimeAdventureMode())
    {
        g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);
        g->DrawImage(Sexy::IMAGE_SOD3ROW, 235 - BOARD_OFFSET, 149);
        int aWidth = TodAnimateCurve(0, 1000, mSodPosition, 0, 773, Curves::Linear);
        Rect aSrcRect(232, 0, aWidth, Sexy::IMAGE_BACKGROUND1->GetHeight());
        g->DrawImage(Sexy::IMAGE_BACKGROUND1, 232 - BOARD_OFFSET, 0, aSrcRect);
    }
    else if (aBgImage)
    {
        if (aBgImage == Sexy::IMAGE_BACKGROUND_MUSHROOMGARDEN || aBgImage == Sexy::IMAGE_BACKGROUND_GREENHOUSE || aBgImage == Sexy::IMAGE_AQUARIUM1)
        {
            g->DrawImage(aBgImage, 0, 0);
        }
        else
        {
            g->DrawImage(aBgImage, -BOARD_OFFSET, 0);
        }
    }

    if (mApp->mGameScene == GameScenes::SCENE_ZOMBIES_WON)
    {
        DrawHouseDoorBottom_A(g);
    }
    if (StageHasPoolStub(this))
    {
        mApp->mPoolEffect->PoolEffectDraw(g, StageHasPoolStub(this));
    }
    if (mTutorialState == TutorialState::TUTORIAL_LEVEL_1_PLANT_PEASHOOTER)
    {
        Graphics aClipG(*g);
        aClipG.SetColorizeImages(true);
        aClipG.SetColor(GetFlashingColor(mMainCounter, 75));
        aClipG.DrawImage(Sexy::IMAGE_SOD1ROW, 239 - BOARD_OFFSET, 265);
        aClipG.SetColorizeImages(false);
    }
    mChallenge->DrawWeather(g);
    if (mApp->mGameScene == GameScenes::SCENE_LEVEL_INTRO && StageHasPoolStub(this))
    {
        g->DrawImage(Sexy::IMAGE_NIGHT_GRAVE_GRAPHIC, 1092, 40);
    }
}

// FormB：HEAD 逐字（kBackgrounds 合并结构体）
__declspec(noinline) void Board::DrawBackdrop_B(Graphics* g)
{
    Image* aBgImage = nullptr;
    int aBgType = (int)mBackground;
    if ((unsigned)aBgType < (unsigned)(sizeof(kBackgrounds) / sizeof(kBackgrounds[0])))
    {
        aBgImage = kBackgrounds[aBgType].mTopImage ? *kBackgrounds[aBgType].mTopImage : nullptr;
    }
    else
    {
        TOD_ASSERT(false);
    }

    if (mLevel == 1 && mApp->IsFirstTimeAdventureMode())
    {
        g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);
        int aWidth = TodAnimateCurve(0, 1000, mSodPosition, 0, Sexy::IMAGE_SOD1ROW->GetWidth(), Curves::Linear);
        Rect aSrcRect(0, 0, aWidth, Sexy::IMAGE_SOD1ROW->GetHeight());
        g->DrawImage(Sexy::IMAGE_SOD1ROW, 239 - BOARD_OFFSET, 265, aSrcRect);
    }
    else if (((mLevel == 2 || mLevel == 3) && mApp->IsFirstTimeAdventureMode()) || mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_RESODDED)
    {
        g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);
        g->DrawImage(Sexy::IMAGE_SOD1ROW, 239 - BOARD_OFFSET, 265);
        int aWidth = TodAnimateCurve(0, 1000, mSodPosition, 0, Sexy::IMAGE_SOD3ROW->GetWidth(), Curves::Linear);
        Rect aSrcRect(0, 0, aWidth, Sexy::IMAGE_SOD3ROW->GetHeight());
        g->DrawImage(Sexy::IMAGE_SOD3ROW, 235 - BOARD_OFFSET, 149, aSrcRect);
    }
    else if (mLevel == 4 && mApp->IsFirstTimeAdventureMode())
    {
        g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);
        g->DrawImage(Sexy::IMAGE_SOD3ROW, 235 - BOARD_OFFSET, 149);
        int aWidth = TodAnimateCurve(0, 1000, mSodPosition, 0, 773, Curves::Linear);
        Rect aSrcRect(232, 0, aWidth, Sexy::IMAGE_BACKGROUND1->GetHeight());
        g->DrawImage(Sexy::IMAGE_BACKGROUND1, 232 - BOARD_OFFSET, 0, aSrcRect);
    }
    else if (aBgImage)
    {
        if (aBgImage == Sexy::IMAGE_BACKGROUND_MUSHROOMGARDEN || aBgImage == Sexy::IMAGE_BACKGROUND_GREENHOUSE || aBgImage == Sexy::IMAGE_AQUARIUM1)
        {
            g->DrawImage(aBgImage, 0, 0);
        }
        else
        {
            g->DrawImage(aBgImage, -BOARD_OFFSET, 0);
        }
    }

    if (mApp->mGameScene == GameScenes::SCENE_ZOMBIES_WON)
    {
        DrawHouseDoorBottom_B(g);
    }
    if (StageHasPoolStub(this))
    {
        mApp->mPoolEffect->PoolEffectDraw(g, StageHasPoolStub(this));
    }
    if (mTutorialState == TutorialState::TUTORIAL_LEVEL_1_PLANT_PEASHOOTER)
    {
        Graphics aClipG(*g);
        aClipG.SetColorizeImages(true);
        aClipG.SetColor(GetFlashingColor(mMainCounter, 75));
        aClipG.DrawImage(Sexy::IMAGE_SOD1ROW, 239 - BOARD_OFFSET, 265);
        aClipG.SetColorizeImages(false);
    }
    mChallenge->DrawWeather(g);
    if (mApp->mGameScene == GameScenes::SCENE_LEVEL_INTRO && StageHasPoolStub(this))
    {
        g->DrawImage(Sexy::IMAGE_NIGHT_GRAVE_GRAPHIC, 1092, 40);
    }
}

// ==================== 消费点 2：InitLevel 行型段 ====================
__declspec(noinline) void InitLevelRows_A(Board& b)
{
    for (int y = 0; y < MAX_GRID_SIZE_Y; y++)
    {
        b.mPlantRow[y] = kBackgroundRows[(int)b.mBackground][y];
    }
}
__declspec(noinline) void InitLevelRows_B(Board& b)
{
    for (int y = 0; y < MAX_GRID_SIZE_Y; y++)
    {
        b.mPlantRow[y] = kBackgrounds[(int)b.mBackground].mRows[y];
    }
}

// ==================== 消费点 3：LoadBackgroundImages ====================
__declspec(noinline) void LoadBackgroundImages_A(Board& b)
{
    int aBackground = (int)b.mBackground;
    if ((unsigned)aBackground >= (unsigned)(sizeof(kBackgroundResources) / sizeof(kBackgroundResources[0])))
    {
        TOD_ASSERT(false);
        return;
    }
    const auto& aRow = kBackgroundResources[aBackground];
    if (aRow.mMain != nullptr)
    {
        TodLoadResources(aRow.mMain);
        if (aRow.mOverlay != nullptr)
        {
            TodLoadResources(aRow.mOverlay);
        }
    }
    else
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_TREEOFWISDOM, true);
    }
}
__declspec(noinline) void LoadBackgroundImages_B(Board& b)
{
    int aBackground = (int)b.mBackground;
    if ((unsigned)aBackground >= (unsigned)(sizeof(kBackgrounds) / sizeof(kBackgrounds[0])))
    {
        TOD_ASSERT(false);
        return;
    }
    const auto& aRow = kBackgrounds[aBackground];
    if (aRow.mMainResource != nullptr)
    {
        TodLoadResources(aRow.mMainResource);
        if (aRow.mOverlayResource != nullptr)
        {
            TodLoadResources(aRow.mOverlayResource);
        }
    }
    else
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_TREEOFWISDOM, true);
    }
}

// ==================== 门表（DrawBackdrop 内消费，两形态各自版本） ====================
namespace
{
struct DoorImageEntry
{
    Image* const* mImage;
    int mX;
    int mY;
};
constexpr DoorImageEntry kDoorBottom[7] = {
    { &Sexy::IMAGE_BACKGROUND1_GAMEOVER_INTERIOR_OVERLAY, -126, 225 },
    { &Sexy::IMAGE_BACKGROUND2_GAMEOVER_INTERIOR_OVERLAY, -125, 196 },
    { &Sexy::IMAGE_BACKGROUND3_GAMEOVER_INTERIOR_OVERLAY, -171, 241 },
    { &Sexy::IMAGE_BACKGROUND4_GAMEOVER_INTERIOR_OVERLAY, -172, 246 },
    { nullptr, 0, 0 },
    { nullptr, 0, 0 },
    { nullptr, 0, 0 },
};
constexpr DoorImageEntry kDoorTop[7] = {
    { &Sexy::IMAGE_BACKGROUND1_GAMEOVER_MASK, -130, 202 },
    { &Sexy::IMAGE_BACKGROUND2_GAMEOVER_MASK, -128, 207 },
    { &Sexy::IMAGE_BACKGROUND3_GAMEOVER_MASK, -172, 234 },
    { &Sexy::IMAGE_BACKGROUND4_GAMEOVER_MASK, -173, 133 },
    { &Sexy::IMAGE_BACKGROUND5_GAMEOVER_MASK, -220, 81 },
    { &Sexy::IMAGE_BACKGROUND6_GAMEOVER_MASK, -220, 81 },
    { nullptr, 0, 0 },
};
static_assert(sizeof(kDoorBottom) / sizeof(kDoorBottom[0]) == 7 &&
    kDoorBottom[0].mImage == &Sexy::IMAGE_BACKGROUND1_GAMEOVER_INTERIOR_OVERLAY &&
    kDoorBottom[3].mImage == &Sexy::IMAGE_BACKGROUND4_GAMEOVER_INTERIOR_OVERLAY, "门底表锚点");
static_assert(sizeof(kDoorTop) / sizeof(kDoorTop[0]) == 7 &&
    kDoorTop[0].mImage == &Sexy::IMAGE_BACKGROUND1_GAMEOVER_MASK &&
    kDoorTop[5].mImage == &Sexy::IMAGE_BACKGROUND6_GAMEOVER_MASK, "门顶表锚点");
}  // namespace

__declspec(noinline) void Board::DrawHouseDoorBottom_A(Graphics* g)
{
    if (static_cast<unsigned>(mBackground) < 7 && kDoorBottom[(int)mBackground].mImage != nullptr)
    {
        g->DrawImage(*kDoorBottom[(int)mBackground].mImage, kDoorBottom[(int)mBackground].mX, kDoorBottom[(int)mBackground].mY);
    }
}
__declspec(noinline) void Board::DrawHouseDoorBottom_B(Graphics* g)
{
    if (static_cast<unsigned>(mBackground) < 7 && kDoorBottom[(int)mBackground].mImage != nullptr)
    {
        g->DrawImage(*kDoorBottom[(int)mBackground].mImage, kDoorBottom[(int)mBackground].mX, kDoorBottom[(int)mBackground].mY);
    }
}
__declspec(noinline) void Board::DrawHouseDoorTop_A(Graphics* g)
{
    if (static_cast<unsigned>(mBackground) < 7 && kDoorTop[(int)mBackground].mImage != nullptr)
    {
        g->DrawImage(*kDoorTop[(int)mBackground].mImage, kDoorTop[(int)mBackground].mX, kDoorTop[(int)mBackground].mY);
    }
}
__declspec(noinline) void Board::DrawHouseDoorTop_B(Graphics* g)
{
    if (static_cast<unsigned>(mBackground) < 7 && kDoorTop[(int)mBackground].mImage != nullptr)
    {
        g->DrawImage(*kDoorTop[(int)mBackground].mImage, kDoorTop[(int)mBackground].mX, kDoorTop[(int)mBackground].mY);
    }
}

// ============================ main ============================
static Board g_board;
static LawnApp g_app;
static CutScene g_cut;
static Challenge g_chal;
static PoolEffect g_pool;
static CursorObject g_cursor;
static Graphics g_gfx;

static void ResetBoard(BackgroundType bg)
{
    g_board.mApp = &g_app;
    g_app.mBoard = &g_board;
    g_board.mBackground = bg;
    g_board.mLevel = 7;                 // 跳过铺草皮三段（走主背景支）
    g_board.mSodPosition = 500;
    g_board.mTutorialState = TutorialState::TUTORIAL_OFF;
    g_board.mChallenge = &g_chal;
    g_board.mCutScene = &g_cut;
    g_app.mPoolEffect = &g_pool;
    g_app.mGameScene = GameScenes::SCENE_PLAYING;
    g_app.mGameMode = GAMEMODE_ADVENTURE;
}

static void FoldRows(uint64_t& h, const Board& b)
{
    for (int y = 0; y < MAX_GRID_SIZE_Y; y++)
        h = ZBMixU64(h, (uint64_t)(uint32_t)b.mPlantRow[y]);
}

int main()
{
    int rc = 0;
    // t08a：fixed 背景（真实每帧模式：背景全程不变）
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(BackgroundType::BACKGROUND_3_POOL);
                g_board.DrawBackdrop_A(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(BackgroundType::BACKGROUND_3_POOL);
                g_board.DrawBackdrop_B(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        rc |= R3BenchMain("t08a_DrawBackdrop_fixedbg", reset, pa, pb);
    }
    // t08b：varying 背景（均匀输入：量 locality 差）
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard((BackgroundType)(g_inputs[i].d % 10));
                g_board.DrawBackdrop_A(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard((BackgroundType)(g_inputs[i].d % 10));
                g_board.DrawBackdrop_B(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        rc |= R3BenchMain("t08b_DrawBackdrop_varyingbg", reset, pa, pb);
    }
    // t08c：InitLevel 行型段
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard((BackgroundType)(g_inputs[i].d % 10));
                InitLevelRows_A(g_board);
                FoldRows(ck, g_board);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard((BackgroundType)(g_inputs[i].d % 10));
                InitLevelRows_B(g_board);
                FoldRows(ck, g_board);
            }
        };
        rc |= R3BenchMain("t08c_InitLevelRows", reset, pa, pb);
    }
    // t08d：LoadBackgroundImages（资源组消费）
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard((BackgroundType)(g_inputs[i].d % 10));
                LoadBackgroundImages_A(g_board);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard((BackgroundType)(g_inputs[i].d % 10));
                LoadBackgroundImages_B(g_board);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        rc |= R3BenchMain("t08d_LoadBackgroundImages", reset, pa, pb);
    }
    // 布局事实输出（cache line 分析用，不计时）
    printf("layout|parallel_imgs=%dB rows=%dB res=%dB|merged_row=%dB total=%dB\n",
        (int)sizeof(kBackgroundImages), (int)sizeof(kBackgroundRows), (int)sizeof(kBackgroundResources),
        (int)sizeof(BackgroundInfo), (int)sizeof(kBackgrounds));
    return rc;
}
