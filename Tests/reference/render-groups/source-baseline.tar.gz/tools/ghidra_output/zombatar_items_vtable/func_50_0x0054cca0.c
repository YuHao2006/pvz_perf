
undefined4
FUN_0054cca0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined1 uVar1;
  undefined4 uVar2;
  
  uVar1 = *(undefined1 *)(param_1 + 0x4a);
  *(undefined1 *)(param_1 + 0x4a) = DAT_0071abe6;
  uVar2 = FUN_0059a1d0(param_2,param_3,param_4,param_5,0,0xffffffff,0,0);
  *(undefined1 *)(param_1 + 0x4a) = uVar1;
  return uVar2;
}

