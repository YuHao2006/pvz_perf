// t14_render.cpp — ★kRenderItemDraws -> Board::DrawGameObjects 渲染分发循环（每帧·最热之一）
// FormA = 5369c973^ 原 24 case 跳转 switch（逐字）；FormB = HEAD 函数内 static lambda 表（逐字）。
// 只测分发循环段（排序/构建不在对拍面），输入=固定 32 项渲染列表×2M 帧轮转。
#include "r3_entities.h"

// ==================== RenderItem（仓库 Board.h 形状） ====================
class RenderItem
{
public:
    RenderObjectType mRenderObjectType;
    int mZPos;
    union
    {
        void* mGameObject;
        Plant* mPlant;
        Zombie* mZombie;
        Coin* mCoin;
        Projectile* mProjectile;
        CursorPreview* mCursorPreview;
        TodParticleSystem* mParticleSytem;
        Reanimation* mReanimation;
        GridItem* mGridItem;
        LawnMower* mMower;
        BossPart mBossPart;
        int mBoardGridY;
    };
};

// ==================== 输入列表（真实帧形状：25 类型混合） ====================
static RenderItem g_list[32];
static int aRenderItemCountExt = 32;
static RenderItem* aRenderListExt = g_list;

// ==================== FormA：5369c973^ switch 循环（逐字） ====================
__declspec(noinline) void Board::DrawGameObjectsDispatch_A(Graphics* g)
{
    for (int i = 0; i < aRenderItemCountExt; i++)
    {
        RenderItem& aRenderItem = aRenderListExt[i];
        switch (aRenderItem.mRenderObjectType)
        {
        case RenderObjectType::RENDER_ITEM_PLANT:
        {
            Plant* aPlant = aRenderItem.mPlant;
            if (aPlant->BeginDraw(g))
            {
                aPlant->Draw(g);
                aPlant->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_PLANT_OVERLAY:
        {
            Plant* aPlant = aRenderItem.mPlant;
            if (aPlant->BeginDraw(g))
            {
                mApp->mZenGarden->DrawPlantOverlay(g, aPlant);
                aPlant->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_PLANT_MAGNET_ITEMS:
        {
            Plant* aPlant = aRenderItem.mPlant;
            if (aPlant->BeginDraw(g))
            {
                aPlant->DrawMagnetItems(g);
                aPlant->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_MOWER:
        {
            LawnMower* aLawnMower = aRenderItem.mMower;
            aLawnMower->Draw(g);
            break;
        }

        case RenderObjectType::RENDER_ITEM_ZOMBIE:
        {
            Zombie* aZombie = aRenderItem.mZombie;
            if (aZombie->BeginDraw(g))
            {
                aZombie->Draw(g);
                aZombie->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_ZOMBIE_SHADOW:
        {
            Zombie* aZombie = aRenderItem.mZombie;
            if (aZombie->BeginDraw(g))
            {
                aZombie->DrawShadow(g);
                aZombie->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_ZOMBIE_BUNGEE_TARGET:
        {
            Zombie* aZombie = aRenderItem.mZombie;
            aZombie->DrawBungeeTarget(g);
            break;
        }

        case RenderObjectType::RENDER_ITEM_BOSS_PART:
        {
            Zombie* aBossZombie = GetBossZombie();
            if (aBossZombie && aBossZombie->BeginDraw(g))
            {
                aBossZombie->DrawBossPart(g, aRenderItem.mBossPart);
                aBossZombie->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_COIN:
        {
            Coin* aCoin = aRenderItem.mCoin;
            if (aCoin->BeginDraw(g))
            {
                aCoin->Draw(g);
                aCoin->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_PROJECTILE:
        {
            Projectile* aProjectile = aRenderItem.mProjectile;
            if (aProjectile->BeginDraw(g))
            {
                aProjectile->Draw(g);
                aProjectile->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_PROJECTILE_SHADOW:
        {
            Projectile* aProjectile = aRenderItem.mProjectile;
            if (aProjectile->BeginDraw(g))
            {
                aProjectile->DrawShadow(g);
                aProjectile->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_CURSOR_PREVIEW:
        {
            CursorPreview* aCursorPreview = aRenderItem.mCursorPreview;
            if (aCursorPreview->BeginDraw(g))
            {
                aCursorPreview->Draw(g);
                aCursorPreview->EndDraw(g);
            }
            break;
        }

        case RenderObjectType::RENDER_ITEM_GRID_ITEM:
        {
            GridItem* aGridItem = aRenderItem.mGridItem;
            aGridItem->DrawGridItem(g);
            break;
        }

        case RenderObjectType::RENDER_ITEM_GRID_ITEM_OVERLAY:
        {
            GridItem* aGridItem = aRenderItem.mGridItem;
            aGridItem->DrawGridItemOverlay(g);
            break;
        }

        case RenderObjectType::RENDER_ITEM_ICE:
            DrawIce(g, aRenderItem.mBoardGridY);
            break;

        case RenderObjectType::RENDER_ITEM_PARTICLE:
        {
            TodParticleSystem* aParticle = aRenderItem.mParticleSytem;
            aParticle->Draw(g);
            break;
        }

        case RenderObjectType::RENDER_ITEM_REANIMATION:
        {
            Reanimation* aReanimation = aRenderItem.mReanimation;
            aReanimation->Draw(g);
            break;
        }

        case RenderObjectType::RENDER_ITEM_COIN_BANK:
            DrawUICoinBank(g);
            break;

        case RenderObjectType::RENDER_ITEM_BACKDROP:
            DrawBackdrop(g);
            break;

        case RenderObjectType::RENDER_ITEM_DOOR_MASK:
            DrawHouseDoorTop(g);
            break;

        case RenderObjectType::RENDER_ITEM_BOTTOM_UI:
            DrawUIBottom(g);
            break;

        case RenderObjectType::RENDER_ITEM_TOP_UI:
            DrawUITop(g);
            break;

        case RenderObjectType::RENDER_ITEM_FOG:
            DrawFog(g);
            break;

        case RenderObjectType::RENDER_ITEM_STORM:
            mChallenge->DrawWeather(g);
            break;

        case RenderObjectType::RENDER_ITEM_SCREEN_FADE:
            DrawFadeOut(g);
            break;

        default:
            TOD_ASSERT(false);
            break;
        }
    }
}

// ==================== FormB：HEAD static lambda 表循环（逐字） ====================
__declspec(noinline) void Board::DrawGameObjectsDispatch_B(Graphics* g)
{
    static_assert(RENDER_ITEM_COIN == 0, "渲染项表以枚举首项为基 0");
    static constexpr void (*kRenderItemDraws[])(Board*, Graphics*, RenderItem&) = {
        /* [0]  RENDER_ITEM_COIN                 */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Coin* aCoin = aRenderItem.mCoin; if (aCoin->BeginDraw(g)) { aCoin->Draw(g); aCoin->EndDraw(g); } },
        /* [1]  RENDER_ITEM_PROJECTILE           */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Projectile* aProjectile = aRenderItem.mProjectile; if (aProjectile->BeginDraw(g)) { aProjectile->Draw(g); aProjectile->EndDraw(g); } },
        /* [2]  RENDER_ITEM_ZOMBIE               */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Zombie* aZombie = aRenderItem.mZombie; if (aZombie->BeginDraw(g)) { aZombie->Draw(g); aZombie->EndDraw(g); } },
        /* [3]  RENDER_ITEM_ZOMBIE_SHADOW        */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Zombie* aZombie = aRenderItem.mZombie; if (aZombie->BeginDraw(g)) { aZombie->DrawShadow(g); aZombie->EndDraw(g); } },
        /* [4]  RENDER_ITEM_ZOMBIE_BUNGEE_TARGET */ [](Board*, Graphics* g, RenderItem& aRenderItem) { aRenderItem.mZombie->DrawBungeeTarget(g); },
        /* [5]  RENDER_ITEM_PLANT                */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Plant* aPlant = aRenderItem.mPlant; if (aPlant->BeginDraw(g)) { aPlant->Draw(g); aPlant->EndDraw(g); } },
        /* [6]  RENDER_ITEM_PLANT_OVERLAY        */ [](Board* aBoard, Graphics* g, RenderItem& aRenderItem) { Plant* aPlant = aRenderItem.mPlant; if (aPlant->BeginDraw(g)) { aBoard->mApp->mZenGarden->DrawPlantOverlay(g, aPlant); aPlant->EndDraw(g); } },
        /* [7]  RENDER_ITEM_PLANT_MAGNET_ITEMS   */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Plant* aPlant = aRenderItem.mPlant; if (aPlant->BeginDraw(g)) { aPlant->DrawMagnetItems(g); aPlant->EndDraw(g); } },
        /* [8]  RENDER_ITEM_CURSOR_PREVIEW       */ [](Board*, Graphics* g, RenderItem& aRenderItem) { CursorPreview* aCursorPreview = aRenderItem.mCursorPreview; if (aCursorPreview->BeginDraw(g)) { aCursorPreview->Draw(g); aCursorPreview->EndDraw(g); } },
        /* [9]  RENDER_ITEM_PARTICLE             */ [](Board*, Graphics* g, RenderItem& aRenderItem) { aRenderItem.mParticleSytem->Draw(g); },
        /* [10] RENDER_ITEM_REANIMATION          */ [](Board*, Graphics* g, RenderItem& aRenderItem) { aRenderItem.mReanimation->Draw(g); },
        /* [11] RENDER_ITEM_ICE                  */ [](Board* aBoard, Graphics* g, RenderItem& aRenderItem) { aBoard->DrawIce(g, aRenderItem.mBoardGridY); },
        /* [12] RENDER_ITEM_TOP_UI               */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawUITop(g); },
        /* [13] RENDER_ITEM_FOG                  */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawFog(g); },
        /* [14] RENDER_ITEM_STORM                */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->mChallenge->DrawWeather(g); },
        /* [15] RENDER_ITEM_BOTTOM_UI            */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawUIBottom(g); },
        /* [16] RENDER_ITEM_BACKDROP             */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawBackdrop(g); },
        /* [17] RENDER_ITEM_DOOR_MASK            */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawHouseDoorTop(g); },
        /* [18] RENDER_ITEM_COIN_BANK            */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawUICoinBank(g); },
        /* [19] RENDER_ITEM_PROJECTILE_SHADOW    */ [](Board*, Graphics* g, RenderItem& aRenderItem) { Projectile* aProjectile = aRenderItem.mProjectile; if (aProjectile->BeginDraw(g)) { aProjectile->DrawShadow(g); aProjectile->EndDraw(g); } },
        /* [20] RENDER_ITEM_MOWER                */ [](Board*, Graphics* g, RenderItem& aRenderItem) { aRenderItem.mMower->Draw(g); },
        /* [21] RENDER_ITEM_SCREEN_FADE          */ [](Board* aBoard, Graphics* g, RenderItem&) { aBoard->DrawFadeOut(g); },
        /* [22] RENDER_ITEM_BOSS_PART            */ [](Board* aBoard, Graphics* g, RenderItem& aRenderItem) { Zombie* aBossZombie = aBoard->GetBossZombie(); if (aBossZombie && aBossZombie->BeginDraw(g)) { aBossZombie->DrawBossPart(g, aRenderItem.mBossPart); aBossZombie->EndDraw(g); } },
        /* [23] RENDER_ITEM_GRID_ITEM            */ [](Board*, Graphics* g, RenderItem& aRenderItem) { aRenderItem.mGridItem->DrawGridItem(g); },
        /* [24] RENDER_ITEM_GRID_ITEM_OVERLAY    */ [](Board*, Graphics* g, RenderItem& aRenderItem) { aRenderItem.mGridItem->DrawGridItemOverlay(g); },
    };
    static_assert(sizeof(kRenderItemDraws) / sizeof(kRenderItemDraws[0]) == RENDER_ITEM_GRID_ITEM_OVERLAY + 1,
        "渲染项绘制槽位须与 RenderObjectType 枚举尾同步");
    static constexpr int kRenderItemCount = (int)(sizeof(kRenderItemDraws) / sizeof(kRenderItemDraws[0]));
    for (int i = 0; i < aRenderItemCountExt; i++)
    {
        RenderItem& aRenderItem = aRenderListExt[i];
        int aType = (int)aRenderItem.mRenderObjectType;
        if ((unsigned)aType < (unsigned)kRenderItemCount)
        {
            kRenderItemDraws[aType](this, g, aRenderItem);
        }
        else
        {
            TOD_ASSERT(false);
        }
    }
}

// ============================ 输入列表（真实帧形状：25 类型混合；g_list 已前置） ============================
static Board g_board;
static LawnApp g_app;
static ZenGarden g_zen;
static Challenge g_chal;
static Graphics g_gfx;
static Plant g_plant;
static Zombie g_zombie;
static Coin g_coin;
static Projectile g_proj;
static CursorPreview g_cursorPreview;
static TodParticleSystem g_particleSys;
static Reanimation g_reanim;
static GridItem g_gridItem;
static LawnMower g_mower;

static void BuildList()
{
    const RenderObjectType types[32] = {
        RENDER_ITEM_BACKDROP, RENDER_ITEM_DOOR_MASK, RENDER_ITEM_BOTTOM_UI, RENDER_ITEM_PLANT,
        RENDER_ITEM_PLANT, RENDER_ITEM_PLANT, RENDER_ITEM_ZOMBIE, RENDER_ITEM_ZOMBIE,
        RENDER_ITEM_ZOMBIE, RENDER_ITEM_ZOMBIE_SHADOW, RENDER_ITEM_ZOMBIE_SHADOW, RENDER_ITEM_COIN,
        RENDER_ITEM_PROJECTILE, RENDER_ITEM_PROJECTILE, RENDER_ITEM_PROJECTILE_SHADOW, RENDER_ITEM_REANIMATION,
        RENDER_ITEM_PARTICLE, RENDER_ITEM_MOWER, RENDER_ITEM_TOP_UI, RENDER_ITEM_FOG,
        RENDER_ITEM_CURSOR_PREVIEW, RENDER_ITEM_GRID_ITEM, RENDER_ITEM_GRID_ITEM_OVERLAY, RENDER_ITEM_ICE,
        RENDER_ITEM_COIN_BANK, RENDER_ITEM_STORM, RENDER_ITEM_SCREEN_FADE, RENDER_ITEM_PLANT_MAGNET_ITEMS,
        RENDER_ITEM_PLANT_OVERLAY, RENDER_ITEM_ZOMBIE_BUNGEE_TARGET, RENDER_ITEM_BOSS_PART, RENDER_ITEM_PLANT,
    };
    for (int i = 0; i < 32; i++)
    {
        g_list[i].mRenderObjectType = types[i];
        g_list[i].mZPos = i * 17;
        switch (types[i])
        {
        case RENDER_ITEM_PLANT: case RENDER_ITEM_PLANT_OVERLAY: case RENDER_ITEM_PLANT_MAGNET_ITEMS:
            g_list[i].mPlant = &g_plant; break;
        case RENDER_ITEM_ZOMBIE: case RENDER_ITEM_ZOMBIE_SHADOW: case RENDER_ITEM_ZOMBIE_BUNGEE_TARGET: case RENDER_ITEM_BOSS_PART:
            g_list[i].mZombie = &g_zombie; break;
        case RENDER_ITEM_COIN: g_list[i].mCoin = &g_coin; break;
        case RENDER_ITEM_PROJECTILE: case RENDER_ITEM_PROJECTILE_SHADOW: g_list[i].mProjectile = &g_proj; break;
        case RENDER_ITEM_CURSOR_PREVIEW: g_list[i].mCursorPreview = &g_cursorPreview; break;
        case RENDER_ITEM_PARTICLE: g_list[i].mParticleSytem = &g_particleSys; break;
        case RENDER_ITEM_REANIMATION: g_list[i].mReanimation = &g_reanim; break;
        case RENDER_ITEM_GRID_ITEM: case RENDER_ITEM_GRID_ITEM_OVERLAY: g_list[i].mGridItem = &g_gridItem; break;
        case RENDER_ITEM_MOWER: g_list[i].mMower = &g_mower; break;
        case RENDER_ITEM_ICE: g_list[i].mBoardGridY = i % 6; break;
        default: g_list[i].mGameObject = nullptr; break;
        }
    }
}

// Zombie 绘制桩（Board.h 声明；编号桩两形态同参）
__declspec(noinline) void Zombie::DrawShadow(Graphics* g) { ZSink(RID_Coin_Draw, 5); }
__declspec(noinline) void Zombie::DrawReanim(Graphics* g, const ZombieDrawPosition&, int) { ZSink(RID_Coin_Draw, 6); }
__declspec(noinline) void Zombie::DrawBungeeTarget(Graphics* g) { ZSink(RID_Coin_Draw, 7); }
__declspec(noinline) void Zombie::DrawBossPart(Graphics* g, BossPart p) { ZSink(RID_Coin_Draw, 8, (uint32_t)p); }

int main()
{
    BuildList();
    g_board.mApp = &g_app;
    g_app.mBoard = &g_board;
    g_app.mZenGarden = &g_zen;
    g_board.mChallenge = &g_chal;

    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                g_board.DrawGameObjectsDispatch_A(&g_gfx);
                ck = ZBMixU64(ck, i);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                g_board.DrawGameObjectsDispatch_B(&g_gfx);
                ck = ZBMixU64(ck, i);
            }
        };
        rc |= R3BenchMain("t14_DrawGameObjects_kRenderItemDraws", reset, pa, pb);
    }
    return rc;
}
