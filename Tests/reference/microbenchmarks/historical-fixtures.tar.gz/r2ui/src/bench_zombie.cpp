// bench_zombie.cpp -- 目标5  kAdventureLevelAwards(51)  Zombie::TrySpawnLevelAward（结算一次，冷）
//                    目标6  kZombieChewTimes(34)        Zombie::Animate 啃咬音效（啃咬每帧，热）
//                    目标7  kDropHelmCases(10)          Zombie::DropHelm（事件，冷）
// FormA = 36a066a7^ 逐字（链）；FormB = HEAD 逐字（表）。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// ---------------- enums ----------------
enum ZombieType {
    ZOMBIE_NORMAL = 0, ZOMBIE_FLAG, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL,
    ZOMBIE_NEWSPAPER, ZOMBIE_DOOR, ZOMBIE_FOOTBALL, ZOMBIE_DANCER, ZOMBIE_BACKUP_DANCER,
    ZOMBIE_DUCKY_TUBE, ZOMBIE_SNORKEL, ZOMBIE_ZAMBONI, ZOMBIE_BOBSLED, ZOMBIE_DOLPHIN_RIDER,
    ZOMBIE_JACK_IN_THE_BOX, ZOMBIE_BALLOON, ZOMBIE_DIGGER, ZOMBIE_POGO, ZOMBIE_YETI,
    ZOMBIE_BUNGEE, ZOMBIE_LADDER, ZOMBIE_CATAPULT, ZOMBIE_GARGANTUAR, ZOMBIE_IMP,
    ZOMBIE_BOSS, ZOMBIE_PEA_HEAD, ZOMBIE_WALLNUT_HEAD, ZOMBIE_JALAPENO_HEAD, ZOMBIE_GATLING_HEAD,
    ZOMBIE_SQUASH_HEAD, ZOMBIE_TALLNUT_HEAD, ZOMBIE_REDEYE_GARGANTUAR, ZOMBIE_ZOMBATAR,
    NUM_ZOMBIE_TYPES
};
enum HelmType { HELMTYPE_NONE = 0, HELMTYPE_TRAFFIC_CONE, HELMTYPE_PAIL, HELMTYPE_FOOTBALL, HELMTYPE_DIGGER,
    HELMTYPE_REDEYES, HELMTYPE_HEADBAND, HELMTYPE_BOBSLED, HELMTYPE_WALLNUT, HELMTYPE_TALLNUT };
enum ZombiePhase { PHASE_ZOMBIE_NORMAL = 0, PHASE_SNORKEL_UP_TO_EAT, PHASE_JACK_IN_THE_BOX_POPPING,
    PHASE_NEWSPAPER_MADDENING, PHASE_DIGGER_RISING, PHASE_DIGGER_TUNNELING_PAUSE_WITHOUT_AXE,
    PHASE_DIGGER_RISE_WITHOUT_AXE, PHASE_DIGGER_STUNNED, PHASE_OTHER };
enum CoinType { COIN_NONE = 0, COIN_FINAL_SEED_PACKET, COIN_NOTE, COIN_SHOVEL, COIN_ALMANAC,
    COIN_CARKEYS, COIN_TACO, COIN_WATERING_CAN, COIN_AWARD_SILVER_SUNFLOWER,
    COIN_AWARD_MONEY_BAG, COIN_AWARD_GOLD_SUNFLOWER, COIN_TROPHY, COIN_SUN };
enum CoinMotion { COIN_MOTION_COIN = 0, COIN_MOTION_FROM_BOSS };
enum GameMode { GAMEMODE_ADVENTURE = 0, GAMEMODE_CHALLENGE_X = 5, GAMEMODE_SURVIVAL_X = 20, GAMEMODE_OTHER = 40 };

static inline bool TestBit(unsigned int flags, int bit) { return (flags & (1u << bit)) != 0; }
enum DamageFlagsBits { DAMAGE_DOESNT_LEAVE_BODY = 3, DAMAGE_DOESNT_CAUSE_FLASH = 5, DAMAGE_FREEZE = 6 };

// ---------------- stubs ----------------
struct Rect2 { int mX, mY, mWidth, mHeight; };
struct Reanimation2 {
    float mTrigA, mTrigB;
    bool ShouldTriggerTimedEvent(float t) { bool r = mTrigA > t; mTrigA = mTrigB; return r; }
};
static Reanimation2 g_reanim; // Animate 用

struct ChallengeStub {
    bool mScaryPotterCompleted;
    void PuzzlePhaseComplete(int x, int row) { CS(300); CS((uint64_t)x); CS((uint64_t)row); }
    bool ScaryPotterIsCompleted() { return mScaryPotterCompleted; }
};
struct BoardStub {
    bool mHasLevelAwardDropped, mLevelComplete, mAreEnemyZombiesOnScreen, mLevelAwardSpawned;
    bool mSurvivalRepick, mLastStandRepick, mFinalScaryPotter;
    int mCurrentWave, mNumWaves, mLevel, mZombieCountDown;
    ChallengeStub* mChallenge;
    void RemoveAllZombies() { CS(301); }
    void FadeOutLevel() { CS(302); }
    void AddCoin(int x, int y, CoinType t, CoinMotion m) { CS(303); CS((uint64_t)t); CS((uint64_t)m); CS((uint64_t)x); }
    int PixelToGridXKeepOnBoard(float x, float y) { CS(304); return (int)x / 80; }
    bool HasLevelAwardDropped() { return mHasLevelAwardDropped; }
    bool AreEnemyZombiesOnScreen() { return mAreEnemyZombiesOnScreen; }
    bool IsSurvivalStageWithRepick() { return mSurvivalRepick; }
    bool IsLastStandStageWithRepick() { return mLastStandRepick; }
    bool IsFinalScaryPotterStage() { return mFinalScaryPotter; }
};

struct AppStub2 {
    GameMode mGameMode;
    bool mFinalBoss, mScaryPotter, mContinuous, mWhackAZombie, mAdventure, mFinishedAdventure;
    int mBeatenChallenge; int mTrophiesNeeded;
    ChallengeStub* mChallenge;
    bool IsFinalBossLevel() { return mFinalBoss; }
    bool IsScaryPotterLevel() { return mScaryPotter; }
    bool IsContinuousChallenge() { return mContinuous; }
    bool IsWhackAZombieLevel() { return mWhackAZombie; }
    bool IsAdventureMode() { return mAdventure; }
    bool HasFinishedAdventure() { return mFinishedAdventure; }
    bool HasBeatenChallenge(GameMode) { return mBeatenChallenge != 0; }
    int TrophiesNeedForGoldSunflower() { return mTrophiesNeeded; }
    void PlayFoley(int f) { CS(305); CS((uint64_t)f); }
};

struct ZombieDrawPosition { float mImageOffsetX, mImageOffsetY, mHeadX, mHeadY, mBodyY; };
struct ZombieStub {
    AppStub2* mApp; BoardStub* mBoard;
    ZombieType mZombieType; HelmType mHelmType; ZombiePhase mZombiePhase;
    bool mDroppedLoot, mIsEating, mHasHead, mYuckyFace, mMindControlled, mOnBoard, mImmobilized;
    int mAnimCounter, mAnimFrames, mFrame, mPrevFrame, mChilledCounter, mRenderOrder;
    int mRow;
    float mPosX, mPosY;
    Reanimation2* mBodyReanim;
    ZombieDrawPosition* mDrawPos;
    int mAnimTicksPerFrame;

    bool IsOnBoard() { return mOnBoard; }
    bool IsImmobilizied() { return mImmobilized; }
    void UpdateYuckyFace() { CS(306); }
    void AnimateChewSound() { CS(307); }
    void AnimateChewEffect() { CS(308); }
    void BobsledCrash() { CS(309); }
    Rect2 GetZombieRect() { CS(310); return Rect2{ (int)mPosX, (int)mPosY, 80, 120 }; }
    // DropHelm 辅助
    void GetTrackPosition(int trackId, float& x, float& y) { CS(311); CS((uint64_t)trackId); x += trackId; }
    void ReanimShowRange(int rangeId, int group) { CS(312); CS((uint64_t)rangeId); CS((uint64_t)group); }
    void ReanimShowTrack(int trackId, int group) { CS(313); CS((uint64_t)trackId); CS((uint64_t)group); }
};
static void GetDrawPos(ZombieStub& z, ZombieDrawPosition& p) { p = *z.mDrawPos; }
struct TodParticleDummy { int x; };

static void OverrideParticleScale(TodParticleDummy*) { CS(314); }
static TodParticleDummy g_dummyParticle;
static TodParticleDummy* AddTodParticle(float x, float y, int layer, int effect) { CS(315); CS((uint64_t)effect); return &g_dummyParticle; }

// ================= FormA (36a066a7^) =================
namespace FormA {
__declspec(noinline) void ZombieAnimate(ZombieStub& m)
{
    m.mPrevFrame = m.mFrame;
    if (m.mZombiePhase == PHASE_JACK_IN_THE_BOX_POPPING ||
        m.mZombiePhase == PHASE_NEWSPAPER_MADDENING ||
        m.mZombiePhase == PHASE_DIGGER_RISING ||
        m.mZombiePhase == PHASE_DIGGER_TUNNELING_PAUSE_WITHOUT_AXE ||
        m.mZombiePhase == PHASE_DIGGER_RISE_WITHOUT_AXE ||
        m.mZombiePhase == PHASE_DIGGER_STUNNED ||
        m.IsImmobilizied())
        return;

    m.mAnimCounter++;
    if (m.mYuckyFace)
    {
        m.UpdateYuckyFace();
    }

    if (m.mIsEating && m.mHasHead)
    {
        int aFrameLength = 6;
        if (m.mChilledCounter > 0)
        {
            aFrameLength = 12;
        }
        if (m.mAnimCounter >= m.mAnimFrames * aFrameLength)
        {
            m.mAnimCounter = aFrameLength;
        }
        m.mFrame = m.mAnimCounter / aFrameLength;

        Reanimation2* aBodyReanim = m.mBodyReanim;
        if (aBodyReanim)
        {
            float aLeftHandTime = 0.14f;
            float aRightHandTime = 0.68f;
            if (m.mZombieType == ZOMBIE_POLEVAULTER)
            {
                aLeftHandTime = 0.38f;
                aRightHandTime = 0.8f;
            }
            else if (m.mZombieType == ZOMBIE_NEWSPAPER || m.mZombieType == ZOMBIE_LADDER)
            {
                aLeftHandTime = 0.42f;
                aRightHandTime = 0.42f;
            }
            else if (m.mZombieType == ZOMBIE_JACK_IN_THE_BOX)
            {
                aLeftHandTime = 0.53f;
                aRightHandTime = 0.53f;
            }
            else if (m.mZombieType == ZOMBIE_BOBSLED)
            {
                aLeftHandTime = 0.33f;
                aRightHandTime = 0.83f;
            }
            else if (m.mZombieType == ZOMBIE_IMP)
            {
                aLeftHandTime = 0.33f;
                aRightHandTime = 0.79f;
            }

            if (aBodyReanim->ShouldTriggerTimedEvent(aLeftHandTime) || aBodyReanim->ShouldTriggerTimedEvent(aRightHandTime))
            {
                m.AnimateChewSound();
                m.AnimateChewEffect();
            }
        }
        else
        {
            if (m.mAnimCounter == 4 * aFrameLength)
            {
                m.AnimateChewSound();
            }
            if (m.mAnimCounter == 7 * aFrameLength && !m.mMindControlled)
            {
                m.AnimateChewEffect();
            }
        }
    }
    else
    {
        if (m.mAnimCounter >= m.mAnimFrames * m.mAnimTicksPerFrame)
        {
            m.mAnimCounter = 0;
        }
        m.mFrame = m.mAnimCounter / m.mAnimTicksPerFrame;
    }
}

__declspec(noinline) bool TrySpawnLevelAward(ZombieStub& m)
{
    if (!m.IsOnBoard() || m.mBoard->HasLevelAwardDropped() || m.mBoard->mLevelComplete || m.mDroppedLoot)
    {
        return false;
    }

    if (m.mApp->IsFinalBossLevel())
    {
        if (m.mZombieType != ZOMBIE_BOSS)
        {
            return false;
        }
    }
    else if (m.mApp->IsScaryPotterLevel())
    {
        if (!m.mBoard->mChallenge->ScaryPotterIsCompleted())
        {
            return false;
        }
    }
    else if (m.mApp->IsContinuousChallenge() || m.mBoard->mCurrentWave < m.mBoard->mNumWaves || m.mBoard->AreEnemyZombiesOnScreen())
    {
        return false;
    }

    if (m.mApp->IsWhackAZombieLevel() && m.mBoard->mZombieCountDown > 0)
    {
        return false;
    }

    m.mBoard->mLevelAwardSpawned = true;
    CS(320); // mApp->mBoardResult = BOARDRESULT_WON（编号空桩）

    Rect2 aZombieRect = m.GetZombieRect();
    int aCenterX = aZombieRect.mX + aZombieRect.mWidth / 2;
    int aCenterY = aZombieRect.mY + aZombieRect.mHeight / 2;

    if (!m.mBoard->IsSurvivalStageWithRepick())
    {
        m.mBoard->RemoveAllZombies();
    }

    CoinType aCoinType;
    if (m.mApp->IsScaryPotterLevel() && !m.mBoard->IsFinalScaryPotterStage())
    {
        aCoinType = COIN_NONE;
        m.mBoard->mChallenge->PuzzlePhaseComplete(m.mBoard->PixelToGridXKeepOnBoard(m.mPosX + 75, m.mPosY), m.mRow);
    }
    else if (m.mApp->IsAdventureMode() && m.mBoard->mLevel <= 50)
    {
        if (m.mBoard->mLevel == 9 || m.mBoard->mLevel == 19 || m.mBoard->mLevel == 29 || m.mBoard->mLevel == 39 || m.mBoard->mLevel == 49)
        {
            aCoinType = COIN_NOTE;
        }
        else if (m.mBoard->mLevel == 50)
        {
            aCoinType = m.mApp->HasFinishedAdventure() ? COIN_AWARD_MONEY_BAG : COIN_AWARD_SILVER_SUNFLOWER;
        }
        else if (m.mApp->HasFinishedAdventure())
        {
            aCoinType = COIN_AWARD_MONEY_BAG;
        }
        else if (m.mBoard->mLevel == 4)
        {
            aCoinType = COIN_SHOVEL;
        }
        else if (m.mBoard->mLevel == 14)
        {
            aCoinType = COIN_ALMANAC;
        }
        else if (m.mBoard->mLevel == 24)
        {
            aCoinType = COIN_CARKEYS;
        }
        else if (m.mBoard->mLevel == 34)
        {
            aCoinType = COIN_TACO;
        }
        else if (m.mBoard->mLevel == 44)
        {
            aCoinType = COIN_WATERING_CAN;
        }
        else
        {
            aCoinType = COIN_FINAL_SEED_PACKET;
        }
    }
    else if (m.mBoard->IsSurvivalStageWithRepick())
    {
        aCoinType = COIN_NONE;
        m.mBoard->FadeOutLevel();
    }
    else if (m.mBoard->IsLastStandStageWithRepick())
    {
        aCoinType = COIN_NONE;
        m.mBoard->FadeOutLevel();
        m.mApp->PlayFoley(6);
        for (int i = 0; i < 10; i++)
        {
            m.mBoard->AddCoin(aCenterX + i * 5, aCenterY, COIN_SUN, COIN_MOTION_COIN);
        }
    }
    else if (!m.mApp->IsAdventureMode())
    {
        if (m.mApp->HasBeatenChallenge(m.mApp->mGameMode))
        {
            aCoinType = COIN_AWARD_MONEY_BAG;
        }
        else if (m.mApp->TrophiesNeedForGoldSunflower() == 1)
        {
            aCoinType = COIN_AWARD_GOLD_SUNFLOWER;
        }
        else
        {
            aCoinType = COIN_TROPHY;
        }
    }
    else
    {
        aCoinType = COIN_AWARD_MONEY_BAG;
    }

    CoinMotion aCoinMotion = COIN_MOTION_COIN;
    if (m.mZombieType == ZOMBIE_BOSS)
    {
        aCoinMotion = COIN_MOTION_FROM_BOSS;
    }

    if (aCoinType != COIN_NONE)
    {
        m.mApp->PlayFoley(6);
        m.mBoard->AddCoin(aCenterX, aCenterY, aCoinType, aCoinMotion);
    }

    m.mDroppedLoot = true;
    return true;
}

__declspec(noinline) void DropHelm(ZombieStub& m, unsigned int theDamageFlags)
{
    if (m.mHelmType == HELMTYPE_NONE)
        return;

    ZombieDrawPosition aDrawPos;
    GetDrawPos(m, aDrawPos);
    float aPosX = m.mPosX + aDrawPos.mImageOffsetX + aDrawPos.mHeadX + 14.0f;
    float aPosY = m.mPosY + aDrawPos.mImageOffsetY + aDrawPos.mHeadY + aDrawPos.mBodyY + 18.0f;
    int aEffect = 0;
    if (m.mHelmType == HELMTYPE_TRAFFIC_CONE)
    {
        m.GetTrackPosition(10, aPosX, aPosY);
        m.ReanimShowRange(110, 1);
        m.ReanimShowRange(111, 0);
        aEffect = 1;
    }
    else if (m.mHelmType == HELMTYPE_PAIL)
    {
        m.GetTrackPosition(11, aPosX, aPosY);
        m.ReanimShowRange(112, 1);
        m.ReanimShowRange(111, 0);
        aEffect = 2;
    }
    else if (m.mHelmType == HELMTYPE_FOOTBALL)
    {
        m.GetTrackPosition(12, aPosX, aPosY);
        m.ReanimShowRange(113, 1);
        m.ReanimShowRange(111, 0);
        aEffect = 3;
    }
    else if (m.mHelmType == HELMTYPE_DIGGER)
    {
        m.GetTrackPosition(13, aPosX, aPosY);
        m.ReanimShowTrack(13, 1);
        aEffect = 4;
    }
    else if (m.mHelmType == HELMTYPE_BOBSLED && !TestBit(theDamageFlags, DAMAGE_DOESNT_LEAVE_BODY))
    {
        m.BobsledCrash();
    }

    if (!TestBit(theDamageFlags, DAMAGE_DOESNT_LEAVE_BODY) && aEffect != 0)
    {
        TodParticleDummy* aParticle = AddTodParticle(aPosX, aPosY, m.mRenderOrder + 1, aEffect);
        OverrideParticleScale(aParticle);
    }

    m.mHelmType = HELMTYPE_NONE;
}
} // namespace FormA

// ================= FormB (HEAD) =================
namespace FormB {
namespace {
using DropHelmCaseFn = void (*)(ZombieStub&, float&, float&, unsigned int, int&);
// 轨 id / 区间 id 与 FormA 桩号一致
void DropHelmTakeProp(ZombieStub& z, float& thePosX, float& thePosY, int& theEffect,
    int theTrackId, int theTrackRange, int theParticleEffect)
{
    z.GetTrackPosition(theTrackId, thePosX, thePosY);
    z.ReanimShowRange(theTrackRange, 1);
    z.ReanimShowRange(111, 0);
    theEffect = theParticleEffect;
}
constexpr DropHelmCaseFn kDropHelmCases[(int)HELMTYPE_TALLNUT + 1] = {
    nullptr,
    [](ZombieStub& z, float& x, float& y, unsigned int, int& e)
    { DropHelmTakeProp(z, x, y, e, 10, 110, 1); },
    [](ZombieStub& z, float& x, float& y, unsigned int, int& e)
    { DropHelmTakeProp(z, x, y, e, 11, 112, 2); },
    [](ZombieStub& z, float& x, float& y, unsigned int, int& e)
    { DropHelmTakeProp(z, x, y, e, 12, 113, 3); },
    [](ZombieStub& z, float& x, float& y, unsigned int, int& e)
    { z.GetTrackPosition(13, x, y); z.ReanimShowTrack(13, 1); e = 4; },
    nullptr,
    nullptr,
    [](ZombieStub& z, float&, float&, unsigned int theDamageFlags, int&)
    {
        if (!TestBit(theDamageFlags, DAMAGE_DOESNT_LEAVE_BODY))
        {
            z.BobsledCrash();
        }
    },
    nullptr,
    nullptr,
};
} // namespace

__declspec(noinline) void DropHelm(ZombieStub& m, unsigned int theDamageFlags)
{
    if (m.mHelmType == HELMTYPE_NONE)
        return;

    ZombieDrawPosition aDrawPos;
    GetDrawPos(m, aDrawPos);
    float aPosX = m.mPosX + aDrawPos.mImageOffsetX + aDrawPos.mHeadX + 14.0f;
    float aPosY = m.mPosY + aDrawPos.mImageOffsetY + aDrawPos.mHeadY + aDrawPos.mBodyY + 18.0f;
    int aEffect = 0;
    const unsigned aHelmIndex = static_cast<unsigned>(m.mHelmType);
    if (aHelmIndex < sizeof(kDropHelmCases) / sizeof(kDropHelmCases[0]) &&
        kDropHelmCases[aHelmIndex] != nullptr)
    {
        kDropHelmCases[aHelmIndex](m, aPosX, aPosY, theDamageFlags, aEffect);
    }

    if (!TestBit(theDamageFlags, DAMAGE_DOESNT_LEAVE_BODY) && aEffect != 0)
    {
        TodParticleDummy* aParticle = AddTodParticle(aPosX, aPosY, m.mRenderOrder + 1, aEffect);
        OverrideParticleScale(aParticle);
    }

    m.mHelmType = HELMTYPE_NONE;
}

__declspec(noinline) void ZombieAnimate(ZombieStub& m)
{
    m.mPrevFrame = m.mFrame;
    if (m.mZombiePhase == PHASE_JACK_IN_THE_BOX_POPPING ||
        m.mZombiePhase == PHASE_NEWSPAPER_MADDENING ||
        m.mZombiePhase == PHASE_DIGGER_RISING ||
        m.mZombiePhase == PHASE_DIGGER_TUNNELING_PAUSE_WITHOUT_AXE ||
        m.mZombiePhase == PHASE_DIGGER_RISE_WITHOUT_AXE ||
        m.mZombiePhase == PHASE_DIGGER_STUNNED ||
        m.IsImmobilizied())
        return;

    m.mAnimCounter++;
    if (m.mYuckyFace)
    {
        m.UpdateYuckyFace();
    }

    if (m.mIsEating && m.mHasHead)
    {
        int aFrameLength = 6;
        if (m.mChilledCounter > 0)
        {
            aFrameLength = 12;
        }
        if (m.mAnimCounter >= m.mAnimFrames * aFrameLength)
        {
            m.mAnimCounter = aFrameLength;
        }
        m.mFrame = m.mAnimCounter / aFrameLength;

        Reanimation2* aBodyReanim = m.mBodyReanim;
        if (aBodyReanim)
        {
            // B 形态 -> 常量表 kZombieChewTimes：行序 = ZombieType 枚举序，无 case 槽 = 默认值
            static constexpr struct { float mLeft; float mRight; } kZombieChewTimes[(int)NUM_ZOMBIE_TYPES] = {
                { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.38f, 0.80f }, { 0.14f, 0.68f },
                { 0.42f, 0.42f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f },
                { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.33f, 0.83f }, { 0.14f, 0.68f },
                { 0.53f, 0.53f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f },
                { 0.14f, 0.68f }, { 0.42f, 0.42f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.33f, 0.79f },
                { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f },
                { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f }, { 0.14f, 0.68f },
            };

            float aLeftHandTime = 0.14f;
            float aRightHandTime = 0.68f;
            const unsigned aTypeIndex = static_cast<unsigned>(m.mZombieType);
            if (aTypeIndex < sizeof(kZombieChewTimes) / sizeof(kZombieChewTimes[0]))
            {
                aLeftHandTime = kZombieChewTimes[aTypeIndex].mLeft;
                aRightHandTime = kZombieChewTimes[aTypeIndex].mRight;
            }

            if (aBodyReanim->ShouldTriggerTimedEvent(aLeftHandTime) || aBodyReanim->ShouldTriggerTimedEvent(aRightHandTime))
            {
                m.AnimateChewSound();
                m.AnimateChewEffect();
            }
        }
        else
        {
            if (m.mAnimCounter == 4 * aFrameLength)
            {
                m.AnimateChewSound();
            }
            if (m.mAnimCounter == 7 * aFrameLength && !m.mMindControlled)
            {
                m.AnimateChewEffect();
            }
        }
    }
    else
    {
        if (m.mAnimCounter >= m.mAnimFrames * m.mAnimTicksPerFrame)
        {
            m.mAnimCounter = 0;
        }
        m.mFrame = m.mAnimCounter / m.mAnimTicksPerFrame;
    }
}

__declspec(noinline) bool TrySpawnLevelAward(ZombieStub& m)
{
    if (!m.IsOnBoard() || m.mBoard->HasLevelAwardDropped() || m.mBoard->mLevelComplete || m.mDroppedLoot)
    {
        return false;
    }

    if (m.mApp->IsFinalBossLevel())
    {
        if (m.mZombieType != ZOMBIE_BOSS)
        {
            return false;
        }
    }
    else if (m.mApp->IsScaryPotterLevel())
    {
        if (!m.mBoard->mChallenge->ScaryPotterIsCompleted())
        {
            return false;
        }
    }
    else if (m.mApp->IsContinuousChallenge() || m.mBoard->mCurrentWave < m.mBoard->mNumWaves || m.mBoard->AreEnemyZombiesOnScreen())
    {
        return false;
    }

    if (m.mApp->IsWhackAZombieLevel() && m.mBoard->mZombieCountDown > 0)
    {
        return false;
    }

    m.mBoard->mLevelAwardSpawned = true;
    CS(320);

    Rect2 aZombieRect = m.GetZombieRect();
    int aCenterX = aZombieRect.mX + aZombieRect.mWidth / 2;
    int aCenterY = aZombieRect.mY + aZombieRect.mHeight / 2;

    if (!m.mBoard->IsSurvivalStageWithRepick())
    {
        m.mBoard->RemoveAllZombies();
    }

    CoinType aCoinType;
    if (m.mApp->IsScaryPotterLevel() && !m.mBoard->IsFinalScaryPotterStage())
    {
        aCoinType = COIN_NONE;
        m.mBoard->mChallenge->PuzzlePhaseComplete(m.mBoard->PixelToGridXKeepOnBoard(m.mPosX + 75, m.mPosY), m.mRow);
    }
    else if (m.mApp->IsAdventureMode() && m.mBoard->mLevel <= 50)
    {
        // B 形态 -> 常量表 kAdventureLevelAwards：关卡号直下标，NOTE 不受通关覆盖
        static constexpr CoinType kAdventureLevelAwards[51] = {
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_SHOVEL,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_NOTE,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_ALMANAC,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_NOTE,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_CARKEYS,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_NOTE,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_TACO,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_NOTE,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_WATERING_CAN,
            COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_FINAL_SEED_PACKET, COIN_NOTE,
            COIN_AWARD_SILVER_SUNFLOWER,
        };

        const unsigned aLevelIndex = static_cast<unsigned>(m.mBoard->mLevel);
        const CoinType aLevelAward = aLevelIndex < 51 ?
            kAdventureLevelAwards[aLevelIndex] : COIN_FINAL_SEED_PACKET;
        if (aLevelAward == COIN_NOTE)
        {
            aCoinType = aLevelAward;
        }
        else
        {
            aCoinType = m.mApp->HasFinishedAdventure() ? COIN_AWARD_MONEY_BAG : aLevelAward;
        }
    }
    else if (m.mBoard->IsSurvivalStageWithRepick())
    {
        aCoinType = COIN_NONE;
        m.mBoard->FadeOutLevel();
    }
    else if (m.mBoard->IsLastStandStageWithRepick())
    {
        aCoinType = COIN_NONE;
        m.mBoard->FadeOutLevel();
        m.mApp->PlayFoley(6);
        for (int i = 0; i < 10; i++)
        {
            m.mBoard->AddCoin(aCenterX + i * 5, aCenterY, COIN_SUN, COIN_MOTION_COIN);
        }
    }
    else if (!m.mApp->IsAdventureMode())
    {
        if (m.mApp->HasBeatenChallenge(m.mApp->mGameMode))
        {
            aCoinType = COIN_AWARD_MONEY_BAG;
        }
        else if (m.mApp->TrophiesNeedForGoldSunflower() == 1)
        {
            aCoinType = COIN_AWARD_GOLD_SUNFLOWER;
        }
        else
        {
            aCoinType = COIN_TROPHY;
        }
    }
    else
    {
        aCoinType = COIN_AWARD_MONEY_BAG;
    }

    CoinMotion aCoinMotion = COIN_MOTION_COIN;
    if (m.mZombieType == ZOMBIE_BOSS)
    {
        aCoinMotion = COIN_MOTION_FROM_BOSS;
    }

    if (aCoinType != COIN_NONE)
    {
        m.mApp->PlayFoley(6);
        m.mBoard->AddCoin(aCenterX, aCenterY, aCoinType, aCoinMotion);
    }

    m.mDroppedLoot = true;
    return true;
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];
static ZombieStub g_z;
static ZombieDrawPosition g_dp;

typedef void (*AnimateFn)(ZombieStub&);
typedef bool (*AwardFn)(ZombieStub&);
typedef void (*HelmFn)(ZombieStub&, unsigned int);

static uint64_t RunAnimate(AnimateFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++)
    {
        uint32_t v = g_in[i];
        g_z.mZombiePhase = (ZombiePhase)((v >> 3) % 9);
        g_z.mImmobilized = ((v >> 8) & 1) != 0;
        g_z.mYuckyFace = ((v >> 9) & 1) != 0;
        g_z.mIsEating = ((v >> 10) & 3) != 0;
        g_z.mHasHead = ((v >> 12) & 3) != 0;
        g_z.mChilledCounter = (int)((v >> 14) & 1);
        g_z.mAnimCounter = (int)((v >> 16) & 63);
        g_z.mAnimFrames = 12;
        g_z.mAnimTicksPerFrame = 6;
        g_z.mZombieType = (ZombieType)((v >> 22) % 35); // 34 = 越界键回落默认
        g_z.mMindControlled = ((v >> 27) & 1) != 0;
        g_reanim.mTrigA = (float)((v >> 5) & 255) * 0.003f;
        g_reanim.mTrigB = (float)((v >> 18) & 255) * 0.003f;
        g_z.mBodyReanim = &g_reanim;
        fn(g_z);
    }
    return g_cs;
}

static uint64_t RunAward(AwardFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++)
    {
        uint32_t v = g_in[i];
        g_z.mOnBoard = true;
        g_z.mDroppedLoot = false;
        g_z.mZombieType = (ZombieType)((v >> 26) % 34);
        g_z.mApp->mFinalBoss = ((v >> 2) & 1) != 0 && g_z.mZombieType == ZOMBIE_BOSS;
        g_z.mApp->mScaryPotter = ((v >> 4) & 1) != 0;
        g_z.mBoard->mChallenge->mScaryPotterCompleted = ((v >> 5) & 1) != 0;
        g_z.mApp->mContinuous = ((v >> 6) & 1) != 0;
        g_z.mBoard->mHasLevelAwardDropped = false;
        g_z.mBoard->mLevelComplete = false;
        g_z.mBoard->mAreEnemyZombiesOnScreen = ((v >> 7) & 1) != 0;
        g_z.mApp->mWhackAZombie = false;
        g_z.mBoard->mZombieCountDown = 0;
        g_z.mBoard->mCurrentWave = 5;
        g_z.mBoard->mNumWaves = 5;
        g_z.mBoard->mSurvivalRepick = false;
        g_z.mBoard->mLastStandRepick = ((v >> 9) & 1) != 0;
        g_z.mBoard->mFinalScaryPotter = ((v >> 10) & 1) != 0;
        g_z.mApp->mAdventure = ((v >> 11) & 1) != 0;
        g_z.mBoard->mLevel = (int)((v >> 13) % 52); // 0..51（51 = 越界走 default）
        g_z.mApp->mFinishedAdventure = ((v >> 19) & 1) != 0;
        g_z.mApp->mBeatenChallenge = (int)((v >> 20) & 1);
        g_z.mApp->mTrophiesNeeded = (int)((v >> 21) & 3);
        g_z.mPosX = (float)(v & 63);
        g_z.mRow = (int)((v >> 22) & 7);
        fn(g_z);
    }
    return g_cs;
}

static uint64_t RunHelm(HelmFn fn)
{
    g_cs = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < N; i++)
    {
        uint32_t v = g_in[i];
        g_z.mHelmType = (HelmType)((v >> 2) % 11); // 10 = 越界
        g_z.mPosX = (float)(v & 31);
        g_z.mPosY = (float)((v >> 6) & 31);
        fn(g_z, v & 0xFFu); // damage flags 含 DOESNT_LEAVE_BODY 位随机
    }
    return g_cs;
}

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    LCG rng{ 0x13198A2E03707344ULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();

    static AppStub2 app; static BoardStub board; static ChallengeStub chal;
    app.mChallenge = &chal; board.mChallenge = &chal;
    g_z.mApp = &app; g_z.mBoard = &board;
    g_dp.mImageOffsetX = 3; g_dp.mImageOffsetY = 4; g_dp.mHeadX = 5; g_dp.mHeadY = 6; g_dp.mBodyY = 7;
    g_z.mDrawPos = &g_dp;
    g_z.mRenderOrder = 100;

    {
        uint64_t csA = RunAnimate(FormA::ZombieAnimate), csB = RunAnimate(FormB::ZombieAnimate);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunAnimate(FormA::ZombieAnimate); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunAnimate(FormB::ZombieAnimate); }) / N * 1e9;
        }
        Report("t6 kZombieChewTimes(34) Zombie::Animate", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    {
        uint64_t csA = RunAward(FormA::TrySpawnLevelAward), csB = RunAward(FormB::TrySpawnLevelAward);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunAward(FormA::TrySpawnLevelAward); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunAward(FormB::TrySpawnLevelAward); }) / N * 1e9;
        }
        Report("t5 kAdventureLevelAwards(51) TrySpawnLevelAward", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    {
        uint64_t csA = RunHelm(FormA::DropHelm), csB = RunHelm(FormB::DropHelm);
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([] { RunHelm(FormA::DropHelm); }) / N * 1e9;
            r[rd][1] = TimeMin5([] { RunHelm(FormB::DropHelm); }) / N * 1e9;
        }
        Report("t7 kDropHelmCases(10) Zombie::DropHelm", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
