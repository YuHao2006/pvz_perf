// bench_t05 — kZombiePreloadExtras 34x3 -> Zombie::PreloadZombieResources（装载期冷）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::PreloadZombieResources_A(ZombieType theZombieType)
{
    const ZombieDefinition& aZombieDef = GetZombieDefinition(theZombieType);
    if (aZombieDef.mReanimationType != ReanimationType::REANIM_NONE)
    {
        ReanimatorEnsureDefinitionLoaded(aZombieDef.mReanimationType, true);
    }

    if (theZombieType == ZombieType::ZOMBIE_DIGGER)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_DIGGER_DIRT, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED_DIGGER, true);
    }
    else if (theZombieType == ZombieType::ZOMBIE_BOSS)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BOSS_DRIVER, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BOSS_FIREBALL, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BOSS_ICEBALL, true);

        for (size_t i = 0; i < LENGTH(gBossZombieList); i++)
        {
            const ZombieDefinition& aDef = GetZombieDefinition(gBossZombieList[i]);
            ReanimatorEnsureDefinitionLoaded(aDef.mReanimationType, true);
        }
    }
    else if (theZombieType == ZombieType::ZOMBIE_DANCER)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BACKUP_DANCER, true);
    }
    else if (theZombieType == ZombieType::ZOMBIE_GARGANTUAR || theZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_IMP, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED_IMP, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED_GARGANTUAR, true);
    }
    else if (theZombieType == ZombieType::ZOMBIE_ZAMBONI)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_IMP, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED_ZAMBONI, true);
    }
    else if (theZombieType == ZombieType::ZOMBIE_CATAPULT)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED_CATAPULT, true);
    }

    ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_PUFF, true);
    ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED, true);
    ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_LAWN_MOWERED_ZOMBIE, true);
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::PreloadZombieResources_B(ZombieType theZombieType)
{
    const ZombieDefinition& aZombieDef = GetZombieDefinition(theZombieType);
    if (aZombieDef.mReanimationType != ReanimationType::REANIM_NONE)
    {
        ReanimatorEnsureDefinitionLoaded(aZombieDef.mReanimationType, true);
    }

    // B 形态 -> 常量二维表 kZombiePreloadExtras（原 6 支链合并）：行序 =
    // ZombieType 枚举序 0..33，每行至多 3 个附加 reanim 定义，REANIM_NONE =
    // 行尾哨兵/无 case。GARGANTUAR/REDEYE 共体同值填两槽；BOSS 支含
    // gBossZombieList 循环装载，异构特例表外保留（表前 if）。
    static constexpr ReanimationType kZombiePreloadExtras[(int)ZombieType::NUM_ZOMBIE_TYPES][3] = {
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 0 ZOMBIE_NORMAL（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 1 ZOMBIE_FLAG（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 2 ZOMBIE_TRAFFIC_CONE（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 3 ZOMBIE_POLEVAULTER（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 4 ZOMBIE_PAIL（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 5 ZOMBIE_NEWSPAPER（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 6 ZOMBIE_DOOR（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 7 ZOMBIE_FOOTBALL（无 case）
        { ReanimationType::REANIM_BACKUP_DANCER, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 8 ZOMBIE_DANCER
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 9 ZOMBIE_BACKUP_DANCER（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 10 ZOMBIE_DUCKY_TUBE（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 11 ZOMBIE_SNORKEL（无 case）
        { ReanimationType::REANIM_IMP, ReanimationType::REANIM_ZOMBIE_CHARRED_ZAMBONI, ReanimationType::REANIM_NONE },  // 12 ZOMBIE_ZAMBONI
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 13 ZOMBIE_BOBSLED（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 14 ZOMBIE_DOLPHIN_RIDER（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 15 ZOMBIE_JACK_IN_THE_BOX（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 16 ZOMBIE_BALLOON（无 case）
        { ReanimationType::REANIM_DIGGER_DIRT, ReanimationType::REANIM_ZOMBIE_CHARRED_DIGGER, ReanimationType::REANIM_NONE },  // 17 ZOMBIE_DIGGER
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 18 ZOMBIE_POGO（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 19 ZOMBIE_YETI（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 20 ZOMBIE_BUNGEE（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 21 ZOMBIE_LADDER（无 case）
        { ReanimationType::REANIM_ZOMBIE_CHARRED_CATAPULT, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 22 ZOMBIE_CATAPULT
        { ReanimationType::REANIM_IMP, ReanimationType::REANIM_ZOMBIE_CHARRED_IMP, ReanimationType::REANIM_ZOMBIE_CHARRED_GARGANTUAR },  // 23 ZOMBIE_GARGANTUAR
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 24 ZOMBIE_IMP（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 25 ZOMBIE_BOSS（特例表外，槽位不可达）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 26 ZOMBIE_PEA_HEAD（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 27 ZOMBIE_WALLNUT_HEAD（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 28 ZOMBIE_JALAPENO_HEAD（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 29 ZOMBIE_GATLING_HEAD（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 30 ZOMBIE_SQUASH_HEAD（无 case）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 31 ZOMBIE_TALLNUT_HEAD（无 case）
        { ReanimationType::REANIM_IMP, ReanimationType::REANIM_ZOMBIE_CHARRED_IMP, ReanimationType::REANIM_ZOMBIE_CHARRED_GARGANTUAR },  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
        { ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE, ReanimationType::REANIM_NONE },  // 33 ZOMBIE_ZOMBATAR（无 case）
    };
    static_assert(sizeof(kZombiePreloadExtras) / sizeof(kZombiePreloadExtras[0]) ==
        (int)ZombieType::NUM_ZOMBIE_TYPES, "kZombiePreloadExtras 槽位须与 ZombieType 枚举同步");

    if (theZombieType == ZombieType::ZOMBIE_BOSS)
    {
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BOSS_DRIVER, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BOSS_FIREBALL, true);
        ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_BOSS_ICEBALL, true);

        for (size_t i = 0; i < LENGTH(gBossZombieList); i++)
        {
            const ZombieDefinition& aDef = GetZombieDefinition(gBossZombieList[i]);
            ReanimatorEnsureDefinitionLoaded(aDef.mReanimationType, true);
        }
    }
    else
    {
        const unsigned aTypeIndex = static_cast<unsigned>(theZombieType);
        if (aTypeIndex < sizeof(kZombiePreloadExtras) / sizeof(kZombiePreloadExtras[0]))
        {
            for (ReanimationType aExtraType : kZombiePreloadExtras[aTypeIndex])
            {
                if (aExtraType == ReanimationType::REANIM_NONE)  // 行尾哨兵
                {
                    break;
                }
                ReanimatorEnsureDefinitionLoaded(aExtraType, true);
            }
        }
    }

    ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_PUFF, true);
    ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_ZOMBIE_CHARRED, true);
    ReanimatorEnsureDefinitionLoaded(ReanimationType::REANIM_LAWN_MOWERED_ZOMBIE, true);
}

static Zombie g_z;
static void InitDefs()
{
    for (int i = 0; i < NUM_ZOMBIE_TYPES; i++)
    {
        g_zb_zombieDefs[i].mZombieType = (ZombieType)i;
        // 5/6 概率非 NONE（首装载支命中），REANIM_NONE 走跳过支
        g_zb_zombieDefs[i].mReanimationType = (ReanimationType)((i % 6 == 5) ? (int)ReanimationType::REANIM_NONE : 40 + i);
    }
}

int main()
{
    InitDefs();
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ZombieType t = (ZombieType)(g_zb_inputs[i].a % 34);
            g_z.PreloadZombieResources_A(t);
            ck = ZBMixU64(ck, (uint64_t)t);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ZombieType t = (ZombieType)(g_zb_inputs[i].a % 34);
            g_z.PreloadZombieResources_B(t);
            ck = ZBMixU64(ck, (uint64_t)t);
        }
    };
    return ZBenchMain("t05_PreloadZombieRes", passA, passB);
}
