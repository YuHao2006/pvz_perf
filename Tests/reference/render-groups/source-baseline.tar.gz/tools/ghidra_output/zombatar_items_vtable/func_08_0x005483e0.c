
void FUN_005483e0(undefined4 param_1,undefined4 param_2)

{
  undefined1 local_5;
  
  local_5 = 0;
  FUN_005482f0(param_1,param_2,&local_5);
  return;
}

