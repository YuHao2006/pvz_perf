// r3_entities.h — 实体桩（第三段）：Zombie / Plant / CursorObject /
// MessageWidget / StoreScreen / Music / Coin / AlmanacDialog
#pragma once
#include "r3_stubs.h"

// ============================ Zombie 桩 ============================
struct Zombie
{
    // ZOMBIE_WAVE_* 常量（仓库 Zombie.h 真值）
    static constexpr int ZOMBIE_WAVE_UI = -2;
    static constexpr int ZOMBIE_WAVE_CUTSCENE = -3;
    static constexpr int ZOMBIE_WAVE_WINNER = -1;

    // ---- 字段（目标函数读写集） ----
    LawnApp* mApp;
    Board* mBoard;
    ZombieType mZombieType;
    ZombiePhase mZombiePhase;
    ZombieHeight mZombieHeight;
    int mX, mY;
    float mPosX, mPosY;
    float mVelX;
    float mVelZ;
    float mAltitude;
    bool mInPool, mIsEating, mHasHead, mHasArm, mHasObject, mDead, mMindControlled;
    int mFrame, mPrevFrame, mRow, mRenderOrder, mFromWave, mPhaseCounter;
    ReanimationID mBodyReanimID, mSpecialHeadReanimID, mMoweredReanimID, mBossFireBallReanimID, mZombatarHeadReanimID;
    AttachmentID mAttachmentID;
    ZombieID mRelatedZombieID;
    ZombieID mFollowerZombieID[MAX_ZOMBIE_FOLLOWERS];
    HelmType mHelmType;
    int mHelmHealth, mHelmMaxHealth;
    ShieldType mShieldType;
    int mShieldHealth, mShieldMaxHealth;
    int mBodyHealth, mBodyMaxHealth;
    int mFlyingHealth, mFlyingMaxHealth;
    int mJustGotShotCounter, mShieldJustGotShotCounter, mShieldRecoilCounter;
    int mIceTrapCounter, mButteredCounter, mChilledCounter, mYuckyFaceCounter;
    bool mYuckyFace;
    Rect mZombieRect, mZombieAttackRect;
    float mScaleZombie;
    bool mVariant;
    bool mHasZombatar;
    int mZombatarIndex;
    int mTargetCol, mTargetRow, mFireballRow;
    bool mIsFireBall;
    int mWidth, mHeight;
    int mZombieAge;
    int mAnimCounter, mAnimTicksPerFrame, mAnimFrames;
    int mGroanCounter;
    int mSummonCounter, mBossStompCounter, mBossBungeeCounter, mBossHeadCounter, mBossMode;
    bool mOnHighGround, mHitUmbrella, mDroppedLoot, mPlayingSong, mBlowingAway, mFlatTires, mIsEatingFlag;
    int mZombieFade;
    int mUseLadderCol;
    float mOriginalAnimRate;
    PlantID mTargetPlantID;
    int mLastPortalX;
    bool mMindControlledFlag;
    float mVelY;
    int mGroundY;

    // ---- 对拍形态函数声明（各 bench.cpp 定义；未用者不链接） ----
    __declspec(noinline) void DrawIceTrap_A(Graphics* g, const ZombieDrawPosition& theDrawPos, bool theFront);
    __declspec(noinline) void DrawIceTrap_B(Graphics* g, const ZombieDrawPosition& theDrawPos, bool theFront);
    __declspec(noinline) void DrawButter_A(Graphics* g, const ZombieDrawPosition& theDrawPos);
    __declspec(noinline) void DrawButter_B(Graphics* g, const ZombieDrawPosition& theDrawPos);
    __declspec(noinline) void DrawDancerReanim_A(Graphics* g);
    __declspec(noinline) void DrawDancerReanim_B(Graphics* g);
    __declspec(noinline) bool SetupDrawZombieWon_A(Graphics* g);
    __declspec(noinline) bool SetupDrawZombieWon_B(Graphics* g);
    __declspec(noinline) void SetupReanimForLostArm_A(unsigned int theDamageFlags);
    __declspec(noinline) void SetupReanimForLostArm_B(unsigned int theDamageFlags);
    __declspec(noinline) void BossSpawnAttack_A();
    __declspec(noinline) void BossSpawnAttack_B();
    __declspec(noinline) void BossHeadSpit_A();
    __declspec(noinline) void BossHeadSpit_B();
    __declspec(noinline) void EnableMustache_A(bool theEnableMustache);
    __declspec(noinline) void EnableMustache_B(bool theEnableMustache);
    __declspec(noinline) void EnableFuture_A(bool theEnableFuture);
    __declspec(noinline) void EnableFuture_B(bool theEnableFuture);
    __declspec(noinline) void ZombieInitialize_A(int theRow, ZombieType theType, bool theVariant, Zombie* theParentZombie, int theFromWave);
    __declspec(noinline) void ZombieInitialize_B(int theRow, ZombieType theType, bool theVariant, Zombie* theParentZombie, int theFromWave);
    __declspec(noinline) void DrawShadow(Graphics* g);
    __declspec(noinline) void DrawReanim(Graphics* g, const ZombieDrawPosition& dp, int grp);
    __declspec(noinline) void DrawBungeeTarget(Graphics* g);
    __declspec(noinline) void DrawBossPart(Graphics* g, BossPart p);
    __declspec(noinline) bool BeginDraw(Graphics* g) { ZSink(RID_Coin_BeginDraw); return true; }
    __declspec(noinline) void Draw(Graphics* g) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void EndDraw(Graphics* g) { ZSink(RID_Coin_EndDraw); }

    // ---- 查询（纯状态，两形态共享） ----
    __declspec(noinline) bool IsOnBoard() { return mBoard != nullptr; }
    __declspec(noinline) bool IsDeadOrDying()
    {
        return mDead || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_DYING ||
            mZombiePhase == ZombiePhase::PHASE_ZOMBIE_BURNED || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED;
    }
    __declspec(noinline) bool IsImmobilizied() { return mIceTrapCounter > 0 || mButteredCounter > 0; }
    __declspec(noinline) bool IsWalkingBackwards() { return mVelX < 0.0f; }
    __declspec(noinline) bool ZombieNotWalking() { return mZombiePhase != ZombiePhase::PHASE_ZOMBIE_NORMAL; }
    static bool IsZombotany(ZombieType theZombieType)
    {
        return theZombieType >= ZombieType::ZOMBIE_PEA_HEAD && theZombieType <= ZombieType::ZOMBIE_TALLNUT_HEAD;
    }
    __declspec(noinline) bool CanLoseBodyParts()
    {
        return mZombieType != ZombieType::ZOMBIE_GARGANTUAR && mZombieType != ZombieType::ZOMBIE_REDEYE_GARGANTUAR &&
            mZombieType != ZombieType::ZOMBIE_BOSS;
    }

    // ---- 动作桩（编号入 checksum） ----
    __declspec(noinline) void GetDrawPos(ZombieDrawPosition& theDrawPos)
    {
        ZSink(RID_Z_GetDrawPos);
        theDrawPos.mImageOffsetX = 3.0f; theDrawPos.mImageOffsetY = 4.0f;
        theDrawPos.mHeadX = 5.0f; theDrawPos.mHeadY = 6.0f; theDrawPos.mBodyY = 7.0f;
    }
    __declspec(noinline) void GetTrackPosition(ReanimTrackId t, float& x, float& y)
    {
        ZSink(RID_Z_GetTrackPosition, (uint32_t)t);
        x += (float)(int)t; y += 2.0f;
    }
    __declspec(noinline) void ReanimShowRange(const ReanimTrackIdRange& r, int theGroup)
    {
        ZSink(RID_Z_ReanimShowRange, (uint32_t)r.mLo, (uint32_t)r.mHi, (uint32_t)theGroup);
    }
    __declspec(noinline) void ReanimShowTrack(ReanimTrackId t, int theGroup)
    {
        ZSink(RID_Z_ReanimShowTrack, (uint32_t)t, (uint32_t)theGroup);
    }
    __declspec(noinline) void OverrideParticleScale(TodParticleSystem* p) { ZSink(RID_Z_OverrideParticleScale, p ? 1u : 0u); }
    __declspec(noinline) void OverrideParticleColor(TodParticleSystem* p) { ZSink(RID_Z_OverrideParticleColor, p ? 1u : 0u); }
    __declspec(noinline) void PlayZombieReanim(ReanimTrackId t, ReanimLoopType l, int i, float r)
    {
        ZSink(RID_Z_PlayZombieReanim, (uint32_t)t, (uint32_t)l, (uint32_t)(int)r);
    }
    __declspec(noinline) void StartWalkAnim(int i) { ZSink(RID_Z_StartWalkAnim, (uint32_t)i); }
    __declspec(noinline) void PickRandomSpeed() { ZSink(RID_Z_PickRandomSpeed); mVelX = 0.3f; }
    __declspec(noinline) void LoadReanim(ReanimationType t) { ZSink(RID_Z_LoadReanim, (uint32_t)t); }
    __declspec(noinline) void LoadPlainZombieReanim() { ZSink(RID_Z_LoadPlain); }
    __declspec(noinline) void AttachShield() { ZSink(RID_Z_AttachShield); }
    __declspec(noinline) void PickBungeeZombieTarget(int i) { ZSink(RID_Z_PickBungeeTarget, (uint32_t)i); }
    __declspec(noinline) void SetupWaterTrack(ReanimTrackId t) { ZSink(RID_Rean_SetFramesForLayer, (uint32_t)t); }
    __declspec(noinline) void AddAttachedParticle(int x, int y, ParticleEffect e) { ZSink(RID_Z_AddAttachedParticle, (uint32_t)x, (uint32_t)y, (uint32_t)e); }
    __declspec(noinline) void UpdateAnimSpeed() { ZSink(RID_Z_UpdateAnimSpeed); }
    __declspec(noinline) void PlayZombieAppearSound() { ZSink(RID_Z_PlayAppearSound); }
    __declspec(noinline) void StartZombieSound() { ZSink(RID_Z_StartZombieSound); }
    __declspec(noinline) void UpdateReanim() { ZSink(RID_Z_UpdateReanim); }
    __declspec(noinline) void BossSetupReanim() { ZSink(RID_Z_BossSetupReanim); }
    __declspec(noinline) void ResetZombatarHead(LawnApp* a) { ZSink(RID_Z_ResetZombatarHead); }
    __declspec(noinline) void ApplyZombatarHead(LawnApp* a, void* z) { ZSink(RID_Z_ApplyZombatarHead); }
    __declspec(noinline) void SetAnimRate(float r) { ZSink(RID_Z_SetAnimRate, (uint32_t)(int)r); mOriginalAnimRate = r; }
    __declspec(noinline) void RemoveColdEffects() { ZSink(RID_Z_RemoveColdEffects); }
    __declspec(noinline) void Collect() { ZSink(RID_Z_Collect); }
    __declspec(noinline) float GetPosYBasedOnRow(int theRow) { ZSink(RID_Z_GetPosYBasedOnRow, (uint32_t)theRow); return 80.0f + theRow * 100.0f; }
    __declspec(noinline) void UpdateDamageStates(unsigned int f) { ZSink(RID_Z_UpdateDamageStates, f); }

    // ---- 状态哈希 ----
    __declspec(noinline) void HashFold(uint64_t& h) const
    {
        h = ZBMixU64(h, (uint64_t)(int64_t)mZombieType);
        h = ZBMixU64(h, (uint64_t)(int64_t)mZombiePhase);
        h = ZBMixU64(h, (uint64_t)(int64_t)mZombieHeight);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mX);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mY);
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mPosX));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mPosY));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mVelX));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mAltitude));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mScaleZombie));
        h = ZBMixU64(h, (uint64_t)(uint32_t)mFrame);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mPhaseCounter);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mBodyHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mHelmHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mShieldHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mZombieAge);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mZombieAttackRect.mX * 31 + mZombieAttackRect.mWidth));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mZombieRect.mX * 31 + mZombieRect.mWidth));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mTargetRow * 17 + mFireballRow));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mSummonCounter * 13 + mBossStompCounter));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mRenderOrder * 7 + mRow));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mWidth * 31 + mHeight));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mHelmMaxHealth * 3 + mBodyMaxHealth));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mShieldMaxHealth * 5 + mFlyingMaxHealth));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mZombieRect.mY * 11 + mZombieAttackRect.mY));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mHelmType) * 3u + (uint64_t)(uint32_t)(mShieldType));
        h = ZBMixU64(h, (uint64_t)(mVariant ? 2 : 0) + (mHasObject ? 1 : 0) + (mHasZombatar ? 4 : 0) + (mDead ? 8 : 0) + (mIsFireBall ? 16 : 0));
    }
};

inline Zombie* Board::GetBossZombie() { ZSink(RID_Coin_Draw); return nullptr; }


// ============================ Plant 桩 ============================
// PlantDefinition / 装载定义（仓库 Plant.h 形状）
enum PlantSubClass { SUBCLASS_NORMAL = 0, SUBCLASS_SHOOTER = 1 };
enum PlantOnBungeeState { NOT_ON_BUNGEE, GETTING_GRABBED_BY_BUNGEE, RISING_WITH_BUNGEE };
struct PlantDefinition
{
    SeedType mSeedType = SeedType::SEED_NONE;
    ReanimationType mReanimationType = ReanimationType::REANIM_NONE;
    int mPacketIndex = 0, mSeedCost = 0, mRefreshTime = 0;
    PlantSubClass mSubClass = SUBCLASS_NORMAL;
    int mLaunchRate = 0;
    const char* mPlantName = "";
};
inline PlantDefinition gPlantDefs[(int)SeedType::NUM_SEED_TYPES];
inline void R3InitPlantDefs()
{
    for (int i = 0; i < (int)SeedType::NUM_SEED_TYPES; i++)
    {
        gPlantDefs[i].mSeedType = (SeedType)i;
        gPlantDefs[i].mReanimationType = (ReanimationType)((int)ReanimationType::REANIM_PEASHOOTER + i % 5);  // 全型有动画（保 case 体 reanim 非空不变量）
        gPlantDefs[i].mSubClass = (i % 2 == 0) ? SUBCLASS_SHOOTER : SUBCLASS_NORMAL;
        gPlantDefs[i].mLaunchRate = (i % 3) * 100;
    }
}
inline PlantDefinition& GetPlantDefinition(SeedType theSeedType) { return gPlantDefs[(int)theSeedType]; }

struct Plant
{
    LawnApp* mApp = nullptr;
    Board* mBoard = nullptr;
    SeedType mSeedType = SeedType::SEED_PEASHOOTER;
    SeedType mImitaterType = SeedType::SEED_NONE;
    PlantState mState = (PlantState)0;
    int mStateCountdown = 0, mDoSpecialCountdown = 0, mBlinkCountdown = 0;
    int mPlantHealth = 300, mPlantHealthMax = 300;
    int mX = 100, mY = 200, mRow = 2, mPlantCol = 3, mRenderOrder = 5;
    int mWidth = 80, mHeight = 80;
    bool mIsAsleep = false, mDead = false, mSquashable = true, mOnHighGround = false;
    bool mNeedsFertilizer = false, mNeedsWater = false, mNeedsBugSpray = false, mAwake = true;
    ReanimationID mBodyReanimID = (ReanimationID)1, mHeadReanimID = (ReanimationID)2;
    bool mSelected = false;
    int mPottedPlantIndex = 0;
    int mNumRadius = 0, mGlowParticleCount = 0;
    // PlantInitialize 读写字段全集（仓库 Plant.h 形状）
    int mPlantMaxHealth = 300;
    ReanimationID mHeadReanimID2 = (ReanimationID)0, mHeadReanimID3 = (ReanimationID)0;
    ReanimationID mBlinkReanimID = (ReanimationID)0, mLightReanimID = (ReanimationID)0, mSleepingReanimID = (ReanimationID)0;
    ParticleSystemID mParticleID = ParticleSystemID::PARTICLESYSTEMID_NULL;   // 仓库 Plant.h：字段名 mParticleID，类型 ParticleSystemID
    int mAnimCounter = 0;
    bool mAnimPing = true;
    int mFrame = 0, mShootingCounter = 0;
    float mShakeOffsetX = 0.0f, mShakeOffsetY = 0.0f;
    int mFrameLength = 12, mTargetX = -1, mTargetY = -1, mStartRow = 0, mNumFrames = 5;
    bool mSquished = false;
    int mDisappearCountdown = 0;
    int mRecentlyEatenCountdown = 0, mEatenFlashCountdown = 0, mBeghouledFlashCountdown = 0;
    int mMagnetItems[32] = {};
    int mWakeUpCounter = 0;
    PlantOnBungeeState mOnBungeeState = NOT_ON_BUNGEE;
    int mLaunchRate = 0;
    PlantSubClass mSubclass = SUBCLASS_NORMAL;
    int mLaunchCounter = 0;

    __declspec(noinline) int CalcRenderOrder() { ZSink(RID_Coin_Draw, 71); return 300 + mRow * 100 + mPlantCol; }
    __declspec(noinline) void SetSleeping(bool b) { ZSink(RID_Coin_Draw, 72, b); mIsAsleep = b; }
    static bool IsNocturnal(SeedType t) { ZSink(RID_Coin_Draw, 73, (uint32_t)t); return ((int)t % 2) == 1; }
    bool MakesSun() { ZSink(RID_Coin_Draw, 74); return mSeedType == SeedType::SEED_SUNFLOWER; }
    __declspec(noinline) bool IsOnBoard() { ZSink(RID_Coin_Draw, 75); return mBoard != nullptr; }
    __declspec(noinline) void AddAttachedParticle(int x, int y, ParticleEffect e) { ZSink(RID_Z_AddAttachedParticle, (uint32_t)x, (uint32_t)y, (uint32_t)e); }
    __declspec(noinline) TodParticleSystem* AddAttachedParticle(int x, int y, int theRenderPosition, ParticleEffect e) { ZSink(RID_Z_AddAttachedParticle, (uint32_t)x, (uint32_t)y, (uint32_t)((int)e * 3 + theRenderPosition)); return &g_particle; }

    static bool IsFlying(SeedType) { ZSink(RID_Plant_IsFlying); return false; }
    static void DrawSeedType(Graphics* g, SeedType a, SeedType b, int c, float x, float y)
    {
        ZSink(RID_Plant_DrawSeedType, (uint32_t)a, (uint32_t)(int)(x * 4.0f), (uint32_t)(int)(y * 4.0f));
    }
    static float PlantDrawHeightOffset(Board* b, Plant* p, SeedType s, int x, int y)
    {
        ZSink(RID_Plant_DrawHeightOffset, (uint32_t)s);
        return 10.0f;
    }
    static SexyString GetNameString(SeedType s, SeedType b) { ZSink(RID_Plant_GetNameString, (uint32_t)s); return "N"; }
    __declspec(noinline) bool IsInPlay() { return mBoard != nullptr; }
    __declspec(noinline) bool BeginDraw(Graphics*) { ZSink(RID_Coin_BeginDraw); return true; }
    __declspec(noinline) void Draw(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void EndDraw(Graphics*) { ZSink(RID_Coin_EndDraw); }
    __declspec(noinline) void DrawMagnetItems(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void Squish() { ZSink(RID_Coin_Draw); }

    __declspec(noinline) void PlantInitialize_A(int theGridX, int theGridY, SeedType theSeedType, SeedType theImitaterType);
    __declspec(noinline) void PlantInitialize_B(int theGridX, int theGridY, SeedType theSeedType, SeedType theImitaterType);
    __declspec(noinline) void HashFold(uint64_t& h) const
    {
        h = ZBMixU64(h, (uint64_t)(uint32_t)mSeedType);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mState);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mX);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mY);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mPlantHealth);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mStateCountdown * 13 + mDoSpecialCountdown * 7 + mBlinkCountdown));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mRow * 31 + mPlantCol));
        h = ZBMixU64(h, (uint64_t)(uint32_t)mRenderOrder);
        h = ZBMixU64(h, (uint64_t)(mIsAsleep ? 1 : 0) + (mSelected ? 2 : 0));
    }
};

inline Plant* Board::GetFlowerPotAt(int gx, int gy)
{
    ZSink(RID_Coin_Draw, 76, (uint32_t)(gx * 7 + gy));
    static Plant sPot;
    sPot.mBodyReanimID = (ReanimationID)1;
    return ((gx + gy) % 4 == 0) ? &sPot : nullptr;
}

inline Plant* R3PlantList::DataArrayGet(unsigned int theID)
{
    static Plant sPlants[4];
    sPlants[theID % 4].mPottedPlantIndex = (int)(theID % 3);
    return &sPlants[theID % 4];
}

// ============================ CursorObject 桩 ============================
struct CursorObject
{
    LawnApp* mApp = nullptr;
    Board* mBoard = nullptr;
    SeedType mType = SeedType::SEED_NONE;
    SeedType mImitaterType = SeedType::SEED_NONE;
    CursorType mCursorType = CursorType::CURSOR_TYPE_NORMAL;
    ReanimationID mReanimCursorID = (ReanimationID)1;
    PlantID mGlovePlantID = PlantID::PLANTID_NULL;
    int mX = 0, mY = 0, mWidth = 80, mHeight = 80;
    bool mVisible = true;

    __declspec(noinline) void Draw_A(Graphics* g);
    __declspec(noinline) void Draw_B(Graphics* g);
};

// ============================ MessageWidget 桩 ============================
struct MessageWidget
{
    LawnApp* mApp = nullptr;
    Board* mBoard = nullptr;
    SexyString mLabel = "msg";
    SexyString mLabelNext = "next";
    MessageStyle mMessageStyle = MessageStyle::MESSAGE_STYLE_OFF;
    MessageStyle mMessageStyleNext = MessageStyle::MESSAGE_STYLE_OFF;
    ReanimationType mReanimType = ReanimationType::REANIM_NONE;
    int mDuration = 0, mDisplayTime = 0, mSlideOffTime = 0;
    ReanimationID mTextReanimID[128] = {};
    int mX = 0, mY = 0, mWidth = 800, mHeight = 600;

    __declspec(noinline) void CopyMessageLabel(SexyString& dst, const SexyString& src) { ZSink(RID_Msg_CopyLabel, (uint32_t)src.size()); dst = src; }
    __declspec(noinline) void ClearLabel() { ZSink(RID_Msg_ClearLabel); }
    __declspec(noinline) void ClearReanim() { ZSink(RID_Msg_ClearReanim); }
    __declspec(noinline) void LayoutReanimText() { ZSink(RID_Msg_LayoutReanim); }
    __declspec(noinline) _Font* GetFont();
    __declspec(noinline) void DrawReanimatedTextStub(Graphics* g, _Font* theFont, const Color& theColor, float thePosY);
    __declspec(noinline) void SetLabel_A(const SexyString& theNewLabel, MessageStyle theMessageStyle);
    __declspec(noinline) void SetLabel_B(const SexyString& theNewLabel, MessageStyle theMessageStyle);
    __declspec(noinline) void Draw_A(Graphics* g);
    __declspec(noinline) void Draw_B(Graphics* g);
    __declspec(noinline) void HashFold(uint64_t& h) const
    {
        h = ZBMixU64(h, (uint64_t)(uint32_t)mMessageStyle);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mReanimType);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mDuration);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mDisplayTime);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mLabel.size() * 17 + mLabelNext.size()));
    }
};
inline SexyString EntityTranslate(const SexyString& s) { ZSink(RID_Msg_EntityTranslate, (uint32_t)s.size()); return s; }

// ============================ StoreScreen 桩 ============================
struct StoreScreen
{
    LawnApp* mApp = nullptr;
    int mX = 0, mY = 0;
    int mStoreTime = 200;
    bool mBubbleClickToContinue = false;
    bool mPurchaseDialoguePending = false;
    int mHatchTimer = 0;
    bool mWaitForDialog = false;
    StoreItem mMouseOverItem = (StoreItem)STORE_ITEM_INVALID;
    int mBubbleCountDown = 0;
    WidgetButton* mBackButton = nullptr;
    WidgetButton* mPrevButton = nullptr;
    WidgetButton* mNextButton = nullptr;

    __declspec(noinline) bool CanInteractWithButtons() { ZSink(RID_Store_CanInteract); return mStoreTime >= 120 && !mBubbleClickToContinue && !mPurchaseDialoguePending && mHatchTimer <= 0 && !mWaitForDialog; }
    __declspec(noinline) StoreItem GetStoreItemType(int thePos) { ZSink(RID_Store_GetItemType, (uint32_t)thePos); return (StoreItem)(thePos % 31); }
    __declspec(noinline) bool IsItemUnavailable(StoreItem theItem) { ZSink(RID_Store_IsUnavailable, (uint32_t)theItem); return ((int)theItem % 7) == 6; }
    __declspec(noinline) void GetStorePosition(int thePos, int& x, int& y) { ZSink(RID_Store_GetPosition, (uint32_t)thePos); x = 30 + (thePos % 6) * 90; y = 100 + (thePos / 6) * 100; }
    __declspec(noinline) bool IsFullVersionOnly(StoreItem theItem) { ZSink(RID_Store_IsFullVersionOnly, (uint32_t)theItem); return ((int)theItem % 11) == 5; }
    __declspec(noinline) bool IsItemSoldOut(StoreItem theItem) { ZSink(RID_Store_IsSoldOut, (uint32_t)theItem); return ((int)theItem % 13) == 4; }
    __declspec(noinline) bool IsComingSoon(StoreItem theItem) { ZSink(RID_Store_IsComingSoon, (uint32_t)theItem); return ((int)theItem % 17) == 3; }
    __declspec(noinline) void SetBubbleText(int theIndex, int theTime, bool theClick) { ZSink(RID_Store_SetBubbleText, (uint32_t)theIndex, (uint32_t)theTime, theClick); }
    __declspec(noinline) void UpdateMouse_A();
    __declspec(noinline) void UpdateMouse_B();
};

// ============================ Music 桩 ============================
struct Music
{
    int mCurMusicTune = MUSIC_TUNE_NONE;
    MusicFile mCurMusicFileMain = MUSIC_FILE_NONE;
    MusicFile mCurMusicFileDrums = MUSIC_FILE_NONE;
    MusicFile mCurMusicFileHihats = MUSIC_FILE_NONE;
    int mBaseBPM = 0, mBaseModSpeed = 0;

    __declspec(noinline) bool IsMusicDisabled() { ZSink(RID_Music_IsMusicDisabled); return false; }
    __declspec(noinline) void PlayFromOffset(MusicFile theMusicFile, int theOffset, float theVolume)
    {
        ZSink(RID_Music_PlayFromOffset, (uint32_t)theMusicFile, (uint32_t)theOffset, (uint32_t)(int)(theVolume * 8.0f));
    }
    __declspec(noinline) void SetupMusicFileForTune_A(MusicFile theMusicFile, MusicTune theMusicTune);
    __declspec(noinline) void SetupMusicFileForTune_B(MusicFile theMusicFile, MusicTune theMusicTune);
    __declspec(noinline) void PlayMusic_A(MusicTune theMusicTune, int theOffset, int theDrumsOffset);
    __declspec(noinline) void PlayMusic_B(MusicTune theMusicTune, int theOffset, int theDrumsOffset);
    __declspec(noinline) void HashFold(uint64_t& h) const
    {
        h = ZBMixU64(h, (uint64_t)(uint32_t)mCurMusicTune);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mCurMusicFileMain);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mCurMusicFileDrums);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mCurMusicFileHihats);
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mBaseBPM * 31 + mBaseModSpeed));
    }
};

// ============================ Coin 桩 ============================
struct Coin
{
    LawnApp* mApp = nullptr;
    Board* mBoard = nullptr;
    CoinType mType = CoinType::COIN_SUN;
    CoinMotion mCoinMotion = CoinMotion::COIN_MOTION_COIN;
    float mPosX = 0, mPosY = 0, mVelX = 0, mVelY = 0;
    int mGroundY = 0;
    float mScale = 1.0f;
    int mWidth = 60, mHeight = 60, mRenderOrder = 0;
    float mCollectionDistance = 0;
    bool mDead = false, mIsBeingCollected = false, mHitGround = false;
    int mDisappearCounter = 0, mFadeCount = 0, mCoinAge = 0, mTimesDropped = 0;
    AttachmentID mAttachmentID = ATTACHMENTID_NULL;
    bool mNeedsBouncyArrow = false, mHasBouncyArrow = false;
    SeedType mUsableSeedType = SeedType::SEED_NONE;
    PottedPlant mPottedPlantSpec;

    __declspec(noinline) bool IsSun() { ZSink(RID_Coin_IsSun); return mType == CoinType::COIN_SUN || mType == CoinType::COIN_SMALLSUN || mType == CoinType::COIN_LARGESUN; }
    __declspec(noinline) void CoinInitialize_A(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion);
    __declspec(noinline) void CoinInitialize_B(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion);
    __declspec(noinline) void CoinInitialize_Amotion(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion);
    __declspec(noinline) void CoinInitialize_Apresent(int theX, int theY, CoinType theCoinType, CoinMotion theCoinMotion);
    __declspec(noinline) void Collect() { ZSink(RID_Z_Collect); mIsBeingCollected = true; }
    __declspec(noinline) bool BeginDraw(Graphics*) { ZSink(RID_Coin_BeginDraw); return true; }
    __declspec(noinline) void Draw(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void EndDraw(Graphics*) { ZSink(RID_Coin_EndDraw); }
    __declspec(noinline) void HashFold(uint64_t& h) const
    {
        h = ZBMixU64(h, (uint64_t)(uint32_t)mType);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mCoinMotion);
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mPosX));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mPosY));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mVelX));
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mVelY));
        h = ZBMixU64(h, (uint64_t)(uint32_t)mGroundY);
        h = ZBMixU64(h, (uint64_t)reinterpret_cast<const uint32_t&>(mScale));
        h = ZBMixU64(h, (uint64_t)(uint32_t)(mWidth * 31 + mHeight));
        h = ZBMixU64(h, (uint64_t)(uint32_t)mRenderOrder);
        h = ZBMixU64(h, (uint64_t)(uint32_t)mPottedPlantSpec.mSeedType);
        h = ZBMixU64(h, (uint64_t)(mDead ? 2 : 0) + (mIsBeingCollected ? 1 : 0) + (mHitGround ? 4 : 0));
    }
};

// ============================ AlmanacDialog 桩 ============================
struct ReanimatorCache
{
    __declspec(noinline) void DrawCachedZombie(Graphics* g, int x, int y, ZombieType t) { ZSink(RID_Almanac_DrawCachedZombie, (uint32_t)t, (uint32_t)(x * 31 + y)); }
};
struct AlmanacDialog
{
    LawnApp* mApp = nullptr;
    int mX = 0, mY = 0;
    Zombie* mZombie = nullptr;
    ZombieType mSelectedZombie = ZOMBIE_NORMAL;

    __declspec(noinline) ZombieType ZombieHitTest(int x, int y) { ZSink(RID_Almanac_ZombieHitTest, (uint32_t)x, (uint32_t)y); return (ZombieType)(x % 34); }
    __declspec(noinline) ZombieType GetZombieType(int i) { ZSink(RID_Almanac_GetZombieType, (uint32_t)i); return (ZombieType)(i % 34); }
    __declspec(noinline) void GetZombiePosition(ZombieType t, int& x, int& y) { ZSink(RID_Almanac_GetZombiePosition, (uint32_t)t); x = 40 + ((int)t % 7) * 110; y = 90 + ((int)t / 7) * 120; }
    __declspec(noinline) bool ZombieIsShown(ZombieType t) { ZSink(RID_Almanac_ZombieIsShown, (uint32_t)t); return ((int)t % 5) != 4; }
    __declspec(noinline) bool ZombieHasSilhouette(ZombieType t) { ZSink(RID_Almanac_ZombieHasSilhouette, (uint32_t)t); return ((int)t % 6) == 2; }
    __declspec(noinline) void DrawZombies_A(Graphics* g);
    __declspec(noinline) void DrawZombies_B(Graphics* g);
};
inline ReanimatorCache g_reanimCache;

// ============================ MessageWidget::GetFont 桩（kStyleFonts 真值） ============================
inline _Font g_fonts[3];   // 0=HOT28 1=HOT16 2=CONTINUUM14
inline void R3InitFonts()
{
    g_fonts[0].mAscent = 28; g_fonts[1].mAscent = 16; g_fonts[2].mAscent = 14;
}
namespace Sexy
{
    inline _Font* FONT_HOUSEOFTERROR28 = &g_fonts[0];
    inline _Font* FONT_HOUSEOFTERROR16 = &g_fonts[1];
    inline _Font* FONT_CONTINUUMBOLD14 = &g_fonts[2];
    inline _Font* FONT_CONTINUUMBOLD14OUTLINE = &g_fonts[1];
    inline _Font* FONT_DWARVENTODCRAFT24 = &g_fonts[0];
}
inline _Font* MessageWidget::GetFont()
{
    ZSink(RID_Msg_GetFont, (uint32_t)mMessageStyle);
    // 仓库 kStyleFonts 语义：仅 SLOT_MACHINE=16 号字体，其余 28 号
    return mMessageStyle == MessageStyle::MESSAGE_STYLE_SLOT_MACHINE ? Sexy::FONT_HOUSEOFTERROR16 : Sexy::FONT_HOUSEOFTERROR28;
}
