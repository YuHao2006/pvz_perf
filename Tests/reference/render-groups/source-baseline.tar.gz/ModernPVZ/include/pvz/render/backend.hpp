#pragma once

#include "pvz/render/viewport.hpp"

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>

namespace pvz::render {

enum class BackendKind {
    null_backend,
    vulkan,
};

enum class BlendMode {
    opaque,
    alpha,
    additive,
};

enum class TextureFilter {
    nearest,
    linear,
};

enum class TextureAddressMode {
    clamp,
    repeat,
};

struct SamplingState {
    TextureFilter filter{TextureFilter::nearest};
    TextureAddressMode address_u{TextureAddressMode::clamp};
    TextureAddressMode address_v{TextureAddressMode::clamp};

    [[nodiscard]] bool operator==(const SamplingState&) const noexcept = default;
};

struct TextureHandle {
    // Zero selects the backend-owned opaque white texture for untextured geometry.
    std::uint32_t value{0};

    [[nodiscard]] explicit operator bool() const noexcept
    {
        return value != 0;
    }

    [[nodiscard]] bool operator==(const TextureHandle&) const noexcept = default;
};

enum class TextureFormat {
    rgba8_unorm,
    rgba8_srgb,
};

struct TextureUpload {
    std::uint32_t width{0};
    std::uint32_t height{0};
    std::uint32_t row_pitch_bytes{0};
    TextureFormat format{TextureFormat::rgba8_srgb};
    std::span<const std::byte> pixels;
};

[[nodiscard]] constexpr std::uint32_t pack_rgba8(
    const std::uint8_t red,
    const std::uint8_t green,
    const std::uint8_t blue,
    const std::uint8_t alpha = 255) noexcept
{
    // Vertex memory is R, G, B, A on every supported little-endian target.
    return static_cast<std::uint32_t>(red) |
           (static_cast<std::uint32_t>(green) << 8U) |
           (static_cast<std::uint32_t>(blue) << 16U) |
           (static_cast<std::uint32_t>(alpha) << 24U);
}

struct Vertex2D {
    float x{0.0F};
    float y{0.0F};
    float u{0.0F};
    float v{0.0F};
    std::uint32_t rgba{0xFFFFFFFF};
};

struct DrawBatch {
    TextureHandle texture;
    BlendMode blend_mode{BlendMode::alpha};
    std::uint32_t first_index{0};
    std::uint32_t index_count{0};
    Rect2D logical_scissor;
    SamplingState sampling;
};

struct FramePacket {
    std::uint64_t frame_index{0};
    Extent2D logical_extent;
    Rect2D pixel_viewport;
    double interpolation_alpha{0.0};
    std::span<const Vertex2D> vertices;
    std::span<const std::uint32_t> indices;
    std::span<const DrawBatch> batches;
};

struct BackendCapabilities {
    BackendKind kind{BackendKind::null_backend};
    std::string name;
    std::uint32_t max_texture_dimension_2d{0};
    bool supports_bindless_textures{false};
    bool supports_timeline_synchronization{false};
};

class IRenderBackend {
public:
    virtual ~IRenderBackend() = default;

    [[nodiscard]] virtual const BackendCapabilities& capabilities() const noexcept = 0;
    [[nodiscard]] virtual TextureHandle create_texture(const TextureUpload& upload) = 0;
    virtual void update_texture(TextureHandle texture, const TextureUpload& upload) = 0;
    virtual void destroy_texture(TextureHandle texture) = 0;
    virtual void resize(std::uint32_t pixel_width, std::uint32_t pixel_height) = 0;
    virtual void submit(const FramePacket& frame) = 0;
    virtual void wait_idle() = 0;
};

} // namespace pvz::render
