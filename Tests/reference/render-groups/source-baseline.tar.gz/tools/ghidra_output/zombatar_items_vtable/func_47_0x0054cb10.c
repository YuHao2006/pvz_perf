
undefined4 __thiscall
FUN_0054cb10(int param_1,undefined4 param_2,CMFCCaptionButtonEx *param_3,int param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *in_stack_00000034;
  
  piVar1 = (int *)FUN_00598310();
  iVar2 = (**(code **)(*piVar1 + 0x1c))(param_5);
  CMFCCaptionButtonEx::SetRect(param_3,(CRect *)&stack0x00000024);
  FUN_00598a10(param_5,(*(int *)(param_1 + 0x48) - iVar2) / 2 + *in_stack_00000034,
               param_4 + in_stack_00000034[1]);
  CMFCCaptionButtonEx::SetRect(param_3,(CRect *)&stack0x00000014);
  FUN_00598a10(param_5,(*(int *)(param_1 + 0x48) - iVar2) / 2,param_4);
  iVar3 = (**(code **)(*piVar1 + 0x10))();
  iVar4 = FUN_0069e652(in_stack_00000034[1]);
  iVar3 = iVar3 + iVar4;
  iVar4 = FUN_0069e652(*in_stack_00000034,iVar3);
  iVar4 = iVar4 + iVar2;
  (**(code **)(*piVar1 + 4))(iVar4);
  FUN_00401a90(iVar4,iVar3);
  return param_2;
}

