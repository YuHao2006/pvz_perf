#include "pvz/render/viewport.hpp"

#include <algorithm>
#include <stdexcept>

namespace pvz::render {

ViewportTransform ViewportTransform::create(
    const std::uint32_t pixel_width,
    const std::uint32_t pixel_height,
    const ViewportPolicy policy)
{
    if (pixel_width == 0 || pixel_height == 0)
        throw std::invalid_argument("viewport pixel dimensions must be positive");
    if (policy.logical_height <= 0.0 || policy.minimum_logical_width <= 0.0 ||
        policy.maximum_logical_width < policy.minimum_logical_width)
        throw std::invalid_argument("invalid viewport policy");

    const auto physical_width = static_cast<double>(pixel_width);
    const auto physical_height = static_cast<double>(pixel_height);
    const auto desired_logical_width = policy.logical_height * physical_width / physical_height;
    const auto logical_width = std::clamp(
        desired_logical_width,
        policy.minimum_logical_width,
        policy.maximum_logical_width);

    ViewportTransform result;
    result.logical_extent_ = {logical_width, policy.logical_height};
    result.scale_ = std::min(
        physical_width / result.logical_extent_.width,
        physical_height / result.logical_extent_.height);

    result.pixel_viewport_.extent = {
        result.logical_extent_.width * result.scale_,
        result.logical_extent_.height * result.scale_,
    };
    result.pixel_viewport_.origin = {
        (physical_width - result.pixel_viewport_.extent.width) * 0.5,
        (physical_height - result.pixel_viewport_.extent.height) * 0.5,
    };
    result.width_clamped_ = logical_width != desired_logical_width;
    return result;
}

Extent2D ViewportTransform::logical_extent() const noexcept
{
    return logical_extent_;
}

Rect2D ViewportTransform::pixel_viewport() const noexcept
{
    return pixel_viewport_;
}

double ViewportTransform::pixels_per_logical_unit() const noexcept
{
    return scale_;
}

bool ViewportTransform::is_width_clamped() const noexcept
{
    return width_clamped_;
}

Point2D ViewportTransform::logical_to_pixel(const Point2D logical) const noexcept
{
    return {
        pixel_viewport_.origin.x + logical.x * scale_,
        pixel_viewport_.origin.y + logical.y * scale_,
    };
}

std::optional<Point2D> ViewportTransform::pixel_to_logical(const Point2D pixel) const noexcept
{
    const auto right = pixel_viewport_.origin.x + pixel_viewport_.extent.width;
    const auto bottom = pixel_viewport_.origin.y + pixel_viewport_.extent.height;
    if (pixel.x < pixel_viewport_.origin.x || pixel.y < pixel_viewport_.origin.y ||
        pixel.x >= right || pixel.y >= bottom)
        return std::nullopt;

    return Point2D{
        (pixel.x - pixel_viewport_.origin.x) / scale_,
        (pixel.y - pixel_viewport_.origin.y) / scale_,
    };
}

} // namespace pvz::render
