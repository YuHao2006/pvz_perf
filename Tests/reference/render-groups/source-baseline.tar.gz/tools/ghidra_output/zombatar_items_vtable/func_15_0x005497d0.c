
void __thiscall FUN_005497d0(int *param_1,int *param_2)

{
  int iVar1;
  char cVar2;
  undefined1 local_1c [4];
  int local_18;
  int *local_14;
  undefined1 local_10 [11];
  char local_5;
  
  if ((char)param_2[0xf] == '\0') {
    (**(code **)(*param_1 + 0x44))();
    *(undefined1 *)(param_2 + 0xf) = 1;
    if (param_1[9] == 0) {
      if ((char)param_2[0x14] == '\0') {
        local_5 = '\0';
        FUN_005b75d0(local_10);
        while( true ) {
          iVar1 = param_1[6];
          FUN_00420ae0();
          local_18 = iVar1;
          if (param_1 == (int *)0xfffffffc) {
            FUN_0069a6f2();
          }
          FUN_0040a150();
          cVar2 = FUN_006143c0(local_1c);
          if (cVar2 != '\0') break;
          local_14 = (int *)FUN_005e2150();
          local_14 = (int *)*local_14;
          if (local_14 == param_2) {
            local_5 = '\x01';
          }
          else if (((local_5 != '\0') && ((char)local_14[0x19] != '\0')) &&
                  (cVar2 = (**(code **)(*local_14 + 8))(param_2), cVar2 != '\0')) {
            (**(code **)(*param_1 + 0x40))(local_14);
          }
          FUN_00614350();
        }
      }
      else {
        (**(code **)(*param_1 + 0x48))(param_2);
      }
    }
  }
  return;
}

