#include "pvz/render/viewport.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>

namespace {

using pvz::render::Point2D;
using pvz::render::ViewportTransform;

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void require_near(const double actual, const double expected, const char* message)
{
    require(std::abs(actual - expected) < 1e-9, message);
}

void test_classic_viewport()
{
    const auto viewport = ViewportTransform::create(800, 600);
    require_near(viewport.logical_extent().width, 800.0, "4:3 must retain the classic width");
    require_near(viewport.logical_extent().height, 600.0, "logical height must remain fixed");
    require_near(viewport.pixels_per_logical_unit(), 1.0, "800x600 must use unit scale");
    require(!viewport.is_width_clamped(), "4:3 is inside the supported aspect range");
}

void test_widescreen_viewport()
{
    const auto viewport = ViewportTransform::create(1920, 1080);
    require_near(viewport.logical_extent().width, 1066.6666666666667, "16:9 must expand logical width");
    require_near(viewport.pixels_per_logical_unit(), 1.8, "1080 pixels must map to 600 logical units");
    require_near(viewport.pixel_viewport().origin.x, 0.0, "supported widescreen must fill horizontally");
    require_near(viewport.pixel_viewport().origin.y, 0.0, "supported widescreen must fill vertically");
}

void test_ultrawide_is_pillarboxed()
{
    const auto viewport = ViewportTransform::create(2560, 1080);
    require_near(viewport.logical_extent().width, 1068.0, "ultrawide must clamp to audited logical width");
    require(viewport.is_width_clamped(), "ultrawide width must report clamping");
    require_near(viewport.pixel_viewport().extent.width, 1922.4, "clamped content width must preserve scale");
    require_near(viewport.pixel_viewport().origin.x, 318.8, "pillarboxes must be symmetric");
}

void test_portrait_is_letterboxed()
{
    const auto viewport = ViewportTransform::create(600, 800);
    require_near(viewport.logical_extent().width, 800.0, "portrait must retain minimum logical width");
    require_near(viewport.pixel_viewport().extent.height, 450.0, "portrait content height must fit by width");
    require_near(viewport.pixel_viewport().origin.y, 175.0, "letterboxes must be symmetric");
}

void test_coordinate_round_trip_and_bar_rejection()
{
    const auto viewport = ViewportTransform::create(2560, 1080);
    const Point2D logical{534.0, 300.0};
    const auto pixel = viewport.logical_to_pixel(logical);
    const auto round_trip = viewport.pixel_to_logical(pixel);
    require(round_trip.has_value(), "content point must map back into logical space");
    require_near(round_trip->x, logical.x, "logical X must survive a round trip");
    require_near(round_trip->y, logical.y, "logical Y must survive a round trip");
    require(!viewport.pixel_to_logical({0.0, 540.0}), "input in a pillarbox must be rejected");
}

} // namespace

int main()
{
    test_classic_viewport();
    test_widescreen_viewport();
    test_ultrawide_is_pillarboxed();
    test_portrait_is_letterboxed();
    test_coordinate_round_trip_and_bar_rejection();
    return EXIT_SUCCESS;
}
