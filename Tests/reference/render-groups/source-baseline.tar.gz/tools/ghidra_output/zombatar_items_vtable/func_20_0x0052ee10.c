
void __thiscall FUN_0052ee10(int *param_1,undefined4 param_2)

{
  FUN_00549210(param_2);
  (**(code **)(*param_1 + 0x10))(param_1[0x3b]);
  return;
}

