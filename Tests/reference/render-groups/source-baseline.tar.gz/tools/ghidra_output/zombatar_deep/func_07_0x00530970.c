
void FUN_00530970(CMFCCaptionButtonEx *param_1,int *param_2,int *param_3,int *param_4)

{
  bool bVar1;
  undefined4 *puVar2;
  CRect *pCVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 **ppuVar11;
  undefined4 *local_1c [4];
  undefined4 *local_c;
  undefined4 *local_8;
  undefined4 *local_4;
  
  puVar2 = (undefined4 *)FUN_0052fcd0();
  if (puVar2 != (undefined4 *)0x0) {
    if (puVar2[6] != 4) {
      FUN_005983e0(1);
      if (param_2[8] == -1) {
        pCVar3 = (CRect *)&DAT_007a2300;
      }
      else {
        pCVar3 = (CRect *)(&DAT_007a2010 + param_2[8] * 0x10);
      }
      CMFCCaptionButtonEx::SetRect(param_1,pCVar3);
    }
    FUN_00598a60(*(undefined4 *)*puVar2,puVar2[2] + *param_3,puVar2[3] + *param_4);
    if (puVar2[6] != 4) {
      FUN_005983e0(0);
    }
  }
  if (*param_2 == -1) {
    pCVar3 = (CRect *)&DAT_007a2300;
  }
  else {
    pCVar3 = (CRect *)(&DAT_007a2010 + *param_2 * 0x10);
  }
  CMFCCaptionButtonEx::SetRect(param_1,pCVar3);
  FUN_005983e0(1);
  iVar4 = FUN_0059abc0();
  iVar7 = *param_4;
  iVar5 = FUN_0059aba0();
  iVar9 = *param_3;
  iVar6 = FUN_0059abc0();
  iVar6 = iVar6 + (iVar7 - iVar4);
  iVar7 = FUN_0059aba0(iVar6);
  FUN_00598a60(DAT_00726778,iVar7 + (iVar9 - iVar5),iVar6);
  FUN_005983e0(0);
  iVar4 = FUN_0059abc0();
  iVar7 = *param_4;
  iVar5 = FUN_0059aba0();
  iVar9 = *param_3;
  iVar6 = FUN_0059abc0();
  iVar6 = iVar6 + (iVar7 - iVar4);
  iVar7 = FUN_0059aba0(iVar6);
  FUN_00598a60(DAT_00727150,iVar7 + (iVar9 - iVar5),iVar6);
  iVar7 = 1;
  ppuVar11 = local_1c;
  do {
    puVar2 = (undefined4 *)FUN_0052fcd0();
    *ppuVar11 = puVar2;
    iVar7 = iVar7 + 1;
    ppuVar11 = ppuVar11 + 1;
    puVar2 = local_1c[0];
  } while (iVar7 < 8);
  do {
    bVar1 = false;
    iVar9 = -1;
    iVar7 = 0xc;
    puVar10 = (undefined4 *)0x0;
    if (puVar2 != (undefined4 *)0x0) {
      bVar1 = true;
      iVar7 = 0xc;
      if ((int)puVar2[9] < 0xd) {
        iVar9 = 0;
        iVar7 = puVar2[9];
        puVar10 = puVar2;
      }
    }
    if (local_1c[1] != (undefined4 *)0x0) {
      bVar1 = true;
      if ((int)local_1c[1][9] <= iVar7) {
        iVar9 = 1;
        iVar7 = local_1c[1][9];
        puVar10 = local_1c[1];
      }
    }
    if (local_1c[2] != (undefined4 *)0x0) {
      bVar1 = true;
      if ((int)local_1c[2][9] <= iVar7) {
        iVar9 = 2;
        iVar7 = local_1c[2][9];
        puVar10 = local_1c[2];
      }
    }
    if (local_1c[3] != (undefined4 *)0x0) {
      bVar1 = true;
      if ((int)local_1c[3][9] <= iVar7) {
        iVar9 = 3;
        iVar7 = local_1c[3][9];
        puVar10 = local_1c[3];
      }
    }
    if (local_c != (undefined4 *)0x0) {
      bVar1 = true;
      if ((int)local_c[9] <= iVar7) {
        iVar9 = 4;
        iVar7 = local_c[9];
        puVar10 = local_c;
      }
    }
    if (local_8 != (undefined4 *)0x0) {
      bVar1 = true;
      if ((int)local_8[9] <= iVar7) {
        iVar9 = 5;
        iVar7 = local_8[9];
        puVar10 = local_8;
      }
    }
    if ((local_4 != (undefined4 *)0x0) && (bVar1 = true, (int)local_4[9] <= iVar7)) {
      iVar9 = 6;
      puVar10 = local_4;
    }
    if (puVar10 != (undefined4 *)0x0) {
      iVar7 = puVar10[6];
      local_1c[iVar9] = (undefined4 *)0x0;
      if (iVar7 != 4) {
        FUN_005983e0(1);
        if (param_2[iVar9 + 1] == -1) {
          pCVar3 = (CRect *)&DAT_007a2300;
        }
        else {
          pCVar3 = (CRect *)(&DAT_007a2010 + param_2[iVar9 + 1] * 0x10);
        }
        CMFCCaptionButtonEx::SetRect(param_1,pCVar3);
      }
      if ((undefined4 *)puVar10[1] == (undefined4 *)0x0) {
        iVar9 = *param_4 + puVar10[3];
        iVar7 = *param_3;
        uVar8 = *(undefined4 *)*puVar10;
      }
      else {
        iVar9 = puVar10[5] + *param_4 + puVar10[3];
        uVar8 = *(undefined4 *)puVar10[1];
        iVar7 = puVar10[4] + *param_3;
      }
      FUN_00598a60(uVar8,iVar7 + puVar10[2],iVar9);
      if (puVar10[6] != 4) {
        FUN_005983e0(0);
      }
      puVar2 = local_1c[0];
      if (puVar10[1] != 0) {
        FUN_00598a60(*(undefined4 *)*puVar10,*param_3 + puVar10[2],*param_4 + puVar10[3]);
        puVar2 = local_1c[0];
      }
    }
  } while (bVar1);
  return;
}

