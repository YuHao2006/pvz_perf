
void __fastcall FUN_00548410(int *param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined1 local_14 [4];
  int local_10;
  undefined1 local_c [8];
  
  (**(code **)(*param_1 + 0x44))();
  FUN_005b75d0(local_c);
  while( true ) {
    iVar1 = param_1[6];
    FUN_00420ae0();
    local_10 = iVar1;
    if (param_1 == (int *)0xfffffffc) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    cVar2 = FUN_006143c0(local_14);
    if (cVar2 != '\0') break;
    piVar3 = (int *)FUN_005e2150();
    *(undefined1 *)(*piVar3 + 0x3c) = 1;
    puVar4 = (undefined4 *)FUN_005e2150();
    (**(code **)(*(int *)*puVar4 + 0x28))();
    FUN_00614350();
  }
  return;
}

