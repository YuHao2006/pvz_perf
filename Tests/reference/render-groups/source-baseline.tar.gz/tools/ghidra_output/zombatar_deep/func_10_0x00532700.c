
void __fastcall FUN_00532700(int param_1)

{
  FUN_0044af50();
  FUN_0044af50();
  if (*(char *)(param_1 + 0x19c) != '\0') {
    if (*(char *)(param_1 + 0x19d) == '\0') {
      *(int *)(param_1 + 0x1a0) = *(int *)(param_1 + 0x1a0) + -3;
      if (*(int *)(param_1 + 0x1a0) < 1) {
        *(undefined4 *)(param_1 + 0x1a0) = 0;
        *(undefined1 *)(param_1 + 0x19d) = 1;
      }
    }
    else {
      *(int *)(param_1 + 0x1a0) = *(int *)(param_1 + 0x1a0) + 3;
      if (0xfe < *(int *)(param_1 + 0x1a0)) {
        *(undefined4 *)(param_1 + 0x1a0) = 0xff;
        *(undefined1 *)(param_1 + 0x19d) = 0;
        return;
      }
    }
  }
  return;
}

