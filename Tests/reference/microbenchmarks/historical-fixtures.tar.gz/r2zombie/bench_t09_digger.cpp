// bench_t09 — kDiggerPhaseCases 8 -> UpdateZombieDigger（矿工期每帧）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::UpdateZombieDigger_A()
{
    if (mZombiePhase == ZombiePhase::PHASE_DIGGER_TUNNELING)
    {
        if (mPosX < 10.0f)
        {
            mAltitude = -120.0f;
            mZombiePhase = ZombiePhase::PHASE_DIGGER_RISING;
            mPhaseCounter = 130;
            PlayZombieReanim(ReanimTrackId::anim_drill, ReanimLoopType::REANIM_LOOP, 0, 20.0f);

            mApp->PlayFoley(FoleyType::FOLEY_DIRT_RISE);
            mApp->PlayFoley(FoleyType::FOLEY_WAKEUP);
            AttachmentDetachCrossFadeParticleType(mAttachmentID, ParticleEffect::PARTICLE_DIGGER_TUNNEL, nullptr);
            StopZombieSound();

            mApp->AddTodParticle(mPosX + 60.0f, mPosY + 118.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_DIGGER_RISE);
            Reanimation* aDirtReanim = mApp->AddReanimation(mPosX + 13.0f, mPosY + 97.0f, mRenderOrder + 1, ReanimationType::REANIM_DIGGER_DIRT);
            aDirtReanim->mAnimRate = 24.0f;
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DIGGER_RISING)
    {
        if (mPhaseCounter > 40)
        {
            mAltitude = TodAnimateCurve(130, 40, mPhaseCounter, -120, 20, Curves::EaseOut);
        }
        else
        {
            mAltitude = TodAnimateCurve(30, 0, mPhaseCounter, 20, 0, Curves::EaseIn);
        }

        if (mPhaseCounter == 30)
        {
            PlayZombieReanim(ReanimTrackId::anim_landing, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
        }

        if (mPhaseCounter == 0)
        {
            mAltitude = 0.0f;
            mZombiePhase = ZombiePhase::PHASE_DIGGER_STUNNED;
            PlayZombieReanim(ReanimTrackId::anim_dizzy, ReanimLoopType::REANIM_LOOP, 10, 12.0f);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DIGGER_TUNNELING_PAUSE_WITHOUT_AXE)
    {
        if (mPhaseCounter == 150)
        {
            AddAttachedReanim(23, 93, ReanimationType::REANIM_ZOMBIE_SURPRISE);
        }

        if (mPhaseCounter == 0)
        {
            mAltitude = -120.f;
            mZombiePhase = ZombiePhase::PHASE_DIGGER_RISE_WITHOUT_AXE;
            mPhaseCounter = 130;
            PlayZombieReanim(ReanimTrackId::anim_landing, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 0.0f);

            mApp->PlayFoley(FoleyType::FOLEY_DIRT_RISE);
            mApp->AddTodParticle(mPosX + 60.0f, mPosY + 118.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_DIGGER_RISE);
            Reanimation* aDirtReanim = mApp->AddReanimation(mPosX + 13.0f, mPosY + 97.0f, mRenderOrder + 1, ReanimationType::REANIM_DIGGER_DIRT);
            aDirtReanim->mAnimRate = 24.0f;
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DIGGER_RISE_WITHOUT_AXE)
    {
        if (mPhaseCounter > 40)
        {
            mAltitude = TodAnimateCurve(130, 40, mPhaseCounter, -120, 20, Curves::EaseOut);
        }
        else
        {
            mAltitude = TodAnimateCurve(30, 0, mPhaseCounter, 20, 0, Curves::EaseIn);
        }

        if (mPhaseCounter == 30)
        {
            PlayZombieReanim(ReanimTrackId::anim_landing, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 12.0f);
        }

        if (mPhaseCounter == 0)
        {
            mAltitude = 0.0f;
            mZombiePhase = ZombiePhase::PHASE_DIGGER_WALKING_WITHOUT_AXE;
            StartWalkAnim(20);
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_DIGGER_STUNNED)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aBodyReanim->mLoopCount > 1)
        {
            mZombiePhase = ZombiePhase::PHASE_DIGGER_WALKING;
            StartWalkAnim(20);
        }
    }
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::UpdateZombieDigger_B()
{
    // C 形态 -> 匿名 lambda 函数指针表 kDiggerPhaseCases（仿 kBossPhaseCases
    // 范式）：行序 = ZombiePhase 枚举序 PHASE_DIGGER_TUNNELING..
    // PHASE_DIGGER_CUTSCENE（8 相位连续）；WALKING/WALKING_WITHOUT_AXE/
    // CUTSCENE 槽 nullptr（原无 case）；RISING 与 RISE_WITHOUT_AXE 两支
    // 末段相位迁移/动画参数不同，非共体，各占一槽。
    using DiggerPhaseFn = void (*)(Zombie&);
    static constexpr DiggerPhaseFn kDiggerPhaseCases[(int)ZombiePhase::PHASE_DIGGER_CUTSCENE - (int)ZombiePhase::PHASE_DIGGER_TUNNELING + 1] = {
        // 原 if PHASE_DIGGER_TUNNELING
        [](Zombie& z)
        {
            if (z.mPosX < 10.0f)
            {
                z.mAltitude = -120.0f;
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_RISING;
                z.mPhaseCounter = 130;
                z.PlayZombieReanim(ReanimTrackId::anim_drill, ReanimLoopType::REANIM_LOOP, 0, 20.0f);

                z.mApp->PlayFoley(FoleyType::FOLEY_DIRT_RISE);
                z.mApp->PlayFoley(FoleyType::FOLEY_WAKEUP);
                AttachmentDetachCrossFadeParticleType(z.mAttachmentID, ParticleEffect::PARTICLE_DIGGER_TUNNEL, nullptr);
                z.StopZombieSound();

                z.mApp->AddTodParticle(z.mPosX + 60.0f, z.mPosY + 118.0f, z.mRenderOrder + 1, ParticleEffect::PARTICLE_DIGGER_RISE);
                Reanimation* aDirtReanim = z.mApp->AddReanimation(z.mPosX + 13.0f, z.mPosY + 97.0f, z.mRenderOrder + 1, ReanimationType::REANIM_DIGGER_DIRT);
                aDirtReanim->mAnimRate = 24.0f;
            }
        },  // PHASE_DIGGER_TUNNELING
        // 原 else-if PHASE_DIGGER_RISING
        [](Zombie& z)
        {
            if (z.mPhaseCounter > 40)
            {
                z.mAltitude = TodAnimateCurve(130, 40, z.mPhaseCounter, -120, 20, Curves::EaseOut);
            }
            else
            {
                z.mAltitude = TodAnimateCurve(30, 0, z.mPhaseCounter, 20, 0, Curves::EaseIn);
            }

            if (z.mPhaseCounter == 30)
            {
                z.PlayZombieReanim(ReanimTrackId::anim_landing, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
            }

            if (z.mPhaseCounter == 0)
            {
                z.mAltitude = 0.0f;
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_STUNNED;
                z.PlayZombieReanim(ReanimTrackId::anim_dizzy, ReanimLoopType::REANIM_LOOP, 10, 12.0f);
            }
        },  // PHASE_DIGGER_RISING
        // 原 else-if PHASE_DIGGER_TUNNELING_PAUSE_WITHOUT_AXE
        [](Zombie& z)
        {
            if (z.mPhaseCounter == 150)
            {
                z.AddAttachedReanim(23, 93, ReanimationType::REANIM_ZOMBIE_SURPRISE);
            }

            if (z.mPhaseCounter == 0)
            {
                z.mAltitude = -120.f;
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_RISE_WITHOUT_AXE;
                z.mPhaseCounter = 130;
                z.PlayZombieReanim(ReanimTrackId::anim_landing, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 0.0f);

                z.mApp->PlayFoley(FoleyType::FOLEY_DIRT_RISE);
                z.mApp->AddTodParticle(z.mPosX + 60.0f, z.mPosY + 118.0f, z.mRenderOrder + 1, ParticleEffect::PARTICLE_DIGGER_RISE);
                Reanimation* aDirtReanim = z.mApp->AddReanimation(z.mPosX + 13.0f, z.mPosY + 97.0f, z.mRenderOrder + 1, ReanimationType::REANIM_DIGGER_DIRT);
                aDirtReanim->mAnimRate = 24.0f;
            }
        },  // PHASE_DIGGER_TUNNELING_PAUSE_WITHOUT_AXE
        // 原 else-if PHASE_DIGGER_RISE_WITHOUT_AXE
        [](Zombie& z)
        {
            if (z.mPhaseCounter > 40)
            {
                z.mAltitude = TodAnimateCurve(130, 40, z.mPhaseCounter, -120, 20, Curves::EaseOut);
            }
            else
            {
                z.mAltitude = TodAnimateCurve(30, 0, z.mPhaseCounter, 20, 0, Curves::EaseIn);
            }

            if (z.mPhaseCounter == 30)
            {
                z.PlayZombieReanim(ReanimTrackId::anim_landing, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 20, 12.0f);
            }

            if (z.mPhaseCounter == 0)
            {
                z.mAltitude = 0.0f;
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_WALKING_WITHOUT_AXE;
                z.StartWalkAnim(20);
            }
        },  // PHASE_DIGGER_RISE_WITHOUT_AXE
        // 原 else-if PHASE_DIGGER_STUNNED
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (aBodyReanim->mLoopCount > 1)
            {
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_WALKING;
                z.StartWalkAnim(20);
            }
        },  // PHASE_DIGGER_STUNNED
        nullptr,  // PHASE_DIGGER_WALKING（原无 case）
        nullptr,  // PHASE_DIGGER_WALKING_WITHOUT_AXE（原无 case）
        nullptr,  // PHASE_DIGGER_CUTSCENE（原无 case）
    };
    static_assert(sizeof(kDiggerPhaseCases) / sizeof(kDiggerPhaseCases[0]) ==
        (int)ZombiePhase::PHASE_DIGGER_CUTSCENE - (int)ZombiePhase::PHASE_DIGGER_TUNNELING + 1,
        "kDiggerPhaseCases 槽位须与 ZombiePhase DIGGER 段同步");

    const unsigned aPhaseIndex = static_cast<unsigned>(mZombiePhase) - static_cast<unsigned>(ZombiePhase::PHASE_DIGGER_TUNNELING);
    if (aPhaseIndex < sizeof(kDiggerPhaseCases) / sizeof(kDiggerPhaseCases[0]) &&
        kDiggerPhaseCases[aPhaseIndex] != nullptr)
    {
        kDiggerPhaseCases[aPhaseIndex](*this);
    }
}

static Zombie g_z;
static void ResetDigger(const ZBInput& in)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    // 段前 1 值 .. 段后 1 值（含 3 个 nullptr 槽 + 越界）
    g_z.mZombiePhase = (ZombiePhase)((int)ZombiePhase::PHASE_DIGGER_TUNNELING + (int)(in.a % 10) - 1);
    g_z.mPosX = (float)(in.b % 40);
    g_z.mPosY = (float)(in.c % 600);
    g_z.mPhaseCounter = (int)(in.c % 200) - 10;
    g_z.mRenderOrder = (int)(in.d % 1000);
    g_z.mAltitude = -100.0f + (float)(in.d % 150);
    g_z.mBodyReanimID = (ReanimationID)(1 + in.a % 2);
    g_zb_reanimA.mLoopCount = (int)(in.a % 4);
    g_zb_reanimB.mLoopCount = (int)(in.b % 4);
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetDigger(g_zb_inputs[i]);
            g_z.UpdateZombieDigger_A();
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetDigger(g_zb_inputs[i]);
            g_z.UpdateZombieDigger_B();
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t09_DiggerPhase", passA, passB);
}
