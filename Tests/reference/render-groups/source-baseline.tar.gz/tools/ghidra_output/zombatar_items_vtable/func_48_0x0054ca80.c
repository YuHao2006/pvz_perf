
undefined4 __thiscall
FUN_0054ca80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  piVar1 = (int *)FUN_00598310();
  iVar2 = (**(code **)(*piVar1 + 0x1c))(param_5);
  FUN_00598a10(param_5,(*(int *)(param_1 + 0x48) - iVar2) / 2,param_4);
  uVar3 = (**(code **)(*piVar1 + 0x10))();
  (**(code **)(*piVar1 + 4))(iVar2,uVar3);
  FUN_00401a90(iVar2,uVar3);
  return param_2;
}

