
void __thiscall FUN_00547b00(int *param_1,char param_2,char param_3)

{
  undefined4 *puVar1;
  undefined1 local_18 [8];
  int *local_10;
  int *local_c;
  int *local_8;
  
  while (param_1[7] != 0) {
    FUN_005b75d0(local_18);
    puVar1 = (undefined4 *)FUN_005e2150();
    local_8 = (int *)*puVar1;
    (**(code **)(*param_1 + 0x10))(local_8);
    if (param_3 != '\0') {
      (**(code **)(*local_8 + 0x1c))(param_2,param_3);
    }
    if (param_2 != '\0') {
      local_10 = local_8;
      local_c = local_8;
      if (local_8 != (int *)0x0) {
        (**(code **)*local_8)(1);
      }
    }
  }
  return;
}

