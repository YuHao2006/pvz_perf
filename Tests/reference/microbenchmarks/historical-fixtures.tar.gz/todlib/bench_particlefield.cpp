// bench_particlefield.cpp — 目标12：TodParticleEmitter::UpdateParticleField
// FormA = ac447d19^ 改造前（11 case switch + default TOD_ASSERT(0)）
// FormB = HEAD 终态（kParticleFieldCases 12 槽 lambda 表 + 越界守卫）
// 输入：2M 均匀分布 ParticleFieldType(0..11)，固定种子，两形态消费同一数组。
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <random>
#include <cmath>
#include <cstdlib>

// ---------------- harness ----------------
static uint64_t g_cs = 0;
static inline void CsMix(uint64_t v) { g_cs = g_cs * 0x9E3779B97F4A7C15ull + v; }
static uint64_t QpcFreq() { static uint64_t f = 0; if (!f) { LARGE_INTEGER li; QueryPerformanceFrequency(&li); f = (uint64_t)li.QuadPart; } return f; }
static uint64_t QpcNow() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (uint64_t)c.QuadPart; }
static double QpcToNs(uint64_t ticks) { return (double)ticks * 1e9 / (double)QpcFreq(); }
#define TOD_ASSERT(...) ((void)0)

// ---------------- game type stubs ----------------
enum ParticleFieldType
{
    FIELD_INVALID,
    FIELD_FRICTION,
    FIELD_ACCELERATION,
    FIELD_ATTRACTOR,
    FIELD_MAX_VELOCITY,
    FIELD_VELOCITY,
    FIELD_POSITION,
    FIELD_SYSTEM_POSITION,
    FIELD_GROUND_CONSTRAINT,
    FIELD_SHAKE,
    FIELD_CIRCLE,
    FIELD_AWAY,
    PARTICLE_FIELD_COUNT
};
#define MAX_PARTICLE_FIELDS 4

enum ParticleTracks
{
    TRACK_PARTICLE_RED, TRACK_PARTICLE_GREEN, TRACK_PARTICLE_BLUE, TRACK_PARTICLE_ALPHA, TRACK_PARTICLE_BRIGHTNESS,
    TRACK_PARTICLE_SPIN_SPEED, TRACK_PARTICLE_SPIN_ANGLE, TRACK_PARTICLE_SCALE, TRACK_PARTICLE_STRETCH,
    TRACK_PARTICLE_COLLISION_REFLECT, TRACK_PARTICLE_COLLISION_SPIN,
    TRACK_PARTICLE_CLIP_TOP, TRACK_PARTICLE_CLIP_BOTTOM, TRACK_PARTICLE_CLIP_LEFT, TRACK_PARTICLE_CLIP_RIGHT,
    TRACK_PARTICLE_ANIMATION_RATE, NUM_PARTICLE_TRACKS
};

struct SexyVector2
{
    float x = 0.0f, y = 0.0f;
    SexyVector2() {}
    SexyVector2(float theX, float theY) : x(theX), y(theY) {}
    SexyVector2 operator-(const SexyVector2& o) const { return SexyVector2(x - o.x, y - o.y); }
    SexyVector2 operator+(const SexyVector2& o) const { return SexyVector2(x + o.x, y + o.y); }
    SexyVector2 operator*(float t) const { return SexyVector2(t * x, t * y); }
    void operator*=(float t) { x *= t; y *= t; }
    void operator+=(const SexyVector2& o) { x += o.x; y += o.y; }
    float Magnitude() const { return sqrtf(x * x + y * y); }
    SexyVector2 Normalize() const { float m = Magnitude(); if (m > 0.0f) return SexyVector2(x / m, y / m); return *this; }
    SexyVector2 Perp() const { return SexyVector2(-y, x); }
};

class FloatParameterTrack { public: int mCountNodes = 0; };

class ParticleField
{
public:
    ParticleFieldType mFieldType = FIELD_INVALID;
    FloatParameterTrack mX, mY;
};

class TodParticle
{
public:
    int mParticleDuration = 10, mParticleAge = 3;
    float mParticleTimeValue = 1.5f, mParticleLastTimeValue = 1.0f;
    SexyVector2 mVelocity, mPosition;
    float mSpinVelocity = 0.0f;
    float mParticleInterp[ParticleTracks::NUM_PARTICLE_TRACKS];
    float mParticleFieldInterp[MAX_PARTICLE_FIELDS][2];
    TodParticle() { for (int i = 0; i < NUM_PARTICLE_TRACKS; i++) mParticleInterp[i] = 0.25f * (i + 1); for (int i = 0; i < MAX_PARTICLE_FIELDS; i++) { mParticleFieldInterp[i][0] = 0.3f; mParticleFieldInterp[i][1] = 0.6f; } }
};

class TodEmitterDefinition
{
public:
    FloatParameterTrack mCollisionReflect, mCollisionSpin;
};

// 游戏函数 → 同签名空桩（编号入 checksum）
static float FloatTrackEvaluate(FloatParameterTrack& theTrack, float theTimeValue, float theInterp)
{
    CsMix(41);
    return theInterp * 1.7f + theTimeValue * 0.3f + (float)(theTrack.mCountNodes & 7);
}
static float FloatTrackEvaluateFromLastTime(FloatParameterTrack& theTrack, float theTimeValue, float theInterp)
{
    return theTimeValue < 0.0f ? 0.0f : FloatTrackEvaluate(theTrack, theTimeValue, theInterp);
}
static inline float ClampFloat(float theValue, float theMin, float theMax)
{
    if (theValue < theMin) return theMin;
    if (theValue > theMax) return theMax;
    return theValue;
}

class TodParticleEmitter
{
public:
    TodEmitterDefinition* mEmitterDef;
    SexyVector2 mSystemCenter;

    void UpdateParticleField_A(TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, int theFieldIndex);
    void UpdateParticleField_B(TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, int theFieldIndex);
};

// ================= FormA：改造前（ac447d19^ 逐字） =================
__declspec(noinline) void TodParticleEmitter::UpdateParticleField_A(TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, int theFieldIndex)
{
	TOD_ASSERT(theFieldIndex < MAX_PARTICLE_FIELDS);
	float aInterpX = theParticle->mParticleFieldInterp[theFieldIndex][0];
	float aInterpY = theParticle->mParticleFieldInterp[theFieldIndex][1];
	float x = FloatTrackEvaluate(theParticleField->mX, theParticleTimeValue, aInterpX);
	float y = FloatTrackEvaluate(theParticleField->mY, theParticleTimeValue, aInterpY);

	switch (theParticleField->mFieldType)
	{
	case ParticleFieldType::FIELD_INVALID:
		break;
	case ParticleFieldType::FIELD_FRICTION:  // 摩擦力场
		theParticle->mVelocity.x *= 1 - x;
		theParticle->mVelocity.y *= 1 - y;
		break;
	case ParticleFieldType::FIELD_ACCELERATION:  // 加速度场
		theParticle->mVelocity.x += 0.01f * x;
		theParticle->mVelocity.y += 0.01f * y;
		break;
	case ParticleFieldType::FIELD_ATTRACTOR:  // 弹性力场
	{
		float aDiffX = x - (theParticle->mPosition.x - mSystemCenter.x);
		float aDiffY = y - (theParticle->mPosition.y - mSystemCenter.y);
		// 加速度的方向始终从粒子所在位置指向“标准位置”
		theParticle->mVelocity.x += 0.01f * aDiffX;
		theParticle->mVelocity.y += 0.01f * aDiffY;
		break;
	}
	case ParticleFieldType::FIELD_MAX_VELOCITY:  // 限速场
		theParticle->mVelocity.x = ClampFloat(theParticle->mVelocity.x, -x, x);
		theParticle->mVelocity.y = ClampFloat(theParticle->mVelocity.y, -y, y);
		break;
	case ParticleFieldType::FIELD_VELOCITY:  // 匀速场
		theParticle->mPosition.x += 0.01 * x;
		theParticle->mPosition.y += 0.01 * y;
		break;
	case ParticleFieldType::FIELD_POSITION:  // 定位场
	{
		float aLastX = FloatTrackEvaluateFromLastTime(theParticleField->mX, theParticle->mParticleLastTimeValue, aInterpX);
		float aLastY = FloatTrackEvaluateFromLastTime(theParticleField->mY, theParticle->mParticleLastTimeValue, aInterpY);
		theParticle->mPosition.x += x - aLastX;
		theParticle->mPosition.y += y - aLastY;
		break;
	}
	case ParticleFieldType::FIELD_GROUND_CONSTRAINT:
		if (theParticle->mPosition.y > mSystemCenter.y + y)  // 判断是否触及地面
		{
			theParticle->mPosition.y = mSystemCenter.y + y;  // 将坐标重置至地面
			float aCollisionReflect = FloatTrackEvaluate(
				mEmitterDef->mCollisionReflect, theParticleTimeValue, theParticle->mParticleInterp[ParticleTracks::TRACK_PARTICLE_COLLISION_REFLECT]
			);
			float aCollisionSpin = FloatTrackEvaluate(
				mEmitterDef->mCollisionSpin, theParticleTimeValue, theParticle->mParticleInterp[ParticleTracks::TRACK_PARTICLE_COLLISION_SPIN]
			) / 1000.0f;
			theParticle->mSpinVelocity = theParticle->mVelocity.y * aCollisionSpin;
			theParticle->mVelocity.x *= aCollisionReflect;
			theParticle->mVelocity.y *= -aCollisionReflect;
		}
		break;
	case ParticleFieldType::FIELD_SHAKE:  // 震动
	{
		float aLastX = FloatTrackEvaluateFromLastTime(theParticleField->mX, theParticle->mParticleLastTimeValue, aInterpX);
		float aLastY = FloatTrackEvaluateFromLastTime(theParticleField->mY, theParticle->mParticleLastTimeValue, aInterpY);
		// 先恢复上一次震动效果的影响
		int aLastRandSeed = theParticle->mParticleAge - 1;
		if (aLastRandSeed == -1)
			aLastRandSeed = theParticle->mParticleDuration - 1;
		srand(aLastRandSeed * (uintptr_t)theParticle);
		theParticle->mPosition.x -= aLastX * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
		theParticle->mPosition.y -= aLastY * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
		// 再随机取得当前帧的震动效果
		srand(theParticle->mParticleAge * (uintptr_t)theParticle);
		theParticle->mPosition.x += x * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
		theParticle->mPosition.y += y * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
		break;
	}
	case ParticleFieldType::FIELD_CIRCLE:  // 圆周
	{
		SexyVector2 aToCenter = theParticle->mPosition - mSystemCenter;
		SexyVector2 aMotion = aToCenter.Perp().Normalize();  // 标准化的法向量
		float aRadius = aToCenter.Magnitude();
		aMotion *= 0.01 * (x + aRadius * y);
		theParticle->mPosition += aMotion;
		break;
	}
	case ParticleFieldType::FIELD_AWAY:  // 远离
	{
		SexyVector2 aToCenter = theParticle->mPosition - mSystemCenter;
		SexyVector2 aMotion = aToCenter.Normalize();  // 标准化的方向向量
		float aRadius = aToCenter.Magnitude();
		aMotion *= 0.01 * (x + aRadius * y);
		theParticle->mPosition += aMotion;
		break;
	}
	default:
		TOD_ASSERT(0);
		break;
	}
}

// ================= FormB：当前终态（HEAD 逐字） =================
namespace
{
using ParticleFieldCaseFn = void (*)(TodParticleEmitter&, TodParticle*, ParticleField*, float, float, float, float, float);

void ParticleFieldDefault(TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
{
    		TOD_ASSERT(0);
}

constexpr ParticleFieldCaseFn kParticleFieldCases[(int)ParticleFieldType::PARTICLE_FIELD_COUNT] = {
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {

    },  // 0 FIELD_INVALID
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 摩擦力场
    		theParticle->mVelocity.x *= 1 - x;
    		theParticle->mVelocity.y *= 1 - y;
    },  // 1 FIELD_FRICTION
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 加速度场
    		theParticle->mVelocity.x += 0.01f * x;
    		theParticle->mVelocity.y += 0.01f * y;
    },  // 2 FIELD_ACCELERATION
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 弹性力场
    		float aDiffX = x - (theParticle->mPosition.x - e.mSystemCenter.x);
    		float aDiffY = y - (theParticle->mPosition.y - e.mSystemCenter.y);
    		// 加速度的方向始终从粒子所在位置指向“标准位置”
    		theParticle->mVelocity.x += 0.01f * aDiffX;
    		theParticle->mVelocity.y += 0.01f * aDiffY;
    },  // 3 FIELD_ATTRACTOR
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 限速场
    		theParticle->mVelocity.x = ClampFloat(theParticle->mVelocity.x, -x, x);
    		theParticle->mVelocity.y = ClampFloat(theParticle->mVelocity.y, -y, y);
    },  // 4 FIELD_MAX_VELOCITY
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 匀速场
    		theParticle->mPosition.x += 0.01 * x;
    		theParticle->mPosition.y += 0.01 * y;
    },  // 5 FIELD_VELOCITY
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 定位场
    		float aLastX = FloatTrackEvaluateFromLastTime(theParticleField->mX, theParticle->mParticleLastTimeValue, aInterpX);
    		float aLastY = FloatTrackEvaluateFromLastTime(theParticleField->mY, theParticle->mParticleLastTimeValue, aInterpY);
    		theParticle->mPosition.x += x - aLastX;
    		theParticle->mPosition.y += y - aLastY;
    },  // 6 FIELD_POSITION
    &ParticleFieldDefault,  // 7 FIELD_SYSTEM_POSITION（原 default）
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    		if (theParticle->mPosition.y > e.mSystemCenter.y + y)  // 判断是否触及地面
    		{
    			theParticle->mPosition.y = e.mSystemCenter.y + y;  // 将坐标重置至地面
    			float aCollisionReflect = FloatTrackEvaluate(
    				e.mEmitterDef->mCollisionReflect, theParticleTimeValue, theParticle->mParticleInterp[ParticleTracks::TRACK_PARTICLE_COLLISION_REFLECT]
    			);
    			float aCollisionSpin = FloatTrackEvaluate(
    				e.mEmitterDef->mCollisionSpin, theParticleTimeValue, theParticle->mParticleInterp[ParticleTracks::TRACK_PARTICLE_COLLISION_SPIN]
    			) / 1000.0f;
    			theParticle->mSpinVelocity = theParticle->mVelocity.y * aCollisionSpin;
    			theParticle->mVelocity.x *= aCollisionReflect;
    			theParticle->mVelocity.y *= -aCollisionReflect;
    		}
    },  // 8 FIELD_GROUND_CONSTRAINT
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 震动
    		float aLastX = FloatTrackEvaluateFromLastTime(theParticleField->mX, theParticle->mParticleLastTimeValue, aInterpX);
    		float aLastY = FloatTrackEvaluateFromLastTime(theParticleField->mY, theParticle->mParticleLastTimeValue, aInterpY);
    		// 先恢复上一次震动效果的影响
    		int aLastRandSeed = theParticle->mParticleAge - 1;
    		if (aLastRandSeed == -1)
    			aLastRandSeed = theParticle->mParticleDuration - 1;
    		srand(aLastRandSeed * (uintptr_t)theParticle);
    		theParticle->mPosition.x -= aLastX * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
    		theParticle->mPosition.y -= aLastY * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
    		// 再随机取得当前帧的震动效果
    		srand(theParticle->mParticleAge * (uintptr_t)theParticle);
    		theParticle->mPosition.x += x * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
    		theParticle->mPosition.y += y * ((float)rand() / RAND_MAX * 2.0f - 1.0f);
    },  // 9 FIELD_SHAKE
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 圆周
    		SexyVector2 aToCenter = theParticle->mPosition - e.mSystemCenter;
    		SexyVector2 aMotion = aToCenter.Perp().Normalize();  // 标准化的法向量
    		float aRadius = aToCenter.Magnitude();
    		aMotion *= 0.01 * (x + aRadius * y);
    		theParticle->mPosition += aMotion;
    },  // 10 FIELD_CIRCLE
    [](TodParticleEmitter& e, TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, float x, float y, float aInterpX, float aInterpY)
    {
    // 远离
    		SexyVector2 aToCenter = theParticle->mPosition - e.mSystemCenter;
    		SexyVector2 aMotion = aToCenter.Normalize();  // 标准化的方向向量
    		float aRadius = aToCenter.Magnitude();
    		aMotion *= 0.01 * (x + aRadius * y);
    		theParticle->mPosition += aMotion;
    },  // 11 FIELD_AWAY
};
static_assert(sizeof(kParticleFieldCases) / sizeof(kParticleFieldCases[0]) ==
    (int)ParticleFieldType::PARTICLE_FIELD_COUNT, "kParticleFieldCases 槽位数须与 ParticleFieldType 枚举同步");
}  // namespace

__declspec(noinline) void TodParticleEmitter::UpdateParticleField_B(TodParticle* theParticle, ParticleField* theParticleField, float theParticleTimeValue, int theFieldIndex)
{
	TOD_ASSERT(theFieldIndex < MAX_PARTICLE_FIELDS);
	float aInterpX = theParticle->mParticleFieldInterp[theFieldIndex][0];
	float aInterpY = theParticle->mParticleFieldInterp[theFieldIndex][1];
	float x = FloatTrackEvaluate(theParticleField->mX, theParticleTimeValue, aInterpX);
	float y = FloatTrackEvaluate(theParticleField->mY, theParticleTimeValue, aInterpY);

	const unsigned aFieldTypeIndex = static_cast<unsigned>(theParticleField->mFieldType);
	if (aFieldTypeIndex < static_cast<unsigned>(ParticleFieldType::PARTICLE_FIELD_COUNT))
	{
		kParticleFieldCases[aFieldTypeIndex](*this, theParticle, theParticleField, theParticleTimeValue, x, y, aInterpX, aInterpY);
	}
	else
	{
		ParticleFieldDefault(*this, theParticle, theParticleField, theParticleTimeValue, x, y, aInterpX, aInterpY);
	}

}

// ---------------- bench driver ----------------
static const int N = 2000000;
static int g_input[N];

static inline uint64_t FBits(float f) { uint64_t u; memcpy(&u, &f, 4); return u; }

static void MixParticle(const TodParticle& p)
{
    CsMix(FBits(p.mPosition.x) << 32 | FBits(p.mPosition.y));
    CsMix(FBits(p.mVelocity.x) << 32 | FBits(p.mVelocity.y));
    CsMix(FBits(p.mSpinVelocity));
}

static TodParticle g_p;
static TodEmitterDefinition g_def;
static TodParticleEmitter g_em;   // 两形态共用同一发射器对象（A/B 是同一函数的两个时代形态）
static ParticleField g_field;     // 两形态共用同一场对象（地址一致，排除桩外变量）

static void ResetParticle(TodParticle& p)
{
    p.mPosition = SexyVector2(10.0f, 50.0f);
    p.mVelocity = SexyVector2(2.0f, 3.0f);
    p.mSpinVelocity = 0.0f;
}

static void RunPassA(const int* in, int n, bool mix)
{
    ParticleField& f = g_field; f.mX.mCountNodes = 1; f.mY.mCountNodes = 2;
    ResetParticle(g_p);
    srand(1);
    for (int k = 0; k < n; k++)
    {
        if ((k & 255) == 0) ResetParticle(g_p);  // 粒子定期重生：状态有界（游戏内粒子寿命有限，同构）
        f.mFieldType = (ParticleFieldType)in[k];
        g_em.UpdateParticleField_A(&g_p, &f, 1.5f, 0);
        if (mix) MixParticle(g_p);
    }
}
static void RunPassB(const int* in, int n, bool mix)
{
    ParticleField& f = g_field; f.mX.mCountNodes = 1; f.mY.mCountNodes = 2;
    ResetParticle(g_p);
    srand(1);
    for (int k = 0; k < n; k++)
    {
        if ((k & 255) == 0) ResetParticle(g_p);
        f.mFieldType = (ParticleFieldType)in[k];
        g_em.UpdateParticleField_B(&g_p, &f, 1.5f, 0);
        if (mix) MixParticle(g_p);
    }
}

int main()
{
    std::mt19937 rng(20261002);
    std::uniform_int_distribution<int> dist(0, (int)ParticleFieldType::FIELD_AWAY);
    for (int k = 0; k < N; k++) g_input[k] = dist(rng);

    g_def.mCollisionReflect.mCountNodes = 1; g_def.mCollisionSpin.mCountNodes = 2;
    g_em.mEmitterDef = &g_def;
    g_em.mSystemCenter = SexyVector2(30.0f, 40.0f);
    ResetParticle(g_p);

    // ---- checksum pass ----
    g_cs = 0; RunPassA(g_input, N, true); uint64_t csA = g_cs;
    g_cs = 0; RunPassB(g_input, N, true); uint64_t csB = g_cs;
    bool csOK = (csA == csB);

    // ---- warmup ----
    RunPassA(g_input, 10000, false); RunPassB(g_input, 10000, false);

    // ---- timing：min-of-5，A/B 交错 ----
    uint64_t aMin = UINT64_MAX, bMin = UINT64_MAX;
    for (int rep = 0; rep < 5; rep++)
    {
        uint64_t t0 = QpcNow(); RunPassA(g_input, N, false); uint64_t t1 = QpcNow();
        uint64_t t2 = QpcNow(); RunPassB(g_input, N, false); uint64_t t3 = QpcNow();
        if (t1 - t0 < aMin) aMin = t1 - t0;
        if (t3 - t2 < bMin) bMin = t3 - t2;
    }

    double nsA = QpcToNs(aMin) / N;
    double nsB = QpcToNs(bMin) / N;
    double diff = (nsB - nsA) / nsA * 100.0;
    printf("UpdateParticleField | before %.2f ns | after %.2f ns | diff %+.2f%% | checksum=%s (A=%016llx B=%016llx)\n",
        nsA, nsB, diff, csOK ? "OK" : "FAIL", (unsigned long long)csA, (unsigned long long)csB);
    return csOK ? 0 : 1;
}
