// bench_t11 — kMowDownCases 34 -> Zombie::MowDown（割草机命中事件）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::MowDown_A()
{
    if (mDead || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED || mZombieType == ZombieType::ZOMBIE_BOSS)
        return;

    if (mZombieType == ZombieType::ZOMBIE_CATAPULT)
    {
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 60.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_CATAPULT_EXPLOSION);
        mApp->PlayFoley(FoleyType::FOLEY_EXPLOSION);
        DieWithLoot();
        return;
    }

    if (mZombieType == ZombieType::ZOMBIE_ZAMBONI)
    {
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 60.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_ZAMBONI_EXPLOSION);
        mApp->PlayFoley(FoleyType::FOLEY_EXPLOSION);
        DieWithLoot();
        return;
    }

    if (mZombiePhase == ZombiePhase::PHASE_ZOMBIE_DYING ||
        mZombiePhase == ZombiePhase::PHASE_POLEVAULTER_IN_VAULT ||
        mZombiePhase == ZombiePhase::PHASE_RISING_FROM_GRAVE ||
        mZombiePhase == ZombiePhase::PHASE_DANCER_RISING ||
        mZombiePhase == ZombiePhase::PHASE_SNORKEL_INTO_POOL ||
        mZombiePhase == ZombiePhase::PHASE_ZOMBIE_BURNED ||
        mZombieType == ZombieType::ZOMBIE_GARGANTUAR ||
        mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR ||
        mZombieType == ZombieType::ZOMBIE_BUNGEE ||
        mZombieType == ZombieType::ZOMBIE_DIGGER ||
        mZombieType == ZombieType::ZOMBIE_IMP ||
        mZombieType == ZombieType::ZOMBIE_YETI ||
        mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER ||
        IsBobsledTeamWithSled() ||
        IsFlying() ||
        mInPool)
    {
        Reanimation* aPuffReanim = mApp->AddReanimation(mPosX - 73.0f, mPosY - 56.0f, mRenderOrder + 2, ReanimationType::REANIM_PUFF);
        aPuffReanim->SetFramesForLayer(ReanimTrackId::anim_puff);
        mApp->AddTodParticle(mPosX + 110.0f, mPosY + 0.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_MOWER_CLOUD);

        if (mBoard->mPlantRow[mRow] != PlantRowType::PLANTROW_POOL)
        {
            DropHead(0U);
            DropArm(0U);
            DropHelm(0U);
            DropShield(0U);
        }

        DieWithLoot();
        return;
    }

    if (mIceTrapCounter > 0)
    {
        RemoveIceTrap();
    }
    if (mButteredCounter > 0)
    {
        mButteredCounter = 0;
    }

    DropShield(0U);
    DropHelm(0U);
    if (mZombieType == ZombieType::ZOMBIE_FLAG ||
        mZombieType == ZombieType::ZOMBIE_ZOMBATAR)
    {
        DropFlag();
    }
    else if (mZombieType == ZombieType::ZOMBIE_POLEVAULTER)
    {
        DropPole();
    }
    else if (mZombieType == ZombieType::ZOMBIE_NEWSPAPER || mZombieType == ZombieType::ZOMBIE_BALLOON)
    {
        DropHead(0U);
    }
    else if (mZombieType == ZombieType::ZOMBIE_POGO)
    {
        DropHead(0U);
        mAltitude = 0.0f;
    }

    Reanimation* aMoweredReanim = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder, ReanimationType::REANIM_LAWN_MOWERED_ZOMBIE);
    aMoweredReanim->mAnimRate = 8.0f;
    aMoweredReanim->mIsAttachment = false;
    aMoweredReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;
    mMoweredReanimID = mApp->ReanimationGetID(aMoweredReanim);
    mZombiePhase = ZombiePhase::PHASE_ZOMBIE_MOWERED;
    DropLoot();
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::MowDown_B()
{
    if (mDead || mZombiePhase == ZombiePhase::PHASE_ZOMBIE_MOWERED || mZombieType == ZombieType::ZOMBIE_BOSS)
        return;

    if (mZombieType == ZombieType::ZOMBIE_CATAPULT)
    {
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 60.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_CATAPULT_EXPLOSION);
        mApp->PlayFoley(FoleyType::FOLEY_EXPLOSION);
        DieWithLoot();
        return;
    }

    if (mZombieType == ZombieType::ZOMBIE_ZAMBONI)
    {
        mApp->AddTodParticle(mPosX + 80.0f, mPosY + 60.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_ZAMBONI_EXPLOSION);
        mApp->PlayFoley(FoleyType::FOLEY_EXPLOSION);
        DieWithLoot();
        return;
    }

    if (mZombiePhase == ZombiePhase::PHASE_ZOMBIE_DYING ||
        mZombiePhase == ZombiePhase::PHASE_POLEVAULTER_IN_VAULT ||
        mZombiePhase == ZombiePhase::PHASE_RISING_FROM_GRAVE ||
        mZombiePhase == ZombiePhase::PHASE_DANCER_RISING ||
        mZombiePhase == ZombiePhase::PHASE_SNORKEL_INTO_POOL ||
        mZombiePhase == ZombiePhase::PHASE_ZOMBIE_BURNED ||
        mZombieType == ZombieType::ZOMBIE_GARGANTUAR ||
        mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR ||
        mZombieType == ZombieType::ZOMBIE_BUNGEE ||
        mZombieType == ZombieType::ZOMBIE_DIGGER ||
        mZombieType == ZombieType::ZOMBIE_IMP ||
        mZombieType == ZombieType::ZOMBIE_YETI ||
        mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER ||
        IsBobsledTeamWithSled() ||
        IsFlying() ||
        mInPool)
    {
        Reanimation* aPuffReanim = mApp->AddReanimation(mPosX - 73.0f, mPosY - 56.0f, mRenderOrder + 2, ReanimationType::REANIM_PUFF);
        aPuffReanim->SetFramesForLayer(ReanimTrackId::anim_puff);
        mApp->AddTodParticle(mPosX + 110.0f, mPosY + 0.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_MOWER_CLOUD);

        if (mBoard->mPlantRow[mRow] != PlantRowType::PLANTROW_POOL)
        {
            DropHead(0U);
            DropArm(0U);
            DropHelm(0U);
            DropShield(0U);
        }

        DieWithLoot();
        return;
    }

    if (mIceTrapCounter > 0)
    {
        RemoveIceTrap();
    }
    if (mButteredCounter > 0)
    {
        mButteredCounter = 0;
    }

    DropShield(0U);
    DropHelm(0U);
    // C 形态 -> 匿名 lambda 函数指针表 kMowDownCases（仿 kSeedTypeUpdates
    // 范式）：行序 = ZombieType 枚举序 0..33；原 4 支中 FLAG/ZOMBATAR 与
    // NEWSPAPER/BALLOON 各为共体（constexpr 指针变量复用同一 lambda）；
    // 无 case 槽 = nullptr（原链无命中 = 无操作）。
    using MowDownCaseFn = void (*)(Zombie&);
    static constexpr MowDownCaseFn kMowDownDropFlag = [](Zombie& z) { z.DropFlag(); };
    static constexpr MowDownCaseFn kMowDownDropHead = [](Zombie& z) { z.DropHead(0U); };
    static constexpr MowDownCaseFn kMowDownCases[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
        nullptr,  // 0 ZOMBIE_NORMAL（无 case）
        kMowDownDropFlag,  // 1 ZOMBIE_FLAG（共体）
        nullptr,  // 2 ZOMBIE_TRAFFIC_CONE（无 case）
        // 原 else-if ZOMBIE_POLEVAULTER
        [](Zombie& z) { z.DropPole(); },  // 3 ZOMBIE_POLEVAULTER
        nullptr,  // 4 ZOMBIE_PAIL（无 case）
        kMowDownDropHead,  // 5 ZOMBIE_NEWSPAPER（共体）
        nullptr,  // 6 ZOMBIE_DOOR（无 case）
        nullptr,  // 7 ZOMBIE_FOOTBALL（无 case）
        nullptr,  // 8 ZOMBIE_DANCER（无 case）
        nullptr,  // 9 ZOMBIE_BACKUP_DANCER（无 case）
        nullptr,  // 10 ZOMBIE_DUCKY_TUBE（无 case）
        nullptr,  // 11 ZOMBIE_SNORKEL（无 case）
        nullptr,  // 12 ZOMBIE_ZAMBONI（无 case）
        nullptr,  // 13 ZOMBIE_BOBSLED（无 case）
        nullptr,  // 14 ZOMBIE_DOLPHIN_RIDER（无 case）
        nullptr,  // 15 ZOMBIE_JACK_IN_THE_BOX（无 case）
        kMowDownDropHead,  // 16 ZOMBIE_BALLOON（共体）
        nullptr,  // 17 ZOMBIE_DIGGER（无 case）
        // 原 else-if ZOMBIE_POGO
        [](Zombie& z)
        {
            z.DropHead(0U);
            z.mAltitude = 0.0f;
        },  // 18 ZOMBIE_POGO
        nullptr,  // 19 ZOMBIE_YETI（无 case）
        nullptr,  // 20 ZOMBIE_BUNGEE（无 case）
        nullptr,  // 21 ZOMBIE_LADDER（无 case）
        nullptr,  // 22 ZOMBIE_CATAPULT（无 case）
        nullptr,  // 23 ZOMBIE_GARGANTUAR（无 case）
        nullptr,  // 24 ZOMBIE_IMP（无 case）
        nullptr,  // 25 ZOMBIE_BOSS（无 case）
        nullptr,  // 26 ZOMBIE_PEA_HEAD（无 case）
        nullptr,  // 27 ZOMBIE_WALLNUT_HEAD（无 case）
        nullptr,  // 28 ZOMBIE_JALAPENO_HEAD（无 case）
        nullptr,  // 29 ZOMBIE_GATLING_HEAD（无 case）
        nullptr,  // 30 ZOMBIE_SQUASH_HEAD（无 case）
        nullptr,  // 31 ZOMBIE_TALLNUT_HEAD（无 case）
        nullptr,  // 32 ZOMBIE_REDEYE_GARGANTUAR（无 case）
        kMowDownDropFlag,  // 33 ZOMBIE_ZOMBATAR（共体）
    };
    static_assert(sizeof(kMowDownCases) / sizeof(kMowDownCases[0]) ==
        (int)ZombieType::NUM_ZOMBIE_TYPES, "kMowDownCases 槽位须与 ZombieType 枚举同步");

    const unsigned aTypeIndex = static_cast<unsigned>(mZombieType);
    if (aTypeIndex < sizeof(kMowDownCases) / sizeof(kMowDownCases[0]) &&
        kMowDownCases[aTypeIndex] != nullptr)
    {
        kMowDownCases[aTypeIndex](*this);
    }

    Reanimation* aMoweredReanim = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder, ReanimationType::REANIM_LAWN_MOWERED_ZOMBIE);
    aMoweredReanim->mAnimRate = 8.0f;
    aMoweredReanim->mIsAttachment = false;
    aMoweredReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;
    mMoweredReanimID = mApp->ReanimationGetID(aMoweredReanim);
    mZombiePhase = ZombiePhase::PHASE_ZOMBIE_MOWERED;
    DropLoot();
}

static Zombie g_z;
static void ResetMowDown(const ZBInput& in)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    g_z.mZombieType = (ZombieType)(in.a % 34);
    // 相位取正常带相位（避开 DYING/MOWERED，偶取 IN_VAULT/RISING/GRAVE 等门支）
    g_z.mZombiePhase = (ZombiePhase)(in.b % 14 == 0 ? (int)ZombiePhase::PHASE_POLEVAULTER_IN_VAULT :
        in.b % 14 == 3 ? (int)ZombiePhase::PHASE_RISING_FROM_GRAVE : 0);
    g_z.mDead = (in.a % 23) == 0;
    g_z.mPosX = (float)(in.b % 780);
    g_z.mPosY = (float)(in.c % 600);
    g_z.mRenderOrder = (int)(in.d % 1000);
    g_z.mInPool = (in.c & 1) != 0;
    g_z.mIceTrapCounter = (int)(in.c % 4) - 1;
    g_z.mButteredCounter = (int)(in.d % 4) - 1;
    g_z.mHasObject = (in.d % 5) == 0;
    g_z.mRow = (int)(in.a % 6);
    g_z.mAltitude = 5.0f;
    g_z.mZombieHeight = ZombieHeight::HEIGHT_ZOMBIE_NORMAL;
}

int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetMowDown(g_zb_inputs[i]);
            g_z.MowDown_A();
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetMowDown(g_zb_inputs[i]);
            g_z.MowDown_B();
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t11_MowDown", passA, passB);
}
