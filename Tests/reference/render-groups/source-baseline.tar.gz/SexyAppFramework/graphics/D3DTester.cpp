#include "D3DTester.h"

using namespace Sexy;

void D3DTester::SetVidMemoryConstraints(DWORD theMin, DWORD theRecommended)
{
	(void)theMin;
	(void)theRecommended;
}

void D3DTester::TestD3D(HWND theHWND, void* theDDraw)
{
	(void)theHWND;
	(void)theDDraw;
	// 3D acceleration is mandatory and always on; no capability test runs.
	mFailureReason.clear();
	mWarning.clear();
	mResultsChanged = false;
}
