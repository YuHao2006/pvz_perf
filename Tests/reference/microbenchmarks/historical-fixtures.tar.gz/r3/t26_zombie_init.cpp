// t26_zombie_init.cpp — kZombieInitCases -> Zombie::ZombieInitialize（装载一次）
// FormA = 73d93be5^ 原 34 型 switch（逐字）；FormB = HEAD 匿名 lambda 表+固定尾部直呼（逐字）。
// 对照旧数：4.53→4.18 / 8.90→8.41（形态沿革 73d93be5→cb766530→711d022e）。
#include "r3_entities.h"

// ==================== FormB 表群（HEAD 86-864 逐字） ====================
namespace
{
// ZombieInitialize 槽位上下文：switch 外提局部（aRenderLayer/aRenderOffset）
// 与跨段参数（定义动画型、父僵尸、来波号）经此传递。表内匿名 lambda = 原
// case 体逐句迁移（生成器 + 逆变换 token 对拍 0 差异），1073 地址注释随体
// 保留。尾部公共逻辑具名化（ZombieInitializeTail），各槽位结尾直呼（尾部固定
// 无需回调传参）——return 原样即跳过直呼，BUNGEE 选靶自毙语义零改写。
struct ZombieInitLocals
{
    RenderLayer mRenderLayer;
    int mRenderOffset;
    ReanimationType mBodyReanimType;
    Zombie* mParentZombie;
    int mFromWave;
};
using ZombieInitCaseFn = void (*)(Zombie&, ZombieInitLocals&);

// 尾部公共逻辑（原 switch 后至函数尾逐句迁移）：各槽位结尾直呼——尾部固定，
// 无需回调传参；case 内 return 原样保留——不调即跳过尾部（=原 return 跳过
// 的同一段）；哨兵/越界由分发点 else 直调。置于共体函数与表之前（引用者
// 须后置）。
void ZombieInitializeTail(Zombie& z, ZombieInitLocals& lc)
{


        if (z.IsOnBoard() && z.mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_ZOMBIQUARIUM)
        {
            float aAnimRate = RandRangeFloat(8.0f, 10.0f);
            z.PlayZombieReanim(ReanimTrackId::anim_aquarium_swim, ReanimLoopType::REANIM_LOOP, 0, aAnimRate);

            z.mZombieHeight = ZombieHeight::HEIGHT_ZOMBIQUARIUM;
            z.mZombiePhase = ZombiePhase::PHASE_ZOMBIQUARIUM_DRIFT;
            z.mPhaseCounter = 200;
            z.mBodyHealth = 200;
            z.mSummonCounter = RandRangeInt(200, 400);
        }

        if (z.mApp->IsLittleTroubleLevel() && (z.IsOnBoard() || lc.mFromWave == Zombie::ZOMBIE_WAVE_CUTSCENE))
        {
            z.mScaleZombie = 0.5f;
            z.mBodyHealth /= 4;
            z.mHelmHealth /= 4;
            z.mShieldHealth /= 4;
            z.mFlyingHealth /= 4;
        }

        z.UpdateAnimSpeed();
        if (z.mVariant)
        {
            z.ReanimShowRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_NORMAL);
        }

        z.mHelmMaxHealth = z.mHelmHealth;
        z.mBodyMaxHealth = z.mBodyHealth;
        z.mShieldMaxHealth = z.mShieldHealth;
        z.mFlyingMaxHealth = z.mFlyingHealth;
        z.mDead = false;
        z.mX = (int)z.mPosX;
        z.mY = (int)z.mPosY;
        z.mRenderOrder = Board::MakeRenderOrder(lc.mRenderLayer, z.mRow, lc.mRenderOffset);
        if (z.mZombieHeight == ZombieHeight::HEIGHT_ZOMBIQUARIUM)
        {
            z.mBodyMaxHealth = 300;
        }

        if (z.IsOnBoard())
        {
            z.PlayZombieAppearSound();
            z.StartZombieSound();
        }

        z.UpdateReanim();

}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case ZOMBIE_NORMAL, ZOMBIE_DUCKY_TUBE
void ZombieInitNormal(Zombie& z, ZombieInitLocals& lc)
{
            z.LoadPlainZombieReanim();
            ZombieInitializeTail(z, lc);
}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case ZOMBIE_GARGANTUAR, ZOMBIE_REDEYE_GARGANTUAR
void ZombieInitGargantuar(Zombie& z, ZombieInitLocals& lc)
{
            z.mWidth = 180;
            z.mHeight = 180;
            z.mBodyHealth = 3000;
            z.mAnimFrames = 24;
            z.mAnimTicksPerFrame = 8;
            z.mPosX = WIDE_BOARD_WIDTH + 45 + Rand(10);
            z.mZombieRect = Rect(-17, -38, 125, 154);
            z.mZombieAttackRect = Rect(-30, -38, 89, 154);
            z.mVariant = false;
            lc.mRenderOffset = 8;
            z.mHasObject = true;

            int aPoleHit = Rand(100);
            int aPoleVariant;
            if (!z.IsOnBoard() || z.mBoard->mLevel == 48)
            {
                aPoleVariant = 0;
            }
            else
            {
                aPoleVariant = aPoleHit < 10 ? 2 : aPoleHit < 35 ? 1 : 0;
            }

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (aPoleVariant == 2)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_telephonepole, IMAGE_REANIM_ZOMBIE_GARGANTUAR_ZOMBIE);
            }
            else if (aPoleVariant == 1)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_telephonepole, IMAGE_REANIM_ZOMBIE_GARGANTUAR_DUCKXING);
            }

            if (z.mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
            {
                aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD_REDEYE);
                z.mBodyHealth = 6000;
            }
            ZombieInitializeTail(z, lc);
}

// 匿名 lambda 函数指针表，行序 = ZombieType 枚举值序（0..33）；
// 哨兵（CACHED/NUM/INVALID）在表外，由分发守卫拦下 = 原 default 无操作，
// 尾部仍由 else 分支直调。
constexpr ZombieInitCaseFn kZombieInitCases[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
    &ZombieInitNormal,  // 0 ZOMBIE_NORMAL（共体）
    // 原 case ZOMBIE_FLAG
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mHasObject = true;
            z.LoadPlainZombieReanim();

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            Reanimation* aFlagReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FLAG);
            aFlagReanim->PlayReanim(ReanimTrackId::Zombie_flag, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aFlagReanim);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_flaghand);
            AttachReanim(aTrackInstance->mAttachmentID, aFlagReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;

            z.mPosX = WIDE_BOARD_WIDTH;
            ZombieInitializeTail(z, lc);
    },  // 1 ZOMBIE_FLAG
    // 原 case ZOMBIE_TRAFFIC_CONE
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_cone, RENDER_GROUP_NORMAL);
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.mHelmType = HelmType::HELMTYPE_TRAFFIC_CONE;
            z.mHelmHealth = 370;
            ZombieInitializeTail(z, lc);
    },  // 2 ZOMBIE_TRAFFIC_CONE
    // 原 case ZOMBIE_POLEVAULTER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mAnimTicksPerFrame = 6;
            z.mZombiePhase = ZombiePhase::PHASE_POLEVAULTER_PRE_VAULT;
            z.mHasObject = true;
            z.mVariant = false;
            z.mPosX = WIDE_BOARD_WIDTH + 70 + Rand(10);
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_run, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
                z.PickRandomSpeed();
            }
            if (z.mApp->IsWallnutBowlingLevel())
            {
                z.mZombieAttackRect = Rect(-229, 0, 270, 115);
            }
            else
            {
                z.mZombieAttackRect = Rect(-29, 0, 70, 115);
            }
            ZombieInitializeTail(z, lc);
    },  // 3 ZOMBIE_POLEVAULTER
    // 原 case ZOMBIE_PAIL
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_bucket, RENDER_GROUP_NORMAL);
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.mHelmType = HelmType::HELMTYPE_PAIL;
            z.mHelmHealth = 1100;
            ZombieInitializeTail(z, lc);
    },  // 4 ZOMBIE_PAIL
    // 原 case ZOMBIE_NEWSPAPER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mZombieAttackRect = Rect(20, 0, 50, 115);
            z.mZombiePhase = ZombiePhase::PHASE_NEWSPAPER_READING;
            z.mShieldType = ShieldType::SHIELDTYPE_NEWSPAPER;
            z.mShieldHealth = 150;
            z.mVariant = false;
            z.AttachShield();
            ZombieInitializeTail(z, lc);
    },  // 5 ZOMBIE_NEWSPAPER
    // 原 case ZOMBIE_DOOR
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mShieldType = ShieldType::SHIELDTYPE_DOOR;
            z.mShieldHealth = 1100;
            z.LoadPlainZombieReanim();
            z.AttachShield();
            ZombieInitializeTail(z, lc);
    },  // 6 ZOMBIE_DOOR
    // 原 case ZOMBIE_FOOTBALL
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mZombieRect = Rect(50, 0, 57, 115);
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.mHelmType = HelmType::HELMTYPE_FOOTBALL;
            z.mHelmHealth = 1400;
            z.mAnimTicksPerFrame = 6;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 7 ZOMBIE_FOOTBALL
    // 原 case ZOMBIE_DANCER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            // @Patoke: add scaling for new assets
            z.mScaleZombie = 0.8f;
            if (!z.IsOnBoard())
            {
                // @Patoke: oops
                z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            else
            {
                z.mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_IN;
                z.mVelX = 0.5f;
                z.mPhaseCounter = 300 + Rand(12);
                z.PlayZombieReanim(ReanimTrackId::anim_moonwalk, ReanimLoopType::REANIM_LOOP, 0, 24.0f);
            }
            z.mBodyHealth = 500;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 8 ZOMBIE_DANCER
    // 原 case ZOMBIE_BACKUP_DANCER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            // @Patoke: add scaling for new assets
            z.mScaleZombie = 0.8f;
            if (!z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            z.mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_LEFT;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 9 ZOMBIE_BACKUP_DANCER
    &ZombieInitNormal,  // 10 ZOMBIE_DUCKY_TUBE（共体）
    // 原 case ZOMBIE_SNORKEL
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mZombieRect = Rect(12, 0, 62, 115);
            z.mZombieAttackRect = Rect(-5, 0, 55, 115);
            z.SetupWaterTrack(ReanimTrackId::Zombie_snorkle_whitewater);
            z.SetupWaterTrack(ReanimTrackId::Zombie_snorkle_whitewater2);
            z.mVariant = false;
            z.mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
            ZombieInitializeTail(z, lc);
    },  // 11 ZOMBIE_SNORKEL
    // 原 case ZOMBIE_ZAMBONI
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 1350;
            z.mAnimFrames = 2;
            z.mAnimTicksPerFrame = 8;
            z.mPosX = WIDE_BOARD_WIDTH + Rand(10);
            lc.mRenderOffset = 8;
            z.PlayZombieReanim(ReanimTrackId::anim_drive, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            z.mZombieRect = Rect(0, -13, 153, 140);
            z.mZombieAttackRect = Rect(10, -13, 133, 140);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 12 ZOMBIE_ZAMBONI
    // 原 case ZOMBIE_BOBSLED
    [](Zombie& z, ZombieInitLocals& lc)
    {
            lc.mRenderOffset = 3;

            if (lc.mParentZombie)
            {
                int aPosition = 0;
                while (aPosition < NUM_BOBSLED_FOLLOWERS && lc.mParentZombie->mFollowerZombieID[aPosition] != ZombieID::ZOMBIEID_NULL)
                {
                    aPosition++;
                }
                TOD_ASSERT(aPosition < 3);
                lc.mParentZombie->mFollowerZombieID[aPosition] = z.mBoard->ZombieGetID(&z);
                z.mRelatedZombieID = z.mBoard->ZombieGetID(lc.mParentZombie);

                z.mPosX = lc.mParentZombie->mPosX + (aPosition + 1) * 50;
                if (aPosition == 0)
                {
                    lc.mRenderOffset = 1;
                    z.mAltitude = 9.0f;
                }
                else if (aPosition == 1)
                {
                    lc.mRenderOffset = 2;
                    z.mAltitude = -7.0f;
                }
                else
                {
                    lc.mRenderOffset = 0;
                    z.mAltitude = 9.0f;
                }
            }
            else
            {
                z.mPosX = WIDE_BOARD_WIDTH + 80;
                z.mZombieRect = Rect(-50, 0, 275, 115);
                z.mHelmType = HelmType::HELMTYPE_BOBSLED;
                z.mHelmHealth = 300;
                z.mAltitude = -10.0f;
            }

            z.mVelX = 0.6f;
            z.mZombiePhase = ZombiePhase::PHASE_BOBSLED_SLIDING;
            z.mPhaseCounter = 500;
            z.mVariant = false;

            if (z.mFromWave == Zombie::ZOMBIE_WAVE_CUTSCENE)
            {
                z.PlayZombieReanim(ReanimTrackId::anim_jump, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 20.0f);
                z.mApp->ReanimationGet(z.mBodyReanimID)->mAnimTime = 1.0f;
                z.mAltitude = 18.0f;
            }
            else if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_push, ReanimLoopType::REANIM_LOOP, 0, 30.0f);
            }
            ZombieInitializeTail(z, lc);
    },  // 13 ZOMBIE_BOBSLED
    // 原 case ZOMBIE_DOLPHIN_RIDER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mAnimTicksPerFrame = 6;
            z.mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING;
            z.mVariant = false;
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_walkdolphin, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
                z.PickRandomSpeed();
            }
            z.SetupWaterTrack(ReanimTrackId::Zombie_dolphinrider_whitewater);
            z.SetupWaterTrack(ReanimTrackId::Zombie_dolphinrider_dolphininwater);
            ZombieInitializeTail(z, lc);
    },  // 14 ZOMBIE_DOLPHIN_RIDER
    // 原 case ZOMBIE_JACK_IN_THE_BOX
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mAnimTicksPerFrame = 6;

            int aDistance = 450 + Rand(300);
            if (Rand(20) == 0)  // 早爆的概率
            {
                aDistance /= 3;
            }
            z.mPhaseCounter = (int)(aDistance / z.mVelX) * ZOMBIE_LIMP_SPEED_FACTOR;
            z.mZombieAttackRect = Rect(20, 0, 50, 115);

            if (z.mApp->IsScaryPotterLevel())
            {
                z.mPhaseCounter = 10;
            }
            if (z.IsOnBoard())
            {
                z.mZombiePhase = ZombiePhase::PHASE_JACK_IN_THE_BOX_RUNNING;
            }
            ZombieInitializeTail(z, lc);
    },  // 15 ZOMBIE_JACK_IN_THE_BOX
    // 原 case ZOMBIE_BALLOON
    [](Zombie& z, ZombieInitLocals& lc)
    {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            aBodyReanim->SetTruncateDisappearingFramesAll( false);

            if (z.IsOnBoard())
            {
                z.mAltitude = 25.0f;
                z.mZombiePhase = ZombiePhase::PHASE_BALLOON_FLYING;
                z.PlayZombieReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, aBodyReanim->mAnimRate);
            }
            else
            {
                float aAnimRate = RandRangeFloat(8.0f, 10.0f);
                z.SetAnimRate(aAnimRate);
            }

            Reanimation* aPropellerReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, lc.mBodyReanimType);
            aPropellerReanim->SetFramesForLayer(ReanimTrackId::propeller);
            aPropellerReanim->mLoopType = ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME;
            aPropellerReanim->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::hat);

            z.mFlyingHealth = 20;
            z.mZombieRect = Rect(36, 30, 42, 115);
            z.mZombieAttackRect = Rect(20, 30, 50, 115);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 16 ZOMBIE_BALLOON
    // 原 case ZOMBIE_DIGGER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mHelmType = HelmType::HELMTYPE_DIGGER;
            z.mHelmHealth = 100;
            z.mVariant = false;
            z.mHasObject = true;
            z.mZombieRect = Rect(50, 0, 28, 115);
        
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            aBodyReanim->SetTruncateDisappearingFramesAll( false);
        
            if (!z.IsOnBoard())
            {
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_CUTSCENE;
            }
            else
            {
                z.mZombiePhase = ZombiePhase::PHASE_DIGGER_TUNNELING;
                z.AddAttachedParticle(60, 100, ParticleEffect::PARTICLE_DIGGER_TUNNEL);
                lc.mRenderOffset = 7;
                z.PlayZombieReanim(ReanimTrackId::anim_dig, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
                z.PickRandomSpeed();
            }
            ZombieInitializeTail(z, lc);
    },  // 17 ZOMBIE_DIGGER
    // 原 case ZOMBIE_POGO
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mVariant = false;
            z.mZombiePhase = ZombiePhase::PHASE_POGO_BOUNCING;
            z.mPhaseCounter = Rand(POGO_BOUNCE_TIME) + 1;
            z.mHasObject = true;
            z.mBodyHealth = 500;
            z.mZombieAttackRect = Rect(10, 0, 30, 115);
            z.PlayZombieReanim(ReanimTrackId::anim_pogo, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 40.0f);
            z.mApp->ReanimationGet(z.mBodyReanimID)->mAnimTime = 1.0f;
            ZombieInitializeTail(z, lc);
    },  // 18 ZOMBIE_POGO
    // 原 case ZOMBIE_YETI
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 1350;
            z.mPhaseCounter = RandRangeInt(1500, 2000);
            z.mHasObject = true;
            z.mZombieAttackRect = Rect(20, 0, 50, 115);
            ZombieInitializeTail(z, lc);
    },  // 19 ZOMBIE_YETI
    // 原 case ZOMBIE_BUNGEE
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 450;
            z.mAnimFrames = 4;
            z.mAltitude = BUNGEE_ZOMBIE_HEIGHT + RandRangeInt(0, 150);
            z.mVelX = 0.0f;

            if (z.IsOnBoard())
            {
                z.PickBungeeZombieTarget(-1);
            
                if (z.mDead)
                {
                    return;
                }

                z.mZombiePhase = ZombiePhase::PHASE_BUNGEE_DIVING;
            }
            else
            {
                z.mZombiePhase = ZombiePhase::PHASE_BUNGEE_CUTSCENE;
                z.mPhaseCounter = RandRangeInt(0, 200);
            }

            z.PlayZombieReanim(ReanimTrackId::anim_drop, ReanimLoopType::REANIM_LOOP, 0, 24.0f);
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_rightarm_lower2, RENDER_GROUP_ARMS);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_rightarm_hand2, RENDER_GROUP_ARMS);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_leftarm_lower2, RENDER_GROUP_ARMS);
            aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_leftarm_hand2, RENDER_GROUP_ARMS);
            aBodyReanim->SetTruncateDisappearingFramesAll( false);

            lc.mRenderLayer = RenderLayer::RENDER_LAYER_GRAVE_STONE;
            lc.mRenderOffset = 7;
            z.mZombieRect = Rect(-20, 22, 110, 94);
            z.mZombieAttackRect = Rect(0, 0, 0, 0);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 20 ZOMBIE_BUNGEE
    // 原 case ZOMBIE_LADDER
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 500;
            z.mShieldHealth = 500;
            z.mShieldType = ShieldType::SHIELDTYPE_LADDER;
            z.mZombieAttackRect = Rect(10, 0, 50, 115);
            if (z.IsOnBoard())
            {
                z.mZombiePhase = ZombiePhase::PHASE_LADDER_CARRYING;
                z.StartWalkAnim(0);
            }
            z.AttachShield();
            ZombieInitializeTail(z, lc);
    },  // 21 ZOMBIE_LADDER
    // 原 case ZOMBIE_CATAPULT
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mBodyHealth = 850;
            z.mPosX = WIDE_BOARD_WIDTH + 25 + Rand(10);
            z.mSummonCounter = 20;
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 5.5f);
            }
            else
            {
                z.PlayZombieReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 8.0f);
            }
            z.mZombieRect = Rect(0, -13, 153, 140);
            z.mZombieAttackRect = Rect(10, -13, 133, 140);
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 22 ZOMBIE_CATAPULT
    &ZombieInitGargantuar,  // 23 ZOMBIE_GARGANTUAR（共体）
    // 原 case ZOMBIE_IMP
    [](Zombie& z, ZombieInitLocals& lc)
    {
            if (!z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            if (z.mApp->IsIZombieLevel())
            {
                z.mBodyHealth = 70;
            }
            ZombieInitializeTail(z, lc);
    },  // 24 ZOMBIE_IMP
    // 原 case ZOMBIE_BOSS
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mPosX = 0.0f;
            z.mPosY = 0.0f;
            z.mZombieRect = Rect(700, 80, 90, 430);
            z.mZombieAttackRect = Rect(0, 0, 0, 0);
            lc.mRenderLayer = RenderLayer::RENDER_LAYER_TOP;
            z.mBodyHealth = z.mApp->IsAdventureMode() ? 40000 : 60000;
            if (z.IsOnBoard())
            {
                z.PlayZombieReanim(ReanimTrackId::anim_enter, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
                z.mSummonCounter = 500;
                z.mBossHeadCounter = 5000;
                z.mZombiePhase = ZombiePhase::PHASE_BOSS_ENTER;
            }
            else
            {
                z.PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
            }
            z.BossSetupReanim();
            ZombieInitializeTail(z, lc);
    },  // 25 ZOMBIE_BOSS
    // 原 case ZOMBIE_PEA_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aTrackInstance->mImageOverride = IMAGE_BLANK;
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_PEASHOOTER);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 65.0f, -5.0f, 0.2f, -1.0f, 1.0f);

            z.mPhaseCounter = 150;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 26 ZOMBIE_PEA_HEAD
    // 原 case ZOMBIE_WALLNUT_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_WALLNUT);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 50.0f, 0.0f, 0.2f, -0.8f, 0.8f);

            z.mHelmType = HelmType::HELMTYPE_WALLNUT;
            z.mHelmHealth = 1100;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 27 ZOMBIE_WALLNUT_HEAD
    // 原 case ZOMBIE_JALAPENO_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_JALAPENO);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 55.0f, -5.0f, 0.2f, -1.0f, 1.0f);

            z.mVariant = false;
            z.mBodyHealth = 500;
            int aDistance = 275 + Rand(175);
            z.mPhaseCounter = (int)(aDistance / z.mVelX) * ZOMBIE_LIMP_SPEED_FACTOR;
            ZombieInitializeTail(z, lc);
    },  // 28 ZOMBIE_JALAPENO_HEAD
    // 原 case ZOMBIE_GATLING_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aTrackInstance->mImageOverride = IMAGE_BLANK;
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_GATLINGPEA);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 65.0f, -5.0f, 0.2f, -1.0f, 1.0f);

            z.mPhaseCounter = 150;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 29 ZOMBIE_GATLING_HEAD
    // 原 case ZOMBIE_SQUASH_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aTrackInstance->mImageOverride = IMAGE_BLANK;
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SQUASH);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 55.0f, -15.0f, 0.2f, -0.75f, 0.75f);

            z.mZombiePhase = ZombiePhase::PHASE_SQUASH_PRE_LAUNCH;
            z.mVariant = false;
            ZombieInitializeTail(z, lc);
    },  // 30 ZOMBIE_SQUASH_HEAD
    // 原 case ZOMBIE_TALLNUT_HEAD
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.LoadPlainZombieReanim();
            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_TALLNUT);
            aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;
            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 37.0f, 0.0f, 0.2f, -0.8f, 0.8f);

            z.mHelmType = HelmType::HELMTYPE_TALLNUT;
            z.mHelmHealth = 2200;
            z.mVariant = false;
            z.mPosX += 30.0f;
            ZombieInitializeTail(z, lc);
    },  // 31 ZOMBIE_TALLNUT_HEAD
    &ZombieInitGargantuar,  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
    // 原 case ZOMBIE_ZOMBATAR
    [](Zombie& z, ZombieInitLocals& lc)
    {
            z.mHasObject = true;
            z.LoadPlainZombieReanim();

            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            Reanimation* aFlagReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FLAG);
            aFlagReanim->PlayReanim(ReanimTrackId::Zombie_flag, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            z.mSpecialHeadReanimID = z.mApp->ReanimationGetID(aFlagReanim);
            ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_flaghand);
            AttachReanim(aTrackInstance->mAttachmentID, aFlagReanim, 0.0f, 0.0f);
            aBodyReanim->mFrameBasePose = 0;

            z.mPosX = WIDE_BOARD_WIDTH;

            z.ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
            z.ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

            if (z.IsOnBoard())
            {
                aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
            }

            ReanimatorTrackInstance* aHeadTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
            aHeadTrackInstance->mImageOverride = IMAGE_BLANK;

            Reanimation* aHeadReanim = z.mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_ZOMBATAR_HEAD);
            // zombatar_zombie_head 无 anim_head_idle 轨道：原版此查询必 miss，
            // 靠"查不到回退轨道 0"落到 anim_head1（该定义轨道 0）。回退语义已删
            // 除，这里显式点名等效轨道，行为不变。
            aHeadReanim->PlayReanim(ReanimTrackId::anim_head1, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
            aHeadReanim->AssignRenderGroupToTrack(ReanimTrackId::anim_hair, RENDER_GROUP_HIDDEN);

            z.mZombatarHeadReanimID = z.mApp->ReanimationGetID(aHeadReanim);
            AttachEffect* aAttachEffect = AttachReanim(aHeadTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
    		aBodyReanim->mFrameBasePose = 0; // @Patoke: should &z be aBodyReanim? &z could be a bug in the original code

            TodScaleRotateTransformMatrix(aAttachEffect->mOffset, M(-20.0f), M(-1.0f), M(0.2f), 1.0f, 1.0f);

            z.ResetZombatarHead(z.mApp);

            z.mPhaseCounter = 150;
            z.mVariant = false;

            if (z.mHasZombatar)
            {
    			z.ApplyZombatarHead(z.mApp, &z.mApp->mPlayerInfo->mZombatars[z.mZombatarIndex]);
            }
            ZombieInitializeTail(z, lc);
    },  // 33 ZOMBIE_ZOMBATAR
};
static_assert(sizeof(kZombieInitCases) / sizeof(kZombieInitCases[0]) ==
    (int)ZombieType::NUM_ZOMBIE_TYPES, "ZombieInitialize 分发表槽位数须与 ZombieType 枚举同步");
static_assert(kZombieInitCases[(int)ZombieType::ZOMBIE_NORMAL] == &ZombieInitNormal &&
    kZombieInitCases[(int)ZombieType::ZOMBIE_DUCKY_TUBE] == &ZombieInitNormal &&
    kZombieInitCases[(int)ZombieType::ZOMBIE_GARGANTUAR] == &ZombieInitGargantuar &&
    kZombieInitCases[(int)ZombieType::ZOMBIE_REDEYE_GARGANTUAR] == &ZombieInitGargantuar,
    "共体槽位锚点错位（匿名槽由生成器 token 对拍覆盖）");
}  // namespace

// ==================== FormA：73d93be5^ 原 switch（逐字；仅签名加 _A 与 noinline） ====================
__declspec(noinline) void Zombie::ZombieInitialize_A(int theRow, ZombieType theType, bool theVariant, Zombie* theParentZombie, int theFromWave)
{
    TOD_ASSERT(theType >= 0 && theType <= ZombieType::NUM_ZOMBIE_TYPES);

    mHasZombatar = false;
    // GOTY 1073 rewrites a flag zombie to the dedicated Zombatar type before
    // the rest of initialization, then selects one saved avatar at random.
    if (theType == ZombieType::ZOMBIE_FLAG && mApp->mPlayerInfo &&
        mApp->mPlayerInfo->mNumZombatars > 0)
    {
        theType = ZombieType::ZOMBIE_ZOMBATAR;
        mHasZombatar = true;
        mZombatarIndex = Rand(mApp->mPlayerInfo->mNumZombatars);
        if (mZombatarIndex >= mApp->mPlayerInfo->mNumZombatars)
            mZombatarIndex = mApp->mPlayerInfo->mNumZombatars - 1;
    }

    mRow = theRow;
    mFromWave = theFromWave;
    mPosX = 780 + Rand(ZOMBIE_START_RANDOM_OFFSET);
    mPosY = GetPosYBasedOnRow(theRow);
    mVelX = 0.0f;
    mVelZ = 0.0f;
    mWidth = 120;
    mHeight = 120;
    mFrame = 0;
    mPrevFrame = 0;
    mZombieType = theType;
    mVariant = theVariant;
    mIsEating = false;
    mJustGotShotCounter = 0;
    mShieldJustGotShotCounter = 0;
    mShieldRecoilCounter = 0;
    mChilledCounter = 0;
    mIceTrapCounter = 0;
    mButteredCounter = 0;
    mMindControlled = false;
    mBlowingAway = false;
    mHasHead = true;
    mHasArm = true;
    mHasObject = false;
    mInPool = false;
    mOnHighGround = false;
    mHelmType = HelmType::HELMTYPE_NONE;
    mShieldType = ShieldType::SHIELDTYPE_NONE;
    mYuckyFace = false;
    mYuckyFaceCounter = 0;
    mAnimCounter = 0;
    mGroanCounter = RandRangeInt(300, 400);
    mAnimTicksPerFrame = 12;
    mAnimFrames = 12;
    mZombieAge = 0;
    mTargetCol = -1;
    mZombiePhase = ZombiePhase::PHASE_ZOMBIE_NORMAL;
    mZombieHeight = ZombieHeight::HEIGHT_ZOMBIE_NORMAL;
    mPhaseCounter = 0;
    mHitUmbrella = false;
    mDroppedLoot = false;
    mRelatedZombieID = ZombieID::ZOMBIEID_NULL;
    mZombieRect = Rect(36, 0, 42, 115);
    mZombieAttackRect = Rect(50, 0, 20, 115);
    mPlayingSong = false;
    mZombieFade = -1;
    mFlatTires = false;
    mScaleZombie = 1.0f;
    mUseLadderCol = -1;
    mShieldHealth = 0;
    mHelmHealth = 0;
    mAltitude = 0.0f;
    mFlyingHealth = 0;
    mOriginalAnimRate = 0.0f;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mSummonCounter = 0;
    mBossStompCounter = -1;
    mBossBungeeCounter = -1;
    mBossHeadCounter = -1;
    mBodyReanimID = ReanimationID::REANIMATIONID_NULL;
    mTargetPlantID = PlantID::PLANTID_NULL;
    mBossMode = 0;
    mBossFireBallReanimID = ReanimationID::REANIMATIONID_NULL;
    mSpecialHeadReanimID = ReanimationID::REANIMATIONID_NULL;
    mTargetRow = -1;
    mFireballRow = -1;
    mIsFireBall = false;
    mMoweredReanimID = ReanimationID::REANIMATIONID_NULL;
    mLastPortalX = -1;
    for (int i = 0; i < MAX_ZOMBIE_FOLLOWERS; i++)
    {
        mFollowerZombieID[i] = ZombieID::ZOMBIEID_NULL;
    }
    if (mBoard && mBoard->IsFlagWave(mFromWave))
    {
        mPosX += 40.0f;
    }
    PickRandomSpeed();
    mBodyHealth = 270;

    const ZombieDefinition& aZombieDef = GetZombieDefinition(mZombieType);
    RenderLayer aRenderLayer = RenderLayer::RENDER_LAYER_ZOMBIE;
    int aRenderOffset = 4;
    if (aZombieDef.mReanimationType != ReanimationType::REANIM_NONE)
    {
        LoadReanim(aZombieDef.mReanimationType);
    }

    switch (theType)
    {
    case ZombieType::ZOMBIE_NORMAL:  //0x5227E9
    case ZombieType::ZOMBIE_DUCKY_TUBE:  //0x5227F8
        LoadPlainZombieReanim();
        break;

    case ZombieType::ZOMBIE_TRAFFIC_CONE:  //0x52280B
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_cone, RENDER_GROUP_NORMAL);
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        mHelmType = HelmType::HELMTYPE_TRAFFIC_CONE;
        mHelmHealth = 370;
        break;

    case ZombieType::ZOMBIE_PAIL:  //0x5228A4
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_bucket, RENDER_GROUP_NORMAL);
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        mHelmType = HelmType::HELMTYPE_PAIL;
        mHelmHealth = 1100;
        break;

    case ZombieType::ZOMBIE_DOOR:  //0x522939
        mShieldType = ShieldType::SHIELDTYPE_DOOR;
        mShieldHealth = 1100;
        LoadPlainZombieReanim();
        AttachShield();
        break;

    case ZombieType::ZOMBIE_YETI:  //0x522963
        mBodyHealth = 1350;
        mPhaseCounter = RandRangeInt(1500, 2000);
        mHasObject = true;
        mZombieAttackRect = Rect(20, 0, 50, 115);
        break;

    case ZombieType::ZOMBIE_LADDER:  //0x52299B
        mBodyHealth = 500;
        mShieldHealth = 500;
        mShieldType = ShieldType::SHIELDTYPE_LADDER;
        mZombieAttackRect = Rect(10, 0, 50, 115);
        if (IsOnBoard())
        {
            mZombiePhase = ZombiePhase::PHASE_LADDER_CARRYING;
            StartWalkAnim(0);
        }
        AttachShield();
        break;

    case ZombieType::ZOMBIE_BUNGEE:  //0x522A10
    {
        mBodyHealth = 450;
        mAnimFrames = 4;
        mAltitude = BUNGEE_ZOMBIE_HEIGHT + RandRangeInt(0, 150);
        mVelX = 0.0f;

        if (IsOnBoard())
        {
            PickBungeeZombieTarget(-1);
            
            if (mDead)
            {
                return;
            }

            mZombiePhase = ZombiePhase::PHASE_BUNGEE_DIVING;
        }
        else
        {
            mZombiePhase = ZombiePhase::PHASE_BUNGEE_CUTSCENE;
            mPhaseCounter = RandRangeInt(0, 200);
        }

        PlayZombieReanim(ReanimTrackId::anim_drop, ReanimLoopType::REANIM_LOOP, 0, 24.0f);
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_rightarm_lower2, RENDER_GROUP_ARMS);
        aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_rightarm_hand2, RENDER_GROUP_ARMS);
        aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_leftarm_lower2, RENDER_GROUP_ARMS);
        aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Zombie_bungi_leftarm_hand2, RENDER_GROUP_ARMS);
        aBodyReanim->SetTruncateDisappearingFramesAll( false);

        aRenderLayer = RenderLayer::RENDER_LAYER_GRAVE_STONE;
        aRenderOffset = 7;
        mZombieRect = Rect(-20, 22, 110, 94);
        mZombieAttackRect = Rect(0, 0, 0, 0);
        mVariant = false;
        break;
    }
    
    case ZombieType::ZOMBIE_FOOTBALL:  //0x522B6E
        mZombieRect = Rect(50, 0, 57, 115);
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        mHelmType = HelmType::HELMTYPE_FOOTBALL;
        mHelmHealth = 1400;
        mAnimTicksPerFrame = 6;
        mVariant = false;
        break;

    case ZombieType::ZOMBIE_DIGGER:  //0x522BCC
    {
        mHelmType = HelmType::HELMTYPE_DIGGER;
        mHelmHealth = 100;
        mVariant = false;
        mHasObject = true;
        mZombieRect = Rect(50, 0, 28, 115);
        
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        aBodyReanim->SetTruncateDisappearingFramesAll( false);
        
        if (!IsOnBoard())
        {
            mZombiePhase = ZombiePhase::PHASE_DIGGER_CUTSCENE;
        }
        else
        {
            mZombiePhase = ZombiePhase::PHASE_DIGGER_TUNNELING;
            AddAttachedParticle(60, 100, ParticleEffect::PARTICLE_DIGGER_TUNNEL);
            aRenderOffset = 7;
            PlayZombieReanim(ReanimTrackId::anim_dig, ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME, 0, 12.0f);
            PickRandomSpeed();
        }

        break;
    }

    case ZombieType::ZOMBIE_POLEVAULTER:  //0x522CB4
        mBodyHealth = 500;
        mAnimTicksPerFrame = 6;
        mZombiePhase = ZombiePhase::PHASE_POLEVAULTER_PRE_VAULT;
        mHasObject = true;
        mVariant = false;
        mPosX = WIDE_BOARD_WIDTH + 70 + Rand(10);
        if (IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_run, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
            PickRandomSpeed();
        }
        if (mApp->IsWallnutBowlingLevel())
        {
            mZombieAttackRect = Rect(-229, 0, 270, 115);
        }
        else
        {
            mZombieAttackRect = Rect(-29, 0, 70, 115);
        }
        break;

    case ZombieType::ZOMBIE_DOLPHIN_RIDER:  //0x522D5C
        mBodyHealth = 500;
        mAnimTicksPerFrame = 6;
        mZombiePhase = ZombiePhase::PHASE_DOLPHIN_WALKING;
        mVariant = false;
        if (IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_walkdolphin, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
            PickRandomSpeed();
        }
        SetupWaterTrack(ReanimTrackId::Zombie_dolphinrider_whitewater);
        SetupWaterTrack(ReanimTrackId::Zombie_dolphinrider_dolphininwater);
        break;

    case ZombieType::ZOMBIE_GARGANTUAR:
    case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:  //0x523D10
    {
        mWidth = 180;
        mHeight = 180;
        mBodyHealth = 3000;
        mAnimFrames = 24;
        mAnimTicksPerFrame = 8;
        mPosX = WIDE_BOARD_WIDTH + 45 + Rand(10);
        mZombieRect = Rect(-17, -38, 125, 154);
        mZombieAttackRect = Rect(-30, -38, 89, 154);
        mVariant = false;
        aRenderOffset = 8;
        mHasObject = true;

        int aPoleHit = Rand(100);
        int aPoleVariant;
        if (!IsOnBoard() || mBoard->mLevel == 48)
        {
            aPoleVariant = 0;
        }
        else
        {
            aPoleVariant = aPoleHit < 10 ? 2 : aPoleHit < 35 ? 1 : 0;
        }

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aPoleVariant == 2)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_telephonepole, IMAGE_REANIM_ZOMBIE_GARGANTUAR_ZOMBIE);
        }
        else if (aPoleVariant == 1)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::Zombie_gargantuar_telephonepole, IMAGE_REANIM_ZOMBIE_GARGANTUAR_DUCKXING);
        }

        if (mZombieType == ZombieType::ZOMBIE_REDEYE_GARGANTUAR)
        {
            aBodyReanim->SetImageOverride(ReanimTrackId::anim_head1, IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD_REDEYE);
            mBodyHealth = 6000;
        }

        break;
    }

    case ZombieType::ZOMBIE_ZAMBONI:  //0x522DD3
        mBodyHealth = 1350;
        mAnimFrames = 2;
        mAnimTicksPerFrame = 8;
        mPosX = WIDE_BOARD_WIDTH + Rand(10);
        aRenderOffset = 8;
        PlayZombieReanim(ReanimTrackId::anim_drive, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
        mZombieRect = Rect(0, -13, 153, 140);
        mZombieAttackRect = Rect(10, -13, 133, 140);
        mVariant = false;
        break;

    case ZombieType::ZOMBIE_CATAPULT:  //0x522E82
        mBodyHealth = 850;
        mPosX = WIDE_BOARD_WIDTH + 25 + Rand(10);
        mSummonCounter = 20;
        if (IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 5.5f);
        }
        else
        {
            PlayZombieReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 8.0f);
        }
        mZombieRect = Rect(0, -13, 153, 140);
        mZombieAttackRect = Rect(10, -13, 133, 140);
        mVariant = false;
        break;

    case ZombieType::ZOMBIE_SNORKEL:  //0x522F43
        mZombieRect = Rect(12, 0, 62, 115);
        mZombieAttackRect = Rect(-5, 0, 55, 115);
        SetupWaterTrack(ReanimTrackId::Zombie_snorkle_whitewater);
        SetupWaterTrack(ReanimTrackId::Zombie_snorkle_whitewater2);
        mVariant = false;
        mZombiePhase = ZombiePhase::PHASE_SNORKEL_WALKING;
        break;

    case ZombieType::ZOMBIE_JACK_IN_THE_BOX:  //0x522FBC
    {
        mBodyHealth = 500;
        mAnimTicksPerFrame = 6;

        int aDistance = 450 + Rand(300);
        if (Rand(20) == 0)  // 早爆的概率
        {
            aDistance /= 3;
        }
        mPhaseCounter = (int)(aDistance / mVelX) * ZOMBIE_LIMP_SPEED_FACTOR;
        mZombieAttackRect = Rect(20, 0, 50, 115);

        if (mApp->IsScaryPotterLevel())
        {
            mPhaseCounter = 10;
        }
        if (IsOnBoard())
        {
            mZombiePhase = ZombiePhase::PHASE_JACK_IN_THE_BOX_RUNNING;
        }

        break;
    }

    case ZombieType::ZOMBIE_BOBSLED:  //0x523071
    {
        aRenderOffset = 3;

        if (theParentZombie)
        {
            int aPosition = 0;
            while (aPosition < NUM_BOBSLED_FOLLOWERS && theParentZombie->mFollowerZombieID[aPosition] != ZombieID::ZOMBIEID_NULL)
            {
                aPosition++;
            }
            TOD_ASSERT(aPosition < 3);
            theParentZombie->mFollowerZombieID[aPosition] = mBoard->ZombieGetID(this);
            mRelatedZombieID = mBoard->ZombieGetID(theParentZombie);

            mPosX = theParentZombie->mPosX + (aPosition + 1) * 50;
            if (aPosition == 0)
            {
                aRenderOffset = 1;
                mAltitude = 9.0f;
            }
            else if (aPosition == 1)
            {
                aRenderOffset = 2;
                mAltitude = -7.0f;
            }
            else
            {
                aRenderOffset = 0;
                mAltitude = 9.0f;
            }
        }
        else
        {
            mPosX = WIDE_BOARD_WIDTH + 80;
            mZombieRect = Rect(-50, 0, 275, 115);
            mHelmType = HelmType::HELMTYPE_BOBSLED;
            mHelmHealth = 300;
            mAltitude = -10.0f;
        }

        mVelX = 0.6f;
        mZombiePhase = ZombiePhase::PHASE_BOBSLED_SLIDING;
        mPhaseCounter = 500;
        mVariant = false;

        if (mFromWave == Zombie::ZOMBIE_WAVE_CUTSCENE)
        {
            PlayZombieReanim(ReanimTrackId::anim_jump, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 20.0f);
            mApp->ReanimationGet(mBodyReanimID)->mAnimTime = 1.0f;
            mAltitude = 18.0f;
        }
        else if (IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_push, ReanimLoopType::REANIM_LOOP, 0, 30.0f);
        }

        break;
    }

    case ZombieType::ZOMBIE_FLAG:  //0x5231E8
    {
        mHasObject = true;
        LoadPlainZombieReanim();

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        Reanimation* aFlagReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FLAG);
        aFlagReanim->PlayReanim(ReanimTrackId::Zombie_flag, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aFlagReanim);
        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_flaghand);
        AttachReanim(aTrackInstance->mAttachmentID, aFlagReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;

        mPosX = WIDE_BOARD_WIDTH;
        break;
    }

    case ZombieType::ZOMBIE_ZOMBATAR:
    {
        mHasObject = true;
        LoadPlainZombieReanim();

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        Reanimation* aFlagReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_FLAG);
        aFlagReanim->PlayReanim(ReanimTrackId::Zombie_flag, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aFlagReanim);
        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_flaghand);
        AttachReanim(aTrackInstance->mAttachmentID, aFlagReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;

        mPosX = WIDE_BOARD_WIDTH;

        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

        if (IsOnBoard())
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
        }

        ReanimatorTrackInstance* aHeadTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
        aHeadTrackInstance->mImageOverride = IMAGE_BLANK;

        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_ZOMBATAR_HEAD);
        // zombatar_zombie_head 无 anim_head_idle 轨道：原版此查询必 miss，
        // 靠"查不到回退轨道 0"落到 anim_head1（该定义轨道 0）。回退语义已删
        // 除，这里显式点名等效轨道，行为不变。
        aHeadReanim->PlayReanim(ReanimTrackId::anim_head1, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        aHeadReanim->AssignRenderGroupToTrack(ReanimTrackId::anim_hair, RENDER_GROUP_HIDDEN);

        mZombatarHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aHeadTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
		aBodyReanim->mFrameBasePose = 0; // @Patoke: should this be aBodyReanim? this could be a bug in the original code

        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, M(-20.0f), M(-1.0f), M(0.2f), 1.0f, 1.0f);

        ResetZombatarHead(mApp);

        mPhaseCounter = 150;
        mVariant = false;

        if (mHasZombatar)
        {
			ApplyZombatarHead(mApp, &mApp->mPlayerInfo->mZombatars[mZombatarIndex]);
        }

        break;
    }

    case ZombieType::ZOMBIE_POGO:  //0x5232A6
        mVariant = false;
        mZombiePhase = ZombiePhase::PHASE_POGO_BOUNCING;
        mPhaseCounter = Rand(POGO_BOUNCE_TIME) + 1;
        mHasObject = true;
        mBodyHealth = 500;
        mZombieAttackRect = Rect(10, 0, 30, 115);
        PlayZombieReanim(ReanimTrackId::anim_pogo, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 40.0f);
        mApp->ReanimationGet(mBodyReanimID)->mAnimTime = 1.0f;
        break;

    case ZombieType::ZOMBIE_NEWSPAPER:  //0x52333D
        mZombieAttackRect = Rect(20, 0, 50, 115);
        mZombiePhase = ZombiePhase::PHASE_NEWSPAPER_READING;
        mShieldType = ShieldType::SHIELDTYPE_NEWSPAPER;
        mShieldHealth = 150;
        mVariant = false;
        AttachShield();
        break;

    case ZombieType::ZOMBIE_BALLOON:  //0x523397
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        aBodyReanim->SetTruncateDisappearingFramesAll( false);

        if (IsOnBoard())
        {
            mAltitude = 25.0f;
            mZombiePhase = ZombiePhase::PHASE_BALLOON_FLYING;
            PlayZombieReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, aBodyReanim->mAnimRate);
        }
        else
        {
            float aAnimRate = RandRangeFloat(8.0f, 10.0f);
            SetAnimRate(aAnimRate);
        }

        Reanimation* aPropellerReanim = mApp->AddReanimation(0.0f, 0.0f, 0, aZombieDef.mReanimationType);
        aPropellerReanim->SetFramesForLayer(ReanimTrackId::propeller);
        aPropellerReanim->mLoopType = ReanimLoopType::REANIM_LOOP_FULL_LAST_FRAME;
        aPropellerReanim->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::hat);

        mFlyingHealth = 20;
        mZombieRect = Rect(36, 30, 42, 115);
        mZombieAttackRect = Rect(20, 30, 50, 115);
        mVariant = false;
        break;
    }

    case ZombieType::ZOMBIE_DANCER:  //0x5234DF
        // @Patoke: add scaling for new assets
        mScaleZombie = 0.8f;
        if (!IsOnBoard())
        {
            // @Patoke: oops
            PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
        }
        else
        {
            mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_IN;
            mVelX = 0.5f;
            mPhaseCounter = 300 + Rand(12);
            PlayZombieReanim(ReanimTrackId::anim_moonwalk, ReanimLoopType::REANIM_LOOP, 0, 24.0f);
        }
        mBodyHealth = 500;
        mVariant = false;
        break;

    case ZombieType::ZOMBIE_BACKUP_DANCER:  //0x523541
        // @Patoke: add scaling for new assets
        mScaleZombie = 0.8f;
        if (!IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_armraise, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
        }
        mZombiePhase = ZombiePhase::PHASE_DANCER_DANCING_LEFT;
        mVariant = false;
        break;

    case ZombieType::ZOMBIE_IMP:  //0x523576
        if (!IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_walk, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
        }
        if (mApp->IsIZombieLevel())
        {
            mBodyHealth = 70;
        }
        break;
    
    case ZombieType::ZOMBIE_BOSS:  //0x5235BE
        mPosX = 0.0f;
        mPosY = 0.0f;
        mZombieRect = Rect(700, 80, 90, 430);
        mZombieAttackRect = Rect(0, 0, 0, 0);
        aRenderLayer = RenderLayer::RENDER_LAYER_TOP;
        mBodyHealth = mApp->IsAdventureMode() ? 40000 : 60000;
        if (IsOnBoard())
        {
            PlayZombieReanim(ReanimTrackId::anim_enter, ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD, 0, 12.0f);
            mSummonCounter = 500;
            mBossHeadCounter = 5000;
            mZombiePhase = ZombiePhase::PHASE_BOSS_ENTER;
        }
        else
        {
            PlayZombieReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 12.0f);
        }
        BossSetupReanim();
        break;
    
    case ZombieType::ZOMBIE_PEA_HEAD:  //0x52369B
    {
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (IsOnBoard())
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
        }

        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
        aTrackInstance->mImageOverride = IMAGE_BLANK;
        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_PEASHOOTER);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;
        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 65.0f, -5.0f, 0.2f, -1.0f, 1.0f);

        mPhaseCounter = 150;
        mVariant = false;
        break;
    }
    
    case ZombieType::ZOMBIE_WALLNUT_HEAD:  //0x523719
    {
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_WALLNUT);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;
        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 50.0f, 0.0f, 0.2f, -0.8f, 0.8f);

        mHelmType = HelmType::HELMTYPE_WALLNUT;
        mHelmHealth = 1100;
        mVariant = false;
        break;
    }

    case ZombieType::ZOMBIE_TALLNUT_HEAD:  //0x523842
    {
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_TALLNUT);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;
        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 37.0f, 0.0f, 0.2f, -0.8f, 0.8f);

        mHelmType = HelmType::HELMTYPE_TALLNUT;
        mHelmHealth = 2200;
        mVariant = false;
        mPosX += 30.0f;
        break;
    }

    case ZombieType::ZOMBIE_JALAPENO_HEAD:  //0x523977
    {
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::Zombie_tie, RENDER_GROUP_HIDDEN);

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::Zombie_body);
        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_JALAPENO);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;
        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 55.0f, -5.0f, 0.2f, -1.0f, 1.0f);

        mVariant = false;
        mBodyHealth = 500;
        int aDistance = 275 + Rand(175);
        mPhaseCounter = (int)(aDistance / mVelX) * ZOMBIE_LIMP_SPEED_FACTOR;
        break;
    }

    case ZombieType::ZOMBIE_GATLING_HEAD:  //0x523ABA
    {
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (IsOnBoard())
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
        }

        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
        aTrackInstance->mImageOverride = IMAGE_BLANK;
        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_GATLINGPEA);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_head_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;
        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 65.0f, -5.0f, 0.2f, -1.0f, 1.0f);

        mPhaseCounter = 150;
        mVariant = false;
        break;
    }

    case ZombieType::ZOMBIE_SQUASH_HEAD:  //0x523BE7
    {
        LoadPlainZombieReanim();
        ReanimShowRange(ReanimTrackRanges::anim_hair, RENDER_GROUP_HIDDEN);
        ReanimShowRange(ReanimTrackRanges::anim_head2, RENDER_GROUP_HIDDEN);

        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (IsOnBoard())
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_walk2);
        }

        ReanimatorTrackInstance* aTrackInstance = aBodyReanim->GetTrackInstanceByName(ReanimTrackId::anim_head1);
        aTrackInstance->mImageOverride = IMAGE_BLANK;
        Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, 0, ReanimationType::REANIM_SQUASH);
        aHeadReanim->PlayReanim(ReanimTrackId::anim_idle, ReanimLoopType::REANIM_LOOP, 0, 15.0f);
        mSpecialHeadReanimID = mApp->ReanimationGetID(aHeadReanim);
        AttachEffect* aAttachEffect = AttachReanim(aTrackInstance->mAttachmentID, aHeadReanim, 0.0f, 0.0f);
        aBodyReanim->mFrameBasePose = 0;
        TodScaleRotateTransformMatrix(aAttachEffect->mOffset, 55.0f, -15.0f, 0.2f, -0.75f, 0.75f);

        mZombiePhase = ZombiePhase::PHASE_SQUASH_PRE_LAUNCH;
        mVariant = false;
        break;
    }
    case ZombieType::ZOMBIE_CACHED_POLEVAULTER_WITH_POLE:
    case ZombieType::NUM_ZOMBIE_TYPES:
    case ZombieType::NUM_CACHED_ZOMBIE_TYPES:
    case ZombieType::ZOMBIE_INVALID:
        break;
    }

    if (IsOnBoard() && mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_ZOMBIQUARIUM)
    {
        float aAnimRate = RandRangeFloat(8.0f, 10.0f);
        PlayZombieReanim(ReanimTrackId::anim_aquarium_swim, ReanimLoopType::REANIM_LOOP, 0, aAnimRate);

        mZombieHeight = ZombieHeight::HEIGHT_ZOMBIQUARIUM;
        mZombiePhase = ZombiePhase::PHASE_ZOMBIQUARIUM_DRIFT;
        mPhaseCounter = 200;
        mBodyHealth = 200;
        mSummonCounter = RandRangeInt(200, 400);
    }

    if (mApp->IsLittleTroubleLevel() && (IsOnBoard() || theFromWave == Zombie::ZOMBIE_WAVE_CUTSCENE))
    {
        mScaleZombie = 0.5f;
        mBodyHealth /= 4;
        mHelmHealth /= 4;
        mShieldHealth /= 4;
        mFlyingHealth /= 4;
    }

    UpdateAnimSpeed();
    if (mVariant)
    {
        ReanimShowRange(ReanimTrackRanges::anim_tongue, RENDER_GROUP_NORMAL);
    }

    mHelmMaxHealth = mHelmHealth;
    mBodyMaxHealth = mBodyHealth;
    mShieldMaxHealth = mShieldHealth;
    mFlyingMaxHealth = mFlyingHealth;
    mDead = false;
    mX = (int)mPosX;
    mY = (int)mPosY;
    mRenderOrder = Board::MakeRenderOrder(aRenderLayer, mRow, aRenderOffset);
    if (mZombieHeight == ZombieHeight::HEIGHT_ZOMBIQUARIUM)
    {
        mBodyMaxHealth = 300;
    }

    if (IsOnBoard())
    {
        PlayZombieAppearSound();
        StartZombieSound();
    }

    UpdateReanim();
}

// ==================== FormB 驱动（HEAD 868-985 逐字；仅签名加 _B 与 noinline） ====================
//0x522580
// GOTY @Patoke: 0x5329A0
__declspec(noinline) void Zombie::ZombieInitialize_B(int theRow, ZombieType theType, bool theVariant, Zombie* theParentZombie, int theFromWave)
{
    TOD_ASSERT(theType >= 0 && theType <= ZombieType::NUM_ZOMBIE_TYPES);

    mHasZombatar = false;
    // GOTY 1073 rewrites a flag zombie to the dedicated Zombatar type before
    // the rest of initialization, then selects one saved avatar at random.
    if (theType == ZombieType::ZOMBIE_FLAG && mApp->mPlayerInfo &&
        mApp->mPlayerInfo->mNumZombatars > 0)
    {
        theType = ZombieType::ZOMBIE_ZOMBATAR;
        mHasZombatar = true;
        mZombatarIndex = Rand(mApp->mPlayerInfo->mNumZombatars);
        if (mZombatarIndex >= mApp->mPlayerInfo->mNumZombatars)
            mZombatarIndex = mApp->mPlayerInfo->mNumZombatars - 1;
    }

    mRow = theRow;
    mFromWave = theFromWave;
    mPosX = 780 + Rand(ZOMBIE_START_RANDOM_OFFSET);
    mPosY = GetPosYBasedOnRow(theRow);
    mVelX = 0.0f;
    mVelZ = 0.0f;
    mWidth = 120;
    mHeight = 120;
    mFrame = 0;
    mPrevFrame = 0;
    mZombieType = theType;
    mVariant = theVariant;
    mIsEating = false;
    mJustGotShotCounter = 0;
    mShieldJustGotShotCounter = 0;
    mShieldRecoilCounter = 0;
    mChilledCounter = 0;
    mIceTrapCounter = 0;
    mButteredCounter = 0;
    mMindControlled = false;
    mBlowingAway = false;
    mHasHead = true;
    mHasArm = true;
    mHasObject = false;
    mInPool = false;
    mOnHighGround = false;
    mHelmType = HelmType::HELMTYPE_NONE;
    mShieldType = ShieldType::SHIELDTYPE_NONE;
    mYuckyFace = false;
    mYuckyFaceCounter = 0;
    mAnimCounter = 0;
    mGroanCounter = RandRangeInt(300, 400);
    mAnimTicksPerFrame = 12;
    mAnimFrames = 12;
    mZombieAge = 0;
    mTargetCol = -1;
    mZombiePhase = ZombiePhase::PHASE_ZOMBIE_NORMAL;
    mZombieHeight = ZombieHeight::HEIGHT_ZOMBIE_NORMAL;
    mPhaseCounter = 0;
    mHitUmbrella = false;
    mDroppedLoot = false;
    mRelatedZombieID = ZombieID::ZOMBIEID_NULL;
    mZombieRect = Rect(36, 0, 42, 115);
    mZombieAttackRect = Rect(50, 0, 20, 115);
    mPlayingSong = false;
    mZombieFade = -1;
    mFlatTires = false;
    mScaleZombie = 1.0f;
    mUseLadderCol = -1;
    mShieldHealth = 0;
    mHelmHealth = 0;
    mAltitude = 0.0f;
    mFlyingHealth = 0;
    mOriginalAnimRate = 0.0f;
    mAttachmentID = AttachmentID::ATTACHMENTID_NULL;
    mSummonCounter = 0;
    mBossStompCounter = -1;
    mBossBungeeCounter = -1;
    mBossHeadCounter = -1;
    mBodyReanimID = ReanimationID::REANIMATIONID_NULL;
    mTargetPlantID = PlantID::PLANTID_NULL;
    mBossMode = 0;
    mBossFireBallReanimID = ReanimationID::REANIMATIONID_NULL;
    mSpecialHeadReanimID = ReanimationID::REANIMATIONID_NULL;
    mTargetRow = -1;
    mFireballRow = -1;
    mIsFireBall = false;
    mMoweredReanimID = ReanimationID::REANIMATIONID_NULL;
    mLastPortalX = -1;
    for (int i = 0; i < MAX_ZOMBIE_FOLLOWERS; i++)
    {
        mFollowerZombieID[i] = ZombieID::ZOMBIEID_NULL;
    }
    if (mBoard && mBoard->IsFlagWave(mFromWave))
    {
        mPosX += 40.0f;
    }
    PickRandomSpeed();
    mBodyHealth = 270;

    const ZombieDefinition& aZombieDef = GetZombieDefinition(mZombieType);
    if (aZombieDef.mReanimationType != ReanimationType::REANIM_NONE)
    {
        LoadReanim(aZombieDef.mReanimationType);
    }

    // C 形态 -> 匿名 lambda 表（固定尾部直呼形态）：尾部公共逻辑具名化，
    // 各槽位结尾直呼 ZombieInitializeTail；case 内 return 原样即跳过尾部；
    // 越界哨兵走 else 直调（原 default 无操作后尾部照跑）。
    ZombieInitLocals aInitLocals{RenderLayer::RENDER_LAYER_ZOMBIE, 4,
        aZombieDef.mReanimationType, theParentZombie, theFromWave};
    const unsigned aTypeIndex = static_cast<unsigned>(theType);
    if (aTypeIndex < static_cast<unsigned>(ZombieType::NUM_ZOMBIE_TYPES))
    {
        kZombieInitCases[aTypeIndex](*this, aInitLocals);
    }
    else
    {
        ZombieInitializeTail(*this, aInitLocals);
    }
}

// ============================ main ============================
static Zombie g_z;
static Zombie g_parent;
static Board g_board;
static LawnApp g_app;
static CutScene g_cut;
static PlayerInfo g_pi;

static void ResetZ(int row, ZombieType t, bool variant, int fromWave, int zombatars)
{
    g_z.mApp = &g_app;
    g_z.mBoard = &g_board;
    g_app.mBoard = &g_board;
    g_board.mApp = &g_app;
    g_board.mCutScene = &g_cut;
    g_app.mPlayerInfo = &g_pi;
    g_pi.mNumZombatars = zombatars;
    g_z.mDead = false;
    g_z.mVelX = 0.0f;
    g_z.mPosX = 780.0f;
    g_z.mZombieType = t;
    g_parent.mFollowerZombieID[0] = ZombieID::ZOMBIEID_NULL;
    g_parent.mFollowerZombieID[1] = ZombieID::ZOMBIEID_NULL;
    g_parent.mFollowerZombieID[2] = ZombieID::ZOMBIEID_NULL;
    (void)row; (void)fromWave;
}

int main()
{
    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ZombieType t = (ZombieType)(g_inputs[i].a % (int)ZombieType::NUM_ZOMBIE_TYPES);
                ResetZ((int)(g_inputs[i].b % 6), t, (g_inputs[i].c & 1) != 0, (int)(g_inputs[i].d % 40) - 8, (int)(g_inputs[i].b % 3));
                g_z.ZombieInitialize_A((int)(g_inputs[i].b % 6), t, (g_inputs[i].c & 1) != 0, &g_parent, (int)(g_inputs[i].d % 40) - 8);
                g_z.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ZombieType t = (ZombieType)(g_inputs[i].a % (int)ZombieType::NUM_ZOMBIE_TYPES);
                ResetZ((int)(g_inputs[i].b % 6), t, (g_inputs[i].c & 1) != 0, (int)(g_inputs[i].d % 40) - 8, (int)(g_inputs[i].b % 3));
                g_z.ZombieInitialize_B((int)(g_inputs[i].b % 6), t, (g_inputs[i].c & 1) != 0, &g_parent, (int)(g_inputs[i].d % 40) - 8);
                g_z.HashFold(ck);
            }
        };
        rc |= R3BenchMain("t26_ZombieInitialize_kZombieInitCases", reset, pa, pb);
    }
    return rc;
}
