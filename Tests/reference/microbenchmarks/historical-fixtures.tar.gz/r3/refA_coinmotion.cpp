    {
        mWidth = IMAGE_PRESENT->GetCelWidth();
        mHeight = IMAGE_PRESENT->GetCelHeight();
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 0);
    }

    switch (mCoinMotion)
    {
    case CoinMotion::COIN_MOTION_FROM_SKY:
        mVelY = 0.67f;
        mVelX = 0.0f;
        mGroundY = Rand(250) + 300;
        break;

    case CoinMotion::COIN_MOTION_FROM_SKY_SLOW:
        mVelY = 0.33f;
        mVelX = 0.0f;
        mGroundY = Rand(250) + 300;
        break;

    case CoinMotion::COIN_MOTION_FROM_PLANT:
        mVelY = -1.7f - RandRangeFloat(0.0f, 1.7f);
        mVelX = -0.4f + RandRangeFloat(0.0f, 0.8f);
        mGroundY = mPosY + 15 + Rand(20);
        mScale = 0.4f;
        break;

    case CoinMotion::COIN_MOTION_COIN:
        mVelY = -3.0f - RandRangeFloat(0.0f, 2.0f);
        mVelX = -0.5f + RandRangeFloat(0.0f, 1.0f);
        mGroundY = mPosY + 45 + Rand(20);
        if (mGroundY > 521)
        {
            mGroundY = 521;
        }
        if (mGroundY < 80)
        {
            mGroundY = 80;
        }
        if (mType == CoinType::COIN_AWARD_SILVER_SUNFLOWER || mType == CoinType::COIN_AWARD_GOLD_SUNFLOWER)
        {
            mPosY -= 100.0f;
            mGroundY = mPosY + 45.0f;
            if (mGroundY > 400)
            {
                mGroundY = 400;
            }
        }
        if (mType == CoinType::COIN_FINAL_SEED_PACKET || 
            mType == CoinType::COIN_USABLE_SEED_PACKET || 
            mType == CoinType::COIN_TROPHY || 
            mType == CoinType::COIN_SHOVEL || 
            mType == CoinType::COIN_CARKEYS || 
            mType == CoinType::COIN_ALMANAC || 
            mType == CoinType::COIN_VASE || 
            mType == CoinType::COIN_WATERING_CAN || 
            mType == CoinType::COIN_TACO || 
            mType == CoinType::COIN_NOTE)
        {
            mGroundY -= 30;
        }
        break;

    case CoinMotion::COIN_MOTION_LAWNMOWER_COIN:
        mVelY = 0.0f;
        mVelX = 0.0f;
        mGroundY = 600;
        Collect();
        break;

    case CoinMotion::COIN_MOTION_FROM_PRESENT:
        mVelY = 0.0f;
        mVelX = 0.0f;
        mGroundY = 600;
        mRenderOrder = Board::MakeRenderOrder(RenderLayer::RENDER_LAYER_ABOVE_UI, 0, 1);
        break;

    case CoinMotion::COIN_MOTION_FROM_BOSS:
        mVelY = -5.0f;
        mVelX = -3.0f;
        mPosX = 750.0f;
