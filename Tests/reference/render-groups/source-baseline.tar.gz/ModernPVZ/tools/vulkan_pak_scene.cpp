#include "pvz/assets/image_decode.hpp"
#include "pvz/assets/pak_archive.hpp"
#include "pvz/render/draw_command_recorder.hpp"
#include "pvz/render/sexy_draw_adapter.hpp"
#include "pvz/render/viewport.hpp"
#include "pvz/render/vulkan/vulkan_window_backend.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

namespace {

constexpr std::uint32_t kBoardOffset = 220;
constexpr std::uint32_t kLogicalHeight = 600;
constexpr std::uint32_t kMaximumLogicalWidth = 1068;

void write_u16(std::ofstream& output, const std::uint16_t value)
{
    output.put(static_cast<char>(value & 0xFFU));
    output.put(static_cast<char>((value >> 8U) & 0xFFU));
}

void write_u32(std::ofstream& output, const std::uint32_t value)
{
    output.put(static_cast<char>(value & 0xFFU));
    output.put(static_cast<char>((value >> 8U) & 0xFFU));
    output.put(static_cast<char>((value >> 16U) & 0xFFU));
    output.put(static_cast<char>((value >> 24U) & 0xFFU));
}

void write_bmp(const std::filesystem::path& path, const pvz::render::vulkan::CapturedFrame& frame)
{
    const std::uint64_t pixel_bytes_64 = static_cast<std::uint64_t>(frame.extent.width) *
                                         frame.extent.height * 4;
    if (pixel_bytes_64 > std::numeric_limits<std::uint32_t>::max() - 54U)
        throw std::length_error("capture is too large for the BMP writer");
    const auto pixel_bytes = static_cast<std::uint32_t>(pixel_bytes_64);

    if (const auto parent = path.parent_path(); !parent.empty())
        std::filesystem::create_directories(parent);
    std::ofstream output{path, std::ios::binary};
    if (!output)
        throw std::runtime_error("unable to create capture: " + path.string());

    output.write("BM", 2);
    write_u32(output, 14 + 40 + pixel_bytes);
    write_u16(output, 0);
    write_u16(output, 0);
    write_u32(output, 14 + 40);
    write_u32(output, 40);
    write_u32(output, frame.extent.width);
    write_u32(output, frame.extent.height);
    write_u16(output, 1);
    write_u16(output, 32);
    write_u32(output, 0);
    write_u32(output, pixel_bytes);
    write_u32(output, 2835);
    write_u32(output, 2835);
    write_u32(output, 0);
    write_u32(output, 0);

    for (std::uint32_t y = frame.extent.height; y-- > 0;) {
        for (std::uint32_t x = 0; x < frame.extent.width; ++x) {
            const std::size_t offset = (static_cast<std::size_t>(y) * frame.extent.width + x) * 4;
            output.put(static_cast<char>(frame.rgba8[offset + 2]));
            output.put(static_cast<char>(frame.rgba8[offset + 1]));
            output.put(static_cast<char>(frame.rgba8[offset]));
            output.put(static_cast<char>(frame.rgba8[offset + 3]));
        }
    }
    if (!output)
        throw std::runtime_error("unable to write capture: " + path.string());
}

[[nodiscard]] std::uint64_t fnv1a64(const std::vector<std::uint8_t>& bytes)
{
    std::uint64_t hash = 14695981039346656037ULL;
    for (const std::uint8_t byte : bytes) {
        hash ^= byte;
        hash *= 1099511628211ULL;
    }
    return hash;
}

[[nodiscard]] std::size_t capture_pixel_offset(
    const pvz::render::vulkan::CapturedFrame& frame,
    const std::uint32_t x,
    const std::uint32_t y)
{
    return (static_cast<std::size_t>(y) * frame.extent.width + x) * 4;
}

[[nodiscard]] std::size_t source_pixel_offset(
    const pvz::assets::DecodedImage& image,
    const std::uint32_t x,
    const std::uint32_t y)
{
    return static_cast<std::size_t>(y) * image.row_pitch_bytes + static_cast<std::size_t>(x) * 4;
}

[[nodiscard]] bool is_dark_pixel(
    const std::vector<std::uint8_t>& pixels,
    const std::size_t offset) noexcept
{
    return pixels[offset] < 80 && pixels[offset + 1] < 80 && pixels[offset + 2] < 80 &&
           pixels[offset + 3] >= 250;
}

struct PixelComparison {
    std::size_t samples{0};
    std::uint64_t absolute_error{0};
    std::uint8_t maximum_error{0};
};

[[nodiscard]] PixelComparison compare_authoritative_crop(
    const pvz::render::vulkan::CapturedFrame& capture,
    const pvz::assets::DecodedImage& source,
    const std::uint32_t viewport_x)
{
    PixelComparison result;
    for (std::uint32_t y = 29; y < kLogicalHeight - 29; y += 67) {
        for (std::uint32_t x = 17; x < kMaximumLogicalWidth - 17; x += 89) {
            const auto captured_offset = capture_pixel_offset(capture, viewport_x + x, y);
            const auto expected_offset = source_pixel_offset(source, kBoardOffset + x, y);
            for (std::size_t channel = 0; channel < 3; ++channel) {
                const int captured = capture.rgba8[captured_offset + channel];
                const int expected = std::to_integer<std::uint8_t>(source.rgba8[expected_offset + channel]);
                const auto error = static_cast<std::uint8_t>(std::abs(captured - expected));
                result.absolute_error += error;
                result.maximum_error = std::max(result.maximum_error, error);
                ++result.samples;
            }
        }
    }
    return result;
}

int run(
    const std::filesystem::path& pak_path,
    const std::string_view resource_path,
    const std::filesystem::path& vertex_shader,
    const std::filesystem::path& fragment_shader,
    const std::filesystem::path& output_path,
    const bool visible,
    const bool enable_validation)
{
    const auto archive = pvz::assets::PakArchive::open(pak_path);
    const auto entry = archive.find(resource_path);
    if (!entry)
        throw std::runtime_error("PAK resource not found: " + std::string(resource_path));
    const auto encoded = archive.read(entry->get());
    const auto image = pvz::assets::decode_image_rgba8(encoded, pvz::assets::ImageColorSpace::srgb);
    if (image.height != kLogicalHeight || image.width < kBoardOffset + kMaximumLogicalWidth)
        throw std::runtime_error("background does not cover the audited 220..1287 by 0..599 source region");

    pvz::render::vulkan::VulkanWindowConfig config;
    config.title = "Modern PvZ authoritative PAK scene probe";
    config.pixel_width = 800;
    config.pixel_height = 600;
    config.visible = visible;
    config.enable_validation = enable_validation;
    config.vertical_sync = true;
    pvz::render::vulkan::VulkanWindowBackend backend{
        std::move(config),
        vertex_shader,
        fragment_shader,
    };

    const auto texture = backend.create_texture({
        image.width,
        image.height,
        image.row_pitch_bytes,
        pvz::render::TextureFormat::rgba8_srgb,
        image.rgba8,
    });

    bool resized_to_wide = false;
    bool resized_to_ultrawide = false;
    bool capture_requested = false;
    std::optional<pvz::render::vulkan::CapturedFrame> capture;
    std::uint64_t frame_index = 0;

    while (backend.poll_events() && backend.presented_frames() < 150 && !capture) {
        const auto presented = backend.presented_frames();
        if (!resized_to_wide && presented >= 40) {
            backend.resize(1068, 600);
            resized_to_wide = true;
        }
        if (!resized_to_ultrawide && presented >= 85) {
            backend.resize(1280, 600);
            resized_to_ultrawide = true;
        }
        if (!capture_requested && presented >= 125) {
            backend.request_capture();
            capture_requested = true;
        }

        const auto pixels = backend.pixel_extent();
        if (pixels.width == 0 || pixels.height == 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }
        const auto transform = pvz::render::ViewportTransform::create(pixels.width, pixels.height);
        const auto logical = transform.logical_extent();
        pvz::render::DrawCommandRecorder recorder{
            frame_index++,
            logical,
            transform.pixel_viewport(),
        };
        pvz::render::SexyDrawCommandAdapter sexy_draw{recorder};
        sexy_draw.blt(
            {
                texture,
                {static_cast<double>(image.width), static_cast<double>(image.height)},
                {{static_cast<double>(kBoardOffset), 0.0}, logical},
            },
            {0.0, 0.0},
            pvz::render::pack_rgba8(255, 255, 255, 255),
            pvz::render::BlendMode::opaque);
        backend.submit(recorder.frame());
        capture = backend.take_capture();
    }

    backend.wait_idle();
    backend.destroy_texture(texture);
    if (!capture)
        throw std::runtime_error("the Vulkan PAK scene probe did not capture a presented frame");
    if (capture->extent.width != 1280 || capture->extent.height != 600)
        throw std::runtime_error("captured frame did not use the final 1280x600 swapchain extent");

    const auto final_transform = pvz::render::ViewportTransform::create(
        capture->extent.width,
        capture->extent.height);
    const auto final_viewport = final_transform.pixel_viewport();
    const auto viewport_x = static_cast<std::uint32_t>(std::llround(final_viewport.origin.x));
    const auto viewport_width = static_cast<std::uint32_t>(std::llround(final_viewport.extent.width));
    if (viewport_width != kMaximumLogicalWidth || viewport_x * 2 + viewport_width != capture->extent.width)
        throw std::runtime_error("final viewport does not preserve the centered 1068x600 audited region");

    std::size_t dark_bar_pixels = 0;
    const std::size_t expected_bar_pixels = static_cast<std::size_t>(capture->extent.width - viewport_width) *
                                            capture->extent.height;
    for (std::uint32_t y = 0; y < capture->extent.height; ++y) {
        for (std::uint32_t x = 0; x < viewport_x; ++x) {
            if (is_dark_pixel(capture->rgba8, capture_pixel_offset(*capture, x, y)))
                ++dark_bar_pixels;
        }
        for (std::uint32_t x = viewport_x + viewport_width; x < capture->extent.width; ++x) {
            if (is_dark_pixel(capture->rgba8, capture_pixel_offset(*capture, x, y)))
                ++dark_bar_pixels;
        }
    }
    if (dark_bar_pixels < expected_bar_pixels * 99 / 100)
        throw std::runtime_error("captured frame is missing its two safe side bars");

    std::uint8_t minimum_channel = 255;
    std::uint8_t maximum_channel = 0;
    for (std::uint32_t y = 0; y < capture->extent.height; y += 7) {
        for (std::uint32_t x = viewport_x; x < viewport_x + viewport_width; x += 7) {
            const auto offset = capture_pixel_offset(*capture, x, y);
            for (std::size_t channel = 0; channel < 3; ++channel) {
                minimum_channel = std::min(minimum_channel, capture->rgba8[offset + channel]);
                maximum_channel = std::max(maximum_channel, capture->rgba8[offset + channel]);
            }
        }
    }
    if (static_cast<unsigned>(maximum_channel) - minimum_channel < 96U)
        throw std::runtime_error("captured content does not contain the expected image contrast");

    const auto comparison = compare_authoritative_crop(*capture, image, viewport_x);
    const double mean_error = comparison.samples == 0
                                  ? std::numeric_limits<double>::infinity()
                                  : static_cast<double>(comparison.absolute_error) / comparison.samples;
    if (mean_error > 3.0 || comparison.maximum_error > 16)
        throw std::runtime_error("captured pixels do not match the authoritative crop or orientation");
    if (backend.swapchain_recreations() < 3)
        throw std::runtime_error("window resizes did not rebuild the Vulkan swapchain");
    if (backend.validation_error_count() != 0)
        throw std::runtime_error("Vulkan validation reported errors");

    write_bmp(output_path, *capture);
    std::cout << "backend=" << backend.capabilities().name
              << "\nresource=" << entry->get().path
              << "\nencoded_bytes=" << encoded.size()
              << "\ndecoded_size=" << image.width << 'x' << image.height
              << "\nsource_crop=" << kBoardOffset << ",0.."
              << kBoardOffset + kMaximumLogicalWidth - 1 << ',' << kLogicalHeight - 1
              << "\nsize=" << capture->extent.width << 'x' << capture->extent.height
              << "\nlogical_size=" << viewport_width << 'x' << kLogicalHeight
              << "\npresented_frames=" << backend.presented_frames()
              << "\nswapchain_recreations=" << backend.swapchain_recreations()
              << "\nvalidation=" << (enable_validation ? "on" : "off")
              << "\nvalidation_errors=" << backend.validation_error_count()
              << "\ndark_bar_pixels=" << dark_bar_pixels << '/' << expected_bar_pixels
              << "\nsample_rgb_mean_error=" << std::fixed << std::setprecision(3) << mean_error
              << "\nsample_rgb_max_error=" << static_cast<unsigned>(comparison.maximum_error)
              << "\nfnv1a64=0x" << std::hex << fnv1a64(capture->rgba8) << std::dec
              << "\noutput=" << output_path.string() << '\n';
    return 0;
}

} // namespace

int main(const int argc, const char* const argv[])
{
    if (argc < 6 || argc > 8) {
        std::cerr << "usage: pvz_vulkan_pak_scene <main.pak> <resource-path> "
                     "<vertex.spv> <fragment.spv> <output.bmp> [--hidden] [--validation]\n";
        return 2;
    }
    bool visible = true;
    bool enable_validation = false;
    for (int index = 6; index < argc; ++index) {
        const std::string_view option{argv[index]};
        if (option == "--hidden")
            visible = false;
        else if (option == "--validation")
            enable_validation = true;
        else {
            std::cerr << "unknown option: " << option << '\n';
            return 2;
        }
    }
    try {
        return run(argv[1], argv[2], argv[3], argv[4], argv[5], visible, enable_validation);
    } catch (const std::exception& error) {
        std::cerr << "pvz_vulkan_pak_scene: " << error.what() << '\n';
        return 1;
    }
}
