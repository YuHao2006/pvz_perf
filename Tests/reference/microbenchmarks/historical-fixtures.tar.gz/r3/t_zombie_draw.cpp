// t_zombie_draw.cpp — ★每帧四目标单测：
//   t01 kIceTrapAdjusts  -> Zombie::DrawIceTrap   （冻结期每帧）
//   t02 kButterAdjusts   -> Zombie::DrawButter    （黄油期每帧）
//   t03 kDancerSpotlight -> Zombie::DrawDancerReanim（舞王每帧）
//   t04 kZombiesWonClip  -> Zombie::SetupDrawZombieWon（胜利期每帧）
// FormA = 引入提交父版逐字；FormB = HEAD 逐字（命名空间级表照抄）。
#include "r3_entities.h"

// ==================== t01 DrawIceTrap ====================
// FormA：446bc24a（=beaacd3b^）原 switch 逐字
__declspec(noinline) void Zombie::DrawIceTrap_A(Graphics* g, const ZombieDrawPosition& theDrawPos, bool theFront)
{
    if (mInPool || mZombieType == ZombieType::ZOMBIE_BOSS)
        return;

    float aOffsetX = 46.0f;
    float aOffsetY = theDrawPos.mBodyY + 92.0f;
    float aScale = 1.0f;
    switch (mZombieType)
    {
    case ZombieType::ZOMBIE_POGO:
        aOffsetX -= 10.0f;
        aOffsetY += 20.0f;
        break;
    case ZombieType::ZOMBIE_GARGANTUAR:
    case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:
        aOffsetX -= 20.0f;
        aOffsetY -= 7.0f;
        aScale = 1.6f;
        break;
    case ZombieType::ZOMBIE_BUNGEE:
        aOffsetX -= 45.0f;
        aOffsetY -= 23.0f;
        aScale = 1.2f;
        break;
    case ZombieType::ZOMBIE_DIGGER:
        aOffsetX -= 27.0f;
        break;
    case ZombieType::ZOMBIE_CATAPULT:
        aOffsetX += 32.0f;
        break;
    case ZombieType::ZOMBIE_BALLOON:
        aOffsetX -= 9.0f;
        aOffsetY += 27.0f;
        break;
    default:
        break;
    }

    TodDrawImageScaledF(g, theFront ? IMAGE_ICETRAP : IMAGE_ICETRAP2, aOffsetX, aOffsetY, aScale, aScale);
}

namespace
{
// Zombie::DrawIceTrap 偏移调整表：表内匿名 lambda = 原 case 体逐句迁移
//（生成器 + 逆变换 token 对拍 0 差异）；无 case 槽不调整（哨兵布尔表）。
struct IceTrapAdjust
{
    float mDx;
    float mDy;
    float mScale;
    bool mAdjust;   // false = 哨兵：不调整
};
using IceTrapAdjustFn = void (*)(Zombie&, IceTrapAdjust&);

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case ZOMBIE_GARGANTUAR, ZOMBIE_REDEYE_GARGANTUAR
void IceTrapAdjustCaseGargantuar(Zombie& z, IceTrapAdjust& lc)
{
            lc.mDx -= 20.0f;
            lc.mDy -= 7.0f;
            lc.mScale = 1.6f;
}

// 原 default（无 case 的 27 型（空操作）共用）
void IceTrapNoAdjust(Zombie& z, IceTrapAdjust& lc)
{

}

// 匿名 lambda 函数指针表，行序 = ZombieType 枚举值序（0..33）。
constexpr IceTrapAdjustFn kIceTrapAdjusts[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
    &IceTrapNoAdjust,  // 0 ZOMBIE_NORMAL（原 default）
    &IceTrapNoAdjust,  // 1 ZOMBIE_FLAG（原 default）
    &IceTrapNoAdjust,  // 2 ZOMBIE_TRAFFIC_CONE（原 default）
    &IceTrapNoAdjust,  // 3 ZOMBIE_POLEVAULTER（原 default）
    &IceTrapNoAdjust,  // 4 ZOMBIE_PAIL（原 default）
    &IceTrapNoAdjust,  // 5 ZOMBIE_NEWSPAPER（原 default）
    &IceTrapNoAdjust,  // 6 ZOMBIE_DOOR（原 default）
    &IceTrapNoAdjust,  // 7 ZOMBIE_FOOTBALL（原 default）
    &IceTrapNoAdjust,  // 8 ZOMBIE_DANCER（原 default）
    &IceTrapNoAdjust,  // 9 ZOMBIE_BACKUP_DANCER（原 default）
    &IceTrapNoAdjust,  // 10 ZOMBIE_DUCKY_TUBE（原 default）
    &IceTrapNoAdjust,  // 11 ZOMBIE_SNORKEL（原 default）
    &IceTrapNoAdjust,  // 12 ZOMBIE_ZAMBONI（原 default）
    &IceTrapNoAdjust,  // 13 ZOMBIE_BOBSLED（原 default）
    &IceTrapNoAdjust,  // 14 ZOMBIE_DOLPHIN_RIDER（原 default）
    &IceTrapNoAdjust,  // 15 ZOMBIE_JACK_IN_THE_BOX（原 default）
    // 原 case ZOMBIE_BALLOON
    [](Zombie& z, IceTrapAdjust& lc)
    {
            lc.mDx -= 9.0f;
            lc.mDy += 27.0f;
    },  // 16 ZOMBIE_BALLOON
    // 原 case ZOMBIE_DIGGER
    [](Zombie& z, IceTrapAdjust& lc)
    {
            lc.mDx -= 27.0f;
    },  // 17 ZOMBIE_DIGGER
    // 原 case ZOMBIE_POGO
    [](Zombie& z, IceTrapAdjust& lc)
    {
            lc.mDx -= 10.0f;
            lc.mDy += 20.0f;
    },  // 18 ZOMBIE_POGO
    &IceTrapNoAdjust,  // 19 ZOMBIE_YETI（原 default）
    // 原 case ZOMBIE_BUNGEE
    [](Zombie& z, IceTrapAdjust& lc)
    {
            lc.mDx -= 45.0f;
            lc.mDy -= 23.0f;
            lc.mScale = 1.2f;
    },  // 20 ZOMBIE_BUNGEE
    &IceTrapNoAdjust,  // 21 ZOMBIE_LADDER（原 default）
    // 原 case ZOMBIE_CATAPULT
    [](Zombie& z, IceTrapAdjust& lc)
    {
            lc.mDx += 32.0f;
    },  // 22 ZOMBIE_CATAPULT
    &IceTrapAdjustCaseGargantuar,  // 23 ZOMBIE_GARGANTUAR（共体）
    &IceTrapNoAdjust,  // 24 ZOMBIE_IMP（原 default）
    &IceTrapNoAdjust,  // 25 ZOMBIE_BOSS（原 default）
    &IceTrapNoAdjust,  // 26 ZOMBIE_PEA_HEAD（原 default）
    &IceTrapNoAdjust,  // 27 ZOMBIE_WALLNUT_HEAD（原 default）
    &IceTrapNoAdjust,  // 28 ZOMBIE_JALAPENO_HEAD（原 default）
    &IceTrapNoAdjust,  // 29 ZOMBIE_GATLING_HEAD（原 default）
    &IceTrapNoAdjust,  // 30 ZOMBIE_SQUASH_HEAD（原 default）
    &IceTrapNoAdjust,  // 31 ZOMBIE_TALLNUT_HEAD（原 default）
    &IceTrapAdjustCaseGargantuar,  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
    &IceTrapNoAdjust,  // 33 ZOMBIE_ZOMBATAR（原 default）
};
static_assert(sizeof(kIceTrapAdjusts) / sizeof(kIceTrapAdjusts[0]) ==
    (int)ZombieType::NUM_ZOMBIE_TYPES, "kIceTrapAdjusts 槽位数须与 ZombieType 枚举同步");
}  // namespace

//0x52E020
__declspec(noinline) void Zombie::DrawIceTrap_B(Graphics* g, const ZombieDrawPosition& theDrawPos, bool theFront)
{
    if (mInPool || mZombieType == ZombieType::ZOMBIE_BOSS)
        return;

    float aOffsetX = 46.0f;
    float aOffsetY = theDrawPos.mBodyY + 92.0f;
    float aScale = 1.0f;
    // C 形态 -> 匿名 lambda 表：行序 = ZombieType 枚举序（0..33）；无 case
    // 槽=IceTrapNoAdjust 具名空操作（=原 default 无操作）。三浮点经
    // IceTrapAdjust 传递（读写回写）。
    IceTrapAdjust aAdjust{aOffsetX, aOffsetY, aScale, false};
    const unsigned aTypeIndex = static_cast<unsigned>(mZombieType);
    if (aTypeIndex < static_cast<unsigned>(ZombieType::NUM_ZOMBIE_TYPES))
    {
        kIceTrapAdjusts[aTypeIndex](*this, aAdjust);
    }
    aOffsetX = aAdjust.mDx;
    aOffsetY = aAdjust.mDy;
    aScale = aAdjust.mScale;


    TodDrawImageScaledF(g, theFront ? IMAGE_ICETRAP : IMAGE_ICETRAP2, aOffsetX, aOffsetY, aScale, aScale);
}

// ==================== t02 DrawButter ====================
// FormA：198fef4a^ 原 switch 逐字
__declspec(noinline) void Zombie::DrawButter_A(Graphics* g, const ZombieDrawPosition& theDrawPos)
{
    float aOffsetX = mPosX + theDrawPos.mImageOffsetX + theDrawPos.mHeadX + 11.0f;
    float aOffsetY = mPosY + theDrawPos.mImageOffsetY + theDrawPos.mHeadY + theDrawPos.mBodyY + 21.0f;
    float aScale = 1.0f;
    if (mZombiePhase == ZombiePhase::PHASE_NEWSPAPER_MADDENING)
    {
        GetTrackPosition(ReanimTrackId::anim_head_look, aOffsetX, aOffsetY);
    }
    else if (mZombieType == ZombieType::ZOMBIE_CATAPULT)
    {
        GetTrackPosition(ReanimTrackId::Zombie_catapult_driver_head, aOffsetX, aOffsetY);
    }
    else if (mBodyReanimID != ReanimationID::REANIMATIONID_NULL)
    {
        GetTrackPosition(ReanimTrackId::anim_head1, aOffsetX, aOffsetY);
    }
    aOffsetX -= mPosX + 29.0f;
    aOffsetY -= mPosY + 36.0f;

    switch (mZombieType)
    {
    case ZombieType::ZOMBIE_POGO:
        aOffsetY -= 5.0f;
        break;
    case ZombieType::ZOMBIE_GARGANTUAR:
    case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:
        aOffsetX -= 5.0f;
        aOffsetY -= 15.0f;
        aScale = 1.2f;
        break;
    case ZombieType::ZOMBIE_SQUASH_HEAD:
        aOffsetX += 6.0f;
        aOffsetY -= 9.0f;
        break;
    case ZombieType::ZOMBIE_WALLNUT_HEAD:
        aOffsetX -= 6.0f;
        aOffsetY -= 1.0f;
        break;
    case ZombieType::ZOMBIE_TALLNUT_HEAD:
        aOffsetX -= 24.0f;
        aOffsetY -= 39.0f;
        break;
    default:
        break;
    }

    TodDrawImageScaledF(g, IMAGE_REANIM_CORNPULT_BUTTER_SPLAT, aOffsetX, aOffsetY, aScale, aScale);
}

namespace
{
// Zombie::DrawButter 偏移调整表：表内匿名 lambda = 原 case 体逐句迁移
//（生成器 + 逆变换 token 对拍 0 差异）；无 case 槽不调整。
struct ButterAdjust
{
    float mDx;
    float mDy;
    float mScale;
};
using ButterAdjustFn = void (*)(Zombie&, ButterAdjust&);

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case ZOMBIE_GARGANTUAR, ZOMBIE_REDEYE_GARGANTUAR
void ButterAdjustCaseGargantuar(Zombie& z, ButterAdjust& lc)
{
            lc.mDx -= 5.0f;
            lc.mDy -= 15.0f;
            lc.mScale = 1.2f;
}

// 原 default（无 case 的 28 型（空操作）共用）
void ButterNoAdjust(Zombie& z, ButterAdjust& lc)
{

}

// 匿名 lambda 函数指针表，行序 = ZombieType 枚举值序（0..33）。
constexpr ButterAdjustFn kButterAdjusts[(int)ZombieType::NUM_ZOMBIE_TYPES] = {
    &ButterNoAdjust,  // 0 ZOMBIE_NORMAL（原 default）
    &ButterNoAdjust,  // 1 ZOMBIE_FLAG（原 default）
    &ButterNoAdjust,  // 2 ZOMBIE_TRAFFIC_CONE（原 default）
    &ButterNoAdjust,  // 3 ZOMBIE_POLEVAULTER（原 default）
    &ButterNoAdjust,  // 4 ZOMBIE_PAIL（原 default）
    &ButterNoAdjust,  // 5 ZOMBIE_NEWSPAPER（原 default）
    &ButterNoAdjust,  // 6 ZOMBIE_DOOR（原 default）
    &ButterNoAdjust,  // 7 ZOMBIE_FOOTBALL（原 default）
    &ButterNoAdjust,  // 8 ZOMBIE_DANCER（原 default）
    &ButterNoAdjust,  // 9 ZOMBIE_BACKUP_DANCER（原 default）
    &ButterNoAdjust,  // 10 ZOMBIE_DUCKY_TUBE（原 default）
    &ButterNoAdjust,  // 11 ZOMBIE_SNORKEL（原 default）
    &ButterNoAdjust,  // 12 ZOMBIE_ZAMBONI（原 default）
    &ButterNoAdjust,  // 13 ZOMBIE_BOBSLED（原 default）
    &ButterNoAdjust,  // 14 ZOMBIE_DOLPHIN_RIDER（原 default）
    &ButterNoAdjust,  // 15 ZOMBIE_JACK_IN_THE_BOX（原 default）
    &ButterNoAdjust,  // 16 ZOMBIE_BALLOON（原 default）
    &ButterNoAdjust,  // 17 ZOMBIE_DIGGER（原 default）
    // 原 case ZOMBIE_POGO
    [](Zombie& z, ButterAdjust& lc)
    {
            lc.mDy -= 5.0f;
    },  // 18 ZOMBIE_POGO
    &ButterNoAdjust,  // 19 ZOMBIE_YETI（原 default）
    &ButterNoAdjust,  // 20 ZOMBIE_BUNGEE（原 default）
    &ButterNoAdjust,  // 21 ZOMBIE_LADDER（原 default）
    &ButterNoAdjust,  // 22 ZOMBIE_CATAPULT（原 default）
    &ButterAdjustCaseGargantuar,  // 23 ZOMBIE_GARGANTUAR（共体）
    &ButterNoAdjust,  // 24 ZOMBIE_IMP（原 default）
    &ButterNoAdjust,  // 25 ZOMBIE_BOSS（原 default）
    &ButterNoAdjust,  // 26 ZOMBIE_PEA_HEAD（原 default）
    // 原 case ZOMBIE_WALLNUT_HEAD
    [](Zombie& z, ButterAdjust& lc)
    {
            lc.mDx -= 6.0f;
            lc.mDy -= 1.0f;
    },  // 27 ZOMBIE_WALLNUT_HEAD
    &ButterNoAdjust,  // 28 ZOMBIE_JALAPENO_HEAD（原 default）
    &ButterNoAdjust,  // 29 ZOMBIE_GATLING_HEAD（原 default）
    // 原 case ZOMBIE_SQUASH_HEAD
    [](Zombie& z, ButterAdjust& lc)
    {
            lc.mDx += 6.0f;
            lc.mDy -= 9.0f;
    },  // 30 ZOMBIE_SQUASH_HEAD
    // 原 case ZOMBIE_TALLNUT_HEAD
    [](Zombie& z, ButterAdjust& lc)
    {
            lc.mDx -= 24.0f;
            lc.mDy -= 39.0f;
    },  // 31 ZOMBIE_TALLNUT_HEAD
    &ButterAdjustCaseGargantuar,  // 32 ZOMBIE_REDEYE_GARGANTUAR（共体）
    &ButterNoAdjust,  // 33 ZOMBIE_ZOMBATAR（原 default）
};
static_assert(sizeof(kButterAdjusts) / sizeof(kButterAdjusts[0]) ==
    (int)ZombieType::NUM_ZOMBIE_TYPES, "kButterAdjusts 槽位数须与 ZombieType 枚举同步");
}  // namespace

//0x52E150
__declspec(noinline) void Zombie::DrawButter_B(Graphics* g, const ZombieDrawPosition& theDrawPos)
{
    float aOffsetX = mPosX + theDrawPos.mImageOffsetX + theDrawPos.mHeadX + 11.0f;
    float aOffsetY = mPosY + theDrawPos.mImageOffsetY + theDrawPos.mHeadY + theDrawPos.mBodyY + 21.0f;
    float aScale = 1.0f;
    if (mZombiePhase == ZombiePhase::PHASE_NEWSPAPER_MADDENING)
    {
        GetTrackPosition(ReanimTrackId::anim_head_look, aOffsetX, aOffsetY);
    }
    else if (mZombieType == ZombieType::ZOMBIE_CATAPULT)
    {
        GetTrackPosition(ReanimTrackId::Zombie_catapult_driver_head, aOffsetX, aOffsetY);
    }
    else if (mBodyReanimID != ReanimationID::REANIMATIONID_NULL)
    {
        GetTrackPosition(ReanimTrackId::anim_head1, aOffsetX, aOffsetY);
    }
    aOffsetX -= mPosX + 29.0f;
    aOffsetY -= mPosY + 36.0f;

    // C 形态 -> 匿名 lambda 表：行序 = ZombieType 枚举序（0..33）；无 case
    // 槽=ButterNoAdjust 具名空操作（=原 default）。
    ButterAdjust aAdjust{aOffsetX, aOffsetY, aScale};
    const unsigned aTypeIndex = static_cast<unsigned>(mZombieType);
    if (aTypeIndex < static_cast<unsigned>(ZombieType::NUM_ZOMBIE_TYPES))
    {
        kButterAdjusts[aTypeIndex](*this, aAdjust);
    }
    aOffsetX = aAdjust.mDx;
    aOffsetY = aAdjust.mDy;
    aScale = aAdjust.mScale;


    TodDrawImageScaledF(g, IMAGE_REANIM_CORNPULT_BUTTER_SPLAT, aOffsetX, aOffsetY, aScale, aScale);
}

// ==================== t03 DrawDancerReanim ====================
// FormA：f87ffc85^ 原 switch 逐字
__declspec(noinline) void Zombie::DrawDancerReanim_A(Graphics* g)
{
    Color aSpotLightColor;
    bool aDrawSpotLight = false;
    if (mZombiePhase != ZombiePhase::PHASE_DANCER_DANCING_IN && mZombiePhase != ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS &&
        mZombiePhase != ZombiePhase::PHASE_ZOMBIE_NORMAL && mZombiePhase != ZombiePhase::PHASE_ZOMBIE_DYING && mApp->mGameScene != GameScenes::SCENE_ZOMBIES_WON)
    {
        aDrawSpotLight = true;

        switch (mZombieAge >= 700 ? mZombieAge / 100 * 7 % 5 : 0)
        {
        case 0:
            aSpotLightColor = Color(250, 250, 160);
            break;
        case 1:
            aSpotLightColor = Color(114, 234, 170);
            break;
        case 2:
            aSpotLightColor = Color(216, 126, 202);
            break;
        case 3:
            aSpotLightColor = Color(90, 110, 140);
            break;
        case 4:
            aSpotLightColor = Color(240, 90, 130);
            break;
        }

        g->SetColorizeImages(true);
        g->SetColor(aSpotLightColor);
        TodDrawImageScaledF(g, IMAGE_SPOTLIGHT2, -30.0f, 60.0f, 4.0f, 4.0f);
        g->SetColorizeImages(false);
    }

    Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
    aBodyReanim->DrawRenderGroup(g, RENDER_GROUP_NORMAL);

    if (aDrawSpotLight)
    {
        g->SetColorizeImages(true);
        g->SetColor(aSpotLightColor);
        TodDrawImageScaledF(g, IMAGE_SPOTLIGHT, -30.0f, -480.0f, 4.0f, 4.0f);
        g->SetColorizeImages(false);
    }
}

namespace
{
// 舞王聚光灯颜色表（手工生成；整型直下标 0..4，与原 switch 表达式
// mZombieAge/100*7%5 的值域一一对应）
// Color 无 constexpr 构造——表为运行期初始化（一次性，静态存储）
const Color kDancerSpotlight[5] = {
    Color(250, 250, 160),  // 0
    Color(114, 234, 170),  // 1
    Color(216, 126, 202),  // 2
    Color(90, 110, 140),   // 3
    Color(240, 90, 130),   // 4
};
static_assert(sizeof(kDancerSpotlight) / sizeof(kDancerSpotlight[0]) == 5, "聚光灯表槽位");
}  // namespace

//0x52CDF0
__declspec(noinline) void Zombie::DrawDancerReanim_B(Graphics* g)
{
    Color aSpotLightColor;
    bool aDrawSpotLight = false;
    if (mZombiePhase != ZombiePhase::PHASE_DANCER_DANCING_IN && mZombiePhase != ZombiePhase::PHASE_DANCER_SNAPPING_FINGERS &&
        mZombiePhase != ZombiePhase::PHASE_ZOMBIE_NORMAL && mZombiePhase != ZombiePhase::PHASE_ZOMBIE_DYING && mApp->mGameScene != GameScenes::SCENE_ZOMBIES_WON)
    {
        aDrawSpotLight = true;

        // B 形态 -> 常量表（下方 kDancerSpotlight，整型直下标 0..4）
        aSpotLightColor = kDancerSpotlight[mZombieAge >= 700 ? mZombieAge / 100 * 7 % 5 : 0];

        g->SetColorizeImages(true);
        g->SetColor(aSpotLightColor);
        TodDrawImageScaledF(g, IMAGE_SPOTLIGHT2, -30.0f, 60.0f, 4.0f, 4.0f);
        g->SetColorizeImages(false);
    }

    Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
    aBodyReanim->DrawRenderGroup(g, RENDER_GROUP_NORMAL);

    if (aDrawSpotLight)
    {
        g->SetColorizeImages(true);
        g->SetColor(aSpotLightColor);
        TodDrawImageScaledF(g, IMAGE_SPOTLIGHT, -30.0f, -480.0f, 4.0f, 4.0f);
        g->SetColorizeImages(false);
    }
}

// ==================== t04 SetupDrawZombieWon ====================
// FormA：f87ffc85^ 原 switch 逐字
__declspec(noinline) bool Zombie::SetupDrawZombieWon_A(Graphics* g)
{
    if (mFromWave != Zombie::ZOMBIE_WAVE_WINNER)
        return true;

    if (!mBoard->mCutScene->ShowZombieWalking())
        return false;

    switch (mBoard->mBackground)
    {
    case BackgroundType::BACKGROUND_1_DAY:
    case BackgroundType::BACKGROUND_2_NIGHT:
        g->ClipRect(-123 - mX, -mY, BOARD_WIDTH, BOARD_HEIGHT);
        break;
    case BackgroundType::BACKGROUND_3_POOL:
    case BackgroundType::BACKGROUND_4_FOG:
        g->ClipRect(-172 - mX, -mY, BOARD_WIDTH, BOARD_HEIGHT);
        break;
    case BackgroundType::BACKGROUND_5_ROOF:
    case BackgroundType::BACKGROUND_6_BOSS:
        g->ClipRect(-220 - mX, -mY, BOARD_WIDTH, 187);
        break;
    default:
        break;
    }

    return true;
}

namespace
{
// 胜利剪裁表（手工生成；0 = 无 case 背景不剪裁=原 default；-220 行高度用
// 187（ROOF/BOSS），其余 BOARD_HEIGHT）
constexpr int kZombiesWonClip[7] = {
    -123,  // 0 BACKGROUND_1_DAY
    -123,  // 1 BACKGROUND_2_NIGHT
    -172,  // 2 BACKGROUND_3_POOL
    -172,  // 3 BACKGROUND_4_FOG
    -220,  // 4 BACKGROUND_5_ROOF
    -220,  // 5 BACKGROUND_6_BOSS
    0,     // 6 MUSHROOM_GARDEN（原 default）
};
static_assert(sizeof(kZombiesWonClip) / sizeof(kZombiesWonClip[0]) == 7 &&
    kZombiesWonClip[0] == -123 && kZombiesWonClip[5] == -220, "胜利剪裁表锚点");
}  // namespace

//0x534040
__declspec(noinline) bool Zombie::SetupDrawZombieWon_B(Graphics* g)
{
    if (mFromWave != Zombie::ZOMBIE_WAVE_WINNER)
        return true;

    if (!mBoard->mCutScene->ShowZombieWalking())
        return false;

    // B 形态 -> 常量表（下方 kZombiesWonClip，BackgroundType 直下标 0..6；
    // 无 case 背景 = 0 不剪裁 = 原 default）
    if (static_cast<unsigned>(mBoard->mBackground) < 7 && kZombiesWonClip[(int)mBoard->mBackground] != 0)
    {
        const int aClipX = kZombiesWonClip[(int)mBoard->mBackground];
        g->ClipRect(aClipX - mX, -mY, BOARD_WIDTH, aClipX == -220 ? 187 : BOARD_HEIGHT);
    }

    return true;
}

// ============================ main ============================
static Zombie g_z;
static Board g_board;
static LawnApp g_app;
static CutScene g_cut;
static Graphics g_gfx;

static void ResetZombie(const R3Input& in)
{
    g_z.mApp = &g_app;
    g_z.mBoard = &g_board;
    g_app.mBoard = &g_board;
    g_board.mApp = &g_app;
    g_board.mCutScene = &g_cut;
    g_z.mZombieType = (ZombieType)(in.a % (int)ZombieType::NUM_ZOMBIE_TYPES);
    g_z.mZombiePhase = (ZombiePhase)(in.b % 40);
    g_z.mZombieAge = (int)(in.c % 3000);
    g_z.mInPool = (in.b % 5 == 0);
    g_z.mPosX = (float)(in.c % 700);
    g_z.mPosY = (float)(in.d % 500);
    g_z.mVelX = 0.25f;
    g_z.mFromWave = (in.a % 4 == 0) ? Zombie::ZOMBIE_WAVE_WINNER : (int)(in.a % 20) - 6;
    g_z.mBodyReanimID = (ReanimationID)(1 + in.b % 2);
    g_z.mX = (int)(in.c % 600);
    g_z.mY = (int)(in.d % 400);
    g_board.mBackground = (BackgroundType)(in.d % 7);
}

int main()
{
    int rc = 0;
    {
        ZombieDrawPosition dp; dp.mBodyY = 12.0f;
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                g_z.DrawIceTrap_A(&g_gfx, dp, (i & 1) != 0);
                g_z.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                g_z.DrawIceTrap_B(&g_gfx, dp, (i & 1) != 0);
                g_z.HashFold(ck);
            }
        };
        rc |= R3BenchMain("t01_DrawIceTrap_kIceTrapAdjusts", reset, pa, pb);
    }
    {
        ZombieDrawPosition dp; dp.mImageOffsetX = 3.0f; dp.mImageOffsetY = 4.0f; dp.mHeadX = 5.0f; dp.mHeadY = 6.0f; dp.mBodyY = 7.0f;
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                g_z.DrawButter_A(&g_gfx, dp);
                g_z.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                g_z.DrawButter_B(&g_gfx, dp);
                g_z.HashFold(ck);
            }
        };
        rc |= R3BenchMain("t02_DrawButter_kButterAdjusts", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                g_z.DrawDancerReanim_A(&g_gfx);
                g_z.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                g_z.DrawDancerReanim_B(&g_gfx);
                g_z.HashFold(ck);
            }
        };
        rc |= R3BenchMain("t03_DrawDancerReanim_kDancerSpotlight", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                bool r = g_z.SetupDrawZombieWon_A(&g_gfx);
                g_z.HashFold(ck);
                ck = ZBMixU64(ck, r ? 1 : 0);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetZombie(g_inputs[i]);
                bool r = g_z.SetupDrawZombieWon_B(&g_gfx);
                g_z.HashFold(ck);
                ck = ZBMixU64(ck, r ? 1 : 0);
            }
        };
        rc |= R3BenchMain("t04_SetupDrawZombieWon_kZombiesWonClip", reset, pa, pb);
    }
    return rc;
}
