
void __thiscall FUN_0052e710(int param_1,CMFCCaptionButtonEx *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  CRect *pCVar5;
  int iVar6;
  undefined4 local_150;
  int local_14c;
  int local_148;
  int local_144;
  int local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined4 local_134;
  undefined1 local_130 [140];
  undefined1 local_a4 [144];
  void *local_14;
  undefined1 *puStack_10;
  undefined4 local_c;
  
  local_c = 0xffffffff;
  puStack_10 = &LAB_006c80a2;
  local_14 = ExceptionList;
  ExceptionList = &local_14;
  uVar1 = FUN_0059abc0();
  uVar2 = FUN_0059aba0();
  iVar4 = *(int *)(*(int *)(param_1 + 0xa0) + 0xc4);
  iVar6 = *(int *)(param_1 + 0xe8);
  *(undefined4 *)(iVar6 + 8) = 0x28;
  *(int *)(iVar6 + 0xc) = iVar4 + -0x99;
  *(undefined4 *)(iVar6 + 0x10) = uVar2;
  *(undefined4 *)(iVar6 + 0x14) = uVar1;
  if (*(char *)(param_1 + 0xf6e) == '\x01') {
    FUN_00531680(param_1);
    FUN_005313f0();
    *(undefined1 *)(param_1 + 0xf6e) = 0;
  }
  FUN_00598a60(DAT_00726f0c,0,0);
  switch(*(undefined4 *)(param_1 + 0xf5c)) {
  case 0:
    FUN_0052fe90(param_1);
    FUN_0044aac0(*(undefined4 *)(param_1 + 0xd4));
    if (*(char *)(*(int *)(param_1 + 0xe8) + 0x1a) == '\0') {
      FUN_0044aac0(*(int *)(param_1 + 0xe8));
    }
    break;
  case 1:
    FUN_0052fe90(param_1);
    uVar1 = FUN_0051bea0(0,0xff,1);
    goto LAB_0052e818;
  case 2:
    FUN_0052fe90(param_1);
    uVar1 = FUN_0051bea0(0xff,0,1);
LAB_0052e818:
    pCVar5 = (CRect *)FUN_005615d0(0,0,0,uVar1);
    CMFCCaptionButtonEx::SetRect(param_2,pCVar5);
    FUN_00598460(0x21,100,*(int *)(param_1 + 0x48) + -0x3f,*(int *)(param_1 + 0x4c) + -0x10d);
    FUN_0044aac0(*(undefined4 *)(param_1 + 0xd4));
    break;
  case 3:
    FUN_004021f0("[ZOMBATAR_FINISHED_WARNING_HEADER]");
    local_c = 0;
    puVar3 = (undefined4 *)FUN_00561590(0xfe,0xe3,0);
    FUN_0051bf40(param_2,0xa0,2,*puVar3,puVar3[1],puVar3[2],puVar3[3]);
    local_c = 0xffffffff;
    FUN_00401b00();
    local_140 = *(int *)(param_1 + 0x48) / 2 + -0xf5;
    local_13c = 200;
    local_138 = 500;
    local_134 = 100;
    FUN_004021f0("[ZOMBATAR_FINISHED_WARNING_TEXT]");
    uVar1 = 2;
    local_c = 1;
    FUN_00561590(0xff,0xff,0xff);
    FUN_005246a0(param_2,DAT_00726804,uVar1);
    local_c = 0xffffffff;
    FUN_00401b00();
    FUN_004021f0("[ZOMBATAR_FINISHED_BUTTON_TEXT]");
    local_c = 2;
    puVar3 = (undefined4 *)FUN_00561590(0xff,0xff,0xff);
    FUN_0051bf40(param_2,0x136,2,*puVar3,puVar3[1],puVar3[2],puVar3[3]);
    local_c = 0xffffffff;
    FUN_00401b00();
    FUN_004021f0("[ZOMBATAR_BACK_BUTTON_TEXT]");
    local_c = 3;
    puVar3 = (undefined4 *)FUN_00561590(0xff,0xff,0xff);
    FUN_0051bf40(param_2,0x136,2,*puVar3,puVar3[1],puVar3[2],puVar3[3]);
    local_c = 0xffffffff;
    FUN_00401b00();
    FUN_0044aac0(*(undefined4 *)(param_1 + 0xd0));
    FUN_0044aac0(*(undefined4 *)(param_1 + 0xd4));
    break;
  case 4:
    if (*(char *)(*(int *)(param_1 + 0xd4) + 0x1a) == '\0') {
      FUN_0044aac0(*(int *)(param_1 + 0xd4));
    }
    FUN_005993f0(0x21,100,*(int *)(param_1 + 0x48) + -0x3f,*(int *)(param_1 + 0x4c) + -0xa3);
    FUN_00598460(0x21,100,*(int *)(param_1 + 0x48) + -0x3f,*(int *)(param_1 + 0x4c) + -0x10d);
    *(undefined4 *)(param_1 + 0xf68) = 0x28;
    iVar4 = *(int *)(*(int *)(param_1 + 0xa0) + 0x94c);
    if ((iVar4 != 0) && (0 < *(int *)(iVar4 + 0x4840))) {
      local_150 = 0x96;
      iVar4 = FUN_0059aba0();
      iVar6 = ((*(int *)(param_1 + 0x48) + -0x1e) / 2 + *(int *)(param_1 + 0xf68) / 2) - iVar4 / 2;
      local_144 = iVar6;
      local_14c = FUN_0059aba0();
      local_14c = (iVar6 - *(int *)(param_1 + 0xf68)) - local_14c;
      iVar4 = FUN_0059aba0();
      local_148 = iVar4 + *(int *)(param_1 + 0xf68) + iVar6;
      FUN_00530970(param_2,*(int *)(*(int *)(param_1 + 0xa0) + 0x94c) + 0x4844 +
                           *(int *)(param_1 + 0xf64) * 0x48,&local_144,&local_150);
      iVar4 = *(int *)(*(int *)(param_1 + 0xa0) + 0x94c);
      if (*(int *)(param_1 + 0xf64) < *(int *)(iVar4 + 0x4840) + -1) {
        FUN_00530970(param_2,iVar4 + 0x488c + *(int *)(param_1 + 0xf64) * 0x48,&local_148,&local_150
                    );
      }
      if (0 < *(int *)(param_1 + 0xf64)) {
        FUN_00530970(param_2,*(int *)(*(int *)(param_1 + 0xa0) + 0x94c) + 0x47fc +
                             *(int *)(param_1 + 0xf64) * 0x48,&local_14c,&local_150);
      }
    }
    FUN_005993a0();
    if (*(char *)(*(int *)(param_1 + 0xdc) + 0x1a) == '\0') {
      FUN_0044aac0(*(int *)(param_1 + 0xdc));
    }
    if (*(char *)(*(int *)(param_1 + 0xe0) + 0x1a) == '\0') {
      FUN_0044aac0(*(int *)(param_1 + 0xe0));
    }
    if (*(char *)(*(int *)(param_1 + 0xd8) + 0x1a) == '\0') {
      FUN_0044aac0(*(int *)(param_1 + 0xd8));
    }
    FUN_00598330(DAT_00726e60);
    CMFCCaptionButtonEx::SetRect(param_2,(CRect *)&DAT_007a23e0);
    if (*(int *)(*(int *)(param_1 + 0xa0) + 0x94c) != 0) {
      FUN_00600ff0(local_130,"%d / %d",*(int *)(param_1 + 0xf64) + 1,
                   *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xa0) + 0x94c) + 0x4840));
      local_c = 4;
      iVar6 = *(int *)(param_1 + 0xa4);
      iVar4 = (*(int *)(*(int *)(param_1 + 0xa8) + 8) - *(int *)(iVar6 + 8)) / 2 + -0x73 +
              *(int *)(iVar6 + 8);
      local_14c = *(int *)(iVar6 + 0x14) / 2 + -0xe6 + *(int *)(iVar6 + 0xc);
      FUN_00598a10(local_130,iVar4,local_14c);
      FUN_00598330(DAT_00726be8);
      if (*(char *)(param_1 + 0xf6f) == '\0') {
        pCVar5 = (CRect *)&DAT_007a23e0;
      }
      else {
        pCVar5 = (CRect *)FUN_00561590(0x16,0xfd,5);
      }
      CMFCCaptionButtonEx::SetRect(param_2,pCVar5);
      FUN_004021f0("Delete?");
      local_c = CONCAT31(local_c._1_3_,5);
      FUN_00598a10(local_a4,iVar4 + 0x82,local_14c);
      FUN_00401b00();
      local_c = 0xffffffff;
      FUN_00401b00();
    }
  }
  FUN_0044aac0(*(undefined4 *)(param_1 + 0xe4));
  ExceptionList = local_14;
  return;
}

