// bench_cold_events.cpp -- 目标3  kTitleQuickLoadRows(7)   TitleScreen::Update 快捷键段（按键，冷）
//                          目标23 kChooserButtonCases(4)    SeedChooserScreen::ButtonDepress（事件，冷）
//                          目标24 kZenToolRows(3)           ZenGarden::MouseDownWithFeedingTool（事件，冷）
//                          目标25 kFeedingCases(4)          ZenGarden::DoFeedingTool（事件，冷）
// FormA = 36a066a7^ / 403c1968^ 逐字；FormB = HEAD 逐字。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_cs;
static inline void CS(uint64_t v) { g_cs = g_cs * 1315423911ULL + v; }
struct LCG { uint64_t s; uint64_t nx() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return s >> 33; } };
static double NowSec() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
template <class F> double TimeMin5(F&& f) { double best = 1e300; for (int i = 0; i < 5; i++) { double t0 = NowSec(); f(); double t = NowSec() - t0; if (t < best) best = t; } return best; }

// ---------------- t3 TitleScreen::Update 快捷键段 ----------------
typedef int KeyCode;
static const KeyCode KEYCODE_UNKNOWN = 0, KEYCODE_ASCIIEND = 0x5A;
struct TitleAppStub {
    bool mTodCheatKeys;
    void* mPlayerInfo;
    void FastLoad(int mode) { CS(200); CS((uint64_t)mode); }
    void LoadingCompleted() { CS(201); }
    void KillGameSelector() { CS(202); }
    void ShowChallengeScreen(int page) { CS(203); CS((uint64_t)page); }
    void PreNewGame(int mode, bool restart) { CS(204); CS((uint64_t)mode); }
    void ShowCreditScreen() { CS(205); }
};
struct TitleScreenStub {
    TitleAppStub* mApp;
    KeyCode mQuickLoadKey;
    bool mLoadingThreadComplete = false, mStartButtonVisible = false;
    void SetStartVisible() { CS(206); mStartButtonVisible = true; }
};
enum ChallengePageT { CHALLENGE_PAGE_CHALLENGE = 0, CHALLENGE_PAGE_PUZZLE, CHALLENGE_PAGE_SURVIVAL };
enum GameModeT { GAMEMODE_INTRO = 1, GAMEMODE_CHALLENGE_ZEN_GARDEN = 2, GAMEMODE_ADVENTURE = 3 };

namespace FormA {
namespace {
void TitleQuickLoadChallengePage(TitleAppStub* theApp, ChallengePageT thePage)
{
    theApp->LoadingCompleted();
    theApp->KillGameSelector();
    theApp->ShowChallengeScreen(thePage);
}
} // namespace
__declspec(noinline) void UpdateQuickLoad(TitleScreenStub& s)
{
    if (!s.mLoadingThreadComplete)
    {
        s.mLoadingThreadComplete = true;

        if (s.mQuickLoadKey == KEYCODE_ASCIIEND)
        {
            s.mApp->FastLoad(GAMEMODE_CHALLENGE_ZEN_GARDEN);
        }
        else if (s.mQuickLoadKey == (KeyCode)0x4D)
        {
            s.mApp->LoadingCompleted();
        }
        else if (s.mQuickLoadKey == (KeyCode)0x53)
        {
            TitleQuickLoadChallengePage(s.mApp, CHALLENGE_PAGE_SURVIVAL);
        }
        else if (s.mQuickLoadKey == (KeyCode)0x43)
        {
            TitleQuickLoadChallengePage(s.mApp, CHALLENGE_PAGE_CHALLENGE);
        }
        else if (s.mQuickLoadKey == (KeyCode)0x49)
        {
            s.mApp->LoadingCompleted();
            s.mApp->KillGameSelector();
            s.mApp->PreNewGame(GAMEMODE_INTRO, false);
        }
        else if (s.mQuickLoadKey == (KeyCode)0x50)
        {
            TitleQuickLoadChallengePage(s.mApp, CHALLENGE_PAGE_PUZZLE);
        }
        else if (s.mQuickLoadKey == (KeyCode)0x52)
        {
            s.mApp->LoadingCompleted();
            s.mApp->KillGameSelector();
            s.mApp->ShowCreditScreen();
        }
        else if (s.mApp->mTodCheatKeys && s.mApp->mPlayerInfo && s.mQuickLoadKey == (KeyCode)0x54)
        {
            s.mApp->FastLoad(GAMEMODE_ADVENTURE);
        }
        else
        {
            s.SetStartVisible();
        }
    }
}
} // namespace FormA

namespace FormB {
namespace {
using TitleQuickLoadFn = void (*)(TitleAppStub*);
void TitleQuickLoadChallengePage(TitleAppStub* theApp, ChallengePageT thePage)
{
    theApp->LoadingCompleted();
    theApp->KillGameSelector();
    theApp->ShowChallengeScreen(thePage);
}
constexpr struct { KeyCode mKey; TitleQuickLoadFn mAction; } kTitleQuickLoadRows[] = {
    { (KeyCode)0x43, [](TitleAppStub* theApp) { TitleQuickLoadChallengePage(theApp, CHALLENGE_PAGE_CHALLENGE); } },
    { (KeyCode)0x49, [](TitleAppStub* theApp) { theApp->LoadingCompleted(); theApp->KillGameSelector(); theApp->PreNewGame(GAMEMODE_INTRO, false); } },
    { (KeyCode)0x4D, [](TitleAppStub* theApp) { theApp->LoadingCompleted(); } },
    { (KeyCode)0x50, [](TitleAppStub* theApp) { TitleQuickLoadChallengePage(theApp, CHALLENGE_PAGE_PUZZLE); } },
    { (KeyCode)0x52, [](TitleAppStub* theApp) { theApp->LoadingCompleted(); theApp->KillGameSelector(); theApp->ShowCreditScreen(); } },
    { (KeyCode)0x53, [](TitleAppStub* theApp) { TitleQuickLoadChallengePage(theApp, CHALLENGE_PAGE_SURVIVAL); } },
    { KEYCODE_ASCIIEND, [](TitleAppStub* theApp) { theApp->FastLoad(GAMEMODE_CHALLENGE_ZEN_GARDEN); } },
};
} // namespace
__declspec(noinline) void UpdateQuickLoad(TitleScreenStub& s)
{
    if (!s.mLoadingThreadComplete)
    {
        s.mLoadingThreadComplete = true;

        // C 形态 -> lambda 表 kTitleQuickLoadRows：键配对扫描，命中即执行
        TitleQuickLoadFn aQuickLoad = nullptr;
        for (const auto& aRow : kTitleQuickLoadRows)
        {
            if (aRow.mKey == s.mQuickLoadKey)
            {
                aQuickLoad = aRow.mAction;
                break;
            }
        }

        if (aQuickLoad != nullptr)
        {
            aQuickLoad(s.mApp);
        }
        else if (s.mApp->mTodCheatKeys && s.mApp->mPlayerInfo && s.mQuickLoadKey == (KeyCode)0x54)
        {
            s.mApp->FastLoad(GAMEMODE_ADVENTURE);
        }
        else
        {
            s.SetStartVisible();
        }
    }
}
} // namespace FormB

// ---------------- t23 SeedChooserScreen::ButtonDepress ----------------
enum ChooserBtn { SC_ViewLawn = 102, SC_Almanac, SC_Menu, SC_Store, SC_Start, SC_Random };
static bool g_sessionCurrent; // ChooserModalSession::IsCurrent 输入驱动
struct ModalSessionStub { bool IsCurrent() { return g_sessionCurrent; } };
struct ChooserAppStub {
    bool mGoToTreeNow;
    void* DoAlmanacDialog() { CS(210); return nullptr; }
    void WaitForResultAlmanac(bool) { CS(211); }
    void MakeSureMusicIsPlaying(int t) { CS(212); CS((uint64_t)t); }
    void DoNewOptions(bool) { CS(213); }
    void* ShowStoreScreen() { CS(214); return nullptr; }
    void KillBoard() { CS(215); }
    void PreNewGame(int mode, bool r) { CS(216); CS((uint64_t)mode); }
    int GetSeedsAvailable() { return g_seedsAvail; }
    static int g_seedsAvail;
};
int ChooserAppStub::g_seedsAvail = 0;
struct ChooserMenuButton { bool mDisabled, mIsOver, mIsDown; void SetLabel(const char* s) { CS(217); CS((uint64_t)s[0]); } };
static ChooserMenuButton g_menuBtn, g_backBtn;
struct SeedBankStub2 { int mNumPackets; };
static SeedBankStub2 g_seedBank;
struct ChooserScreenStub {
    ChooserAppStub* mApp;
    ChooserMenuButton* mMenuButton;
    void* mBoard;
    int mSeedsInFlight, mChooseState, mMouseVisible;
    void UpdateCursor() { CS(218); }
    void OnStartButton() { CS(219); }
    void PickRandomSeeds() { CS(220); }
};

namespace FormA {
__declspec(noinline) void ButtonDepress(ChooserScreenStub& s, int theId)
{
    ModalSessionStub aSession;
    if (!aSession.IsCurrent())
        return;
    if (s.mSeedsInFlight > 0 || s.mChooseState == 1 /* CHOOSE_VIEW_LAWN */ || !s.mMouseVisible)
        return;

    if (theId == SC_ViewLawn)
    {
        s.mChooseState = 1;
        s.mMenuButton->mDisabled = true;
        CS(221); // mViewLawnTime = 0
    }
    else if (theId == SC_Almanac)
    {
        s.mApp->DoAlmanacDialog();
        s.mApp->WaitForResultAlmanac(true);
        if (!aSession.IsCurrent())
            return;
        s.mApp->MakeSureMusicIsPlaying(1);
    }
    else if (theId == SC_Store)
    {
        s.mApp->ShowStoreScreen();
        g_backBtn.SetLabel("STORE_BACK_TO_GAME");
        CS(222); // aStore->WaitForResult()
        if (!aSession.IsCurrent())
            return;
        if (s.mApp->mGoToTreeNow)
        {
            s.mApp->KillBoard();
            s.mApp->PreNewGame(52, false);
        }
        else s.mApp->MakeSureMusicIsPlaying(1);
    }
    else if (theId == SC_Menu)
    {
        s.mMenuButton->mIsOver = false;
        s.mMenuButton->mIsDown = false;
        s.UpdateCursor();
        s.mApp->DoNewOptions(false);
    }
    else if (s.mApp->GetSeedsAvailable() >= g_seedBank.mNumPackets)
    {
        if (theId == SC_Start)
            s.OnStartButton();
        else if (theId == SC_Random)
            s.PickRandomSeeds();
    }
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void ButtonDepress(ChooserScreenStub& s, int theId)
{
    ModalSessionStub aSession;
    if (!aSession.IsCurrent())
        return;
    if (s.mSeedsInFlight > 0 || s.mChooseState == 1 || !s.mMouseVisible)
        return;

    // C 形态 -> 成员函数内匿名 lambda 表 kChooserButtonCases（102..105）
    using SeedChooserBtnFn = bool (*)(ChooserScreenStub&, ModalSessionStub&);
    constexpr SeedChooserBtnFn kChooserButtonCases[SC_Store - SC_ViewLawn + 1] = {
        [](ChooserScreenStub& s, ModalSessionStub& aSession) -> bool
        {
            s.mChooseState = 1;
            s.mMenuButton->mDisabled = true;
            CS(221);
            return true;
        },
        [](ChooserScreenStub& s, ModalSessionStub& aSession) -> bool
        {
            s.mApp->DoAlmanacDialog();
            s.mApp->WaitForResultAlmanac(true);
            if (!aSession.IsCurrent())
                return false;
            s.mApp->MakeSureMusicIsPlaying(1);
            return true;
        },
        [](ChooserScreenStub& s, ModalSessionStub&) -> bool
        {
            s.mMenuButton->mIsOver = false;
            s.mMenuButton->mIsDown = false;
            s.UpdateCursor();
            s.mApp->DoNewOptions(false);
            return true;
        },
        [](ChooserScreenStub& s, ModalSessionStub& aSession) -> bool
        {
            s.mApp->ShowStoreScreen();
            g_backBtn.SetLabel("STORE_BACK_TO_GAME");
            CS(222);
            if (!aSession.IsCurrent())
                return false;
            if (s.mApp->mGoToTreeNow)
            {
                s.mApp->KillBoard();
                s.mApp->PreNewGame(52, false);
            }
            else s.mApp->MakeSureMusicIsPlaying(1);
            return true;
        },
    };

    const int aButtonIndex = theId - (int)SC_ViewLawn;
    if ((unsigned)aButtonIndex < sizeof(kChooserButtonCases) / sizeof(kChooserButtonCases[0]))
    {
        if (!kChooserButtonCases[aButtonIndex](s, aSession))
            return;
    }
    else if (s.mApp->GetSeedsAvailable() >= g_seedBank.mNumPackets)
    {
        if (theId == SC_Start)
            s.OnStartButton();
        else if (theId == SC_Random)
            s.PickRandomSeeds();
    }
}
} // namespace FormB

// ---------------- t24 ZenGarden::MouseDownWithFeedingTool ----------------
enum CursorTypeZ { CURSOR_TYPE_WATERING_CAN = 9, CURSOR_TYPE_FERTILIZER = 10, CURSOR_TYPE_BUG_SPRAY = 11, CURSOR_TYPE_PHONOGRAPH = 12, CURSOR_TYPE_CHOCOLATE = 13 };
enum GridItemStateZ { GIS_ZEN_TOOL_NONE = 0, GIS_ZEN_TOOL_GOLD_WATERING_CAN, GIS_ZEN_TOOL_WATERING_CAN,
    GIS_ZEN_TOOL_FERTILIZER, GIS_ZEN_TOOL_BUG_SPRAY, GIS_ZEN_TOOL_PHONOGRAPH };
enum GridItemTypeZ { GRIDITEM_ZEN_TOOL = 1 };
enum ReanimTypeZ { REANIM_ZENGARDEN_WATERINGCAN = 1, REANIM_ZENGARDEN_FERTILIZER, REANIM_ZENGARDEN_BUGSPRAY, REANIM_ZENGARDEN_PHONOGRAPH };
enum FoleyZ { FOLEY_WATERING = 1, FOLEY_FERTILIZER, FOLEY_BUGSPRAY, FOLEY_PHONOGRAPH, FOLEY_WAKEUP };
enum ParticleZ { PARTICLE_PRESENT_PICKUP = 1 };
static const int PURCHASE_COUNT_OFFSET_Z = 100;

struct ReanimationZ {
    float mAnimRate; int mLoopType;
    void PlayReanim(int track, int loop, float shade, float rate) { CS(230); CS((uint64_t)track); CS((uint64_t)loop); }
};
static ReanimationZ g_reanimZ;
struct GridItemZ {
    int mGridItemType; int mGridX, mGridY; int mPosX, mPosY; int mRenderOrder;
    int mGridItemState; int mGridItemReanimID;
    bool mHighlighted;
    float mStinkyX, mStinkyY; int mStinkyRenderOrder;
};
static GridItemZ g_gridItems[4];
static int g_gridItemCount;
struct PlantZ { bool mHighlighted; int mPottedPlantIndex; int mPlantCol; int mRow; int mX, mY; };
static PlantZ g_plant;
struct ZenAppStub {
    int mPurchases[32];
    ZenAppStub() { for (int i = 0; i < 32; i++) mPurchases[i] = 0; }
    ReanimationZ* AddReanimation(float x, float y, int layer, ReanimTypeZ type) { CS(231); CS((uint64_t)type); CS((uint64_t)(int64_t)x); return &g_reanimZ; }
    int ReanimationGetID(ReanimationZ* r) { CS(232); return 1; }
    void AddTodParticle(float x, float y, int layer, ParticleZ p) { CS(233); CS((uint64_t)p); CS((uint64_t)(int64_t)x); }
    void PlayFoley(FoleyZ f) { CS(234); CS((uint64_t)f); }
    void PlaySample(int s) { CS(235); CS((uint64_t)s); }
};
struct ZenBoardStub {
    GridItemZ* mGridItems; int* mGridItemCount;
    PlantZ* IterateFindHighlighted() { return g_hasHighlightedPlant ? &g_plant : nullptr; }
    GridItemZ* DataArrayAlloc() { CS(236); GridItemZ* gi = &mGridItems[0]; gi->mGridItemType = 0; return gi; }
    void ClearCursor() { CS(237); }
    static bool g_hasHighlightedPlant;
    static GridItemZ* g_stinky;
};
bool ZenBoardStub::g_hasHighlightedPlant = false;
GridItemZ* ZenBoardStub::g_stinky = nullptr;
struct ZenGardenStub {
    ZenAppStub* mApp;
    ZenBoardStub* mBoard;
    void WakeStinky() { CS(238); }
    void FeedChocolateToPlant(PlantZ*) { CS(239); }
};

namespace FormA {
__declspec(noinline) void MouseDownWithFeedingTool(ZenGardenStub& s, int x, int y, CursorTypeZ theCursorType)
{
    PlantZ* aPlantToFeed = s.mBoard->IterateFindHighlighted();

    if (theCursorType == CURSOR_TYPE_CHOCOLATE)
    {
        GridItemZ* aStinky = ZenBoardStub::g_stinky;
        if (aStinky && aStinky->mHighlighted)
        {
            s.WakeStinky();
            s.mApp->AddTodParticle(aStinky->mStinkyX + 40.0f, aStinky->mStinkyY + 40.0f, aStinky->mStinkyRenderOrder + 1, PARTICLE_PRESENT_PICKUP);
            s.mApp->mPurchases[26]--; // STORE_ITEM_CHOCOLATE
            s.mApp->PlayFoley(FOLEY_WAKEUP);
            s.mApp->PlaySample(3);
        }

        if (aPlantToFeed)
        {
            s.mApp->mPurchases[26]--;
            s.FeedChocolateToPlant(aPlantToFeed);
            s.mApp->PlayFoley(FOLEY_WAKEUP);
        }
    }

    if (aPlantToFeed)
    {
        GridItemZ* aZenTool = s.mBoard->DataArrayAlloc();
        aZenTool->mGridItemType = GRIDITEM_ZEN_TOOL;
        aZenTool->mGridX = aPlantToFeed->mPlantCol;
        aZenTool->mGridY = aPlantToFeed->mRow;
        aZenTool->mPosX = aPlantToFeed->mX + 40;
        aZenTool->mPosY = aPlantToFeed->mY + 40;
        aZenTool->mRenderOrder = 900;

        if (theCursorType == CURSOR_TYPE_WATERING_CAN)
        {
            if (s.mApp->mPurchases[13]) // STORE_ITEM_GOLD_WATERINGCAN
            {
                aZenTool->mPosX = x;
                aZenTool->mPosY = y;
                ReanimationZ* w = s.mApp->AddReanimation((float)x, (float)y, 0, REANIM_ZENGARDEN_WATERINGCAN);
                w->PlayReanim(2, 2, 0, 8.0f);
                aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
                aZenTool->mGridItemState = GIS_ZEN_TOOL_GOLD_WATERING_CAN;
                s.mApp->PlayFoley(FOLEY_WATERING);
            }
            else
            {
                ReanimationZ* w = s.mApp->AddReanimation(aPlantToFeed->mX + 32.0f, (float)aPlantToFeed->mY, 0, REANIM_ZENGARDEN_WATERINGCAN);
                w->PlayReanim(1, 2, 0, 0.0f);
                aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
                aZenTool->mGridItemState = GIS_ZEN_TOOL_WATERING_CAN;
                s.mApp->PlayFoley(FOLEY_WATERING);
            }
        }
        else if (theCursorType == CURSOR_TYPE_FERTILIZER)
        {
            ReanimationZ* w = s.mApp->AddReanimation((float)aPlantToFeed->mX, (float)aPlantToFeed->mY, 0, REANIM_ZENGARDEN_FERTILIZER);
            w->mLoopType = 2;
            aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
            aZenTool->mGridItemState = GIS_ZEN_TOOL_FERTILIZER;
            s.mApp->PlayFoley(FOLEY_FERTILIZER);

            s.mApp->mPurchases[14]--; // STORE_ITEM_FERTILIZER
        }
        else if (theCursorType == CURSOR_TYPE_BUG_SPRAY)
        {
            ReanimationZ* w = s.mApp->AddReanimation(aPlantToFeed->mX + 54.0f, (float)aPlantToFeed->mY, 0, REANIM_ZENGARDEN_BUGSPRAY);
            w->mLoopType = 2;
            aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
            aZenTool->mGridItemState = GIS_ZEN_TOOL_BUG_SPRAY;
            s.mApp->PlayFoley(FOLEY_BUGSPRAY);

            s.mApp->mPurchases[15]--; // STORE_ITEM_BUG_SPRAY
        }
        else if (theCursorType == CURSOR_TYPE_PHONOGRAPH)
        {
            ReanimationZ* w = s.mApp->AddReanimation(aPlantToFeed->mX + 20.0f, aPlantToFeed->mY + 34.0f, 0, REANIM_ZENGARDEN_PHONOGRAPH);
            w->mAnimRate = 20.0f;
            w->mLoopType = 1;
            aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
            aZenTool->mGridItemState = GIS_ZEN_TOOL_PHONOGRAPH;
            s.mApp->PlayFoley(FOLEY_PHONOGRAPH);
        }
    }

    s.mBoard->ClearCursor();
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void MouseDownWithFeedingTool(ZenGardenStub& s, int x, int y, CursorTypeZ theCursorType)
{
    PlantZ* aPlantToFeed = s.mBoard->IterateFindHighlighted();

    if (theCursorType == CURSOR_TYPE_CHOCOLATE)
    {
        GridItemZ* aStinky = ZenBoardStub::g_stinky;
        if (aStinky && aStinky->mHighlighted)
        {
            s.WakeStinky();
            s.mApp->AddTodParticle(aStinky->mStinkyX + 40.0f, aStinky->mStinkyY + 40.0f, aStinky->mStinkyRenderOrder + 1, PARTICLE_PRESENT_PICKUP);
            s.mApp->mPurchases[26]--;
            s.mApp->PlayFoley(FOLEY_WAKEUP);
            s.mApp->PlaySample(3);
        }

        if (aPlantToFeed)
        {
            s.mApp->mPurchases[26]--;
            s.FeedChocolateToPlant(aPlantToFeed);
            s.mApp->PlayFoley(FOLEY_WAKEUP);
        }
    }

    if (aPlantToFeed)
    {
        GridItemZ* aZenTool = s.mBoard->DataArrayAlloc();
        aZenTool->mGridItemType = GRIDITEM_ZEN_TOOL;
        aZenTool->mGridX = aPlantToFeed->mPlantCol;
        aZenTool->mGridY = aPlantToFeed->mRow;
        aZenTool->mPosX = aPlantToFeed->mX + 40;
        aZenTool->mPosY = aPlantToFeed->mY + 40;
        aZenTool->mRenderOrder = 900;

        if (theCursorType == CURSOR_TYPE_WATERING_CAN)
        {
            if (s.mApp->mPurchases[13])
            {
                aZenTool->mPosX = x;
                aZenTool->mPosY = y;
                ReanimationZ* w = s.mApp->AddReanimation((float)x, (float)y, 0, REANIM_ZENGARDEN_WATERINGCAN);
                w->PlayReanim(2, 2, 0, 8.0f);
                aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
                aZenTool->mGridItemState = GIS_ZEN_TOOL_GOLD_WATERING_CAN;
                s.mApp->PlayFoley(FOLEY_WATERING);
            }
            else
            {
                ReanimationZ* w = s.mApp->AddReanimation(aPlantToFeed->mX + 32.0f, (float)aPlantToFeed->mY, 0, REANIM_ZENGARDEN_WATERINGCAN);
                w->PlayReanim(1, 2, 0, 0.0f);
                aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(w);
                aZenTool->mGridItemState = GIS_ZEN_TOOL_WATERING_CAN;
                s.mApp->PlayFoley(FOLEY_WATERING);
            }
        }
        else
        {
            // B 形态 -> 常量表 kZenToolRows（FERTILIZER/BUG_SPRAY/PHONOGRAPH 三支同构链合并）
            constexpr struct {
                ReanimTypeZ mReanimType;
                float mOffX;
                float mOffY;
                GridItemStateZ mToolState;
                FoleyZ mFoley;
                int mLoopType;
                float mAnimRate;
                int mPurchaseItem;
            } kZenToolRows[CURSOR_TYPE_PHONOGRAPH - CURSOR_TYPE_FERTILIZER + 1] = {
                { REANIM_ZENGARDEN_FERTILIZER,  0.0f,  0.0f, GIS_ZEN_TOOL_FERTILIZER, FOLEY_FERTILIZER, 2, 0.0f, 14 },
                { REANIM_ZENGARDEN_BUGSPRAY,   54.0f,  0.0f, GIS_ZEN_TOOL_BUG_SPRAY,  FOLEY_BUGSPRAY,   2, 0.0f, 15 },
                { REANIM_ZENGARDEN_PHONOGRAPH, 20.0f, 34.0f, GIS_ZEN_TOOL_PHONOGRAPH,  FOLEY_PHONOGRAPH, 1, 20.0f, -1 },
            };

            const int aToolIndex = (int)theCursorType - (int)CURSOR_TYPE_FERTILIZER;
            if ((unsigned)aToolIndex < sizeof(kZenToolRows) / sizeof(kZenToolRows[0]))
            {
                const auto& aRow = kZenToolRows[aToolIndex];
                ReanimationZ* aToolReanim = s.mApp->AddReanimation(aPlantToFeed->mX + aRow.mOffX, aPlantToFeed->mY + aRow.mOffY, 0, aRow.mReanimType);
                if (aRow.mAnimRate != 0.0f)
                {
                    aToolReanim->mAnimRate = aRow.mAnimRate;
                }
                aToolReanim->mLoopType = aRow.mLoopType;
                aZenTool->mGridItemReanimID = s.mApp->ReanimationGetID(aToolReanim);
                aZenTool->mGridItemState = aRow.mToolState;
                s.mApp->PlayFoley(aRow.mFoley);

                if (aRow.mPurchaseItem >= 0)
                {
                    s.mApp->mPurchases[aRow.mPurchaseItem]--;
                }
            }
        }
    }

    s.mBoard->ClearCursor();
}
} // namespace FormB

// ---------------- t25 ZenGarden::DoFeedingTool ----------------
enum PottedPlantNeed { PLANTNEED_WATER = 0, PLANTNEED_FERTILIZER, PLANTNEED_BUGSPRAY, PLANTNEED_PHONOGRAPH, PLANTNEED_NONE };
static int g_plantsNeed; // GetPlantsNeed 输入驱动
struct ZenGardenFeedStub {
    ZenAppStub* mApp;
    ZenBoardStub* mBoard;
    void PlantWatered(PlantZ*) { CS(240); }
    void PlantFertilized(PlantZ*) { CS(241); }
    void PlantFulfillNeed(PlantZ*) { CS(242); }
};
static int PixelToGridXZ(int x, int y) { CS(243); return x / 80; }
static int PixelToGridYZ(int x, int y) { CS(244); return y / 80; }
static bool g_hasTopPlant;
static PlantZ* GetTopPlantAtZ(int, int) { CS(245); return g_hasTopPlant ? &g_plant : nullptr; }

namespace FormA {
__declspec(noinline) void DoFeedingTool(ZenGardenFeedStub& s, int x, int y, GridItemStateZ theToolType)
{
    if (theToolType == GIS_ZEN_TOOL_GOLD_WATERING_CAN)
    {
        CS(246); // 金水壶范围遍历桩（结构同两侧）
        return;
    }

    int aGridX = PixelToGridXZ(x, y);
    int aGridY = PixelToGridYZ(x, y);
    PlantZ* aPlant = GetTopPlantAtZ(aGridX, aGridY);
    if (aPlant && aPlant->mPottedPlantIndex >= 0)
    {
        PottedPlantNeed aNeed = (PottedPlantNeed)g_plantsNeed;
        if (aNeed == PLANTNEED_WATER && theToolType == GIS_ZEN_TOOL_WATERING_CAN)
        {
            s.PlantWatered(aPlant);
        }
        else if (aNeed == PLANTNEED_FERTILIZER && theToolType == GIS_ZEN_TOOL_FERTILIZER)
        {
            s.PlantFertilized(aPlant);
        }
        else if (aNeed == PLANTNEED_BUGSPRAY && theToolType == GIS_ZEN_TOOL_BUG_SPRAY)
        {
            s.PlantFulfillNeed(aPlant);
        }
        else if (aNeed == PLANTNEED_PHONOGRAPH && theToolType == GIS_ZEN_TOOL_PHONOGRAPH)
        {
            s.PlantFulfillNeed(aPlant);
        }
        CS(247); // 教程段桩（两侧同）
    }
}
} // namespace FormA

namespace FormB {
__declspec(noinline) void DoFeedingTool(ZenGardenFeedStub& s, int x, int y, GridItemStateZ theToolType)
{
    if (theToolType == GIS_ZEN_TOOL_GOLD_WATERING_CAN)
    {
        CS(246);
        return;
    }

    int aGridX = PixelToGridXZ(x, y);
    int aGridY = PixelToGridYZ(x, y);
    PlantZ* aPlant = GetTopPlantAtZ(aGridX, aGridY);
    if (aPlant && aPlant->mPottedPlantIndex >= 0)
    {
        PottedPlantNeed aNeed = (PottedPlantNeed)g_plantsNeed;

        // B 形态 -> 成员函数指针配对表 kFeedingCases（原 4 支 need×tool 配对链合并）
        static constexpr struct { PottedPlantNeed mNeed; GridItemStateZ mTool; void (ZenGardenFeedStub::*mFeed)(PlantZ*); } kFeedingCases[] = {
            { PLANTNEED_WATER,      GIS_ZEN_TOOL_WATERING_CAN, &ZenGardenFeedStub::PlantWatered },
            { PLANTNEED_FERTILIZER, GIS_ZEN_TOOL_FERTILIZER,   &ZenGardenFeedStub::PlantFertilized },
            { PLANTNEED_BUGSPRAY,   GIS_ZEN_TOOL_BUG_SPRAY,    &ZenGardenFeedStub::PlantFulfillNeed },
            { PLANTNEED_PHONOGRAPH, GIS_ZEN_TOOL_PHONOGRAPH,   &ZenGardenFeedStub::PlantFulfillNeed },
        };

        for (const auto& aCase : kFeedingCases)
        {
            if (aCase.mNeed == aNeed && aCase.mTool == theToolType)
            {
                (s.*aCase.mFeed)(aPlant);
                break;
            }
        }
        CS(247);
    }
}
} // namespace FormB

// ---------------- driver ----------------
static const int N = 2000000;
static uint32_t g_in[2000000];

static void Report(const char* name, double a1, double a2, double b1, double b2, uint64_t csA, uint64_t csB)
{
    printf("%s | before %.2f/%.2f ns | after %.2f/%.2f ns | diff %.1f%%/%.1f%% | cs %llx==%llx %s\n",
        name, a1, a2, b1, b2, (a1 - b1) / a1 * 100.0, (a2 - b2) / a2 * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "OK" : "MISMATCH");
}

int main()
{
    LCG rng{ 0x7FDB9FBE25AF8C3CULL };
    for (int i = 0; i < N; i++) g_in[i] = (uint32_t)rng.nx();

    // t3
    {
        static TitleAppStub app; static TitleScreenStub scr; scr.mApp = &app;
        static const KeyCode keys[10] = { 0x43, 0x49, 0x4D, 0x50, 0x52, 0x53, 0x54, 0x5A, 0x30, 0x5A };
        auto prep = [&](uint32_t v) {
            scr.mLoadingThreadComplete = false;
            scr.mQuickLoadKey = keys[v % 10];
            app.mTodCheatKeys = ((v >> 4) & 1) != 0;
            app.mPlayerInfo = ((v >> 5) & 1) != 0 ? (void*)&app : nullptr;
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::UpdateQuickLoad(scr); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::UpdateQuickLoad(scr); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t3 kTitleQuickLoadRows(7) TitleScreen::Update quickload", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t23
    {
        static ChooserAppStub app; static ChooserScreenStub scr; scr.mApp = &app; scr.mMenuButton = &g_menuBtn;
        auto prep = [&](uint32_t v) {
            g_sessionCurrent = ((v >> 0) & 1) != 0;
            scr.mSeedsInFlight = (int)((v >> 1) & 3) == 0 ? 1 : 0; // 偶尔 >0 早退
            scr.mChooseState = (int)((v >> 3) & 1);
            scr.mMouseVisible = (int)((v >> 4) & 3) != 0;
            ChooserAppStub::g_seedsAvail = (int)((v >> 6) & 1) * 10;
            g_seedBank.mNumPackets = 10;
            app.mGoToTreeNow = ((v >> 7) & 1) != 0;
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::ButtonDepress(scr, 102 + (int)(g_in[i] % 6)); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::ButtonDepress(scr, 102 + (int)(g_in[i] % 6)); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t23 kChooserButtonCases(4) SeedChooserScreen::ButtonDepress", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t24
    {
        static ZenAppStub app; static ZenBoardStub board; static ZenGardenStub zg; zg.mApp = &app; zg.mBoard = &board;
        board.mGridItems = g_gridItems; board.mGridItemCount = &g_gridItemCount;
        static GridItemZ stinky;
        auto prep = [&](uint32_t v) {
            ZenBoardStub::g_hasHighlightedPlant = ((v >> 0) & 1) != 0;
            g_plant.mPlantCol = (int)((v >> 1) & 7);
            g_plant.mRow = (int)((v >> 4) & 7);
            g_plant.mX = (int)((v >> 7) & 63);
            g_plant.mY = (int)((v >> 13) & 63);
            g_plant.mPottedPlantIndex = (int)((v >> 19) & 1);
            app.mPurchases[13] = (int)((v >> 20) & 1) * 105;
            app.mPurchases[14] = 105; app.mPurchases[15] = 105; app.mPurchases[26] = 105;
            ZenBoardStub::g_stinky = ((v >> 21) & 1) != 0 ? &stinky : nullptr;
            stinky.mHighlighted = ((v >> 22) & 1) != 0;
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::MouseDownWithFeedingTool(zg, 400, 300, (CursorTypeZ)(9 + (g_in[i] % 6))); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::MouseDownWithFeedingTool(zg, 400, 300, (CursorTypeZ)(9 + (g_in[i] % 6))); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t24 kZenToolRows(3) ZenGarden::MouseDownWithFeedingTool", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    // t25
    {
        static ZenAppStub app; static ZenBoardStub board; static ZenGardenFeedStub zg; zg.mApp = &app; zg.mBoard = &board;
        auto prep = [&](uint32_t v) {
            g_hasTopPlant = ((v >> 0) & 1) != 0;
            g_plant.mPottedPlantIndex = (int)((v >> 1) & 3) - 1;
            g_plantsNeed = (int)((v >> 3) % 5); // 含 NONE=4（不配对）
        };
        auto runA = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormA::DoFeedingTool(zg, 400, 300, (GridItemStateZ)(g_in[i] % 6)); } return g_cs; };
        auto runB = [&] { g_cs = 0x9E3779B97F4A7C15ULL; for (int i = 0; i < N; i++) { prep(g_in[i]); FormB::DoFeedingTool(zg, 400, 300, (GridItemStateZ)(g_in[i] % 6)); } return g_cs; };
        uint64_t csA = runA(), csB = runB();
        double r[2][2] = {};
        for (int rd = 0; rd < 2; rd++)
        {
            r[rd][0] = TimeMin5([&] { runA(); }) / N * 1e9;
            r[rd][1] = TimeMin5([&] { runB(); }) / N * 1e9;
        }
        Report("t25 kFeedingCases(4) ZenGarden::DoFeedingTool", r[0][0], r[1][0], r[0][1], r[1][1], csA, csB);
    }
    return 0;
}
