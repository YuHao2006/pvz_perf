
void FUN_00532930(void)

{
  int iVar1;
  int *in_EAX;
  
  iVar1 = DAT_007296fc;
  in_EAX[2] = 0;
  in_EAX[3] = 0;
  in_EAX[4] = 0;
  in_EAX[5] = 0;
  *(undefined1 *)(in_EAX + 6) = 1;
  in_EAX[7] = -1;
  in_EAX[8] = 400000;
  *in_EAX = iVar1;
  in_EAX[1] = *(int *)(iVar1 + 0x868);
  in_EAX[0x23] = 0;
  in_EAX[0x24] = 0;
  in_EAX[0x25] = 0;
  in_EAX[0x26] = 0;
  in_EAX[0x27] = 0;
  in_EAX[0x28] = 0;
  in_EAX[0x29] = 0;
  in_EAX[0x2a] = 0;
  return;
}

