
void __thiscall FUN_00547c30(int *param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined1 *puVar5;
  int *piVar6;
  int *piVar7;
  undefined1 local_2c [4];
  int local_28;
  undefined1 local_24 [4];
  int local_20;
  undefined1 local_1c [8];
  undefined1 local_14 [8];
  undefined4 local_c;
  int local_8;
  
  iVar3 = param_1[6];
  piVar6 = param_1;
  FUN_00420ae0();
  local_20 = iVar3;
  if (param_1 == (int *)0xfffffffc) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  iVar3 = piVar6[6];
  piVar7 = piVar6;
  FUN_00420ae0();
  local_8 = iVar3;
  if (piVar6 == (int *)0xfffffffc) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  puVar5 = local_24;
  puVar4 = &param_2;
  iVar3 = local_8;
  puVar2 = (undefined4 *)FUN_005b75d0(local_14);
  FUN_0055a680(local_1c,*puVar2,puVar2[1],local_c,iVar3,puVar4,puVar5);
  cVar1 = FUN_006143c0(puVar5);
  if (cVar1 != '\0') {
    piVar6 = piVar7 + 1;
    iVar3 = piVar7[6];
    FUN_00420ae0(piVar7,piVar6,iVar3);
    local_28 = iVar3;
    if (piVar6 == (int *)0x0) {
      FUN_0069a6f2();
    }
    FUN_0040a150();
    FUN_005484e0(local_2c,param_2);
    param_2[8] = piVar7[8];
    param_2[9] = (int)piVar7;
    if (piVar7[8] != 0) {
      (**(code **)(*param_2 + 0x50))(piVar7[8]);
      (**(code **)(*param_2 + 0x4c))();
      FUN_0054b6f0();
    }
    (**(code **)(*piVar7 + 0x44))();
  }
  return;
}

