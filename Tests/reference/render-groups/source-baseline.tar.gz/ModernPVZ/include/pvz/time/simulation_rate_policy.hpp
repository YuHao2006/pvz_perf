#pragma once

#include "pvz/time/fixed_step_clock.hpp"

#include <chrono>
#include <cstdint>

namespace pvz::time {

struct RatePolicyConfig {
    std::uint32_t requested_hz{200};
    std::uint32_t minimum_hz{100};
    std::uint32_t cpu_budget_percent{85};
};

struct RateDecision {
    std::uint32_t requested_hz{0};
    std::uint32_t selected_hz{0};
    std::uint32_t sustainable_hz{0};
    std::chrono::nanoseconds average_tick_cost{0};
    bool within_budget{true};
};

class SimulationRatePolicy {
public:
    explicit SimulationRatePolicy(RatePolicyConfig config = {});

    // Cost is one high-rate simulation substep, not a complete rendered frame.
    void observe_tick_cost(std::chrono::nanoseconds cost) noexcept;
    void reset() noexcept;

    [[nodiscard]] const RatePolicyConfig& config() const noexcept;
    [[nodiscard]] RateDecision decision() const noexcept;
    [[nodiscard]] std::uint64_t observed_samples() const noexcept;

private:
    RatePolicyConfig config_;
    std::chrono::nanoseconds average_tick_cost_{0};
    std::uint64_t observed_samples_{0};
};

} // namespace pvz::time
