#include "pvz/time/fixed_step_clock.hpp"

#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <d3d9.h>

#include <chrono>
#include <cstdio>
#include <stdexcept>

class D3D9Shell
{
public:
    D3D9Shell(GLFWwindow* window)
    {
        hwnd_ = glfwGetWin32Window(window);
        if (hwnd_ == nullptr)
            throw std::runtime_error("glfwGetWin32Window failed");

        d3d_ = Direct3DCreate9(D3D_SDK_VERSION);
        if (d3d_ == nullptr)
            throw std::runtime_error("Direct3DCreate9 failed");

        ZeroMemory(&present_, sizeof(present_));
        present_.Windowed = TRUE;
        present_.SwapEffect = D3DSWAPEFFECT_DISCARD;
        present_.hDeviceWindow = hwnd_;
        present_.BackBufferFormat = D3DFMT_X8R8G8B8;
        present_.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

        if (FAILED(d3d_->CreateDevice(
                D3DADAPTER_DEFAULT,
                D3DDEVTYPE_HAL,
                hwnd_,
                D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_FPU_PRESERVE,
                &present_,
                &device_)))
            throw std::runtime_error("CreateDevice failed");
    }

    ~D3D9Shell()
    {
        if (device_ != nullptr)
            device_->Release();
        if (d3d_ != nullptr)
            d3d_->Release();
    }

    void draw(std::uint64_t tick)
    {
        if (device_ == nullptr)
            return;

        D3DCOLOR color = D3DCOLOR_XRGB(
            static_cast<int>((tick * 7) % 255),
            30,
            45);
        device_->Clear(0, nullptr, D3DCLEAR_TARGET, color, 1.0f, 0);
        device_->BeginScene();
        device_->EndScene();
        if (device_->Present(nullptr, nullptr, nullptr, nullptr) == D3DERR_DEVICELOST)
            device_->Reset(&present_);
    }

private:
    HWND hwnd_{nullptr};
    IDirect3D9* d3d_{nullptr};
    IDirect3DDevice9* device_{nullptr};
    D3DPRESENT_PARAMETERS present_{};
};

int main()
{
    if (glfwInit() != GLFW_TRUE)
        return 1;

    GLFWwindow* window = glfwCreateWindow(800, 600, "Modern PvZ D3D9 Shell", nullptr, nullptr);
    if (window == nullptr)
    {
        glfwTerminate();
        return 1;
    }

    try
    {
        D3D9Shell shell(window);
        pvz::time::FixedStepClock clock(
            pvz::time::ClockConfig{
                .simulation_hz = 100,
                .semantic_hz = 100,
                .max_steps_per_advance = 64,
                .max_frame_delta = std::chrono::milliseconds{250},
            });

        auto previous = std::chrono::steady_clock::now();
        while (!glfwWindowShouldClose(window))
        {
            glfwPollEvents();
            const auto now = std::chrono::steady_clock::now();
            const auto elapsed = now - previous;
            previous = now;
            const pvz::time::StepBatch batch = clock.advance(elapsed);
            (void)batch;
            shell.draw(clock.total_ticks());
        }
    }
    catch (const std::exception& error)
    {
        std::fprintf(stderr, "%s\n", error.what());
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
