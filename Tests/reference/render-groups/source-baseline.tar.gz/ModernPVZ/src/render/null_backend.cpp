#include "pvz/render/null_backend.hpp"

#include <limits>
#include <stdexcept>

namespace pvz::render {

NullRenderBackend::NullRenderBackend()
{
    capabilities_.kind = BackendKind::null_backend;
    capabilities_.name = "Null validation backend";
    capabilities_.max_texture_dimension_2d = 16'384;
}

const BackendCapabilities& NullRenderBackend::capabilities() const noexcept
{
    return capabilities_;
}

TextureHandle NullRenderBackend::create_texture(const TextureUpload& upload)
{
    if (upload.width == 0 || upload.height == 0)
        throw std::invalid_argument("texture dimensions must be positive");
    if (upload.width > capabilities_.max_texture_dimension_2d ||
        upload.height > capabilities_.max_texture_dimension_2d)
        throw std::out_of_range("texture dimensions exceed backend capabilities");

    constexpr std::uint32_t bytes_per_pixel = 4;
    const auto minimum_row_pitch = static_cast<std::uint64_t>(upload.width) * bytes_per_pixel;
    if (upload.row_pitch_bytes < minimum_row_pitch)
        throw std::invalid_argument("texture row pitch is smaller than its width");

    const auto required_size = static_cast<std::uint64_t>(upload.row_pitch_bytes) * upload.height;
    if (required_size > upload.pixels.size())
        throw std::invalid_argument("texture upload does not contain every row");
    if (next_texture_handle_ == std::numeric_limits<std::uint32_t>::max())
        throw std::overflow_error("texture handle space exhausted");

    const TextureHandle handle{next_texture_handle_++};
    textures_.insert(handle.value);
    return handle;
}

void NullRenderBackend::update_texture(const TextureHandle texture, const TextureUpload& upload)
{
    if (!texture || !textures_.contains(texture.value))
        throw std::invalid_argument("unknown texture handle");
    if (upload.width == 0 || upload.height == 0)
        throw std::invalid_argument("texture dimensions must be positive");
    if (upload.width > capabilities_.max_texture_dimension_2d ||
        upload.height > capabilities_.max_texture_dimension_2d)
        throw std::out_of_range("texture dimensions exceed backend capabilities");

    constexpr std::uint32_t bytes_per_pixel = 4;
    const auto minimum_row_pitch = static_cast<std::uint64_t>(upload.width) * bytes_per_pixel;
    if (upload.row_pitch_bytes < minimum_row_pitch)
        throw std::invalid_argument("texture row pitch is smaller than its width");
    const auto required_size = static_cast<std::uint64_t>(upload.row_pitch_bytes) * upload.height;
    if (required_size > upload.pixels.size())
        throw std::invalid_argument("texture upload does not contain every row");
}

void NullRenderBackend::destroy_texture(const TextureHandle texture)
{
    if (!texture)
        return;
    if (textures_.erase(texture.value) == 0)
        throw std::invalid_argument("unknown texture handle");
}

void NullRenderBackend::resize(const std::uint32_t pixel_width, const std::uint32_t pixel_height)
{
    if (pixel_width == 0 || pixel_height == 0)
        throw std::invalid_argument("render target dimensions must be positive");
    pixel_width_ = pixel_width;
    pixel_height_ = pixel_height;
}

void NullRenderBackend::submit(const FramePacket& frame)
{
    if (pixel_width_ == 0 || pixel_height_ == 0)
        throw std::logic_error("render backend must be resized before submission");
    if (frame.logical_extent.width <= 0.0 || frame.logical_extent.height <= 0.0)
        throw std::invalid_argument("frame logical extent must be positive");
    if (frame.pixel_viewport.extent.width <= 0.0 || frame.pixel_viewport.extent.height <= 0.0)
        throw std::invalid_argument("frame pixel viewport must be positive");
    if (frame.interpolation_alpha < 0.0 || frame.interpolation_alpha >= 1.0)
        throw std::invalid_argument("frame interpolation alpha must be in [0, 1)");

    constexpr double epsilon = 1e-6;
    const auto viewport_right = frame.pixel_viewport.origin.x + frame.pixel_viewport.extent.width;
    const auto viewport_bottom = frame.pixel_viewport.origin.y + frame.pixel_viewport.extent.height;
    if (frame.pixel_viewport.origin.x < -epsilon || frame.pixel_viewport.origin.y < -epsilon ||
        viewport_right > static_cast<double>(pixel_width_) + epsilon ||
        viewport_bottom > static_cast<double>(pixel_height_) + epsilon)
        throw std::out_of_range("frame pixel viewport exceeds the render target");

    for (const auto index : frame.indices) {
        if (index >= frame.vertices.size())
            throw std::out_of_range("draw index references a missing vertex");
    }

    for (const auto& batch : frame.batches) {
        if (batch.texture && !textures_.contains(batch.texture.value))
            throw std::invalid_argument("draw batch references an unknown texture");

        const auto first = static_cast<std::uint64_t>(batch.first_index);
        const auto count = static_cast<std::uint64_t>(batch.index_count);
        if (first + count > frame.indices.size())
            throw std::out_of_range("draw batch exceeds the frame index buffer");

        const auto scissor_right = batch.logical_scissor.origin.x + batch.logical_scissor.extent.width;
        const auto scissor_bottom = batch.logical_scissor.origin.y + batch.logical_scissor.extent.height;
        if (batch.logical_scissor.extent.width < 0.0 || batch.logical_scissor.extent.height < 0.0 ||
            batch.logical_scissor.origin.x < 0.0 || batch.logical_scissor.origin.y < 0.0 ||
            scissor_right > frame.logical_extent.width + epsilon ||
            scissor_bottom > frame.logical_extent.height + epsilon)
            throw std::out_of_range("draw batch logical scissor exceeds the logical frame");
    }

    ++submitted_frames_;
    submitted_batches_ += frame.batches.size();
}

void NullRenderBackend::wait_idle()
{
}

std::uint64_t NullRenderBackend::submitted_frames() const noexcept
{
    return submitted_frames_;
}

std::uint64_t NullRenderBackend::submitted_batches() const noexcept
{
    return submitted_batches_;
}

} // namespace pvz::render
