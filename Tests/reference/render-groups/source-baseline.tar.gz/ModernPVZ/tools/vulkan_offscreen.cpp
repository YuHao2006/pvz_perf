#include <vulkan/vulkan.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

constexpr std::uint32_t kWidth = 256;
constexpr std::uint32_t kHeight = 256;
constexpr std::uint32_t kTextureWidth = 64;
constexpr std::uint32_t kTextureHeight = 64;
constexpr VkFormat kColorFormat = VK_FORMAT_R8G8B8A8_UNORM;

void check(const VkResult result, const char* operation)
{
    if (result != VK_SUCCESS)
        throw std::runtime_error(std::string(operation) + " failed with Vulkan error " + std::to_string(result));
}

struct VulkanResources {
    VkInstance instance{VK_NULL_HANDLE};
    VkDevice device{VK_NULL_HANDLE};
    VkCommandPool command_pool{VK_NULL_HANDLE};
    VkDescriptorPool descriptor_pool{VK_NULL_HANDLE};
    VkDescriptorSetLayout descriptor_set_layout{VK_NULL_HANDLE};
    VkPipelineLayout pipeline_layout{VK_NULL_HANDLE};
    VkRenderPass render_pass{VK_NULL_HANDLE};
    VkPipeline pipeline{VK_NULL_HANDLE};
    VkShaderModule vertex_shader{VK_NULL_HANDLE};
    VkShaderModule fragment_shader{VK_NULL_HANDLE};
    VkFramebuffer framebuffer{VK_NULL_HANDLE};
    VkSampler sampler{VK_NULL_HANDLE};
    VkImageView color_view{VK_NULL_HANDLE};
    VkImageView texture_view{VK_NULL_HANDLE};
    VkImage color_image{VK_NULL_HANDLE};
    VkImage texture_image{VK_NULL_HANDLE};
    VkDeviceMemory color_memory{VK_NULL_HANDLE};
    VkDeviceMemory texture_memory{VK_NULL_HANDLE};
    VkBuffer upload_buffer{VK_NULL_HANDLE};
    VkBuffer readback_buffer{VK_NULL_HANDLE};
    VkDeviceMemory upload_memory{VK_NULL_HANDLE};
    VkDeviceMemory readback_memory{VK_NULL_HANDLE};

    ~VulkanResources()
    {
        if (device != VK_NULL_HANDLE)
            vkDeviceWaitIdle(device);
        if (framebuffer != VK_NULL_HANDLE)
            vkDestroyFramebuffer(device, framebuffer, nullptr);
        if (pipeline != VK_NULL_HANDLE)
            vkDestroyPipeline(device, pipeline, nullptr);
        if (fragment_shader != VK_NULL_HANDLE)
            vkDestroyShaderModule(device, fragment_shader, nullptr);
        if (vertex_shader != VK_NULL_HANDLE)
            vkDestroyShaderModule(device, vertex_shader, nullptr);
        if (pipeline_layout != VK_NULL_HANDLE)
            vkDestroyPipelineLayout(device, pipeline_layout, nullptr);
        if (render_pass != VK_NULL_HANDLE)
            vkDestroyRenderPass(device, render_pass, nullptr);
        if (descriptor_pool != VK_NULL_HANDLE)
            vkDestroyDescriptorPool(device, descriptor_pool, nullptr);
        if (descriptor_set_layout != VK_NULL_HANDLE)
            vkDestroyDescriptorSetLayout(device, descriptor_set_layout, nullptr);
        if (sampler != VK_NULL_HANDLE)
            vkDestroySampler(device, sampler, nullptr);
        if (color_view != VK_NULL_HANDLE)
            vkDestroyImageView(device, color_view, nullptr);
        if (texture_view != VK_NULL_HANDLE)
            vkDestroyImageView(device, texture_view, nullptr);
        if (color_image != VK_NULL_HANDLE)
            vkDestroyImage(device, color_image, nullptr);
        if (texture_image != VK_NULL_HANDLE)
            vkDestroyImage(device, texture_image, nullptr);
        if (upload_buffer != VK_NULL_HANDLE)
            vkDestroyBuffer(device, upload_buffer, nullptr);
        if (readback_buffer != VK_NULL_HANDLE)
            vkDestroyBuffer(device, readback_buffer, nullptr);
        if (color_memory != VK_NULL_HANDLE)
            vkFreeMemory(device, color_memory, nullptr);
        if (texture_memory != VK_NULL_HANDLE)
            vkFreeMemory(device, texture_memory, nullptr);
        if (upload_memory != VK_NULL_HANDLE)
            vkFreeMemory(device, upload_memory, nullptr);
        if (readback_memory != VK_NULL_HANDLE)
            vkFreeMemory(device, readback_memory, nullptr);
        if (command_pool != VK_NULL_HANDLE)
            vkDestroyCommandPool(device, command_pool, nullptr);
        if (device != VK_NULL_HANDLE)
            vkDestroyDevice(device, nullptr);
        if (instance != VK_NULL_HANDLE)
            vkDestroyInstance(instance, nullptr);
    }
};

[[nodiscard]] std::vector<std::uint32_t> read_spirv(const std::filesystem::path& path)
{
    std::ifstream input{path, std::ios::binary | std::ios::ate};
    if (!input)
        throw std::runtime_error("unable to open shader: " + path.string());
    const auto end = input.tellg();
    const auto size = static_cast<std::streamoff>(end);
    if (size <= 0 || size % 4 != 0)
        throw std::runtime_error("invalid SPIR-V size: " + path.string());

    std::vector<std::uint32_t> words(static_cast<std::size_t>(size) / sizeof(std::uint32_t));
    input.seekg(0);
    input.read(reinterpret_cast<char*>(words.data()), size);
    if (!input)
        throw std::runtime_error("unable to read shader: " + path.string());
    return words;
}

[[nodiscard]] std::uint32_t find_memory_type(
    const VkPhysicalDeviceMemoryProperties& properties,
    const std::uint32_t type_bits,
    const VkMemoryPropertyFlags required)
{
    for (std::uint32_t index = 0; index < properties.memoryTypeCount; ++index) {
        if ((type_bits & (1U << index)) != 0 &&
            (properties.memoryTypes[index].propertyFlags & required) == required)
            return index;
    }
    throw std::runtime_error("no compatible Vulkan memory type");
}

void create_buffer(
    VulkanResources& resources,
    const VkPhysicalDeviceMemoryProperties& memory_properties,
    const VkDeviceSize size,
    const VkBufferUsageFlags usage,
    VkBuffer& buffer,
    VkDeviceMemory& memory)
{
    VkBufferCreateInfo buffer_info{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    buffer_info.size = size;
    buffer_info.usage = usage;
    buffer_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    check(vkCreateBuffer(resources.device, &buffer_info, nullptr, &buffer), "vkCreateBuffer");

    VkMemoryRequirements requirements{};
    vkGetBufferMemoryRequirements(resources.device, buffer, &requirements);

    VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    allocation.allocationSize = requirements.size;
    allocation.memoryTypeIndex = find_memory_type(
        memory_properties,
        requirements.memoryTypeBits,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    check(vkAllocateMemory(resources.device, &allocation, nullptr, &memory), "vkAllocateMemory(buffer)");
    check(vkBindBufferMemory(resources.device, buffer, memory, 0), "vkBindBufferMemory");
}

void create_image(
    VulkanResources& resources,
    const VkPhysicalDeviceMemoryProperties& memory_properties,
    const std::uint32_t width,
    const std::uint32_t height,
    const VkImageUsageFlags usage,
    VkImage& image,
    VkDeviceMemory& memory)
{
    VkImageCreateInfo image_info{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    image_info.imageType = VK_IMAGE_TYPE_2D;
    image_info.format = kColorFormat;
    image_info.extent = {width, height, 1};
    image_info.mipLevels = 1;
    image_info.arrayLayers = 1;
    image_info.samples = VK_SAMPLE_COUNT_1_BIT;
    image_info.tiling = VK_IMAGE_TILING_OPTIMAL;
    image_info.usage = usage;
    image_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    image_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    check(vkCreateImage(resources.device, &image_info, nullptr, &image), "vkCreateImage");

    VkMemoryRequirements requirements{};
    vkGetImageMemoryRequirements(resources.device, image, &requirements);

    VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    allocation.allocationSize = requirements.size;
    allocation.memoryTypeIndex = find_memory_type(
        memory_properties,
        requirements.memoryTypeBits,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    check(vkAllocateMemory(resources.device, &allocation, nullptr, &memory), "vkAllocateMemory(image)");
    check(vkBindImageMemory(resources.device, image, memory, 0), "vkBindImageMemory");
}

[[nodiscard]] VkImageView create_image_view(VkDevice device, VkImage image)
{
    VkImageViewCreateInfo view_info{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    view_info.image = image;
    view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
    view_info.format = kColorFormat;
    view_info.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    view_info.subresourceRange.levelCount = 1;
    view_info.subresourceRange.layerCount = 1;

    VkImageView view = VK_NULL_HANDLE;
    check(vkCreateImageView(device, &view_info, nullptr, &view), "vkCreateImageView");
    return view;
}

[[nodiscard]] VkShaderModule create_shader_module(
    const VkDevice device,
    const std::vector<std::uint32_t>& words)
{
    VkShaderModuleCreateInfo create_info{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    create_info.codeSize = words.size() * sizeof(std::uint32_t);
    create_info.pCode = words.data();
    VkShaderModule module = VK_NULL_HANDLE;
    check(vkCreateShaderModule(device, &create_info, nullptr, &module), "vkCreateShaderModule");
    return module;
}

[[nodiscard]] std::vector<std::uint8_t> make_checkerboard()
{
    std::vector<std::uint8_t> pixels(kTextureWidth * kTextureHeight * 4);
    constexpr std::array<std::uint8_t, 4> green{52, 168, 83, 255};
    constexpr std::array<std::uint8_t, 4> gold{246, 194, 62, 255};

    for (std::uint32_t y = 0; y < kTextureHeight; ++y) {
        for (std::uint32_t x = 0; x < kTextureWidth; ++x) {
            const auto& color = (((x / 8) + (y / 8)) % 2 == 0) ? green : gold;
            const auto offset = static_cast<std::size_t>((y * kTextureWidth + x) * 4);
            std::copy(color.begin(), color.end(), pixels.begin() + static_cast<std::ptrdiff_t>(offset));
        }
    }
    return pixels;
}

void write_u16(std::ostream& output, const std::uint16_t value)
{
    const std::array bytes{
        static_cast<char>(value & 0xFF),
        static_cast<char>((value >> 8) & 0xFF),
    };
    output.write(bytes.data(), bytes.size());
}

void write_u32(std::ostream& output, const std::uint32_t value)
{
    const std::array bytes{
        static_cast<char>(value & 0xFF),
        static_cast<char>((value >> 8) & 0xFF),
        static_cast<char>((value >> 16) & 0xFF),
        static_cast<char>((value >> 24) & 0xFF),
    };
    output.write(bytes.data(), bytes.size());
}

void write_bmp(const std::filesystem::path& path, const std::vector<std::uint8_t>& rgba)
{
    constexpr std::uint32_t header_size = 14 + 40;
    const auto image_size = kWidth * kHeight * 4;
    std::ofstream output{path, std::ios::binary};
    if (!output)
        throw std::runtime_error("unable to create BMP output");

    output.put('B');
    output.put('M');
    write_u32(output, header_size + image_size);
    write_u16(output, 0);
    write_u16(output, 0);
    write_u32(output, header_size);

    write_u32(output, 40);
    write_u32(output, kWidth);
    write_u32(output, static_cast<std::uint32_t>(-static_cast<std::int32_t>(kHeight)));
    write_u16(output, 1);
    write_u16(output, 32);
    write_u32(output, 0);
    write_u32(output, image_size);
    write_u32(output, 2835);
    write_u32(output, 2835);
    write_u32(output, 0);
    write_u32(output, 0);

    for (std::size_t offset = 0; offset < rgba.size(); offset += 4) {
        output.put(static_cast<char>(rgba[offset + 2]));
        output.put(static_cast<char>(rgba[offset + 1]));
        output.put(static_cast<char>(rgba[offset]));
        output.put(static_cast<char>(rgba[offset + 3]));
    }
    if (!output)
        throw std::runtime_error("unable to write BMP output");
}

[[nodiscard]] std::uint64_t fnv1a64(const std::vector<std::uint8_t>& bytes) noexcept
{
    std::uint64_t hash = 14695981039346656037ULL;
    for (const auto byte : bytes) {
        hash ^= byte;
        hash *= 1099511628211ULL;
    }
    return hash;
}

int run(const std::filesystem::path& vertex_path,
        const std::filesystem::path& fragment_path,
        const std::filesystem::path& output_path)
{
    VulkanResources resources;

    VkApplicationInfo application_info{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    application_info.pApplicationName = "Modern PvZ Vulkan offscreen smoke";
    application_info.apiVersion = VK_API_VERSION_1_3;
    VkInstanceCreateInfo instance_info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    instance_info.pApplicationInfo = &application_info;
    check(vkCreateInstance(&instance_info, nullptr, &resources.instance), "vkCreateInstance");

    std::uint32_t physical_device_count = 0;
    check(vkEnumeratePhysicalDevices(resources.instance, &physical_device_count, nullptr),
          "vkEnumeratePhysicalDevices(count)");
    if (physical_device_count == 0)
        throw std::runtime_error("no Vulkan physical devices available");
    std::vector<VkPhysicalDevice> physical_devices(physical_device_count);
    check(vkEnumeratePhysicalDevices(resources.instance, &physical_device_count, physical_devices.data()),
          "vkEnumeratePhysicalDevices");

    VkPhysicalDevice physical_device = VK_NULL_HANDLE;
    std::uint32_t queue_family_index = std::numeric_limits<std::uint32_t>::max();
    VkPhysicalDeviceProperties selected_properties{};
    for (const auto candidate : physical_devices) {
        std::uint32_t queue_count = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(candidate, &queue_count, nullptr);
        std::vector<VkQueueFamilyProperties> queues(queue_count);
        vkGetPhysicalDeviceQueueFamilyProperties(candidate, &queue_count, queues.data());
        for (std::uint32_t index = 0; index < queue_count; ++index) {
            if ((queues[index].queueFlags & VK_QUEUE_GRAPHICS_BIT) == 0)
                continue;
            VkPhysicalDeviceProperties properties{};
            vkGetPhysicalDeviceProperties(candidate, &properties);
            if (physical_device == VK_NULL_HANDLE || properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) {
                physical_device = candidate;
                queue_family_index = index;
                selected_properties = properties;
            }
            break;
        }
        if (selected_properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU)
            break;
    }
    if (physical_device == VK_NULL_HANDLE)
        throw std::runtime_error("no Vulkan graphics queue available");

    VkFormatProperties format_properties{};
    vkGetPhysicalDeviceFormatProperties(physical_device, kColorFormat, &format_properties);
    const auto required_format_features = VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT |
                                          VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT |
                                          VK_FORMAT_FEATURE_TRANSFER_SRC_BIT |
                                          VK_FORMAT_FEATURE_TRANSFER_DST_BIT;
    if ((format_properties.optimalTilingFeatures & required_format_features) != required_format_features)
        throw std::runtime_error("RGBA8 optimal images do not support the required Vulkan operations");

    const float queue_priority = 1.0F;
    VkDeviceQueueCreateInfo queue_info{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    queue_info.queueFamilyIndex = queue_family_index;
    queue_info.queueCount = 1;
    queue_info.pQueuePriorities = &queue_priority;
    VkDeviceCreateInfo device_info{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    device_info.queueCreateInfoCount = 1;
    device_info.pQueueCreateInfos = &queue_info;
    check(vkCreateDevice(physical_device, &device_info, nullptr, &resources.device), "vkCreateDevice");

    VkQueue queue = VK_NULL_HANDLE;
    vkGetDeviceQueue(resources.device, queue_family_index, 0, &queue);
    VkPhysicalDeviceMemoryProperties memory_properties{};
    vkGetPhysicalDeviceMemoryProperties(physical_device, &memory_properties);

    VkCommandPoolCreateInfo command_pool_info{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    command_pool_info.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    command_pool_info.queueFamilyIndex = queue_family_index;
    check(vkCreateCommandPool(resources.device, &command_pool_info, nullptr, &resources.command_pool),
          "vkCreateCommandPool");

    const auto texture_pixels = make_checkerboard();
    create_buffer(resources, memory_properties, texture_pixels.size(), VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                  resources.upload_buffer, resources.upload_memory);
    create_buffer(resources, memory_properties, kWidth * kHeight * 4, VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                  resources.readback_buffer, resources.readback_memory);
    create_image(resources, memory_properties, kTextureWidth, kTextureHeight,
                 VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
                 resources.texture_image, resources.texture_memory);
    create_image(resources, memory_properties, kWidth, kHeight,
                 VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT,
                 resources.color_image, resources.color_memory);

    void* upload_mapping = nullptr;
    check(vkMapMemory(resources.device, resources.upload_memory, 0, texture_pixels.size(), 0, &upload_mapping),
          "vkMapMemory(upload)");
    std::memcpy(upload_mapping, texture_pixels.data(), texture_pixels.size());
    vkUnmapMemory(resources.device, resources.upload_memory);

    resources.texture_view = create_image_view(resources.device, resources.texture_image);
    resources.color_view = create_image_view(resources.device, resources.color_image);

    VkSamplerCreateInfo sampler_info{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    sampler_info.magFilter = VK_FILTER_NEAREST;
    sampler_info.minFilter = VK_FILTER_NEAREST;
    sampler_info.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    sampler_info.addressModeU = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    sampler_info.addressModeV = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    sampler_info.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    sampler_info.maxLod = 0.0F;
    check(vkCreateSampler(resources.device, &sampler_info, nullptr, &resources.sampler), "vkCreateSampler");

    VkDescriptorSetLayoutBinding layout_binding{};
    layout_binding.binding = 0;
    layout_binding.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    layout_binding.descriptorCount = 1;
    layout_binding.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo layout_info{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    layout_info.bindingCount = 1;
    layout_info.pBindings = &layout_binding;
    check(vkCreateDescriptorSetLayout(resources.device, &layout_info, nullptr, &resources.descriptor_set_layout),
          "vkCreateDescriptorSetLayout");

    VkPipelineLayoutCreateInfo pipeline_layout_info{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pipeline_layout_info.setLayoutCount = 1;
    pipeline_layout_info.pSetLayouts = &resources.descriptor_set_layout;
    check(vkCreatePipelineLayout(resources.device, &pipeline_layout_info, nullptr, &resources.pipeline_layout),
          "vkCreatePipelineLayout");

    VkAttachmentDescription attachment{};
    attachment.format = kColorFormat;
    attachment.samples = VK_SAMPLE_COUNT_1_BIT;
    attachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    attachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    attachment.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    attachment.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachment.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    attachment.finalLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    VkAttachmentReference color_reference{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkSubpassDescription subpass{};
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &color_reference;
    VkRenderPassCreateInfo render_pass_info{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    render_pass_info.attachmentCount = 1;
    render_pass_info.pAttachments = &attachment;
    render_pass_info.subpassCount = 1;
    render_pass_info.pSubpasses = &subpass;
    check(vkCreateRenderPass(resources.device, &render_pass_info, nullptr, &resources.render_pass),
          "vkCreateRenderPass");

    VkFramebufferCreateInfo framebuffer_info{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
    framebuffer_info.renderPass = resources.render_pass;
    framebuffer_info.attachmentCount = 1;
    framebuffer_info.pAttachments = &resources.color_view;
    framebuffer_info.width = kWidth;
    framebuffer_info.height = kHeight;
    framebuffer_info.layers = 1;
    check(vkCreateFramebuffer(resources.device, &framebuffer_info, nullptr, &resources.framebuffer),
          "vkCreateFramebuffer");

    const auto vertex_words = read_spirv(vertex_path);
    const auto fragment_words = read_spirv(fragment_path);
    resources.vertex_shader = create_shader_module(resources.device, vertex_words);
    resources.fragment_shader = create_shader_module(resources.device, fragment_words);

    VkPipelineShaderStageCreateInfo vertex_stage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    vertex_stage.stage = VK_SHADER_STAGE_VERTEX_BIT;
    vertex_stage.module = resources.vertex_shader;
    vertex_stage.pName = "main";
    VkPipelineShaderStageCreateInfo fragment_stage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    fragment_stage.stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    fragment_stage.module = resources.fragment_shader;
    fragment_stage.pName = "main";
    const std::array shader_stages{vertex_stage, fragment_stage};

    VkPipelineVertexInputStateCreateInfo vertex_input{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo input_assembly{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    input_assembly.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkViewport viewport{0.0F, 0.0F, static_cast<float>(kWidth), static_cast<float>(kHeight), 0.0F, 1.0F};
    VkRect2D scissor{{0, 0}, {kWidth, kHeight}};
    VkPipelineViewportStateCreateInfo viewport_state{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    viewport_state.viewportCount = 1;
    viewport_state.pViewports = &viewport;
    viewport_state.scissorCount = 1;
    viewport_state.pScissors = &scissor;
    VkPipelineRasterizationStateCreateInfo rasterization{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rasterization.polygonMode = VK_POLYGON_MODE_FILL;
    rasterization.cullMode = VK_CULL_MODE_NONE;
    rasterization.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rasterization.lineWidth = 1.0F;
    VkPipelineMultisampleStateCreateInfo multisample{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    multisample.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState blend_attachment{};
    blend_attachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                      VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    VkPipelineColorBlendStateCreateInfo blend_state{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    blend_state.attachmentCount = 1;
    blend_state.pAttachments = &blend_attachment;
    VkGraphicsPipelineCreateInfo pipeline_info{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    pipeline_info.stageCount = static_cast<std::uint32_t>(shader_stages.size());
    pipeline_info.pStages = shader_stages.data();
    pipeline_info.pVertexInputState = &vertex_input;
    pipeline_info.pInputAssemblyState = &input_assembly;
    pipeline_info.pViewportState = &viewport_state;
    pipeline_info.pRasterizationState = &rasterization;
    pipeline_info.pMultisampleState = &multisample;
    pipeline_info.pColorBlendState = &blend_state;
    pipeline_info.layout = resources.pipeline_layout;
    pipeline_info.renderPass = resources.render_pass;
    check(vkCreateGraphicsPipelines(resources.device, VK_NULL_HANDLE, 1, &pipeline_info, nullptr,
                                    &resources.pipeline),
          "vkCreateGraphicsPipelines");
    vkDestroyShaderModule(resources.device, resources.fragment_shader, nullptr);
    vkDestroyShaderModule(resources.device, resources.vertex_shader, nullptr);
    resources.fragment_shader = VK_NULL_HANDLE;
    resources.vertex_shader = VK_NULL_HANDLE;

    VkDescriptorPoolSize pool_size{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1};
    VkDescriptorPoolCreateInfo pool_info{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    pool_info.maxSets = 1;
    pool_info.poolSizeCount = 1;
    pool_info.pPoolSizes = &pool_size;
    check(vkCreateDescriptorPool(resources.device, &pool_info, nullptr, &resources.descriptor_pool),
          "vkCreateDescriptorPool");
    VkDescriptorSetAllocateInfo set_allocation{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    set_allocation.descriptorPool = resources.descriptor_pool;
    set_allocation.descriptorSetCount = 1;
    set_allocation.pSetLayouts = &resources.descriptor_set_layout;
    VkDescriptorSet descriptor_set = VK_NULL_HANDLE;
    check(vkAllocateDescriptorSets(resources.device, &set_allocation, &descriptor_set),
          "vkAllocateDescriptorSets");
    VkDescriptorImageInfo descriptor_image{};
    descriptor_image.sampler = resources.sampler;
    descriptor_image.imageView = resources.texture_view;
    descriptor_image.imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    VkWriteDescriptorSet descriptor_write{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    descriptor_write.dstSet = descriptor_set;
    descriptor_write.dstBinding = 0;
    descriptor_write.descriptorCount = 1;
    descriptor_write.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    descriptor_write.pImageInfo = &descriptor_image;
    vkUpdateDescriptorSets(resources.device, 1, &descriptor_write, 0, nullptr);

    VkCommandBufferAllocateInfo command_allocation{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    command_allocation.commandPool = resources.command_pool;
    command_allocation.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    command_allocation.commandBufferCount = 1;
    VkCommandBuffer command_buffer = VK_NULL_HANDLE;
    check(vkAllocateCommandBuffers(resources.device, &command_allocation, &command_buffer),
          "vkAllocateCommandBuffers");
    VkCommandBufferBeginInfo begin_info{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    begin_info.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    check(vkBeginCommandBuffer(command_buffer, &begin_info), "vkBeginCommandBuffer");

    VkImageMemoryBarrier texture_to_transfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    texture_to_transfer.srcAccessMask = 0;
    texture_to_transfer.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    texture_to_transfer.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    texture_to_transfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    texture_to_transfer.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    texture_to_transfer.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    texture_to_transfer.image = resources.texture_image;
    texture_to_transfer.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    texture_to_transfer.subresourceRange.levelCount = 1;
    texture_to_transfer.subresourceRange.layerCount = 1;
    vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
                         0, 0, nullptr, 0, nullptr, 1, &texture_to_transfer);

    VkBufferImageCopy texture_copy{};
    texture_copy.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    texture_copy.imageSubresource.layerCount = 1;
    texture_copy.imageExtent = {kTextureWidth, kTextureHeight, 1};
    vkCmdCopyBufferToImage(command_buffer, resources.upload_buffer, resources.texture_image,
                           VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &texture_copy);

    VkImageMemoryBarrier texture_to_shader{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    texture_to_shader.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    texture_to_shader.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    texture_to_shader.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    texture_to_shader.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    texture_to_shader.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    texture_to_shader.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    texture_to_shader.image = resources.texture_image;
    texture_to_shader.subresourceRange = texture_to_transfer.subresourceRange;
    vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                         0, 0, nullptr, 0, nullptr, 1, &texture_to_shader);

    const VkClearValue clear_value{{{0.04F, 0.05F, 0.06F, 1.0F}}};
    VkRenderPassBeginInfo render_begin{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    render_begin.renderPass = resources.render_pass;
    render_begin.framebuffer = resources.framebuffer;
    render_begin.renderArea.extent = {kWidth, kHeight};
    render_begin.clearValueCount = 1;
    render_begin.pClearValues = &clear_value;
    vkCmdBeginRenderPass(command_buffer, &render_begin, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(command_buffer, VK_PIPELINE_BIND_POINT_GRAPHICS, resources.pipeline);
    vkCmdBindDescriptorSets(command_buffer, VK_PIPELINE_BIND_POINT_GRAPHICS, resources.pipeline_layout,
                            0, 1, &descriptor_set, 0, nullptr);
    vkCmdDraw(command_buffer, 3, 1, 0, 0);
    vkCmdEndRenderPass(command_buffer);

    VkImageMemoryBarrier color_to_transfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    color_to_transfer.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    color_to_transfer.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    color_to_transfer.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    color_to_transfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    color_to_transfer.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    color_to_transfer.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    color_to_transfer.image = resources.color_image;
    color_to_transfer.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    color_to_transfer.subresourceRange.levelCount = 1;
    color_to_transfer.subresourceRange.layerCount = 1;
    vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
                         VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &color_to_transfer);

    VkBufferImageCopy readback_copy{};
    readback_copy.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    readback_copy.imageSubresource.layerCount = 1;
    readback_copy.imageExtent = {kWidth, kHeight, 1};
    vkCmdCopyImageToBuffer(command_buffer, resources.color_image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                           resources.readback_buffer, 1, &readback_copy);

    VkBufferMemoryBarrier readback_to_host{VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER};
    readback_to_host.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    readback_to_host.dstAccessMask = VK_ACCESS_HOST_READ_BIT;
    readback_to_host.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    readback_to_host.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    readback_to_host.buffer = resources.readback_buffer;
    readback_to_host.size = VK_WHOLE_SIZE;
    vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT,
                         0, 0, nullptr, 1, &readback_to_host, 0, nullptr);
    check(vkEndCommandBuffer(command_buffer), "vkEndCommandBuffer");

    VkSubmitInfo submit_info{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submit_info.commandBufferCount = 1;
    submit_info.pCommandBuffers = &command_buffer;
    check(vkQueueSubmit(queue, 1, &submit_info, VK_NULL_HANDLE), "vkQueueSubmit");
    check(vkQueueWaitIdle(queue), "vkQueueWaitIdle");

    std::vector<std::uint8_t> rgba(kWidth * kHeight * 4);
    void* readback_mapping = nullptr;
    check(vkMapMemory(resources.device, resources.readback_memory, 0, rgba.size(), 0, &readback_mapping),
          "vkMapMemory(readback)");
    std::memcpy(rgba.data(), readback_mapping, rgba.size());
    vkUnmapMemory(resources.device, resources.readback_memory);

    constexpr std::array<std::uint8_t, 4> green{52, 168, 83, 255};
    constexpr std::array<std::uint8_t, 4> gold{246, 194, 62, 255};
    std::size_t green_pixels = 0;
    std::size_t gold_pixels = 0;
    std::size_t unexpected_pixels = 0;
    for (std::size_t offset = 0; offset < rgba.size(); offset += 4) {
        const std::array pixel{rgba[offset], rgba[offset + 1], rgba[offset + 2], rgba[offset + 3]};
        if (pixel == green)
            ++green_pixels;
        else if (pixel == gold)
            ++gold_pixels;
        else
            ++unexpected_pixels;
    }
    if (green_pixels == 0 || gold_pixels == 0 || unexpected_pixels != 0)
        throw std::runtime_error("Vulkan textured output did not match the uploaded checkerboard");

    write_bmp(output_path, rgba);
    std::cout << "device=" << selected_properties.deviceName
              << "\nsize=" << kWidth << 'x' << kHeight
              << "\ngreen_pixels=" << green_pixels
              << "\ngold_pixels=" << gold_pixels
              << "\nfnv1a64=0x" << std::hex << fnv1a64(rgba) << std::dec
              << "\noutput=" << output_path.string() << '\n';
    return 0;
}

} // namespace

int main(const int argc, const char* const argv[])
{
    if (argc != 4) {
        std::cerr << "usage: pvz_vulkan_offscreen <vertex.spv> <fragment.spv> <output.bmp>\n";
        return 2;
    }

    try {
        return run(argv[1], argv[2], argv[3]);
    } catch (const std::exception& error) {
        std::cerr << "pvz_vulkan_offscreen: " << error.what() << '\n';
        return 1;
    }
}
