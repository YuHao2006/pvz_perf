bool Board::Met(SeedType theSeedType)
{
	if (theSeedType < SeedType::SEED_GATLINGPEA || theSeedType > SeedType::SEED_COBCANNON)
	{
		return true;
	}
	constexpr bool (*kUpgradeBasisReqs[])(Board*) = {
		/* SEED_GATLINGPEA    */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_REPEATER) != 0; },
		/* SEED_TWINSUNFLOWER */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_SUNFLOWER) != 0; },
		/* SEED_GLOOMSHROOM   */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_FUMESHROOM) != 0; },
		/* SEED_CATTAIL       */ [](Board* aBoard) { return aBoard->CountEmptyPotsOrLilies(SeedType::SEED_LILYPAD) != 0; },
		/* SEED_WINTERMELON   */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_MELONPULT) != 0; },
		/* SEED_GOLD_MAGNET   */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_MAGNETSHROOM) != 0; },
		/* SEED_SPIKEROCK     */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_SPIKEWEED) != 0; },
		/* SEED_COBCANNON     */ [](Board* aBoard) { return aBoard->HasValidCobCannonSpot(); },
	};
	static_assert(sizeof(kUpgradeBasisReqs) / sizeof(kUpgradeBasisReqs[0])
		== (int)SeedType::SEED_COBCANNON - (int)SeedType::SEED_GATLINGPEA + 1,
		"基座检查槽位须与 SeedType 升级段同步");
	return kUpgradeBasisReqs[(int)theSeedType - (int)SeedType::SEED_GATLINGPEA](this);
}

//0x40D430
int Board::CountEmptyPotsOrLilies(SeedType theSeedType)
{
	int aCount = 0;
	Plant* aPlant = nullptr;
	while (IteratePlants(aPlant))
	{
		if (aPlant->mSeedType == theSeedType && !GetTopPlantAt(aPlant->mPlantCol, aPlant->mRow, PlantPriority::TOPPLANT_ONLY_NORMAL_POSITION))
		{
			aCount++;
		}
	}
	return aCount;
}

//0x40D4F0
bool Board::IsValidCobCannonSpotHelper(int theGridX, int theGridY)
{
	PlantsOnLawn aPlantOnLawn;
	GetPlantsOnLawn(theGridX, theGridY, &aPlantOnLawn);
	if (aPlantOnLawn.mPumpkinPlant)
		return false;

	if (aPlantOnLawn.mNormalPlant && aPlantOnLawn.mNormalPlant->mSeedType == SeedType::SEED_KERNELPULT)
		return true;

	return mApp->mEasyPlantingCheat && CanPlantAt(theGridX, theGridY, SeedType::SEED_KERNELPULT) == PlantingReason::PLANTING_OK;
}

//0x40D550
bool Board::IsValidCobCannonSpot(int theGridX, int theGridY)
{
	if (!IsValidCobCannonSpotHelper(theGridX, theGridY) || !IsValidCobCannonSpotHelper(theGridX + 1, theGridY))
