#pragma once

#include <cstdint>
#include <optional>
#include <span>
#include <string_view>

namespace pvz::assets {

enum class ImageFormat {
    png,
    jpeg,
    gif,
};

struct ImageDimensions {
    std::uint32_t width{0};
    std::uint32_t height{0};
    ImageFormat format{ImageFormat::png};
};

[[nodiscard]] std::optional<ImageDimensions> inspect_image_dimensions(
    std::span<const std::uint8_t> bytes) noexcept;
[[nodiscard]] std::string_view image_format_name(ImageFormat format) noexcept;

} // namespace pvz::assets
