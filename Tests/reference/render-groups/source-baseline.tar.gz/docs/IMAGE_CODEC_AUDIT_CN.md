# 图像编解码审计

审计日期：2026-08-24。

## 结论

| 场景 | 后端 |
| --- | --- |
| pak64 PNG 读取/写出 | libspng 0.7.4 |
| pak64 JPG 读取 | Jpegli（固定 commit `031a0077f5799a6041004267fc12b956c1f52a20`） |
| 大头贴导出 | libspng 无损 PNG，文件名 `Zombatar_n.png` |
| Guetzli | 不接入游戏 |
| WIC | 不作为 Legacy 默认后端；仅保留为 Modern/诊断代码的系统备选 |

## WIC 是否老旧

WIC（Windows Imaging Component）是 Windows 的编解码器框架，不是一个独立的
“WIC 压缩算法”。它根据文件头选择系统注册的 JPEG/PNG 编解码器。WIC 的接口
成熟、兼容性好，但使用哪个具体实现取决于 Windows 版本和系统组件更新；它不会
自动把 PNG 换成新格式，也不会自动获得 Jpegli 的量化和 SIMD 优化。因此 Legacy
为了可复现和自包含，使用项目固定的库，而不是依赖系统 WIC。

## PNG

PNG 文件格式本身没有被替换成新的解压算法：标准流程仍是行滤波器加 DEFLATE
数据流（通常由 zlib 实现）。库的更新主要在边界检查、内存限制、滤波器选择和
SIMD 优化。libspng 不是新文件格式，而是一个 API 更小、输出格式明确的 libpng
替代实现；项目将它固定输出为 `SPNG_FMT_RGBA8`，再转换为内部的 `0xAARRGGBB`，
避免依赖旧版 libpng 的隐式 BGR 变换。

## JPEG

JPEG 标准核心仍是 DCT、量化、色彩变换和熵编码，但编码器/解码器实现一直在改进
量化矩阵、心理视觉模型、浮点精度和 SIMD。Jpegli 仍输出普通、可被旧查看器读取
的 JPEG，并兼容传统 `jpeglib` API；它使用更精确的浮点中间结果、自适应量化和
Highway SIMD。项目只把 libjpeg-turbo 的头文件作为 ABI 兼容输入，不链接其实现
代码。

## Guetzli 与 Jpegli

Guetzli 是“只编码、不解码”的离线压缩器。它可以在高质量下取得较小文件，但
计算量和内存量都很大，适合发布前一次性处理，不适合游戏运行时。

Jpegli 同时提供编码和解码。其解码路径与传统 SIMD JPEG 实现处于同一性能目标
范围，且保持 JPEG 互操作性；它的自适应量化启发式比 Guetzli 的同类搜索快得多。
所以本项目选 Jpegli 作为 JPG 编解码后端，完全不选 Guetzli。

参考：

- [Microsoft WIC 工作方式](https://learn.microsoft.com/en-us/windows/win32/wic/-wic-howwicworks)
- [PNG 第三版标准](https://www.w3.org/TR/png-3/)
- [Google Jpegli 介绍](https://opensource.googleblog.com/2024/04/introducing-jpegli-new-jpeg-coding-library.html)
- [Jpegli 源码](https://github.com/google/jpegli)
- [Guetzli 源码说明](https://github.com/google/guetzli)
