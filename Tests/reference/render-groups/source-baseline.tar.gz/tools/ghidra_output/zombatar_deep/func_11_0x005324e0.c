
void __thiscall FUN_005324e0(int param_1,CMFCCaptionButtonEx *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  CRect *pCVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  uint local_4c;
  undefined4 local_3c;
  uint local_38;
  undefined1 local_34 [4];
  undefined4 local_30;
  uint local_1c;
  void *pvStack_14;
  undefined1 *puStack_10;
  undefined4 local_c;
  
  local_c = 0xffffffff;
  puStack_10 = &LAB_006c8020;
  pvStack_14 = ExceptionList;
  ExceptionList = &pvStack_14;
  FUN_0045aec0(param_2);
  uVar1 = FUN_0059abc0();
  uVar2 = FUN_0059aba0();
  iVar5 = *(int *)(param_1 + 0x198);
  *(undefined4 *)(iVar5 + 8) = 0x28;
  *(undefined4 *)(iVar5 + 0xc) = 0x158;
  *(undefined4 *)(iVar5 + 0x10) = uVar2;
  *(undefined4 *)(iVar5 + 0x14) = uVar1;
  FUN_0044aac0(*(undefined4 *)(param_1 + 0x194));
  FUN_0044aac0(*(undefined4 *)(param_1 + 0x198));
  if (*(char *)(param_1 + 0x19c) != '\0') {
    pCVar3 = (CRect *)FUN_005615d0(0xff,0xff,0xff,*(undefined4 *)(param_1 + 0x1a0));
    CMFCCaptionButtonEx::SetRect(param_2,pCVar3);
    FUN_005983e0(1);
    FUN_00598a60(DAT_007266ec,0x1a4,0x122);
    FUN_005983e0(0);
  }
  local_80 = 0x32;
  local_7c = 0x82;
  local_78 = 0x1b3;
  local_74 = 0xa0;
  SetBorders(&local_80);
  uVar1 = *(undefined4 *)(param_1 + 0x1b0);
  local_38 = 0xf;
  local_3c = 0;
  local_4c = local_4c & 0xffffff00;
  FUN_004020c0("[ZOMBATAR_TOS]",0xe);
  local_c = 0;
  puVar4 = (undefined4 *)FUN_00561590(0xff,0xff,0xff);
  uVar2 = DAT_00726994;
  FUN_00523b90();
  local_c = CONCAT31(local_c._1_3_,1);
  local_70 = 0x32;
  local_68 = 0x1b3;
  local_64 = 0x4b0;
  local_6c = uVar1;
  iVar5 = FUN_005241c0(param_2,local_34,&local_70,uVar2,0,1,*puVar4,puVar4[1],puVar4[2],puVar4[3]);
  if (0xf < local_1c) {
    FUN_00699e4a(local_30);
  }
  *(int *)(param_1 + 0x1ac) = 0x104 - iVar5;
  if (0xf < local_38) {
    FUN_00699e4a(local_4c);
  }
  ExceptionList = pvStack_14;
  return;
}

