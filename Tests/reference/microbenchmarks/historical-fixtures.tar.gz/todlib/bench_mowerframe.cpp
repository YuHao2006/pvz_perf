// bench_mowerframe.cpp — 目标2：ReanimatorCache::MakeCachedMowerFrame
// FormA = ac447d19^ 改造前（4 case switch + default）
// FormB = HEAD 终态（kMowerFrameCases 4 槽 lambda 表 + 越界守卫）
// 输入：2M 均匀分布 LawnMowerType(0..3)，固定种子，两形态消费同一数组。
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <random>
#include <memory>

// ---------------- harness ----------------
static uint64_t g_cs = 0;
static inline void CsMix(uint64_t v) { g_cs = g_cs * 0x9E3779B97F4A7C15ull + v; }
static uint64_t QpcFreq() { static uint64_t f = 0; if (!f) { LARGE_INTEGER li; QueryPerformanceFrequency(&li); f = (uint64_t)li.QuadPart; } return f; }
static uint64_t QpcNow() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (uint64_t)c.QuadPart; }
static double QpcToNs(uint64_t ticks) { return (double)ticks * 1e9 / (double)QpcFreq(); }
#define TOD_ASSERT(...) ((void)0)

// ---------------- game type stubs ----------------
enum LawnMowerType { LAWNMOWER_LAWN, LAWNMOWER_POOL, LAWNMOWER_ROOF, LAWNMOWER_SUPER_MOWER, NUM_MOWER_TYPES };
enum DrawVariation { VARIATION_NORMAL };
enum ReanimTrackId { None = 0, anim_normal, anim_tricked };
enum ReanimationType { REANIM_NONE, REANIM_LAWNMOWER, REANIM_POOL_CLEANER, REANIM_ROOF_CLEANER };

class Image { public: int mPad; };
class MemoryImage : public Image { public: };

class Graphics
{
public:
    float mScaleX, mScaleY;
    Image* mImage;
    Graphics(Image* theImage) : mScaleX(1.0f), mScaleY(1.0f), mImage(theImage) {}
    void SetLinearBlend(bool theBlend) { CsMix(21); CsMix(theBlend ? 1 : 0); }
};

class ReanimatorCache
{
public:
    MemoryImage* MakeBlankMemoryImage(int theWidth, int theHeight)
    {
        CsMix(22); CsMix((uint64_t)theWidth * 1000 + (uint64_t)theHeight);
        return new MemoryImage();
    }
    void DrawReanimatorFrame(Graphics* g, float thePosX, float thePosY, ReanimationType theReanimationType, ReanimTrackId theTrackId, DrawVariation theDrawVariation)
    {
        CsMix(23);
        CsMix(((uint64_t)(thePosX * 16.0f) << 44) ^ ((uint64_t)theReanimationType << 32) ^ ((uint64_t)theTrackId << 20)
            ^ ((uint64_t)theDrawVariation << 12) ^ (uint64_t)(g->mScaleX * 64.0f));
    }

    MemoryImage* MakeCachedMowerFrame_A(LawnMowerType theMowerType);
    MemoryImage* MakeCachedMowerFrame_B(LawnMowerType theMowerType);
};

// ================= FormA：改造前（ac447d19^ 逐字） =================
__declspec(noinline) MemoryImage* ReanimatorCache::MakeCachedMowerFrame_A(LawnMowerType theMowerType)
{
	std::unique_ptr<MemoryImage> aImage;

	switch (theMowerType)
	{
	case LawnMowerType::LAWNMOWER_LAWN:
	{
		aImage.reset(MakeBlankMemoryImage(90, 100));
		Graphics aMemoryGraphics(aImage.get());
		aMemoryGraphics.SetLinearBlend(true);
		aMemoryGraphics.mScaleX = 0.85f;
		aMemoryGraphics.mScaleY = 0.85f;
		DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 0.0f, ReanimationType::REANIM_LAWNMOWER, ReanimTrackId::anim_normal, DrawVariation::VARIATION_NORMAL);
		break;
	}
	case LawnMowerType::LAWNMOWER_POOL:
	{
		aImage.reset(MakeBlankMemoryImage(90, 100));
		Graphics aMemoryGraphics(aImage.get());
		aMemoryGraphics.SetLinearBlend(true);
		aMemoryGraphics.mScaleX = 0.8f;
		aMemoryGraphics.mScaleY = 0.8f;
		DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 25.0f, ReanimationType::REANIM_POOL_CLEANER, ReanimTrackId::None, DrawVariation::VARIATION_NORMAL);
		break;
	}
	case LawnMowerType::LAWNMOWER_ROOF:
	{
		aImage.reset(MakeBlankMemoryImage(90, 100));
		Graphics aMemoryGraphics(aImage.get());
		aMemoryGraphics.SetLinearBlend(true);
		aMemoryGraphics.mScaleX = 0.85f;
		aMemoryGraphics.mScaleY = 0.85f;
		DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 0.0f, ReanimationType::REANIM_ROOF_CLEANER, ReanimTrackId::None, DrawVariation::VARIATION_NORMAL);
		break;
	}
	case LawnMowerType::LAWNMOWER_SUPER_MOWER:
	{
		aImage.reset(MakeBlankMemoryImage(90, 100));
		Graphics aMemoryGraphics(aImage.get());
		aMemoryGraphics.SetLinearBlend(true);
		aMemoryGraphics.mScaleX = 0.85f;
		aMemoryGraphics.mScaleY = 0.85f;
		DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 0.0f, ReanimationType::REANIM_LAWNMOWER, ReanimTrackId::anim_tricked, DrawVariation::VARIATION_NORMAL);
		break;
	}
	default:
		TOD_ASSERT(false);
		break;
	}

	return aImage.release();
}

// ================= FormB：当前终态（HEAD 逐字） =================
namespace
{
using MowerFrameCaseFn = void (*)(ReanimatorCache&, std::unique_ptr<MemoryImage>&);

void MowerFrameDefault(ReanimatorCache& rc, std::unique_ptr<MemoryImage>& aImage)
{
    		TOD_ASSERT(false);
}

constexpr MowerFrameCaseFn kMowerFrameCases[(int)LawnMowerType::NUM_MOWER_TYPES] = {
    [](ReanimatorCache& rc, std::unique_ptr<MemoryImage>& aImage)
    {
    		aImage.reset(rc.MakeBlankMemoryImage(90, 100));
    		Graphics aMemoryGraphics(aImage.get());
    		aMemoryGraphics.SetLinearBlend(true);
    		aMemoryGraphics.mScaleX = 0.85f;
    		aMemoryGraphics.mScaleY = 0.85f;
    		rc.DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 0.0f, ReanimationType::REANIM_LAWNMOWER, ReanimTrackId::anim_normal, DrawVariation::VARIATION_NORMAL);
    },  // 0 LAWNMOWER_LAWN
    [](ReanimatorCache& rc, std::unique_ptr<MemoryImage>& aImage)
    {
    		aImage.reset(rc.MakeBlankMemoryImage(90, 100));
    		Graphics aMemoryGraphics(aImage.get());
    		aMemoryGraphics.SetLinearBlend(true);
    		aMemoryGraphics.mScaleX = 0.8f;
    		aMemoryGraphics.mScaleY = 0.8f;
    		rc.DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 25.0f, ReanimationType::REANIM_POOL_CLEANER, ReanimTrackId::None, DrawVariation::VARIATION_NORMAL);
    },  // 1 LAWNMOWER_POOL
    [](ReanimatorCache& rc, std::unique_ptr<MemoryImage>& aImage)
    {
    		aImage.reset(rc.MakeBlankMemoryImage(90, 100));
    		Graphics aMemoryGraphics(aImage.get());
    		aMemoryGraphics.SetLinearBlend(true);
    		aMemoryGraphics.mScaleX = 0.85f;
    		aMemoryGraphics.mScaleY = 0.85f;
    		rc.DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 0.0f, ReanimationType::REANIM_ROOF_CLEANER, ReanimTrackId::None, DrawVariation::VARIATION_NORMAL);
    },  // 2 LAWNMOWER_ROOF
    [](ReanimatorCache& rc, std::unique_ptr<MemoryImage>& aImage)
    {
    		aImage.reset(rc.MakeBlankMemoryImage(90, 100));
    		Graphics aMemoryGraphics(aImage.get());
    		aMemoryGraphics.SetLinearBlend(true);
    		aMemoryGraphics.mScaleX = 0.85f;
    		aMemoryGraphics.mScaleY = 0.85f;
    		rc.DrawReanimatorFrame(&aMemoryGraphics, 10.0f, 0.0f, ReanimationType::REANIM_LAWNMOWER, ReanimTrackId::anim_tricked, DrawVariation::VARIATION_NORMAL);
    },  // 3 LAWNMOWER_SUPER_MOWER
};
static_assert(sizeof(kMowerFrameCases) / sizeof(kMowerFrameCases[0]) ==
    (int)LawnMowerType::NUM_MOWER_TYPES, "kMowerFrameCases 槽位数须与 LawnMowerType 枚举同步");
}  // namespace

__declspec(noinline) MemoryImage* ReanimatorCache::MakeCachedMowerFrame_B(LawnMowerType theMowerType)
{
	std::unique_ptr<MemoryImage> aImage;

	const unsigned aMowerIndex = static_cast<unsigned>(theMowerType);
	if (aMowerIndex < static_cast<unsigned>(LawnMowerType::NUM_MOWER_TYPES))
	{
		kMowerFrameCases[aMowerIndex](*this, aImage);
	}
	else
	{
		MowerFrameDefault(*this, aImage);
	}


	return aImage.release();
}

// ---------------- bench driver ----------------
static const int N = 2000000;
static int g_input[N];

template <typename F>
static inline uint64_t TimedPass(F&& f)
{
    uint64_t t0 = QpcNow();
    f();
    uint64_t t1 = QpcNow();
    return t1 - t0;
}

int main()
{
    std::mt19937 rng(20261002);
    std::uniform_int_distribution<int> dist(0, (int)LawnMowerType::LAWNMOWER_SUPER_MOWER);
    for (int k = 0; k < N; k++) g_input[k] = dist(rng);

    ReanimatorCache rc;

    // ---- checksum pass ----
    g_cs = 0;
    for (int k = 0; k < N; k++) { MemoryImage* p = rc.MakeCachedMowerFrame_A((LawnMowerType)g_input[k]); CsMix((uint64_t)g_input[k]); delete p; }
    uint64_t csA = g_cs;

    g_cs = 0;
    for (int k = 0; k < N; k++) { MemoryImage* p = rc.MakeCachedMowerFrame_B((LawnMowerType)g_input[k]); CsMix((uint64_t)g_input[k]); delete p; }
    uint64_t csB = g_cs;

    bool csOK = (csA == csB);

    // ---- warmup ----
    for (int k = 0; k < 10000; k++) { delete rc.MakeCachedMowerFrame_A((LawnMowerType)g_input[k]); delete rc.MakeCachedMowerFrame_B((LawnMowerType)g_input[k]); }

    // ---- timing：min-of-5，A/B 交错 ----
    uint64_t aMin = UINT64_MAX, bMin = UINT64_MAX;
    for (int rep = 0; rep < 5; rep++)
    {
        aMin = std::min(aMin, TimedPass([&] { for (int k = 0; k < N; k++) { MemoryImage* p = rc.MakeCachedMowerFrame_A((LawnMowerType)g_input[k]); CsMix((uint64_t)g_input[k]); delete p; } }));
        bMin = std::min(bMin, TimedPass([&] { for (int k = 0; k < N; k++) { MemoryImage* p = rc.MakeCachedMowerFrame_B((LawnMowerType)g_input[k]); CsMix((uint64_t)g_input[k]); delete p; } }));
    }

    double nsA = QpcToNs(aMin) / N;
    double nsB = QpcToNs(bMin) / N;
    double diff = (nsB - nsA) / nsA * 100.0;
    printf("MakeCachedMowerFrame | before %.2f ns | after %.2f ns | diff %+.2f%% | checksum=%s (A=%016llx B=%016llx)\n",
        nsA, nsB, diff, csOK ? "OK" : "FAIL", (unsigned long long)csA, (unsigned long long)csB);
    return csOK ? 0 : 1;
}
