
undefined4 __thiscall FUN_0054cf00(int param_1,undefined4 param_2)

{
  FUN_00401a90((*(int *)(param_1 + 0x48) - *(int *)(param_1 + 0x84)) - *(int *)(param_1 + 0x8c),
               (*(int *)(param_1 + 0x4c) - *(int *)(param_1 + 0x88)) - *(int *)(param_1 + 0x90));
  return param_2;
}

