//#define SEXY_TRACING_ENABLED
//#define SEXY_PERF_ENABLED
//#define SEXY_MEMTRACE

#include "SexyAppBase.h"
#include "misc/SEHCatcher.h"
#include "widget/WidgetManager.h"
#include "widget/Widget.h"
#include "misc/Debug.h"
#include "misc/KeyCodes.h"
#include "misc/LegacyRuntimeTrace.h"
#include "effect/ScaleEffectRuntime.h"
#include "misc/StableTime.h"
#include "misc/XMLParser.h"
#include "graphics/DDInterface.h"
#include "graphics/D3DInterface.h"
#include "graphics/D3DTester.h"
#include "graphics/DDImage.h"
#include "graphics/MemoryImage.h"
#include "widget/Dialog.h"
#include "imagelib/ImageLib.h"
#include "sound/DSoundManager.h"
#include "sound/DSoundInstance.h"
#include "misc/Rect.h"
#include "misc/PropertiesParser.h"
#include "misc/PerfTimer.h"
#include "misc/MTRand.h"
#include "misc/ModVal.h"
#include <process.h>
#include <cerrno>
#include <cmath>
#include <direct.h>
#include <fstream>
#include <time.h>
#include <math.h>
#include <regstr.h>
#include <cstdlib>
#include "graphics/SysFont.h"
#include "misc/ResourceManager.h"
#include "../Sexy.TodLib/Reanimator.h"
#include "sound/BassMusicInterface.h"
#include "misc/AutoCrit.h"
#include "misc/Debug.h"
#include "paklib/PakInterface.h"
#include <string>
#include <shlobj.h>

#pragma comment(lib, "imagehlp.lib")
#pragma comment(lib, "dxgi.lib")
#include "sound/DummyMusicInterface.h"

#include "misc/memmgr.h"

using namespace Sexy;

namespace
{
void LegacyStartupProbe(const char* theStage)
{
	if (std::getenv("PVZ_STARTUP_PROBE") == nullptr)
		return;
	FILE* aFile = fopen(GetLogFilePath("startup-probe.log").c_str(), "a");
	if (aFile == nullptr)
		return;
	fprintf(aFile, "%s\n", theStage != nullptr ? theStage : "<null>");
	fclose(aFile);
}
}

const int DEMO_FILE_ID = 0x42BEEF78;
const int DEMO_VERSION = 2;

SexyAppBase* Sexy::gSexyAppBase = NULL;

SEHCatcher Sexy::gSEHCatcher;

HMODULE gDDrawDLL = NULL;
HMODULE gDSoundDLL = NULL;
HMODULE gVersionDLL = NULL;

// The legacy renderer calls the operating system's DirectDraw 7 entry points
// directly.  Do not let a ddraw.dll next to the executable replace that API
// with a compatibility implementation.
static HMODULE LoadSystemLibrary(const char* theName)
{
	char aSystemDirectory[MAX_PATH] = {};
	UINT aLength = GetSystemDirectoryA(aSystemDirectory, ARRAYSIZE(aSystemDirectory));
	if (aLength == 0 || aLength >= ARRAYSIZE(aSystemDirectory))
		return NULL;

	std::string aPath(aSystemDirectory, aLength);
	aPath += '\\';
	aPath += theName;
	return LoadLibraryA(aPath.c_str());
}

//typedef struct { UINT cbSize; DWORD dwTime; } LASTINPUTINFO;
typedef BOOL (WINAPI*GetLastInputInfoFunc)(LASTINPUTINFO *plii);
GetLastInputInfoFunc gGetLastInputInfoFunc = NULL;
static bool gScreenSaverActive = false;

#ifndef SPI_GETSCREENSAVERRUNNING
#define SPI_GETSCREENSAVERRUNNING 114
#endif


//HotSpot: 11 4
//Size: 32 32
unsigned char gFingerCursorData[] = {
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
	0xff, 0xff, 0xe7, 0xff, 0xff, 0xff, 0xc3, 0xff, 0xff, 0xff, 0xc3, 0xff, 0xff, 0xff, 0xc3, 
	0xff, 0xff, 0xff, 0xc3, 0xff, 0xff, 0xff, 0xc0, 0xff, 0xff, 0xff, 0xc0, 0x1f, 0xff, 0xff, 
	0xc0, 0x07, 0xff, 0xff, 0xc0, 0x03, 0xff, 0xfc, 0x40, 0x01, 0xff, 0xfc, 0x00, 0x01, 0xff, 
	0xfc, 0x00, 0x01, 0xff, 0xfc, 0x00, 0x01, 0xff, 0xff, 0x00, 0x01, 0xff, 0xff, 0x00, 0x01, 
	0xff, 0xff, 0x80, 0x01, 0xff, 0xff, 0x80, 0x03, 0xff, 0xff, 0xc0, 0x03, 0xff, 0xff, 0xc0, 
	0x03, 0xff, 0xff, 0xe0, 0x07, 0xff, 0xff, 0xe0, 0x07, 0xff, 0xff, 0xe0, 0x07, 0xff, 0xff, 
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 
	0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 
	0x18, 0x00, 0x00, 0x00, 0x1b, 0x00, 0x00, 0x00, 0x1b, 0x60, 0x00, 0x00, 0x1b, 0x68, 0x00, 
	0x00, 0x1b, 0x6c, 0x00, 0x01, 0x9f, 0xec, 0x00, 0x01, 0xdf, 0xfc, 0x00, 0x00, 0xdf, 0xfc, 
	0x00, 0x00, 0x5f, 0xfc, 0x00, 0x00, 0x7f, 0xfc, 0x00, 0x00, 0x3f, 0xfc, 0x00, 0x00, 0x3f, 
	0xf8, 0x00, 0x00, 0x1f, 0xf8, 0x00, 0x00, 0x1f, 0xf8, 0x00, 0x00, 0x0f, 0xf0, 0x00, 0x00, 
	0x0f, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00
};

//HotSpot: 15 10
//Size: 32 32
unsigned char gDraggingCursorData[] = {
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
	0xff, 0xff, 0xfe, 0x7f, 0xff, 0xff, 0xfc, 0x0f, 0xff, 0xff, 0xf0, 0x07, 0xff, 0xff, 0xe0, 
	0x01, 0xff, 0xff, 0xe0, 0x00, 0xff, 0xff, 0xe0, 0x00, 0xff, 0xff, 0xe0, 0x00, 0xff, 0xff, 
	0xe0, 0x00, 0xff, 0xfe, 0x60, 0x00, 0xff, 0xfc, 0x20, 0x00, 0xff, 0xfc, 0x00, 0x00, 0xff, 
	0xfe, 0x00, 0x00, 0xff, 0xfe, 0x00, 0x00, 0xff, 0xff, 0x00, 0x00, 0xff, 0xff, 0x80, 0x00, 
	0xff, 0xff, 0x80, 0x01, 0xff, 0xff, 0xc0, 0x01, 0xff, 0xff, 0xe0, 0x01, 0xff, 0xff, 0xf0, 
	0x03, 0xff, 0xff, 0xf8, 0x03, 0xff, 0xff, 0xf8, 0x03, 0xff, 0xff, 0xf8, 0x03, 0xff, 0xff, 
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 
	0x80, 0x00, 0x00, 0x01, 0xb0, 0x00, 0x00, 0x0d, 0xb0, 0x00, 0x00, 0x0d, 0xb6, 0x00, 0x00, 
	0x0d, 0xb6, 0x00, 0x00, 0x0d, 0xb6, 0x00, 0x00, 0x0d, 0xb6, 0x00, 0x00, 0x0d, 0xb6, 0x00, 
	0x01, 0x8d, 0xb6, 0x00, 0x01, 0xcf, 0xfe, 0x00, 0x00, 0xef, 0xfe, 0x00, 0x00, 0xff, 0xfe, 
	0x00, 0x00, 0x7f, 0xfe, 0x00, 0x00, 0x3f, 0xfe, 0x00, 0x00, 0x3f, 0xfc, 0x00, 0x00, 0x1f, 
	0xfc, 0x00, 0x00, 0x0f, 0xfc, 0x00, 0x00, 0x07, 0xf8, 0x00, 0x00, 0x03, 0xf8, 0x00, 0x00, 
	0x03, 0xf8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00
};
static DDImage* gFPSImage = NULL; 

//////////////////////////////////////////////////////////////////////////

typedef HRESULT (WINAPI *SHGetFolderPathFunc)(HWND, int, HANDLE, DWORD, LPTSTR);
void* GetSHGetFolderPath(const char* theDLL, HMODULE* theMod)
{
	HMODULE aMod = LoadLibrary(theDLL);
	SHGetFolderPathFunc aFunc = NULL;

	if (aMod != NULL)
	{
		*((void**)&aFunc) = (void*)GetProcAddress(aMod, "SHGetFolderPathA");
		if (aFunc == NULL)
		{
			FreeLibrary(aMod);
			aMod = NULL;
		}
	}	

	*theMod = aMod;
	return (void *)aFunc;
}

//////////////////////////////////////////////////////////////////////////

SexyAppBase::SexyAppBase()
{
	LegacyStartupProbe("SexyAppBase::SexyAppBase begin");
	gSexyAppBase = this;

	gVersionDLL = LoadLibraryA("version.dll");
	gDDrawDLL = LoadSystemLibrary("ddraw.dll");
	gDSoundDLL = LoadLibraryA("dsound.dll");
	LegacyStartupProbe(gDDrawDLL != nullptr && gDSoundDLL != nullptr ?
		"SexyAppBase DLLs loaded" : "SexyAppBase DLL load failed");
	gGetLastInputInfoFunc = (GetLastInputInfoFunc) GetProcAddress(GetModuleHandleA("user32.dll"),"GetLastInputInfo");

	//ImageLib::InitJPEG2000();

	mMutex = NULL;
	mNotifyGameMessage = 0;

#ifdef _DEBUG
	mOnlyAllowOneCopyToRun = false;
#else
	mOnlyAllowOneCopyToRun = true;
#endif

	// Extract product version
	char aPath[_MAX_PATH];
	GetModuleFileNameA(NULL, aPath, 256);
	mProductVersion = GetProductVersion(aPath);	
	mChangeDirTo = GetFileDir(aPath);

	mNoDefer = false;	
	mFullScreenPageFlip = true; // should we page flip in fullscreen?
	mTimeLoaded = GetTickCount();
	mSEHOccured = false;
	mProdName = "Product";
	mTitle = _S("SexyApp");
	mShutdown = false;
	mExitToTop = false;
	mWidth = 640;
	mHeight = 480;
	mFullscreenBits = 16;
	mIsWindowed = true;
	mIsPhysWindowed = true;
	mFullScreenWindow = false;
	mPreferredX = -1;
	mPreferredY = -1;
	mIsScreenSaver = false;
	mAllowMonitorPowersave = true;
	mHWnd = NULL;
	mDDInterface = NULL;	
	mMusicInterface = NULL;
	mInvisHWnd = NULL;
	mUseExternalHWND = false;
	mExternalHWND = NULL;
	mFrameTime = 10;
	mNonDrawCount = 0;
	mDrawCount = 0;
	mSleepCount = 0;
	mUpdateCount = 0;	
	mUpdateAppState = 0;
	mUpdateAppDepth = 0;
	mPendingUpdatesAcc = 0.0;
	mUpdateFTimeAcc = 0.0;
	mHasPendingDraw = true;
	mIsDrawing = false;
	mLastDrawWasEmpty = false;	
	mLastTimeCheck = 0;
	mUpdateMultiplier = 1;
	mPaused = false;
	mFastForwardToUpdateNum = 0;
	mFastForwardToMarker = false;
	mFastForwardStep = false;
	mSoundManager = NULL;
	mCursorNum = CURSOR_POINTER;		
	mMouseIn = false;
	mRunning = false;
	mActive = true;
	mProcessInTimer = false;
	mMinimized = false;	
	mPhysMinimized = false;
	mIsDisabled = false;
	mLoaded = false;	
	mYieldMainThread = false; 
	mLoadingFailed = false;	
	mLoadingThreadStarted = false;
	mAutoStartLoadingThread = true;
	mLoadingThreadCompleted = false;
	mCursorThreadRunning = false;
	mWatchdogLastTick = 0;
	mWatchdogStop = false;
	mWatchdogThread = NULL;
	mNumLoadingThreadTasks = 0;
	mCompletedLoadingThreadTasks = 0;	
	mLastDrawTick = SexyGetTickCount();
	// These clocks are read by the first pre-Start frame.  Leaving them
	// uninitialized lets the screen-saver probe suppress the title screen
	// before Start() has a chance to establish the real input epoch.
	mLastUserInputTick = mLastDrawTick;
	mLastTimerTime = mLastDrawTick;
	mNextDrawTick = SexyGetTickCount();
	mSysCursor = true;	
	mForceFullscreen = false;
	mForceWindowed = false;
	mHasFocus = true;			
	mCustomCursorsEnabled = false;	
	mCustomCursorDirty = false;
	mOverrideCursor = NULL;
	mInitialized = false;	
	mLastShutdownWasGraceful = true;	
	mReadFromRegistry = false;	
	mCmdLineParsed = false;
	mSkipSignatureChecks = false;	
	mCtrlDown = false;
	mAltDown = false;
	mAllowAltEnter = true;
	mStepMode = 0;
	mCleanupSharedImages = false;
	mStandardWordWrap = true;
	mbAllowExtendedChars = true;
	mEnableMaximizeButton = false;
	mMusicVolume = 0.85;
	mSfxVolume = 0.85;
	mDemoMusicVolume = mDemoSfxVolume = 0.0;
	mMuteCount = 0;	
	mAutoMuteCount = 0;
	mDemoMute = false;
	mMuteOnLostFocus = true;
	mCurHandleNum = 0;
	mFPSTime = 0;
	mFPSStartTick = GetTickCount();
	mFPSFlipCount = 0;
	mFPSCount = 0;
	mFPSDirtyCount = 0;
	mShowFPS = false;
	mShowFPSMode = FPS_ShowFPS;
	mDrawTime = 0;
	mScreenBltTime = 0;
	mAlphaDisabled = false;	
	mDebugKeysEnabled = false;
	mOldWndProc = 0;
	mNoSoundNeeded = false;

	mSyncRefreshRate = 100;
	mVSyncUpdates = false;
	mVSyncBroken = false;
	mVSyncBrokenCount = 0;
	mVSyncBrokenTestStartTick = 0;
	mVSyncBrokenTestUpdates = 0;
	mWaitForVSync = false;
	mSoftVSyncWait = true;
	mUserChanged3DSetting = false;
	mAutoEnable3D = false;
	mTest3D = false;
	mMinVidMemory3D = 6;
	mRecommendedVidMemory3D = 14;
	mRelaxUpdateBacklogCount = 0;
	mWidescreenAware = false;
	mEnableWindowAspect = false;
	mWindowAspect.Set(4, 3);
	mWindowScale = 2;
	mUseCustomScale = true;
	mScaleConfigWindow = 2;
	mScaleConfigFullscreenWidth = 0;
	mScaleConfigFullscreenHeight = 0;
	mScaleWindowConfig.mOutputWidth = 0;
	mScaleWindowConfig.mOutputHeight = 0;
	mScaleFullscreenConfig.mOutputWidth = 0;
	mScaleFullscreenConfig.mOutputHeight = 0;
	mScaleSharedTexture = NULL;
	mScaleSharedHandle = NULL;
	mScaleSwapChain = NULL;
	mScaleSwapWidth = 0;
	mScaleSwapHeight = 0;
	mIsWideWindow = false;

	int i;

	for (i = 0; i < NUM_CURSORS; i++)
		mCursorImages[i] = NULL;	

	for (i = 0; i < 256; i++)
		mAdd8BitMaxTable[i] = i;

	for (i = 256; i < 512; i++)
		mAdd8BitMaxTable[i] = 255;
	
	// Set default strings.  Init could read in overrides from partner.xml
	SetString("DIALOG_BUTTON_OK",		L"OK");
	SetString("DIALOG_BUTTON_CANCEL",	L"CANCEL");

	mDemoPrefix = "sexyapp";
	mDemoFileName = mDemoPrefix + ".dmo";
	mPlayingDemoBuffer = false;
	mManualShutdown = false;
	mRecordingDemoBuffer = false;
	mLastDemoMouseX = 0;
	mLastDemoMouseY = 0;
	mLastDemoUpdateCnt = 0;
	mDemoNeedsCommand = true;
	mDemoLoadingComplete = false;
	mDemoLength = 0;
	mDemoCmdNum = 0;
	mDemoCmdOrder = -1; // Means we haven't processed any demo commands yet
	mDemoCmdBitPos = 0;

	mWidgetManager = new WidgetManager(this);
	mResourceManager = new ResourceManager(this);

	mPrimaryThreadId = 0;

	if (GetSystemMetrics(86)) // check for tablet pc
	{
		mTabletPC = true;
		mFullScreenPageFlip = false; // so that tablet keyboard can show up
	}
	else
		mTabletPC = false;	

	gSEHCatcher.mApp = this;	
	
	//std::wifstream stringsFile(_wfopen(L".\\properties\\fstrings", L"rb"));
	//
	//if(!stringsFile)
	//{
	//	MessageBox(NULL, "file missing: 'install-folder\\properties\\fstrings' Please re-install", "FATAL ERROR", MB_OK);
	//	DoExit(1);
	//}
	//std::getline(stringsFile, mString_HardwareAccelSwitchedOn);
	//std::getline(stringsFile, mString_HardwareAccelConfirm);
	//std::getline(stringsFile, mString_HardwareAccelNotWorking);
	//std::getline(stringsFile, mString_SetColorDepth);
	//std::getline(stringsFile, mString_FailedInitDirectDrawColon);
	//std::getline(stringsFile, mString_UnableOpenProperties);
	//std::getline(stringsFile, mString_SigCheckFailed);
	//std::getline(stringsFile, mString_InvalidCommandLineParam);
	//std::getline(stringsFile, mString_RequiresDirectX);
	//std::getline(stringsFile, mString_YouNeedDirectX);
	//std::getline(stringsFile, mString_FailedInitDirectDraw);
	//std::getline(stringsFile, mString_FatalError);
	//std::getline(stringsFile, mString_UnexpectedErrorOccured);
	//std::getline(stringsFile, mString_PleaseHelpBy);
	//std::getline(stringsFile, mString_FailedConnectPopcap);
	//stringsFile.close();
}

SexyAppBase::~SexyAppBase()
{
	Shutdown();

	// Check if we should write the current 3d setting
	bool showedMsgBox = false;
	if (mUserChanged3DSetting)
	{
		bool writeToRegistry = true;
		bool is3D = false;
		bool is3DOptionSet = RegistryReadBoolean("Is3D", &is3D);
		if(!is3DOptionSet) // should we write the option?
		{
			if(!Is3DAccelerationRecommended()) // may need to prompt user if he wants to keep 3d acceleration on
			{
				if (Is3DAccelerated())
				{
					showedMsgBox = true;
					int aResult = MessageBox(NULL,
									GetString("HARDWARE_ACCEL_SWITCHED_ON", 
															_S("Hardware Acceleration was switched on during this session.\r\n")
															_S("If this resulted in slower performance, it should be switched off.\r\n")
															_S("Would you like to keep Hardware Acceleration switched on?")).c_str(),
									(StringToSexyString(mCompanyName) + _S(" ") +
									 GetString("HARDWARE_ACCEL_CONFIRMATION", _S("Hardware Acceleration Confirmation"))).c_str(),
									MB_YESNO | MB_ICONQUESTION);

					mDDInterface->mIs3D = aResult == IDYES ? true : false;
					if (aResult!=IDYES)
						writeToRegistry = false;
				}
				else
					writeToRegistry = false;
			}
		}

		if (writeToRegistry)
		{
			// 3D acceleration is always on in this port; nothing to persist.
		}
	}

	if (!showedMsgBox && gD3DInterfacePreDrawError && !IsScreenSaver())
	{
		int aResult = MessageBox(NULL, 
						GetString("HARDWARE_ACCEL_NOT_WORKING", 
									_S("Hardware Acceleration may not have been working correctly during this session.\r\n")
									_S("If you noticed graphics problems, you may want to turn off Hardware Acceleration.\r\n")
									_S("Would you like to keep Hardware Acceleration switched on?")).c_str(),
						(StringToSexyString(mCompanyName) + _S(" ") +
						 GetString("HARDWARE_ACCEL_CONFIRMATION", _S("Hardware Acceleration Confirmation"))).c_str(),
						MB_YESNO | MB_ICONQUESTION);

		if (aResult == IDNO)
		{
			// 3D acceleration is always on; no registry write.
		}
	}


	DialogMap::iterator aDialogItr = mDialogMap.begin();
	while (aDialogItr != mDialogMap.end())
	{
		mWidgetManager->RemoveWidget(aDialogItr->second);
		delete aDialogItr->second;
		++aDialogItr;
	}
	mDialogMap.clear();
	mDialogList.clear();
	
	if (mInvisHWnd != NULL)
	{
		HWND aWindow = mInvisHWnd;
		mInvisHWnd = NULL;
		SetWindowLongPtr(aWindow, GWLP_USERDATA, 0);
		DestroyWindow(aWindow);
	}	
	
	delete mWidgetManager;	
	delete mResourceManager;
	delete gFPSImage;
	gFPSImage = NULL;
	
	SharedImageMap::iterator aSharedImageItr = mSharedImageMap.begin();
	while (aSharedImageItr != mSharedImageMap.end())
	{
		SharedImage* aSharedImage = &aSharedImageItr->second;
		DBG_ASSERTE(aSharedImage->mRefCount == 0);		
		delete aSharedImage->mImage;
		mSharedImageMap.erase(aSharedImageItr++);		
	}
	
	delete mDDInterface;
	delete mMusicInterface;
	delete mSoundManager;			

	if (mHWnd != NULL)
	{
		HWND aWindow = mHWnd;
		mHWnd = NULL;
		
		SetWindowLongPtr(aWindow, GWLP_USERDATA, 0);

		/*char aStr[256];
		sprintf(aStr, "HWND: %d\r\n", aWindow);
		OutputDebugString(aStr);*/
				
		DestroyWindow(aWindow);
	}	
	
	WaitForLoadingThread();	

	DestroyCursor(mHandCursor);
	DestroyCursor(mDraggingCursor);			

	gSexyAppBase = NULL;

	WriteDemoBuffer();

	if (mMutex != NULL)
		::CloseHandle(mMutex);	

	FreeLibrary(gDDrawDLL);
	FreeLibrary(gDSoundDLL);
	FreeLibrary(gVersionDLL);
}

static BOOL CALLBACK ChangeDisplayWindowEnumProc(HWND hwnd, LPARAM lParam)
{
	typedef std::map<HWND,RECT> WindowMap;
	static WindowMap aMap;

	if (lParam==0 && aMap.find(hwnd)==aMap.end()) // record
	{
		RECT aRect;
		if (!IsIconic(hwnd) && IsWindowVisible(hwnd))
		{
			if (GetWindowRect(hwnd,&aRect))
			{
//				char aBuf[4096];
//				GetWindowText(hwnd,aBuf,4000);
//				DWORD aProcessId = 0;
//				GetWindowThreadProcessId(hwnd,&aProcessId);
//				SEXY_TRACE(StrFormat("%s %d - %d %d %d %d",aBuf,aProcessId,aRect.left,aRect.top,aRect.right,aRect.bottom).c_str());
				aMap[hwnd] = aRect;
			}
		}
	}
	else 
	{
		WindowMap::iterator anItr = aMap.find(hwnd);
		if (anItr != aMap.end())
		{
			RECT &r = anItr->second;
			MoveWindow(hwnd,r.left,r.top,abs(r.right-r.left),abs(r.bottom-r.top),TRUE);
		}
	}
	return TRUE;
}

void SexyAppBase::ClearUpdateBacklog(bool relaxForASecond)
{
	mLastTimeCheck = SexyGetTickCount();
	mUpdateFTimeAcc = 0.0;

	if (relaxForASecond)
		mRelaxUpdateBacklogCount = 1000;
}

bool SexyAppBase::IsScreenSaver()
{
	return mIsScreenSaver;
}

bool SexyAppBase::AppCanRestore()
{
	return !mIsDisabled;
}

bool SexyAppBase::ReadDemoBuffer(std::string &theError)
{
	FILE* aFP = fopen(mDemoFileName.c_str(), "rb");

	if (aFP == NULL)
	{
		theError = "Demo file not found: " + mDemoFileName;
		return false;
	}

	struct AutoFile { FILE *f; AutoFile(FILE *file) : f(file) {} ~AutoFile() { fclose(f); } };
	AutoFile aCloseFile(aFP);

	ulong aFileID;
	fread(&aFileID, 4, 1, aFP);

	DBG_ASSERTE(aFileID == DEMO_FILE_ID);
	if (aFileID != DEMO_FILE_ID)
	{
		theError = "Invalid demo file.";
		return false;
	}


	ulong aVersion;
	fread(&aVersion, 4, 1, aFP);
	
	fread(&mRandSeed, 4, 1, aFP);
	SRand(mRandSeed);

	ushort aStrLen = 4;
	fread(&aStrLen, 2, 1, aFP);
	if (aStrLen > 255)
		aStrLen = 255;
	char aStr[256];
	fread(aStr, 1, aStrLen, aFP);
	aStr[aStrLen] = '\0';

	DBG_ASSERTE(mProductVersion == aStr);
	if (mProductVersion != aStr)
	{
		theError = "This demo file appears to be for '" + std::string(aStr) + "'";
		return false;
	}

	int aFilePos = ftell(aFP);
	fseek(aFP, 0, SEEK_END);
	int aBytesLeft = ftell(aFP) - aFilePos;
	fseek(aFP, aFilePos, SEEK_SET);

	uchar* aBuffer;
	// read marker list
	if (aVersion >= 2) 
	{
		int aSize;
		fread(&aSize, 4, 1, aFP);
		aBytesLeft -= 4;

		if (aSize >= aBytesLeft)
		{
			theError = "Invalid demo file.";
			return false;
		}

		Buffer aMarkerBuffer;

		aBuffer = new uchar[aSize];
		fread(aBuffer, 1, aSize, aFP);
		aMarkerBuffer.WriteBytes(aBuffer, aSize);
		aMarkerBuffer.SeekFront();

		int aNumItems = aMarkerBuffer.ReadLong();
		int i;
		for (i=0; i<aNumItems && !aMarkerBuffer.AtEnd(); i++)
		{
			mDemoMarkerList.push_back(DemoMarker());
			DemoMarker &aMarker = mDemoMarkerList.back();
			aMarker.first = aMarkerBuffer.ReadString();
			aMarker.second = aMarkerBuffer.ReadLong();
		}

		if (i!=aNumItems)
		{
			theError = "Invalid demo file.";
			return false;
		}

		aBytesLeft -= aSize;

		delete [] aBuffer;			
	}

	// Read demo commands
	fread(&mDemoLength, 4, 1, aFP);
	aBytesLeft -= 4;
	
	if (aBytesLeft <= 0)
	{
		theError = "Invalid demo file.";
		return false;
	}


	aBuffer = new uchar[aBytesLeft];
	fread(aBuffer, 1, aBytesLeft, aFP);		

	mDemoBuffer.WriteBytes(aBuffer, aBytesLeft);
	mDemoBuffer.SeekFront();

	delete [] aBuffer;
	return true;
}

void SexyAppBase::WriteDemoBuffer()
{
	if (mRecordingDemoBuffer)
	{
		FILE* aFP = fopen(mDemoFileName.c_str(), "w+b");

		if (aFP != NULL)
		{
			ulong aFileID = DEMO_FILE_ID;
			fwrite(&aFileID, 4, 1, aFP);		

			ulong aVersion = DEMO_VERSION;
			fwrite(&aVersion, 4, 1, aFP);
			
			fwrite(&mRandSeed, 4, 1, aFP);

			ushort aStrLen = mProductVersion.length();
			fwrite(&aStrLen, 2, 1, aFP);		
			fwrite(mProductVersion.c_str(), 1, mProductVersion.length(), aFP);

			Buffer aMarkerBuffer;
			aMarkerBuffer.WriteLong(mDemoMarkerList.size());
			for (DemoMarkerList::iterator aMarkerItr = mDemoMarkerList.begin(); aMarkerItr != mDemoMarkerList.end(); ++aMarkerItr)
			{
				aMarkerBuffer.WriteString(aMarkerItr->first);
				aMarkerBuffer.WriteLong(aMarkerItr->second);
			}
			int aMarkerBufferSize = aMarkerBuffer.GetDataLen();
			fwrite(&aMarkerBufferSize, 4, 1, aFP);
			fwrite(aMarkerBuffer.GetDataPtr(), aMarkerBufferSize, 1, aFP);

			ulong aDemoLength = mUpdateCount;
			fwrite(&aDemoLength, 4, 1, aFP);

			fwrite(mDemoBuffer.GetDataPtr(), 1, mDemoBuffer.GetDataLen(), aFP);
			fclose(aFP);
		}		
	}
}

void SexyAppBase::DemoSyncBuffer(Buffer* theBuffer)
{
	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
		
		DBG_ASSERTE(!mDemoIsShortCmd);
		DBG_ASSERTE(mDemoCmdNum == DEMO_SYNC);

		ulong aLen = mDemoBuffer.ReadLong();
		
		theBuffer->Clear();
		for (int i = 0; i < (int) aLen; i++)
			theBuffer->WriteByte(mDemoBuffer.ReadByte());		
	}
	else if (mRecordingDemoBuffer)
	{
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_SYNC, 5);		
		mDemoBuffer.WriteLong(theBuffer->GetDataLen());
		mDemoBuffer.WriteBytes((uchar*) theBuffer->GetDataPtr(), theBuffer->GetDataLen());
	}
}

void SexyAppBase::DemoSyncString(std::string* theString)
{
	Buffer aBuffer;
	aBuffer.WriteString(*theString);
	DemoSyncBuffer(&aBuffer);
	*theString = aBuffer.ReadString();
}

void SexyAppBase::DemoSyncInt(int* theInt)
{
	Buffer aBuffer;
	aBuffer.WriteLong(*theInt);
	DemoSyncBuffer(&aBuffer);
	*theInt = aBuffer.ReadLong();
}

void SexyAppBase::DemoSyncBool(bool* theBool)
{
	Buffer aBuffer;
	aBuffer.WriteBoolean(*theBool);
	DemoSyncBuffer(&aBuffer);
	*theBool = aBuffer.ReadBoolean();
}

void SexyAppBase::DemoAssertStringEqual(const std::string& theString)
{
	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
		
		DBG_ASSERTE(!mDemoIsShortCmd);
		DBG_ASSERTE(mDemoCmdNum == DEMO_ASSERT_STRING_EQUAL);

		std::string aString = mDemoBuffer.ReadString();
		DBG_ASSERTE(aString == theString);
	}
	else if (mRecordingDemoBuffer)
	{
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_ASSERT_STRING_EQUAL, 5);				
		mDemoBuffer.WriteString(theString);
	}
}

void SexyAppBase::DemoAddMarker(const std::string& theString)
{
	if (mPlayingDemoBuffer)
	{
		mFastForwardToMarker = false;
	}
	else if (mRecordingDemoBuffer)
	{
		mDemoMarkerList.push_back(DemoMarker(theString,mUpdateCount));
	}
}

void SexyAppBase::DemoRegisterHandle(HANDLE theHandle)
{
	if ((mRecordingDemoBuffer) || (mPlayingDemoBuffer))
	{
		// Insert the handle into a map with an auto-incrementing number so
		//  we can match up the auto-incrementing numbers with the handle
		//  later on, as handles may not be the same between executions
		std::pair<HandleToIntMap::iterator, bool> aPair = mHandleToIntMap.insert(HandleToIntMap::value_type(theHandle, mCurHandleNum));
		(void)aPair; // unused in Release mode
		DBG_ASSERT(aPair.second);
		mCurHandleNum++;
	}
}

void SexyAppBase::DemoWaitForHandle(HANDLE theHandle)
{
	WaitForSingleObject(theHandle, INFINITE);
	
	if ((mRecordingDemoBuffer) || (mPlayingDemoBuffer))
	{
		// Remove the handle from our waiting map
		HandleToIntMap::iterator anItr = mHandleToIntMap.find(theHandle);					
		DBG_ASSERT(anItr != mHandleToIntMap.end());
		mHandleToIntMap.erase(anItr);
	}
}

bool SexyAppBase::DemoCheckHandle(HANDLE theHandle)
{
	if (mPlayingDemoBuffer)
	{	
		// We only need to try to get the result if we think we are waiting for one	
		if (gSexyAppBase->PrepareDemoCommand(false))
		{
			if ((!gSexyAppBase->mDemoIsShortCmd) && (gSexyAppBase->mDemoCmdNum == DEMO_HANDLE_COMPLETE))
			{
				// Find auto-incrementing handle num from handle
				HandleToIntMap::iterator anItr = mHandleToIntMap.find(theHandle);					
				DBG_ASSERT(anItr != mHandleToIntMap.end());

				int anOldBufferPos = gSexyAppBase->mDemoBuffer.mReadBitPos;

				// Since we don't require a demo result entry to be here, we must verify
				//  that this is referring to us
				int aDemoHandleNum = gSexyAppBase->mDemoBuffer.ReadLong();
				
				if (aDemoHandleNum == anItr->second)
				{
					// Alright, this was the handle we were waiting for!
					gSexyAppBase->mDemoNeedsCommand = true;

					// Actually wait for our local buddy to complete
					WaitForSingleObject(theHandle, INFINITE);
					mHandleToIntMap.erase(anItr);

					return true;
				}
				else
				{
					// Not us, go back
					gSexyAppBase->mDemoBuffer.mReadBitPos = anOldBufferPos;
				}
			}
		}

		return false;	
	}
	else 
	{
		if (WaitForSingleObject(theHandle, 0) == WAIT_OBJECT_0)
		{
			if (mRecordingDemoBuffer)
			{
				// Find auto-incrementing handle num from handle
				HandleToIntMap::iterator anItr = mHandleToIntMap.find(theHandle);					
				DBG_ASSERT(anItr != mHandleToIntMap.end());

				gSexyAppBase->WriteDemoTimingBlock();
				gSexyAppBase->mDemoBuffer.WriteNumBits(0, 1);
				gSexyAppBase->mDemoBuffer.WriteNumBits(DEMO_HANDLE_COMPLETE, 5);
				gSexyAppBase->mDemoBuffer.WriteLong(anItr->second);

				mHandleToIntMap.erase(anItr);
			}

			return true;
		}

		return false;
	}
}

void SexyAppBase::DemoAssertIntEqual(int theInt)
{
	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
		
		DBG_ASSERTE(!mDemoIsShortCmd);
		DBG_ASSERTE(mDemoCmdNum == DEMO_ASSERT_INT_EQUAL);

		int anInt = mDemoBuffer.ReadLong();
		(void)anInt; // unused in Release mode
		DBG_ASSERTE(anInt == theInt);
	}
	else if (mRecordingDemoBuffer)
	{		
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_ASSERT_INT_EQUAL, 5);				
		mDemoBuffer.WriteLong(theInt);
	}
}

Dialog* SexyAppBase::NewDialog(int theDialogId, bool isModal, const SexyString& theDialogHeader, const SexyString& theDialogLines, const SexyString& theDialogFooter, int theButtonMode)
{	
	Dialog* aDialog = new Dialog(NULL, NULL, theDialogId, isModal, theDialogHeader,	theDialogLines, theDialogFooter, theButtonMode);		
	return aDialog;
}

Dialog* SexyAppBase::DoDialog(int theDialogId, bool isModal, const SexyString& theDialogHeader, const SexyString& theDialogLines, const SexyString& theDialogFooter, int theButtonMode)
{
	KillDialog(theDialogId);

	Dialog* aDialog = NewDialog(theDialogId, isModal, theDialogHeader, theDialogLines, theDialogFooter, theButtonMode);		

	AddDialog(theDialogId, aDialog);

	return aDialog;
}


Dialog*	SexyAppBase::GetDialog(int theDialogId)
{
	DialogMap::iterator anItr = mDialogMap.find(theDialogId);

	if (anItr != mDialogMap.end())	
		return anItr->second;

	return NULL;
}

bool SexyAppBase::KillDialog(int theDialogId, bool removeWidget, bool deleteWidget)
{
	DialogMap::iterator anItr = mDialogMap.find(theDialogId);

	if (anItr != mDialogMap.end())
	{
		Dialog* aDialog = anItr->second;

		// set the result to something else so DoMainLoop knows that the dialog is gone 
		// in case nobody else sets mResult		
		if (aDialog->mResult == -1) 
			aDialog->mResult = 0;
		
		DialogList::iterator aListItr = std::find(mDialogList.begin(),mDialogList.end(),aDialog);
		if (aListItr != mDialogList.end())
			mDialogList.erase(aListItr);
		
		mDialogMap.erase(anItr);

		if (removeWidget || deleteWidget)
		mWidgetManager->RemoveWidget(aDialog);

		if (aDialog->IsModal())
		{			
			ModalClose();
			mWidgetManager->RemoveBaseModal(aDialog);
		}				

		if (deleteWidget)
		SafeDeleteWidget(aDialog);
		
		return true;
	}

	return false;
}

bool SexyAppBase::KillDialog(int theDialogId)
{
	return KillDialog(theDialogId,true,true);
}

bool SexyAppBase::KillDialog(Dialog* theDialog)
{
	return KillDialog(theDialog->mId);
}

int SexyAppBase::GetDialogCount()
{
	return mDialogMap.size();
}

void SexyAppBase::AddDialog(int theDialogId, Dialog* theDialog)
{
	KillDialog(theDialogId);

	if (theDialog->mWidth == 0)
	{
		// Set the dialog position ourselves
		int aWidth = mWidth/2;
		theDialog->Resize((mWidth - aWidth)/2, mHeight / 5, aWidth, theDialog->GetPreferredHeight(aWidth));
	}

	mDialogMap.insert(DialogMap::value_type(theDialogId, theDialog));
	mDialogList.push_back(theDialog);

	mWidgetManager->AddWidget(theDialog);
	if (theDialog->IsModal())
	{
		mWidgetManager->AddBaseModal(theDialog);
		ModalOpen();
	}
}

void SexyAppBase::AddDialog(Dialog* theDialog)
{
	AddDialog(theDialog->mId, theDialog);
}

void SexyAppBase::ModalOpen()
{
}

void SexyAppBase::ModalClose()
{
}

void SexyAppBase::DialogButtonPress(int theDialogId, int theButtonId)
{	
	if (theButtonId == Dialog::ID_YES)
		ButtonPress(2000 + theDialogId);
	else if (theButtonId == Dialog::ID_NO)
		ButtonPress(3000 + theDialogId);	
}

void SexyAppBase::DialogButtonDepress(int theDialogId, int theButtonId)
{
	if (theButtonId == Dialog::ID_YES)
		ButtonDepress(2000 + theDialogId);
	else if (theButtonId == Dialog::ID_NO)
		ButtonDepress(3000 + theDialogId);
}

void SexyAppBase::GotFocus()
{	
}

void SexyAppBase::LostFocus()
{	
}

std::string SexyAppBase::GetProductVersion(const std::string& thePath)
{	
	// Dynamically Load Version.dll
	typedef DWORD (APIENTRY *GetFileVersionInfoSizeFunc)(LPSTR lptstrFilename, LPDWORD lpdwHandle);
	typedef BOOL (APIENTRY *GetFileVersionInfoFunc)(LPSTR lptstrFilename, DWORD dwHandle, DWORD dwLen, LPVOID lpData);
	typedef BOOL (APIENTRY *VerQueryValueFunc)(const LPVOID pBlock, LPSTR lpSubBlock, LPVOID * lplpBuffer, PUINT puLen);

	static GetFileVersionInfoSizeFunc aGetFileVersionInfoSizeFunc = NULL;
	static GetFileVersionInfoFunc aGetFileVersionInfoFunc = NULL;
	static VerQueryValueFunc aVerQueryValueFunc = NULL;

	if (aGetFileVersionInfoSizeFunc==NULL)
	{
		aGetFileVersionInfoSizeFunc = (GetFileVersionInfoSizeFunc)GetProcAddress(gVersionDLL,"GetFileVersionInfoSizeA");
		aGetFileVersionInfoFunc = (GetFileVersionInfoFunc)GetProcAddress(gVersionDLL,"GetFileVersionInfoA");
		aVerQueryValueFunc = (VerQueryValueFunc)GetProcAddress(gVersionDLL,"VerQueryValueA");
	}

	// Get Product Version
	std::string aProductVersion;
	
	uint aSize = aGetFileVersionInfoSizeFunc((char*) thePath.c_str(), 0);
	if (aSize > 0)		
	{
		uchar* aVersionBuffer = new uchar[aSize];
		aGetFileVersionInfoFunc((char*) thePath.c_str(), 0, aSize, aVersionBuffer);	
		char* aBuffer;
		if (aVerQueryValueFunc(aVersionBuffer, 
				  (char*)"\\StringFileInfo\\040904B0\\ProductVersion",
				  (void**) &aBuffer, 
				  &aSize))
		{
			aProductVersion = aBuffer;
		}
		else if (aVerQueryValueFunc(aVersionBuffer, 
				  (char*)"\\StringFileInfo\\040904E4\\ProductVersion", 
				  (void**) &aBuffer, 
				  &aSize))
		{
			aProductVersion = aBuffer;
		}

		delete[] aVersionBuffer;	
	}

	return aProductVersion;
}

void SexyAppBase::WaitForLoadingThread()
{
	while ((mLoadingThreadStarted) && (!mLoadingThreadCompleted))
		Sleep(20);
}

void SexyAppBase::SetCursorImage(int theCursorNum, Image* theImage)
{
	if ((theCursorNum >= 0) && (theCursorNum < NUM_CURSORS))
	{
		mCursorImages[theCursorNum] = theImage;
		EnforceCursor();
	}
}

void SexyAppBase::TakeScreenshot()
{
	// DirectDraw-based screenshot is gone; use an external capture tool.
	ClearUpdateBacklog();
}

void SexyAppBase::DumpProgramInfo()
{
	Deltree(GetAppDataFolder() + "_dump");

	for (;;)
	{
		if (mkdir((GetAppDataFolder() + "_dump").c_str()))
			break;
		Sleep(100);
	}

	std::fstream aDumpStream((GetAppDataFolder() + "_dump\\imagelist.html").c_str(), std::ios::out);

	time_t aTime;
	time(&aTime);
	tm* aTM = localtime(&aTime);

	aDumpStream << "<HTML><BODY BGCOLOR=EEEEFF><CENTER><FONT SIZE=+2><B>" << asctime(aTM) << "</B></FONT><BR>" << std::endl;

	int anImgNum = 0;

	int aThumbWidth = 64;
	int aThumbHeight = 64;

	ImageLib::Image anImageLibImage;
	anImageLibImage.mWidth = aThumbWidth;
	anImageLibImage.mHeight = aThumbHeight;
	anImageLibImage.mBits = new unsigned long[aThumbWidth*aThumbHeight];	

	typedef std::multimap<int, MemoryImage*, std::greater<int> > SortedImageMap;

	int aTotalMemory = 0;

	SortedImageMap aSortedImageMap;
	MemoryImageSet::iterator anItr = mMemoryImageSet.begin();
	while (anItr != mMemoryImageSet.end())
	{
		MemoryImage* aMemoryImage = *anItr;				

		int aNumPixels = aMemoryImage->mWidth*aMemoryImage->mHeight;

		DDImage* aDDImage = dynamic_cast<DDImage*>(aMemoryImage);

		int aBitsMemory = 0;
		int aSurfaceMemory = 0;
		int aPalletizedMemory = 0;
		int aNativeAlphaMemory = 0;
		int aRLAlphaMemory = 0;
		int aRLAdditiveMemory = 0;
		int aTextureMemory = 0;

		int aMemorySize = 0;
		if (aMemoryImage->mBits != NULL)
			aBitsMemory = aNumPixels * 4;
		if (aMemoryImage->mColorTable != NULL)
			aPalletizedMemory = aNumPixels + 256*4;
		if (aMemoryImage->mNativeAlphaData != NULL)
		{
			if (aMemoryImage->mColorTable != NULL)
				aNativeAlphaMemory = 256*4;
			else
				aNativeAlphaMemory = aNumPixels * 4;
		}
		if (aMemoryImage->mRLAlphaData != NULL)
			aRLAlphaMemory = aNumPixels;
		if (aMemoryImage->mRLAdditiveData != NULL)
			aRLAdditiveMemory = aNumPixels;
		if (aMemoryImage->mD3DData != NULL)
			aTextureMemory += ((TextureData*)aMemoryImage->mD3DData)->mTexMemSize;

		aMemorySize = aBitsMemory + aSurfaceMemory + aPalletizedMemory + aNativeAlphaMemory + aRLAlphaMemory + aRLAdditiveMemory + aTextureMemory;
		aTotalMemory += aMemorySize;

		aSortedImageMap.insert(SortedImageMap::value_type(aMemorySize, aMemoryImage));

		++anItr;
	}

	aDumpStream << "Total Image Allocation: " << CommaSeperate(aTotalMemory).c_str() << " bytes<BR>";
	aDumpStream << "<TABLE BORDER=1 CELLSPACING=0 CELLPADDING=4>";

	int aTotalMemorySize = 0;
	int aTotalBitsMemory = 0;
	int aTotalSurfaceMemory = 0;
	int aTotalPalletizedMemory = 0;
	int aTotalNativeAlphaMemory = 0;
	int aTotalRLAlphaMemory = 0;
	int aTotalRLAdditiveMemory = 0;
	int aTotalTextureMemory = 0;

	SortedImageMap::iterator aSortedItr = aSortedImageMap.begin();
	while (aSortedItr != aSortedImageMap.end())
	{
		MemoryImage* aMemoryImage = aSortedItr->second;				

		char anImageName[256];
		sprintf(anImageName, "img%04d.png", anImgNum);

		char aThumbName[256];
		sprintf(aThumbName, "thumb%04d.jpg", anImgNum);
		
		aDumpStream << "<TR>" << std::endl;

		aDumpStream << "<TD><A HREF=" << anImageName << "><IMG SRC=" << aThumbName << " WIDTH=" << aThumbWidth << " HEIGHT=" << aThumbHeight << "></A></TD>" << std::endl;
		
		int aNumPixels = aMemoryImage->mWidth*aMemoryImage->mHeight;

		DDImage* aDDImage = dynamic_cast<DDImage*>(aMemoryImage);

		int aMemorySize = aSortedItr->first;

		int aBitsMemory = 0;
		int aSurfaceMemory = 0;
		int aPalletizedMemory = 0;
		int aNativeAlphaMemory = 0;
		int aRLAlphaMemory = 0;
		int aRLAdditiveMemory = 0;
		int aTextureMemory = 0;
		std::string aTextureFormatName;
		
		if (aMemoryImage->mBits != NULL)
			aBitsMemory = aNumPixels * 4;
		if (aMemoryImage->mColorTable != NULL)
			aPalletizedMemory = aNumPixels + 256*4;
		if (aMemoryImage->mNativeAlphaData != NULL)
		{
			if (aMemoryImage->mColorTable != NULL)
				aNativeAlphaMemory = 256*4;
			else
				aNativeAlphaMemory = aNumPixels * 4;
		}
		if (aMemoryImage->mRLAlphaData != NULL)
			aRLAlphaMemory = aNumPixels;
		if (aMemoryImage->mRLAdditiveData != NULL)
			aRLAdditiveMemory = aNumPixels;		
		if (aMemoryImage->mD3DData != NULL)
		{
			aTextureMemory += ((TextureData*)aMemoryImage->mD3DData)->mTexMemSize;

			switch (((TextureData*)aMemoryImage->mD3DData)->mPixelFormat)
			{				
			case PixelFormat_A8R8G8B8: aTextureFormatName = "A8R8G8B8"; break;
			case PixelFormat_A4R4G4B4: aTextureFormatName = "A4R4G4B4"; break;
			case PixelFormat_R5G6B5: aTextureFormatName = "R5G6B5"; break;
			case PixelFormat_Palette8: aTextureFormatName = "Palette8"; break;
			case PixelFormat_Unknown: break;
			}			
		}

		aTotalMemorySize		+= aMemorySize;
		aTotalBitsMemory		+= aBitsMemory;
		aTotalTextureMemory		+= aTextureMemory;
		aTotalSurfaceMemory		+= aSurfaceMemory;
		aTotalPalletizedMemory	+= aPalletizedMemory;
		aTotalNativeAlphaMemory	+= aNativeAlphaMemory;
		aTotalRLAlphaMemory		+= aRLAlphaMemory;
		aTotalRLAdditiveMemory	+= aRLAdditiveMemory;

				

		char aStr[256];
		sprintf(aStr, "%d x %d<BR>%s bytes", aMemoryImage->mWidth, aMemoryImage->mHeight, CommaSeperate(aMemorySize).c_str());
		aDumpStream << "<TD ALIGN=RIGHT>" << aStr << "</TD>" << std::endl;

		aDumpStream << "<TD>" << SexyStringToString(((aBitsMemory != 0) ? _S("mBits<BR>") + CommaSeperate(aBitsMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;	
		aDumpStream << "<TD>" << SexyStringToString(((aPalletizedMemory != 0) ? _S("Palletized<BR>") + CommaSeperate(aPalletizedMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;				
		aDumpStream << "<TD>" << SexyStringToString(((aSurfaceMemory != 0) ? _S("DDSurface<BR>") + CommaSeperate(aSurfaceMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;		
		aDumpStream << "<TD>" << SexyStringToString(((aMemoryImage->mD3DData!=NULL) ? _S("Texture<BR>") + StringToSexyString(aTextureFormatName) + _S("<BR>") + CommaSeperate(aTextureMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;

		aDumpStream << "<TD>" << SexyStringToString(((aMemoryImage->mIsVolatile) ? _S("Volatile") : _S("&nbsp;"))) << "</TD>" << std::endl;
		aDumpStream << "<TD>" << SexyStringToString(((aMemoryImage->mForcedMode) ? _S("Forced") : _S("&nbsp;"))) << "</TD>" << std::endl;		
		aDumpStream << "<TD>" << SexyStringToString(((aMemoryImage->mHasAlpha) ? _S("HasAlpha") : _S("&nbsp;"))) << "</TD>" << std::endl;
		aDumpStream << "<TD>" << SexyStringToString(((aMemoryImage->mHasTrans) ? _S("HasTrans") : _S("&nbsp;"))) << "</TD>" << std::endl;
		aDumpStream << "<TD>" << SexyStringToString(((aNativeAlphaMemory != 0) ? _S("NativeAlpha<BR>") + CommaSeperate(aNativeAlphaMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;
		aDumpStream << "<TD>" << SexyStringToString(((aRLAlphaMemory != 0) ? _S("RLAlpha<BR>") + CommaSeperate(aRLAlphaMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;
		aDumpStream << "<TD>" << SexyStringToString(((aRLAdditiveMemory != 0) ? _S("RLAdditive<BR>") + CommaSeperate(aRLAdditiveMemory) : _S("&nbsp;"))) << "</TD>" << std::endl;
		aDumpStream << "<TD>" << (aMemoryImage->mFilePath.empty()? "&nbsp;":aMemoryImage->mFilePath) << "</TD>" << std::endl;

		aDumpStream << "</TR>" << std::endl;
		
		// Write thumb

		MemoryImage aCopiedImage(*aMemoryImage);

		ulong* aBits = aCopiedImage.GetBits();

		ulong* aThumbBitsPtr = anImageLibImage.mBits;

		for (int aThumbY = 0; aThumbY < aThumbHeight; aThumbY++)
			for (int aThumbX = 0; aThumbX < aThumbWidth; aThumbX++)
			{
				int aSrcX = (int) (aCopiedImage.mWidth  * (aThumbX + 0.5)) / aThumbWidth;
				int aSrcY = (int) (aCopiedImage.mHeight * (aThumbY + 0.5)) / aThumbHeight;
				
				*(aThumbBitsPtr++) = aBits[aSrcX + (aSrcY*aCopiedImage.mWidth)];
			}

		ImageLib::WriteJPEGImage((GetAppDataFolder() + std::string("_dump\\") + aThumbName).c_str(), &anImageLibImage);

		// Write high resolution image

		ImageLib::Image anFullImage;
		anFullImage.mBits = aCopiedImage.GetBits();
		anFullImage.mWidth = aCopiedImage.GetWidth();
		anFullImage.mHeight = aCopiedImage.GetHeight();

		ImageLib::WritePNGImage((GetAppDataFolder() + std::string("_dump\\") + anImageName).c_str(), &anFullImage);

		anFullImage.mBits = NULL;

		anImgNum++;

		aSortedItr++;		
	}

	aDumpStream << "<TD>Totals</TD>" << std::endl;
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalMemorySize)) << "</TD>" << std::endl;	
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalBitsMemory)) << "</TD>" << std::endl;	
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalPalletizedMemory)) << "</TD>" << std::endl;				
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalSurfaceMemory)) << "</TD>" << std::endl;		
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalTextureMemory)) << "</TD>" << std::endl;		
	aDumpStream << "<TD>&nbsp;</TD>" << std::endl;
	aDumpStream << "<TD>&nbsp;</TD>" << std::endl;
	aDumpStream << "<TD>&nbsp;</TD>" << std::endl;
	aDumpStream << "<TD>&nbsp;</TD>" << std::endl;
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalNativeAlphaMemory)) << "</TD>" << std::endl;
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalRLAlphaMemory)) << "</TD>" << std::endl;
	aDumpStream << "<TD>" << SexyStringToString(CommaSeperate(aTotalRLAdditiveMemory)) << "</TD>" << std::endl;
	aDumpStream << "<TD>&nbsp;</TD>" << std::endl;

	aDumpStream << "</TABLE></CENTER></BODY></HTML>" << std::endl;
}

double SexyAppBase::GetLoadingThreadProgress()
{
	if (mLoaded)
		return 1.0;
	if (!mLoadingThreadStarted)
		return 0.0;
	if (mNumLoadingThreadTasks == 0)
		return 0.0;
	return std::min(mCompletedLoadingThreadTasks / (double) mNumLoadingThreadTasks, 1.0);
}

bool SexyAppBase::RegistryWrite(const std::string& theValueName, ulong theType, const uchar* theValue, ulong theLength)
{
	if (mRegKey.length() == 0)
		return false;

	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return true;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;

		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_REGISTRY_WRITE);

		return mDemoBuffer.ReadNumBits(1, false) != 0;		
	}

	HKEY aGameKey;
	
	std::string aKeyName = RemoveTrailingSlash("SOFTWARE\\" + mRegKey);
	std::string aValueName;

	int aSlashPos = (int) theValueName.rfind('\\');
	if (aSlashPos != -1)
	{
		aKeyName += "\\" + theValueName.substr(0, aSlashPos);
		aValueName = theValueName.substr(aSlashPos + 1);
	}
	else
	{
		aValueName = theValueName;
	}

	int aResult = RegOpenKeyExA(HKEY_CURRENT_USER, aKeyName.c_str(), 0, KEY_WRITE, &aGameKey);
	if (aResult != ERROR_SUCCESS)
	{
		ulong aDisp;
		aResult = RegCreateKeyExA(HKEY_CURRENT_USER, aKeyName.c_str(), 0, (char *)"Key", REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS, NULL, &aGameKey, &aDisp);
	}

	if (aResult != ERROR_SUCCESS)
	{
		if (mRecordingDemoBuffer)
		{
			WriteDemoTimingBlock();
			mDemoBuffer.WriteNumBits(0, 1);
			mDemoBuffer.WriteNumBits(DEMO_REGISTRY_WRITE, 5);
			mDemoBuffer.WriteNumBits(0, 1); // failure
		}

		return false;
	}
		
	RegSetValueExA(aGameKey, aValueName.c_str(), 0, theType, theValue, theLength);
	RegCloseKey(aGameKey);

	if (mRecordingDemoBuffer)
	{
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_REGISTRY_WRITE, 5);
		mDemoBuffer.WriteNumBits(1, 1); // success
	}

	return true;
}

bool SexyAppBase::RegistryWriteString(const std::string& theValueName, const std::string& theString)
{
	return RegistryWrite(theValueName, REG_SZ, (uchar*) theString.c_str(), theString.length());
}

bool SexyAppBase::RegistryWriteInteger(const std::string& theValueName, int theValue)
{
	return RegistryWrite(theValueName, REG_DWORD, (uchar*) &theValue, sizeof(int));
}

bool SexyAppBase::RegistryWriteBoolean(const std::string& theValueName, bool theValue)
{
	int aValue = theValue ? 1 : 0;
	return RegistryWrite(theValueName, REG_DWORD, (uchar*) &aValue, sizeof(int));
}

bool SexyAppBase::RegistryWriteData(const std::string& theValueName, const uchar* theValue, ulong theLength)
{
	return RegistryWrite(theValueName, REG_BINARY, (uchar*) theValue, theLength);
}

void SexyAppBase::WriteToRegistry()
{
	FILE* aFile = fopen("settings.xml", "w");
	if (aFile == nullptr)
		return;
	fprintf(aFile, "<settings>\n");
	fprintf(aFile, "  <musicVolume>%d</musicVolume>\n", (int)(mMusicVolume * 100));
	fprintf(aFile, "  <sfxVolume>%d</sfxVolume>\n", (int)(mSfxVolume * 100));
	fprintf(aFile, "  <muted>%d</muted>\n", (mMuteCount - mAutoMuteCount > 0) ? 1 : 0);
	fprintf(aFile, "  <screenMode>%s</screenMode>\n", mIsWindowed ? "windowed" : "fullscreen");
	fprintf(aFile, "  <preferredX>%d</preferredX>\n", mPreferredX);
	fprintf(aFile, "  <preferredY>%d</preferredY>\n", mPreferredY);
	fprintf(aFile, "  <customCursors>%d</customCursors>\n", mCustomCursorsEnabled ? 1 : 0);
	fprintf(aFile, "  <waitForVSync>%d</waitForVSync>\n", mWaitForVSync ? 1 : 0);
	fprintf(aFile, "  <customScale>%d</customScale>\n", mUseCustomScale ? 1 : 0);
	fprintf(aFile, "</settings>\n");
	fclose(aFile);
}

bool SexyAppBase::RegistryEraseKey(const SexyString& _theKeyName)
{
	std::string theKeyName = SexyStringToStringFast(_theKeyName);
	if (mRegKey.length() == 0)
		return false;

	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return true;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;

		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_REGISTRY_ERASE);

		return mDemoBuffer.ReadNumBits(1, false) != 0;		
	}	
	
	std::string aKeyName = RemoveTrailingSlash("SOFTWARE\\" + mRegKey) + "\\" + theKeyName;

	int aResult = RegDeleteKeyA(HKEY_CURRENT_USER, aKeyName.c_str());
	if (aResult != ERROR_SUCCESS)
	{
		if (mRecordingDemoBuffer)
		{
			WriteDemoTimingBlock();
			mDemoBuffer.WriteNumBits(0, 1);
			mDemoBuffer.WriteNumBits(DEMO_REGISTRY_ERASE, 5);
			mDemoBuffer.WriteNumBits(0, 1); // failure
		}

		return false;
	}		

	if (mRecordingDemoBuffer)
	{
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_REGISTRY_ERASE, 5);
		mDemoBuffer.WriteNumBits(1, 1); // success
	}

	return true;
}

void SexyAppBase::RegistryEraseValue(const SexyString& _theValueName)
{
	std::string theValueName = SexyStringToStringFast(_theValueName);
	if (mRegKey.length() == 0)
		return;

	HKEY aGameKey;	
	std::string aKeyName = RemoveTrailingSlash("SOFTWARE\\" + mRegKey);
	std::string aValueName;

	int aSlashPos = (int) theValueName.rfind('\\');
	if (aSlashPos != -1)
	{
		aKeyName += "\\" + theValueName.substr(0, aSlashPos);
		aValueName = theValueName.substr(aSlashPos + 1);
	}
	else
	{
		aValueName = theValueName;
	}

	int aResult = RegOpenKeyExA(HKEY_CURRENT_USER, aKeyName.c_str(), 0, KEY_WRITE, &aGameKey);
	if (aResult == ERROR_SUCCESS)
	{		
		RegDeleteValueA(aGameKey, aValueName.c_str());
		RegCloseKey(aGameKey);
	}
}

bool SexyAppBase::RegistryGetSubKeys(const std::string& theKeyName, StringVector* theSubKeys)
{
	theSubKeys->clear();

	if (mRegKey.length() == 0)
		return false;

	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return true;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;

		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_REGISTRY_GETSUBKEYS);

		bool success = mDemoBuffer.ReadNumBits(1, false) != 0;
		if (!success)
			return false;

		int aNumKeys = mDemoBuffer.ReadLong();

		for (int i = 0; i < aNumKeys; i++)
			theSubKeys->push_back(mDemoBuffer.ReadString());

		return true;
	}
	else
	{
		HKEY aKey;
		
		std::string aKeyName = RemoveTrailingSlash(RemoveTrailingSlash("SOFTWARE\\" + mRegKey) + "\\" + theKeyName);	
		int aResult = RegOpenKeyExA(HKEY_CURRENT_USER, aKeyName.c_str(), 0, KEY_READ, &aKey);
		
		if (aResult == ERROR_SUCCESS)
		{		
			for (int anIdx = 0; ; anIdx++)
			{
				char aStr[1024];

				aResult = RegEnumKeyA(aKey, anIdx, aStr, 1024);
				if (aResult != ERROR_SUCCESS)
					break;

				theSubKeys->push_back(aStr);
			}

			RegCloseKey(aKey);

			if (mRecordingDemoBuffer)
			{
				WriteDemoTimingBlock();
				mDemoBuffer.WriteNumBits(0, 1);
				mDemoBuffer.WriteNumBits(DEMO_REGISTRY_GETSUBKEYS, 5);
				mDemoBuffer.WriteNumBits(1, 1); // success
				mDemoBuffer.WriteLong(theSubKeys->size());

				for (int i = 0; i < (int) theSubKeys->size(); i++)
					mDemoBuffer.WriteString((*theSubKeys)[i]);				
			}

			return true;
		}
		else
		{
			if (mRecordingDemoBuffer)
			{
				WriteDemoTimingBlock();
				mDemoBuffer.WriteNumBits(0, 1);
				mDemoBuffer.WriteNumBits(DEMO_REGISTRY_GETSUBKEYS, 5);
				mDemoBuffer.WriteNumBits(0, 1); // failure
			}

			return false;	
		}
	}
}

bool SexyAppBase::RegistryRead(const std::string& theValueName, ulong* theType, uchar* theValue, ulong* theLength)
{
	return RegistryReadKey(theValueName, theType, theValue, theLength, HKEY_CURRENT_USER);
}

bool SexyAppBase::RegistryReadKey(const std::string& theValueName, ulong* theType, uchar* theValue, ulong* theLength, HKEY theKey)
{
	if (mRegKey.length() == 0)
		return false;

	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return false;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
				
		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_REGISTRY_READ);

		bool success = mDemoBuffer.ReadNumBits(1, false) != 0;
		if (!success)
			return false;

		*theType = mDemoBuffer.ReadLong();

		ulong aLen = mDemoBuffer.ReadLong();
		*theLength = aLen;
		
		if (*theLength >= aLen)
		{			
			mDemoBuffer.ReadBytes(theValue, aLen);
			return true;
		}
		else
		{
			for (int i = 0; i < (int) aLen; i++)
				mDemoBuffer.ReadByte();
			return false;
		}		
	}
	else
	{		
		HKEY aGameKey;

		std::string aKeyName = RemoveTrailingSlash("SOFTWARE\\" + mRegKey);
		std::string aValueName;

		int aSlashPos = (int) theValueName.rfind('\\');
		if (aSlashPos != -1)
		{
			aKeyName += "\\" + theValueName.substr(0, aSlashPos);
			aValueName = theValueName.substr(aSlashPos + 1);
		}
		else
		{
			aValueName = theValueName;
		}		

		if (RegOpenKeyExA(theKey, aKeyName.c_str(), 0, KEY_READ, &aGameKey) == ERROR_SUCCESS)
		{
			if (RegQueryValueExA(aGameKey, aValueName.c_str(), 0, theType, (uchar*) theValue, theLength) == ERROR_SUCCESS)
			{
				if (mRecordingDemoBuffer)
				{
					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_REGISTRY_READ, 5);
					mDemoBuffer.WriteNumBits(1, 1); // success
					mDemoBuffer.WriteLong(*theType);
					mDemoBuffer.WriteLong(*theLength);
					mDemoBuffer.WriteBytes(theValue, *theLength);
				}

				RegCloseKey(aGameKey);
				return true;	
			}

			RegCloseKey(aGameKey);
		}

		if (mRecordingDemoBuffer)
		{
			WriteDemoTimingBlock();
			mDemoBuffer.WriteNumBits(0, 1);
			mDemoBuffer.WriteNumBits(DEMO_REGISTRY_READ, 5);
			mDemoBuffer.WriteNumBits(0, 1); // failure
		}
		
		return false;
	}
}

// aStr isn't initialised lmao
bool SexyAppBase::RegistryReadString(const std::string& theKey, std::string* theString)
{
	char aStr[1024];
	
	ulong aType;	
	ulong aLen = sizeof(aStr) - 1;
	if (!RegistryRead(theKey, &aType, (uchar*) aStr, &aLen))
		return false;

	if (aType != REG_SZ)
		return false;

	aStr[aLen] = 0;

	*theString = aStr;
	return true;
}

bool SexyAppBase::RegistryReadInteger(const std::string& theKey, int* theValue)
{
	ulong aType;
	ulong aLong;
	ulong aLen = 4;
	if (!RegistryRead(theKey, &aType, (uchar*) &aLong, &aLen))
		return false;

	if (aType != REG_DWORD)
		return false;

	*theValue = aLong;
	return true;
}

bool SexyAppBase::RegistryReadBoolean(const std::string& theKey, bool* theValue)
{
	int aValue;
	if (!RegistryReadInteger(theKey, &aValue))
		return false;
	
	*theValue = aValue != 0;
	return true;
}

bool SexyAppBase::RegistryReadData(const std::string& theKey, uchar* theValue, ulong* theLength)
{		
	ulong aType;
	if (!RegistryRead(theKey, &aType, (uchar*) theValue, theLength))
		return false;

	if (aType != REG_BINARY)
		return false;
	
	return true;
}

static std::string TrimScaleText(const SexyString& theText);
static std::string LowerScaleText(const std::string& theText);

void SexyAppBase::ReadFromRegistry()
{
	mReadFromRegistry = true;
	mRegKey.clear();

	// Settings live in settings.xml next to the executable (self-contained,
	// no registry / user-profile dependency).
	XMLParser aParser;
	aParser.OpenFile("settings.xml");
	if (aParser.HasFailed())
		return;

	XMLElement aElement;
	SexyString aCurrentName;
	while (aParser.NextElement(&aElement))
	{
		if (aElement.mType == XMLElement::TYPE_START)
		{
			aCurrentName = aElement.mValue;
		}
		else if (aElement.mType == XMLElement::TYPE_ELEMENT)
		{
			std::string aText = TrimScaleText(aElement.mValue);
			if (aText.empty())
				continue;
			std::string aName = LowerScaleText(SexyStringToStringFast(aCurrentName));
			int anInt = atoi(aText.c_str());
			if (aName == "musicvolume")
				mMusicVolume = anInt / 100.0;
			else if (aName == "sfxvolume")
				mSfxVolume = anInt / 100.0;
			else if (aName == "muted")
				mMuteCount = anInt;
			else if (aName == "screenmode")
				mIsWindowed = LowerScaleText(aText) == "windowed";
			else if (aName == "preferredx")
				mPreferredX = anInt;
			else if (aName == "preferredy")
				mPreferredY = anInt;
			else if (aName == "customcursors")
				EnableCustomCursors(anInt != 0);
			else if (aName == "waitforvsync")
				mWaitForVSync = anInt != 0;
			else if (aName == "customscale")
				mUseCustomScale = anInt != 0;
		}
		else if (aElement.mType == XMLElement::TYPE_END)
		{
			aCurrentName.clear();
		}
	}
}

bool SexyAppBase::WriteBytesToFile(const std::string& theFileName, const void *theData, unsigned long theDataLen)
{
	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return true;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;

		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_FILE_WRITE);		

		bool success = mDemoBuffer.ReadNumBits(1, false) != 0;
		if (!success)
			return false;

		return true;
	}	

	MkDir(GetFileDir(theFileName));
	FILE* aFP = fopen(theFileName.c_str(), "w+b");

	if (aFP == NULL)
	{
		if (mRecordingDemoBuffer)
		{
			WriteDemoTimingBlock();
			mDemoBuffer.WriteNumBits(0, 1);
			mDemoBuffer.WriteNumBits(DEMO_FILE_WRITE, 5);
			mDemoBuffer.WriteNumBits(0, 1); // failure				
		}

		return false;
	}

	fwrite(theData, 1, theDataLen, aFP);
	fclose(aFP);

	if (mRecordingDemoBuffer)
	{
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_FILE_WRITE, 5);
		mDemoBuffer.WriteNumBits(1, 1); // success
	}

	return true;
}

bool SexyAppBase::WriteBufferToFile(const std::string& theFileName, const Buffer* theBuffer)
{
	return WriteBytesToFile(theFileName,theBuffer->GetDataPtr(),theBuffer->GetDataLen());
}


bool SexyAppBase::ReadBufferFromFile(const std::string& theFileName, Buffer* theBuffer, bool dontWriteToDemo)
{
	if ((mPlayingDemoBuffer) && (!dontWriteToDemo))
	{
		if (mManualShutdown)
			return false;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
		
		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_FILE_READ);

		bool success = mDemoBuffer.ReadNumBits(1, false) != 0;
		if (!success)
			return false;

		ulong aLen = mDemoBuffer.ReadLong();		
				
		theBuffer->Clear();
		for (int i = 0; i < (int) aLen; i++)
			theBuffer->WriteByte(mDemoBuffer.ReadByte());

		return true;		
	}
	else
	{
		PFILE* aFP = p_fopen(theFileName.c_str(), "rb");

		if (aFP == NULL)
		{
			if ((mRecordingDemoBuffer) && (!dontWriteToDemo))
			{
				WriteDemoTimingBlock();
				mDemoBuffer.WriteNumBits(0, 1);
				mDemoBuffer.WriteNumBits(DEMO_FILE_READ, 5);
				mDemoBuffer.WriteNumBits(0, 1); // failure				
			}

			return false;
		}
		
		p_fseek(aFP, 0, SEEK_END);
		int aFileSize = p_ftell(aFP);
		p_fseek(aFP, 0, SEEK_SET);
		
		uchar* aData = new uchar[aFileSize];

		p_fread(aData, 1, aFileSize, aFP);
		p_fclose(aFP);

		theBuffer->Clear();
		theBuffer->SetData(aData, aFileSize);

		if ((mRecordingDemoBuffer) && (!dontWriteToDemo))
		{
			WriteDemoTimingBlock();
			mDemoBuffer.WriteNumBits(0, 1);
			mDemoBuffer.WriteNumBits(DEMO_FILE_READ, 5);
			mDemoBuffer.WriteNumBits(1, 1); // success			
			mDemoBuffer.WriteLong(aFileSize);
			mDemoBuffer.WriteBytes(aData, aFileSize);
		}

		delete [] aData;

		return true;
	}
}

bool SexyAppBase::FileExists(const std::string& theFileName)
{
	if (mPlayingDemoBuffer)
	{
		if (mManualShutdown)
			return true;

		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
		
		DBG_ASSERTE(!mDemoIsShortCmd);		
		DBG_ASSERTE(mDemoCmdNum == DEMO_FILE_EXISTS);		

		bool success = mDemoBuffer.ReadNumBits(1, false) != 0;		
		return success;
	}
	else
	{
		PFILE* aFP = p_fopen(theFileName.c_str(), "rb");

		if (mRecordingDemoBuffer)
		{
			WriteDemoTimingBlock();
			mDemoBuffer.WriteNumBits(0, 1);
			mDemoBuffer.WriteNumBits(DEMO_FILE_EXISTS, 5);
			mDemoBuffer.WriteNumBits((aFP != NULL) ? 1 : 0, 1); 
		}

		if (aFP == NULL)		
			return false;		
		
		p_fclose(aFP);
		return true;
	}
}

bool SexyAppBase::EraseFile(const std::string& theFileName)
{
	if (mPlayingDemoBuffer)
		return true;

	return DeleteFileA(theFileName.c_str()) != 0;
}

void SexyAppBase::SEHOccured()
{
	SetMusicVolume(0);
	::ShowWindow(mHWnd, SW_HIDE);
	mSEHOccured = true;
	EnforceCursor();
}

std::string SexyAppBase::GetGameSEHInfo()
{
	int aSecLoaded = (GetTickCount() - mTimeLoaded) / 1000;

	char aTimeStr[16];
	sprintf(aTimeStr, "%02d:%02d:%02d", (aSecLoaded/60/60), (aSecLoaded/60)%60, aSecLoaded%60);
	
	char aThreadIdStr[16];
	sprintf(aThreadIdStr, "%lX", mPrimaryThreadId);

	std::string anInfoString = 
		"Product: " + mProdName + "\r\n" +		
		"Version: " + mProductVersion + "\r\n";			

	anInfoString +=
		"Time Loaded: " + std::string(aTimeStr) + "\r\n"
		"Fullscreen: " + (mIsWindowed ? std::string("No") : std::string("Yes")) + "\r\n"
		"Primary ThreadId: " + aThreadIdStr + "\r\n";	

	return anInfoString;						
}


void SexyAppBase::ShutdownHook()
{
}

void SexyAppBase::Shutdown()
{
	if ((mPrimaryThreadId != 0) && (GetCurrentThreadId() != mPrimaryThreadId))
	{
		mLoadingFailed = true;
	}
	else if (!mShutdown)
	{
		mExitToTop = true;
		mShutdown = true;
		ShutdownHook();

		if (mPlayingDemoBuffer)
		{
			//if the music/sfx volume is 0, then it means that in playback
			//someone pressed the "S" key to mute sounds (or that the 
			//sound volume was set to 0 in the first place). Out of politeness,
			//return the system sound volume to what it last was in the game.
			SetMusicVolume(mDemoMusicVolume);
			SetSfxVolume(mDemoSfxVolume);
		}

		// Blah
		while (mCursorThreadRunning)
		{
			Sleep(10);
		}

		if (mMusicInterface != NULL)
			mMusicInterface->StopAllMusic();		
		
		if (mHWnd != NULL) 
		{
			ShowWindow(mHWnd, SW_HIDE);			
		}

		RestoreScreenResolution();

		if (mReadFromRegistry)
			WriteToRegistry();

		if (mDDInterface != nullptr && mDDInterface->mD3DInterface != nullptr &&
			mDDInterface->mD3DInterface->mD3D11 != nullptr)
		{
			D3D11Renderer* aRender = mDDInterface->mD3DInterface->mD3D11;
			aRender->SetScalePresent(D3D11Renderer::ScalePresentFn());
			mDDInterface->mD3DInterface->Flush();
			aRender->PrepareForResize();
		}
		mScaleRuntime.DestroyDevice();
		CleanupScalePresent();

		//ImageLib::CloseJPEG2000();
	}
}

void SexyAppBase::RestoreScreenResolution()
{
	if (mFullScreenWindow)
	{
		EnumWindows(ChangeDisplayWindowEnumProc,0); // get any windows that appeared while we were running
		ChangeDisplaySettings(NULL,0);
		EnumWindows(ChangeDisplayWindowEnumProc,1); // restore window pos
		mFullScreenWindow = false;
	}
}
	
void SexyAppBase::DoExit(int theCode)
{
	RestoreScreenResolution();
	exit(theCode);
}

void SexyAppBase::UpdateFrames()
{
	const int anUpdateNumber = mUpdateCount + 1;
	const std::uint64_t anUpdateStart = LegacyRuntimeTraceNowMicroseconds();
	static std::uint64_t aPreviousUpdateStart = 0;
	if (anUpdateStart != 0 && aPreviousUpdateStart != 0)
	{
		LegacyRuntimeTraceDuration(
			"update-gap",
			anUpdateNumber,
			aPreviousUpdateStart,
			anUpdateStart);
	}
	aPreviousUpdateStart = anUpdateStart;
	LegacyRuntimeTraceScope anUpdateScope("update-total", anUpdateNumber);

	mUpdateCount++;	

	if (!mMinimized)
	{
		LegacyRuntimeTraceScope aWidgetUpdateScope("update-widgets", mUpdateCount);
		if (mWidgetManager->UpdateFrame())
			++mFPSDirtyCount;
	}

	{
		LegacyRuntimeTraceScope anAudioUpdateScope("update-audio", mUpdateCount);
		mMusicInterface->Update();
	}
	{
		LegacyRuntimeTraceScope anImageCleanupScope("update-image-cleanup", mUpdateCount);
		CleanSharedImages();
	}
}

void SexyAppBase::DoUpdateFramesF(float theFrac)
{
	if ((mVSyncUpdates) && (!mMinimized))
		mWidgetManager->UpdateFrameF(theFrac);	
}

bool SexyAppBase::DoUpdateFrames()
{
	SEXY_AUTO_PERF("SexyAppBase::DoUpdateFrames");

	if (gScreenSaverActive)
		return false;

	if (mPlayingDemoBuffer)
	{
		if ((mLoadingThreadCompleted) && (!mLoaded) && (mDemoLoadingComplete))
		{			
			mLoaded = true;
			::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);
			mYieldMainThread = false;
			LoadingThreadCompleted();
		}

		// Hrrm not sure why we check (mUpdateCount != mLastDemoUpdateCnt) here
		if ((mLoaded == mDemoLoadingComplete) && (mUpdateCount != mLastDemoUpdateCnt))		
		{
			UpdateFrames();		
			return true;
		}

		return false;
	}
	else
	{
		if ((mLoadingThreadCompleted) && (!mLoaded))
		{
			::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);
			mLoaded = true;
			mYieldMainThread = false;
			LoadingThreadCompleted();

			if (mRecordingDemoBuffer)
			{
				WriteDemoTimingBlock();
				mDemoBuffer.WriteNumBits(0, 1);
				mDemoBuffer.WriteNumBits(DEMO_LOADING_COMPLETE, 5);	
			}
		}
				
		UpdateFrames();		
		return true;
	}
}

bool gIsFailing = false;

void SexyAppBase::Redraw(Rect* theClipRect)
{
	SEXY_AUTO_PERF("SexyAppBase::Redraw");
	LegacyRuntimeTraceScope aTraceScope("present", mUpdateCount);

	// Do mIsDrawing check because we could enter here at a bad time if any windows messages
	//  are processed during WidgetManager->Draw
	if ((mIsDrawing) || (mShutdown))
		return;

	if (gScreenSaverActive)
		return;

	static DWORD aRetryTick = 0;
	if (!mDDInterface->Redraw(theClipRect))
	{
		//extern bool gD3DInterfacePreDrawError;
		gD3DInterfacePreDrawError = false; // this predraw error happens naturally when ddraw is failing
		if (!gIsFailing)
		{
			//gDebugStream << GetTickCount() << " Redraw failed!" << std::endl;
			gIsFailing = true;
		}

		WINDOWPLACEMENT aWindowPlacement;
		ZeroMemory(&aWindowPlacement, sizeof(aWindowPlacement));
		aWindowPlacement.length = sizeof(aWindowPlacement);
		::GetWindowPlacement(mHWnd, &aWindowPlacement);
		
		DWORD aTick = GetTickCount();
		if ((mActive || (aTick-aRetryTick>1000 && mIsPhysWindowed)) && (aWindowPlacement.showCmd != SW_SHOWMINIMIZED) && (!mMinimized))
		{
			aRetryTick = aTick;

			mWidgetManager->mImage = NULL;

			// Re-check resolution at this point, because we hit here when you change your resolution.
			if (((mWidth >= GetSystemMetrics(SM_CXFULLSCREEN)) || (mHeight >= GetSystemMetrics(SM_CYFULLSCREEN))) && (mIsWindowed))
			{
				if (mForceWindowed)
				{
					Popup(GetString("PLEASE_SET_COLOR_DEPTH", _S("Please set your desktop color depth to 16 bit."))); 
					Shutdown();
					return;
				}
				mForceFullscreen = true;

				SwitchScreenMode(false);
				return;
			}


			int aResult = InitDDInterface();

			//gDebugStream << GetTickCount() << " ReInit..." << std::endl;
			
			if ((mIsWindowed) && (aResult == DDInterface::RESULT_INVALID_COLORDEPTH))
			{
				//gDebugStream << GetTickCount() << "ReInit Invalid Colordepth" << std::endl;
				if (!mActive) // don't switch to full screen if not active app
					return;

				SwitchScreenMode(false);
				mForceFullscreen = true;
				return;
			}
			else if (aResult == DDInterface::RESULT_3D_FAIL)
			{
				Popup(GetString("D3D11_REQUIRED",
					_S("Direct3D 11 reinitialization failed: ")) +
					StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
				DoExit(1);
				return;
			}
			else if (aResult != DDInterface::RESULT_OK)
			{
				Popup(GetString("D3D11_REQUIRED", _S("Direct3D 11 reinitialization failed: ")) + StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
				DoExit(1);
				//gDebugStream << GetTickCount() << " ReInit Failed" << std::endl;
				//Fail("Failed to initialize DirectDraw");
				//Sleep(1000);				
				
				return;
			}						

			ReInitImages();

			mWidgetManager->mImage = mDDInterface->GetScreenImage();
			mWidgetManager->MarkAllDirty();

			mLastTime = SexyGetTickCount();
		}
	}
	else
	{
		if (gIsFailing)
		{
			//gDebugStream << GetTickCount() << " Redraw succeeded" << std::endl;
			gIsFailing = false;
			aRetryTick = 0;
		}
	}

	mFPSFlipCount++;
}

///////////////////////////// FPS Stuff
static PerfTimer gFPSTimer;
static int gFrameCount;
static int gFPSDisplay;
static bool gForceDisplay = false;
static void CalculateFPS()
{
	gFrameCount++;

	static SysFont aFont(gSexyAppBase,"Tahoma",8);
	if (gFPSImage==NULL)
	{
		gFPSImage = new DDImage(gSexyAppBase->mDDInterface);
		gFPSImage->Create(50,aFont.GetHeight()+4);
		gFPSImage->SetImageMode(false,false);
		gFPSImage->SetVolatile(true);
		gFPSImage->mPurgeBits = false;
		gFPSImage->PurgeBits();
	}

	if (gFPSTimer.GetDuration() >= 1000 || gForceDisplay)
	{
		gFPSTimer.Stop();
		if (!gForceDisplay)
			gFPSDisplay = (int)(gFrameCount*1000/gFPSTimer.GetDuration() + 0.5f);
		else
		{
			gForceDisplay = false;
			gFPSDisplay = 0;
		}

		gFPSTimer.Start();
		gFrameCount = 0;

		Graphics aDrawG(gFPSImage);
		aDrawG.SetFont(&aFont);
		SexyString aFPS = StrFormat(_S("FPS: %d"), gFPSDisplay);
		aDrawG.SetColor(0x000000);
		aDrawG.FillRect(0,0,gFPSImage->GetWidth(),gFPSImage->GetHeight());
		aDrawG.SetColor(0xFFFFFF);
		aDrawG.DrawString(aFPS,2,aFont.GetAscent());
		//gFPSImage->mKeepBits = false;
		//gFPSImage->GenerateDDSurface();
		gFPSImage->mBitsChangedCount++;
	}
}

///////////////////////////// FPS Stuff to draw mouse coords
static void FPSDrawCoords(int theX, int theY)
{
	static SysFont aFont(gSexyAppBase,"Tahoma",8);
	if (gFPSImage==NULL)
	{
		gFPSImage = new DDImage(gSexyAppBase->mDDInterface);
		gFPSImage->Create(50,aFont.GetHeight()+4);
		gFPSImage->SetImageMode(false,false);
		gFPSImage->SetVolatile(true);
		gFPSImage->mPurgeBits = false;
		gFPSImage->PurgeBits();
	}

	Graphics aDrawG(gFPSImage);
	aDrawG.SetFont(&aFont);
	SexyString aFPS = StrFormat(_S("%d,%d"),theX,theY);
	aDrawG.SetColor(0x000000);
	aDrawG.FillRect(0,0,gFPSImage->GetWidth(),gFPSImage->GetHeight());
	aDrawG.SetColor(0xFFFFFF);
	aDrawG.DrawString(aFPS,2,aFont.GetAscent());	
	gFPSImage->mBitsChangedCount++;
}

///////////////////////////// Demo TimeLeft Stuff
static DDImage* gDemoTimeLeftImage = NULL;
static void CalculateDemoTimeLeft()
{
	static SysFont aFont(gSexyAppBase,"Tahoma",8);
	static DWORD aLastTick = 0;

	if (gDemoTimeLeftImage==NULL)
	{
		gDemoTimeLeftImage = new DDImage(gSexyAppBase->mDDInterface);
		gDemoTimeLeftImage->Create(50,aFont.GetHeight()+4);
		gDemoTimeLeftImage->SetImageMode(false,false);
		gDemoTimeLeftImage->SetVolatile(true);
		gDemoTimeLeftImage->mPurgeBits = false;
		gDemoTimeLeftImage->PurgeBits();
	}

	DWORD aTick = GetTickCount();
	if (aTick - aLastTick < 1000/gSexyAppBase->mUpdateMultiplier)
		return;

	aLastTick = aTick;

	int aNumUpdatesLeft = gSexyAppBase->mDemoLength - gSexyAppBase->mUpdateCount;
	Graphics aDrawG(gDemoTimeLeftImage);
	aDrawG.SetFont(&aFont);

	int aTotalSeconds = aNumUpdatesLeft*gSexyAppBase->mFrameTime/1000;
	int aSeconds = aTotalSeconds%60;
	int aMinutes = (aTotalSeconds/60)%60;
	int anHours = (aTotalSeconds/3600);

	SexyString aFPS = StrFormat(_S("%02d:%02d:%02d"), anHours,aMinutes,aSeconds);
	aDrawG.SetColor(0x000000);
	aDrawG.FillRect(0,0,gDemoTimeLeftImage->GetWidth(),gDemoTimeLeftImage->GetHeight());
	aDrawG.SetColor(0xFFFFFF);
	aDrawG.DrawString(aFPS,2,aFont.GetAscent());	
	gDemoTimeLeftImage->mBitsChangedCount++;
}

static void UpdateScreenSaverInfo(DWORD theTick)
{
	if (gSexyAppBase->IsScreenSaver() || !gSexyAppBase->mIsPhysWindowed)
		return;

	// Get screen saver timeout		
	static DWORD aPeriodicTick = 0;
	static DWORD aScreenSaverTimeout = 60000;
	static BOOL aScreenSaverEnabled = TRUE;

	if (theTick-aPeriodicTick > 10000)
	{
		aPeriodicTick = theTick;

		int aTimeout = 0;

		SystemParametersInfo(SPI_GETSCREENSAVETIMEOUT,0,&aTimeout,0);
		SystemParametersInfo(SPI_GETSCREENSAVEACTIVE,0,&aScreenSaverEnabled,0);
		aTimeout-=2;

		if (aTimeout < 1)
			aTimeout = 1;

		aScreenSaverTimeout = aTimeout*1000;

		if (!aScreenSaverEnabled)
			gScreenSaverActive = false;

		LegacyRuntimeTraceInstant(
			"screensaver-config",
			gSexyAppBase->mUpdateCount,
			"timeout=%d enabled=%d",
			(int)aScreenSaverTimeout,
			aScreenSaverEnabled ? 1 : 0);
	}

	// Get more accurate last user input time
	if (gGetLastInputInfoFunc)
	{
		LASTINPUTINFO anInfo;
		anInfo.cbSize = sizeof(anInfo);
		if (gGetLastInputInfoFunc(&anInfo))
		{
			// anInfo.dwTime is on the GetTickCount clock, while theTick
			// (SexyGetTickCount) is QPC-derived. Translating before comparing
			// keeps the screensaver idle test on one clock; subtracting the
			// raw values made the game look idle for the whole clock offset
			// and spuriously froze it in a 100% CPU busy loop.
			DWORD aNowGetTick = GetTickCount();
			DWORD aLastInput = anInfo.dwTime;
			if (aLastInput > aNowGetTick)
				aLastInput = aNowGetTick;

			DWORD aQpcLastInput = theTick - (aNowGetTick - aLastInput);
			gSexyAppBase->mLastUserInputTick = std::max(gSexyAppBase->mLastUserInputTick, aQpcLastInput);
		}
	}

	if (!aScreenSaverEnabled)
		return;

	DWORD anIdleTime = theTick - gSexyAppBase->mLastUserInputTick;
	if (gScreenSaverActive)
	{
		BOOL aBool = FALSE;
		if (SystemParametersInfo(SPI_GETSCREENSAVERRUNNING, 0, &aBool, 0))
		{
			if (aBool) // screen saver not off yet
				return;
		}

		if (anIdleTime < aScreenSaverTimeout)
		{
			gScreenSaverActive = false;
			LegacyRuntimeTraceInstant(
				"screensaver-clear",
				gSexyAppBase->mUpdateCount,
				"timeout=%d idle=%d",
				(int)aScreenSaverTimeout,
				(int)anIdleTime);
			gSexyAppBase->mWidgetManager->MarkAllDirty();
		}
	}
	else if (anIdleTime > aScreenSaverTimeout)
	{
		gScreenSaverActive = true;
		LegacyRuntimeTraceInstant(
			"screensaver-active",
			gSexyAppBase->mUpdateCount,
			"timeout=%d idle=%d",
			(int)aScreenSaverTimeout,
			(int)anIdleTime);
	}
}

bool SexyAppBase::DrawDirtyStuff()
{
	SEXY_AUTO_PERF("SexyAppBase::DrawDirtyStuff");
	LegacyRuntimeTraceScope aTraceScope("draw-dirty-total", mUpdateCount);
	MTAutoDisallowRand aDisallowRand;

	if (gIsFailing) // just try to reinit
	{
		Redraw(NULL);
		mHasPendingDraw = false;
		mLastDrawWasEmpty = true;		
		return false;
	}	

	if (mShowFPS)
	{
		switch(mShowFPSMode)
		{
			case FPS_ShowFPS: CalculateFPS(); break;
			case FPS_ShowCoords:
				if (mWidgetManager!=NULL)
					FPSDrawCoords(mWidgetManager->mLastMouseX, mWidgetManager->mLastMouseY); 
				break;
		}

		if (mPlayingDemoBuffer)
			CalculateDemoTimeLeft();
	}

	DWORD aStartTime = SexyGetTickCount();

	// Update user input and screen saver info
	static DWORD aPeriodicTick = 0;
	if (aStartTime-aPeriodicTick > 1000)
	{
		aPeriodicTick = aStartTime;
		UpdateScreenSaverInfo(aStartTime);
	}

	if (gScreenSaverActive)
	{
		mHasPendingDraw = false;
		mLastDrawWasEmpty = true;		
		return false;
	}

	mIsDrawing = true;
	bool drewScreen = mWidgetManager->DrawScreen();
	mIsDrawing = false;

	if ((drewScreen || (aStartTime - mLastDrawTick >= 1000) || (mCustomCursorDirty)) &&
		((int) (aStartTime - mNextDrawTick) >= 0))
	{
		mLastDrawWasEmpty = false;

		mDrawCount++;		

		DWORD aMidTime = SexyGetTickCount();

		mFPSCount++;
		mFPSTime += aMidTime - aStartTime;

		mDrawTime += aMidTime - aStartTime;

		if (mShowFPS)
		{
			Graphics g(mDDInterface->GetScreenImage());
			g.DrawImage(gFPSImage,mWidth-gFPSImage->GetWidth()-10,mHeight-gFPSImage->GetHeight()-10);
		
			if (mPlayingDemoBuffer)
				g.DrawImage(gDemoTimeLeftImage,mWidth-gDemoTimeLeftImage->GetWidth()-10,mHeight-gFPSImage->GetHeight()-gDemoTimeLeftImage->GetHeight()-15);
		}

		if (mWaitForVSync && mIsPhysWindowed && mSoftVSyncWait)
		{
			DWORD aTick = SexyGetTickCount();
			if (aTick-mLastDrawTick < mDDInterface->mMillisecondsPerFrame)
				Sleep(mDDInterface->mMillisecondsPerFrame - (aTick-mLastDrawTick));
		}

		DWORD aPreScreenBltTime = SexyGetTickCount();
		mLastDrawTick = aPreScreenBltTime;

		Redraw(NULL);		

		// This is our one UpdateFTimeAcc if we are vsynched
		UpdateFTimeAcc(); 

		DWORD aEndTime = SexyGetTickCount();

		mScreenBltTime = aEndTime - aPreScreenBltTime;

#ifdef _DEBUG
		/*if (mFPSTime >= 5000) // Show FPS about every 5 seconds
		{
			ulong aTickNow = GetTickCount();

			OutputDebugString(StrFormat(_S("Theoretical FPS: %d\r\n"), (int) (mFPSCount * 1000 / mFPSTime)).c_str());
			OutputDebugString(StrFormat(_S("Actual      FPS: %d\r\n"), (mFPSFlipCount * 1000) / max((aTickNow - mFPSStartTick), 1)).c_str());
			OutputDebugString(StrFormat(_S("Dirty Rate     : %d\r\n"), (mFPSDirtyCount * 1000) / max((aTickNow - mFPSStartTick), 1)).c_str());

			mFPSTime = 0;
			mFPSCount = 0;
			mFPSFlipCount = 0;
			mFPSStartTick = aTickNow;
			mFPSDirtyCount = 0;
		}*/
#endif

		if ((mLoadingThreadStarted) && (!mLoadingThreadCompleted))
		{
			int aTotalTime = aEndTime - aStartTime;

			mNextDrawTick += 35 + std::max(aTotalTime, 15);

			if ((int) (aEndTime - mNextDrawTick) >= 0)			
				mNextDrawTick = aEndTime;			

			/*char aStr[256];
			sprintf(aStr, "Next Draw Time: %d\r\n", mNextDrawTick);
			OutputDebugString(aStr);*/
		}
		else
			mNextDrawTick = aEndTime;

		mHasPendingDraw = false;		
		mCustomCursorDirty = false;

		return true;
	}
	else
	{		
		mHasPendingDraw = false;
		mLastDrawWasEmpty = true;		
		return false;
	}
}

void SexyAppBase::LogScreenSaverError(const std::string &theError)
{
	static bool firstTime = true;
	char aBuf[512];

	const char *aFlag = firstTime?"w":"a+";
	firstTime = false;

	FILE *aFile = fopen(GetLogFilePath("ScrError.txt").c_str(),aFlag);
	if (aFile != NULL)
	{
		fprintf(aFile,"%s %s %lu\n",theError.c_str(),_strtime(aBuf),GetTickCount());
		fclose(aFile);
	}
}

void SexyAppBase::BeginPopup()
{
	if (!mIsPhysWindowed)
	{
		mNoDefer = true;
	}
}

void SexyAppBase::EndPopup()
{
	if (!mIsPhysWindowed)
		mNoDefer = false;

	ClearUpdateBacklog();
	ClearKeysDown();

	if (mWidgetManager->mDownButtons)
	{
		mWidgetManager->DoMouseUps();
		ReleaseCapture();
	}
}

int SexyAppBase::MsgBox(const std::string& theText, const std::string& theTitle, int theFlags)
{
//	if (mDDInterface && mDDInterface->mDD)
//		mDDInterface->mDD->FlipToGDISurface();
	if (IsScreenSaver())
	{
		LogScreenSaverError(theText);
		return IDOK;
	}

	BeginPopup();
	int aResult = MessageBoxA(mHWnd, theText.c_str(), theTitle.c_str(), theFlags);
	EndPopup();

	return aResult;
}

int SexyAppBase::MsgBox(const std::wstring& theText, const std::wstring& theTitle, int theFlags)
{
//	if (mDDInterface && mDDInterface->mDD)
//		mDDInterface->mDD->FlipToGDISurface();
	if (IsScreenSaver())
	{
		LogScreenSaverError(WStringToString(theText));
		return IDOK;
	}

	BeginPopup();
	int aResult = MessageBoxW(mHWnd, theText.c_str(), theTitle.c_str(), theFlags);
	EndPopup();

	return aResult;
}

void SexyAppBase::Popup(const std::string& theString)
{
	if (IsScreenSaver())
	{
		LogScreenSaverError(theString);
		return;
	}

	BeginPopup();
	if (!mShutdown)
		::MessageBoxA(mHWnd, theString.c_str(), SexyStringToString(GetString("FATAL_ERROR", _S("FATAL ERROR"))).c_str(), MB_APPLMODAL | MB_ICONSTOP);
	EndPopup();
}

void SexyAppBase::Popup(const std::wstring& theString)
{
	if (IsScreenSaver())
	{
		LogScreenSaverError(WStringToString(theString));
		return;
	}

	BeginPopup();
	if (!mShutdown)
		::MessageBoxW(mHWnd, theString.c_str(), SexyStringToWString(GetString("FATAL_ERROR", _S("FATAL ERROR"))).c_str(), MB_APPLMODAL | MB_ICONSTOP);
	EndPopup();
}

void SexyAppBase::SafeDeleteWidget(Widget* theWidget)
{
	WidgetSafeDeleteInfo aWidgetSafeDeleteInfo;
	aWidgetSafeDeleteInfo.mUpdateAppDepth = mUpdateAppDepth;
	aWidgetSafeDeleteInfo.mWidget = theWidget;
	mSafeDeleteList.push_back(aWidgetSafeDeleteInfo);
}

static INT_PTR CALLBACK MarkerListDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	(void)lParam;
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			HWND aListBox = GetDlgItem(hwnd,100);

			DWORD       dwExtent = 0;
			HDC         hDCListBox;
			HFONT       hFontOld, hFontNew;
			TEXTMETRIC  tm; 
			RECT aRect;
			SIZE aSize;

			hDCListBox = GetDC(aListBox); 
			hFontNew = (HFONT)SendMessage(aListBox, WM_GETFONT, 0, 0); 
			hFontOld = (HFONT)SelectObject(hDCListBox, hFontNew); 
			GetTextMetrics(hDCListBox, (LPTEXTMETRIC)&tm); 
			GetClientRect(hwnd, &aRect);
			MoveWindow(aListBox,10,10,aRect.right-aRect.left-20,aRect.bottom-aRect.top-20,FALSE);
			for (SexyAppBase::DemoMarkerList::iterator anItr = gSexyAppBase->mDemoMarkerList.begin(); anItr != gSexyAppBase->mDemoMarkerList.end(); ++anItr)
			{
				if (anItr->second <= gSexyAppBase->mUpdateCount)
					continue;

				int aTotalSeconds = (gSexyAppBase->mDemoLength - anItr->second)*gSexyAppBase->mFrameTime/1000;
				int aSeconds = aTotalSeconds%60;
				int aMinutes = (aTotalSeconds/60)%60;
				int anHours = (aTotalSeconds/3600);

				SexyString aStr = StrFormat(_S("%s (%02d:%02d:%02d)"), anItr->first.c_str(),anHours,aMinutes,aSeconds);				
				GetTextExtentPoint32(hDCListBox, aStr.c_str(), aStr.length(), &aSize);
				dwExtent = std::max (aSize.cx + tm.tmAveCharWidth, (LONG)dwExtent);
				SendMessage(aListBox, LB_SETHORIZONTALEXTENT, dwExtent, 0);
				LRESULT anIndex = SendMessage(aListBox, LB_ADDSTRING, 0, (LPARAM)aStr.c_str());
				SendMessage(aListBox, LB_SETITEMDATA, anIndex, anItr->second);
			}
	
			SelectObject(hDCListBox, hFontOld);
			ReleaseDC(aListBox, hDCListBox); 

			return TRUE;
		}

		case WM_CLOSE:
			EndDialog(hwnd,0);
			return TRUE;

		case WM_COMMAND:
			if (HIWORD(wParam)==LBN_DBLCLK)
			{
				HWND aListBox = GetDlgItem(hwnd,100);

				int anIndex = SendMessage(aListBox,LB_GETCURSEL,0,0);
				if (anIndex >= 0)
				{
					int anUpdateTime = SendMessage(aListBox,LB_GETITEMDATA,anIndex,0);
					if (anUpdateTime > gSexyAppBase->mUpdateCount)
					{
						gSexyAppBase->mFastForwardToUpdateNum = anUpdateTime;
						EndDialog(hwnd,0);
					}
				}
				return TRUE;
			}
			break;

	}

	return FALSE;
}

static LPWORD lpdwAlign ( LPWORD lpIn)
{
    ULONG ul;

    ul = (ULONG)(intptr_t)lpIn;
    ul +=3;
    ul >>=2;
    ul <<=2;
    return (LPWORD)(intptr_t)ul;
}

static int ListDemoMarkers()
{
	HGLOBAL hgbl;
    LPDLGTEMPLATE lpdt;
    LPDLGITEMTEMPLATE lpdit;
    LPWORD lpw;
    LPWSTR lpwsz;
    LRESULT ret;
    int nchar;

    hgbl = GlobalAlloc(GMEM_ZEROINIT, 1024);
    if (!hgbl)
        return -1;
 
    lpdt = (LPDLGTEMPLATE)GlobalLock(hgbl);
 
    // Define a dialog box. 
    lpdt->style = WS_POPUP | WS_BORDER | WS_SYSMENU | DS_MODALFRAME | WS_CAPTION | DS_SETFONT;
    lpdt->cdit = 1;  // number of controls
    lpdt->x  = 10;  lpdt->y  = 10;
    lpdt->cx = 200; lpdt->cy = 200;

    lpw = (LPWORD) (lpdt + 1);
    *lpw++ = 0;   // no menu
    *lpw++ = 0;   // predefined dialog box class (by default)

    lpwsz = (LPWSTR) lpw;
    nchar = MultiByteToWideChar (CP_ACP, 0, "Marker List", -1, lpwsz, 50);
    lpw   += nchar;
	*lpw++ = 8;
	lpwsz = (LPWSTR) lpw;
    nchar = MultiByteToWideChar (CP_ACP, 0, "Tahoma", -1, lpwsz, 50);
	lpw += nchar;

	// Define Listbox
    lpw = lpdwAlign (lpw); // align DLGITEMTEMPLATE on DWORD boundary
    lpdit = (LPDLGITEMTEMPLATE) lpw;
    lpdit->x  = 5; lpdit->y  = 5;
    lpdit->cx = 190; lpdit->cy = 195;
    lpdit->id = 100;  
	lpdit->style = WS_VISIBLE | WS_CHILD | WS_VSCROLL | WS_HSCROLL | LBS_NOTIFY;
	lpdit->dwExtendedStyle = WS_EX_CLIENTEDGE;
    lpw = (LPWORD) (lpdit + 1);
    *lpw++ = 0xFFFF;
    *lpw++ = 0x0083;    // listbox class
	*lpw++ = 0;			// no window text
    *lpw++ = 0;			// no creation data


    GlobalUnlock(hgbl); 
    ret = DialogBoxIndirect(gHInstance, (LPDLGTEMPLATE) hgbl, gSexyAppBase->mHWnd, (DLGPROC) MarkerListDialogProc); 
    GlobalFree(hgbl); 

	gSexyAppBase->mLastTime = SexyGetTickCount();

    return ret; 
}

static INT_PTR CALLBACK JumpToTimeDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	(void)lParam;
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			HWND anEdit = GetDlgItem(hwnd,100);
			HKEY aGameKey;
			std::string aKeyName = RemoveTrailingSlash("SOFTWARE\\" + gSexyAppBase->mRegKey);
			if (RegOpenKeyExA(HKEY_CURRENT_USER, aKeyName.c_str(), 0, KEY_READ | KEY_WRITE, &aGameKey) == ERROR_SUCCESS)
			{
				char aBuf[1024];
				DWORD aLength = 1000;
				DWORD aType = REG_SZ;
				if (RegQueryValueExA(aGameKey, "DemoJumpTime", 0, &aType, (uchar*) aBuf, &aLength) == ERROR_SUCCESS)
				{
					aBuf[aLength] = 0;
					SetWindowTextA(anEdit,aBuf);
					SendMessage(anEdit,EM_SETSEL,0,-1);
				}
				RegCloseKey(aGameKey);
			}
			return TRUE;
		}
		break;

		case WM_CLOSE:
			EndDialog(hwnd,0);
			return TRUE;

		case WM_COMMAND:
			if (HIWORD(wParam)==BN_CLICKED)
			{
				if (LOWORD(wParam)==IDOK)
				{
					char aBuf[512];
					HWND anEdit = GetDlgItem(hwnd,100);
					GetWindowTextA(anEdit,aBuf,500);

					HKEY aGameKey;
					std::string aKeyName = RemoveTrailingSlash("SOFTWARE\\" + gSexyAppBase->mRegKey);
					if (RegOpenKeyExA(HKEY_CURRENT_USER, aKeyName.c_str(), 0, KEY_READ | KEY_WRITE, &aGameKey) == ERROR_SUCCESS)
					{
						RegSetValueExA(aGameKey, "DemoJumpTime", 0, REG_SZ, (const BYTE*)aBuf, strlen(aBuf)+1);
						RegCloseKey(aGameKey);
					}

					int aTime = 0;
					char *aPtr = strtok(aBuf,":");
					while (aPtr != NULL)
					{
						aTime *= 60;
						aTime += atoi(aPtr);
						aPtr = strtok(NULL,":");
					}
					aTime++;

					int aNumFrames = aTime*1000/gSexyAppBase->mFrameTime;
					gSexyAppBase->mFastForwardToUpdateNum = gSexyAppBase->mDemoLength - aNumFrames;					


				}
					
				EndDialog(hwnd,0);
				return TRUE;
			}
			break;
	}

	return FALSE;
}

static int DemoJumpToTime()
{
	HGLOBAL hgbl;
    LPDLGTEMPLATE lpdt;
    LPDLGITEMTEMPLATE lpdit;
    LPWORD lpw;
    LPWSTR lpwsz;
    LRESULT ret;
    int nchar;

    hgbl = GlobalAlloc(GMEM_ZEROINIT, 1024);
    if (!hgbl)
        return -1;
 
    lpdt = (LPDLGTEMPLATE)GlobalLock(hgbl);
 
    // Define a dialog box. 
    lpdt->style = WS_POPUP | WS_BORDER | WS_SYSMENU | DS_MODALFRAME | WS_CAPTION | DS_SETFONT;
    lpdt->cdit = 3;  // number of controls
    lpdt->x  = 10;  lpdt->y  = 10;
    lpdt->cx = 200; lpdt->cy = 50;

    lpw = (LPWORD) (lpdt + 1);
    *lpw++ = 0;   // no menu
    *lpw++ = 0;   // predefined dialog box class (by default)

    lpwsz = (LPWSTR) lpw;
    nchar = MultiByteToWideChar (CP_ACP, 0, "Jump To Time", -1, lpwsz, 50);
    lpw   += nchar;
	*lpw++ = 8;
	lpwsz = (LPWSTR) lpw;
    nchar = MultiByteToWideChar (CP_ACP, 0, "Tahoma", -1, lpwsz, 50);
	lpw += nchar;

	// Define Edit
    lpw = lpdwAlign (lpw); // align DLGITEMTEMPLATE on DWORD boundary
    lpdit = (LPDLGITEMTEMPLATE) lpw;
    lpdit->x  = 5; lpdit->y  = 5;
    lpdit->cx = 190; lpdit->cy = 15;
    lpdit->id = 100;  
	lpdit->style = WS_VISIBLE | WS_CHILD;
	lpdit->dwExtendedStyle = WS_EX_CLIENTEDGE;
    lpw = (LPWORD) (lpdit + 1);
    *lpw++ = 0xFFFF;
    *lpw++ = 0x0081;    // edit class
	*lpw++ = 0;			// no window text
    *lpw++ = 0;			// no creation data

	// Define Button
    lpw = lpdwAlign (lpw); // align DLGITEMTEMPLATE on DWORD boundary
    lpdit = (LPDLGITEMTEMPLATE) lpw;
    lpdit->x  = 30; lpdit->y  = 25;
    lpdit->cx = 60; lpdit->cy = 15;
    lpdit->id = IDOK;  
	lpdit->style = WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON;
//	lpdit->dwExtendedStyle = WS_EX_CLIENTEDGE;
    lpw = (LPWORD) (lpdit + 1);
    *lpw++ = 0xFFFF;
    *lpw++ = 0x0080;    // button class
	lpwsz = (LPWSTR) lpw;
	nchar = MultiByteToWideChar (CP_ACP, 0, "Ok", -1, lpwsz, 50);
    lpw   += nchar;
    lpw = lpdwAlign (lpw); // align creation data on DWORD boundary
    *lpw++ = 0;			// no creation data


	// Define Button
    lpw = lpdwAlign (lpw); // align DLGITEMTEMPLATE on DWORD boundary
    lpdit = (LPDLGITEMTEMPLATE) lpw;
    lpdit->x  = 100; lpdit->y  = 25;
    lpdit->cx = 60; lpdit->cy = 15;
    lpdit->id = IDCANCEL;  
	lpdit->style = WS_VISIBLE | WS_CHILD;
//	lpdit->dwExtendedStyle = WS_EX_CLIENTEDGE;
    lpw = (LPWORD) (lpdit + 1);
    *lpw++ = 0xFFFF;
    *lpw++ = 0x0080;    // button class
	lpwsz = (LPWSTR) lpw;
	nchar = MultiByteToWideChar (CP_ACP, 0, "Cancel", -1, lpwsz, 50);
    lpw   += nchar;
    lpw = lpdwAlign (lpw); // align creation data on DWORD boundary
    *lpw++ = 0;			// no creation data




    GlobalUnlock(hgbl); 
    ret = DialogBoxIndirect(gHInstance, (LPDLGTEMPLATE) hgbl, gSexyAppBase->mHWnd, (DLGPROC) JumpToTimeDialogProc); 
    GlobalFree(hgbl); 

	gSexyAppBase->mLastTime = SexyGetTickCount();

    return ret; 
}

static void ToggleDemoSoundVolume()
{
	if (gSexyAppBase->GetMusicVolume() == 0.0)
		gSexyAppBase->SetMusicVolume(gSexyAppBase->mDemoMusicVolume);
	else
	{
		gSexyAppBase->mDemoMusicVolume = gSexyAppBase->mMusicVolume;
		gSexyAppBase->SetMusicVolume(0.0);
	}

	if (gSexyAppBase->GetSfxVolume() == 0.0)
		gSexyAppBase->SetSfxVolume(gSexyAppBase->mDemoSfxVolume);
	else
	{
		gSexyAppBase->mDemoSfxVolume = gSexyAppBase->mSfxVolume;
		gSexyAppBase->SetSfxVolume(0.0);
	}
}

static DWORD gPowerSaveTick = 0;
static bool ScreenSaverWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT &theResult)
{
	static bool gCreated = false;
	static int gMouseMoveCount = 0;
	static int gLastMouseX = 0, gLastMouseY = 0;
	static bool gClosed = false;
	typedef BOOL (WINAPI *VERIFYPWDPROC)(HWND);
	static VERIFYPWDPROC aPasswordFunc = NULL;
	HMODULE aPasswordLib = NULL;

	if (gClosed)
		return false;

	switch (uMsg)
	{
		case WM_CREATE:
		{
			if (gCreated)
				return false;

			gCreated = true;
			POINT aMousePoint;
			GetCursorPos(&aMousePoint);
			gLastMouseX = aMousePoint.x;
			gLastMouseY = aMousePoint.y;

			// Password checking stuff for 95/98/ME
			OSVERSIONINFO aVersion;
			aVersion.dwOSVersionInfoSize = sizeof(aVersion);
			GetVersionEx(&aVersion);
			if (aVersion.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
			{
				HKEY hKey;
				if (RegOpenKey(HKEY_CURRENT_USER, REGSTR_PATH_SCREENSAVE ,&hKey) == ERROR_SUCCESS)
				{
					DWORD aCheckPwd = 0;
					DWORD aSize = sizeof(DWORD);
					DWORD aType;
					LONG aResult = RegQueryValueEx(hKey, REGSTR_VALUE_USESCRPASSWORD, NULL, &aType, (PBYTE) &aCheckPwd, &aSize);
					if (aResult==ERROR_SUCCESS && aCheckPwd)
					{
						aPasswordLib = LoadLibrary(TEXT("PASSWORD.CPL"));
						if (aPasswordLib)
						{
							aPasswordFunc = (VERIFYPWDPROC)GetProcAddress(aPasswordLib, "VerifyScreenSavePwd");
							// prevents user from ctrl-alt-deleting the screensaver etc to avoid typing in a password
							int aPrev;
							SystemParametersInfo(SPI_SCREENSAVERRUNNING, TRUE, &aPrev, 0); 
						}

					}
					RegCloseKey(hKey);
				}
			}
			return false;
		}
		break;

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
				case SC_SCREENSAVE:
				case SC_NEXTWINDOW:
				case SC_PREVWINDOW:
					theResult = FALSE;
					return true;

				default:
					return false;
			}
		}
		break;

		case WM_MOUSEMOVE:
		{
			int aMouseX = LOWORD(lParam);
			int aMouseY = HIWORD(lParam);
//			SEXY_TRACE(StrFormat("SCR MouseMove: %d %d",aMouseX,aMouseY).c_str());
			if (aMouseX!=gLastMouseX || aMouseY!=gLastMouseY)
			{
				gLastMouseX = aMouseX;
				gLastMouseY = aMouseY;
				gMouseMoveCount++;
			}

			if (gMouseMoveCount < 4)
			{
				theResult = 0;
				return true;
			}
		}
		break;

		case WM_NCACTIVATE:
		case WM_ACTIVATE:
		case WM_ACTIVATEAPP:
		{
			if (wParam != FALSE)
				return false;
		}
		break;

		case WM_CLOSE:
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
		case WM_MBUTTONDOWN:
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			break;

		default:
			return false;
	}

	if (gSexyAppBase!=NULL && gSexyAppBase->mHWnd!=hWnd) // wrong window
		return false;

	if (GetTickCount()-gPowerSaveTick < 1000) // powersave just went on so ignore certain messages that seem to come on certain os's at that time
	{
		switch (uMsg)
		{
			case WM_MOUSEMOVE: 
			case WM_NCACTIVATE:
			case WM_ACTIVATE: 
			case WM_ACTIVATEAPP:
			case WM_CLOSE: 
				return false;
		}
	}

	if (aPasswordFunc && gSexyAppBase!=NULL && gSexyAppBase->mInitialized) // need to verify password before closing
	{
		gSexyAppBase->mNoDefer = true;							// so the app doesn't draw over the password dialog
	    
		gClosed = true; // prevent this function from doing anything while in the password dialog
		BOOL aPasswordResult = aPasswordFunc(hWnd);
		gClosed = false; // let this functino work again

		if (gSexyAppBase!=NULL)
		{
			gSexyAppBase->mNoDefer = false;
			gSexyAppBase->ClearUpdateBacklog();
		}

		if (!aPasswordResult) // bad password
		{
			// Get new mouse coordinate
			POINT aMousePoint;
			GetCursorPos(&aMousePoint);
			gLastMouseX = aMousePoint.x;
			gLastMouseY = aMousePoint.y;
			gMouseMoveCount = 0;

			return false;
		}


		// can turn this SPI_SCREENSAVERRUNNING off now since screensaver is about to stop
		int aPrev;
		SystemParametersInfo(SPI_SCREENSAVERRUNNING, FALSE, &aPrev, 0); 

		// good password -> close and unload dll
		FreeLibrary(aPasswordLib);
		aPasswordLib = NULL;
		aPasswordFunc = NULL;
	}
	
	// Screen saver should shutdown
	gClosed = true;
	PostMessage(hWnd, WM_CLOSE, 0, 0);

/*	const char *str = "";
	switch (uMsg)
	{
		case WM_CREATE: str="WM_CREATE"; break;
		case WM_SYSCOMMAND: str="WM_SYSCOMMAND"; break;
		case WM_MOUSEMOVE: str="WM_MOUSEMOVE"; break;
		case WM_NCACTIVATE: str="WM_NCACTIVATE"; break;
		case WM_ACTIVATE: str="WM_ACTIVATE"; break;
		case WM_ACTIVATEAPP: str="WM_ACTIVATEAPP"; break;
		case WM_CLOSE: str="WM_CLOSE"; break;
		case WM_LBUTTONDOWN: str="WM_LBUTTONDOWN"; break;
		case WM_RBUTTONDOWN: str="WM_RBUTTONDOWN"; break;
		case WM_MBUTTONDOWN: str="WM_MBUTTONDOWN"; break;
		case WM_KEYDOWN: str="WM_KEYDOWN"; break;
		case WM_SYSKEYDOWN: str="WM_SYSKEYDOWN"; break;
	}

	SEXY_TRACE(StrFormat("Scr shutdown: %s",str).c_str());*/
	return false;
}

LRESULT CALLBACK SexyAppBase::WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (gSexyAppBase!=NULL && gSexyAppBase->IsScreenSaver())
	{
		LRESULT aResult;
		if (ScreenSaverWindowProc(hWnd,uMsg,wParam,lParam,aResult))
			return aResult;
	}

	SexyAppBase* aSexyApp = (SexyAppBase*)(intptr_t)GetWindowLongPtr(hWnd, GWLP_USERDATA);	
	switch (uMsg)
	{		
//  TODO: switch to killfocus/setfocus?
//	case WM_KILLFOCUS:
//	case WM_SETFOCUS:
//	if ((aSexyApp != NULL) && (!aSexyApp->mPlayingDemoBuffer))
//	{
//		if (hWnd == aSexyApp->mHWnd)
//			aSexyApp->mActive = uMsg==WM_SETFOCUS;
//	}
//	//Fallthrough

	case WM_TIMER:
		// The timer is only a wake-up plus mouse enter/exit bookkeeping. Handle
		// it synchronously instead of parking it in the
		// deferred queue: a parked timer splits otherwise-consecutive mouse
		// messages and taxes the deferred drain one 10ms tick per message,
		// which turns click bursts into visible stutter.
		if ((aSexyApp != NULL) && (!aSexyApp->mNoDefer))
			aSexyApp->ProcessTimerMessage(hWnd);
		return 0;

	case WM_ACTIVATEAPP:
		if ((aSexyApp != NULL) && (!aSexyApp->mPlayingDemoBuffer))
		{
			if (hWnd == aSexyApp->mHWnd)
			{
				aSexyApp->mActive = wParam != 0;
			}
		}
		//Fallthrough	

	case WM_SIZE:
	case WM_MOVE:
	case WM_LBUTTONDOWN:		
	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDBLCLK:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:		
	case WM_MBUTTONUP:		
	case WM_MOUSEMOVE:			
	case WM_KEYDOWN:
	case WM_SYSKEYDOWN:
	case WM_KEYUP:
	case WM_SYSKEYUP:
	case WM_CHAR:	
	case WM_CLOSE:
	case WM_MOUSEWHEEL:
	case WM_DISPLAYCHANGE:
	case WM_SYSCOLORCHANGE:
		{
/*			if (aSexyApp!=NULL && aSexyApp->mProcessInTimer && !aSexyApp->mShutdown && aSexyApp->mRunning)
			{
				if (uMsg==WM_TIMER && wParam==101)
				{
					for (int i=0; i<5; i++)
					{
						if (GetQueueStatus(QS_INPUT | QS_PAINT))
							break;

						if (!aSexyApp->Process(false))
							break;
					}
				}
					
				break;
			}*/

			/*if ((aSexyApp != NULL) && (aSexyApp->mNoDefer))
			{
				// Check to see if we should be windowed
				WINDOWPLACEMENT aWindowPlacement;
				aWindowPlacement.length = sizeof(aWindowPlacement);
				if (GetWindowPlacement(aSexyApp->mHWnd, &aWindowPlacement))
				{
					if (aWindowPlacement.showCmd == SW_SHOWMINIMIZED)
					{
						aSexyApp->Redraw(NULL);
					}
				}
			}*/

			if ((aSexyApp != NULL) && (!aSexyApp->mNoDefer))
			{
				bool keyDown = (uMsg==WM_KEYDOWN) || (uMsg==WM_SYSKEYDOWN);

				if ((keyDown) || (uMsg==WM_KEYUP) || (uMsg == WM_SYSKEYUP))
				{	
					if (wParam == VK_CONTROL)
						aSexyApp->mCtrlDown = keyDown;
					if (wParam == VK_MENU)
						aSexyApp->mAltDown = keyDown;
				}

				/*
				if ((keyDown) && (aSexyApp->DebugKeyDownAsync(wParam, aSexyApp->mCtrlDown, aSexyApp->mAltDown)))
					return 0;
				*/
				
				if (aSexyApp->mPlayingDemoBuffer)
				{
					if (uMsg==WM_CHAR)
					{
						switch (wParam)
						{
						case '+':
							aSexyApp->mUpdateMultiplier *= 1.5;
							break;
						case '-':
							aSexyApp->mUpdateMultiplier /= 1.5;
							break;
						case '=':
							aSexyApp->mUpdateMultiplier = 1;
							break;
						case 'p':
						case 'P':
							aSexyApp->mPaused = !aSexyApp->mPaused;
							aSexyApp->mLastTimeCheck = SexyGetTickCount();
							aSexyApp->mUpdateFTimeAcc = 0.0;
							break;

						case 'n':
						case 'N':
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mUpdateCount+1;
							aSexyApp->mFastForwardStep = true;
							break;

						case 'm':
						case 'M':
							aSexyApp->mFastForwardToMarker = true;
							break;

						case 'l':
						case 'L':
							ListDemoMarkers();
							break;

						case 'j':
						case 'J':
							DemoJumpToTime();
							break;

						case 's':
						case 'S':
							ToggleDemoSoundVolume();
							break;

						case '4':
							// Fast foward to 120 seconds before it ends
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength - (120000 / aSexyApp->mFrameTime);
							break;
						case '5':
							// Fast foward to 90 seconds before it ends
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength - (90000 / aSexyApp->mFrameTime);
							break;
						case '6':
							// Fast foward to 60 seconds before it ends
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength - (60000 / aSexyApp->mFrameTime);
							break;
						case '7':
							// Fast foward to 30 seconds before it ends
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength - (30000 / aSexyApp->mFrameTime);
							break;
						case '8':
							// Fast foward to 10 seconds before it ends
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength - (10000 / aSexyApp->mFrameTime);
							break;
						case '9':
							// Fast foward to 5 seconds before it ends
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength - (5000 / aSexyApp->mFrameTime);
							break;
						case '0':						
							// Fast forward to the end
							aSexyApp->mFastForwardToUpdateNum = aSexyApp->mDemoLength;
							break;

						}
					}
					else if (uMsg==WM_KEYDOWN)
						aSexyApp->DebugKeyDown(wParam);
				}

				bool pushMessage = true;

				if (aSexyApp->mDeferredMessages.size() > 0)
				{
					// Don't add any more messages after WM_CLOSE
					MSG* aMsg = &aSexyApp->mDeferredMessages.back();

					if (aMsg->message == WM_CLOSE)
						pushMessage = false;
					if ((uMsg == WM_TIMER) && (uMsg == aMsg->message))
						pushMessage = false; // Don't need more timer messages


					if (pushMessage && (uMsg==WM_SYSCOLORCHANGE || uMsg==WM_DISPLAYCHANGE)) // kill duplicate SysColorChange() events.
					{
						WindowsMessageList::iterator aMsgListItr = aSexyApp->mDeferredMessages.begin();
						while (pushMessage && aMsgListItr != aSexyApp->mDeferredMessages.end())
						{
							MSG& aMsg = *aMsgListItr;

							if (aMsg.message == WM_SYSCOLORCHANGE || aMsg.message == WM_DISPLAYCHANGE)
								pushMessage = false;

							++aMsgListItr;
						}
					}
				}

				if (pushMessage)
				{
					MSG msg;
					msg.hwnd = hWnd;
					msg.message = uMsg;
					msg.lParam = lParam;
					msg.wParam = wParam;	
					
					aSexyApp->mDeferredMessages.push_back(msg);
				}

				if (uMsg == WM_SIZE)
				{
					aSexyApp->mPhysMinimized = wParam == SIZE_MINIMIZED;
				}
				else if (uMsg == WM_SYSKEYDOWN)
				{
					if (wParam != VK_F4)
						return 0;		
				}
				else if (uMsg == WM_CLOSE)
				{
					/*char aStr[256];
					sprintf(aStr, "CLOSED HWND: %d\r\n", hWnd);
					OutputDebugString(aStr);*/
					
					aSexyApp->CloseRequestAsync();
					return 0;
				}
			}			
		}
		break;

	case WM_ENABLE:
		if (aSexyApp != NULL)
		{
			aSexyApp->mIsDisabled = wParam == 0;
		}
		break;

	case WM_QUERYOPEN:
		if ((aSexyApp != NULL) && (!aSexyApp->AppCanRestore()))
			return 0;
		break;

	case WM_SYSCHAR:
		if ((aSexyApp != NULL) && (aSexyApp->IsAltKeyUsed(wParam)))
			return 0;
		break;

	case WM_NCLBUTTONDOWN:
		if (aSexyApp!=NULL)
		{
//			aSexyApp->mProcessInTimer = true;
			LRESULT aResult = DefWindowProc(hWnd, uMsg, wParam, lParam);
//			aSexyApp->mProcessInTimer = false;
			aSexyApp->ClearUpdateBacklog();
			return aResult;
		}
		break;


	case WM_SYSCOMMAND:
		if (wParam==SC_MONITORPOWER)
		{
			gPowerSaveTick = GetTickCount();
			if (aSexyApp!=NULL && (!aSexyApp->mAllowMonitorPowersave || !aSexyApp->mLoaded))
				return FALSE;
		}
		if (wParam==SC_SCREENSAVE && aSexyApp!=NULL && (!aSexyApp->mLoaded || !aSexyApp->mIsPhysWindowed))
			return FALSE;

		break;

/*	case WM_DISPLAYCHANGE:
		SEXY_TRACE("WM_DISPLAYCHANGE 1");
		if (aSexyApp!=NULL && aSexyApp->mIsWindowed && aSexyApp->mDDInterface!=NULL && aSexyApp->mHWnd==hWnd && aSexyApp->mLoaded)
		{
			SEXY_TRACE("WM_DISPLAYCHANGE 2");
			aSexyApp->mDDInterface->Init(aSexyApp->mHWnd,aSexyApp->mIsWindowed);
			aSexyApp->mWidgetManager->mImage = aSexyApp->mDDInterface->GetScreenImage();
			aSexyApp->mWidgetManager->MarkAllDirty();
		}
		break;*/

	case WM_DESTROY:
		{
			char aStr[256];
			sprintf(aStr, "DESTROYED HWND: %p\r\n", hWnd);
			OutputDebugStringA(aStr);
		}
		break;	
	case WM_SETCURSOR:
		if (!aSexyApp->mSEHOccured)
			aSexyApp->EnforceCursor();
		return TRUE;		
	case WM_ERASEBKGND:
		return TRUE;		
	case WM_ENDSESSION:
		aSexyApp->Shutdown();
		break;
	case WM_PAINT:
		if ((aSexyApp->mInitialized) && (!gInAssert) && (!aSexyApp->mSEHOccured))
		{
			RECT aClientRect;
			GetClientRect(hWnd, &aClientRect);			

			PAINTSTRUCT ps;
			BeginPaint(hWnd, &ps);			
			
			if (aSexyApp->mRunning)
				aSexyApp->Redraw(NULL);

			EndPaint(hWnd, &ps);

			return 0;
		}
		break;
	}

	if ((aSexyApp != NULL) && (uMsg == aSexyApp->mNotifyGameMessage) && (hWnd == aSexyApp->mHWnd))
	{
		// Oh, we are trying to open another instance of ourselves.
		// Bring up the original window instead
		aSexyApp->HandleNotifyGameMessage(wParam);		
		return 0;
	}

	if (gSexyAppBase->mIsWideWindow)
		return DefWindowProcW(hWnd, uMsg, wParam, lParam);
	else
		return DefWindowProcA(hWnd, uMsg, wParam, lParam);
}

void SexyAppBase::HandleNotifyGameMessage(int theType)
{
	if (theType==0) // bring to front message
	{
		WINDOWPLACEMENT aWindowPlacement;
		aWindowPlacement.length = sizeof(WINDOWPLACEMENT);
		GetWindowPlacement(mHWnd, &aWindowPlacement);		

		if (aWindowPlacement.showCmd == SW_SHOWMINIMIZED)
			ShowWindow(mHWnd, SW_RESTORE);

		::SetForegroundWindow(mHWnd);
	}
}

void SexyAppBase::RehupFocus()
{
	bool wantHasFocus = mActive && !mMinimized;

	if (wantHasFocus != mHasFocus)
	{					
		mHasFocus = wantHasFocus;

		if (mHasFocus)
		{
			if (mMuteOnLostFocus)
				Unmute(true);
	
			mWidgetManager->GotFocus();
			GotFocus();
		}
		else
		{
			if (mMuteOnLostFocus)
				Mute(true);
	
			mWidgetManager->LostFocus();
			LostFocus();

			ReleaseCapture();
			mWidgetManager->DoMouseUps();
		}
	}
}

void SexyAppBase::ClearKeysDown()
{
	if (mWidgetManager != NULL) // fix stuck alt-key problem
	{
		for (int aKeyNum = 0; aKeyNum < 0xFF; aKeyNum++)
			mWidgetManager->mKeyDown[aKeyNum] = false;
	}
	mCtrlDown = false;
	mAltDown = false;
}

void SexyAppBase::WriteDemoTimingBlock()
{
	// Demo writing functions can only be called from the main thread and after SexyAppBase::Init
	DBG_ASSERTE(GetCurrentThreadId() == mPrimaryThreadId);

	while (mUpdateCount - mLastDemoUpdateCnt > 15)
	{
		mDemoBuffer.WriteNumBits(15, 4);
		mLastDemoUpdateCnt += 15;

		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_IDLE, 5);
		mDemoCmdOrder++;
	}
	
	mDemoBuffer.WriteNumBits(mUpdateCount - mLastDemoUpdateCnt, 4);
	mLastDemoUpdateCnt = mUpdateCount;
	mDemoCmdOrder++;
}

int aNumBigMoveMessages = 0;
int aNumSmallMoveMessages = 0;
int aNumTimerMessages = 0;

// Required unused in release mode
bool SexyAppBase::PrepareDemoCommand([[maybe_unused]] bool required)
{
	if (mDemoNeedsCommand)
	{
		mDemoCmdBitPos = mDemoBuffer.mReadBitPos;

		mLastDemoUpdateCnt += mDemoBuffer.ReadNumBits(4, false);

		mDemoIsShortCmd = mDemoBuffer.ReadNumBits(1, false) == 1;

		if (mDemoIsShortCmd)		
			mDemoCmdNum = mDemoBuffer.ReadNumBits(1, false);
		else
			mDemoCmdNum = mDemoBuffer.ReadNumBits(5, false);

		mDemoNeedsCommand = false;

		mDemoCmdOrder++;
	}

	DBG_ASSERTE((mUpdateCount == mLastDemoUpdateCnt) || (!required));

	return mUpdateCount == mLastDemoUpdateCnt;
}

void SexyAppBase::ProcessDemo()
{
	if (mPlayingDemoBuffer)
	{
		// At end of demo buffer?  How dare you!
		DBG_ASSERTE(!mDemoBuffer.AtEnd());

		while ((!mShutdown) && (mUpdateCount == mLastDemoUpdateCnt) && (!mDemoBuffer.AtEnd()))
		{
			if (PrepareDemoCommand(false))
			{
				mDemoNeedsCommand = true;
				
				if (mDemoIsShortCmd)
				{
					switch (mDemoCmdNum)
					{
					case 0:
						{
							int aDeltaX = mDemoBuffer.ReadNumBits(6, true);
							int aDeltaY = mDemoBuffer.ReadNumBits(6, true);
							mLastDemoMouseX += aDeltaX;
							mLastDemoMouseY += aDeltaY;

							mWidgetManager->MouseMove(mLastDemoMouseX, mLastDemoMouseY);
						}
						break;
					case 1:
						{
							bool down = mDemoBuffer.ReadNumBits(1, false) != 0;
							int aBtnCount = mDemoBuffer.ReadNumBits(3, true);							
		
							if (down)
								mWidgetManager->MouseDown(mLastDemoMouseX, mLastDemoMouseY, aBtnCount);
							else
								mWidgetManager->MouseUp(mLastDemoMouseX, mLastDemoMouseY, aBtnCount);
						}
						break;
					}
				}
				else
				{				
					switch (mDemoCmdNum)
					{
					case DEMO_MOUSE_POSITION:
						{
							mLastDemoMouseX = mDemoBuffer.ReadNumBits(12, false);
							mLastDemoMouseY = mDemoBuffer.ReadNumBits(12, false);

							mWidgetManager->MouseMove(mLastDemoMouseX, mLastDemoMouseY);						
						}
						break;
					case DEMO_ACTIVATE_APP:
						{
							mActive = mDemoBuffer.ReadNumBits(1, false) != 0;

							RehupFocus();
							
							if ((mActive) && (!mIsWindowed))
								mWidgetManager->MarkAllDirty();

						}
						break;
					case DEMO_SIZE:
						{
							bool isMinimized = mDemoBuffer.ReadBoolean();

							if ((!mShutdown) && (isMinimized != mMinimized))
							{
								mMinimized = isMinimized;

								// We don't want any sounds (or music) playing while its minimized
								if (mMinimized)
									Mute(true);
								else
								{
									Unmute(true);
									mWidgetManager->MarkAllDirty();
								}
							}

							RehupFocus();
						}
						break;
					case DEMO_MOUSE_WHEEL:
						{
							int aScroll = mDemoBuffer.ReadNumBits(8, true);
							mWidgetManager->MouseWheel(aScroll);
						}
						break;
					case DEMO_KEY_DOWN:
						{
							KeyCode aKeyCode = (KeyCode) mDemoBuffer.ReadNumBits(8, false);
							mWidgetManager->KeyDown(aKeyCode);
						}
						break;
					case DEMO_KEY_UP:
						{
							KeyCode aKeyCode = (KeyCode) mDemoBuffer.ReadNumBits(8, false);
							mWidgetManager->KeyUp(aKeyCode);
						}
						break;
					case DEMO_KEY_CHAR:
						{
							int sizeMult = (int)mDemoBuffer.ReadNumBits(1, false) + 1; // will be 1 for single, 2 for double
							SexyChar aChar = (SexyChar) mDemoBuffer.ReadNumBits(8*sizeMult, false);
							mWidgetManager->KeyChar(aChar);
						}
						break;
					case DEMO_CLOSE:
						Shutdown();
						break;
					case DEMO_MOUSE_ENTER:
						mMouseIn = true;
						EnforceCursor();
						break;
					case DEMO_MOUSE_EXIT:
						mWidgetManager->MouseExit(mLastDemoMouseX, mLastDemoMouseY);
						mMouseIn = false;
						EnforceCursor();
						break;
					case DEMO_LOADING_COMPLETE:
						mDemoLoadingComplete = true;
						break;
					case DEMO_VIDEO_DATA:
						mIsWindowed = mDemoBuffer.ReadBoolean();
						mSyncRefreshRate = mDemoBuffer.ReadByte();
						break;
					case DEMO_IDLE:
						break;
					default:
						DBG_ASSERTE("Invalid Demo Command" == 0);
						break;
					}
				}
			}
		}
	}

	{
		FILE* aLog = fopen(GetLogFilePath("scale.log").c_str(), "w");
		if (aLog != NULL)
		{
			fprintf(aLog, "window simple=%d pipeline=%d\n",
				mScaleConfigWindow, (int)mScaleWindowConfig.mEffects.size());
			for (size_t i = 0; i < mScaleWindowConfig.mEffects.size(); i++)
			{
				fprintf(aLog, "  window[%d] %s params=%d\n",
					(int)i,
					mScaleWindowConfig.mEffects[i].mPath.c_str(),
					(int)mScaleWindowConfig.mEffects[i].mParams.size());
				for (StringStringMap::const_iterator anItr =
						mScaleWindowConfig.mEffects[i].mParams.begin();
					anItr != mScaleWindowConfig.mEffects[i].mParams.end();
					++anItr)
				{
					fprintf(aLog, "    %s=%s\n", anItr->first.c_str(), anItr->second.c_str());
				}
			}

			fprintf(aLog, "fullscreen output=%dx%d pipeline=%d\n",
				mScaleFullscreenConfig.mOutputWidth,
				mScaleFullscreenConfig.mOutputHeight,
				(int)mScaleFullscreenConfig.mEffects.size());
			for (size_t i = 0; i < mScaleFullscreenConfig.mEffects.size(); i++)
			{
				fprintf(aLog, "  fullscreen[%d] %s params=%d\n",
					(int)i,
					mScaleFullscreenConfig.mEffects[i].mPath.c_str(),
					(int)mScaleFullscreenConfig.mEffects[i].mParams.size());
				for (StringStringMap::const_iterator anItr =
						mScaleFullscreenConfig.mEffects[i].mParams.begin();
					anItr != mScaleFullscreenConfig.mEffects[i].mParams.end();
					++anItr)
				{
					fprintf(aLog, "    %s=%s\n", anItr->first.c_str(), anItr->second.c_str());
				}
			}
			fclose(aLog);
		}
	}
}

void SexyAppBase::ShowMemoryUsage()
{
	DWORD aTotal = 0;
	DWORD aFree = 0;

	MemoryImageSet::iterator anItr = mMemoryImageSet.begin();
	typedef std::pair<int,int> FormatUsage;
	typedef std::map<PixelFormat,FormatUsage> FormatMap;
	FormatMap aFormatMap;
	int aTextureMemory = 0;
	while (anItr != mMemoryImageSet.end())
	{
		MemoryImage* aMemoryImage = *anItr;				
		if (aMemoryImage->mD3DData != NULL)
		{
			TextureData *aData = (TextureData*)aMemoryImage->mD3DData;
			aTextureMemory += aData->mTexMemSize;

			FormatUsage &aUsage = aFormatMap[aData->mPixelFormat];
			aUsage.first++;
			aUsage.second += aData->mTexMemSize;
		}

		++anItr;
	}

	std::string aStr;

	const char *aDesc;
	if (Is3DAccelerationRecommended())
		aDesc = "Recommended";
	else if (Is3DAccelerationSupported())
		aDesc = "Supported";
	else
		aDesc = "Unsupported";

	aStr += StrFormat("3D-Mode is %s (3D is %s on this system)\r\n\r\n",Is3DAccelerated()?"On":"Off",aDesc);

	aStr += StrFormat("Num Images: %d\r\n",(int)mMemoryImageSet.size());
	aStr += StrFormat("Num Sounds: %d\r\n",mSoundManager->GetNumSounds());
	aStr += StrFormat("Video Memory: %s/%s KB\r\n", SexyStringToString(CommaSeperate((aTotal-aFree)/1024)).c_str(), SexyStringToString(CommaSeperate(aTotal/1024)).c_str());
	aStr += StrFormat("Texture Memory: %s KB\r\n",CommaSeperate(aTextureMemory/1024).c_str());

	FormatUsage aUsage = aFormatMap[PixelFormat_A8R8G8B8];
	aStr += StrFormat("A8R8G8B8: %d - %s KB\r\n",aUsage.first,SexyStringToString(CommaSeperate(aUsage.second/1024)).c_str());
	aUsage = aFormatMap[PixelFormat_A4R4G4B4];
	aStr += StrFormat("A4R4G4B4: %d - %s KB\r\n",aUsage.first,SexyStringToString(CommaSeperate(aUsage.second/1024)).c_str());
	aUsage = aFormatMap[PixelFormat_R5G6B5];
	aStr += StrFormat("R5G6B5: %d - %s KB\r\n",aUsage.first,SexyStringToString(CommaSeperate(aUsage.second/1024)).c_str());
	aUsage = aFormatMap[PixelFormat_Palette8];
	aStr += StrFormat("Palette8: %d - %s KB\r\n",aUsage.first,SexyStringToString(CommaSeperate(aUsage.second/1024)).c_str());
	
	MsgBox(aStr,"Video Stats",MB_OK);
	mLastTime = SexyGetTickCount();
}

bool SexyAppBase::IsAltKeyUsed(WPARAM wParam)
{
	int aChar = tolower(wParam);
	switch (aChar)
	{
		case 13: // alt-enter
		case 'r': 
			return true;		
		default: 
			return false;
	}
}

bool SexyAppBase::DebugKeyDown(int theKey)
{
	if ((theKey == 'R') && (mWidgetManager->mKeyDown[KEYCODE_MENU]))
	{	
#ifndef RELEASEFINAL
		if (ReparseModValues())
			PlaySoundA("c:\\windows\\media\\Windows XP Menu Command.wav", NULL, SND_ASYNC);				
		else
		{
			for (int aKeyNum = 0; aKeyNum < 0xFF; aKeyNum++) // prevent alt from getting stuck
				mWidgetManager->mKeyDown[aKeyNum] = false;
		}
#endif
	}
	else if (theKey == VK_F3)
	{
		if(mWidgetManager->mKeyDown[KEYCODE_SHIFT])
		{
			mShowFPS = true;
			if (++mShowFPSMode >= Num_FPS_Types)
				mShowFPSMode = 0;
		}
		else
			mShowFPS = !mShowFPS;

		mWidgetManager->MarkAllDirty();

		if (mShowFPS)
		{
			gFPSTimer.Start();
			gFrameCount = 0;
			gFPSDisplay = 0;
			gForceDisplay = true;
		}
	}
	else if (theKey == VK_F8)
	{
		if(mWidgetManager->mKeyDown[KEYCODE_SHIFT])
		{
			Set3DAcclerated(!Is3DAccelerated());

			char aBuf[512];
			sprintf(aBuf,"3D-Mode: %s",Is3DAccelerated()?"ON":"OFF");
			MsgBox(aBuf,"Mode Switch",MB_OK);
			mLastTime = SexyGetTickCount();
		}
		else
			ShowMemoryUsage();

		return true;
	}
	else if (theKey == VK_F10)
	{
#ifndef RELEASEFINAL
		if (mWidgetManager->mKeyDown[KEYCODE_CONTROL])
		{
			if (mUpdateMultiplier==0.25)
				mUpdateMultiplier = 1.0;
			else
				mUpdateMultiplier = 0.25;
		}
		else if(mWidgetManager->mKeyDown[KEYCODE_SHIFT])
		{
			mStepMode = 0;
			ClearUpdateBacklog();
		}
		else
			mStepMode = 1;
#endif

		return true;
	}
	else if (theKey == VK_F11)
	{
		if (mWidgetManager->mKeyDown[KEYCODE_SHIFT])
			DumpProgramInfo();
		else
			TakeScreenshot();

		return true;
	}
	else if (theKey == VK_F2)
	{
		bool isPerfOn = !SexyPerf::IsPerfOn();
		if (isPerfOn)
		{
//			MsgBox("Perf Monitoring: ON", "Perf Monitoring", MB_OK);
			ClearUpdateBacklog();
			SexyPerf::BeginPerf();
		}
		else
		{
			SexyPerf::EndPerf();
			MsgBox(SexyPerf::GetResults().c_str(), "Perf Results", MB_OK);
			ClearUpdateBacklog();
		}
	}
	else
		return false;

	return false;
}

/*
bool SexyAppBase::DebugKeyDownAsync(int theKey, bool ctrlDown, bool altDown)
{
	return false;
}
*/

void SexyAppBase::CloseRequestAsync()
{
}

void SexyAppBase::ProcessTimerMessage(HWND hWnd)
{
	if ((!gInAssert) && (!mSEHOccured) && (mRunning))
	{	
		DWORD aTimeNow = SexyGetTickCount();
		if (aTimeNow - mLastTimerTime > 500)
			mLastBigDelayTime = aTimeNow;

		mLastTimerTime = aTimeNow;

		POINT aULCorner = {0, 0};
		::ClientToScreen(hWnd, &aULCorner);

		POINT aBRCorner = {mDDInterface->mDisplayWidth, mDDInterface->mDisplayHeight};
		::ClientToScreen(hWnd, &aBRCorner);

		POINT aPoint;
		::GetCursorPos(&aPoint);			
		
		HWND aWindow = ::WindowFromPoint(aPoint);
		bool isMouseIn = (aWindow == hWnd) && 
			(aPoint.x >= aULCorner.x) && (aPoint.y >= aULCorner.y) &&
			(aPoint.x < aBRCorner.x) && (aPoint.y < aBRCorner.y);

		if (mMouseIn != isMouseIn)
		{
			if ((mRecordingDemoBuffer) && (!mShutdown))
			{
				WriteDemoTimingBlock();
				mDemoBuffer.WriteNumBits(0, 1);

				if (isMouseIn)
					mDemoBuffer.WriteNumBits(DEMO_MOUSE_ENTER, 5);
				else
					mDemoBuffer.WriteNumBits(DEMO_MOUSE_EXIT, 5);
			}

			if (!isMouseIn)
			{
				int x = aPoint.x - aULCorner.x;
				int y = aPoint.y - aULCorner.y;
				mWidgetManager->RemapMouse(x, y);
				mWidgetManager->MouseExit(x, y);
			}

			mMouseIn = isMouseIn;
			EnforceCursor();
		}			
	}
}

// GLFW-style event dispatch. GLFW's win32 windowProc does not hand input to
// the application inside DispatchMessage; it only queues the event, and
// glfwPollEvents invokes the callbacks after the whole native queue has been
// pumped. ProcessMessageNow is the legacy equivalent of that callback pass:
// it runs outside the WndProc (no reentrancy into the framework from inside a
// window message) and is called by UpdateAppStep right after the pump, with
// every message from the burst delivered in the same frame.
void SexyAppBase::ProcessMessageNow(UINT uMsg, WPARAM wParam, LPARAM lParam, HWND hWnd)
{
	// WM_CLOSE must always shut the app down, even while a demo buffer is
	// playing (the original deferred path handled it outside the demo guard).
	if (uMsg == WM_CLOSE)
	{
		if ((hWnd == mHWnd) || (hWnd == mInvisHWnd))
		{
			// This should short-circuit all demo calls, otherwise we will get
			//  all sorts of weird asserts because we are changing
			//  program flow
			mManualShutdown = true;

			Shutdown();
		}
		return;
	}

	if (mPlayingDemoBuffer)
		return;

	switch (uMsg)
	{
//  TODO: switch to killfocus/setfocus?
//	case WM_KILLFOCUS:
//	case WM_SETFOCUS:
	case WM_ACTIVATEAPP:
		if ((hWnd == mHWnd) && (!gInAssert) && (!mSEHOccured) && (!mShutdown))
		{
			RehupFocus();

			if ((mActive) && (!mIsWindowed))
				mWidgetManager->MarkAllDirty();

		}
		break;
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDBLCLK:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
	case WM_MBUTTONUP:
	case WM_MOUSEMOVE:
		if ((!gInAssert) && (!mSEHOccured))
		{
			int x = (short) LOWORD(lParam);
			int y = (short) HIWORD(lParam);
			mWidgetManager->RemapMouse(x, y);

			mLastUserInputTick = SexyGetTickCount();

			DWORD aBeforeMouseMove = GetTickCount();
			mWidgetManager->MouseMove(x, y);
			DWORD aMouseMoveElapsed = GetTickCount() - aBeforeMouseMove;
			if (aMouseMoveElapsed > 50)
			{
				FILE* aLog = fopen(GetLogFilePath("mousemove.log").c_str(), "a");
				if (aLog != NULL)
				{
					fprintf(aLog, "mousemove=%d x=%d y=%d msg=%u\n",
						(int)aMouseMoveElapsed, x, y, uMsg);
					fclose(aLog);
				}
			}

			if (!mMouseIn)
			{
				if (mRecordingDemoBuffer)
				{
					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_MOUSE_ENTER, 5);
				}

				mMouseIn = true;
				EnforceCursor();
			}

			switch (uMsg)
			{
			case WM_LBUTTONDOWN:
				SetCapture(hWnd);
				mWidgetManager->MouseDown(x, y, 1);
				break;
			case WM_RBUTTONDOWN:
				SetCapture(hWnd);
				mWidgetManager->MouseDown(x, y, -1);
				break;
			case WM_MBUTTONDOWN:
				SetCapture(hWnd);
				mWidgetManager->MouseDown(x, y, 3);
				break;
			case WM_LBUTTONDBLCLK:
				SetCapture(hWnd);
				mWidgetManager->MouseDown(x, y, 2);
				break;
			case WM_RBUTTONDBLCLK:
				SetCapture(hWnd);
				mWidgetManager->MouseDown(x, y, -2);
				break;
			case WM_LBUTTONUP:
				if ((mWidgetManager->mDownButtons & ~1) == 0)
					ReleaseCapture();
				mWidgetManager->MouseUp(x, y, 1);
				break;
			case WM_RBUTTONUP:
				if ((mWidgetManager->mDownButtons & ~2) == 0)
					ReleaseCapture();
				mWidgetManager->MouseUp(x, y, -1);
				break;
			case WM_MBUTTONUP:
				if ((mWidgetManager->mDownButtons & ~4) == 0)
					ReleaseCapture();
				mWidgetManager->MouseUp(x, y, 3);
				break;
			}
		}
		break;
	case WM_MOUSEWHEEL:
		{
			char aZDelta = ((short)HIWORD(wParam)) / 120;
			mWidgetManager->MouseWheel(aZDelta);
		}
		break;
	case WM_KEYDOWN:
	case WM_SYSKEYDOWN:
		mLastUserInputTick = SexyGetTickCount();

		if (wParam==VK_RETURN && uMsg==WM_SYSKEYDOWN && !mForceFullscreen && !mForceWindowed && mAllowAltEnter)
		{
			SwitchScreenMode(!mIsWindowed);
			ClearKeysDown();
			break;
		}
		else if ((wParam == 'D') && (mWidgetManager != NULL) && (mWidgetManager->mKeyDown[KEYCODE_CONTROL]) && (mWidgetManager->mKeyDown[KEYCODE_MENU]))
		{
			PlaySoundA("c:\\windows\\media\\Windows XP Menu Command.wav", NULL, SND_ASYNC);
			mDebugKeysEnabled = !mDebugKeysEnabled;
		}

		if (mDebugKeysEnabled)
		{
			if (DebugKeyDown(wParam))
				break;
		}

		mWidgetManager->KeyDown((KeyCode) wParam);
		break;

	case WM_KEYUP:
	case WM_SYSKEYUP:
		mLastUserInputTick = SexyGetTickCount();
		mWidgetManager->KeyUp((KeyCode) wParam);
		break;
	case WM_CHAR:
		mLastUserInputTick = SexyGetTickCount();
		mWidgetManager->KeyChar((SexyChar) wParam);
		break;
	case WM_MOVE:
		{
			if ((hWnd == mHWnd) && (mIsWindowed))
			{
				WINDOWPLACEMENT aWindowPlacment;
				aWindowPlacment.length = sizeof(aWindowPlacment);

				GetWindowPlacement(hWnd, &aWindowPlacment);
				if ((aWindowPlacment.showCmd == SW_SHOW) ||
					(aWindowPlacment.showCmd == SW_SHOWNORMAL))
				{
					mPreferredX = aWindowPlacment.rcNormalPosition.left;
					mPreferredY = aWindowPlacment.rcNormalPosition.top;
				}
			}
		}
		break;
	case WM_SIZE:
		{
			bool isMinimized = wParam == SIZE_MINIMIZED;

			if ((hWnd == mHWnd) && (!mShutdown) && (isMinimized != mMinimized))
			{
				mMinimized = isMinimized;

				// We don't want any sounds (or music) playing while its minimized
				if (mMinimized)
				{
					if (mMuteOnLostFocus)
						Mute(true);
				}
				else
				{
					if (mMuteOnLostFocus)
						Unmute(true);

					mWidgetManager->MarkAllDirty();
				}
			}

			RehupFocus();
			if (wParam==SIZE_MAXIMIZED)
				SwitchScreenMode(false);
		}
		break;
	case WM_TIMER:
		ProcessTimerMessage(hWnd);
		break;

	case WM_SYSCOLORCHANGE:
	case WM_DISPLAYCHANGE:
		mWidgetManager->SysColorChangedAll();
		mWidgetManager->MarkAllDirty();
		break;
	}

}

// Why did I defer messages?  Oh, incase a dialog comes up such as a crash
//  it won't keep crashing and stuff
bool SexyAppBase::ProcessDeferredMessages(bool singleMessage)
{
	while (mDeferredMessages.size() > 0)
	{
		MSG aMsg = mDeferredMessages.front();
		mDeferredMessages.pop_front();

		// Consecutive motion messages are safe to coalesce, but button
		// transitions are not: dropping WM_LBUTTONDOWN or WM_LBUTTONUP makes a
		// real click disappear (the next click then appears to fix it).  The
		// old code coalesced every mouse message and caused exactly that race.
		if (aMsg.message == WM_MOUSEMOVE)
		{
			while (!mDeferredMessages.empty())
			{
				MSG aNext = mDeferredMessages.front();
				if (aNext.message != WM_MOUSEMOVE)
					break;
				aMsg = aNext;
				mDeferredMessages.pop_front();
			}
		}

		DWORD aMsgStart = SexyGetTickCount();

		UINT uMsg = aMsg.message;
		LPARAM lParam = aMsg.lParam;
		WPARAM wParam = aMsg.wParam;
		HWND hWnd = aMsg.hwnd;

		if ((mRecordingDemoBuffer) && (!mShutdown))
		{
			switch (uMsg)
			{
//  TODO: switch to killfocus/setfocus?
//			case WM_SETFOCUS:
//			case WM_KILLFOCUS:
//				if (hWnd == mHWnd)
//				{					
//					WriteDemoTimingBlock();
//					mDemoBuffer.WriteNumBits(0, 1);
//					mDemoBuffer.WriteNumBits(DEMO_ACTIVATE_APP, 5);
//					mDemoBuffer.WriteNumBits(uMsg==WM_SETFOCUS ? 1 : 0, 1);
//				}
//				break;			
	
			case WM_ACTIVATEAPP:
				if (hWnd == mHWnd)
				{					
					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_ACTIVATE_APP, 5);
					mDemoBuffer.WriteNumBits((wParam != 0) ? 1 : 0, 1);
				}
				break;			

			case WM_SIZE:
				{
					bool isMinimized = wParam == SIZE_MINIMIZED;

					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_SIZE, 5);
					mDemoBuffer.WriteBoolean(isMinimized);		
				}
				break;
			case WM_LBUTTONDOWN:
			case WM_RBUTTONDOWN:
			case WM_MBUTTONDOWN:
			case WM_LBUTTONDBLCLK:
			case WM_RBUTTONDBLCLK:
			case WM_LBUTTONUP:
			case WM_RBUTTONUP:
			case WM_MBUTTONUP:
			case WM_MOUSEMOVE:
				{
					int aCurX = (short) LOWORD(lParam);
					int aCurY = (short) HIWORD(lParam);

					int aDiffX = aCurX - mLastDemoMouseX;
					int aDiffY = aCurY - mLastDemoMouseY;

					if ((abs(aCurX - mLastDemoMouseX) < 32) && (abs(aCurY - mLastDemoMouseY) < 32))
					{
						if ((aDiffX != 0) || (aDiffY != 0))
						{
							WriteDemoTimingBlock();
							mDemoBuffer.WriteNumBits(1, 1);
							mDemoBuffer.WriteNumBits(0, 1);
							mDemoBuffer.WriteNumBits(aDiffX, 6);
							mDemoBuffer.WriteNumBits(aDiffY, 6);
						}						
					}
					else
					{
						WriteDemoTimingBlock();
						mDemoBuffer.WriteNumBits(0, 1);
						mDemoBuffer.WriteNumBits(DEMO_MOUSE_POSITION, 5);
						mDemoBuffer.WriteNumBits(aCurX, 12);
						mDemoBuffer.WriteNumBits(aCurY, 12);
					}

					bool down = true;
					int aBtnNum = 0;
					switch (uMsg)
					{
						case WM_LBUTTONDOWN:
							aBtnNum = 1;
							break;
						case WM_RBUTTONDOWN:
							aBtnNum = -1;
							break;
						case WM_MBUTTONDOWN:
							aBtnNum = 3;
							break;
						case WM_LBUTTONDBLCLK:
							aBtnNum = 2;
							break;
						case WM_RBUTTONDBLCLK:
							aBtnNum = -2;
							break;
						case WM_LBUTTONUP:
							aBtnNum = 1;
							down = false;
							break;
						case WM_RBUTTONUP:
							aBtnNum = -1;
							down = false;
							break;
						case WM_MBUTTONUP:
							aBtnNum = 3;
							down = false;
							break;
					}

					if (aBtnNum != 0)
					{
						WriteDemoTimingBlock();
						mDemoBuffer.WriteNumBits(1, 1);
						mDemoBuffer.WriteNumBits(1, 1);
						mDemoBuffer.WriteNumBits(down ? 1 : 0, 1);
						mDemoBuffer.WriteNumBits(aBtnNum, 3);
					}

					mLastDemoMouseX = aCurX;
					mLastDemoMouseY = aCurY;
				}
				break;
			case WM_MOUSEWHEEL:
				{
					int aZDelta = ((short)HIWORD(wParam)) / 120;

					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_MOUSE_WHEEL, 5);
					mDemoBuffer.WriteNumBits(aZDelta, 8);
				}
				break;
			case WM_KEYDOWN:
			case WM_SYSKEYDOWN:
				{
					KeyCode aKeyCode = (KeyCode) wParam;

					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_KEY_DOWN, 5);
					mDemoBuffer.WriteNumBits(aKeyCode, 8);
				}
				break;
			case WM_KEYUP:	
			case WM_SYSKEYUP:
				{
					KeyCode aKeyCode = (KeyCode) wParam;

					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_KEY_UP, 5);
					mDemoBuffer.WriteNumBits((int) aKeyCode, 8);
				}
				break;
			case WM_CHAR:
				{
					SexyChar aChar = (SexyChar) wParam;

					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_KEY_CHAR, 5);
					mDemoBuffer.WriteNumBits(sizeof(SexyChar) == 2, 1);
					mDemoBuffer.WriteNumBits(aChar, sizeof(SexyChar)*8);
				}				
				break;	
			case WM_CLOSE:
				if ((hWnd == mHWnd) || (hWnd == mInvisHWnd))
				{
					WriteDemoTimingBlock();
					mDemoBuffer.WriteNumBits(0, 1);
					mDemoBuffer.WriteNumBits(DEMO_CLOSE, 5);
				}
				break;
			}

			// int aBufferSize = mDemoBuffer.GetDataLen(); // Why?
		}

		if (!mPlayingDemoBuffer || uMsg == WM_CLOSE)
			ProcessMessageNow(uMsg, wParam, lParam, hWnd);

		DWORD aMsgElapsed = SexyGetTickCount() - aMsgStart;
		if (aMsgElapsed > 50)
		{
			FILE* aLog = fopen(GetLogFilePath("mainloop-msg.log").c_str(), "a");
			if (aLog != NULL)
			{
				fprintf(aLog, "msg=%u wparam=%d lparam=%d took=%d update=%d\n",
					uMsg, (int)wParam, (int)lParam, (int)aMsgElapsed, mUpdateCount);
				fclose(aLog);
			}
		}

		if (singleMessage)
			break;
	}

	return (mDeferredMessages.size() > 0);
}

void SexyAppBase::Done3dTesting()
{
}

void SexyAppBase::MakeWindow()
{
	//OutputDebugString("MAKING WINDOW\r\n");

	if (mHWnd != NULL)
	{
		SetWindowLongPtr(mHWnd, GWLP_USERDATA, 0);
		HWND anOldWindow = mHWnd;
		mHWnd = NULL;		
		DestroyWindow(anOldWindow);	
		mWidgetManager->mImage = NULL;
	}


	if (mUseExternalHWND && mExternalHWND != NULL)
	{
		mHWnd = mExternalHWND;
		mIsPhysWindowed = true;
		SetWindowLongPtr(mHWnd, GWLP_USERDATA, (intptr_t)this);
	}
	else if ((mPlayingDemoBuffer) || (mIsWindowed && !mFullScreenWindow))
	{
		DWORD aWindowStyle = WS_CLIPCHILDREN | WS_POPUP | WS_BORDER | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
		if (mEnableMaximizeButton)
			aWindowStyle |= WS_MAXIMIZEBOX;

		RECT aRect;
		aRect.left = 0;
		aRect.top = 0;
		aRect.right = mWidth;
		aRect.bottom = mHeight;
		
		BOOL worked = AdjustWindowRect(&aRect, aWindowStyle, FALSE);
		(void)worked; // Unused. Naughty not checking if it worked

		int aWidth = aRect.right - aRect.left;
		int aHeight = aRect.bottom - aRect.top;

		// Get the work area of the desktop to allow us to center
		RECT aDesktopRect;
		::SystemParametersInfo(SPI_GETWORKAREA, 0, &aDesktopRect, 0);

		int aPlaceX = 64;
		int aPlaceY = 64;
		
		if (mPreferredX != -1)
		{
			aPlaceX = mPreferredX;
			aPlaceY = mPreferredY;

			int aSpacing = 4;

			if (aPlaceX < aDesktopRect.left + aSpacing)
				aPlaceX = aDesktopRect.left + aSpacing;

			if (aPlaceY < aDesktopRect.top + aSpacing)
				aPlaceY = aDesktopRect.top + aSpacing;

			if (aPlaceX + aWidth >= aDesktopRect.right - aSpacing)
				aPlaceX = aDesktopRect.right - aWidth - aSpacing;
			
			if (aPlaceY + aHeight >= aDesktopRect.bottom - aSpacing)
				aPlaceY = aDesktopRect.bottom - aHeight - aSpacing;
		}

		// @Patoke: removed unnecessary if checks for win98
		mHWnd = CreateWindowEx(
			0,
			_S("MainWindow"),
			SexyStringToStringFast(mTitle).c_str(),
			aWindowStyle,
			aPlaceX,
			aPlaceY,
			aWidth,
			aHeight,
			NULL,
			NULL,
			gHInstance,
			0);

		if (mPreferredX == -1)
		{
			::MoveWindow(mHWnd,
				aDesktopRect.left + ((aDesktopRect.right - aDesktopRect.left) - aWidth) / 2,
				aDesktopRect.top + (int)(((aDesktopRect.bottom - aDesktopRect.top) - aHeight) * 0.382),
				aWidth, aHeight, FALSE);
		}

		mIsPhysWindowed = true;
	}
	else
	{

		int aFullWidth = GetSystemMetrics(SM_CXSCREEN);
		int aFullHeight = GetSystemMetrics(SM_CYSCREEN);
		mHWnd = CreateWindowEx(
			0,
			_S("MainWindow"),
			SexyStringToStringFast(mTitle).c_str(),
			WS_POPUP,
			0,
			0,
			aFullWidth,
			aFullHeight,
			NULL,
			NULL,
			gHInstance,
			0);

		mIsPhysWindowed = true;
	}

	/*char aStr[256];
	sprintf(aStr, "HWND: %d\r\n", mHWnd);
	OutputDebugString(aStr);*/

	SetWindowLongPtr(mHWnd, GWLP_USERDATA, (intptr_t) this);	

	if (mDDInterface == NULL)
	{
		mDDInterface = new DDInterface(this);

		// GPU (D3D11) acceleration is mandatory and always on. The persisted
		// Is3D preference is no longer honored; we always run accelerated.
		mDDInterface->mIs3D = true;
		if (mAutoEnable3D)
		{
			mAutoEnable3D = false;
			mTest3D = true;
		}

	}

	int aResult = InitDDInterface();

	if (mDDInterface->mD3DTester!=NULL && mDDInterface->mD3DTester->ResultsChanged())
		RegistryEraseValue(_S("Is3D"));

	if ((mIsWindowed) && (aResult == DDInterface::RESULT_INVALID_COLORDEPTH))
	{
		if (mForceWindowed)
		{
			Popup(GetString("PLEASE_SET_COLOR_DEPTH", _S("Please set your desktop color depth to 16 bit.")));
			DoExit(1);
		}
		else
		{
			mForceFullscreen = true;
			SwitchScreenMode(false);
		}
		return;
	}
	else if ((!mIsWindowed) && 
		((aResult == DDInterface::RESULT_EXCLUSIVE_FAIL) ||
		 (aResult == DDInterface::RESULT_DISPCHANGE_FAIL)))
	{
		mForceWindowed = true;
		SwitchScreenMode(true);
	}
	else if (aResult == DDInterface::RESULT_3D_FAIL)
	{
		// D3D11 is mandatory in this build. If it cannot initialize, tell
		// the user clearly and exit rather than silently falling back.
		Popup(GetString("D3D11_REQUIRED",
			_S("This 64-bit build requires Direct3D 11 hardware acceleration, which\n"
			   "could not be enabled on this system. Please use the 32-bit original.")));
		DoExit(1);
		return;
	}
	else if (aResult != DDInterface::RESULT_OK)
	{
		if (Is3DAccelerated())
		{
			Popup(GetString("D3D11_REQUIRED",
				_S("This 64-bit build requires Direct3D 11 hardware acceleration, which\n"
				   "could not be initialized. Please use the 32-bit original.")));
			DoExit(1);
			return;
		}
		else
		{
			Popup(GetString("FAILED_INIT_DIRECTDRAW", _S("Failed to initialize DirectDraw: ")) + StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
			DoExit(1);
		}
	}

	// Parity tests need to distinguish the persisted preference from the device
	// that this process actually created. D3DTester may erase a stale Is3D value
	// after the device has already been initialized, so expose the runtime state
	// only when the existing diagnostic environment flag is present.
	const char* aD3DDiagnostics = std::getenv("PVZ_D3D_TEST_DIAGNOSTICS");
	if (aD3DDiagnostics != NULL && aD3DDiagnostics[0] != '\0')
	{
		RegistryWriteBoolean(
			"Test3D\\Active",
			mDDInterface->mIs3D && mDDInterface->mD3DInterface != NULL);
	}

	bool isActive = mActive;
	mActive = GetActiveWindow() == mHWnd;

	mPhysMinimized = false;
	if (mMinimized)
	{
		if (mMuteOnLostFocus)
			Unmute(true);

		mMinimized = false;
		isActive = mActive; // set this here so we don't call RehupFocus again.
		RehupFocus();
	}
	
	if (isActive != mActive)
		RehupFocus();

	ReInitImages();

	mWidgetManager->mImage = mDDInterface->GetScreenImage();
	mWidgetManager->MarkAllDirty();

	// No 100Hz SetTimer stream: the loop is paced by Process() sleeps and
	// UpdateAppStep performs the timer bookkeeping once per frame, matching
	// the GLFW poll loop (glfwPollEvents + UpdateApp). This keeps the native
	// queue empty instead of feeding it a WM_TIMER every mFrameTime ms.
}

void SexyAppBase::DeleteNativeImageData()
{
	MemoryImageSet::iterator anItr = mMemoryImageSet.begin();
	while (anItr != mMemoryImageSet.end())
	{
		MemoryImage* aMemoryImage = *anItr;		
		aMemoryImage->DeleteNativeData();			
		++anItr;
	}
}

void SexyAppBase::DeleteExtraImageData()
{
	AutoCrit anAutoCrit(mDDInterface->mCritSect);
	MemoryImageSet::iterator anItr = mMemoryImageSet.begin();
	while (anItr != mMemoryImageSet.end())
	{
		MemoryImage* aMemoryImage = *anItr;
		aMemoryImage->DeleteExtraBuffers();
		++anItr;
	}
}

void SexyAppBase::ReInitImages()
{
	MemoryImageSet::iterator anItr = mMemoryImageSet.begin();
	while (anItr != mMemoryImageSet.end())
	{
		MemoryImage* aMemoryImage = *anItr;				
		aMemoryImage->ReInit();
		++anItr;
	}
}


void SexyAppBase::LoadingThreadProc()
{
}

void SexyAppBase::LoadingThreadCompleted()
{
}

void SexyAppBase::LoadingThreadProcStub(void *theArg)
{
	SexyAppBase* aSexyApp = (SexyAppBase*) theArg;
	
	aSexyApp->LoadingThreadProc();		

	char aStr[256];
	sprintf(aStr, "Resource Loading Time: %ld\r\n", (GetTickCount() - aSexyApp->mTimeLoaded));
	OutputDebugStringA(aStr);

	aSexyApp->mLoadingThreadCompleted = true;
}

void SexyAppBase::StartLoadingThread()
{	
	if (!mLoadingThreadStarted)
	{
		mYieldMainThread = true; 
		::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);		
		mLoadingThreadStarted = true;
		_beginthread(LoadingThreadProcStub, 0, this);
	}
}
void SexyAppBase::CursorThreadProc()
{
	::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);

	POINT aLastCursorPos = {0, 0};
	int aLastDrawCount = 0;

	while (!mShutdown)
	{
//		if (mProcessInTimer)
//			PostMessage(mHWnd,WM_TIMER,101,0);

		POINT aCursorPos;

		if (mPlayingDemoBuffer)
		{
			aCursorPos.x = mLastDemoMouseX;
			aCursorPos.y = mLastDemoMouseY;
		}
		else
		{
			::GetCursorPos(&aCursorPos);
			::ScreenToClient(mHWnd, &aCursorPos);
		}

		if (aLastDrawCount != mDrawCount)
		{
			// We did a draw so we may have committed a pending mNextCursorX/Y 
			aLastCursorPos.x = mDDInterface->mCursorX;
			aLastCursorPos.y = mDDInterface->mCursorY;
		}

		if ((aCursorPos.x != aLastCursorPos.x) ||
			(aCursorPos.y != aLastCursorPos.y))
		{	
			DWORD aTimeNow = SexyGetTickCount();
			if (aTimeNow - mNextDrawTick > mDDInterface->mMillisecondsPerFrame + 5)
			{
				// Do the special drawing if we are rendering at less than full framerate				
				mDDInterface->SetCursorPos(aCursorPos.x, aCursorPos.y);
				aLastCursorPos = aCursorPos;
			}
			else
			{
				// Set them up to get assigned in the next screen redraw
				mDDInterface->mNextCursorX = aCursorPos.x;
				mDDInterface->mNextCursorY = aCursorPos.y;
			}			
		}		

		Sleep(10);
	}
	
	mCursorThreadRunning = false;
}

void SexyAppBase::CursorThreadProcStub(void *theArg)
{
	CoInitialize(NULL);
	SexyAppBase* aSexyApp = (SexyAppBase*) theArg;
	aSexyApp->CursorThreadProc();
}

void SexyAppBase::StartCursorThread()
{
	if (!mCursorThreadRunning)
	{
		mCursorThreadRunning = true;
		::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
		_beginthread(CursorThreadProcStub, 0, this);
	}
}

void SexyAppBase::StallWatchdogProcStub(void *theArg)
{
	SexyAppBase* aSexyApp = (SexyAppBase*) theArg;
	aSexyApp->StallWatchdogProc();
}

void SexyAppBase::StallWatchdogProc()
{
	::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_HIGHEST);

	DWORD aLastCaptureTick = 0;
	DWORD aLastAliveLogTick = 0;
	const bool aVerboseHeartbeat = getenv("PVZ_WATCHDOG_VERBOSE") != nullptr;
	while (!mWatchdogStop)
	{
		::Sleep(20);
		if (mWatchdogStop)
			break;

		DWORD aNow = SexyGetTickCount();
		DWORD aLast = mWatchdogLastTick;

		// Self-diagnostic heartbeat: if these lines stop appearing while the
		// game is still running, the whole process (including this thread) is
		// being suspended — which is itself the stutter.
		if (aVerboseHeartbeat && (DWORD)(aNow - aLastAliveLogTick) > 500)
		{
			aLastAliveLogTick = aNow;
			FILE* aLog = fopen(GetLogFilePath("watchdog.log").c_str(), "a");
			if (aLog != NULL)
			{
				fprintf(aLog, "alive tick=%lu update=%d last=%lu\n",
					(unsigned long)aNow, (int)mUpdateCount, (unsigned long)aLast);
				fclose(aLog);
			}
		}

		if ((aLast != 0) && ((DWORD)(aNow - aLast) > 150) &&
			((DWORD)(aNow - aLastCaptureTick) > 1000))
		{
			aLastCaptureTick = aNow;
			CaptureMainThreadStack();
		}
	}
}

void SexyAppBase::CaptureMainThreadStack()
{
	static bool aSymbolsInitialized = false;
	if (!aSymbolsInitialized)
	{
		aSymbolsInitialized = SymInitialize(GetCurrentProcess(), NULL, TRUE) != FALSE;
	}

	HANDLE aThread = ::OpenThread(
		THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION,
		FALSE,
		mPrimaryThreadId);
	if (aThread == NULL)
	{
		FILE* aLog = fopen(GetLogFilePathC("stall-stack.log"), "a");
		if (aLog != NULL)
		{
			fprintf(aLog, "=== capture failed: OpenThread error=%lu ===\n",
				(unsigned long)::GetLastError());
			fclose(aLog);
		}
		return;
	}

	CONTEXT aContext;
	ZeroMemory(&aContext, sizeof(aContext));
	aContext.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;

	DWORD aSuspendCount = ::SuspendThread(aThread);
	BOOL aGotContext = (aSuspendCount != (DWORD)-1) && ::GetThreadContext(aThread, &aContext);

	DWORD64 aAddresses[96] = {};
	int aCount = 0;
	if (aGotContext)
	{
		STACKFRAME64 aFrame;
		ZeroMemory(&aFrame, sizeof(aFrame));
		aFrame.AddrPC.Offset = aContext.Rip;
		aFrame.AddrPC.Mode = AddrModeFlat;
		aFrame.AddrFrame.Offset = aContext.Rbp;
		aFrame.AddrFrame.Mode = AddrModeFlat;
		aFrame.AddrStack.Offset = aContext.Rsp;
		aFrame.AddrStack.Mode = AddrModeFlat;

		__try
		{
			for (int i = 0; i < 96; i++)
			{
				if (!StackWalk64(
						IMAGE_FILE_MACHINE_AMD64,
						GetCurrentProcess(),
						aThread,
						&aFrame,
						&aContext,
						NULL,
						SymFunctionTableAccess64,
						SymGetModuleBase64,
						NULL))
					break;
				if (aFrame.AddrPC.Offset == 0)
					break;
				aAddresses[aCount++] = aFrame.AddrPC.Offset;
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER)
		{
			aCount = -1; // StackWalk64 faulted; keep the watchdog alive.
		}
	}

	::ResumeThread(aThread);
	::CloseHandle(aThread);

	if (aCount == -1)
	{
		FILE* aLog = fopen(GetLogFilePathC("stall-stack.log"), "a");
		if (aLog != NULL)
		{
			fprintf(aLog, "=== capture aborted: StackWalk64 fault, tick=%lu ===\n",
				(unsigned long)SexyGetTickCount());
			fclose(aLog);
		}
		return;
	}

	if (aCount == 0)
		return;

	FILE* aLog = fopen(GetLogFilePathC("stall-stack.log"), "a");
	if (aLog == NULL)
		return;

	fprintf(
		aLog,
		"=== stall at tick=%lu update=%d ===\n",
		(unsigned long)SexyGetTickCount(),
		(int)mUpdateCount);

	for (int i = 0; i < aCount; i++)
	{
		DWORD64 aBase = SymGetModuleBase64(GetCurrentProcess(), aAddresses[i]);
		char aModule[MAX_PATH] = "?";
		if (aBase != 0)
			GetModuleFileNameA((HMODULE)aBase, aModule, MAX_PATH);

		char aSymbol[512] = "?";
		{
			char aBuffer[sizeof(SYMBOL_INFO) + 512] = {};
			SYMBOL_INFO* aSymbolInfo = (SYMBOL_INFO*)aBuffer;
			aSymbolInfo->SizeOfStruct = sizeof(SYMBOL_INFO);
			aSymbolInfo->MaxNameLen = 511;
			DWORD64 aDisplacement = 0;
			if (SymFromAddr(GetCurrentProcess(), aAddresses[i], &aDisplacement, aSymbolInfo))
				snprintf(
					aSymbol,
					sizeof(aSymbol),
					"%s+0x%llx",
					aSymbolInfo->Name,
					(unsigned long long)aDisplacement);
		}

		fprintf(
			aLog,
			"#%02d %s!%s (rva=0x%llx)\n",
			i,
			aModule,
			aSymbol,
			(unsigned long long)(aBase ? (aAddresses[i] - aBase) : aAddresses[i]));
	}

	fclose(aLog);
}

void SexyAppBase::StartStallWatchdog()
{
	if (mWatchdogThread != NULL)
		return;

	// The stall stack capture is always armed: it writes stall-stack.log only
	// when the main loop pauses (>150ms), which is exactly the diagnostic we
	// need for the recurring freeze. Heartbeat logging is opt-in via
	// PVZ_WATCHDOG_VERBOSE so normal play does not churn watchdog.log.

	mWatchdogLastTick = SexyGetTickCount();
	mWatchdogStop = false;
	mWatchdogThread = ::CreateThread(
		NULL,
		0,
		(LPTHREAD_START_ROUTINE)StallWatchdogProcStub,
		this,
		0,
		NULL);
}

void SexyAppBase::StopStallWatchdog()
{
	if (mWatchdogThread == NULL)
		return;

	mWatchdogStop = true;
	::WaitForSingleObject(mWatchdogThread, 2000);
	::CloseHandle(mWatchdogThread);
	mWatchdogThread = NULL;
}

void SexyAppBase::SwitchScreenMode(bool wantWindowed, bool is3d, bool force)
{
	{
		FILE* aLog = fopen(GetLogFilePath("switchmode.log").c_str(), "a");
		if (aLog != NULL)
		{
			fprintf(aLog, "SwitchScreenMode wantWindowed=%d is3d=%d force=%d mIsWindowed=%d\n",
				wantWindowed ? 1 : 0, is3d ? 1 : 0, force ? 1 : 0, mIsWindowed ? 1 : 0);
			fclose(aLog);
		}
	}

	// GLFW shell (mUseExternalHWND) owns its own window and swapchain; the
	// Win32 MakeWindow/InitDDInterface/ReInitImages path would rebuild the
	// framework window on top of the GLFW window (and previously crashed the
	// shell). Fullscreen toggles are accepted but stay windowed there; the
	// options checkbox reverts immediately. Legacy keeps the original
	// fullscreen behavior in the PVZ_WIN32=1 loop.
	if (mUseExternalHWND)
	{
		mIsWindowed = true;
		Set3DAcclerated(is3d);
		return;
	}

	if (mForceFullscreen)
		wantWindowed = false;

	if (mIsWindowed == wantWindowed && !force)
	{
		Set3DAcclerated(is3d);
		return;
	}

	// Set 3d acceleration preference
	Set3DAcclerated(is3d,false);

	// Always make the app windowed when playing demos, in order to
	//  make it easier to track down bugs.  We place this after the
	//  sanity check just so things get re-initialized and stuff
	//if (mPlayingDemoBuffer)
	//	wantWindowed = true;

	// Non-destructive mode switch: resize the existing window and swapchain.
	// Recreating the HWND and D3D11 device here was the source of the black
	// lawn after toggling, the mouse-mapping breakage, and long stalls after
	// repeated toggles (every toggle re-uploaded every image texture).
	// Detach the scale callback before changing the swapchain.  Otherwise a
	// WM_SIZE/Present boundary can observe the old callback while its output
	// texture is being resized.  ClearState also drops all SRV/UAV references
	// held by the previous frame.
	D3D11Renderer* aModeRender = nullptr;
	if (mDDInterface != nullptr && mDDInterface->mD3DInterface != nullptr)
		aModeRender = mDDInterface->mD3DInterface->mD3D11;
	if (aModeRender != nullptr)
	{
		FILE* aLog = fopen(GetLogFilePath("switchmode.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "detach renderer=%p sceneBegun=%d present=%dx%d\n",
				(void*)aModeRender,
				mDDInterface->mD3DInterface->mSceneBegun ? 1 : 0,
				aModeRender->GetPresentWidth(), aModeRender->GetPresentHeight());
			fclose(aLog);
		}
		aModeRender->SetScalePresent(D3D11Renderer::ScalePresentFn());
		if (mDDInterface->mD3DInterface != nullptr)
			mDDInterface->mD3DInterface->Flush();
		aModeRender->PrepareForResize();
	}

	// Select the new pipeline while the old-sized window is still on screen.
	// Materializing a large Anime4K chain after SetWindowPos made DWM expose the
	// resized black backbuffer for the whole compilation/allocation interval.
	// Warm it now, then change the swapchain and HWND only after it is ready.
	mIsWindowed = wantWindowed;
	if (mUseCustomScale && aModeRender != nullptr)
	{
		InstallD3D11ScalePresent();
		const bool aWarmOk = aModeRender->WarmScalePresent();
		FILE* aWarmLog = fopen(GetLogFilePath("scale-warmup.log").c_str(), "a");
		if (aWarmLog != nullptr)
		{
			fprintf(aWarmLog, "mode-switch-before-resize target=%s ok=%d\n",
				wantWindowed ? "window" : "fullscreen", aWarmOk ? 1 : 0);
			fclose(aWarmLog);
		}
		if (!aWarmOk)
		{
			// The warm-up is the first execution of the selected required
			// pipeline. Continuing would merely turn this error into a black
			// first frame, so expose it at the actual failure site.
			RaiseException(0xE000D313, EXCEPTION_NONCONTINUABLE, 0, nullptr);
		}
		aModeRender->SetScalePresent(D3D11Renderer::ScalePresentFn());
		aModeRender->PrepareForResize();
	}

	if (mDDInterface != NULL && Is3DAccelerated())
	{
		int aResult = mDDInterface->ApplyScreenMode(mHWnd, wantWindowed);
		FILE* aLog = fopen(GetLogFilePath("switchmode.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "apply result=%d display=%dx%d\n", aResult,
				mDDInterface->mDisplayWidth, mDDInterface->mDisplayHeight);
			fclose(aLog);
		}
		if (aResult == DDInterface::RESULT_OK)
		{
			// ResizeBuffers is completed before the visible HWND grows. Thus the
			// first fullscreen composition already has a correctly-sized target.
			if (!ResizeAppWindowForMode(wantWindowed))
				RaiseException(0xE000D315, EXCEPTION_NONCONTINUABLE, 0, nullptr);
			mWidgetManager->mImage = mDDInterface->GetScreenImage();
			mWidgetManager->Resize(mScreenBounds, mDDInterface->mVisibleGameRect);
			mWidgetManager->MarkAllDirty();
		}
		else
		{
			Popup(GetString("D3D11_MODE_SWITCH_FAILED",
				_S("Direct3D 11 screen-mode switch failed: ")) +
				StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
			DoExit(1);
			return;
		}
	}
	InstallD3D11ScalePresent();

	::ShowWindow(mHWnd, SW_NORMAL);
	::SetForegroundWindow(mHWnd);

	if (mSoundManager!=NULL)
		mSoundManager->SetCooperativeWindow(mHWnd);

	mLastTime = SexyGetTickCount();
}

// Sizes the existing HWND for the requested screen mode without destroying
// it. Windowed uses the logical size times the custom-scale multiplier;
// fullscreen is a borderless window covering the desktop (matching the
// runtime behavior of the original: no display-mode change on toggle).
bool SexyAppBase::ResizeAppWindowForMode(bool wantWindowed)
{
	if (mHWnd == NULL)
		return false;

	auto LogWin32Failure = [](const char* theOperation, DWORD theError)
	{
		FILE* aLog = fopen(GetLogFilePath("switchmode.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "window operation failed op=%s error=%lu\n",
				theOperation, (unsigned long)theError);
			fclose(aLog);
		}
	};

	// Preserve visibility. GWL_STYLE is replaced wholesale below, and dropping
	// WS_VISIBLE makes the window disappear (clicks then fall through to the
	// desktop while DWM keeps compositing the last frame).
	::SetLastError(ERROR_SUCCESS);
	const DWORD aCurrentStyle = (DWORD)::GetWindowLongPtr(mHWnd, GWL_STYLE);
	if (aCurrentStyle == 0 && ::GetLastError() != ERROR_SUCCESS)
	{
		LogWin32Failure("GetWindowLongPtr(GWL_STYLE)", ::GetLastError());
		return false;
	}
	const bool aWasVisible = (aCurrentStyle & WS_VISIBLE) != 0;

	DWORD aWindowStyle;
	int aWidth;
	int aHeight;
	int aPlaceX;
	int aPlaceY;

	if (wantWindowed)
	{
		aWindowStyle = WS_CLIPCHILDREN | WS_POPUP | WS_BORDER | WS_CAPTION |
			WS_SYSMENU | WS_MINIMIZEBOX;
		if (mEnableMaximizeButton)
			aWindowStyle |= WS_MAXIMIZEBOX;

		int aClientW = mWidth * (mWindowScale > 1 ? mWindowScale : 1);
		int aClientH = mHeight * (mWindowScale > 1 ? mWindowScale : 1);

		RECT aRect;
		aRect.left = 0;
		aRect.top = 0;
		aRect.right = aClientW;
		aRect.bottom = aClientH;
		if (!AdjustWindowRect(&aRect, aWindowStyle, FALSE))
		{
			LogWin32Failure("AdjustWindowRect", ::GetLastError());
			return false;
		}
		aWidth = aRect.right - aRect.left;
		aHeight = aRect.bottom - aRect.top;

		RECT aDesktopRect;
		if (!::SystemParametersInfo(SPI_GETWORKAREA, 0, &aDesktopRect, 0))
		{
			LogWin32Failure("SystemParametersInfo(SPI_GETWORKAREA)", ::GetLastError());
			return false;
		}

		aPlaceX = 64;
		aPlaceY = 64;
		if (mPreferredX != -1)
		{
			aPlaceX = mPreferredX;
			aPlaceY = mPreferredY;

			int aSpacing = 4;
			if (aPlaceX < aDesktopRect.left + aSpacing)
				aPlaceX = aDesktopRect.left + aSpacing;
			if (aPlaceY < aDesktopRect.top + aSpacing)
				aPlaceY = aDesktopRect.top + aSpacing;
			if (aPlaceX + aWidth >= aDesktopRect.right - aSpacing)
				aPlaceX = aDesktopRect.right - aWidth - aSpacing;
			if (aPlaceY + aHeight >= aDesktopRect.bottom - aSpacing)
				aPlaceY = aDesktopRect.bottom - aHeight - aSpacing;
		}
		else
		{
			aPlaceX = aDesktopRect.left + ((aDesktopRect.right - aDesktopRect.left) - aWidth) / 2;
			aPlaceY = aDesktopRect.top + (int)(((aDesktopRect.bottom - aDesktopRect.top) - aHeight) * 0.382);
		}
	}
	else
	{
		aWindowStyle = WS_POPUP;
		aWidth = GetSystemMetrics(SM_CXSCREEN);
		aHeight = GetSystemMetrics(SM_CYSCREEN);
		if (aWidth <= 0 || aHeight <= 0)
		{
			LogWin32Failure("GetSystemMetrics(screen)", ERROR_INVALID_DATA);
			return false;
		}
		aPlaceX = 0;
		aPlaceY = 0;
	}

	if (aWasVisible)
		aWindowStyle |= WS_VISIBLE;

	::SetLastError(ERROR_SUCCESS);
	const LONG_PTR aPreviousStyle = ::SetWindowLongPtr(mHWnd, GWL_STYLE, aWindowStyle);
	if (aPreviousStyle == 0 && ::GetLastError() != ERROR_SUCCESS)
	{
		LogWin32Failure("SetWindowLongPtr(GWL_STYLE)", ::GetLastError());
		return false;
	}
	if (!::SetWindowPos(
		mHWnd,
		NULL,
		aPlaceX,
		aPlaceY,
		aWidth,
		aHeight,
		SWP_FRAMECHANGED | SWP_NOZORDER | SWP_NOACTIVATE |
		(aWasVisible ? SWP_SHOWWINDOW : 0)))
	{
		LogWin32Failure("SetWindowPos", ::GetLastError());
		return false;
	}
	return true;
}

void SexyAppBase::SwitchScreenMode(bool wantWindowed)
{
	SwitchScreenMode(wantWindowed, Is3DAccelerated());
}

void SexyAppBase::SwitchScreenMode()
{
	SwitchScreenMode(mIsWindowed, Is3DAccelerated(), true);
}

void SexyAppBase::SetAlphaDisabled(bool isDisabled)
{
	if (mAlphaDisabled != isDisabled)
	{
		mAlphaDisabled = isDisabled;
		mDDInterface->SetVideoOnlyDraw(mAlphaDisabled);		
		mWidgetManager->mImage = mDDInterface->GetScreenImage();
		mWidgetManager->MarkAllDirty();
	}
}

void SexyAppBase::EnforceCursor()
{
	DWORD aStart = ::GetTickCount();
	bool wantSysCursor = true;

	if (mDDInterface == NULL)
		return;

	if ((mSEHOccured) || (!mMouseIn))
	{
		::SetCursor(::LoadCursor(NULL, IDC_ARROW));	
		if (mDDInterface->SetCursorImage(NULL))
			mCustomCursorDirty = true;
	}
	else
	{
		if ((mCursorImages[mCursorNum] == NULL) || 
			((!mPlayingDemoBuffer) && (!mCustomCursorsEnabled) && (mCursorNum != CURSOR_CUSTOM)))
		{
			if (mOverrideCursor != NULL)
				::SetCursor(mOverrideCursor);
			else if (mCursorNum == CURSOR_POINTER)
				::SetCursor(::LoadCursor(NULL, IDC_ARROW));
			else if (mCursorNum == CURSOR_HAND)
				::SetCursor(mHandCursor);
			else if (mCursorNum == CURSOR_TEXT)
				::SetCursor(::LoadCursor(NULL, IDC_IBEAM));
			else if (mCursorNum == CURSOR_DRAGGING)
				::SetCursor(mDraggingCursor);
			else if (mCursorNum == CURSOR_CIRCLE_SLASH)
				::SetCursor(::LoadCursor(NULL, IDC_NO));
			else if (mCursorNum == CURSOR_SIZEALL)
				::SetCursor(::LoadCursor(NULL, IDC_SIZEALL));
			else if (mCursorNum == CURSOR_SIZENESW)
				::SetCursor(::LoadCursor(NULL, IDC_SIZENESW));
			else if (mCursorNum == CURSOR_SIZENS)
				::SetCursor(::LoadCursor(NULL, IDC_SIZENS));
			else if (mCursorNum == CURSOR_SIZENWSE)
				::SetCursor(::LoadCursor(NULL, IDC_SIZENWSE));
			else if (mCursorNum == CURSOR_SIZEWE)
				::SetCursor(::LoadCursor(NULL, IDC_SIZEWE));
			else if (mCursorNum == CURSOR_WAIT)
				::SetCursor(::LoadCursor(NULL, IDC_WAIT));
			else if (mCursorNum == CURSOR_CUSTOM) 
				::SetCursor(NULL); // Default to not showing anything
			else if (mCursorNum == CURSOR_NONE)
				::SetCursor(NULL);			
			else
				::SetCursor(::LoadCursor(NULL, IDC_ARROW));

			if (mDDInterface->SetCursorImage(NULL))
				mCustomCursorDirty = true;
		}
		else
		{
			if (mDDInterface->SetCursorImage(mCursorImages[mCursorNum]))
				mCustomCursorDirty = true;

			if (!mPlayingDemoBuffer)
			{
				::SetCursor(NULL);
			}
			else
			{
				// Give the NO cursor in the client area and an arrow on the title bar

				POINT aULCorner = {0, 0};
				::ClientToScreen(mHWnd, &aULCorner);

				POINT aBRCorner = {mWidth, mHeight};
				::ClientToScreen(mHWnd, &aBRCorner);

				POINT aPoint;
				::GetCursorPos(&aPoint);			
									
				if ((aPoint.x >= aULCorner.x) && (aPoint.y >= aULCorner.y) &&
					(aPoint.x < aBRCorner.x) && (aPoint.y < aBRCorner.y))
				{
					::SetCursor(::LoadCursor(NULL, IDC_NO));
				}
				else
				{
					::SetCursor(::LoadCursor(NULL, IDC_ARROW));
				}
			}

			wantSysCursor = false;
		}
	}

	if (wantSysCursor != mSysCursor)
	{
		mSysCursor = wantSysCursor;

		// Don't hide the hardware cursor when playing back a demo buffer
//		if (!mPlayingDemoBuffer)
//			::ShowCursor(mSysCursor);
	}

	DWORD anElapsed = ::GetTickCount() - aStart;
	if (anElapsed > 30)
	{
		FILE* aLog = fopen(GetLogFilePath("enforcecursor.log").c_str(), "a");
		if (aLog != NULL)
		{
			fprintf(aLog, "took=%d\n", (int)anElapsed);
			fclose(aLog);
		}
	}
}

void SexyAppBase::ProcessSafeDeleteList()
{
	MTAutoDisallowRand aDisallowRand;

	WidgetSafeDeleteList::iterator anItr = mSafeDeleteList.begin();
	while (anItr != mSafeDeleteList.end())
	{
		WidgetSafeDeleteInfo* aWidgetSafeDeleteInfo = &(*anItr);
		if (mUpdateAppDepth <= aWidgetSafeDeleteInfo->mUpdateAppDepth)
		{
			delete aWidgetSafeDeleteInfo->mWidget;
			anItr = mSafeDeleteList.erase(anItr);
		}
		else
			++anItr;
	}	
}

void SexyAppBase::UpdateFTimeAcc()
{
	DWORD aCurTime = SexyGetTickCount();

	if (mLastTimeCheck != 0)
	{				
		int aDeltaTime = aCurTime - mLastTimeCheck;		

		mUpdateFTimeAcc = std::min(mUpdateFTimeAcc + aDeltaTime, 200.0);

		if (mRelaxUpdateBacklogCount > 0)				
			mRelaxUpdateBacklogCount = std::max(mRelaxUpdateBacklogCount - aDeltaTime, 0);				
	}

	mLastTimeCheck = aCurTime;
}

//int aNumCalls = 0;
//DWORD aLastCheck = 0;

bool SexyAppBase::Process(bool allowSleep)
{
	LegacyRuntimeTraceInstant(
		"process-begin",
		mUpdateCount,
		"state=%d acc=%.1f nonDraw=%d pendingDraw=%d",
		mUpdateAppState,
		mUpdateFTimeAcc,
		mNonDrawCount,
		mHasPendingDraw ? 1 : 0);

	/*DWORD aTimeNow = GetTickCount();
	if (aTimeNow - aLastCheck >= 10000)
	{
		OutputDebugString(StrFormat(_S("FUpdates: %d\n"), aNumCalls).c_str());
		aLastCheck = aTimeNow;
		aNumCalls = 0;
	}*/

	if (mLoadingFailed)
		Shutdown();
	
	bool isVSynched = (!mPlayingDemoBuffer) && (mVSyncUpdates) && (!mLastDrawWasEmpty) && (!mVSyncBroken) &&
		((!mIsPhysWindowed) || (mIsPhysWindowed && mWaitForVSync && !mSoftVSyncWait));
	double aFrameFTime;
	double anUpdatesPerUpdateF;

	if (mVSyncUpdates)
	{
		aFrameFTime = (1000.0 / mSyncRefreshRate) / mUpdateMultiplier;
		anUpdatesPerUpdateF = (float) (1000.0 / (mFrameTime * mSyncRefreshRate));
	}
	else
	{
		aFrameFTime = mFrameTime / mUpdateMultiplier;
		anUpdatesPerUpdateF = 1.0;
	}

	// Do we need to fast forward?
	if (mPlayingDemoBuffer)
	{
		if (mUpdateCount < mFastForwardToUpdateNum || mFastForwardToMarker)
		{
			if (!mDemoMute && !mFastForwardStep)
			{
				mDemoMute = true;
				Mute(true);
			}

			static DWORD aTick = GetTickCount();
			while (mUpdateCount < mFastForwardToUpdateNum || mFastForwardToMarker)
			{
				ClearUpdateBacklog();
				int aLastUpdateCount = mUpdateCount;
								
				// Actual updating code below
				//////////////////////////////////////////////////////////////////////////
				
				bool hadRealUpdate = DoUpdateFrames();

				if (hadRealUpdate)
				{					
					mPendingUpdatesAcc += anUpdatesPerUpdateF;
					mPendingUpdatesAcc -= 1.0;
					ProcessSafeDeleteList();

					// Process any extra updates
					while (mPendingUpdatesAcc >= 1.0)
					{						
						// These should just be IDLE commands we have to clear out
						ProcessDemo();												

						bool hasRealUpdate = DoUpdateFrames();
						DBG_ASSERTE(hasRealUpdate);

						if (!hasRealUpdate)
							break;
												
						ProcessSafeDeleteList();
						mPendingUpdatesAcc -= 1.0;
					}
										
					DoUpdateFramesF((float) anUpdatesPerUpdateF);					
					ProcessSafeDeleteList();
				}

				//////////////////////////////////////////////////////////////////////////				

				// If the update count doesn't change, its because we are
				//  playing back a demo and need to read more
				if (aLastUpdateCount == mUpdateCount)
					return true;

				DWORD aNewTick = GetTickCount();
				if (aNewTick - aTick >= 1000 || mFastForwardStep) // let the app draw some
				{
					mFastForwardStep = false;
					aTick = GetTickCount();
					DrawDirtyStuff();			
					return true;
				}
			}
		}

		if (mDemoMute)
		{
			mDemoMute = false;
			mSoundManager->StopAllSounds();
			Unmute(true);
		}
	}

	// Make sure we're not paused
	if ((!mPaused) && (mUpdateMultiplier > 0))
	{
		ulong aStartTime = SexyGetTickCount();
		
		// ulong aCurTime = aStartTime; // Unused
		int aCumSleepTime = 0;
		
		// When we are VSynching, only calculate this FTimeAcc right after drawing
		
		if (!isVSynched)		
			UpdateFTimeAcc();					

		// mNonDrawCount is used to make sure we draw the screen at least
		// 10 times per second, even if it means we have to slow down
		// the updates to make it draw 10 times per second in "game time"
		
		bool didUpdate = false;
		
		if (mUpdateAppState == UPDATESTATE_PROCESS_1)
		{
			if ((++mNonDrawCount < (int) ceil(10*mUpdateMultiplier)) || (!mLoaded))
			{
				bool doUpdate = false;
				
				if (isVSynched)
				{
					// Synch'ed to vertical refresh, so update as soon as possible after draw
					doUpdate = (!mHasPendingDraw) || (mUpdateFTimeAcc >= (int) (aFrameFTime * 0.75));
				}
				else if (mUpdateFTimeAcc >= aFrameFTime)
				{
					doUpdate = true;
				}

				LegacyRuntimeTraceInstant(
					"update-decision",
					mUpdateCount,
					"doUpdate=%d acc=%.1f frameTime=%.1f vsync=%d",
					doUpdate ? 1 : 0,
					mUpdateFTimeAcc,
					aFrameFTime,
					isVSynched ? 1 : 0);

				if (doUpdate)
				{
					// Do VSyncBroken test.  This test fails if we're in fullscreen and
					// "don't vsync" has been forced in Advanced settings up Display Properties
					if ((!mPlayingDemoBuffer) && (mUpdateMultiplier == 1.0))
					{
						mVSyncBrokenTestUpdates++;
						if (mVSyncBrokenTestUpdates >= (DWORD) ((1000+mFrameTime-1)/mFrameTime))
						{
							// It has to be running 33% fast to be "broken" (25% = 1/0.800)
							if (aStartTime - mVSyncBrokenTestStartTick <= 800)
							{
								// The test has to fail 3 times in a row before we decide that
								//  vsync is broken overall
								mVSyncBrokenCount++;
								if (mVSyncBrokenCount >= 3)
									mVSyncBroken = true;
							}
							else
								mVSyncBrokenCount = 0;

							mVSyncBrokenTestStartTick = aStartTime;
							mVSyncBrokenTestUpdates = 0;
						}
					}
					
					DWORD aBeforeDoUpdate = SexyGetTickCount();
					bool hadRealUpdate = DoUpdateFrames();
					DWORD aAfterDoUpdate = SexyGetTickCount();
					if (aAfterDoUpdate - aBeforeDoUpdate > 30)
					{
						FILE* aLog = fopen(GetLogFilePath("process-frames.log").c_str(), "a");
						if (aLog != NULL)
						{
							fprintf(aLog, "frames=%d update=%d\n",
								(int)(aAfterDoUpdate - aBeforeDoUpdate), mUpdateCount);
							fclose(aLog);
						}
					}
					if (hadRealUpdate)
						mUpdateAppState = UPDATESTATE_PROCESS_2;					
					else if (gScreenSaverActive)
					{
						// DoUpdateFrames refused to run because the screensaver
						// idle mode is active. Pace the spin at ~100Hz instead
						// of 100% CPU: the !didUpdate path would otherwise
						// never be reached and the game would busy-loop until
						// the next screensaver check observes input.
						Sleep(10);
					}

					mHasPendingDraw = true;
					didUpdate = true;
				}
			}
		}
		else if (mUpdateAppState == UPDATESTATE_PROCESS_2)
		{
			mUpdateAppState = UPDATESTATE_PROCESS_DONE;
			
			mPendingUpdatesAcc += anUpdatesPerUpdateF;
			mPendingUpdatesAcc -= 1.0;
			ProcessSafeDeleteList();

			// Process any extra updates
			while (mPendingUpdatesAcc >= 1.0)
			{	
				// These should just be IDLE commands we have to clear out
				ProcessDemo();												

				++mNonDrawCount;
				bool hasRealUpdate = DoUpdateFrames();
				DBG_ASSERTE(hasRealUpdate);

				if (!hasRealUpdate)
					break;
										
				ProcessSafeDeleteList();
				mPendingUpdatesAcc -= 1.0;
			}					

			//aNumCalls++;
			DoUpdateFramesF((float) anUpdatesPerUpdateF);
			ProcessSafeDeleteList();		
		
			// Don't let mUpdateFTimeAcc dip below 0
			//  Subtract an extra 0.2ms, because sometimes refresh rates have some
			//  fractional component that gets truncated, and it's better to take off
			//  too much to keep our timing tending toward occuring right after 
			//  redraws
			if (isVSynched)
				mUpdateFTimeAcc = std::max(mUpdateFTimeAcc - aFrameFTime - 0.2f, 0.0);
			else
				mUpdateFTimeAcc -= aFrameFTime;

			if (mRelaxUpdateBacklogCount > 0)
				mUpdateFTimeAcc = 0;

			didUpdate = true;
		}
		
		if (!didUpdate)
		{
			mUpdateAppState = UPDATESTATE_PROCESS_DONE;

			mNonDrawCount = 0;
			
			if (mHasPendingDraw)
			{
				LegacyRuntimeTraceInstant(
					"no-update-draw",
					mUpdateCount,
					"acc=%.1f",
					mUpdateFTimeAcc);
				DWORD aBeforeDraw = SexyGetTickCount();
				DrawDirtyStuff();
				DWORD aAfterDraw = SexyGetTickCount();
				if (aAfterDraw - aBeforeDraw > 30)
				{
					FILE* aLog = fopen(GetLogFilePath("process-frames.log").c_str(), "a");
					if (aLog != NULL)
					{
						fprintf(aLog, "draw=%d update=%d\n",
							(int)(aAfterDraw - aBeforeDraw), mUpdateCount);
						fclose(aLog);
					}
				}
			}
			else
			{
				// Let us take into account the time it took to draw dirty stuff			
				int aTimeToNextFrame = (int) (aFrameFTime - mUpdateFTimeAcc);
				LegacyRuntimeTraceInstant(
					"no-update-sleep",
					mUpdateCount,
					"acc=%.1f wait=%d",
					mUpdateFTimeAcc,
					aTimeToNextFrame);
				if (aTimeToNextFrame <= 0)
				{
					// Prevent a tight non-sleeping loop when the accumulator is
					// already at/above the frame time. This shows up as high CPU
					// and an unresponsive window before the first frame.
					aTimeToNextFrame = 1;
					mUpdateFTimeAcc = 0;
				}
				if (aTimeToNextFrame > 0)
				{
					if (aTimeToNextFrame > 100)
					{
						FILE* aLog = fopen(GetLogFilePath("frame-wait.log").c_str(), "a");
						if (aLog != NULL)
						{
							fprintf(aLog, "aFrameFTime=%.1f mUpdateFTimeAcc=%.1f wait=%d update=%d\n",
								aFrameFTime, mUpdateFTimeAcc, aTimeToNextFrame, mUpdateCount);
							fclose(aLog);
						}
					}
					if (!allowSleep)
						return false;

					// Wait till next processing cycle
					++mSleepCount;
					Sleep(aTimeToNextFrame);

					aCumSleepTime += aTimeToNextFrame;					
				}
			}
		}

		if (mYieldMainThread)
		{
			// This is to make sure that the title screen doesn't take up any more than 
			// 1/3 of the processor time

			ulong anEndTime = SexyGetTickCount();
			int anElapsedTime = (anEndTime - aStartTime) - aCumSleepTime;
			int aLoadingYieldSleepTime = std::min(250, (anElapsedTime * 2) - aCumSleepTime);

			if (aLoadingYieldSleepTime >= 0)
			{
				if (!allowSleep)
					return false;

				Sleep(aLoadingYieldSleepTime);
			}
		}
	}

	ProcessSafeDeleteList();	
	return true;
}

/*void SexyAppBase::DoMainLoop()
{
	Dialog* aDialog = NULL;
	if (theModalDialogId != -1)
	{
		aDialog = GetDialog(theModalDialogId);
		DBG_ASSERTE(aDialog != NULL);
		if (aDialog == NULL)
			return;
	}

	while (!mShutdown)
	{		
		MSG msg;
		while ((PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) && (!mShutdown))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		ProcessDemo();		
		ProcessDeferredMessages();

		if ((aDialog != NULL) && (aDialog->mResult != -1))
			return;

		if (!mShutdown)
		{
			//++aCount;
			Process();
		}		
	}
}*/

void SexyAppBase::DoMainLoop()
{
	while (!mShutdown)
	{
		if (mExitToTop)
			mExitToTop = false;
		UpdateApp();
	}
}

bool SexyAppBase::UpdateAppStep(bool* updated)
{
	if (updated != NULL)
		*updated = false;

	mWatchdogLastTick = SexyGetTickCount();

	DWORD aStepStart = SexyGetTickCount();

	if (mExitToTop)
		return false;

	if (mUpdateAppState == UPDATESTATE_PROCESS_DONE)
		mUpdateAppState = UPDATESTATE_MESSAGES;

	mUpdateAppDepth++;

	// We update in two stages to avoid doing a Process if our loop termination
	//  condition has already been met by processing windows messages		
	if (mUpdateAppState == UPDATESTATE_MESSAGES)
	{		
		MSG msg;
		int aNativeCount = 0;
		{
			LegacyRuntimeTraceScope aPumpScope("native-pump", mUpdateCount);
			while ((PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) && (!mShutdown) && (aNativeCount < 256))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
				++aNativeCount;
			}
		}

		DWORD aAfterMessages = SexyGetTickCount();

		{
			LegacyRuntimeTraceScope aDemoScope("process-demo", mUpdateCount);
			ProcessDemo();
		}

		// GLFW-style dispatch: the WndProc only queues events (exactly like
		// GLFW's win32 windowProc), and the whole burst is delivered right
		// after the native pump, in the same frame (exactly like
		// glfwPollEvents invoking the callbacks). Splitting a burst across
		// frames with a time budget is what turned rapid clicks into visible
		// stutter. The cap only guards against a pathological flood.
		{
			LegacyRuntimeTraceScope aDeferredScope("deferred-drain", mUpdateCount);
			int aDeferredCount = 0;
			while (!mShutdown && !mDeferredMessages.empty() && aDeferredCount < 4096)
			{
				ProcessDeferredMessages(true);
				++aDeferredCount;
			}
		}

		// The 100Hz SetTimer stream is gone; do mouse enter/exit bookkeeping once
		// per frame instead.
		{
			LegacyRuntimeTraceScope aTimerScope("timer-bookkeeping", mUpdateCount);
			if (!mShutdown)
				ProcessTimerMessage(mHWnd);
		}

		mUpdateAppState = UPDATESTATE_PROCESS_1;

		DWORD aAfterDeferred = SexyGetTickCount();
		if (aAfterDeferred - aStepStart > 50)
		{
			FILE* aLog = fopen(GetLogFilePath("mainloop.log").c_str(), "a");
			if (aLog != NULL)
			{
				fprintf(aLog, "messages=%d deferred=%d total=%d update=%d\n",
					(int)(aAfterMessages - aStepStart),
					(int)(aAfterDeferred - aAfterMessages),
					(int)(aAfterDeferred - aStepStart),
					mUpdateCount);
				fclose(aLog);
			}
		}
	}
	else
	{
		// Process changes state by itself
		if (mStepMode)
		{
			if (mStepMode==2)
			{
				Sleep(mFrameTime);
				mUpdateAppState = UPDATESTATE_PROCESS_DONE; // skip actual update until next step
			}
			else
			{
				mStepMode = 2;
				DoUpdateFrames();
				DoUpdateFramesF(1.0f);
				DrawDirtyStuff();
			}
		}
		else
		{
			int anOldUpdateCnt = mUpdateCount;
			DWORD aBeforeProcess = SexyGetTickCount();
			Process();		
			DWORD aAfterProcess = SexyGetTickCount();
			if (aAfterProcess - aBeforeProcess > 50)
			{
			FILE* aLog = fopen(GetLogFilePath("mainloop.log").c_str(), "a");
				if (aLog != NULL)
				{
					fprintf(aLog, "process=%d update=%d\n",
						(int)(aAfterProcess - aBeforeProcess), mUpdateCount);
					fclose(aLog);
				}
			}
			if (updated != NULL)
				*updated = mUpdateCount != anOldUpdateCnt;			
		}
	}

	mUpdateAppDepth--;

	return true;
}

bool SexyAppBase::UpdateApp()
{
	bool updated;
	for (;;)
	{
		if (!UpdateAppStep(&updated))
			return false;
		if (updated)
			return true;
	}
}

int SexyAppBase::InitDDInterface()
{
	// Init() may be called again after a device rebuild.  ScaleEffectRuntime
	// deliberately borrows the renderer's device/context, so detach the old
	// callback and release borrowed resources before DDInterface destroys that
	// renderer.  Leaving those COM pointers alive was a use-after-release on
	// the first scaled frame after a reinitialization.
	if (mDDInterface != nullptr && mDDInterface->mD3DInterface != nullptr &&
		mDDInterface->mD3DInterface->mD3D11 != nullptr)
	{
		mDDInterface->mD3DInterface->mD3D11->SetScalePresent(D3D11Renderer::ScalePresentFn());
		mDDInterface->mD3DInterface->mD3D11->PrepareForResize();
	}
	mScaleRuntime.DestroyDevice();

	PreDDInterfaceInitHook();
	DeleteNativeImageData();
	// D3D11 always owns a windowed DXGI swapchain; fullscreen is represented by
	// a borderless HWND inside DDInterface. Pass the requested logical mode so
	// DDInterface can choose desktop-sized presentation without exclusive mode.
	int aResult = mDDInterface->Init(mHWnd, mIsWindowed);
	DemoSyncRefreshRate();
	if ( DDInterface::RESULT_OK == aResult )
	{
		mScreenBounds.mX = ( mWidth - mDDInterface->mWidth ) / 2;
		mScreenBounds.mY = ( mHeight - mDDInterface->mHeight ) / 2;
		mScreenBounds.mWidth = mDDInterface->mWidth;
		mScreenBounds.mHeight = mDDInterface->mHeight;
		mWidgetManager->Resize(mScreenBounds, mDDInterface->mVisibleGameRect);
		PostDDInterfaceInitHook();
	}
	if (DDInterface::RESULT_OK == aResult && !mScaleEffects.empty() &&
		!PrepareScalePipelineObjects())
	{
		mDDInterface->mErrorString = "failed to create resident custom-scale shader objects";
		return DDInterface::RESULT_3D_FAIL;
	}
	InstallD3D11ScalePresent();
	return aResult;
}

bool SexyAppBase::PrepareScalePipelineObjects()
{
	if (mScaleEffects.empty() || mDDInterface == nullptr ||
		mDDInterface->mD3DInterface == nullptr ||
		mDDInterface->mD3DInterface->mD3D11 == nullptr)
		return false;

	D3D11Renderer* aRender = mDDInterface->mD3DInterface->mD3D11;
	if (!mScaleRuntime.CreateDevice(aRender->GetDevice(), aRender->GetContext()))
		return false;

	std::vector<ScaleEffectDesc*> aEffects;
	aEffects.reserve(mScaleEffects.size());
	for (ScaleEffectDesc& anEffect : mScaleEffects)
		aEffects.push_back(&anEffect);

	const bool aOk = mScaleRuntime.PreparePipelineObjects(aEffects);
	FILE* aLog = fopen(GetLogFilePath("scale-warmup.log").c_str(), "a");
	if (aLog != nullptr)
	{
		fprintf(aLog, "resident shader objects effects=%d ok=%d\n",
			(int)aEffects.size(), aOk ? 1 : 0);
		fclose(aLog);
	}
	return aOk;
}

void SexyAppBase::InstallD3D11ScalePresent()
{
	D3DInterface* aD3D = (mDDInterface != nullptr) ? mDDInterface->mD3DInterface : nullptr;
	D3D11Renderer* aRender = (aD3D != nullptr) ? aD3D->mD3D11 : nullptr;
	if (aRender == nullptr)
		return;
	// Do not leave a callback installed while the pipeline is absent.  A null
	// callback means scaling is intentionally off; once installed, a null
	// result is an actual pipeline failure and can be diagnosed as such.
	if (!IsScalePresentActive())
	{
		aRender->SetScalePresent(D3D11Renderer::ScalePresentFn());
		return;
	}

	// Presenter runs on the same D3D11 device/context as the renderer so the
	// finished scene texture flows into the Magpie pipeline with no copies.
	aRender->SetScalePresent(
		[this, aRender](ID3D11Texture2D* aScene, int aSrcW, int aSrcH, int& aOutW, int& aOutH)
		-> ID3D11Texture2D*
		{
			return RunScalePresentForMode(mIsWindowed, aRender, aScene, aSrcW, aSrcH, aOutW, aOutH);
		});
}

ID3D11Texture2D* SexyAppBase::RunScalePresentForMode(
	bool theWindowed,
	D3D11Renderer* theRender,
	ID3D11Texture2D* theScene,
	int theSrcW,
	int theSrcH,
	int& theOutW,
	int& theOutH)
{
	auto LogFailure = [&](const char* theReason)
	{
		FILE* aLog = fopen(GetLogFilePath("scale-present.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "failure reason=%s windowed=%d src=%dx%d target=%dx%d effects=%d\n",
				theReason, theWindowed ? 1 : 0, theSrcW, theSrcH,
				theOutW, theOutH, (int)mScaleEffects.size());
			fclose(aLog);
		}
	};

	theOutW = theSrcW;
	theOutH = theSrcH;
	if (!mUseCustomScale || mScaleEffects.empty() || theScene == nullptr || theRender == nullptr)
	{
		LogFailure("inactive-or-missing-renderer");
		return nullptr;
	}

	const ScalePipelineConfig& aConfig = theWindowed ? mScaleWindowConfig : mScaleFullscreenConfig;
	if (aConfig.mEffects.empty())
	{
		LogFailure("empty-mode-config");
		return nullptr;
	}

	ID3D11Device* aDevice = theRender->GetDevice();
	ID3D11DeviceContext* aContext = theRender->GetContext();
	if (aDevice == nullptr || aContext == nullptr)
	{
		LogFailure("missing-device-context");
		return nullptr;
	}

	// The runtime borrows the renderer's device.  CreateDevice handles both
	// device and context changes; the old code only compared the device and
	// could retain resources tied to a replaced immediate context.
	if (!mScaleRuntime.CreateDevice(aDevice, aContext))
	{
		LogFailure("runtime-device-bind-failed");
		return nullptr;
	}

	std::vector<ScaleEffectDesc*> aEffects;
	std::vector<ScaleEffectScaling> aScalings;
	if (!BuildScalePipelineForMode(theWindowed, aEffects, aScalings))
	{
		LogFailure("pipeline-description-not-found");
		return nullptr;
	}

	int aTgtW = theSrcW;
	int aTgtH = theSrcH;
	if (theWindowed)
	{
		// This function is also used to prewarm the next mode before
		// DDInterface has switched its display dimensions. Derive the requested
		// window size directly instead of accidentally using the old mode.
		aTgtW = mWidth * std::max(1, mWindowScale);
		aTgtH = mHeight * std::max(1, mWindowScale);
	}
	else
	{
		// During startup the app is still windowed, so use the actual desktop
		// dimensions for the dormant fullscreen pipeline.  This makes its
		// intermediate textures ready before the first toggle.
		aTgtW = GetSystemMetrics(SM_CXSCREEN);
		aTgtH = GetSystemMetrics(SM_CYSCREEN);
	}
	if (aTgtW <= 0 || aTgtH <= 0)
	{
		LogFailure("invalid-target-size");
		return nullptr;
	}

	ScaleEffectRuntimeOptions aOptions;
	aOptions.mSrcWidth = theSrcW;
	aOptions.mSrcHeight = theSrcH;
	aOptions.mTargetWidth = aTgtW;
	aOptions.mTargetHeight = aTgtH;
	aOptions.mFill = theWindowed;

	ID3D11Texture2D* aOutput = nullptr;
	if (!mScaleRuntime.RunPipeline(
			aEffects, aScalings, theWindowed ? 0u : 1u, theScene, aOptions, &aOutput,
			theRender->GetSceneSRV()))
	{
		LogFailure("runtime-pipeline-failed");
		return nullptr;
	}

	D3D11_TEXTURE2D_DESC aOutputDesc;
	ZeroMemory(&aOutputDesc, sizeof(aOutputDesc));
	aOutput->GetDesc(&aOutputDesc);
	theOutW = (int)aOutputDesc.Width;
	theOutH = (int)aOutputDesc.Height;
	static ID3D11Texture2D* sLastOutput = nullptr;
	static int sLastWindowed = -1;
	static int sLastWidth = 0;
	static int sLastHeight = 0;
	if (sLastOutput != aOutput || sLastWindowed != (theWindowed ? 1 : 0) ||
		sLastWidth != theOutW || sLastHeight != theOutH)
	{
		FILE* aLog = fopen(GetLogFilePath("scale-present.log").c_str(), "a");
		if (aLog != nullptr)
		{
			fprintf(aLog, "success windowed=%d src=%dx%d target=%dx%d output=%dx%d texture=%p\n",
				theWindowed ? 1 : 0, theSrcW, theSrcH, aTgtW, aTgtH,
				theOutW, theOutH, (void*)aOutput);
			fclose(aLog);
		}
		sLastOutput = aOutput;
		sLastWindowed = theWindowed ? 1 : 0;
		sLastWidth = theOutW;
		sLastHeight = theOutH;
	}
	return aOutput;
}

void SexyAppBase::WarmScalePipelinesBeforeShow()
{
	if (!mUseCustomScale || mScaleEffects.empty() || mDDInterface == nullptr ||
		mDDInterface->mD3DInterface == nullptr || mDDInterface->mD3DInterface->mD3D11 == nullptr)
		return;

	D3D11Renderer* aRender = mDDInterface->mD3DInterface->mD3D11;
	// Warm the active mode only.  The two HLSL chains are compiled before the
	// window exists, while their intermediate textures are intentionally kept
	// for the active mode; materializing a 4K fullscreen Anime4K chain beside
	// the window chain would consume hundreds of MiB before the user has even
	// requested fullscreen.  A fullscreen toggle warms its size after the safe
	// swapchain transition below.
	const bool aWarmOk = aRender->WarmScalePresent();

	FILE* aLog = fopen(GetLogFilePath("scale-warmup.log").c_str(), "a");
	if (aLog != nullptr)
	{
		fprintf(aLog, "warmup current=%s ok=%d\n",
			mIsWindowed ? "window" : "fullscreen",
			aWarmOk ? 1 : 0);
		fclose(aLog);
	}
	if (!aWarmOk)
		RaiseException(0xE000D314, EXCEPTION_NONCONTINUABLE, 0, nullptr);
}

void SexyAppBase::PreTerminate()
{
}

void SexyAppBase::Start()
{
	if (mShutdown)
		return;

	// The cursor thread is restored: the Win32 stutter was traced to the
	// screensaver mixed-clock busy loop, not to this thread.
	StartCursorThread();

	if (mAutoStartLoadingThread)
		StartLoadingThread();

	::ShowWindow(mHWnd, SW_SHOW);	
	::SetFocus(mHWnd);

	timeBeginPeriod(1);

	//int aCount = 0; // unused
	//int aSleepCount = 0; // unused

	DWORD aStartTime = SexyGetTickCount();		

	mRunning = true;
	mLastTime = aStartTime;
	mLastUserInputTick = aStartTime;
	mLastTimerTime = aStartTime;
	// Initialization can perform one framework draw before Start().  Never let
	// that pre-run idle check carry a stale screen-saver state into the game.
	gScreenSaverActive = false;

	// Stall watchdog: dumps the main thread's stack whenever the loop stops
	// updating for >250ms (diagnostic for the Win32-loop stutter).
	StartStallWatchdog();

	DoMainLoop();
	ProcessSafeDeleteList();

	StopStallWatchdog();

	mRunning = false;

	WaitForLoadingThread();

	char aString[256];
	sprintf(aString, "Seconds       = %g\r\n", (SexyGetTickCount() - aStartTime) / 1000.0);
	OutputDebugStringA(aString);
	//sprintf(aString, "Count         = %d\r\n", aCount);
	//OutputDebugString(aString);
	sprintf(aString, "Sleep Count   = %d\r\n", mSleepCount);
	OutputDebugStringA(aString);
	sprintf(aString, "Update Count  = %d\r\n", mUpdateCount);
	OutputDebugStringA(aString);
	sprintf(aString, "Draw Count    = %d\r\n", mDrawCount);
	OutputDebugStringA(aString);
	sprintf(aString, "Draw Time     = %d\r\n", mDrawTime);
	OutputDebugStringA(aString);
	sprintf(aString, "Screen Blt    = %d\r\n", mScreenBltTime);
	OutputDebugStringA(aString);
	if (mDrawTime+mScreenBltTime > 0)
	{
		sprintf(aString, "Avg FPS       = %d\r\n", (mDrawCount*1000)/(mDrawTime+mScreenBltTime));
		OutputDebugStringA(aString);
	}

	timeEndPeriod(1);	

	PreTerminate();

	WriteToRegistry();
}

/*
bool SexyAppBase::CheckSignature(const Buffer& theBuffer, const std::string& theFileName)
{
	(void)theBuffer;(void)theFileName;
	// Add your own signature checking code here
	return false;
}
*/

bool SexyAppBase::LoadProperties(const std::string& theFileName, bool required, bool checkSig)
{
	Buffer aBuffer;
	if (!ReadBufferFromFile(theFileName, &aBuffer))
	{
		if (!required)
			return true;
		else
		{
			Popup(GetString("UNABLE_OPEN_PROPERTIES", _S("Unable to open properties file ")) + StringToSexyString(theFileName));
			return false;
		}
	}
	if (checkSig)
	{
		//if (!CheckSignature(aBuffer, theFileName))
		//{
			//Popup(GetString("PROPERTIES_SIG_FAILED", _S("Signature check failed on ")) + StringToSexyString(theFileName + "'"));
			//return false;
		//}
	}

	PropertiesParser aPropertiesParser(this);

	// Load required language-file properties
		if (!aPropertiesParser.ParsePropertiesBuffer(aBuffer))
		{
			Popup(aPropertiesParser.GetErrorText());		
			return false;
		}
		else
			return true;
}

bool SexyAppBase::LoadProperties()
{
	// Load required language-file properties
	return LoadProperties("properties\\default.xml", true, false);
}

void SexyAppBase::LoadResourceManifest()
{
	if (!mResourceManager->ParseResourcesFile("properties\\resources.xml"))
		ShowResourceError(true);
}

void SexyAppBase::ShowResourceError(bool doExit)
{
	Popup(mResourceManager->GetErrorText());	
	if (doExit)
		DoExit(0);
}

bool SexyAppBase::GetBoolean(const std::string& theId)
{
	StringBoolMap::iterator anItr = mBoolProperties.find(theId);
	DBG_ASSERTE(anItr != mBoolProperties.end());
	
	if (anItr != mBoolProperties.end())	
		return anItr->second;
	else
		return false;
}

bool SexyAppBase::GetBoolean(const std::string& theId, bool theDefault)
{
	StringBoolMap::iterator anItr = mBoolProperties.find(theId);	
	
	if (anItr != mBoolProperties.end())	
		return anItr->second;
	else
		return theDefault;	
}

int SexyAppBase::GetInteger(const std::string& theId)
{
	StringIntMap::iterator anItr = mIntProperties.find(theId);
	DBG_ASSERTE(anItr != mIntProperties.end());
	
	if (anItr != mIntProperties.end())	
		return anItr->second;
	else
		return false;
}

int SexyAppBase::GetInteger(const std::string& theId, int theDefault)
{
	StringIntMap::iterator anItr = mIntProperties.find(theId);	
	
	if (anItr != mIntProperties.end())	
		return anItr->second;
	else
		return theDefault;	
}

double SexyAppBase::GetDouble(const std::string& theId)
{
	StringDoubleMap::iterator anItr = mDoubleProperties.find(theId);
	DBG_ASSERTE(anItr != mDoubleProperties.end());
	
	if (anItr != mDoubleProperties.end())	
		return anItr->second;
	else
		return false;
}

double SexyAppBase::GetDouble(const std::string& theId, double theDefault)
{
	StringDoubleMap::iterator anItr = mDoubleProperties.find(theId);	
	
	if (anItr != mDoubleProperties.end())	
		return anItr->second;
	else
		return theDefault;	
}

SexyString SexyAppBase::GetString(const std::string& theId)
{
	StringWStringMap::iterator anItr = mStringProperties.find(theId);
	DBG_ASSERTE(anItr != mStringProperties.end());
	
	if (anItr != mStringProperties.end())	
		return WStringToSexyString(anItr->second);
	else
		return _S("");
}

SexyString SexyAppBase::GetString(const std::string& theId, const SexyString& theDefault)
{
	StringWStringMap::iterator anItr = mStringProperties.find(theId);	
	
	if (anItr != mStringProperties.end())	
		return WStringToSexyString(anItr->second);
	else
		return theDefault;	
}

StringVector SexyAppBase::GetStringVector(const std::string& theId)
{
	StringStringVectorMap::iterator anItr = mStringVectorProperties.find(theId);
	DBG_ASSERTE(anItr != mStringVectorProperties.end());
	
	if (anItr != mStringVectorProperties.end())	
		return anItr->second;
	else
		return StringVector();
}

void SexyAppBase::SetString(const std::string& theId, const std::wstring& theValue)
{
	std::pair<StringWStringMap::iterator, bool> aPair = mStringProperties.insert(StringWStringMap::value_type(theId, theValue));
	if (!aPair.second) // Found it, change value
		aPair.first->second = theValue;
}


void SexyAppBase::SetBoolean(const std::string& theId, bool theValue)
{
	std::pair<StringBoolMap::iterator, bool> aPair = mBoolProperties.insert(StringBoolMap::value_type(theId, theValue));
	if (!aPair.second) // Found it, change value
		aPair.first->second = theValue;
}

void SexyAppBase::SetInteger(const std::string& theId, int theValue)
{
	std::pair<StringIntMap::iterator, bool> aPair = mIntProperties.insert(StringIntMap::value_type(theId, theValue));
	if (!aPair.second) // Found it, change value
		aPair.first->second = theValue;
}

void SexyAppBase::SetDouble(const std::string& theId, double theValue)
{
	std::pair<StringDoubleMap::iterator, bool> aPair = mDoubleProperties.insert(StringDoubleMap::value_type(theId, theValue));
	if (!aPair.second) // Found it, change value
		aPair.first->second = theValue;
}

void SexyAppBase::DoParseCmdLine()
{
	char* aCmdLine = GetCommandLineA();	
	char* aCmdLinePtr = aCmdLine;
	if (aCmdLinePtr[0] == '"')
	{
		aCmdLinePtr = strchr(aCmdLinePtr + 1, '"');
		if (aCmdLinePtr != NULL)
			aCmdLinePtr++;
	}
	
	if (aCmdLinePtr != NULL)
	{
		aCmdLinePtr = strchr(aCmdLinePtr, ' ');
		if (aCmdLinePtr != NULL)
			ParseCmdLine(aCmdLinePtr+1);	
	}

	mCmdLineParsed = true;
}

void SexyAppBase::ParseCmdLine(const std::string& theCmdLine)
{
	// Command line example:  -play -demofile="game demo.dmo"
	// Results in HandleCmdLineParam("-play", ""); HandleCmdLineParam("-demofile", "game demo.dmo");
	std::string aCurParamName;
	std::string aCurParamValue;

	//int aSpacePos = 0; // Unused
	bool inQuote = false;
	bool onValue = false;

	for (size_t i = 0; i < theCmdLine.length(); i++)
	{
		char c = theCmdLine[i];
		bool atEnd = false;
		
		if (c == '"')
		{
			inQuote = !inQuote;

			if (!inQuote)
				atEnd = true;
		}
		else if ((c == ' ') && (!inQuote))
			atEnd = true;
		else if (c == '=')
			onValue = true;
		else if (onValue)
			aCurParamValue += c;
		else
			aCurParamName += c;
		
		if (i == theCmdLine.length() - 1)
			atEnd = true;
		
		if (atEnd && !aCurParamName.empty())
		{
			HandleCmdLineParam(aCurParamName, aCurParamValue);
			aCurParamName = "";
			aCurParamValue = "";
			onValue = false;
		}	
	}
}

static int GetMaxDemoFileNum(const std::string& theDemoPrefix, int theMaxToKeep, bool doErase)
{
	WIN32_FIND_DATAA aData;
	HANDLE aHandle = FindFirstFileA((theDemoPrefix + "*.dmo").c_str(), &aData);
	if (aHandle==INVALID_HANDLE_VALUE)
		return 0;

	typedef std::set<int> IntSet;
	IntSet aSet;

	do {
		int aNum = 0;
		if (sscanf(aData.cFileName,(theDemoPrefix + "%d.dmo").c_str(), &aNum)==1)
			aSet.insert(aNum);

	} while(FindNextFileA(aHandle,&aData));
	FindClose(aHandle);

	IntSet::iterator anItr = aSet.begin();
	if ((int)aSet.size()>theMaxToKeep-1 && doErase)
		DeleteFile(StrFormat((theDemoPrefix + "%d.dmo").c_str(),*anItr).c_str());

	if (aSet.empty())
		return 0;

	anItr = aSet.end();
	--anItr;
	return (*anItr);
}

void SexyAppBase::HandleCmdLineParam(const std::string& theParamName, const std::string& theParamValue)
{
	if (theParamName == "-play")
	{
		mPlayingDemoBuffer = true;
		mRecordingDemoBuffer = false;
	}
	else if (theParamName == "-recnum")
	{
		int aNum = atoi(theParamValue.c_str());
		if (aNum<=0)
			aNum=5;

		int aDemoFileNum = GetMaxDemoFileNum(mDemoPrefix, aNum, true) + 1;
		mDemoFileName = SexyStringToString(StrFormat(StringToSexyString(mDemoPrefix + "%d.dmo").c_str(),aDemoFileNum));
		if (mDemoFileName.length() < 2 || (mDemoFileName[1] != ':' && mDemoFileName[2] != '\\'))
		{
			mDemoFileName = GetAppDataFolder() + mDemoFileName;
		}
		mRecordingDemoBuffer = true;
		mPlayingDemoBuffer = false;
	}
	else if (theParamName == "-playnum")
	{
		int aNum = atoi(theParamValue.c_str())-1;
		if (aNum<0)
			aNum=0;

		int aDemoFileNum = GetMaxDemoFileNum(mDemoPrefix, aNum, false)-aNum;
		mDemoFileName = SexyStringToString(StrFormat(StringToSexyString(mDemoPrefix + "%d.dmo").c_str(),aDemoFileNum));
		mRecordingDemoBuffer = false;
		mPlayingDemoBuffer = true;
	}
	else if (theParamName == "-record")
	{
		mRecordingDemoBuffer = true;
		mPlayingDemoBuffer = false;
	}
	else if (theParamName == "-demofile")
	{
		mDemoFileName = theParamValue;
		if (mDemoFileName.length() < 2 || (mDemoFileName[1] != ':' && mDemoFileName[2] != '\\'))
		{
			mDemoFileName = GetAppDataFolder() + mDemoFileName;
		}
	}	
	else if (theParamName == "-crash")
	{
		// Try to access NULL
		char* a = 0;
		*a = '!';		
	}
	else if (theParamName == "-nosound")
	{
		mNoSoundNeeded = true;
	}
	else if (theParamName == "-screensaver")
	{
		mIsScreenSaver = true;
	}
	else if (theParamName == "-changedir")
	{
		mChangeDirTo = theParamValue;
	}
	else
	{
		Popup(GetString("INVALID_COMMANDLINE_PARAM", _S("Invalid command line parameter: ")) + StringToSexyString(theParamName));
		DoExit(0);
	}
}

void SexyAppBase::PreDisplayHook()
{
}

void SexyAppBase::PreDDInterfaceInitHook()
{
}

void SexyAppBase::PostDDInterfaceInitHook()
{
}

bool SexyAppBase::ChangeDirHook(const char *theIntendedPath)
{
	(void)theIntendedPath;
	return false;
}

MusicInterface* SexyAppBase::CreateMusicInterface()
{
	if (mNoSoundNeeded)
		return new DummyMusicInterface();
	return new BassMusicInterface(mInvisHWnd);
}

void SexyAppBase::InitPropertiesHook()
{
}

void SexyAppBase::InitHook()
{
}

void SexyAppBase::Init()
{
	LegacyStartupProbe("SexyAppBase::Init begin");
	mPrimaryThreadId = GetCurrentThreadId();	
	
	if (mShutdown)
		return;

	if (gDDrawDLL==NULL || gDSoundDLL==NULL)
	{
		LegacyStartupProbe("SexyAppBase::Init missing DirectX DLL");
		MessageBox(NULL, 
						GetString("APP_REQUIRES_DIRECTX", _S("This application requires a compatible DirectX runtime.")).c_str(),
						GetString("YOU_NEED_DIRECTX", _S("You need DirectX")).c_str(), 
						MB_OK | MB_ICONERROR);
		DoExit(0);
	}

	InitPropertiesHook();
	LegacyStartupProbe("SexyAppBase properties hook");
	// Settings (settings.xml, incl. customScale) are read before the immutable
	// scale configuration. Both pipelines compile regardless of checkbox state.
	ReadFromRegistry();
	LoadScaleConfig();
	if (getenv("PVZ_SCALE_DISABLE") != nullptr || getenv("PVZ_D3D11_RENDER") != nullptr)
	{
		// The options checkbox reads mUseCustomScale; keep it in sync with
		// the forced-off window scale so closing the options dialog does not
		// silently re-enable custom scaling.
		mUseCustomScale = false;
	}
	// The two XML pipelines are process-global immutable configuration. Read and
	// inline-compile them exactly once before any main HWND exists, even when the
	// direct (Custom Scale off) presentation path is initially selected. Their
	// D3D11 shader objects are materialized after the device is created and then
	// remain resident for that device's lifetime.
	LegacyStartupProbe("Custom scale compile begin (before MakeWindow)");
	CompileScaleEffects();
	LegacyStartupProbe("Custom scale compile complete (before MakeWindow)");
	UpdateWindowScaleFromPipeline();
	mWindowScale = mUseCustomScale ? std::max(1, mScaleConfigWindow) : 1;

	if (CheckForVista())
	{
		HMODULE aMod;
		SHGetFolderPathFunc aFunc = (SHGetFolderPathFunc)GetSHGetFolderPath("shell32.dll", &aMod);
		if (aFunc == NULL || aMod == NULL)
			// SHGetFolderPathFunc is shadowed!
			// SHGetFolderPathFunc aFunc = (SHGetFolderPathFunc)GetSHGetFolderPath("shfolder.dll", &aMod);
			aFunc = (SHGetFolderPathFunc)GetSHGetFolderPath("shfolder.dll", &aMod);

		if (aMod != NULL)
		{
			char aPath[MAX_PATH];
			aFunc(NULL, CSIDL_COMMON_APPDATA, NULL, SHGFP_TYPE_CURRENT, aPath);

			std::string aDataPath = RemoveTrailingSlash(aPath) + "\\" + mFullCompanyName + "\\" + mProdName;
			SetAppDataFolder(aDataPath + "\\");
			//MkDir(aDataPath);
			//AllowAllAccess(aDataPath);
			if (mDemoFileName.length() < 2 || (mDemoFileName[1] != ':' && mDemoFileName[2] != '\\'))
			{
				mDemoFileName = GetAppDataFolder() + mDemoFileName;
			}

			FreeLibrary(aMod);
		}
	}

	// Test harnesses can override the local profile root explicitly.
	const char* anAppDataOverride = std::getenv("PVZ_APPDATA_DIR");
	if (anAppDataOverride != NULL && anAppDataOverride[0] != '\0')
		SetAppDataFolder(anAppDataOverride);
	else
	{
		// Keep the remake self-contained and never mix its native GOTY saves with
		// files owned by an installed 32-bit release.
		SetAppDataFolder(AddTrailingSlash(mChangeDirTo, true) + "data\\");
	}
	
	if (!mCmdLineParsed)
		DoParseCmdLine();

	if (IsScreenSaver())	
		mOnlyAllowOneCopyToRun = false;	


	if(gHInstance==NULL)
		gHInstance = (HINSTANCE)GetModuleHandle(NULL);

	// Change directory
	if (!ChangeDirHook(mChangeDirTo.c_str()))
		chdir(mChangeDirTo.c_str());

	// The x64 build has exactly one packaged-resource format: the converter's
	// plain main.pak64.  Never mount the official 32-bit/XOR main.pak here.
	if (!gPakInterface->AddPakFile("main.pak64"))
	{
		LegacyStartupProbe("SexyAppBase main.pak64 mount failed");
		MessageBoxA(NULL, "missing or invalid plain x64 resource archive: main.pak64", "Error", MB_OK | MB_ICONERROR);
		exit(1);
	}
	LegacyStartupProbe("SexyAppBase main.pak64 mounted");

	// Create a message we can use to talk to ourselves inter-process
	mNotifyGameMessage = RegisterWindowMessage((_S("Notify") + StringToSexyString(mProdName)).c_str());

	// Create a valid, Legacy-only mutex. Kernel object names cannot contain a
	// path separator in the middle: the old PopCap\PlantsVsZombies-derived name
	// made CreateMutex fail with ERROR_PATH_NOT_FOUND, so every Legacy process
	// accidentally ran as a separate instance. Keep the name independent from
	// the 32-bit game's historical mutex so both programs can be inspected side
	// by side.
	const char* aLegacyMutexName = "PlantsVsZombiesLegacy64SingleInstance";
	::SetLastError(ERROR_SUCCESS);
	mMutex = ::CreateMutexA(NULL, TRUE, aLegacyMutexName);
	const DWORD aMutexError = ::GetLastError();
	if (mMutex == NULL)
	{
		LegacyStartupProbe("SexyAppBase mutex creation failed");
		MessageBoxA(NULL, "Unable to create the Legacy single-instance mutex.", "Plants vs. Zombies [legacy]", MB_OK | MB_ICONERROR);
		DoExit(1);
		return;
	}
	if (aMutexError == ERROR_ALREADY_EXISTS)
	{
		LegacyStartupProbe("SexyAppBase mutex already exists");
		HandleGameAlreadyRunning();
		return;
	}
	LegacyStartupProbe("SexyAppBase mutex created");

	mRandSeed = GetTickCount();
	SRand(mRandSeed);	

	// Set up demo recording stuff
	if (mPlayingDemoBuffer)
	{
		std::string anError;
		if (!ReadDemoBuffer(anError))
		{
			mPlayingDemoBuffer = false;
			Popup(anError);
			DoExit(0);
		}
	}

	srand(GetTickCount());

	mIsWideWindow = sizeof(SexyChar) == sizeof(wchar_t);

	WNDCLASS wc;
	wc.style = CS_DBLCLKS;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = NULL;
	wc.hCursor = NULL;
	wc.hIcon = ::LoadIconA(gHInstance, "IDI_MAIN_ICON");
	wc.hInstance = gHInstance;
	wc.lpfnWndProc = WindowProc;
	wc.lpszClassName = _S("MainWindow");
	wc.lpszMenuName = NULL;	
	bool success = RegisterClass(&wc) != 0;
	(void)success; // success unused in release mode
	DBG_ASSERTE(success);

	wc.style = 0;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = NULL;
	wc.hCursor = NULL;
	wc.hIcon = NULL;
	wc.hInstance = gHInstance;
	wc.lpfnWndProc = WindowProc;
	wc.lpszClassName = _S("InvisWindow");
	wc.lpszMenuName = NULL;	
	success = RegisterClass(&wc) != 0;
	DBG_ASSERTE(success);

	mInvisHWnd = CreateWindowEx(
			0,
			_S("InvisWindow"),
			mTitle.c_str(),
			0,
			0,
			0,
			0,
			0,
			NULL,
			NULL,
			gHInstance,
			0);	
	SetWindowLongPtr(mInvisHWnd, GWLP_USERDATA, (intptr_t) this);
		
	mHandCursor = CreateCursor(gHInstance, 11, 4, 32, 32, gFingerCursorData, gFingerCursorData+sizeof(gFingerCursorData)/2); 
	mDraggingCursor = CreateCursor(gHInstance, 15, 10, 32, 32, gDraggingCursorData, gDraggingCursorData+sizeof(gDraggingCursorData)/2); 
		
	// Let app do something before showing window, or switching to fullscreen mode
	// NOTE: Moved call to PreDisplayHook above mIsWindowed and GetSystemsMetrics
	// checks because the checks below use values that could change in PreDisplayHook.
	// PreDisplayHook must call mWidgetManager->Resize if it changes mWidth or mHeight.
	PreDisplayHook();

	mWidgetManager->Resize(Rect(0, 0, mWidth, mHeight), Rect(0, 0, mWidth, mHeight));

	// Keep the requested startup mode even when the desktop work area is smaller
	// than the original 800x600 client area.  A clipped window is recoverable;
	// silently entering exclusive fullscreen changes the user's display mode.

	if (mFullScreenWindow) // change resoultion using ChangeDisplaySettings
	{
		EnumWindows(ChangeDisplayWindowEnumProc,0); // record window pos
		DEVMODE dm;
		EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &dm );

		// Switch resolutions
		if (dm.dmPelsWidth!=(unsigned int)mWidth || dm.dmPelsHeight!=(unsigned int)mHeight || (dm.dmBitsPerPel!=16 && dm.dmBitsPerPel!=32))
		{
			dm.dmPelsWidth = mWidth;
			dm.dmPelsHeight = mHeight;
			dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY;

			if (dm.dmBitsPerPel!=16 && dm.dmBitsPerPel!=32) // handle 24-bit/256 color case
			{
				dm.dmBitsPerPel = 16;
				dm.dmFields |= DM_BITSPERPEL;
			}

			if (ChangeDisplaySettings(&dm,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
			{
				mFullScreenWindow = false;
				mIsWindowed = false;
			}
		}
	}

	MakeWindow();
	LegacyStartupProbe("SexyAppBase window created");
	// MakeWindow creates the D3D11 device but leaves the HWND hidden. Materialize
	// the already-compiled shader objects/textures first, then resize the hidden
	// swapchain/HWND. Start() is the only point that makes the window visible.
	if (mUseCustomScale && !mScaleEffects.empty())
		WarmScalePipelinesBeforeShow();
	if (mUseCustomScale && !mScaleEffects.empty())
		ApplyScaleWindow();
		
	if (mPlayingDemoBuffer)
	{
		// Get video data
		
		PrepareDemoCommand(true);
		mDemoNeedsCommand = true;
		
		DBG_ASSERTE(!mDemoIsShortCmd);
		DBG_ASSERTE(mDemoCmdNum == DEMO_VIDEO_DATA);

		mIsWindowed = mDemoBuffer.ReadBoolean();
		mSyncRefreshRate = mDemoBuffer.ReadByte();
	}

	if (mSoundManager == NULL)		
		mSoundManager = new DSoundManager(mNoSoundNeeded?NULL:mHWnd);

	SetSfxVolume(mSfxVolume);
	
	mMusicInterface = CreateMusicInterface();	

	SetMusicVolume(mMusicVolume);	

	if (IsScreenSaver())
	{
		SetCursor(CURSOR_NONE);
	}

	InitHook();

	mInitialized = true;
	LegacyStartupProbe("SexyAppBase::Init complete");
}

void SexyAppBase::HandleGameAlreadyRunning()
{
	if(mOnlyAllowOneCopyToRun)
	{
		// Notify the other window and then shut ourselves down
		if (mNotifyGameMessage != 0)
			PostMessage(HWND_BROADCAST, mNotifyGameMessage, 0, 0);

		DoExit(0);
	}
}

void SexyAppBase::CopyToClipboard(const std::string& theString)
{
	if (mPlayingDemoBuffer)
		return;

	HGLOBAL				aGlobalHandle;
	char*				theData;	
	WCHAR*				theWData;

	if (OpenClipboard(mHWnd))
	{
		EmptyClipboard();

		aGlobalHandle = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, theString.length()+1);
		theData = (char*) GlobalLock(aGlobalHandle);
		strcpy(theData, theString.c_str());
		GlobalUnlock(aGlobalHandle);
		SetClipboardData(CF_TEXT, aGlobalHandle);
		SetClipboardData(CF_OEMTEXT, aGlobalHandle);		
		SetClipboardData(CF_LOCALE, aGlobalHandle);

		int aSize = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, theString.c_str(), theString.length(), NULL, 0);
		aGlobalHandle = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, (aSize + 1) * sizeof(WCHAR));
		theWData = (WCHAR*) GlobalLock(aGlobalHandle);
		MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, theString.c_str(), theString.length(), theWData, aSize);
		theWData[aSize] = '\0';
		GlobalUnlock(aGlobalHandle);
		SetClipboardData(CF_UNICODETEXT, aGlobalHandle);
		
		CloseClipboard();
	}
}

std::string	SexyAppBase::GetClipboard()
{
	HGLOBAL				aGlobalHandle;	
	std::string			aString;

	if (!mPlayingDemoBuffer)
	{
		if (OpenClipboard(mHWnd))
		{
			aGlobalHandle = GetClipboardData(CF_TEXT);	
			if (aGlobalHandle != NULL)
			{
				char* theData = (char*) GlobalLock(aGlobalHandle);
				if (theData != NULL)
				{
					aString = theData;		
					GlobalUnlock(aGlobalHandle);
				}
			}
			
			CloseClipboard();
		}
	}

	DemoSyncString(&aString);

	return aString;
}

void SexyAppBase::SetCursor(int theCursorNum)
{
	mCursorNum = theCursorNum;
	EnforceCursor();
}

int SexyAppBase::GetCursor()
{
	return mCursorNum;
}

void SexyAppBase::EnableCustomCursors(bool enabled)
{
	mCustomCursorsEnabled = enabled;
	EnforceCursor();
}

Sexy::DDImage* SexyAppBase::GetImage(const std::string& theFileName, bool commitBits)
{	
	ImageLib::Image* aLoadedImage = ImageLib::GetImage(theFileName, true);
	
	if (aLoadedImage == NULL)
		return NULL;	
	
	DDImage* anImage = new DDImage(mDDInterface);
	anImage->mFilePath = theFileName;
	anImage->SetBits(aLoadedImage->GetBits(), aLoadedImage->GetWidth(), aLoadedImage->GetHeight(), commitBits);	
	anImage->mFilePath = theFileName;
	delete aLoadedImage;
	
	return anImage;
}

Sexy::DDImage* SexyAppBase::CreateCrossfadeImage(Sexy::Image* theImage1, const Rect& theRect1, Sexy::Image* theImage2, const Rect& theRect2, double theFadeFactor)
{
	MemoryImage* aMemoryImage1 = dynamic_cast<MemoryImage*>(theImage1);
	MemoryImage* aMemoryImage2 = dynamic_cast<MemoryImage*>(theImage2);

	if ((aMemoryImage1 == NULL) || (aMemoryImage2 == NULL))
		return NULL;

	if ((theRect1.mX < 0) || (theRect1.mY < 0) || 
		(theRect1.mX + theRect1.mWidth > theImage1->GetWidth()) ||
		(theRect1.mY + theRect1.mHeight > theImage1->GetHeight()))
	{
		DBG_ASSERTE("Crossfade Rect1 out of bounds");
		return NULL;
	}

	if ((theRect2.mX < 0) || (theRect2.mY < 0) || 
		(theRect2.mX + theRect2.mWidth > theImage2->GetWidth()) ||
		(theRect2.mY + theRect2.mHeight > theImage2->GetHeight()))
	{
		DBG_ASSERTE("Crossfade Rect2 out of bounds");
		return NULL;
	}

	int aWidth = theRect1.mWidth;
	int aHeight = theRect1.mHeight;

	DDImage* anImage = new DDImage(mDDInterface);
	anImage->Create(aWidth, aHeight);

	ulong* aDestBits = anImage->GetBits();
	ulong* aSrcBits1 = aMemoryImage1->GetBits();
	ulong* aSrcBits2 = aMemoryImage2->GetBits();

	int aSrc1Width = aMemoryImage1->GetWidth();
	int aSrc2Width = aMemoryImage2->GetWidth();
	ulong aMult = (int) (theFadeFactor*256);
	ulong aOMM = (256 - aMult);

	for (int y = 0; y < aHeight; y++)
	{
		ulong* s1 = &aSrcBits1[(y+theRect1.mY)*aSrc1Width+theRect1.mX];
		ulong* s2 = &aSrcBits2[(y+theRect2.mY)*aSrc2Width+theRect2.mX];
		ulong* d = &aDestBits[y*aWidth];

		for (int x = 0; x < aWidth; x++)
		{
			ulong p1 = *s1++;
			ulong p2 = *s2++;

			//p1 = 0;
			//p2 = 0xFFFFFFFF;

			*d++ = 
				((((p1 & 0x000000FF)*aOMM + (p2 & 0x000000FF)*aMult)>>8) & 0x000000FF) |
				((((p1 & 0x0000FF00)*aOMM + (p2 & 0x0000FF00)*aMult)>>8) & 0x0000FF00) |
				((((p1 & 0x00FF0000)*aOMM + (p2 & 0x00FF0000)*aMult)>>8) & 0x00FF0000) |
				((((p1 >> 24)*aOMM + (p2 >> 24)*aMult)<<16) & 0xFF000000);
		}
	}

	anImage->BitsChanged();
	
	return anImage;
}

void SexyAppBase::ColorizeImage(Image* theImage, const Color& theColor)
{
	MemoryImage* aSrcMemoryImage = dynamic_cast<MemoryImage*>(theImage);

	if (aSrcMemoryImage == NULL)
		return;

	ulong* aBits;	
	int aNumColors;

	if (aSrcMemoryImage->mColorTable == NULL)
	{
		aBits = aSrcMemoryImage->GetBits();		
		aNumColors = theImage->GetWidth()*theImage->GetHeight();				
	}
	else
	{
		aBits = aSrcMemoryImage->mColorTable;		
		aNumColors = 256;				
	}
						
	if ((theColor.mAlpha <= 255) && (theColor.mRed <= 255) && 
		(theColor.mGreen <= 255) && (theColor.mBlue <= 255))
	{
		for (int i = 0; i < aNumColors; i++)
		{
			ulong aColor = aBits[i];

			aBits[i] = 
				((((aColor & 0xFF000000) >> 8) * theColor.mAlpha) & 0xFF000000) |
				((((aColor & 0x00FF0000) * theColor.mRed) >> 8) & 0x00FF0000) |
				((((aColor & 0x0000FF00) * theColor.mGreen) >> 8) & 0x0000FF00)|
				((((aColor & 0x000000FF) * theColor.mBlue) >> 8) & 0x000000FF);
		}
	}
	else
	{
		for (int i = 0; i < aNumColors; i++)
		{
			ulong aColor = aBits[i];

			int aAlpha = ((aColor >> 24) * theColor.mAlpha) / 255;
			int aRed = (((aColor >> 16) & 0xFF) * theColor.mRed) / 255;
			int aGreen = (((aColor >> 8) & 0xFF) * theColor.mGreen) / 255;
			int aBlue = ((aColor & 0xFF) * theColor.mBlue) / 255;

			if (aAlpha > 255)
				aAlpha = 255;
			if (aRed > 255)
				aRed = 255;
			if (aGreen > 255)
				aGreen = 255;
			if (aBlue > 255)
				aBlue = 255;

			aBits[i] = (aAlpha << 24) | (aRed << 16) | (aGreen << 8) | (aBlue);
		}
	}	

	aSrcMemoryImage->BitsChanged();
}

DDImage* SexyAppBase::CreateColorizedImage(Image* theImage, const Color& theColor)
{
	MemoryImage* aSrcMemoryImage = dynamic_cast<MemoryImage*>(theImage);

	if (aSrcMemoryImage == NULL)
		return NULL;

	DDImage* anImage = new DDImage(mDDInterface);
	
	anImage->Create(theImage->GetWidth(), theImage->GetHeight());
	
	ulong* aSrcBits;
	ulong* aDestBits;
	int aNumColors;

	if (aSrcMemoryImage->mColorTable == NULL)
	{
		aSrcBits = aSrcMemoryImage->GetBits();
		aDestBits = anImage->GetBits();
		aNumColors = theImage->GetWidth()*theImage->GetHeight();				
	}
	else
	{
		aSrcBits = aSrcMemoryImage->mColorTable;
		aDestBits = anImage->mColorTable = new ulong[256];
		aNumColors = 256;
		
		anImage->mColorIndices = new uchar[anImage->mWidth*theImage->mHeight];
		memcpy(anImage->mColorIndices, aSrcMemoryImage->mColorIndices, anImage->mWidth*theImage->mHeight);
	}
						
	if ((theColor.mAlpha <= 255) && (theColor.mRed <= 255) && 
		(theColor.mGreen <= 255) && (theColor.mBlue <= 255))
	{
		for (int i = 0; i < aNumColors; i++)
		{
			ulong aColor = aSrcBits[i];

			aDestBits[i] = 
				((((aColor & 0xFF000000) >> 8) * theColor.mAlpha) & 0xFF000000) |
				((((aColor & 0x00FF0000) * theColor.mRed) >> 8) & 0x00FF0000) |
				((((aColor & 0x0000FF00) * theColor.mGreen) >> 8) & 0x0000FF00)|
				((((aColor & 0x000000FF) * theColor.mBlue) >> 8) & 0x000000FF);
		}
	}
	else
	{
		for (int i = 0; i < aNumColors; i++)
		{
			ulong aColor = aSrcBits[i];

			int aAlpha = ((aColor >> 24) * theColor.mAlpha) / 255;
			int aRed = (((aColor >> 16) & 0xFF) * theColor.mRed) / 255;
			int aGreen = (((aColor >> 8) & 0xFF) * theColor.mGreen) / 255;
			int aBlue = ((aColor & 0xFF) * theColor.mBlue) / 255;

			if (aAlpha > 255)
				aAlpha = 255;
			if (aRed > 255)
				aRed = 255;
			if (aGreen > 255)
				aGreen = 255;
			if (aBlue > 255)
				aBlue = 255;

			aDestBits[i] = (aAlpha << 24) | (aRed << 16) | (aGreen << 8) | (aBlue);
		}
	}	

	anImage->BitsChanged();

	return anImage;
}

DDImage* SexyAppBase::CopyImage(Image* theImage, const Rect& theRect)
{
	DDImage* anImage = new DDImage(mDDInterface);

	anImage->Create(theRect.mWidth, theRect.mHeight);
	
	Graphics g(anImage);
	g.DrawImage(theImage, -theRect.mX, -theRect.mY);

	anImage->CopyAttributes(theImage);

	return anImage;
}

DDImage* SexyAppBase::CopyImage(Image* theImage)
{
	return CopyImage(theImage, Rect(0, 0, theImage->GetWidth(), theImage->GetHeight()));
}

void SexyAppBase::MirrorImage(Image* theImage)
{
	MemoryImage* aSrcMemoryImage = dynamic_cast<MemoryImage*>(theImage);	

	ulong* aSrcBits = aSrcMemoryImage->GetBits();

	int aPhysSrcWidth = aSrcMemoryImage->mWidth;
	for (int y = 0; y < aSrcMemoryImage->mHeight; y++)
	{
		ulong* aLeftBits = aSrcBits + (y * aPhysSrcWidth);		
		ulong* aRightBits = aLeftBits + (aPhysSrcWidth - 1);

		for (int x = 0; x < (aPhysSrcWidth >> 1); x++)
		{
			ulong aSwap = *aLeftBits;

			*(aLeftBits++) = *aRightBits;
			*(aRightBits--) = aSwap;
		}
	}

	aSrcMemoryImage->BitsChanged();	
}

void SexyAppBase::FlipImage(Image* theImage)
{
	MemoryImage* aSrcMemoryImage = dynamic_cast<MemoryImage*>(theImage);

	ulong* aSrcBits = aSrcMemoryImage->GetBits();

	int aPhysSrcHeight = aSrcMemoryImage->mHeight;
	int aPhysSrcWidth = aSrcMemoryImage->mWidth;
	for (int x = 0; x < aPhysSrcWidth; x++)
	{
		ulong* aTopBits    = aSrcBits + x;
		ulong* aBottomBits = aTopBits + (aPhysSrcWidth * (aPhysSrcHeight - 1));

		for (int y = 0; y < (aPhysSrcHeight >> 1); y++)
		{
			ulong aSwap = *aTopBits;

			*aTopBits = *aBottomBits;
			aTopBits += aPhysSrcWidth;
			*aBottomBits = aSwap;
			aBottomBits -= aPhysSrcWidth;
		}
	}

	aSrcMemoryImage->BitsChanged();	
}

void SexyAppBase::RotateImageHue(Sexy::MemoryImage *theImage, int theDelta)
{
	while (theDelta < 0)
		theDelta += 256;

	int aSize = theImage->mWidth * theImage->mHeight;
	DWORD *aPtr = theImage->GetBits();
	for (int i=0; i<aSize; i++)
	{
		DWORD aPixel = *aPtr;
		int alpha = aPixel&0xff000000;
		int r = (aPixel>>16)&0xff;
		int g = (aPixel>>8) &0xff;
		int b = aPixel&0xff;

		int maxval = std::max(r, std::max(g, b));
		int minval = std::min(r, std::min(g, b));
		int h = 0;
		int s = 0;
		int l = (minval+maxval)/2;
		int delta = maxval - minval;

		if (delta != 0)
		{			
			s = (delta * 256) / ((l <= 128) ? (minval + maxval) : (512 - maxval - minval));
			
			if (r == maxval)
				h = (g == minval ? 1280 + (((maxval-b) * 256) / delta) :  256 - (((maxval - g) * 256) / delta));
			else if (g == maxval)
				h = (b == minval ?  256 + (((maxval-r) * 256) / delta) :  768 - (((maxval - b) * 256) / delta));
			else
				h = (r == minval ?  768 + (((maxval-g) * 256) / delta) : 1280 - (((maxval - r) * 256) / delta));
			
			h /= 6;
		}

		h += theDelta;
		if (h >= 256)
			h -= 256;

		double v= (l < 128) ? (l * (255+s))/255 :
				(l+s-l*s/255);
		
		int y = (int) (2*l-v);

		int aColorDiv = (6 * h) / 256;
		int x = (int)(y+(v-y)*((h - (aColorDiv * 256 / 6)) * 6)/255);
		if (x > 255)
			x = 255;

		int z = (int) (v-(v-y)*((h - (aColorDiv * 256 / 6)) * 6)/255);
		if (z < 0)
			z = 0;
		
		switch (aColorDiv)
		{
			case 0: r = (int) v; g = x; b = y; break;
			case 1: r = z; g= (int) v; b = y; break;
			case 2: r = y; g= (int) v; b = x; break;
			case 3: r = y; g = z; b = (int) v; break;
			case 4: r = x; g = y; b = (int) v; break;
			case 5: r = (int) v; g = y; b = z; break;
			default: r = (int) v; g = x; b = y; break;
		}

		*aPtr++ = alpha | (r<<16) | (g << 8) | (b);	 

	}

	theImage->BitsChanged();
}

ulong SexyAppBase::HSLToRGB(int h, int s, int l)
{
	int r;
	int g;
	int b;

	double v= (l < 128) ? (l * (255+s))/255 :
			(l+s-l*s/255);
	
	int y = (int) (2*l-v);

	int aColorDiv = (6 * h) / 256;
	int x = (int)(y+(v-y)*((h - (aColorDiv * 256 / 6)) * 6)/255);
	if (x > 255)
		x = 255;

	int z = (int) (v-(v-y)*((h - (aColorDiv * 256 / 6)) * 6)/255);
	if (z < 0)
		z = 0;
	
	switch (aColorDiv)
	{
		case 0: r = (int) v; g = x; b = y; break;
		case 1: r = z; g= (int) v; b = y; break;
		case 2: r = y; g= (int) v; b = x; break;
		case 3: r = y; g = z; b = (int) v; break;
		case 4: r = x; g = y; b = (int) v; break;
		case 5: r = (int) v; g = y; b = z; break;
		default: r = (int) v; g = x; b = y; break;
	}

	return 0xFF000000 | (r << 16) | (g << 8) | (b);
}

ulong SexyAppBase::RGBToHSL(int r, int g, int b)
{					
	int maxval = std::max(r, std::max(g, b));
	int minval = std::min(r, std::min(g, b));
	int hue = 0;
	int saturation = 0;
	int luminosity = (minval+maxval)/2;
	int delta = maxval - minval;

	if (delta != 0)
	{			
		saturation = (delta * 256) / ((luminosity <= 128) ? (minval + maxval) : (512 - maxval - minval));
		
		if (r == maxval)
			hue = (g == minval ? 1280 + (((maxval-b) * 256) / delta) :  256 - (((maxval - g) * 256) / delta));
		else if (g == maxval)
			hue = (b == minval ?  256 + (((maxval-r) * 256) / delta) :  768 - (((maxval - b) * 256) / delta));
		else
			hue = (r == minval ?  768 + (((maxval-g) * 256) / delta) : 1280 - (((maxval - r) * 256) / delta));
		
		hue /= 6;
	}

	return 0xFF000000 | (hue) | (saturation << 8) | (luminosity << 16);	 
}

void SexyAppBase::HSLToRGB(const ulong* theSource, ulong* theDest, int theSize)
{
	for (int i = 0; i < theSize; i++)
	{
		ulong src = theSource[i];
		theDest[i] = (src & 0xFF000000) | (HSLToRGB((src & 0xFF), (src >> 8) & 0xFF, (src >> 16) & 0xFF) & 0x00FFFFFF);
	}
}

void SexyAppBase::RGBToHSL(const ulong* theSource, ulong* theDest, int theSize)
{
	for (int i = 0; i < theSize; i++)
	{
		ulong src = theSource[i];
		theDest[i] = (src & 0xFF000000) | (RGBToHSL(((src >> 16) & 0xFF), (src >> 8) & 0xFF, (src & 0xFF)) & 0x00FFFFFF);
	}
}

void SexyAppBase::PrecacheAdditive(MemoryImage* theImage)
{
	theImage->GetRLAdditiveData(mDDInterface);
}

void SexyAppBase::PrecacheAlpha(MemoryImage* theImage)
{
	theImage->GetRLAlphaData();
}

void SexyAppBase::PrecacheNative(MemoryImage* theImage)
{
	theImage->GetNativeAlphaData(mDDInterface);
}


void SexyAppBase::PlaySample(int theSoundNum)
{
	if (!mSoundManager)
		return;

	SoundInstance* aSoundInstance = mSoundManager->GetSoundInstance(theSoundNum);
	if (aSoundInstance != NULL)
	{
		aSoundInstance->Play(false, true);
	}
}


void SexyAppBase::PlaySample(int theSoundNum, int thePan)
{
	if (!mSoundManager)
		return;

	SoundInstance* aSoundInstance = mSoundManager->GetSoundInstance(theSoundNum);
	if (aSoundInstance != NULL)
	{
		aSoundInstance->SetPan(thePan);
		aSoundInstance->Play(false, true);
	}
}

bool SexyAppBase::IsMuted()
{
	return mMuteCount > 0;
}

void SexyAppBase::Mute(bool autoMute)
{	
	mMuteCount++;
	if (autoMute)
		mAutoMuteCount++;

	SetMusicVolume(mMusicVolume);
	SetSfxVolume(mSfxVolume);
}

void SexyAppBase::Unmute(bool autoMute)
{	
	if (mMuteCount > 0)
	{
		mMuteCount--;
		if (autoMute)
			mAutoMuteCount--;
	}

	SetMusicVolume(mMusicVolume);
	SetSfxVolume(mSfxVolume);
}


double SexyAppBase::GetMusicVolume()
{
	return mMusicVolume;
}

void SexyAppBase::SetMusicVolume(double theVolume)
{
	mMusicVolume = theVolume;

	if (mMusicInterface != NULL)
		mMusicInterface->SetVolume((mMuteCount > 0) ? 0.0 : mMusicVolume);
}

double SexyAppBase::GetSfxVolume()
{
	return mSfxVolume;
}

void SexyAppBase::SetSfxVolume(double theVolume)
{
	mSfxVolume = theVolume;

	if (mSoundManager != NULL)
		mSoundManager->SetVolume((mMuteCount > 0) ? 0.0 : mSfxVolume);
}

double SexyAppBase::GetMasterVolume()
{
	return mSoundManager->GetMasterVolume();
}

void SexyAppBase::SetMasterVolume(double theMasterVolume)
{
	mSfxVolume = theMasterVolume;
	mSoundManager->SetMasterVolume(mSfxVolume);
}

void SexyAppBase::AddMemoryImage(MemoryImage* theMemoryImage)
{
	AutoCrit anAutoCrit(mDDInterface->mCritSect);
	mMemoryImageSet.insert(theMemoryImage);
}

void SexyAppBase::RemoveMemoryImage(MemoryImage* theMemoryImage)
{
	AutoCrit anAutoCrit(mDDInterface->mCritSect);
	MemoryImageSet::iterator anItr = mMemoryImageSet.find(theMemoryImage);
	if (anItr != mMemoryImageSet.end())
		mMemoryImageSet.erase(anItr);

	Remove3DData(theMemoryImage);
}

void SexyAppBase::Remove3DData(MemoryImage* theMemoryImage)
{
	if (mDDInterface)
		mDDInterface->Remove3DData(theMemoryImage);
}


bool SexyAppBase::Is3DAccelerated()
{
	return mDDInterface->mIs3D;
}

bool SexyAppBase::Is3DAccelerationSupported()
{
	if (mDDInterface->mD3DTester)
		return mDDInterface->mD3DTester->Is3DSupported();
	else
		return false;
}

bool SexyAppBase::Is3DAccelerationRecommended()
{
	if (mDDInterface->mD3DTester)
		return mDDInterface->mD3DTester->Is3DRecommended();
	else
		return false;
}

void SexyAppBase::DemoSyncRefreshRate()
{
	mSyncRefreshRate = mDDInterface->mRefreshRate;

	if (mRecordingDemoBuffer)
	{
		WriteDemoTimingBlock();
		mDemoBuffer.WriteNumBits(0, 1);
		mDemoBuffer.WriteNumBits(DEMO_VIDEO_DATA, 5);
		mDemoBuffer.WriteBoolean(mIsWindowed);
		uchar aByte = (uchar) mSyncRefreshRate;
		mDemoBuffer.WriteByte(aByte);		
	}
}

void SexyAppBase::Set3DAcclerated(bool is3D, bool reinit)
{
	// D3D11 acceleration is mandatory; never allow it to be turned off.
	is3D = true;
	if (mDDInterface->mIs3D == is3D)
		return;

	mUserChanged3DSetting = true;
	mDDInterface->mIs3D = is3D;
	
	if (reinit)
	{
		int aResult = InitDDInterface();

		if (is3D && aResult != DDInterface::RESULT_OK)
		{
			// Legacy has no software renderer.  The old recursive call attempted
			// to turn 3D off and hid the real initialization failure; report the
			// original result instead.
			Popup(GetString("D3D11_REQUIRED",
				_S("Direct3D 11 initialization failed: ")) +
				StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
			DoExit(1);
			return;
		}
		else if (aResult != DDInterface::RESULT_OK)
		{
			Popup(GetString("FAILED_INIT_DIRECTDRAW", _S("Failed to initialize DirectDraw: ")) + StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
			DoExit(1);
		}

		ReInitImages();

		mWidgetManager->mImage = mDDInterface->GetScreenImage();
		mWidgetManager->MarkAllDirty();
	}
}

// D3D11 rendering is mandatory and always on; this only selects the present
// path.  Both scale.xml chains and their immutable D3D11 objects were created
// during startup and remain resident until the renderer device is destroyed.
// Toggling never reloads XML/HLSL and never destroys the dormant pipeline.
void SexyAppBase::ReconfigureScale(bool theUseCustomScale)
{
	if (mUseCustomScale == theUseCustomScale)
	{
		WriteToRegistry();
		return;
	}

	// Enabling a missing startup-compiled pipeline is a configuration error,
	// not a reason to compile again at an arbitrary point in the game.
	if (theUseCustomScale && mScaleEffects.empty())
		RaiseException(0xE000D316, EXCEPTION_NONCONTINUABLE, 0, nullptr);

	mUseCustomScale = theUseCustomScale;
	if (theUseCustomScale)
	{
		UpdateWindowScaleFromPipeline();
		mWindowScale = std::max(1, mScaleConfigWindow);
	}
	else
	{
		mWindowScale = 1;
	}

	if (!mShutdown && mDDInterface != nullptr && mHWnd != NULL)
	{
		// Reuse the screen-mode transaction even when windowed/fullscreen itself
		// did not change.  It leaves the old frame visible, prewarms the newly
		// selected path, resizes the swapchain/HWND, and reconnects presentation.
		SwitchScreenMode(mIsWindowed, true, true);
	}

	// Persist the checkbox state immediately (settings.xml next to the exe).
	WriteToRegistry();
}

static std::string TrimScaleText(const SexyString& theText)
{
	std::string aText = SexyStringToStringFast(theText);
	size_t aStart = aText.find_first_not_of(" \t\r\n");
	if (aStart == std::string::npos)
		return "";
	size_t anEnd = aText.find_last_not_of(" \t\r\n");
	return aText.substr(aStart, anEnd - aStart + 1);
}

static std::string LowerScaleText(const std::string& theText)
{
	std::string aResult = theText;
	for (size_t i = 0; i < aResult.size(); i++)
		aResult[i] = (char)tolower((unsigned char)aResult[i]);
	return aResult;
}

static std::string NormalizeScaleEffectPath(std::string thePath)
{
	if (thePath.empty())
		return thePath;
	for (char& aChar : thePath)
		if (aChar == '\\')
			aChar = '/';
	if (LowerScaleText(thePath).compare(0, 8, "effects/") == 0)
		thePath.erase(0, 8);
	const std::string aLowerPath = LowerScaleText(thePath);
	if (aLowerPath.size() <= 5 || aLowerPath.compare(aLowerPath.size() - 5, 5, ".hlsl") != 0)
		thePath += ".hlsl";
	return thePath;
}

static bool ParseScaleEffectParams(
	const StringStringMap& theTextParams,
	ScaleEffectParams& outParams)
{
	outParams.clear();
	for (StringStringMap::const_iterator anItr = theTextParams.begin();
		anItr != theTextParams.end(); ++anItr)
	{
		const char* aBegin = anItr->second.c_str();
		char* anEnd = nullptr;
		errno = 0;
		const float aValue = std::strtof(aBegin, &anEnd);
		while (anEnd != nullptr && *anEnd != '\0' && isspace((unsigned char)*anEnd))
			++anEnd;
		if (anEnd == aBegin || anEnd == nullptr || *anEnd != '\0' ||
			errno == ERANGE || !std::isfinite(aValue))
			return false;
		outParams[LowerScaleText(anItr->first)] = aValue;
	}
	return true;
}

// Read scale.xml (same directory as the executable / working directory).
// Two formats are accepted:
//
//  <pvzScale>
//    <window>
//      <effect>Anime4K/Anime4K_Upscale_L.hlsl</effect>
//      <effect>SSimDownscaler.hlsl<overSharp>1</overSharp></effect>
//    </window>
//    <fullScreen>
//      <output width="0" height="0" />
//      <effect>...</effect>
//    </fullScreen>
//  </pvzScale>
//
// and the older simple format (<Scale><Window multiplier=...>
// <Fullscreen><Output width=... height=.../></Fullscreen></Scale>), which
// falls back to multiplier/output-size scaling when no pipeline is present.
void SexyAppBase::LoadScaleConfig()
{
	mScaleConfigWindow = 1;
	mScaleConfigFullscreenWidth = 0;
	mScaleConfigFullscreenHeight = 0;
	mScaleWindowConfig.mEffects.clear();
	mScaleWindowConfig.mOutputWidth = 0;
	mScaleWindowConfig.mOutputHeight = 0;
	mScaleFullscreenConfig.mEffects.clear();
	mScaleFullscreenConfig.mOutputWidth = 0;
	mScaleFullscreenConfig.mOutputHeight = 0;

	XMLParser aParser;
	aParser.OpenFile("scale.xml");
	if (aParser.HasFailed())
		return; // no scale.xml -> use defaults

	XMLElement aElement;
	SexyString aModeSection;
	SexyString aEffectSection;
	SexyString aParamName;
	ScalePipelineConfig* aCurrentPipeline = NULL;
	ScaleEffectConfig* aCurrentEffect = NULL;

	while (aParser.NextElement(&aElement))
	{
		if (aElement.mType == XMLElement::TYPE_START)
		{
			// This parser reports the PARENT path in mSection for START
			// elements (mValue is the tag name), and the full path for END
			// and text elements.
			SexyString aSection = aElement.mSection;
			SexyString aName = StringToSexyStringFast(
				LowerScaleText(SexyStringToStringFast(aElement.mValue)));

			if (aSection == _S("pvzScale") || aSection == _S("Scale"))
			{
				if (aName == _S("window"))
				{
					aModeSection = aSection + _S("/") + aElement.mValue;
					aCurrentPipeline = &mScaleWindowConfig;
				}
				else if (aName == _S("fullscreen"))
				{
					aModeSection = aSection + _S("/") + aElement.mValue;
					aCurrentPipeline = &mScaleFullscreenConfig;
				}
			}
			else if (aCurrentPipeline != NULL && aSection == aModeSection)
			{
				if (aName == _S("effect"))
				{
					aEffectSection = aSection + _S("/") + aElement.mValue;
					aCurrentPipeline->mEffects.push_back(ScaleEffectConfig());
					aCurrentEffect = &aCurrentPipeline->mEffects.back();
				}
			}
			else if (aCurrentEffect != NULL && aSection == aEffectSection)
			{
				// <effect><paramName>value</paramName></effect>
				aParamName = aElement.mValue;
			}
		}
		else if (aElement.mType == XMLElement::TYPE_ELEMENT)
		{
			std::string aText = TrimScaleText(aElement.mValue);
			if (aText.empty() || aCurrentEffect == NULL)
				continue;

			if (!aParamName.empty())
			{
				std::string aKey = LowerScaleText(SexyStringToStringFast(aParamName));
				if (aKey == "mode")
					aCurrentEffect->mScalingType = LowerScaleText(aText);
				else if (aKey == "scalex")
					aCurrentEffect->mScaleX = (float)atof(aText.c_str());
				else if (aKey == "scaley")
					aCurrentEffect->mScaleY = (float)atof(aText.c_str());
				else
					aCurrentEffect->mParams[aKey] = aText;
				aParamName.clear();
			}
			else if (aElement.mSection == aEffectSection)
				aCurrentEffect->mPath = aText;
		}
		else if (aElement.mType == XMLElement::TYPE_END)
		{
			if (aCurrentEffect != NULL && aElement.mSection == aEffectSection)
			{
				aCurrentEffect = NULL;
				aEffectSection.clear();
				aParamName.clear();
			}
			else if (aCurrentPipeline != NULL && aElement.mSection == aModeSection)
			{
				aCurrentPipeline = NULL;
				aModeSection.clear();
			}
		}
	}
}

bool SexyAppBase::CollectScalePipelineRefs(std::vector<ScaleEffectCompileRequest>& outRefs)
{
	outRefs.clear();
	auto AddRefs = [&outRefs](const ScalePipelineConfig& aCfg) {
		for (const ScaleEffectConfig& aEffect : aCfg.mEffects)
		{
			std::string aPath = NormalizeScaleEffectPath(aEffect.mPath);
			if (aPath.empty())
				return false;
			ScaleEffectParams aParams;
			if (!ParseScaleEffectParams(aEffect.mParams, aParams))
				return false;

			bool aDuplicate = false;
			for (const ScaleEffectCompileRequest& anExisting : outRefs)
			{
				if (LowerScaleText(anExisting.mPath) == LowerScaleText(aPath) &&
					anExisting.mParams == aParams)
				{
					aDuplicate = true;
					break;
				}
			}
			if (!aDuplicate)
			{
				ScaleEffectCompileRequest aRequest;
				aRequest.mPath = aPath;
				aRequest.mParams = std::move(aParams);
				outRefs.push_back(std::move(aRequest));
			}
		}
		return true;
	};
	return AddRefs(mScaleWindowConfig) && AddRefs(mScaleFullscreenConfig) && !outRefs.empty();
}

bool SexyAppBase::CompileScaleEffectList(
	const std::vector<ScaleEffectCompileRequest>& theRefs,
	std::vector<ScaleEffectDesc>& outEffects)
{
	outEffects.clear();
	ScaleEffectCompiler aCompiler;
	bool aAllOk = true;

	{
		FILE* aLog = fopen(GetLogFilePath("effects-compile.log").c_str(), "w");
		if (aLog != nullptr)
			fprintf(aLog, "compile referenced pipelines only (%d effects)\n", (int)theRefs.size());
		for (const ScaleEffectCompileRequest& aRequest : theRefs)
		{
			const std::string& aPath = aRequest.mPath;
			std::string aOpenPath = "effects/" + aPath;
			ScaleEffectDesc aDesc;
			const bool aCompiled = aCompiler.CompileEffect(aOpenPath, aRequest.mParams, aDesc);
			if (aCompiled)
			{
				outEffects.push_back(std::move(aDesc));
				if (aLog != nullptr)
				{
					ScaleEffectDesc& aRef = outEffects.back();
					fprintf(aLog, "OK %s passes=%d inline-params=%d", aRef.mName.c_str(), (int)aRef.mPasses.size(), (int)aRef.mInlineParams.size());
					for (const auto& aParam : aRef.mInlineParams)
						fprintf(aLog, " %s=%.9g", aParam.first.c_str(), (double)aParam.second);
					fprintf(aLog, "\n");
				}
			}
			else
			{
				// CompileEffect failed for this reference. Keep scanning so the
				// log can list every bad effect, but reject the whole pipeline.
				aAllOk = false;
				if (aLog != nullptr)
					fprintf(aLog, "FAIL %s: %s\n", aPath.c_str(), aDesc.mError.c_str());
			}
		}
		if (aLog != nullptr)
			fclose(aLog);
	}
	return aAllOk;
}

void SexyAppBase::CompileScaleEffects()
{
	mScaleEffects.clear();
	std::vector<ScaleEffectCompileRequest> aRefs;
	std::vector<ScaleEffectDesc> aCompiledEffects;
	if (!CollectScalePipelineRefs(aRefs))
	{
		MessageBoxA(NULL, "custom scale is enabled but scale.xml contains no effect", "Scale compile error", MB_OK | MB_ICONERROR);
		DoExit(1);
		return;
	}
	if (!CompileScaleEffectList(aRefs, aCompiledEffects))
	{
		MessageBoxA(NULL, "custom scale effect compilation failed; see log/effects-compile.log", "Scale compile error", MB_OK | MB_ICONERROR);
		DoExit(1);
		return;
	}
	mScaleEffects = std::move(aCompiledEffects);

	// Explicit off-screen diagnostic. PVZ_SCALE_SELFTEST_ONLY also exits here,
	// before MakeWindow, so automated verification never flashes a game window.
	const bool aSelfTestOnly = getenv("PVZ_SCALE_SELFTEST_ONLY") != nullptr;
	if (getenv("PVZ_SCALE_SELFTEST") == nullptr && !aSelfTestOnly)
		return;

	ScaleEffectRuntime aRuntime;
	auto RunModeSelfTest = [&](bool theWindowed, const char* theBmp, const char* theLog)
	{
		std::vector<ScaleEffectDesc*> aEffects;
		std::vector<ScaleEffectScaling> aScalings;
		if (!BuildScalePipelineForMode(theWindowed, aEffects, aScalings))
			return false;
		const int aTargetW = theWindowed ? 1600 : GetSystemMetrics(SM_CXSCREEN);
		const int aTargetH = theWindowed ? 1200 : GetSystemMetrics(SM_CYSCREEN);
		const bool aOk = aRuntime.RunSelfTest(
			aEffects, theWindowed ? 0u : 1u, aTargetW, aTargetH, theBmp, aScalings);
		FILE* aLog = fopen(GetLogFilePath(theLog).c_str(), "w");
		if (aLog != nullptr)
		{
			fprintf(aLog, "%s effects=%d target=%dx%d\n",
				aOk ? "OK" : "FAIL", (int)aEffects.size(), aTargetW, aTargetH);
			fclose(aLog);
		}
		return aOk;
	};

	const bool aWindowOk = RunModeSelfTest(
		true, "scale-selftest-window.bmp", "scale-selftest-window.log");
	const bool aFullscreenOk = RunModeSelfTest(
		false, "scale-selftest-fullscreen.bmp", "scale-selftest-fullscreen.log");
	if (aSelfTestOnly)
		std::exit(aWindowOk && aFullscreenOk ? 0 : 1);
}

void SexyAppBase::ApplyScaleWindow()
{
	if (!mUseCustomScale)
		return;

	UpdateWindowScaleFromPipeline();
	int aScale = std::max(1, mScaleConfigWindow);
	mWindowScale = aScale;
	if (mDDInterface != nullptr)
	{
		if (mDDInterface->mD3DInterface != nullptr && mDDInterface->mD3DInterface->mD3D11 != nullptr)
		{
			D3D11Renderer* aRender = mDDInterface->mD3DInterface->mD3D11;
			aRender->SetScalePresent(D3D11Renderer::ScalePresentFn());
			mDDInterface->mD3DInterface->Flush();
			aRender->PrepareForResize();
		}
		mDDInterface->mIs3D = true;
		int aResult = mDDInterface->ApplyScreenMode(mHWnd, mIsWindowed);
		if (aResult == DDInterface::RESULT_OK)
		{
			if (!ResizeAppWindowForMode(mIsWindowed))
				RaiseException(0xE000D315, EXCEPTION_NONCONTINUABLE, 0, nullptr);
			mWidgetManager->mImage = mDDInterface->GetScreenImage();
			mWidgetManager->Resize(mScreenBounds, mDDInterface->mVisibleGameRect);
			mWidgetManager->MarkAllDirty();
		}
		else
		{
			Popup(GetString("D3D11_MODE_SWITCH_FAILED",
				_S("Direct3D 11 scale-mode switch failed: ")) +
				StringToSexyString(DDInterface::ResultToString(aResult) + " " + mDDInterface->mErrorString));
			DoExit(1);
		}
	}
	InstallD3D11ScalePresent();
}

bool SexyAppBase::IsScalePresentActive() const
{
	if (getenv("PVZ_SCALE_DISABLE") != nullptr)
		return false;
	if (mScaleEffects.empty() || !mUseCustomScale)
		return false;
	if (mIsWindowed)
		return !mScaleWindowConfig.mEffects.empty();
	return !mScaleFullscreenConfig.mEffects.empty();
}

bool SexyAppBase::BuildScalePipelineForMode(
	bool theWindowed,
	std::vector<ScaleEffectDesc*>& outEffects,
	std::vector<ScaleEffectScaling>& outScalings)
{
	outEffects.clear();
	outScalings.clear();

	const ScalePipelineConfig& aCfg = theWindowed ? mScaleWindowConfig : mScaleFullscreenConfig;
	for (const ScaleEffectConfig& aCfgEffect : aCfg.mEffects)
	{
		std::string aPath = NormalizeScaleEffectPath(aCfgEffect.mPath);
		if (aPath.size() > 5)
			aPath.erase(aPath.size() - 5);

		ScaleEffectParams anOverrides;
		if (!ParseScaleEffectParams(aCfgEffect.mParams, anOverrides))
			return false;

		bool aMatched = false;
		for (ScaleEffectDesc& aEffect : mScaleEffects)
		{
			if (LowerScaleText(aEffect.mName) != LowerScaleText(aPath) ||
				!aEffect.mInlineParamsEnabled)
				continue;

			ScaleEffectParams aResolved;
			std::string anError;
			if (!ScaleEffectCompiler::ResolveInlineParams(
					aEffect, anOverrides, aResolved, anError))
				return false;
			if (aResolved != aEffect.mInlineParams)
				continue;

			aMatched = true;
			outEffects.push_back(&aEffect);
			break;
		}
		// A partially built chain is not a usable substitute for the XML chain.
		if (!aMatched)
			return false;

		ScaleEffectScaling aScaling;
		std::string aMode = LowerScaleText(aCfgEffect.mScalingType);
		if (aMode.empty() || aMode == "normal")
			aScaling.mScalingType = SCALE_SCALING_NORMAL;
		else if (aMode == "fit")
			aScaling.mScalingType = SCALE_SCALING_FIT;
		else if (aMode == "absolute")
			aScaling.mScalingType = SCALE_SCALING_ABSOLUTE;
		else if (aMode == "fill")
			aScaling.mScalingType = SCALE_SCALING_FILL;
		else
			return false;
		if (!std::isfinite(aCfgEffect.mScaleX) || !std::isfinite(aCfgEffect.mScaleY) ||
			aCfgEffect.mScaleX <= 0.0f || aCfgEffect.mScaleY <= 0.0f)
			return false;
		aScaling.mScaleX = aCfgEffect.mScaleX;
		aScaling.mScaleY = aCfgEffect.mScaleY;
		outScalings.push_back(aScaling);
	}
	return !outEffects.empty() &&
		outEffects.size() == aCfg.mEffects.size() &&
		outScalings.size() == outEffects.size();
}


void SexyAppBase::UpdateWindowScaleFromPipeline()
{
	std::vector<ScaleEffectDesc*> aEffects;
	std::vector<ScaleEffectScaling> aScalings;
	if (!BuildScalePipelineForMode(true, aEffects, aScalings))
		return;

	int aW = 800;
	int aH = 600;
	for (size_t i = 0; i < aEffects.size(); i++)
	{
		const ScaleEffectDesc& aEffect = *aEffects[i];
		const ScaleEffectTextureDesc* aOut = NULL;
		for (const ScaleEffectTextureDesc& aTex : aEffect.mTextures)
			if (aTex.mName == "OUTPUT")
				aOut = &aTex;
		int aOutW = aW;
		int aOutH = aH;
		if (aOut != NULL && !aOut->mWidthExpr.empty())
		{
			bool aOk = false;
			aOutW = ScaleEffectRuntime::EvalSizeExpr(aOut->mWidthExpr, aW, aH, aW, aH, aOk);
			aOutH = ScaleEffectRuntime::EvalSizeExpr(aOut->mHeightExpr, aW, aH, aW, aH, aOk);
		}
		aW = aOutW;
		aH = aOutH;
	}
	if (aW >= 800 && aW % 800 == 0)
		mScaleConfigWindow = aW / 800;
}

void SexyAppBase::CleanupScalePresent()
{
	if (mScaleSwapChain != NULL)
	{
		mScaleSwapChain->Release();
		mScaleSwapChain = NULL;
	}
	if (mScaleSharedTexture != NULL)
	{
		mScaleSharedTexture->Release();
		mScaleSharedTexture = NULL;
	}
	mScaleSharedHandle = NULL;
	mScaleSwapWidth = 0;
	mScaleSwapHeight = 0;
}

SharedImageRef SexyAppBase::SetSharedImage(const std::string& theFileName, const std::string& theVariant, DDImage* theImage, bool* isNew)
{
	std::string anUpperFileName = StringToUpper(theFileName);
	std::string anUpperVariant = StringToUpper(theVariant);

	std::pair<SharedImageMap::iterator, bool> aResultPair;
	SharedImageRef aSharedImageRef;
	
	{
		AutoCrit anAutoCrit(mDDInterface->mCritSect);
		aResultPair = mSharedImageMap.insert(SharedImageMap::value_type(SharedImageMap::key_type(anUpperFileName, anUpperVariant), SharedImage()));
		aSharedImageRef = &aResultPair.first->second;
	}

	if (isNew != NULL)
		*isNew = aResultPair.second;

	if (aResultPair.second)
	{
		aSharedImageRef.mSharedImage->mImage = theImage;
	}

	return aSharedImageRef;
}

SharedImageRef SexyAppBase::GetSharedImage(const std::string& theFileName, const std::string& theVariant, bool* isNew)
{	
	std::string anUpperFileName = StringToUpper(theFileName);
	std::string anUpperVariant = StringToUpper(theVariant);

	std::pair<SharedImageMap::iterator, bool> aResultPair;
	SharedImageRef aSharedImageRef;

	{
		AutoCrit anAutoCrit(mDDInterface->mCritSect);	
		aResultPair = mSharedImageMap.insert(SharedImageMap::value_type(SharedImageMap::key_type(anUpperFileName, anUpperVariant), SharedImage()));
		aSharedImageRef = &aResultPair.first->second;
	}

	if (isNew != NULL)
		*isNew = aResultPair.second;

	if (aResultPair.second)
	{
		// Pass in a '!' as the first char of the file name to create a new image
		LegacyRuntimeTraceInstant(
			"load-image",
			mUpdateCount,
			"file=%s variant=%s",
			theFileName.c_str(),
			theVariant.c_str());
		LegacyRuntimeTraceScope aLoadImageScope("load-image", mUpdateCount);
		if ((theFileName.length() > 0) && (theFileName[0] == '!'))
			aSharedImageRef.mSharedImage->mImage = new DDImage(mDDInterface);
		else
			aSharedImageRef.mSharedImage->mImage = GetImage(theFileName,false);
	}

	return aSharedImageRef;
}

void SexyAppBase::CleanSharedImages()
{
	AutoCrit anAutoCrit(mDDInterface->mCritSect);	

	if (mCleanupSharedImages)
	{
		// Delete shared images with reference counts of 0
		// This doesn't occur in ~SharedImageRef because sometimes we can not only access the image
		//  through the SharedImageRef returned by GetSharedImage, but also by calling GetSharedImage
		//  again with the same params -- so we can have instances where we do the 'final' deref on
		//  an image but immediately re-request it via GetSharedImage
		SharedImageMap::iterator aSharedImageItr = mSharedImageMap.begin();
		while (aSharedImageItr != mSharedImageMap.end())
		{
			SharedImage* aSharedImage = &aSharedImageItr->second;
			if (aSharedImage->mRefCount == 0)
			{
				delete aSharedImage->mImage;
				mSharedImageMap.erase(aSharedImageItr++);
			}
			else
				++aSharedImageItr;
		}

		mCleanupSharedImages = false;
	}
}
