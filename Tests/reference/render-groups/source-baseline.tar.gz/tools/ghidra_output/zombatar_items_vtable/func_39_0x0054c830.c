
void __fastcall FUN_0054c830(int param_1)

{
  *(undefined1 *)(param_1 + 0x67) = 1;
  return;
}

