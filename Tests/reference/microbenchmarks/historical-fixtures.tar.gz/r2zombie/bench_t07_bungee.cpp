// bench_t07 — kBungeePhaseCases 7 -> UpdateZombieBungee（蹦极期每帧）
#include "zb_common.h"

// ==================== FormA：403c1968^ 原函数（逐字） ====================
__declspec(noinline) void Zombie::UpdateZombieBungee_A()
{
    if (IsDeadOrDying() || IsImmobilizied())
        return;

    if (mZombiePhase == ZombiePhase::PHASE_BUNGEE_DIVING || mZombiePhase == ZombiePhase::PHASE_BUNGEE_DIVING_SCREAMING)
    {
        float aOldAltitude = mAltitude;
        mAltitude -= 8.0f;
        if (mAltitude <= BUNGEE_ZOMBIE_HEIGHT - 404.0f && aOldAltitude > BUNGEE_ZOMBIE_HEIGHT - 404.0f && mRelatedZombieID == ZombieID::ZOMBIEID_NULL)
        {
            mApp->PlayFoley(FoleyType::FOLEY_GRASSSTEP);  // 靶子扎地的音效
        }

        BungeeLanding();
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BUNGEE_AT_BOTTOM)
    {
        if (mPhaseCounter <= 0)
        {
            BungeeStealTarget();
            mZombiePhase = ZombiePhase::PHASE_BUNGEE_GRABBING;
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BUNGEE_GRABBING)
    {
        Reanimation* aBodyReanim = mApp->ReanimationGet(mBodyReanimID);
        if (aBodyReanim->mLoopCount > 0)
        {
            BungeeLiftTarget();
            mZombiePhase = ZombiePhase::PHASE_BUNGEE_RISING;
        }
    }
    // PHASE_BUNGEE_HIT_OUCHY 分支已删（不可达：蹦极相位机仅走 DIVING→RISING→AT_BOTTOM→GRABBING）
    else if (mZombiePhase == ZombiePhase::PHASE_BUNGEE_RISING)
    {
        mAltitude += 8.0f;
        if (mAltitude >= 600.0f)
        {
            DieNoLoot();
        }
    }
    else if (mZombiePhase == ZombiePhase::PHASE_BUNGEE_CUTSCENE)
    {
        mAltitude = TodAnimateCurve(200, 0, mPhaseCounter, 40, 0, Curves::SinWave);
        if (mPhaseCounter <= 0)
        {
            mPhaseCounter = 200;
        }
    }

    mX = (int)mPosX;
    mY = (int)mPosY;
}

// ==================== FormB：HEAD 逐字（函数内 static constexpr 表——照抄含 static） ====================
__declspec(noinline) void Zombie::UpdateZombieBungee_B()
{
    if (IsDeadOrDying() || IsImmobilizied())
        return;

    // C 形态 -> 匿名 lambda 函数指针表 kBungeePhaseCases（仿 kBossPhaseCases
    // 范式）：行序 = ZombiePhase 枚举序 PHASE_BUNGEE_DIVING..PHASE_BUNGEE_CUTSCENE
    // （7 相位连续）；DIVING/DIVING_SCREAMING 共体（constexpr 指针变量复用同一
    // lambda）；HIT_OUCHY 槽 nullptr（不可达相位 + 原 1073 无此 case）；
    // 表外相位/越界 = 原无命中（无操作）。
    using BungeePhaseFn = void (*)(Zombie&);
    static constexpr BungeePhaseFn kBungeeDiving = [](Zombie& z)
    {
        float aOldAltitude = z.mAltitude;
        z.mAltitude -= 8.0f;
        if (z.mAltitude <= BUNGEE_ZOMBIE_HEIGHT - 404.0f && aOldAltitude > BUNGEE_ZOMBIE_HEIGHT - 404.0f && z.mRelatedZombieID == ZombieID::ZOMBIEID_NULL)
        {
            z.mApp->PlayFoley(FoleyType::FOLEY_GRASSSTEP);  // 靶子扎地的音效
        }

        z.BungeeLanding();
    };
    static constexpr BungeePhaseFn kBungeePhaseCases[(int)ZombiePhase::PHASE_BUNGEE_CUTSCENE - (int)ZombiePhase::PHASE_BUNGEE_DIVING + 1] = {
        kBungeeDiving,  // PHASE_BUNGEE_DIVING（共体）
        kBungeeDiving,  // PHASE_BUNGEE_DIVING_SCREAMING（共体）
        // 原 else-if PHASE_BUNGEE_AT_BOTTOM
        [](Zombie& z)
        {
            if (z.mPhaseCounter <= 0)
            {
                z.BungeeStealTarget();
                z.mZombiePhase = ZombiePhase::PHASE_BUNGEE_GRABBING;
            }
        },
        // 原 else-if PHASE_BUNGEE_GRABBING
        [](Zombie& z)
        {
            Reanimation* aBodyReanim = z.mApp->ReanimationGet(z.mBodyReanimID);
            if (aBodyReanim->mLoopCount > 0)
            {
                z.BungeeLiftTarget();
                z.mZombiePhase = ZombiePhase::PHASE_BUNGEE_RISING;
            }
        },
        // 原 else-if PHASE_BUNGEE_RISING
        [](Zombie& z)
        {
            z.mAltitude += 8.0f;
            if (z.mAltitude >= 600.0f)
            {
                z.DieNoLoot();
            }
        },
        nullptr,  // PHASE_BUNGEE_HIT_OUCHY（不可达：蹦极相位机不走此值；原 HIT_OUCHY 分支已删）
        // 原 else-if PHASE_BUNGEE_CUTSCENE
        [](Zombie& z)
        {
            z.mAltitude = TodAnimateCurve(200, 0, z.mPhaseCounter, 40, 0, Curves::SinWave);
            if (z.mPhaseCounter <= 0)
            {
                z.mPhaseCounter = 200;
            }
        },
    };
    static_assert(sizeof(kBungeePhaseCases) / sizeof(kBungeePhaseCases[0]) ==
        (int)ZombiePhase::PHASE_BUNGEE_CUTSCENE - (int)ZombiePhase::PHASE_BUNGEE_DIVING + 1,
        "kBungeePhaseCases 槽位须与 ZombiePhase BUNGEE 段同步");

    const unsigned aPhaseIndex = static_cast<unsigned>(mZombiePhase) - static_cast<unsigned>(ZombiePhase::PHASE_BUNGEE_DIVING);
    if (aPhaseIndex < sizeof(kBungeePhaseCases) / sizeof(kBungeePhaseCases[0]) &&
        kBungeePhaseCases[aPhaseIndex] != nullptr)
    {
        kBungeePhaseCases[aPhaseIndex](*this);
    }

    mX = (int)mPosX;
    mY = (int)mPosY;
}

static Zombie g_z;
static void ResetBungee(const ZBInput& in)
{
    g_z.ZBClearResidue();
    g_z.mApp = &g_zb_app;
    g_z.mBoard = &g_zb_board;
    // 段前 1 值 .. 段后 1 值（含 HIT_OUCHY 空槽 + 越界无操作）
    g_z.mZombiePhase = (ZombiePhase)((int)ZombiePhase::PHASE_BUNGEE_DIVING + (int)(in.a % 9) - 1);
    g_z.mDead = (in.a % 13) == 0;
    g_z.mIceTrapCounter = (int)(in.b % 3) - 1;
    g_z.mButteredCounter = (int)(in.c % 3) - 1;
    g_z.mAltitude = 100.0f + (float)(in.b % 600);
    g_z.mPhaseCounter = (int)(in.c % 260) - 10;
    g_z.mPosX = (float)(in.b % 780);
    g_z.mPosY = (float)(in.c % 600);
    g_z.mRelatedZombieID = (in.d & 1) ? (ZombieID)0 : (ZombieID)3;
    g_z.mBodyReanimID = (ReanimationID)(1 + in.a % 2);
    g_zb_reanimA.mLoopCount = (int)(in.a % 3);
    g_zb_reanimB.mLoopCount = (int)(in.b % 3);
}

#ifndef ZB_DBG
int main()
{
    auto passA = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetBungee(g_zb_inputs[i]);
            g_z.UpdateZombieBungee_A();
            g_z.HashFold(ck);
        }
    };
    auto passB = [&](uint64_t& ck)
    {
        for (uint32_t i = 0; i < ZB_N; i++)
        {
            ResetBungee(g_zb_inputs[i]);
            g_z.UpdateZombieBungee_B();
            g_z.HashFold(ck);
        }
    };
    return ZBenchMain("t07_BungeePhase", passA, passB);
}
#endif
