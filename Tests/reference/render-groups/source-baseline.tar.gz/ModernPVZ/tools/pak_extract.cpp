#include "pvz/assets/pak_archive.hpp"

#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>

int main(const int argc, const char* const argv[])
{
    if (argc != 4) {
        std::cerr << "usage: pvz_pak_extract <main.pak> <entry-path> <output-file>\n";
        return 2;
    }

    try {
        const auto archive = pvz::assets::PakArchive::open(argv[1]);
        const auto entry = archive.find(argv[2]);
        if (!entry) {
            std::cerr << "pvz_pak_extract: entry not found: " << argv[2] << '\n';
            return 1;
        }

        const auto bytes = archive.read(entry->get());
        const std::filesystem::path output_path{argv[3]};
        if (output_path.has_parent_path())
            std::filesystem::create_directories(output_path.parent_path());

        std::ofstream output{output_path, std::ios::binary | std::ios::trunc};
        if (!output)
            throw std::runtime_error("unable to create output file");
        output.write(
            reinterpret_cast<const char*>(bytes.data()),
            static_cast<std::streamsize>(bytes.size()));
        if (!output)
            throw std::runtime_error("unable to write output file");

        std::cout << "extracted " << bytes.size() << " bytes to " << output_path << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "pvz_pak_extract: " << error.what() << '\n';
        return 1;
    }
}
