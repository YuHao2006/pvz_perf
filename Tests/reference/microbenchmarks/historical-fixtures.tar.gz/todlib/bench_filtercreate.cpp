// bench_filtercreate.cpp — 目标14：FilterEffectCreateImage
// FormA = ac447d19^ 改造前（3 实 case + NONE/NUM 空 case 的 switch）
// FormB = HEAD 终态（kFilterCreateCases 3 槽 lambda 表 + 越界守卫）
// 输入：2M 均匀分布 FilterEffect(0..2)，固定种子，两形态消费同一数组。
// FilterEffectDo* 为游戏函数 → 同签名空桩（编号入 checksum）；像素循环不进桩。
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <random>
#include <memory>
#include <cstring>

// ---------------- harness ----------------
static uint64_t g_cs = 0;
static inline void CsMix(uint64_t v) { g_cs = g_cs * 0x9E3779B97F4A7C15ull + v; }
static uint64_t QpcFreq() { static uint64_t f = 0; if (!f) { LARGE_INTEGER li; QueryPerformanceFrequency(&li); f = (uint64_t)li.QuadPart; } return f; }
static uint64_t QpcNow() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (uint64_t)c.QuadPart; }
static double QpcToNs(uint64_t ticks) { return (double)ticks * 1e9 / (double)QpcFreq(); }

// ---------------- game type stubs ----------------
enum FilterEffect
{
    FILTER_EFFECT_NONE = -1,
    FILTER_EFFECT_WASHED_OUT,
    FILTER_EFFECT_LESS_WASHED_OUT,
    FILTER_EFFECT_WHITE,
    NUM_FILTER_EFFECTS
};

namespace Sexy
{
    constexpr unsigned long MEMORYCHECK_ID = 0xDEADBEEF;
    class Image
    {
    public:
        int mWidth, mHeight, mNumCols, mNumRows;
        Image() : mWidth(0), mHeight(0), mNumCols(0), mNumRows(0) {}
    };
    class MemoryImage : public Image
    {
    public:
        unsigned long* mBits = nullptr;
        bool mHasTrans = false, mHasAlpha = false;
        int mBitsChangedCount = 0;
    };
    class Graphics
    {
    public:
        Image* mImage;
        Graphics(Image* theImage) : mImage(theImage) {}
        void DrawImage(Image* theImage, int theX, int theY) { CsMix(31); CsMix((uint64_t)theImage->mWidth * 97 + (uint64_t)theX * 7 + (uint64_t)theY); }
    };
}
using namespace Sexy;

static void FixPixelsOnAlphaEdgeForBlending(MemoryImage* theImage) { CsMix(32); CsMix((uint64_t)theImage->mWidth); }
static void FilterEffectDoWashedOut(MemoryImage* theImage) { CsMix(33); CsMix((uint64_t)theImage->mHeight); }
static void FilterEffectDoLessWashedOut(MemoryImage* theImage) { CsMix(34); CsMix((uint64_t)theImage->mHeight); }
static void FilterEffectDoWhite(MemoryImage* theImage) { CsMix(35); CsMix((uint64_t)theImage->mHeight); }

// ================= FormA：改造前（ac447d19^ 逐字） =================
__declspec(noinline) MemoryImage* FilterEffectCreateImage_A(Image* theImage, FilterEffect theFilterEffect)
{
	auto aImage = std::make_unique<MemoryImage>();
	aImage->mWidth = theImage->mWidth;
	aImage->mHeight = theImage->mHeight;
	int aNumBits = theImage->mWidth * theImage->mHeight;
	aImage->mBits = new unsigned long[aNumBits + 1];
	aImage->mHasTrans = true;
	aImage->mHasAlpha = true;
	memset(aImage->mBits, 0, aNumBits * 4);
	aImage->mBits[aNumBits] = Sexy::MEMORYCHECK_ID;

	{
		Graphics aMemoryGraphics(aImage.get());
		aMemoryGraphics.DrawImage(theImage, 0, 0);
		FixPixelsOnAlphaEdgeForBlending(aImage.get());
	}
	
	switch (theFilterEffect)
	{
	case FilterEffect::FILTER_EFFECT_WASHED_OUT:		FilterEffectDoWashedOut(aImage.get());		break;
	case FilterEffect::FILTER_EFFECT_LESS_WASHED_OUT:	FilterEffectDoLessWashedOut(aImage.get());	break;
	case FilterEffect::FILTER_EFFECT_WHITE:				FilterEffectDoWhite(aImage.get());			break;
	case FilterEffect::NUM_FILTER_EFFECTS:
	case FilterEffect::FILTER_EFFECT_NONE:
		break;
	}

	aImage->mBitsChangedCount++;
	aImage->mNumCols = theImage->mNumCols;
	aImage->mNumRows = theImage->mNumRows;
	return aImage.release();
}

// ================= FormB：当前终态（HEAD 逐字） =================
namespace
{
using FilterCreateCaseFn = void (*)(std::unique_ptr<MemoryImage>&);

constexpr FilterCreateCaseFn kFilterCreateCases[(int)FilterEffect::NUM_FILTER_EFFECTS] = {
    [](std::unique_ptr<MemoryImage>& aImage)
    {
    FilterEffectDoWashedOut(aImage.get());
    },  // 0 FILTER_EFFECT_WASHED_OUT
    [](std::unique_ptr<MemoryImage>& aImage)
    {
    FilterEffectDoLessWashedOut(aImage.get());
    },  // 1 FILTER_EFFECT_LESS_WASHED_OUT
    [](std::unique_ptr<MemoryImage>& aImage)
    {
    FilterEffectDoWhite(aImage.get());
    },  // 2 FILTER_EFFECT_WHITE
};
static_assert(sizeof(kFilterCreateCases) / sizeof(kFilterCreateCases[0]) ==
    (int)FilterEffect::NUM_FILTER_EFFECTS, "kFilterCreateCases 槽位数须与 FilterEffect 枚举同步");
}  // namespace

__declspec(noinline) MemoryImage* FilterEffectCreateImage_B(Image* theImage, FilterEffect theFilterEffect)
{
	auto aImage = std::make_unique<MemoryImage>();
	aImage->mWidth = theImage->mWidth;
	aImage->mHeight = theImage->mHeight;
	int aNumBits = theImage->mWidth * theImage->mHeight;
	aImage->mBits = new unsigned long[aNumBits + 1];
	aImage->mHasTrans = true;
	aImage->mHasAlpha = true;
	memset(aImage->mBits, 0, aNumBits * 4);
	aImage->mBits[aNumBits] = Sexy::MEMORYCHECK_ID;

	{
		Graphics aMemoryGraphics(aImage.get());
		aMemoryGraphics.DrawImage(theImage, 0, 0);
		FixPixelsOnAlphaEdgeForBlending(aImage.get());
	}
	
	const unsigned aFilterKindIndex = static_cast<unsigned>(theFilterEffect);
	if (aFilterKindIndex < static_cast<unsigned>(FilterEffect::NUM_FILTER_EFFECTS))
	{
		kFilterCreateCases[aFilterKindIndex](aImage);
	}


	aImage->mBitsChangedCount++;
	aImage->mNumCols = theImage->mNumCols;
	aImage->mNumRows = theImage->mNumRows;
	return aImage.release();
}

// ---------------- bench driver ----------------
static const int N = 2000000;
static int g_input[N];

static void ReleaseResult(MemoryImage* p)
{
    CsMix((uint64_t)p->mBitsChangedCount * 31 + (uint64_t)p->mNumCols * 7 + (uint64_t)p->mNumRows);
    delete[] p->mBits;
    delete p;
}

template <typename F>
static inline uint64_t TimedPass(F&& f)
{
    uint64_t t0 = QpcNow();
    f();
    uint64_t t1 = QpcNow();
    return t1 - t0;
}

int main()
{
    std::mt19937 rng(20261002);
    std::uniform_int_distribution<int> dist(0, (int)FilterEffect::FILTER_EFFECT_WHITE);
    for (int k = 0; k < N; k++) g_input[k] = dist(rng);

    Image src;
    src.mWidth = 4; src.mHeight = 4; src.mNumCols = 2; src.mNumRows = 2;

    // ---- checksum pass ----
    g_cs = 0;
    for (int k = 0; k < N; k++) { MemoryImage* p = FilterEffectCreateImage_A(&src, (FilterEffect)g_input[k]); ReleaseResult(p); }
    uint64_t csA = g_cs;

    g_cs = 0;
    for (int k = 0; k < N; k++) { MemoryImage* p = FilterEffectCreateImage_B(&src, (FilterEffect)g_input[k]); ReleaseResult(p); }
    uint64_t csB = g_cs;

    bool csOK = (csA == csB);

    // ---- warmup ----
    for (int k = 0; k < 10000; k++) { ReleaseResult(FilterEffectCreateImage_A(&src, (FilterEffect)g_input[k])); ReleaseResult(FilterEffectCreateImage_B(&src, (FilterEffect)g_input[k])); }

    // ---- timing：min-of-5，A/B 交错 ----
    uint64_t aMin = UINT64_MAX, bMin = UINT64_MAX;
    for (int rep = 0; rep < 5; rep++)
    {
        aMin = (std::min)(aMin, TimedPass([&] { for (int k = 0; k < N; k++) { MemoryImage* p = FilterEffectCreateImage_A(&src, (FilterEffect)g_input[k]); ReleaseResult(p); } }));
        bMin = (std::min)(bMin, TimedPass([&] { for (int k = 0; k < N; k++) { MemoryImage* p = FilterEffectCreateImage_B(&src, (FilterEffect)g_input[k]); ReleaseResult(p); } }));
    }

    double nsA = QpcToNs(aMin) / N;
    double nsB = QpcToNs(bMin) / N;
    double diff = (nsB - nsA) / nsA * 100.0;
    printf("FilterEffectCreateImage | before %.2f ns | after %.2f ns | diff %+.2f%% | checksum=%s (A=%016llx B=%016llx)\n",
        nsA, nsB, diff, csOK ? "OK" : "FAIL", (unsigned long long)csA, (unsigned long long)csB);
    return csOK ? 0 : 1;
}
