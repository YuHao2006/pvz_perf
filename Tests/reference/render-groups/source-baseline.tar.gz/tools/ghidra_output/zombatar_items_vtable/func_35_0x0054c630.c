
void __thiscall FUN_0054c630(int *param_1,int param_2,int param_3,int param_4,int param_5)

{
  if ((((param_1[0x10] != param_2) || (param_1[0x11] != param_3)) || (param_1[0x12] != param_4)) ||
     (param_1[0x13] != param_5)) {
    (**(code **)(*param_1 + 0x4c))();
    param_1[0x10] = param_2;
    param_1[0x11] = param_3;
    param_1[0x12] = param_4;
    param_1[0x13] = param_5;
    (**(code **)(*param_1 + 0x44))();
    if (param_1[8] != 0) {
      FUN_0054b6f0();
    }
  }
  return;
}

