#version 450

layout(location = 0) in vec2 logical_position;
layout(location = 1) in vec2 texture_coordinate_in;
layout(location = 2) in vec4 vertex_color_in;

layout(push_constant) uniform FrameConstants
{
    vec2 logical_extent;
} frame;

layout(location = 0) out vec2 texture_coordinate;
layout(location = 1) out vec4 vertex_color;

void main()
{
    vec2 normalized = logical_position / frame.logical_extent;
    gl_Position = vec4(normalized.x * 2.0 - 1.0, normalized.y * 2.0 - 1.0, 0.0, 1.0);
    texture_coordinate = texture_coordinate_in;
    vertex_color = vertex_color_in;
}
