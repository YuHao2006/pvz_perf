
undefined4
FUN_0054cc40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined1 param_7,undefined4 param_8,undefined4 param_9)

{
  undefined1 uVar1;
  undefined4 uVar2;
  
  uVar1 = *(undefined1 *)(param_1 + 0x4a);
  *(undefined1 *)(param_1 + 0x4a) = DAT_0071abe6;
  uVar2 = FUN_00599d50(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0xffffffff);
  *(undefined1 *)(param_1 + 0x4a) = uVar1;
  return uVar2;
}

