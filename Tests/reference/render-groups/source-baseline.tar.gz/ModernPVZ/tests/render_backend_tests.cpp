#include "pvz/render/null_backend.hpp"

#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>

namespace {

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

pvz::render::FramePacket make_valid_frame()
{
    static constexpr std::array vertices{
        pvz::render::Vertex2D{0.0F, 0.0F, 0.0F, 0.0F, 0xFFFFFFFF},
        pvz::render::Vertex2D{1.0F, 0.0F, 1.0F, 0.0F, 0xFFFFFFFF},
        pvz::render::Vertex2D{0.0F, 1.0F, 0.0F, 1.0F, 0xFFFFFFFF},
    };
    static constexpr std::array<std::uint32_t, 3> indices{0, 1, 2};
    static constexpr std::array batches{
        pvz::render::DrawBatch{{}, pvz::render::BlendMode::alpha, 0, 3, {{0.0, 0.0}, {800.0, 600.0}}},
    };

    return {
        1,
        {800.0, 600.0},
        {{0.0, 0.0}, {1600.0, 1200.0}},
        0.5,
        vertices,
        indices,
        batches,
    };
}

void test_valid_frame_is_counted()
{
    pvz::render::NullRenderBackend backend;
    backend.resize(1600, 1200);
    backend.submit(make_valid_frame());
    require(backend.submitted_frames() == 1, "valid frame must be counted");
    require(backend.submitted_batches() == 1, "valid draw batch must be counted");
}

void test_invalid_index_is_rejected()
{
    pvz::render::NullRenderBackend backend;
    backend.resize(800, 600);
    auto frame = make_valid_frame();
    static constexpr std::array<std::uint32_t, 3> invalid_indices{0, 1, 9};
    frame.indices = invalid_indices;

    bool rejected = false;
    try {
        backend.submit(frame);
    } catch (const std::out_of_range&) {
        rejected = true;
    }
    require(rejected, "index outside the vertex buffer must be rejected");
}

void test_resize_is_required()
{
    pvz::render::NullRenderBackend backend;
    bool rejected = false;
    try {
        backend.submit(make_valid_frame());
    } catch (const std::logic_error&) {
        rejected = true;
    }
    require(rejected, "frame submission before resize must be rejected");
}

void test_texture_lifetime_is_validated()
{
    pvz::render::NullRenderBackend backend;
    backend.resize(1600, 1200);

    static constexpr std::array<std::byte, 16> pixels{};
    const auto texture = backend.create_texture({2, 2, 8, pvz::render::TextureFormat::rgba8_unorm, pixels});
    auto frame = make_valid_frame();
    auto batch = frame.batches.front();
    batch.texture = texture;
    const std::array batches{batch};
    frame.batches = batches;
    backend.submit(frame);

    backend.destroy_texture(texture);
    bool rejected = false;
    try {
        backend.submit(frame);
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "destroyed texture handles must be rejected");
}

void test_texture_updates_preserve_handle_lifetime()
{
    pvz::render::NullRenderBackend backend;
    static constexpr std::array<std::byte, 16> pixels{};
    const auto texture = backend.create_texture({2, 2, 8, pvz::render::TextureFormat::rgba8_unorm, pixels});
    backend.update_texture(texture, {1, 4, 4, pvz::render::TextureFormat::rgba8_srgb, pixels});

    bool rejected = false;
    try {
        backend.update_texture({}, {1, 1, 4, pvz::render::TextureFormat::rgba8_unorm, pixels});
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "the backend-owned white texture must not be updated");
}

void test_texture_upload_shape_is_validated()
{
    pvz::render::NullRenderBackend backend;
    static constexpr std::array<std::byte, 16> pixels{};

    bool rejected = false;
    try {
        static_cast<void>(backend.create_texture({
            2,
            2,
            7,
            pvz::render::TextureFormat::rgba8_unorm,
            pixels,
        }));
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "texture row pitch must cover each RGBA8 row");
    require(
        pvz::render::pack_rgba8(0x12, 0x34, 0x56, 0x78) == 0x78563412U,
        "packed vertex colors must have a stable byte order");
}

} // namespace

int main()
{
    test_valid_frame_is_counted();
    test_invalid_index_is_rejected();
    test_resize_is_required();
    test_texture_lifetime_is_validated();
    test_texture_updates_preserve_handle_lifetime();
    test_texture_upload_shape_is_validated();
    return EXIT_SUCCESS;
}
