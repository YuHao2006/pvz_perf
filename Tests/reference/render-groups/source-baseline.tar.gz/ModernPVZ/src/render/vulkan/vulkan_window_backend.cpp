#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define VK_USE_PLATFORM_WIN32_KHR
#include <windows.h>
#include <vulkan/vulkan.h>

#include "pvz/render/vulkan/vulkan_window_backend.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace pvz::render::vulkan {
namespace {

constexpr std::uint32_t kFramesInFlight = 2;
constexpr std::uint32_t kMaxTextureCount = 4096;
constexpr std::size_t kSamplerVariantCount = 8;

void check(const VkResult result, const char* operation)
{
    if (result != VK_SUCCESS)
        throw std::runtime_error(std::string(operation) + " failed with Vulkan error " + std::to_string(result));
}

[[nodiscard]] std::vector<std::uint32_t> read_spirv(const std::filesystem::path& path)
{
    std::ifstream input{path, std::ios::binary | std::ios::ate};
    if (!input)
        throw std::runtime_error("unable to open shader: " + path.string());

    const auto byte_count = static_cast<std::streamoff>(input.tellg());
    if (byte_count <= 0 || byte_count % static_cast<std::streamoff>(sizeof(std::uint32_t)) != 0)
        throw std::runtime_error("invalid SPIR-V size: " + path.string());

    std::vector<std::uint32_t> words(static_cast<std::size_t>(byte_count) / sizeof(std::uint32_t));
    input.seekg(0);
    input.read(reinterpret_cast<char*>(words.data()), byte_count);
    if (!input)
        throw std::runtime_error("unable to read shader: " + path.string());
    return words;
}

[[nodiscard]] bool has_instance_layer(const char* name)
{
    std::uint32_t count = 0;
    check(vkEnumerateInstanceLayerProperties(&count, nullptr), "vkEnumerateInstanceLayerProperties(count)");
    std::vector<VkLayerProperties> layers(count);
    check(vkEnumerateInstanceLayerProperties(&count, layers.data()), "vkEnumerateInstanceLayerProperties");
    return std::any_of(layers.begin(), layers.end(), [name](const VkLayerProperties& layer) {
        return std::strcmp(layer.layerName, name) == 0;
    });
}

[[nodiscard]] bool has_instance_extension(const char* name)
{
    std::uint32_t count = 0;
    check(vkEnumerateInstanceExtensionProperties(nullptr, &count, nullptr),
          "vkEnumerateInstanceExtensionProperties(count)");
    std::vector<VkExtensionProperties> extensions(count);
    check(vkEnumerateInstanceExtensionProperties(nullptr, &count, extensions.data()),
          "vkEnumerateInstanceExtensionProperties");
    return std::any_of(extensions.begin(), extensions.end(), [name](const VkExtensionProperties& extension) {
        return std::strcmp(extension.extensionName, name) == 0;
    });
}

[[nodiscard]] bool has_device_extension(const VkPhysicalDevice device, const char* name)
{
    std::uint32_t count = 0;
    if (vkEnumerateDeviceExtensionProperties(device, nullptr, &count, nullptr) != VK_SUCCESS)
        return false;
    std::vector<VkExtensionProperties> extensions(count);
    if (vkEnumerateDeviceExtensionProperties(device, nullptr, &count, extensions.data()) != VK_SUCCESS)
        return false;
    return std::any_of(extensions.begin(), extensions.end(), [name](const VkExtensionProperties& extension) {
        return std::strcmp(extension.extensionName, name) == 0;
    });
}

[[nodiscard]] VkFormat texture_format(const TextureFormat format)
{
    switch (format) {
    case TextureFormat::rgba8_unorm:
        return VK_FORMAT_R8G8B8A8_UNORM;
    case TextureFormat::rgba8_srgb:
        return VK_FORMAT_R8G8B8A8_SRGB;
    }
    throw std::invalid_argument("unsupported texture format");
}

[[nodiscard]] std::size_t pipeline_index(const BlendMode mode)
{
    switch (mode) {
    case BlendMode::opaque:
        return 0;
    case BlendMode::alpha:
        return 1;
    case BlendMode::additive:
        return 2;
    }
    throw std::invalid_argument("unsupported blend mode");
}

[[nodiscard]] constexpr std::size_t sampler_index(const SamplingState sampling) noexcept
{
    return (sampling.filter == TextureFilter::linear ? 1U : 0U) |
           (sampling.address_u == TextureAddressMode::repeat ? 2U : 0U) |
           (sampling.address_v == TextureAddressMode::repeat ? 4U : 0U);
}

[[nodiscard]] std::uint64_t next_capacity(std::uint64_t required)
{
    std::uint64_t capacity = 4096;
    while (capacity < required) {
        if (capacity > std::numeric_limits<std::uint64_t>::max() / 2)
            throw std::overflow_error("GPU buffer capacity overflow");
        capacity *= 2;
    }
    return capacity;
}

} // namespace

struct VulkanWindowBackend::Implementation {
    struct Buffer {
        VkBuffer buffer{VK_NULL_HANDLE};
        VkDeviceMemory memory{VK_NULL_HANDLE};
        VkDeviceSize capacity{0};
    };

    struct Texture {
        VkImage image{VK_NULL_HANDLE};
        VkDeviceMemory memory{VK_NULL_HANDLE};
        VkImageView view{VK_NULL_HANDLE};
        std::array<VkDescriptorSet, kSamplerVariantCount> descriptor_sets{};
    };

    struct FrameResources {
        VkCommandBuffer command_buffer{VK_NULL_HANDLE};
        VkSemaphore image_available{VK_NULL_HANDLE};
        VkFence fence{VK_NULL_HANDLE};
        Buffer vertex_buffer;
        Buffer index_buffer;
    };

    VulkanWindowConfig config;
    std::vector<std::uint32_t> vertex_shader_words;
    std::vector<std::uint32_t> fragment_shader_words;
    BackendCapabilities capabilities;

    HINSTANCE module{GetModuleHandleA(nullptr)};
    HWND window{nullptr};
    bool close_requested{false};
    bool swapchain_dirty{true};

    VkInstance instance{VK_NULL_HANDLE};
    VkDebugUtilsMessengerEXT debug_messenger{VK_NULL_HANDLE};
    VkSurfaceKHR surface{VK_NULL_HANDLE};
    VkPhysicalDevice physical_device{VK_NULL_HANDLE};
    VkPhysicalDeviceProperties physical_properties{};
    VkPhysicalDeviceMemoryProperties memory_properties{};
    std::uint32_t graphics_queue_family{0};
    std::uint32_t present_queue_family{0};
    VkDevice device{VK_NULL_HANDLE};
    VkQueue graphics_queue{VK_NULL_HANDLE};
    VkQueue present_queue{VK_NULL_HANDLE};
    VkCommandPool command_pool{VK_NULL_HANDLE};

    VkDescriptorSetLayout descriptor_set_layout{VK_NULL_HANDLE};
    VkDescriptorPool descriptor_pool{VK_NULL_HANDLE};
    std::array<VkSampler, kSamplerVariantCount> samplers{};
    VkPipelineLayout pipeline_layout{VK_NULL_HANDLE};
    std::array<VkPipeline, 3> pipelines{};

    VkSwapchainKHR swapchain{VK_NULL_HANDLE};
    VkFormat swapchain_format{VK_FORMAT_UNDEFINED};
    VkExtent2D swapchain_extent{};
    std::vector<VkImage> swapchain_images;
    std::vector<VkImageView> swapchain_views;
    std::vector<VkFence> image_fences;
    std::vector<VkSemaphore> present_semaphores;
    bool swapchain_supports_transfer_source{false};

    std::array<FrameResources, kFramesInFlight> frames{};
    std::size_t current_frame{0};
    Texture white_texture;
    std::unordered_map<std::uint32_t, Texture> textures;
    std::uint32_t next_texture_handle{1};

    bool capture_requested{false};
    Buffer capture_buffer;
    std::optional<CapturedFrame> captured_frame;
    std::uint64_t presented_frame_count{0};
    std::uint64_t swapchain_recreation_count{0};
    std::atomic_uint32_t validation_errors{0};
    bool validation_enabled{false};
    bool timeline_supported{false};

    Implementation(
        VulkanWindowConfig window_config,
        const std::filesystem::path& vertex_shader,
        const std::filesystem::path& fragment_shader)
        : config(std::move(window_config)),
          vertex_shader_words(read_spirv(vertex_shader)),
          fragment_shader_words(read_spirv(fragment_shader))
    {
        if (config.pixel_width == 0 || config.pixel_height == 0)
            throw std::invalid_argument("Vulkan window dimensions must be positive");

        try {
            create_window();
            create_instance();
            create_surface();
            select_physical_device();
            create_device();
            create_command_resources();
            create_descriptor_resources();
            create_white_texture();
            if (!recreate_swapchain())
                throw std::runtime_error("unable to create a non-empty Vulkan swapchain");

            capabilities.kind = BackendKind::vulkan;
            capabilities.name = std::string("Vulkan WSI - ") + physical_properties.deviceName;
            capabilities.max_texture_dimension_2d = physical_properties.limits.maxImageDimension2D;
            capabilities.supports_timeline_synchronization = timeline_supported;
        } catch (...) {
            cleanup();
            throw;
        }
    }

    ~Implementation()
    {
        cleanup();
    }

    static LRESULT CALLBACK window_procedure(
        const HWND handle,
        const UINT message,
        const WPARAM wparam,
        const LPARAM lparam)
    {
        Implementation* implementation = reinterpret_cast<Implementation*>(
            GetWindowLongPtrA(handle, GWLP_USERDATA));
        if (message == WM_NCCREATE) {
            const auto* create = reinterpret_cast<const CREATESTRUCTA*>(lparam);
            implementation = static_cast<Implementation*>(create->lpCreateParams);
            SetWindowLongPtrA(handle, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(implementation));
        }

        if (implementation != nullptr) {
            switch (message) {
            case WM_SIZE:
                implementation->swapchain_dirty = true;
                return 0;
            case WM_CLOSE:
                implementation->close_requested = true;
                DestroyWindow(handle);
                return 0;
            case WM_DESTROY:
                implementation->window = nullptr;
                implementation->close_requested = true;
                return 0;
            default:
                break;
            }
        }
        return DefWindowProcA(handle, message, wparam, lparam);
    }

    static VKAPI_ATTR VkBool32 VKAPI_CALL debug_callback(
        const VkDebugUtilsMessageSeverityFlagBitsEXT severity,
        VkDebugUtilsMessageTypeFlagsEXT,
        const VkDebugUtilsMessengerCallbackDataEXT* callback_data,
        void* user_data)
    {
        auto* implementation = static_cast<Implementation*>(user_data);
        if ((severity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT) != 0)
            implementation->validation_errors.fetch_add(1, std::memory_order_relaxed);

        if ((severity & (VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT |
                         VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT)) != 0) {
            std::cerr << "Vulkan validation: "
                      << (callback_data != nullptr && callback_data->pMessage != nullptr
                              ? callback_data->pMessage
                              : "unknown message")
                      << '\n';
        }
        return VK_FALSE;
    }

    void create_window()
    {
        constexpr const char* class_name = "ModernPVZVulkanWindow";
        WNDCLASSEXA window_class{};
        window_class.cbSize = sizeof(window_class);
        window_class.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
        window_class.lpfnWndProc = window_procedure;
        window_class.hInstance = module;
        window_class.hCursor = LoadCursorA(nullptr, IDC_ARROW);
        window_class.lpszClassName = class_name;
        if (RegisterClassExA(&window_class) == 0 && GetLastError() != ERROR_CLASS_ALREADY_EXISTS)
            throw std::runtime_error("RegisterClassExA failed");

        constexpr DWORD style = WS_OVERLAPPEDWINDOW;
        RECT outer{0, 0, static_cast<LONG>(config.pixel_width), static_cast<LONG>(config.pixel_height)};
        if (!AdjustWindowRectEx(&outer, style, FALSE, 0))
            throw std::runtime_error("AdjustWindowRectEx failed");

        window = CreateWindowExA(
            0,
            class_name,
            config.title.c_str(),
            style,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            outer.right - outer.left,
            outer.bottom - outer.top,
            nullptr,
            nullptr,
            module,
            this);
        if (window == nullptr)
            throw std::runtime_error("CreateWindowExA failed");

        if (config.visible) {
            ShowWindow(window, SW_SHOW);
            UpdateWindow(window);
        }
    }

    void create_instance()
    {
        if (config.enable_validation) {
            char allow_validation[2]{};
            const DWORD value_length = GetEnvironmentVariableA(
                "PVZ_ALLOW_VULKAN_VALIDATION",
                allow_validation,
                static_cast<DWORD>(sizeof(allow_validation)));
            if (value_length != 1 || allow_validation[0] != '1') {
                throw std::runtime_error(
                    "Vulkan validation is safety-gated; set PVZ_ALLOW_VULKAN_VALIDATION=1 "
                    "only on a clean validation-layer environment");
            }
        }
        const auto enumerate_instance_version = reinterpret_cast<PFN_vkEnumerateInstanceVersion>(
            vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion"));
        std::uint32_t loader_version = VK_API_VERSION_1_0;
        if (enumerate_instance_version != nullptr)
            check(enumerate_instance_version(&loader_version), "vkEnumerateInstanceVersion");
        if (loader_version < VK_API_VERSION_1_3)
            throw std::runtime_error("Vulkan 1.3 or newer is required for dynamic rendering");

        const std::uint32_t api_version = std::min(loader_version, static_cast<std::uint32_t>(VK_API_VERSION_1_4));
        VkApplicationInfo application_info{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        application_info.pApplicationName = "Modern PvZ";
        application_info.applicationVersion = VK_MAKE_API_VERSION(0, 0, 1, 0);
        application_info.pEngineName = "ModernPVZ";
        application_info.engineVersion = VK_MAKE_API_VERSION(0, 0, 1, 0);
        application_info.apiVersion = api_version;

        std::vector<const char*> extensions{
            VK_KHR_SURFACE_EXTENSION_NAME,
            VK_KHR_WIN32_SURFACE_EXTENSION_NAME,
        };
        for (const char* extension : extensions) {
            if (!has_instance_extension(extension))
                throw std::runtime_error(std::string("missing Vulkan instance extension: ") + extension);
        }

        constexpr const char* validation_layer = "VK_LAYER_KHRONOS_validation";
        if (config.enable_validation) {
            if (!has_instance_layer(validation_layer))
                throw std::runtime_error("Vulkan validation was requested but VK_LAYER_KHRONOS_validation is missing");
            if (!has_instance_extension(VK_EXT_DEBUG_UTILS_EXTENSION_NAME))
                throw std::runtime_error("Vulkan validation was requested but VK_EXT_debug_utils is missing");
            validation_enabled = true;
            extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
        }

        VkDebugUtilsMessengerCreateInfoEXT debug_info{VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT};
        debug_info.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT |
                                     VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
        debug_info.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                                 VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT |
                                 VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
        debug_info.pfnUserCallback = debug_callback;
        debug_info.pUserData = this;

        VkInstanceCreateInfo create_info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        create_info.pApplicationInfo = &application_info;
        create_info.enabledExtensionCount = static_cast<std::uint32_t>(extensions.size());
        create_info.ppEnabledExtensionNames = extensions.data();
        if (validation_enabled) {
            create_info.enabledLayerCount = 1;
            create_info.ppEnabledLayerNames = &validation_layer;
            // Create the messenger immediately after the instance. This avoids
            // passing a debug callback through vkCreateInstance while retaining
            // validation for device and frame commands.
        }
        check(vkCreateInstance(&create_info, nullptr, &instance), "vkCreateInstance");

        if (validation_enabled) {
            const auto create_debug_messenger = reinterpret_cast<PFN_vkCreateDebugUtilsMessengerEXT>(
                vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT"));
            if (create_debug_messenger == nullptr)
                throw std::runtime_error("vkCreateDebugUtilsMessengerEXT is unavailable");
            check(create_debug_messenger(instance, &debug_info, nullptr, &debug_messenger),
                  "vkCreateDebugUtilsMessengerEXT");
        }
    }

    void create_surface()
    {
        VkWin32SurfaceCreateInfoKHR create_info{VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR};
        create_info.hinstance = module;
        create_info.hwnd = window;
        check(vkCreateWin32SurfaceKHR(instance, &create_info, nullptr, &surface), "vkCreateWin32SurfaceKHR");
    }

    void select_physical_device()
    {
        std::uint32_t device_count = 0;
        check(vkEnumeratePhysicalDevices(instance, &device_count, nullptr),
              "vkEnumeratePhysicalDevices(count)");
        if (device_count == 0)
            throw std::runtime_error("no Vulkan physical device found");

        std::vector<VkPhysicalDevice> devices(device_count);
        check(vkEnumeratePhysicalDevices(instance, &device_count, devices.data()),
              "vkEnumeratePhysicalDevices");

        int best_score = std::numeric_limits<int>::min();
        for (const VkPhysicalDevice candidate : devices) {
            VkPhysicalDeviceProperties properties{};
            vkGetPhysicalDeviceProperties(candidate, &properties);
            if (properties.apiVersion < VK_API_VERSION_1_3 ||
                !has_device_extension(candidate, VK_KHR_SWAPCHAIN_EXTENSION_NAME))
                continue;

            VkPhysicalDeviceTimelineSemaphoreFeatures timeline{
                VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES};
            VkPhysicalDeviceDynamicRenderingFeatures dynamic_rendering{
                VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DYNAMIC_RENDERING_FEATURES};
            dynamic_rendering.pNext = &timeline;
            VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
            features.pNext = &dynamic_rendering;
            vkGetPhysicalDeviceFeatures2(candidate, &features);
            if (dynamic_rendering.dynamicRendering != VK_TRUE)
                continue;

            std::uint32_t queue_count = 0;
            vkGetPhysicalDeviceQueueFamilyProperties(candidate, &queue_count, nullptr);
            std::vector<VkQueueFamilyProperties> queues(queue_count);
            vkGetPhysicalDeviceQueueFamilyProperties(candidate, &queue_count, queues.data());
            std::optional<std::uint32_t> graphics_family;
            std::optional<std::uint32_t> present_family;
            for (std::uint32_t index = 0; index < queue_count; ++index) {
                if ((queues[index].queueFlags & VK_QUEUE_GRAPHICS_BIT) != 0 && !graphics_family)
                    graphics_family = index;
                VkBool32 supports_present = VK_FALSE;
                if (vkGetPhysicalDeviceSurfaceSupportKHR(candidate, index, surface, &supports_present) == VK_SUCCESS &&
                    supports_present == VK_TRUE && !present_family)
                    present_family = index;
            }
            if (!graphics_family || !present_family)
                continue;

            std::uint32_t format_count = 0;
            std::uint32_t present_mode_count = 0;
            if (vkGetPhysicalDeviceSurfaceFormatsKHR(candidate, surface, &format_count, nullptr) != VK_SUCCESS ||
                vkGetPhysicalDeviceSurfacePresentModesKHR(candidate, surface, &present_mode_count, nullptr) != VK_SUCCESS ||
                format_count == 0 || present_mode_count == 0)
                continue;

            int score = static_cast<int>(properties.limits.maxImageDimension2D / 1024);
            if (properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU)
                score += 1000;
            else if (properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU)
                score += 500;
            if (*graphics_family == *present_family)
                score += 50;

            if (score > best_score) {
                best_score = score;
                physical_device = candidate;
                physical_properties = properties;
                graphics_queue_family = *graphics_family;
                present_queue_family = *present_family;
                timeline_supported = timeline.timelineSemaphore == VK_TRUE;
            }
        }

        if (physical_device == VK_NULL_HANDLE)
            throw std::runtime_error("no Vulkan device supports graphics, presentation, swapchains, and dynamic rendering");
        vkGetPhysicalDeviceMemoryProperties(physical_device, &memory_properties);
    }

    void create_device()
    {
        constexpr float priority = 1.0F;
        std::vector<VkDeviceQueueCreateInfo> queue_infos;
        const std::array families{graphics_queue_family, present_queue_family};
        for (std::size_t index = 0; index < families.size(); ++index) {
            if (index != 0 && families[index] == families[0])
                continue;
            VkDeviceQueueCreateInfo queue_info{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
            queue_info.queueFamilyIndex = families[index];
            queue_info.queueCount = 1;
            queue_info.pQueuePriorities = &priority;
            queue_infos.push_back(queue_info);
        }

        VkPhysicalDeviceTimelineSemaphoreFeatures timeline{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES};
        timeline.timelineSemaphore = timeline_supported ? VK_TRUE : VK_FALSE;
        VkPhysicalDeviceDynamicRenderingFeatures dynamic_rendering{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DYNAMIC_RENDERING_FEATURES};
        dynamic_rendering.dynamicRendering = VK_TRUE;
        dynamic_rendering.pNext = &timeline;

        constexpr const char* extensions[]{VK_KHR_SWAPCHAIN_EXTENSION_NAME};
        VkDeviceCreateInfo create_info{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        create_info.pNext = &dynamic_rendering;
        create_info.queueCreateInfoCount = static_cast<std::uint32_t>(queue_infos.size());
        create_info.pQueueCreateInfos = queue_infos.data();
        create_info.enabledExtensionCount = 1;
        create_info.ppEnabledExtensionNames = extensions;
        check(vkCreateDevice(physical_device, &create_info, nullptr, &device), "vkCreateDevice");
        vkGetDeviceQueue(device, graphics_queue_family, 0, &graphics_queue);
        vkGetDeviceQueue(device, present_queue_family, 0, &present_queue);
    }

    void create_command_resources()
    {
        VkCommandPoolCreateInfo pool_info{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pool_info.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT |
                          VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;
        pool_info.queueFamilyIndex = graphics_queue_family;
        check(vkCreateCommandPool(device, &pool_info, nullptr, &command_pool), "vkCreateCommandPool");

        std::array<VkCommandBuffer, kFramesInFlight> command_buffers{};
        VkCommandBufferAllocateInfo allocation{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        allocation.commandPool = command_pool;
        allocation.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        allocation.commandBufferCount = kFramesInFlight;
        check(vkAllocateCommandBuffers(device, &allocation, command_buffers.data()),
              "vkAllocateCommandBuffers");

        for (std::size_t index = 0; index < frames.size(); ++index) {
            frames[index].command_buffer = command_buffers[index];
            VkSemaphoreCreateInfo semaphore_info{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
            check(vkCreateSemaphore(device, &semaphore_info, nullptr, &frames[index].image_available),
                  "vkCreateSemaphore(image available)");
            VkFenceCreateInfo fence_info{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
            fence_info.flags = VK_FENCE_CREATE_SIGNALED_BIT;
            check(vkCreateFence(device, &fence_info, nullptr, &frames[index].fence), "vkCreateFence");
        }
    }

    void create_descriptor_resources()
    {
        VkDescriptorSetLayoutBinding binding{};
        binding.binding = 0;
        binding.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        binding.descriptorCount = 1;
        binding.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
        VkDescriptorSetLayoutCreateInfo layout_info{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
        layout_info.bindingCount = 1;
        layout_info.pBindings = &binding;
        check(vkCreateDescriptorSetLayout(device, &layout_info, nullptr, &descriptor_set_layout),
              "vkCreateDescriptorSetLayout");

        constexpr std::uint32_t descriptor_count =
            kMaxTextureCount * static_cast<std::uint32_t>(kSamplerVariantCount);
        VkDescriptorPoolSize pool_size{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, descriptor_count};
        VkDescriptorPoolCreateInfo pool_info{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
        pool_info.flags = VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT;
        pool_info.maxSets = descriptor_count;
        pool_info.poolSizeCount = 1;
        pool_info.pPoolSizes = &pool_size;
        check(vkCreateDescriptorPool(device, &pool_info, nullptr, &descriptor_pool),
              "vkCreateDescriptorPool");

        for (std::size_t index = 0; index < samplers.size(); ++index) {
            const bool linear = (index & 1U) != 0;
            const bool repeat_u = (index & 2U) != 0;
            const bool repeat_v = (index & 4U) != 0;
            VkSamplerCreateInfo sampler_info{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
            sampler_info.magFilter = linear ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
            sampler_info.minFilter = linear ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
            sampler_info.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
            sampler_info.addressModeU = repeat_u
                ? VK_SAMPLER_ADDRESS_MODE_REPEAT
                : VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
            sampler_info.addressModeV = repeat_v
                ? VK_SAMPLER_ADDRESS_MODE_REPEAT
                : VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
            sampler_info.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
            sampler_info.maxLod = 0.0F;
            check(vkCreateSampler(device, &sampler_info, nullptr, &samplers[index]),
                  "vkCreateSampler");
        }

        VkPushConstantRange push_constants{};
        push_constants.stageFlags = VK_SHADER_STAGE_VERTEX_BIT;
        push_constants.size = sizeof(float) * 2;
        VkPipelineLayoutCreateInfo pipeline_layout_info{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
        pipeline_layout_info.setLayoutCount = 1;
        pipeline_layout_info.pSetLayouts = &descriptor_set_layout;
        pipeline_layout_info.pushConstantRangeCount = 1;
        pipeline_layout_info.pPushConstantRanges = &push_constants;
        check(vkCreatePipelineLayout(device, &pipeline_layout_info, nullptr, &pipeline_layout),
              "vkCreatePipelineLayout");
    }

    [[nodiscard]] VkDescriptorSet ensure_texture_descriptor(
        Texture& texture,
        const std::size_t sampler_variant)
    {
        VkDescriptorSet& descriptor_set = texture.descriptor_sets[sampler_variant];
        if (descriptor_set != VK_NULL_HANDLE)
            return descriptor_set;

        VkDescriptorSetAllocateInfo descriptor_allocation{
            VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
        descriptor_allocation.descriptorPool = descriptor_pool;
        descriptor_allocation.descriptorSetCount = 1;
        descriptor_allocation.pSetLayouts = &descriptor_set_layout;
        check(vkAllocateDescriptorSets(device, &descriptor_allocation, &descriptor_set),
              "vkAllocateDescriptorSets(texture)");

        VkDescriptorImageInfo descriptor_image{};
        descriptor_image.sampler = samplers[sampler_variant];
        descriptor_image.imageView = texture.view;
        descriptor_image.imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        VkWriteDescriptorSet descriptor_write{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
        descriptor_write.dstSet = descriptor_set;
        descriptor_write.dstBinding = 0;
        descriptor_write.descriptorCount = 1;
        descriptor_write.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        descriptor_write.pImageInfo = &descriptor_image;
        vkUpdateDescriptorSets(device, 1, &descriptor_write, 0, nullptr);
        return descriptor_set;
    }

    [[nodiscard]] std::uint32_t find_memory_type(
        const std::uint32_t type_bits,
        const VkMemoryPropertyFlags required) const
    {
        for (std::uint32_t index = 0; index < memory_properties.memoryTypeCount; ++index) {
            if ((type_bits & (1U << index)) != 0 &&
                (memory_properties.memoryTypes[index].propertyFlags & required) == required)
                return index;
        }
        throw std::runtime_error("no compatible Vulkan memory type");
    }

    void create_buffer(
        const VkDeviceSize size,
        const VkBufferUsageFlags usage,
        const VkMemoryPropertyFlags memory_flags,
        Buffer& output)
    {
        VkBufferCreateInfo buffer_info{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        buffer_info.size = size;
        buffer_info.usage = usage;
        buffer_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        check(vkCreateBuffer(device, &buffer_info, nullptr, &output.buffer), "vkCreateBuffer");

        VkMemoryRequirements requirements{};
        vkGetBufferMemoryRequirements(device, output.buffer, &requirements);
        VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        allocation.allocationSize = requirements.size;
        allocation.memoryTypeIndex = find_memory_type(requirements.memoryTypeBits, memory_flags);
        check(vkAllocateMemory(device, &allocation, nullptr, &output.memory), "vkAllocateMemory(buffer)");
        check(vkBindBufferMemory(device, output.buffer, output.memory, 0), "vkBindBufferMemory");
        output.capacity = size;
    }

    void destroy_buffer(Buffer& buffer)
    {
        if (buffer.buffer != VK_NULL_HANDLE)
            vkDestroyBuffer(device, buffer.buffer, nullptr);
        if (buffer.memory != VK_NULL_HANDLE)
            vkFreeMemory(device, buffer.memory, nullptr);
        buffer = {};
    }

    void ensure_buffer(Buffer& buffer, const VkDeviceSize required, const VkBufferUsageFlags usage)
    {
        if (required == 0 || buffer.capacity >= required)
            return;
        destroy_buffer(buffer);
        create_buffer(
            next_capacity(required),
            usage,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
            buffer);
    }

    [[nodiscard]] VkCommandBuffer begin_one_time_commands()
    {
        VkCommandBufferAllocateInfo allocation{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        allocation.commandPool = command_pool;
        allocation.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        allocation.commandBufferCount = 1;
        VkCommandBuffer command_buffer = VK_NULL_HANDLE;
        check(vkAllocateCommandBuffers(device, &allocation, &command_buffer),
              "vkAllocateCommandBuffers(one time)");
        VkCommandBufferBeginInfo begin_info{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        begin_info.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        check(vkBeginCommandBuffer(command_buffer, &begin_info), "vkBeginCommandBuffer(one time)");
        return command_buffer;
    }

    void end_one_time_commands(const VkCommandBuffer command_buffer)
    {
        check(vkEndCommandBuffer(command_buffer), "vkEndCommandBuffer(one time)");
        VkSubmitInfo submit_info{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        submit_info.commandBufferCount = 1;
        submit_info.pCommandBuffers = &command_buffer;
        check(vkQueueSubmit(graphics_queue, 1, &submit_info, VK_NULL_HANDLE), "vkQueueSubmit(one time)");
        check(vkQueueWaitIdle(graphics_queue), "vkQueueWaitIdle(one time)");
        vkFreeCommandBuffers(device, command_pool, 1, &command_buffer);
    }

    [[nodiscard]] Texture create_texture_resource(const TextureUpload& upload)
    {
        if (upload.width == 0 || upload.height == 0)
            throw std::invalid_argument("texture dimensions must be positive");
        if (upload.width > physical_properties.limits.maxImageDimension2D ||
            upload.height > physical_properties.limits.maxImageDimension2D)
            throw std::out_of_range("texture dimensions exceed Vulkan device capabilities");
        constexpr std::uint64_t bytes_per_pixel = 4;
        const auto tight_row_pitch = static_cast<std::uint64_t>(upload.width) * bytes_per_pixel;
        if (upload.row_pitch_bytes < tight_row_pitch)
            throw std::invalid_argument("texture row pitch is smaller than its width");
        const auto source_size = static_cast<std::uint64_t>(upload.row_pitch_bytes) * upload.height;
        if (source_size > upload.pixels.size())
            throw std::invalid_argument("texture upload does not contain every row");
        const auto tight_size = tight_row_pitch * upload.height;
        if (tight_size > std::numeric_limits<std::size_t>::max())
            throw std::overflow_error("texture upload is too large");

        std::vector<std::byte> tight_pixels(static_cast<std::size_t>(tight_size));
        for (std::uint32_t row = 0; row < upload.height; ++row) {
            std::memcpy(
                tight_pixels.data() + static_cast<std::size_t>(row * tight_row_pitch),
                upload.pixels.data() + static_cast<std::size_t>(row) * upload.row_pitch_bytes,
                static_cast<std::size_t>(tight_row_pitch));
        }

        Buffer staging;
        Texture texture;
        try {
            create_buffer(
                tight_size,
                VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                staging);
            void* mapped = nullptr;
            check(vkMapMemory(device, staging.memory, 0, tight_size, 0, &mapped), "vkMapMemory(texture upload)");
            std::memcpy(mapped, tight_pixels.data(), tight_pixels.size());
            vkUnmapMemory(device, staging.memory);

            VkImageCreateInfo image_info{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
            image_info.imageType = VK_IMAGE_TYPE_2D;
            image_info.format = texture_format(upload.format);
            image_info.extent = {upload.width, upload.height, 1};
            image_info.mipLevels = 1;
            image_info.arrayLayers = 1;
            image_info.samples = VK_SAMPLE_COUNT_1_BIT;
            image_info.tiling = VK_IMAGE_TILING_OPTIMAL;
            image_info.usage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT;
            image_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
            image_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            check(vkCreateImage(device, &image_info, nullptr, &texture.image), "vkCreateImage(texture)");

            VkMemoryRequirements requirements{};
            vkGetImageMemoryRequirements(device, texture.image, &requirements);
            VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
            allocation.allocationSize = requirements.size;
            allocation.memoryTypeIndex = find_memory_type(
                requirements.memoryTypeBits,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
            check(vkAllocateMemory(device, &allocation, nullptr, &texture.memory),
                  "vkAllocateMemory(texture)");
            check(vkBindImageMemory(device, texture.image, texture.memory, 0), "vkBindImageMemory(texture)");

            VkImageViewCreateInfo view_info{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
            view_info.image = texture.image;
            view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
            view_info.format = image_info.format;
            view_info.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            view_info.subresourceRange.levelCount = 1;
            view_info.subresourceRange.layerCount = 1;
            check(vkCreateImageView(device, &view_info, nullptr, &texture.view), "vkCreateImageView(texture)");

            const VkCommandBuffer command_buffer = begin_one_time_commands();
            VkImageMemoryBarrier to_transfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
            to_transfer.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            to_transfer.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            to_transfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
            to_transfer.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            to_transfer.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            to_transfer.image = texture.image;
            to_transfer.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            to_transfer.subresourceRange.levelCount = 1;
            to_transfer.subresourceRange.layerCount = 1;
            vkCmdPipelineBarrier(
                command_buffer,
                VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT,
                0,
                0,
                nullptr,
                0,
                nullptr,
                1,
                &to_transfer);

            VkBufferImageCopy copy{};
            copy.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            copy.imageSubresource.layerCount = 1;
            copy.imageExtent = {upload.width, upload.height, 1};
            vkCmdCopyBufferToImage(
                command_buffer,
                staging.buffer,
                texture.image,
                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                1,
                &copy);

            VkImageMemoryBarrier to_shader{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
            to_shader.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            to_shader.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
            to_shader.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
            to_shader.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
            to_shader.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            to_shader.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            to_shader.image = texture.image;
            to_shader.subresourceRange = to_transfer.subresourceRange;
            vkCmdPipelineBarrier(
                command_buffer,
                VK_PIPELINE_STAGE_TRANSFER_BIT,
                VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                0,
                0,
                nullptr,
                0,
                nullptr,
                1,
                &to_shader);
            end_one_time_commands(command_buffer);
            destroy_buffer(staging);
            return texture;
        } catch (...) {
            destroy_buffer(staging);
            destroy_texture_resource(texture);
            throw;
        }
    }

    void destroy_texture_resource(Texture& texture)
    {
        if (descriptor_pool != VK_NULL_HANDLE) {
            for (VkDescriptorSet& descriptor_set : texture.descriptor_sets) {
                if (descriptor_set != VK_NULL_HANDLE)
                    vkFreeDescriptorSets(device, descriptor_pool, 1, &descriptor_set);
                descriptor_set = VK_NULL_HANDLE;
            }
        }
        if (texture.view != VK_NULL_HANDLE)
            vkDestroyImageView(device, texture.view, nullptr);
        if (texture.image != VK_NULL_HANDLE)
            vkDestroyImage(device, texture.image, nullptr);
        if (texture.memory != VK_NULL_HANDLE)
            vkFreeMemory(device, texture.memory, nullptr);
        texture = {};
    }

    void create_white_texture()
    {
        constexpr std::array<std::byte, 4> white{
            std::byte{0xFF}, std::byte{0xFF}, std::byte{0xFF}, std::byte{0xFF}};
        white_texture = create_texture_resource({
            1,
            1,
            4,
            TextureFormat::rgba8_unorm,
            white,
        });
    }

    [[nodiscard]] PixelExtent client_extent() const noexcept
    {
        if (window == nullptr)
            return {};
        RECT client{};
        if (!GetClientRect(window, &client))
            return {};
        return {
            static_cast<std::uint32_t>(std::max<LONG>(0, client.right - client.left)),
            static_cast<std::uint32_t>(std::max<LONG>(0, client.bottom - client.top)),
        };
    }

    [[nodiscard]] VkSurfaceFormatKHR choose_surface_format(
        const std::vector<VkSurfaceFormatKHR>& formats) const
    {
        constexpr std::array preferred{
            VK_FORMAT_B8G8R8A8_SRGB,
            VK_FORMAT_R8G8B8A8_SRGB,
            VK_FORMAT_B8G8R8A8_UNORM,
            VK_FORMAT_R8G8B8A8_UNORM,
        };
        for (const VkFormat format : preferred) {
            const auto found = std::find_if(formats.begin(), formats.end(), [format](const VkSurfaceFormatKHR& candidate) {
                return candidate.format == format && candidate.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR;
            });
            if (found != formats.end())
                return *found;
        }
        return formats.front();
    }

    [[nodiscard]] VkPresentModeKHR choose_present_mode(
        const std::vector<VkPresentModeKHR>& modes) const
    {
        if (config.vertical_sync)
            return VK_PRESENT_MODE_FIFO_KHR;
        if (std::find(modes.begin(), modes.end(), VK_PRESENT_MODE_MAILBOX_KHR) != modes.end())
            return VK_PRESENT_MODE_MAILBOX_KHR;
        if (std::find(modes.begin(), modes.end(), VK_PRESENT_MODE_IMMEDIATE_KHR) != modes.end())
            return VK_PRESENT_MODE_IMMEDIATE_KHR;
        return VK_PRESENT_MODE_FIFO_KHR;
    }

    void destroy_swapchain()
    {
        for (const VkSemaphore semaphore : present_semaphores)
            vkDestroySemaphore(device, semaphore, nullptr);
        present_semaphores.clear();
        for (const VkImageView view : swapchain_views)
            vkDestroyImageView(device, view, nullptr);
        swapchain_views.clear();
        swapchain_images.clear();
        image_fences.clear();
        if (swapchain != VK_NULL_HANDLE)
            vkDestroySwapchainKHR(device, swapchain, nullptr);
        swapchain = VK_NULL_HANDLE;
        swapchain_extent = {};
    }

    [[nodiscard]] bool recreate_swapchain()
    {
        const PixelExtent client = client_extent();
        if (client.width == 0 || client.height == 0)
            return false;
        check(vkDeviceWaitIdle(device), "vkDeviceWaitIdle(swapchain recreation)");

        VkSurfaceCapabilitiesKHR capabilities_info{};
        check(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physical_device, surface, &capabilities_info),
              "vkGetPhysicalDeviceSurfaceCapabilitiesKHR");

        std::uint32_t format_count = 0;
        check(vkGetPhysicalDeviceSurfaceFormatsKHR(physical_device, surface, &format_count, nullptr),
              "vkGetPhysicalDeviceSurfaceFormatsKHR(count)");
        std::vector<VkSurfaceFormatKHR> formats(format_count);
        check(vkGetPhysicalDeviceSurfaceFormatsKHR(physical_device, surface, &format_count, formats.data()),
              "vkGetPhysicalDeviceSurfaceFormatsKHR");

        std::uint32_t present_mode_count = 0;
        check(vkGetPhysicalDeviceSurfacePresentModesKHR(physical_device, surface, &present_mode_count, nullptr),
              "vkGetPhysicalDeviceSurfacePresentModesKHR(count)");
        std::vector<VkPresentModeKHR> present_modes(present_mode_count);
        check(vkGetPhysicalDeviceSurfacePresentModesKHR(
                  physical_device,
                  surface,
                  &present_mode_count,
                  present_modes.data()),
              "vkGetPhysicalDeviceSurfacePresentModesKHR");

        const VkSurfaceFormatKHR surface_format = choose_surface_format(formats);
        const VkPresentModeKHR present_mode = choose_present_mode(present_modes);
        VkExtent2D extent{};
        if (capabilities_info.currentExtent.width != std::numeric_limits<std::uint32_t>::max()) {
            extent = capabilities_info.currentExtent;
        } else {
            extent.width = std::clamp(
                client.width,
                capabilities_info.minImageExtent.width,
                capabilities_info.maxImageExtent.width);
            extent.height = std::clamp(
                client.height,
                capabilities_info.minImageExtent.height,
                capabilities_info.maxImageExtent.height);
        }

        std::uint32_t image_count = capabilities_info.minImageCount + 1;
        if (capabilities_info.maxImageCount != 0)
            image_count = std::min(image_count, capabilities_info.maxImageCount);

        VkImageUsageFlags image_usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        swapchain_supports_transfer_source =
            (capabilities_info.supportedUsageFlags & VK_IMAGE_USAGE_TRANSFER_SRC_BIT) != 0;
        if (swapchain_supports_transfer_source)
            image_usage |= VK_IMAGE_USAGE_TRANSFER_SRC_BIT;

        destroy_swapchain();
        VkSwapchainCreateInfoKHR create_info{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
        create_info.surface = surface;
        create_info.minImageCount = image_count;
        create_info.imageFormat = surface_format.format;
        create_info.imageColorSpace = surface_format.colorSpace;
        create_info.imageExtent = extent;
        create_info.imageArrayLayers = 1;
        create_info.imageUsage = image_usage;
        const std::array queue_families{graphics_queue_family, present_queue_family};
        if (graphics_queue_family != present_queue_family) {
            create_info.imageSharingMode = VK_SHARING_MODE_CONCURRENT;
            create_info.queueFamilyIndexCount = 2;
            create_info.pQueueFamilyIndices = queue_families.data();
        } else {
            create_info.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
        }
        create_info.preTransform = capabilities_info.currentTransform;
        create_info.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        create_info.presentMode = present_mode;
        create_info.clipped = VK_TRUE;
        check(vkCreateSwapchainKHR(device, &create_info, nullptr, &swapchain), "vkCreateSwapchainKHR");

        check(vkGetSwapchainImagesKHR(device, swapchain, &image_count, nullptr),
              "vkGetSwapchainImagesKHR(count)");
        swapchain_images.resize(image_count);
        check(vkGetSwapchainImagesKHR(device, swapchain, &image_count, swapchain_images.data()),
              "vkGetSwapchainImagesKHR");
        swapchain_views.reserve(image_count);
        for (const VkImage image : swapchain_images) {
            VkImageViewCreateInfo view_info{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
            view_info.image = image;
            view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
            view_info.format = surface_format.format;
            view_info.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            view_info.subresourceRange.levelCount = 1;
            view_info.subresourceRange.layerCount = 1;
            VkImageView view = VK_NULL_HANDLE;
            check(vkCreateImageView(device, &view_info, nullptr, &view), "vkCreateImageView(swapchain)");
            swapchain_views.push_back(view);
        }
        image_fences.assign(image_count, VK_NULL_HANDLE);
        present_semaphores.resize(image_count);
        for (VkSemaphore& semaphore : present_semaphores) {
            VkSemaphoreCreateInfo semaphore_info{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
            check(vkCreateSemaphore(device, &semaphore_info, nullptr, &semaphore),
                  "vkCreateSemaphore(present)");
        }

        if (swapchain_format != surface_format.format || pipelines[0] == VK_NULL_HANDLE) {
            swapchain_format = surface_format.format;
            create_pipelines();
        }
        swapchain_extent = extent;
        swapchain_dirty = false;
        ++swapchain_recreation_count;
        return true;
    }

    [[nodiscard]] VkShaderModule create_shader_module(const std::vector<std::uint32_t>& words) const
    {
        VkShaderModuleCreateInfo create_info{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        create_info.codeSize = words.size() * sizeof(std::uint32_t);
        create_info.pCode = words.data();
        VkShaderModule module_handle = VK_NULL_HANDLE;
        check(vkCreateShaderModule(device, &create_info, nullptr, &module_handle), "vkCreateShaderModule");
        return module_handle;
    }

    void create_pipelines()
    {
        for (VkPipeline& pipeline : pipelines) {
            if (pipeline != VK_NULL_HANDLE)
                vkDestroyPipeline(device, pipeline, nullptr);
            pipeline = VK_NULL_HANDLE;
        }

        const VkShaderModule vertex_shader = create_shader_module(vertex_shader_words);
        const VkShaderModule fragment_shader = create_shader_module(fragment_shader_words);
        try {
            VkPipelineShaderStageCreateInfo vertex_stage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
            vertex_stage.stage = VK_SHADER_STAGE_VERTEX_BIT;
            vertex_stage.module = vertex_shader;
            vertex_stage.pName = "main";
            VkPipelineShaderStageCreateInfo fragment_stage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
            fragment_stage.stage = VK_SHADER_STAGE_FRAGMENT_BIT;
            fragment_stage.module = fragment_shader;
            fragment_stage.pName = "main";
            const std::array stages{vertex_stage, fragment_stage};

            VkVertexInputBindingDescription binding{};
            binding.binding = 0;
            binding.stride = sizeof(Vertex2D);
            binding.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
            const std::array attributes{
                VkVertexInputAttributeDescription{0, 0, VK_FORMAT_R32G32_SFLOAT, offsetof(Vertex2D, x)},
                VkVertexInputAttributeDescription{1, 0, VK_FORMAT_R32G32_SFLOAT, offsetof(Vertex2D, u)},
                VkVertexInputAttributeDescription{2, 0, VK_FORMAT_R8G8B8A8_UNORM, offsetof(Vertex2D, rgba)},
            };
            VkPipelineVertexInputStateCreateInfo vertex_input{
                VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
            vertex_input.vertexBindingDescriptionCount = 1;
            vertex_input.pVertexBindingDescriptions = &binding;
            vertex_input.vertexAttributeDescriptionCount = static_cast<std::uint32_t>(attributes.size());
            vertex_input.pVertexAttributeDescriptions = attributes.data();

            VkPipelineInputAssemblyStateCreateInfo input_assembly{
                VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
            input_assembly.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
            VkPipelineViewportStateCreateInfo viewport_state{
                VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
            viewport_state.viewportCount = 1;
            viewport_state.scissorCount = 1;
            VkPipelineRasterizationStateCreateInfo rasterization{
                VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
            rasterization.polygonMode = VK_POLYGON_MODE_FILL;
            rasterization.cullMode = VK_CULL_MODE_NONE;
            rasterization.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
            rasterization.lineWidth = 1.0F;
            VkPipelineMultisampleStateCreateInfo multisample{
                VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
            multisample.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
            const std::array dynamic_states{VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
            VkPipelineDynamicStateCreateInfo dynamic_state{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
            dynamic_state.dynamicStateCount = static_cast<std::uint32_t>(dynamic_states.size());
            dynamic_state.pDynamicStates = dynamic_states.data();
            VkPipelineRenderingCreateInfo rendering_info{VK_STRUCTURE_TYPE_PIPELINE_RENDERING_CREATE_INFO};
            rendering_info.colorAttachmentCount = 1;
            rendering_info.pColorAttachmentFormats = &swapchain_format;

            for (std::size_t index = 0; index < pipelines.size(); ++index) {
                VkPipelineColorBlendAttachmentState blend{};
                blend.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                       VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
                if (index != 0) {
                    blend.blendEnable = VK_TRUE;
                    blend.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
                    blend.dstColorBlendFactor = index == 1
                        ? VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
                        : VK_BLEND_FACTOR_ONE;
                    blend.colorBlendOp = VK_BLEND_OP_ADD;
                    blend.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
                    blend.dstAlphaBlendFactor = index == 1
                        ? VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
                        : VK_BLEND_FACTOR_ONE;
                    blend.alphaBlendOp = VK_BLEND_OP_ADD;
                }
                VkPipelineColorBlendStateCreateInfo blend_state{
                    VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
                blend_state.attachmentCount = 1;
                blend_state.pAttachments = &blend;

                VkGraphicsPipelineCreateInfo pipeline_info{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
                pipeline_info.pNext = &rendering_info;
                pipeline_info.stageCount = static_cast<std::uint32_t>(stages.size());
                pipeline_info.pStages = stages.data();
                pipeline_info.pVertexInputState = &vertex_input;
                pipeline_info.pInputAssemblyState = &input_assembly;
                pipeline_info.pViewportState = &viewport_state;
                pipeline_info.pRasterizationState = &rasterization;
                pipeline_info.pMultisampleState = &multisample;
                pipeline_info.pColorBlendState = &blend_state;
                pipeline_info.pDynamicState = &dynamic_state;
                pipeline_info.layout = pipeline_layout;
                check(vkCreateGraphicsPipelines(
                          device,
                          VK_NULL_HANDLE,
                          1,
                          &pipeline_info,
                          nullptr,
                          &pipelines[index]),
                      "vkCreateGraphicsPipelines");
            }
        } catch (...) {
            vkDestroyShaderModule(device, fragment_shader, nullptr);
            vkDestroyShaderModule(device, vertex_shader, nullptr);
            throw;
        }
        vkDestroyShaderModule(device, fragment_shader, nullptr);
        vkDestroyShaderModule(device, vertex_shader, nullptr);
    }

    void validate_frame(const FramePacket& frame) const
    {
        if (frame.logical_extent.width <= 0.0 || frame.logical_extent.height <= 0.0)
            throw std::invalid_argument("frame logical extent must be positive");
        if (frame.pixel_viewport.extent.width <= 0.0 || frame.pixel_viewport.extent.height <= 0.0)
            throw std::invalid_argument("frame pixel viewport must be positive");
        if (frame.interpolation_alpha < 0.0 || frame.interpolation_alpha >= 1.0)
            throw std::invalid_argument("frame interpolation alpha must be in [0, 1)");

        constexpr double epsilon = 1e-6;
        const double viewport_right = frame.pixel_viewport.origin.x + frame.pixel_viewport.extent.width;
        const double viewport_bottom = frame.pixel_viewport.origin.y + frame.pixel_viewport.extent.height;
        if (frame.pixel_viewport.origin.x < -epsilon || frame.pixel_viewport.origin.y < -epsilon ||
            viewport_right > static_cast<double>(swapchain_extent.width) + epsilon ||
            viewport_bottom > static_cast<double>(swapchain_extent.height) + epsilon)
            throw std::out_of_range("frame pixel viewport exceeds the swapchain");

        for (const std::uint32_t index : frame.indices) {
            if (index >= frame.vertices.size())
                throw std::out_of_range("draw index references a missing vertex");
        }
        for (const DrawBatch& batch : frame.batches) {
            if (batch.texture && !textures.contains(batch.texture.value))
                throw std::invalid_argument("draw batch references an unknown texture");
            if (static_cast<std::uint64_t>(batch.first_index) + batch.index_count > frame.indices.size())
                throw std::out_of_range("draw batch exceeds the frame index buffer");
            const double scissor_right = batch.logical_scissor.origin.x + batch.logical_scissor.extent.width;
            const double scissor_bottom = batch.logical_scissor.origin.y + batch.logical_scissor.extent.height;
            if (batch.logical_scissor.origin.x < 0.0 || batch.logical_scissor.origin.y < 0.0 ||
                batch.logical_scissor.extent.width < 0.0 || batch.logical_scissor.extent.height < 0.0 ||
                scissor_right > frame.logical_extent.width + epsilon ||
                scissor_bottom > frame.logical_extent.height + epsilon)
                throw std::out_of_range("draw batch logical scissor exceeds the logical frame");
        }
    }

    [[nodiscard]] VkRect2D pixel_scissor(const FramePacket& frame, const Rect2D& logical) const
    {
        const double scale_x = frame.pixel_viewport.extent.width / frame.logical_extent.width;
        const double scale_y = frame.pixel_viewport.extent.height / frame.logical_extent.height;
        const double left = frame.pixel_viewport.origin.x + logical.origin.x * scale_x;
        const double top = frame.pixel_viewport.origin.y + logical.origin.y * scale_y;
        const double right = left + logical.extent.width * scale_x;
        const double bottom = top + logical.extent.height * scale_y;

        const auto clamp_x = [this](const double value) {
            return std::clamp(value, 0.0, static_cast<double>(swapchain_extent.width));
        };
        const auto clamp_y = [this](const double value) {
            return std::clamp(value, 0.0, static_cast<double>(swapchain_extent.height));
        };
        const std::int32_t x0 = static_cast<std::int32_t>(std::floor(clamp_x(left)));
        const std::int32_t y0 = static_cast<std::int32_t>(std::floor(clamp_y(top)));
        const std::int32_t x1 = static_cast<std::int32_t>(std::ceil(clamp_x(right)));
        const std::int32_t y1 = static_cast<std::int32_t>(std::ceil(clamp_y(bottom)));
        return {
            {x0, y0},
            {
                static_cast<std::uint32_t>(std::max(0, x1 - x0)),
                static_cast<std::uint32_t>(std::max(0, y1 - y0)),
            },
        };
    }

    [[nodiscard]] VkDescriptorSet descriptor_for(
        const TextureHandle handle,
        const SamplingState sampling)
    {
        const std::size_t index = sampler_index(sampling);
        if (!handle)
            return ensure_texture_descriptor(white_texture, index);
        return ensure_texture_descriptor(textures.at(handle.value), index);
    }

    void transition_swapchain_image(
        const VkCommandBuffer command_buffer,
        const VkImage image,
        const VkImageLayout old_layout,
        const VkImageLayout new_layout,
        const VkAccessFlags source_access,
        const VkAccessFlags destination_access,
        const VkPipelineStageFlags source_stage,
        const VkPipelineStageFlags destination_stage) const
    {
        VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        barrier.srcAccessMask = source_access;
        barrier.dstAccessMask = destination_access;
        barrier.oldLayout = old_layout;
        barrier.newLayout = new_layout;
        barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        barrier.image = image;
        barrier.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        barrier.subresourceRange.levelCount = 1;
        barrier.subresourceRange.layerCount = 1;
        vkCmdPipelineBarrier(
            command_buffer,
            source_stage,
            destination_stage,
            0,
            0,
            nullptr,
            0,
            nullptr,
            1,
            &barrier);
    }

    void read_capture_buffer()
    {
        const std::size_t byte_count = static_cast<std::size_t>(swapchain_extent.width) *
                                       swapchain_extent.height * 4;
        CapturedFrame capture;
        capture.extent = {swapchain_extent.width, swapchain_extent.height};
        capture.rgba8.resize(byte_count);
        void* mapped = nullptr;
        check(vkMapMemory(device, capture_buffer.memory, 0, byte_count, 0, &mapped),
              "vkMapMemory(capture)");
        std::memcpy(capture.rgba8.data(), mapped, byte_count);
        vkUnmapMemory(device, capture_buffer.memory);

        if (swapchain_format == VK_FORMAT_B8G8R8A8_UNORM ||
            swapchain_format == VK_FORMAT_B8G8R8A8_SRGB) {
            for (std::size_t offset = 0; offset < capture.rgba8.size(); offset += 4)
                std::swap(capture.rgba8[offset], capture.rgba8[offset + 2]);
        }
        captured_frame = std::move(capture);
    }

    void submit(const FramePacket& frame)
    {
        static_cast<void>(poll_events());
        if (close_requested)
            return;
        if (swapchain_dirty && !recreate_swapchain())
            return;
        validate_frame(frame);
        for (const DrawBatch& batch : frame.batches)
            static_cast<void>(descriptor_for(batch.texture, batch.sampling));

        FrameResources& resources = frames[current_frame];
        check(vkWaitForFences(device, 1, &resources.fence, VK_TRUE, UINT64_MAX),
              "vkWaitForFences(frame)");

        std::uint32_t image_index = 0;
        const VkResult acquire_result = vkAcquireNextImageKHR(
            device,
            swapchain,
            UINT64_MAX,
            resources.image_available,
            VK_NULL_HANDLE,
            &image_index);
        if (acquire_result == VK_ERROR_OUT_OF_DATE_KHR) {
            swapchain_dirty = true;
            static_cast<void>(recreate_swapchain());
            return;
        }
        if (acquire_result != VK_SUCCESS && acquire_result != VK_SUBOPTIMAL_KHR)
            check(acquire_result, "vkAcquireNextImageKHR");
        if (image_fences[image_index] != VK_NULL_HANDLE)
            check(vkWaitForFences(device, 1, &image_fences[image_index], VK_TRUE, UINT64_MAX),
                  "vkWaitForFences(swapchain image)");
        image_fences[image_index] = resources.fence;

        const VkDeviceSize vertex_bytes = frame.vertices.size_bytes();
        const VkDeviceSize index_bytes = frame.indices.size_bytes();
        ensure_buffer(resources.vertex_buffer, vertex_bytes, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT);
        ensure_buffer(resources.index_buffer, index_bytes, VK_BUFFER_USAGE_INDEX_BUFFER_BIT);
        if (vertex_bytes != 0) {
            void* mapped = nullptr;
            check(vkMapMemory(device, resources.vertex_buffer.memory, 0, vertex_bytes, 0, &mapped),
                  "vkMapMemory(vertices)");
            std::memcpy(mapped, frame.vertices.data(), static_cast<std::size_t>(vertex_bytes));
            vkUnmapMemory(device, resources.vertex_buffer.memory);
        }
        if (index_bytes != 0) {
            void* mapped = nullptr;
            check(vkMapMemory(device, resources.index_buffer.memory, 0, index_bytes, 0, &mapped),
                  "vkMapMemory(indices)");
            std::memcpy(mapped, frame.indices.data(), static_cast<std::size_t>(index_bytes));
            vkUnmapMemory(device, resources.index_buffer.memory);
        }

        const bool capture_this_frame = capture_requested;
        if (capture_this_frame) {
            if (!swapchain_supports_transfer_source)
                throw std::runtime_error("the selected surface does not support swapchain readback");
            const VkDeviceSize capture_bytes = static_cast<VkDeviceSize>(swapchain_extent.width) *
                                               swapchain_extent.height * 4;
            ensure_buffer(capture_buffer, capture_bytes, VK_BUFFER_USAGE_TRANSFER_DST_BIT);
        }

        check(vkResetFences(device, 1, &resources.fence), "vkResetFences");
        check(vkResetCommandBuffer(resources.command_buffer, 0), "vkResetCommandBuffer");
        VkCommandBufferBeginInfo begin_info{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        begin_info.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        check(vkBeginCommandBuffer(resources.command_buffer, &begin_info), "vkBeginCommandBuffer(frame)");

        transition_swapchain_image(
            resources.command_buffer,
            swapchain_images[image_index],
            VK_IMAGE_LAYOUT_UNDEFINED,
            VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
            0,
            VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
            VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
            VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);

        VkClearValue clear_value{{{0.015F, 0.02F, 0.025F, 1.0F}}};
        VkRenderingAttachmentInfo color_attachment{VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO};
        color_attachment.imageView = swapchain_views[image_index];
        color_attachment.imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        color_attachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        color_attachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        color_attachment.clearValue = clear_value;
        VkRenderingInfo rendering_info{VK_STRUCTURE_TYPE_RENDERING_INFO};
        rendering_info.renderArea.extent = swapchain_extent;
        rendering_info.layerCount = 1;
        rendering_info.colorAttachmentCount = 1;
        rendering_info.pColorAttachments = &color_attachment;
        vkCmdBeginRendering(resources.command_buffer, &rendering_info);

        const VkViewport viewport{
            static_cast<float>(frame.pixel_viewport.origin.x),
            static_cast<float>(frame.pixel_viewport.origin.y),
            static_cast<float>(frame.pixel_viewport.extent.width),
            static_cast<float>(frame.pixel_viewport.extent.height),
            0.0F,
            1.0F,
        };
        vkCmdSetViewport(resources.command_buffer, 0, 1, &viewport);
        if (vertex_bytes != 0) {
            constexpr VkDeviceSize offset = 0;
            vkCmdBindVertexBuffers(resources.command_buffer, 0, 1, &resources.vertex_buffer.buffer, &offset);
        }
        if (index_bytes != 0)
            vkCmdBindIndexBuffer(resources.command_buffer, resources.index_buffer.buffer, 0, VK_INDEX_TYPE_UINT32);

        const std::array<float, 2> logical_extent{
            static_cast<float>(frame.logical_extent.width),
            static_cast<float>(frame.logical_extent.height),
        };
        vkCmdPushConstants(
            resources.command_buffer,
            pipeline_layout,
            VK_SHADER_STAGE_VERTEX_BIT,
            0,
            sizeof(logical_extent),
            logical_extent.data());

        std::optional<BlendMode> bound_blend;
        VkDescriptorSet bound_descriptor = VK_NULL_HANDLE;
        for (const DrawBatch& batch : frame.batches) {
            const VkRect2D scissor = pixel_scissor(frame, batch.logical_scissor);
            if (scissor.extent.width == 0 || scissor.extent.height == 0 || batch.index_count == 0)
                continue;
            vkCmdSetScissor(resources.command_buffer, 0, 1, &scissor);
            if (!bound_blend || *bound_blend != batch.blend_mode) {
                vkCmdBindPipeline(
                    resources.command_buffer,
                    VK_PIPELINE_BIND_POINT_GRAPHICS,
                    pipelines[pipeline_index(batch.blend_mode)]);
                bound_blend = batch.blend_mode;
            }
            const VkDescriptorSet descriptor = descriptor_for(batch.texture, batch.sampling);
            if (bound_descriptor != descriptor) {
                vkCmdBindDescriptorSets(
                    resources.command_buffer,
                    VK_PIPELINE_BIND_POINT_GRAPHICS,
                    pipeline_layout,
                    0,
                    1,
                    &descriptor,
                    0,
                    nullptr);
                bound_descriptor = descriptor;
            }
            vkCmdDrawIndexed(resources.command_buffer, batch.index_count, 1, batch.first_index, 0, 0);
        }
        vkCmdEndRendering(resources.command_buffer);

        if (capture_this_frame) {
            transition_swapchain_image(
                resources.command_buffer,
                swapchain_images[image_index],
                VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
                VK_ACCESS_TRANSFER_READ_BIT,
                VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT);
            VkBufferImageCopy copy{};
            copy.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            copy.imageSubresource.layerCount = 1;
            copy.imageExtent = {swapchain_extent.width, swapchain_extent.height, 1};
            vkCmdCopyImageToBuffer(
                resources.command_buffer,
                swapchain_images[image_index],
                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                capture_buffer.buffer,
                1,
                &copy);
            transition_swapchain_image(
                resources.command_buffer,
                swapchain_images[image_index],
                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
                VK_ACCESS_TRANSFER_READ_BIT,
                0,
                VK_PIPELINE_STAGE_TRANSFER_BIT,
                VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
        } else {
            transition_swapchain_image(
                resources.command_buffer,
                swapchain_images[image_index],
                VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
                VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
                VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
                0,
                VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
        }
        check(vkEndCommandBuffer(resources.command_buffer), "vkEndCommandBuffer(frame)");

        constexpr VkPipelineStageFlags wait_stage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        VkSubmitInfo submit_info{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        submit_info.waitSemaphoreCount = 1;
        submit_info.pWaitSemaphores = &resources.image_available;
        submit_info.pWaitDstStageMask = &wait_stage;
        submit_info.commandBufferCount = 1;
        submit_info.pCommandBuffers = &resources.command_buffer;
        submit_info.signalSemaphoreCount = 1;
        submit_info.pSignalSemaphores = &present_semaphores[image_index];
        check(vkQueueSubmit(graphics_queue, 1, &submit_info, resources.fence), "vkQueueSubmit(frame)");

        VkPresentInfoKHR present_info{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
        present_info.waitSemaphoreCount = 1;
        present_info.pWaitSemaphores = &present_semaphores[image_index];
        present_info.swapchainCount = 1;
        present_info.pSwapchains = &swapchain;
        present_info.pImageIndices = &image_index;
        const VkResult present_result = vkQueuePresentKHR(present_queue, &present_info);

        if (capture_this_frame) {
            check(vkWaitForFences(device, 1, &resources.fence, VK_TRUE, UINT64_MAX),
                  "vkWaitForFences(capture)");
            read_capture_buffer();
            capture_requested = false;
        }

        if (present_result == VK_ERROR_OUT_OF_DATE_KHR || present_result == VK_SUBOPTIMAL_KHR ||
            acquire_result == VK_SUBOPTIMAL_KHR)
            swapchain_dirty = true;
        else if (present_result != VK_SUCCESS)
            check(present_result, "vkQueuePresentKHR");

        ++presented_frame_count;
        current_frame = (current_frame + 1) % frames.size();
    }

    [[nodiscard]] bool poll_events()
    {
        MSG message{};
        while (PeekMessageA(&message, nullptr, 0, 0, PM_REMOVE)) {
            if (message.message == WM_QUIT)
                close_requested = true;
            TranslateMessage(&message);
            DispatchMessageA(&message);
        }
        return !close_requested;
    }

    void resize(const std::uint32_t width, const std::uint32_t height)
    {
        if (width == 0 || height == 0)
            throw std::invalid_argument("window dimensions must be positive");
        if (window == nullptr)
            throw std::logic_error("Vulkan window is closed");
        constexpr DWORD style = WS_OVERLAPPEDWINDOW;
        RECT outer{0, 0, static_cast<LONG>(width), static_cast<LONG>(height)};
        if (!AdjustWindowRectEx(&outer, style, FALSE, 0))
            throw std::runtime_error("AdjustWindowRectEx failed while resizing");
        if (!SetWindowPos(
                window,
                nullptr,
                0,
                0,
                outer.right - outer.left,
                outer.bottom - outer.top,
                SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE))
            throw std::runtime_error("SetWindowPos failed");
        swapchain_dirty = true;
    }

    void cleanup() noexcept
    {
        if (device != VK_NULL_HANDLE)
            vkDeviceWaitIdle(device);

        for (auto& [handle, texture] : textures) {
            static_cast<void>(handle);
            destroy_texture_resource(texture);
        }
        textures.clear();
        destroy_texture_resource(white_texture);
        destroy_buffer(capture_buffer);
        for (FrameResources& frame : frames) {
            destroy_buffer(frame.vertex_buffer);
            destroy_buffer(frame.index_buffer);
            if (frame.image_available != VK_NULL_HANDLE)
                vkDestroySemaphore(device, frame.image_available, nullptr);
            if (frame.fence != VK_NULL_HANDLE)
                vkDestroyFence(device, frame.fence, nullptr);
        }
        for (VkPipeline& pipeline : pipelines) {
            if (pipeline != VK_NULL_HANDLE)
                vkDestroyPipeline(device, pipeline, nullptr);
            pipeline = VK_NULL_HANDLE;
        }
        destroy_swapchain();
        if (pipeline_layout != VK_NULL_HANDLE)
            vkDestroyPipelineLayout(device, pipeline_layout, nullptr);
        for (VkSampler& sampler : samplers) {
            if (sampler != VK_NULL_HANDLE)
                vkDestroySampler(device, sampler, nullptr);
            sampler = VK_NULL_HANDLE;
        }
        if (descriptor_pool != VK_NULL_HANDLE)
            vkDestroyDescriptorPool(device, descriptor_pool, nullptr);
        if (descriptor_set_layout != VK_NULL_HANDLE)
            vkDestroyDescriptorSetLayout(device, descriptor_set_layout, nullptr);
        if (command_pool != VK_NULL_HANDLE)
            vkDestroyCommandPool(device, command_pool, nullptr);
        if (device != VK_NULL_HANDLE)
            vkDestroyDevice(device, nullptr);
        device = VK_NULL_HANDLE;

        if (surface != VK_NULL_HANDLE)
            vkDestroySurfaceKHR(instance, surface, nullptr);
        if (debug_messenger != VK_NULL_HANDLE) {
            const auto destroy_debug_messenger = reinterpret_cast<PFN_vkDestroyDebugUtilsMessengerEXT>(
                vkGetInstanceProcAddr(instance, "vkDestroyDebugUtilsMessengerEXT"));
            if (destroy_debug_messenger != nullptr)
                destroy_debug_messenger(instance, debug_messenger, nullptr);
        }
        if (instance != VK_NULL_HANDLE)
            vkDestroyInstance(instance, nullptr);
        instance = VK_NULL_HANDLE;

        if (window != nullptr)
            DestroyWindow(window);
        window = nullptr;
    }
};

VulkanWindowBackend::VulkanWindowBackend(
    VulkanWindowConfig config,
    std::filesystem::path vertex_shader,
    std::filesystem::path fragment_shader)
    : implementation_(std::make_unique<Implementation>(
          std::move(config),
          vertex_shader,
          fragment_shader))
{
}

VulkanWindowBackend::~VulkanWindowBackend() = default;
VulkanWindowBackend::VulkanWindowBackend(VulkanWindowBackend&&) noexcept = default;
VulkanWindowBackend& VulkanWindowBackend::operator=(VulkanWindowBackend&&) noexcept = default;

const BackendCapabilities& VulkanWindowBackend::capabilities() const noexcept
{
    return implementation_->capabilities;
}

TextureHandle VulkanWindowBackend::create_texture(const TextureUpload& upload)
{
    if (implementation_->next_texture_handle == std::numeric_limits<std::uint32_t>::max())
        throw std::overflow_error("texture handle space exhausted");
    if (implementation_->textures.size() + 1 >= kMaxTextureCount)
        throw std::overflow_error("Vulkan texture descriptor pool is full");

    const TextureHandle handle{implementation_->next_texture_handle++};
    auto resource = implementation_->create_texture_resource(upload);
    try {
        const auto [iterator, inserted] = implementation_->textures.emplace(handle.value, resource);
        static_cast<void>(iterator);
        if (!inserted)
            throw std::logic_error("duplicate Vulkan texture handle");
        resource = {};
        return handle;
    } catch (...) {
        implementation_->destroy_texture_resource(resource);
        throw;
    }
}

void VulkanWindowBackend::destroy_texture(const TextureHandle texture)
{
    if (!texture)
        return;
    const auto found = implementation_->textures.find(texture.value);
    if (found == implementation_->textures.end())
        throw std::invalid_argument("unknown texture handle");
    check(vkDeviceWaitIdle(implementation_->device), "vkDeviceWaitIdle(texture destruction)");
    implementation_->destroy_texture_resource(found->second);
    implementation_->textures.erase(found);
}

void VulkanWindowBackend::update_texture(
    const TextureHandle texture,
    const TextureUpload& upload)
{
    if (!texture)
        throw std::invalid_argument("the backend-owned white texture cannot be updated");
    const auto found = implementation_->textures.find(texture.value);
    if (found == implementation_->textures.end())
        throw std::invalid_argument("unknown texture handle");

    check(vkDeviceWaitIdle(implementation_->device), "vkDeviceWaitIdle(texture update)");
    auto replacement = implementation_->create_texture_resource(upload);
    auto old = std::exchange(found->second, replacement);
    implementation_->destroy_texture_resource(old);
}

void VulkanWindowBackend::resize(const std::uint32_t pixel_width, const std::uint32_t pixel_height)
{
    implementation_->resize(pixel_width, pixel_height);
}

void VulkanWindowBackend::submit(const FramePacket& frame)
{
    implementation_->submit(frame);
}

void VulkanWindowBackend::wait_idle()
{
    check(vkDeviceWaitIdle(implementation_->device), "vkDeviceWaitIdle");
}

bool VulkanWindowBackend::poll_events()
{
    return implementation_->poll_events();
}

bool VulkanWindowBackend::should_close() const noexcept
{
    return implementation_->close_requested;
}

PixelExtent VulkanWindowBackend::pixel_extent() const noexcept
{
    return implementation_->client_extent();
}

void VulkanWindowBackend::request_capture()
{
    implementation_->capture_requested = true;
}

std::optional<CapturedFrame> VulkanWindowBackend::take_capture()
{
    auto capture = std::move(implementation_->captured_frame);
    implementation_->captured_frame.reset();
    return capture;
}

std::uint64_t VulkanWindowBackend::presented_frames() const noexcept
{
    return implementation_->presented_frame_count;
}

std::uint64_t VulkanWindowBackend::swapchain_recreations() const noexcept
{
    return implementation_->swapchain_recreation_count;
}

std::uint32_t VulkanWindowBackend::validation_error_count() const noexcept
{
    return implementation_->validation_errors.load(std::memory_order_relaxed);
}

} // namespace pvz::render::vulkan
