#pragma once

#include <cstdint>
#include <optional>

namespace pvz::render {

struct Point2D {
    double x{0.0};
    double y{0.0};
};

struct Extent2D {
    double width{0.0};
    double height{0.0};
};

struct Rect2D {
    Point2D origin;
    Extent2D extent;
};

struct ViewportPolicy {
    double logical_height{600.0};
    double minimum_logical_width{800.0};
    double maximum_logical_width{1068.0};
};

class ViewportTransform {
public:
    [[nodiscard]] static ViewportTransform create(
        std::uint32_t pixel_width,
        std::uint32_t pixel_height,
        ViewportPolicy policy = {});

    [[nodiscard]] Extent2D logical_extent() const noexcept;
    [[nodiscard]] Rect2D pixel_viewport() const noexcept;
    [[nodiscard]] double pixels_per_logical_unit() const noexcept;
    [[nodiscard]] bool is_width_clamped() const noexcept;

    [[nodiscard]] Point2D logical_to_pixel(Point2D logical) const noexcept;
    [[nodiscard]] std::optional<Point2D> pixel_to_logical(Point2D pixel) const noexcept;

private:
    Extent2D logical_extent_;
    Rect2D pixel_viewport_;
    double scale_{1.0};
    bool width_clamped_{false};
};

} // namespace pvz::render
