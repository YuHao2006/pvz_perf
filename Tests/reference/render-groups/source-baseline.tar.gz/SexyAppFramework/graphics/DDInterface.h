#ifndef __DDINTERFACE_H__
#define __DDINTERFACE_H__

#include "Common.h"
#include "misc/CritSect.h"
#include "NativeDisplay.h"
#include "misc/Rect.h"
#include "misc/Ratio.h"

namespace Sexy
{

class SexyAppBase;
class DDImage;
class Image;
class MemoryImage;
class D3DInterface;
class D3DTester;

typedef std::set<DDImage*> DDImageSet;

// Display interface without DirectDraw: owns the window sizing, screen image,
// refresh rate and cursor state, and forwards all drawing to the D3D11
// renderer through D3DInterface. No compatibility layer, no surfaces.
class DDInterface : public NativeDisplay
{
public:
	enum
	{
		RESULT_OK					= 0,
		RESULT_FAIL					= 1,
		RESULT_DD_CREATE_FAIL		= 2,
		RESULT_SURFACE_FAIL			= 3,
		RESULT_EXCLUSIVE_FAIL		= 4,
		RESULT_DISPCHANGE_FAIL		= 5,
		RESULT_INVALID_COLORDEPTH	= 6,
		RESULT_3D_FAIL				= 7
	};

	SexyAppBase*			mApp;
	D3DInterface*			mD3DInterface;
	D3DTester*				mD3DTester;
	bool					mIs3D;

	CritSect				mCritSect;
	bool					mInRedraw;
	int						mWidth;
	int						mHeight;
	Ratio					mAspect;
	int						mDesktopWidth;
	int						mDesktopHeight;
	Ratio					mDesktopAspect;
	bool					mIsWidescreen;
	int						mDisplayWidth;
	int						mDisplayHeight;
	Ratio					mDisplayAspect;

	Rect					mPresentationRect;
	// The visible game rectangle inside mPresentationRect (4:3 fit, centered),
	// used to remap mouse input so letterbox bars never map into game space.
	Rect					mVisibleGameRect;
	// Fullscreen output rect, centered on the desktop. The D3D11 present pass
	// and mouse remap use this instead of the whole back buffer so a configured
	// output smaller than the desktop letterboxes with black bars.
	Rect					mFullscreenOutputRect;
	int						mFullscreenBits;
	DWORD					mRefreshRate;
	DWORD					mMillisecondsPerFrame;
	int						mScanLineFailCount;

	int*					mRedAddTable;
	int*					mGreenAddTable;
	int*					mBlueAddTable;

	ulong					mRedConvTable[256];
	ulong					mGreenConvTable[256];
	ulong					mBlueConvTable[256];

	bool					mInitialized;
	HWND					mHWnd;
	bool					mIsWindowed;
	DDImage*				mScreenImage;
	DDImageSet				mDDImageSet;
	bool					mVideoOnlyDraw;
	ulong					mInitCount;

	int						mCursorWidth;
	int						mCursorHeight;
	int						mNextCursorX;
	int						mNextCursorY;
	int						mCursorX;
	int						mCursorY;
	Image*					mCursorImage;
	bool					mHasOldCursorArea;

	std::string				mErrorString;

public:
	ulong					GetColorRef(ulong theRGB);
	void					AddDDImage(DDImage* theDDImage);
	void					RemoveDDImage(DDImage* theDDImage);
	void					Remove3DData(MemoryImage* theImage);

	void					Cleanup();
	bool					GotDXError(HRESULT theResult, const char *theContext = "");
	bool					Do3DTest(HWND theHWND);

public:
	DDInterface(SexyAppBase* theApp);
	virtual ~DDInterface();

	static std::string		ResultToString(int theResult);

	DDImage*				GetScreenImage();
	void					SetVideoOnlyDraw(bool videoOnlyDraw);
	void					SetCursorPos(int theX, int theY);
	bool					SetCursorImage(Image* theImage);
	bool					Redraw(Rect* theClipRect);
	void					RemapMouse(int& theX, int& theY);
	int						Init(HWND theWindow, bool IsWindowed);
	// Window/fullscreen or custom-scale change without recreating the window
	// or the D3D11 device: recompute the layout and resize the swapchain.
	int						ApplyScreenMode(HWND theWindow, bool wantWindowed);
};

}

#endif //__DDINTERFACE_H__
