#include "pvz/render/vulkan/vulkan_instance.hpp"

#include <vulkan/vulkan_core.h>

#include <cstdint>
#include <exception>
#include <iomanip>
#include <iostream>

namespace {

void print_version(const std::uint32_t version)
{
    std::cout << VK_API_VERSION_MAJOR(version) << '.'
              << VK_API_VERSION_MINOR(version) << '.'
              << VK_API_VERSION_PATCH(version);
}

} // namespace

int main()
{
    try {
        const pvz::render::vulkan::VulkanInstance instance;
        std::cout << "loader_api=";
        print_version(instance.loader_api_version());
        std::cout << "\ninstance_api=";
        print_version(instance.instance_api_version());
        std::cout << "\nphysical_devices=" << instance.physical_devices().size() << '\n';

        for (const auto& device : instance.physical_devices()) {
            std::cout << "device=" << device.name << "\n  api=";
            print_version(device.api_version);
            std::cout << "\n  vendor=0x" << std::hex << device.vendor_id
                      << " device=0x" << device.device_id << std::dec
                      << "\n  type=" << device.device_type
                      << "\n  max_texture_2d=" << device.max_texture_dimension_2d << '\n';
        }
        return instance.physical_devices().empty() ? 1 : 0;
    } catch (const std::exception& error) {
        std::cerr << "pvz_vulkan_probe: " << error.what() << '\n';
        return 1;
    }
}
