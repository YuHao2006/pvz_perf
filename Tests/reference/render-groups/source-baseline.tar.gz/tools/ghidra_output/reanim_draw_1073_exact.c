/* 00477490 FUN_00477490 */

void FUN_00477490(void)

{
  undefined4 unaff_ESI;
  
  FUN_00477550(unaff_ESI,0);
  FUN_00477550(unaff_ESI,1);
  FUN_00477550(unaff_ESI,2);
  FUN_00477550(unaff_ESI,3);
  FUN_00477550(unaff_ESI,4);
  FUN_00477550(unaff_ESI,5);
  FUN_00477550(unaff_ESI,6);
  FUN_00477550(unaff_ESI,7);
  FUN_00477550(unaff_ESI,8);
  FUN_00477550(unaff_ESI,9);
  FUN_00477550(unaff_ESI,10);
  FUN_00477550(unaff_ESI,0xb);
  FUN_00477550(unaff_ESI,0xc);
  FUN_00477550(unaff_ESI,0xd);
  FUN_00477550(unaff_ESI,0xe);
  FUN_00477550(unaff_ESI,0xf);
  FUN_00477550(unaff_ESI,0x10);
  FUN_00477550(unaff_ESI,0x11);
  return;
}



/* 00477550 FUN_00477550 */

/* WARNING: Function: __alloca_probe replaced with injection: alloca_probe */

void __thiscall FUN_00477550(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  int local_3c20;
  int local_3c1c;
  undefined1 local_3c18 [15372];
  undefined4 uStack_c;
  
  uStack_c = 0x477560;
  if (*(char *)(param_1 + 0x14) == '\0') {
    FUN_00448dd0();
    local_3c1c = 0;
    if (0 < *(int *)(*(int *)(param_1 + 0xc) + 4)) {
      local_3c20 = 0;
      do {
        iVar3 = *(int *)(param_1 + 0x58) + local_3c20;
        if (*(int *)(iVar3 + 0x48) == param_3) {
          cVar2 = FUN_004769b0(param_1,param_2,local_3c1c,local_3c18);
          if (*(int *)(iVar3 + 0x40) != 0) {
            FUN_00448e10(param_2);
            uVar1 = *(uint *)(iVar3 + 0x40);
            if (uVar1 != 0) {
              if (((uVar1 & 0xffff) < (uint)(*(int **)(DAT_00729668 + 0xc))[2]) &&
                 (*(uint *)((uVar1 & 0xffff) * 0x30c + **(int **)(DAT_00729668 + 0xc) + 0x308) ==
                  uVar1)) {
                FUN_00405980(param_2,cVar2 == '\0');
              }
            }
          }
        }
        local_3c20 = local_3c20 + 0x60;
        local_3c1c = local_3c1c + 1;
      } while (local_3c1c < *(int *)(*(int *)(param_1 + 0xc) + 4));
    }
    FUN_00448e10(param_2);
  }
  return;
}



