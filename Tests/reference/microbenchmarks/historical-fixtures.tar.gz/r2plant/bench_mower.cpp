// bench_mower.cpp — LawnMower.cpp 1 目标段表性能对拍（第二轮补测）
//   #19 kMowerPoolCases 4 -> LawnMower::UpdatePool（命名空间级 constexpr，照抄 HEAD）
// FormA = 403c1968^ 原函数（4 支 if-else 高度链）。
#include "r2_stub.h"

inline unsigned Rand(unsigned n) { MixCk(0x1090ULL, n); return n ? RngNext() % n : 0u; }

#define MOWER_MEMBERS                                                            \
    float mPosX = 100.0f, mPosY = 200.0f, mAltitude = 0.0f;                      \
    MowerHeight mMowerHeight = MOWER_HEIGHT_LAND;                                \
    LawnMowerType mMowerType = LAWNMOWER_POOL;                                   \
    int mRenderOrder = 500000;                                                   \
    int mReanimID = 2;                                                           \
    int mChompCounter = 0;                                                       \
    LawnApp* mApp = &g_app;                                                      \
    Board* mBoard = &g_board;                                                    \
                                                                                  \
    __declspec(noinline) void UpdatePool();

// ================================================================= FormA
namespace FA {

struct LawnMower
{
    MOWER_MEMBERS
};

// ---- #19 UpdatePool（A：4 支高度链）
void LawnMower::UpdatePool()
{
    bool isPoolRange = false;
    if (mPosX > 26.0f && mPosX < 660.0f)
    {
        isPoolRange = true;
    }

    Reanimation* aMowerReanim = mApp->ReanimationGet(mReanimID);
    if (isPoolRange && mMowerHeight == MowerHeight::MOWER_HEIGHT_LAND)
    {
        Reanimation* aSplashReanim = mApp->AddReanimation(mPosX + 0.0f, mPosY + 25.0f, mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
        aSplashReanim->OverrideScale(1.2f, 0.8f);
        mApp->AddTodParticle(mPosX + 0.0f + 50.0f, mPosY + 0.0f + 42.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
        mApp->PlayFoley(FoleyType::FOLEY_ZOMBIESPLASH);
        mMowerHeight = MowerHeight::MOWER_HEIGHT_DOWN_TO_POOL;
    }
    else if (mMowerHeight == MowerHeight::MOWER_HEIGHT_DOWN_TO_POOL)
    {
        mAltitude -= 2.0f;
        if (mAltitude <= -28.0f)
        {
            mAltitude = 0.0f;
            mMowerHeight = MowerHeight::MOWER_HEIGHT_IN_POOL;
            aMowerReanim->PlayReanim(ReanimTrackId::anim_water, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
        }
    }
    else if (mMowerHeight == MowerHeight::MOWER_HEIGHT_IN_POOL)
    {
        if (!isPoolRange)
        {
            mAltitude = -28.0f;
            mMowerHeight = MowerHeight::MOWER_HEIGHT_UP_TO_LAND;
            Reanimation* aSplashReanim = mApp->AddReanimation(mPosX + 0.0f, mPosY + 25.0f, mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
            aSplashReanim->OverrideScale(1.2f, 0.8f);
            mApp->AddTodParticle(mPosX + 0.0f + 50.0f, mPosY + 0.0f + 42.0f, mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
            mApp->PlayFoley(FoleyType::FOLEY_PLANT_WATER);
            aMowerReanim->PlayReanim(ReanimTrackId::anim_land, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
        }
    }
    else if (mMowerHeight == MowerHeight::MOWER_HEIGHT_UP_TO_LAND)
    {
        mAltitude += 2.0f;
        if (mAltitude >= 0.0f)
        {
            mAltitude = 0.0f;
            mMowerHeight = MowerHeight::MOWER_HEIGHT_LAND;
        }
    }

    if (mMowerHeight == MowerHeight::MOWER_HEIGHT_IN_POOL && aMowerReanim->mLoopType == ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD && aMowerReanim->mLoopCount > 0)
    {
        aMowerReanim->PlayReanim(ReanimTrackId::anim_water, ReanimLoopType::REANIM_LOOP, 10, 35.0f);
    }
}

} // namespace FA

// ================================================================= FormB
namespace FB {

struct LawnMower
{
    MOWER_MEMBERS
};

namespace
{
// LawnMower::UpdatePool 分发表：isPoolRange 与 aMowerReanim 经参传入。
using MowerPoolFn = void (*)(LawnMower&, bool, Reanimation*);

// 匿名 lambda 函数指针表，行序 = MowerHeight 枚举值序（0..3）。
constexpr MowerPoolFn kMowerPoolCases[(int)MowerHeight::MOWER_HEIGHT_UP_TO_LAND + 1] = {
    [](LawnMower& m, bool isPoolRange, Reanimation* aMowerReanim)
    {
        (void)aMowerReanim;
        if (isPoolRange)
        {
            Reanimation* aSplashReanim = m.mApp->AddReanimation(m.mPosX + 0.0f, m.mPosY + 25.0f, m.mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
            aSplashReanim->OverrideScale(1.2f, 0.8f);
            m.mApp->AddTodParticle(m.mPosX + 0.0f + 50.0f, m.mPosY + 0.0f + 42.0f, m.mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
            m.mApp->PlayFoley(FoleyType::FOLEY_ZOMBIESPLASH);
            m.mMowerHeight = MowerHeight::MOWER_HEIGHT_DOWN_TO_POOL;
        }
    },  // 0 MOWER_HEIGHT_LAND
    [](LawnMower& m, bool isPoolRange, Reanimation* aMowerReanim)
    {
        (void)isPoolRange;
        m.mAltitude -= 2.0f;
        if (m.mAltitude <= -28.0f)
        {
            m.mAltitude = 0.0f;
            m.mMowerHeight = MowerHeight::MOWER_HEIGHT_IN_POOL;
            aMowerReanim->PlayReanim(ReanimTrackId::anim_water, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
        }
    },  // 1 MOWER_HEIGHT_DOWN_TO_POOL
    [](LawnMower& m, bool isPoolRange, Reanimation* aMowerReanim)
    {
        if (!isPoolRange)
        {
            m.mAltitude = -28.0f;
            m.mMowerHeight = MowerHeight::MOWER_HEIGHT_UP_TO_LAND;
            Reanimation* aSplashReanim = m.mApp->AddReanimation(m.mPosX + 0.0f, m.mPosY + 25.0f, m.mRenderOrder + 1, ReanimationType::REANIM_SPLASH);
            aSplashReanim->OverrideScale(1.2f, 0.8f);
            m.mApp->AddTodParticle(m.mPosX + 0.0f + 50.0f, m.mPosY + 0.0f + 42.0f, m.mRenderOrder + 1, ParticleEffect::PARTICLE_PLANTING_POOL);
            m.mApp->PlayFoley(FoleyType::FOLEY_PLANT_WATER);
            aMowerReanim->PlayReanim(ReanimTrackId::anim_land, ReanimLoopType::REANIM_LOOP, 0, 0.0f);
        }
    },  // 2 MOWER_HEIGHT_IN_POOL
    [](LawnMower& m, bool isPoolRange, Reanimation* aMowerReanim)
    {
        (void)isPoolRange;
        (void)aMowerReanim;
        m.mAltitude += 2.0f;
        if (m.mAltitude >= 0.0f)
        {
            m.mAltitude = 0.0f;
            m.mMowerHeight = MowerHeight::MOWER_HEIGHT_LAND;
        }
    },  // 3 MOWER_HEIGHT_UP_TO_LAND
};
static_assert(sizeof(kMowerPoolCases) / sizeof(kMowerPoolCases[0]) ==
    (int)MowerHeight::MOWER_HEIGHT_UP_TO_LAND + 1, "kMowerPoolCases 槽位数须与 MowerHeight 枚举同步");
}

// ---- #19 UpdatePool（B：kMowerPoolCases 4 槽，命名空间级 constexpr——照抄）
void LawnMower::UpdatePool()
{
    bool isPoolRange = false;
    if (mPosX > 26.0f && mPosX < 660.0f)
    {
        isPoolRange = true;
    }

    Reanimation* aMowerReanim = mApp->ReanimationGet(mReanimID);

    // C 形态 -> 匿名 lambda 表（上方 kMowerPoolCases）
    const unsigned aHeightIndex = static_cast<unsigned>(mMowerHeight);
    if (aHeightIndex <= static_cast<unsigned>(MowerHeight::MOWER_HEIGHT_UP_TO_LAND))
    {
        kMowerPoolCases[aHeightIndex](*this, isPoolRange, aMowerReanim);
    }

    if (mMowerHeight == MowerHeight::MOWER_HEIGHT_IN_POOL && aMowerReanim->mLoopType == ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD && aMowerReanim->mLoopCount > 0)
    {
        aMowerReanim->PlayReanim(ReanimTrackId::anim_water, ReanimLoopType::REANIM_LOOP, 10, 35.0f);
    }
}

} // namespace FB

// ================================================================= 驱动
static FA::LawnMower g_objA[NOBJ], g_pristineA[NOBJ];
static FB::LawnMower g_objB[NOBJ], g_pristineB[NOBJ];
static In g_in[NIN];

void A_Pool(FA::LawnMower* m) { m->UpdatePool(); }
void B_Pool(FB::LawnMower* m) { m->UpdatePool(); }

int main()
{
    InitZombiePool();
    gSexyAppBase = &g_app;

    printf("%-30s | %19s | %19s | %8s | %s\n", "target(LawnMower)", "A ns r1/r2", "B ns r1/r2", "diff%", "checksum A/B");

    // ---- #19 UpdatePool：mMowerHeight 0..3 均匀 + mPosX 0..760（isPoolRange 混合）+ 高度混合
    GenInputs(g_in, NIN, 0xC001, 4, 61, 32, 8);
    {
        auto prepA = [](FA::LawnMower& m, const In& in) {
            m.mMowerHeight = (MowerHeight)in.a;
            m.mPosX = (float)(in.b * 12.5f);
            m.mAltitude = (float)(in.c) - 16.0f;
            m.mPosY = 200.0f + in.d * 10;
            m.mRenderOrder = 500000;
            m.mReanimID = in.d;
        };
        auto prepB = [](FB::LawnMower& m, const In& in) {
            m.mMowerHeight = (MowerHeight)in.a;
            m.mPosX = (float)(in.b * 12.5f);
            m.mAltitude = (float)(in.c) - 16.0f;
            m.mPosY = 200.0f + in.d * 10;
            m.mRenderOrder = 500000;
            m.mReanimID = in.d;
        };
        RunTarget("19 kMowerPoolCases 4", A_Pool, B_Pool,
            g_objA, g_pristineA, prepA, g_objB, g_pristineB, prepB, g_in, NIN);
    }

    return 0;
}
