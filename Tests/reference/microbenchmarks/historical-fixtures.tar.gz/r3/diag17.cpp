// diag17.cpp — t17 checksum 分歧定位：逐迭代 A/B sink 对比
#include "r3_entities.h"

// 直接 include t17 的两形态（其 main 会跑）不行——改为复制最小诊断。
// 做法：把 t17 的形态函数用 #include 文本纳入，跳过其 main。
#define main t17_main_unused
#include "t17_store.cpp"
#undef main

int main()
{
    g_store.mApp = &g_app;
    g_app.mPlayerInfo = &g_pi;
    g_app.mWidgetManager = &g_wm;
    g_store.mBackButton = &g_back;
    g_store.mPrevButton = &g_prev;
    g_store.mNextButton = &g_next;
    for (int i = 0; i < 128; i++) g_pi.mPurchases[i] = i % 4;
    R3InitInputs();
    int diverge = 0;
    for (uint32_t i = 0; i < 256; i++)
    {
        int aPos = (int)(g_inputs[i].a % 26); if (aPos >= 21) aPos += 1;
        g_wm.mLastMouseX = 30 + (aPos % 6) * 90 + (int)(g_inputs[i].b % 50);
        g_wm.mLastMouseY = 100 + (aPos / 6) * 100 + (int)(g_inputs[i].c % 87);
        uint64_t sA, sB;
        g_sink = 0; ZBRngReset();
        g_store.mMouseOverItem = STORE_ITEM_INVALID; g_store.mBubbleCountDown = 0;
        g_store.UpdateMouse_A(); sA = g_sink;
        g_sink = 0; ZBRngReset();
        g_store.mMouseOverItem = STORE_ITEM_INVALID; g_store.mBubbleCountDown = 0;
        g_store.UpdateMouse_B(); sB = g_sink;
        if (sA != sB)
        {
            if (diverge < 6)
                printf("diverge i=%u aPos=%d hitItem=%d sA=%016llx sB=%016llx\n",
                    i, aPos, (int)g_store.mMouseOverItem,
                    (unsigned long long)sA, (unsigned long long)sB);
            diverge++;
        }
    }
    printf("total diverge=%d/256\n", diverge);
    return 0;
}
