#pragma once

#include "pvz/render/backend.hpp"

#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace pvz::render::vulkan {

struct VulkanWindowConfig {
    std::string title{"Modern PvZ Vulkan"};
    std::uint32_t pixel_width{1068};
    std::uint32_t pixel_height{600};
    bool visible{true};
    bool enable_validation{false};
    bool vertical_sync{true};
};

struct PixelExtent {
    std::uint32_t width{0};
    std::uint32_t height{0};
};

struct CapturedFrame {
    PixelExtent extent;
    std::vector<std::uint8_t> rgba8;
};

class VulkanWindowBackend final : public IRenderBackend {
public:
    VulkanWindowBackend(
        VulkanWindowConfig config,
        std::filesystem::path vertex_shader,
        std::filesystem::path fragment_shader);
    ~VulkanWindowBackend() override;

    VulkanWindowBackend(VulkanWindowBackend&&) noexcept;
    VulkanWindowBackend& operator=(VulkanWindowBackend&&) noexcept;
    VulkanWindowBackend(const VulkanWindowBackend&) = delete;
    VulkanWindowBackend& operator=(const VulkanWindowBackend&) = delete;

    [[nodiscard]] const BackendCapabilities& capabilities() const noexcept override;
    [[nodiscard]] TextureHandle create_texture(const TextureUpload& upload) override;
    void update_texture(TextureHandle texture, const TextureUpload& upload) override;
    void destroy_texture(TextureHandle texture) override;
    void resize(std::uint32_t pixel_width, std::uint32_t pixel_height) override;
    void submit(const FramePacket& frame) override;
    void wait_idle() override;

    [[nodiscard]] bool poll_events();
    [[nodiscard]] bool should_close() const noexcept;
    [[nodiscard]] PixelExtent pixel_extent() const noexcept;
    void request_capture();
    [[nodiscard]] std::optional<CapturedFrame> take_capture();
    [[nodiscard]] std::uint64_t presented_frames() const noexcept;
    [[nodiscard]] std::uint64_t swapchain_recreations() const noexcept;
    [[nodiscard]] std::uint32_t validation_error_count() const noexcept;

private:
    struct Implementation;
    std::unique_ptr<Implementation> implementation_;
};

} // namespace pvz::render::vulkan
