
void __thiscall FUN_0054c6c0(int *param_1,undefined4 *param_2)

{
  (**(code **)(*param_1 + 0xa0))(*param_2,param_2[1],param_2[2],param_2[3]);
  return;
}

