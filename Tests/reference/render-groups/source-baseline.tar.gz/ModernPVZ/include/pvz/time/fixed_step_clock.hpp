#pragma once

#include <chrono>
#include <cstdint>

namespace pvz::time {

struct ClockConfig {
    std::uint32_t simulation_hz{200};
    std::uint32_t semantic_hz{100};
    std::uint32_t max_steps_per_advance{64};
    std::chrono::nanoseconds max_frame_delta{std::chrono::milliseconds{250}};
};

struct StepBatch {
    std::uint64_t first_tick{0};
    std::uint32_t tick_count{0};
    std::uint32_t ticks_per_semantic_tick{1};
    std::uint32_t semantic_phase{0};
    double interpolation_alpha{0.0};
    std::chrono::nanoseconds discarded_time{0};

    [[nodiscard]] bool is_semantic_tick(std::uint32_t batch_offset) const noexcept;
};

class FixedStepClock {
public:
    explicit FixedStepClock(ClockConfig config = {});

    [[nodiscard]] StepBatch advance(std::chrono::nanoseconds elapsed);
    // Rate changes are only valid at a completed semantic boundary.
    void set_simulation_rate(std::uint32_t simulation_hz);
    void reset() noexcept;

    [[nodiscard]] const ClockConfig& config() const noexcept;
    [[nodiscard]] std::chrono::nanoseconds tick_interval() const noexcept;
    [[nodiscard]] std::uint64_t total_ticks() const noexcept;
    [[nodiscard]] std::chrono::nanoseconds total_discarded_time() const noexcept;

private:
    ClockConfig config_;
    std::chrono::nanoseconds tick_interval_;
    std::chrono::nanoseconds accumulator_{0};
    std::chrono::nanoseconds total_discarded_time_{0};
    std::uint64_t total_ticks_{0};
    std::uint32_t semantic_phase_{0};
};

[[nodiscard]] bool is_supported_simulation_rate(std::uint32_t hz) noexcept;

} // namespace pvz::time
