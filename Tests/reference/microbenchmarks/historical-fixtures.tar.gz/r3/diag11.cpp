// diag11.cpp — b11 SetTutorialState 分歧定位：逐 TutorialState 值 A/B sink 对比
#define main b_board_main_unused
#include "b_board_events.cpp"
#undef main

static uint64_t RunB11A()
{
    uint64_t ck = 0;
    for (uint32_t i = 0; i < 2097152; i++)
    {
        ResetBoard(g_inputs[i]);
        g_board.SetTutorialState_A((TutorialState)(g_inputs[i].a % 31));
        ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown));
    }
    return ZBMixU64(ck, g_sink);
}
static uint64_t RunB11B()
{
    uint64_t ck = 0;
    for (uint32_t i = 0; i < 2097152; i++)
    {
        ResetBoard(g_inputs[i]);
        g_board.SetTutorialState_B((TutorialState)(g_inputs[i].a % 31));
        ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown));
    }
    return ZBMixU64(ck, g_sink);
}

int main()
{
    R3InitInputs();
    ZBInitImages(); R3InitZombieDefs();
    // 记录式序列对拍：各自跑完 2M，逐位比对折叠流
    {
        static uint64_t f[2][2097152];
        for (int mode = 0; mode < 2; mode++)
        {
            ResetBoard(g_inputs[0]);
            for (uint32_t i = 0; i < 2097152; i++)
            {
                ResetBoard(g_inputs[i]);
                if (mode == 0) g_board.SetTutorialState_A((TutorialState)(g_inputs[i].a % 31));
                else g_board.SetTutorialState_B((TutorialState)(g_inputs[i].a % 31));
                f[mode][i] = (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown);
            }
        }
        for (uint32_t i = 0; i < 2097152; i++)
        {
            if (f[0][i] != f[1][i])
            {
                printf("FD i=%u state=%d fA=%llx fB=%llx", i, (int)(g_inputs[i].a % 31), (unsigned long long)f[0][i], (unsigned long long)f[1][i]);
                break;
            }
        }
    }
    {
        uint64_t hA = 0, hB = 0;
        int firstDiff = -1;
        for (uint32_t i = 0; i < 2097152; i++)
        {
            ResetBoard(g_inputs[i]);
            g_board.SetTutorialState_A((TutorialState)(g_inputs[i].a % 31));
            uint64_t fA = (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown);
            int timerA = g_board.mTutorialTimer, sunA = g_board.mSunCountDown;
            ResetBoard(g_inputs[i]);
            g_board.SetTutorialState_B((TutorialState)(g_inputs[i].a % 31));
            uint64_t fB = (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown);
            if (fA != fB && firstDiff < 0)
            {
                firstDiff = (int)i;
                printf("FD i=%u state=%d prevTimer=%d prevSun=%d tA=%d tB=%d sA=%d sB=%d", i, (int)(g_inputs[i].a % 31), g_board.mTutorialTimer, g_board.mSunCountDown, timerA, g_board.mTutorialTimer, sunA, g_board.mSunCountDown);
                break;
            }
        }
        printf("firstDiff=%d", firstDiff);
    }
    g_sink = 0; ZBRngReset(); ResetBoard(g_inputs[0]);
    uint64_t a1 = RunB11A();
    g_sink = 0; ZBRngReset(); ResetBoard(g_inputs[0]);
    uint64_t b1 = RunB11B();
    printf("A=%llx B=%llx %s", (unsigned long long)a1, (unsigned long long)b1, a1 == b1 ? "EQ" : "DIFF");
    return 0;
#if 0
    {

        uint64_t hA = 0, hB = 0;
        for (uint32_t i = 0; i < 2097152; i++)
        {
            ResetBoard(g_inputs[i]);
            g_board.SetTutorialState_A((TutorialState)(g_inputs[i].a % 31));
            hA = ZBMixU64(hA, (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown));
            hA = ZBMixU64(hA, g_sink);
            uint64_t stA1 = (uint64_t)(uint32_t)g_board.mTutorialState;
            ResetBoard(g_inputs[i]);
            g_board.SetTutorialState_B((TutorialState)(g_inputs[i].a % 31));
            hB = ZBMixU64(hB, (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown));
            hB = ZBMixU64(hB, g_sink);
            if (hA != hB)
            {
                printf("FD i=%d state=%d mSize=%d wave=%d timerA=%d", i, (int)(g_inputs[i].a % 31), (int)(g_inputs[i].b % 3), (int)(g_inputs[i].c % 3), g_board.mTutorialTimer);
                break;
            }
        }
        printf("SEQ hA=%llx hB=%llx", (unsigned long long)hA, (unsigned long long)hB);
    }
    for (int t = 0; t <= 30; t++)
    {
        uint64_t sA, sB;
        ResetBoard(g_inputs[5]);
        g_sink = 0; ZBRngReset();
        g_board.SetTutorialState_A((TutorialState)t); sA = g_sink;
        uint64_t stA = (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown);
        ResetBoard(g_inputs[5]);
        g_sink = 0; ZBRngReset();
        g_board.SetTutorialState_B((TutorialState)t); sB = g_sink;
        uint64_t stB = (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown);
        if (sA != sB || stA != stB)
            printf("diverge t=%d sA=%llx sB=%llx\n", t, (unsigned long long)sA, (unsigned long long)sB);
    }
    printf("done\n");
    return 0;
}

#endif
}
