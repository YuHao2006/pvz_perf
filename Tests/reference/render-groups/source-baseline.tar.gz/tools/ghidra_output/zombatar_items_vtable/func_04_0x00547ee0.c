
void __thiscall FUN_00547ee0(int param_1,int param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined1 local_40 [8];
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined1 local_28 [4];
  undefined4 local_24;
  undefined1 local_20 [8];
  undefined4 local_18;
  undefined4 local_14;
  char local_d;
  undefined4 local_c;
  undefined4 local_8;
  
  uVar4 = *(undefined4 *)(param_1 + 0x18);
  FUN_00420ae0();
  local_14 = uVar4;
  if (param_1 == -4) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  puVar5 = &param_2;
  uVar4 = local_14;
  puVar3 = (undefined4 *)FUN_005b75d0(local_20);
  FUN_0055a680(&local_c,*puVar3,puVar3[1],local_18,uVar4,puVar5);
  uVar4 = *(undefined4 *)(param_1 + 0x18);
  FUN_00420ae0();
  local_24 = uVar4;
  if (param_1 == -4) {
    FUN_0069a6f2();
  }
  FUN_0040a150();
  cVar2 = FUN_006143c0(local_28);
  if (cVar2 == '\0') {
    FUN_0054c050();
    *(undefined4 *)(param_2 + 0x24) = 0;
    local_d = FUN_006143c0(param_1 + 0x2c);
    uVar1 = local_8;
    uVar4 = local_c;
    FUN_00614350();
    local_38 = uVar4;
    local_34 = uVar1;
    local_30 = uVar4;
    local_2c = uVar1;
    FUN_00556e50(local_40,uVar4,uVar1);
    if (local_d != '\0') {
      *(undefined4 *)(param_1 + 0x2c) = local_c;
      *(undefined4 *)(param_1 + 0x30) = local_8;
      *(undefined1 *)(param_1 + 0x28) = 1;
    }
  }
  return;
}

