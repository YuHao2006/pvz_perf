// b_board_events.cpp — Board.cpp 事件表批测：
//   b09 kDoorBottom+kDoorTop      -> DrawHouseDoorBottom/Top（结算期每帧）
//   b10 kPickUpToolCases          -> PickUpTool（事件）
//   b11 kTutorialStateCases       -> SetTutorialState（事件）
//   b12 kUpgradeAdvice            -> MouseDownWithPlant 升级建议段（事件）
//   b13 kUpgradeBasisReqs         -> Met 升级前置谓词（事件；真原形=e0f71d8a^ switch，
//                                    表族经历 头文件表→具名函数→cpp 表三次重塑）
//   b15 kTreeWisdomCheatRecord    -> KeyChar 树智慧秘技段（按键）
// FormA = 各自表引入提交父版逐字；FormB = HEAD 逐字。
#include "r3_entities.h"

namespace Sexy { inline int SOUND_BUZZER = 3; }
static uint32_t g_curSeed = 0;   // b12 隔离对拍输入（种子型）

// ==================== b09 门表 ====================
namespace
{
struct DoorImageEntry
{
    Image* const* mImage;
    int mX;
    int mY;
};
constexpr DoorImageEntry kDoorBottom[7] = {
    { &Sexy::IMAGE_BACKGROUND1_GAMEOVER_INTERIOR_OVERLAY, -126, 225 },  // 0 BACKGROUND_1_DAY
    { &Sexy::IMAGE_BACKGROUND2_GAMEOVER_INTERIOR_OVERLAY, -125, 196 },  // 1 BACKGROUND_2_NIGHT
    { &Sexy::IMAGE_BACKGROUND3_GAMEOVER_INTERIOR_OVERLAY, -171, 241 },  // 2 BACKGROUND_3_POOL
    { &Sexy::IMAGE_BACKGROUND4_GAMEOVER_INTERIOR_OVERLAY, -172, 246 },  // 3 BACKGROUND_4_FOG
    { nullptr, 0, 0 },                                                   // 4 BACKGROUND_5_ROOF
    { nullptr, 0, 0 },                                                   // 5 BACKGROUND_6_BOSS
    { nullptr, 0, 0 },                                                   // 6 MUSHROOM_GARDEN（原 default）
};
constexpr DoorImageEntry kDoorTop[7] = {
    { &Sexy::IMAGE_BACKGROUND1_GAMEOVER_MASK, -130, 202 },  // 0 BACKGROUND_1_DAY
    { &Sexy::IMAGE_BACKGROUND2_GAMEOVER_MASK, -128, 207 },  // 1 BACKGROUND_2_NIGHT
    { &Sexy::IMAGE_BACKGROUND3_GAMEOVER_MASK, -172, 234 },  // 2 BACKGROUND_3_POOL
    { &Sexy::IMAGE_BACKGROUND4_GAMEOVER_MASK, -173, 133 },  // 3 BACKGROUND_4_FOG
    { &Sexy::IMAGE_BACKGROUND5_GAMEOVER_MASK, -220, 81 },   // 4 BACKGROUND_5_ROOF
    { &Sexy::IMAGE_BACKGROUND6_GAMEOVER_MASK, -220, 81 },   // 5 BACKGROUND_6_BOSS
    { nullptr, 0, 0 },                                      // 6 MUSHROOM_GARDEN（原 default）
};
static_assert(sizeof(kDoorBottom) / sizeof(kDoorBottom[0]) == 7 &&
    kDoorBottom[0].mImage == &Sexy::IMAGE_BACKGROUND1_GAMEOVER_INTERIOR_OVERLAY &&
    kDoorBottom[3].mImage == &Sexy::IMAGE_BACKGROUND4_GAMEOVER_INTERIOR_OVERLAY, "门底表锚点");
static_assert(sizeof(kDoorTop) / sizeof(kDoorTop[0]) == 7 &&
    kDoorTop[0].mImage == &Sexy::IMAGE_BACKGROUND1_GAMEOVER_MASK &&
    kDoorTop[5].mImage == &Sexy::IMAGE_BACKGROUND6_GAMEOVER_MASK, "门顶表锚点");
}  // namespace

// FormA：bcb6cfbc^ switch 逐字
__declspec(noinline) void Board::DrawHouseDoorBottom_A(Graphics* g)
{
    switch (mBackground)
    {
    case BackgroundType::BACKGROUND_1_DAY:		g->DrawImage(Sexy::IMAGE_BACKGROUND1_GAMEOVER_INTERIOR_OVERLAY, -126, 225);		break;
    case BackgroundType::BACKGROUND_2_NIGHT:	g->DrawImage(Sexy::IMAGE_BACKGROUND2_GAMEOVER_INTERIOR_OVERLAY, -125, 196);		break;
    case BackgroundType::BACKGROUND_3_POOL:		g->DrawImage(Sexy::IMAGE_BACKGROUND3_GAMEOVER_INTERIOR_OVERLAY, -171, 241);		break;
    case BackgroundType::BACKGROUND_4_FOG:		g->DrawImage(Sexy::IMAGE_BACKGROUND4_GAMEOVER_INTERIOR_OVERLAY, -172, 246);		break;
    default:																													break;
    }
}

__declspec(noinline) void Board::DrawHouseDoorTop_A(Graphics* g)
{
    switch (mBackground)
    {
    case BackgroundType::BACKGROUND_1_DAY:		g->DrawImage(Sexy::IMAGE_BACKGROUND1_GAMEOVER_MASK, -130, 202);		break;
    case BackgroundType::BACKGROUND_2_NIGHT:	g->DrawImage(Sexy::IMAGE_BACKGROUND2_GAMEOVER_MASK, -128, 207);		break;
    case BackgroundType::BACKGROUND_3_POOL:		g->DrawImage(Sexy::IMAGE_BACKGROUND3_GAMEOVER_MASK, -172, 234);		break;
    case BackgroundType::BACKGROUND_4_FOG:		g->DrawImage(Sexy::IMAGE_BACKGROUND4_GAMEOVER_MASK, -173, 133);		break;
    case BackgroundType::BACKGROUND_5_ROOF:		g->DrawImage(Sexy::IMAGE_BACKGROUND5_GAMEOVER_MASK, -220, 81);		break;
    case BackgroundType::BACKGROUND_6_BOSS:		g->DrawImage(Sexy::IMAGE_BACKGROUND6_GAMEOVER_MASK, -220, 81);		break;
    default:																										break;
    }
}

// FormB：HEAD 表（逐字）
__declspec(noinline) void Board::DrawHouseDoorBottom_B(Graphics* g)
{
    // B 形态 -> 常量表（见上 kDoorBottom）；无 case 背景/越界 = nullptr 不绘。
    if (static_cast<unsigned>(mBackground) < 7 && kDoorBottom[(int)mBackground].mImage != nullptr)
    {
        g->DrawImage(*kDoorBottom[(int)mBackground].mImage, kDoorBottom[(int)mBackground].mX, kDoorBottom[(int)mBackground].mY);
    }
}

__declspec(noinline) void Board::DrawHouseDoorTop_B(Graphics* g)
{
    // B 形态 -> 常量表（见上 kDoorTop）；无 case 背景/越界 = nullptr 不绘。
    if (static_cast<unsigned>(mBackground) < 7 && kDoorTop[(int)mBackground].mImage != nullptr)
    {
        g->DrawImage(*kDoorTop[(int)mBackground].mImage, kDoorTop[(int)mBackground].mX, kDoorTop[(int)mBackground].mY);
    }
}

// ==================== b10 PickUpTool ====================
// FormA：e44390a6^ switch 逐字
__declspec(noinline) void Board::PickUpTool_A(GameObjectType theObjectType)
{
    if (mPaused || (mApp->mGameScene != GameScenes::SCENE_PLAYING && !mCutScene->IsInShovelTutorial()))
        return;

    switch (theObjectType)
    {
    case GameObjectType::OBJECT_TYPE_SHOVEL:
        if (mTutorialState == TutorialState::TUTORIAL_SHOVEL_PICKUP)
        {
            SetTutorialStateStub(TutorialState::TUTORIAL_SHOVEL_DIG);
        }
        mCursorObject->mCursorType = CursorType::CURSOR_TYPE_SHOVEL;
        mApp->PlayFoley(FoleyType::FOLEY_SHOVEL);
        break;

    case GameObjectType::OBJECT_TYPE_WATERING_CAN:
        if (mTutorialState == TutorialState::TUTORIAL_ZEN_GARDEN_PICKUP_WATER)
        {
            mTutorialState = TutorialState::TUTORIAL_ZEN_GARDEN_WATER_PLANT;
            DisplayAdvice(gStr.ADVICE_ZEN_GARDEN_WATER_PLANT, MessageStyle::MESSAGE_STYLE_ZEN_GARDEN_LONG, AdviceType::ADVICE_NONE);
            TutorialArrowRemove();
        }
        mCursorObject->mCursorType = CursorType::CURSOR_TYPE_WATERING_CAN;
        mApp->PlayFoley(FoleyType::FOLEY_DROP);
        break;

    case GameObjectType::OBJECT_TYPE_FERTILIZER:
        if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_FERTILIZER] > PURCHASE_COUNT_OFFSET)
        {
            mCursorObject->mCursorType = CursorType::CURSOR_TYPE_FERTILIZER;
            mApp->PlayFoley(FoleyType::FOLEY_DROP);
        }
        else
        {
            mApp->PlaySample(Sexy::SOUND_BUZZER);
        }
        break;

    case GameObjectType::OBJECT_TYPE_BUG_SPRAY:
        if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_BUG_SPRAY] > PURCHASE_COUNT_OFFSET)
        {
            mCursorObject->mCursorType = CursorType::CURSOR_TYPE_BUG_SPRAY;
            mApp->PlayFoley(FoleyType::FOLEY_DROP);
        }
        else
        {
            mApp->PlaySample(Sexy::SOUND_BUZZER);
        }
        break;

    case GameObjectType::OBJECT_TYPE_PHONOGRAPH:
        mCursorObject->mCursorType = CursorType::CURSOR_TYPE_PHONOGRAPH;
        mApp->PlayFoley(FoleyType::FOLEY_DROP);
        break;

    case GameObjectType::OBJECT_TYPE_CHOCOLATE:
        if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_CHOCOLATE] > PURCHASE_COUNT_OFFSET)
        {
            mCursorObject->mCursorType = CursorType::CURSOR_TYPE_CHOCOLATE;
            mApp->PlayFoley(FoleyType::FOLEY_DROP);
        }
        else
        {
            mApp->PlaySample(Sexy::SOUND_BUZZER);
        }
        break;

    case GameObjectType::OBJECT_TYPE_GLOVE:
        mCursorObject->mCursorType = CursorType::CURSOR_TYPE_GLOVE;
        mApp->PlayFoley(FoleyType::FOLEY_DROP);
        break;

    case GameObjectType::OBJECT_TYPE_MONEY_SIGN:
        mCursorObject->mCursorType = CursorType::CURSOR_TYPE_MONEY_SIGN;
        mApp->PlayFoley(FoleyType::FOLEY_DROP);
        break;

    case GameObjectType::OBJECT_TYPE_WHEELBARROW:
        mCursorObject->mCursorType = CursorType::CURSOR_TYPE_WHEEELBARROW;
        mApp->PlayFoley(FoleyType::FOLEY_DROP);
        break;

    case GameObjectType::OBJECT_TYPE_TREE_FOOD:
        if (mChallenge->TreeOfWisdomCanFeed())
        {
            if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] > PURCHASE_COUNT_OFFSET)
            {
                mCursorObject->mCursorType = CursorType::CURSOR_TYPE_TREE_FOOD;
                mApp->PlayFoley(FoleyType::FOLEY_DROP);
            }
            else
            {
                mApp->PlaySample(Sexy::SOUND_BUZZER);
            }
        }
        break;

    default:
        TOD_ASSERT(false);
        break;
    }

    mCursorObject->mType = SeedType::SEED_NONE;
}

// FormB：HEAD lambda 表（逐字）
namespace
{
using PickUpToolCaseFn = void (*)(Board&);

// 原 default（无 case 的 12 型与表外哨兵共用）
void PickUpToolDefault(Board& b)
{
    		TOD_ASSERT(false);
}

constexpr PickUpToolCaseFn kPickUpToolCases[(int)GameObjectType::OBJECT_TYPE_TREE_OF_WISDOM + 1] = {
    &PickUpToolDefault,  // 0 OBJECT_TYPE_NONE（原 default）
    &PickUpToolDefault,  // 1 OBJECT_TYPE_PLANT（原 default）
    &PickUpToolDefault,  // 2 OBJECT_TYPE_PROJECTILE（原 default）
    &PickUpToolDefault,  // 3 OBJECT_TYPE_COIN（原 default）
    &PickUpToolDefault,  // 4 OBJECT_TYPE_SEEDPACKET（原 default）
    // 原 case OBJECT_TYPE_SHOVEL
    [](Board& b)
    {
    		if (b.mTutorialState == TutorialState::TUTORIAL_SHOVEL_PICKUP)
    		{
    			b.SetTutorialStateStub(TutorialState::TUTORIAL_SHOVEL_DIG);
    		}
    		b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_SHOVEL;
    		b.mApp->PlayFoley(FoleyType::FOLEY_SHOVEL);
    },  // 5 OBJECT_TYPE_SHOVEL
    // 原 case OBJECT_TYPE_WATERING_CAN
    [](Board& b)
    {
    		if (b.mTutorialState == TutorialState::TUTORIAL_ZEN_GARDEN_PICKUP_WATER)
    		{
    			b.mTutorialState = TutorialState::TUTORIAL_ZEN_GARDEN_WATER_PLANT;
    			b.DisplayAdvice(gStr.ADVICE_ZEN_GARDEN_WATER_PLANT, MessageStyle::MESSAGE_STYLE_ZEN_GARDEN_LONG, AdviceType::ADVICE_NONE);
    			b.TutorialArrowRemove();
    		}
    		b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_WATERING_CAN;
    		b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    },  // 6 OBJECT_TYPE_WATERING_CAN
    // 原 case OBJECT_TYPE_FERTILIZER
    [](Board& b)
    {
    		if (b.mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_FERTILIZER] > PURCHASE_COUNT_OFFSET)
    		{
    			b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_FERTILIZER;
    			b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    		}
    		else
    		{
    			b.mApp->PlaySample(Sexy::SOUND_BUZZER);
    		}
    },  // 7 OBJECT_TYPE_FERTILIZER
    // 原 case OBJECT_TYPE_BUG_SPRAY
    [](Board& b)
    {
    		if (b.mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_BUG_SPRAY] > PURCHASE_COUNT_OFFSET)
    		{
    			b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_BUG_SPRAY;
    			b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    		}
    		else
    		{
    			b.mApp->PlaySample(Sexy::SOUND_BUZZER);
    		}
    },  // 8 OBJECT_TYPE_BUG_SPRAY
    // 原 case OBJECT_TYPE_PHONOGRAPH
    [](Board& b)
    {
    		b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_PHONOGRAPH;
    		b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    },  // 9 OBJECT_TYPE_PHONOGRAPH
    // 原 case OBJECT_TYPE_CHOCOLATE
    [](Board& b)
    {
    		if (b.mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_CHOCOLATE] > PURCHASE_COUNT_OFFSET)
    		{
    			b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_CHOCOLATE;
    			b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    		}
    		else
    		{
    			b.mApp->PlaySample(Sexy::SOUND_BUZZER);
    		}
    },  // 10 OBJECT_TYPE_CHOCOLATE
    // 原 case OBJECT_TYPE_GLOVE
    [](Board& b)
    {
    		b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_GLOVE;
    		b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    },  // 11 OBJECT_TYPE_GLOVE
    // 原 case OBJECT_TYPE_MONEY_SIGN
    [](Board& b)
    {
    		b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_MONEY_SIGN;
    		b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    },  // 12 OBJECT_TYPE_MONEY_SIGN
    // 原 case OBJECT_TYPE_WHEELBARROW
    [](Board& b)
    {
    		b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_WHEEELBARROW;
    		b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    },  // 13 OBJECT_TYPE_WHEELBARROW
    // 原 case OBJECT_TYPE_TREE_FOOD
    [](Board& b)
    {
    		if (b.mChallenge->TreeOfWisdomCanFeed())
    		{
    			if (b.mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] > PURCHASE_COUNT_OFFSET)
    			{
    				b.mCursorObject->mCursorType = CursorType::CURSOR_TYPE_TREE_FOOD;
    				b.mApp->PlayFoley(FoleyType::FOLEY_DROP);
    			}
    			else
    			{
    				b.mApp->PlaySample(Sexy::SOUND_BUZZER);
    			}
    		}
    },  // 14 OBJECT_TYPE_TREE_FOOD
    &PickUpToolDefault,  // 15 OBJECT_TYPE_NEXT_GARDEN（原 default）
    &PickUpToolDefault,  // 16 OBJECT_TYPE_MENU_BUTTON（原 default）
    &PickUpToolDefault,  // 17 OBJECT_TYPE_STORE_BUTTON（原 default）
    &PickUpToolDefault,  // 18 OBJECT_TYPE_SLOT_MACHINE_HANDLE（原 default）
    &PickUpToolDefault,  // 19 OBJECT_TYPE_SCARY_POT（原 default）
    &PickUpToolDefault,  // 20 OBJECT_TYPE_STINKY（原 default）
    &PickUpToolDefault,  // 21 OBJECT_TYPE_TREE_OF_WISDOM（原 default）
};
static_assert(sizeof(kPickUpToolCases) / sizeof(kPickUpToolCases[0]) ==
    (int)GameObjectType::OBJECT_TYPE_TREE_OF_WISDOM + 1, "kPickUpToolCases 槽位数须与 GameObjectType 枚举同步");
}  // namespace

__declspec(noinline) void Board::PickUpTool_B(GameObjectType theObjectType)
{
    if (mPaused || (mApp->mGameScene != GameScenes::SCENE_PLAYING && !mCutScene->IsInShovelTutorial()))
        return;

    // C 形态 -> 匿名 lambda 函数指针表：行序 = GameObjectType 枚举序（0..21）。
    // default（TOD_ASSERT）具名并被缺槽与越界分支复用。
    const unsigned anObjectTypeIndex = static_cast<unsigned>(theObjectType);
    if (anObjectTypeIndex <= static_cast<unsigned>(GameObjectType::OBJECT_TYPE_TREE_OF_WISDOM))
    {
        kPickUpToolCases[anObjectTypeIndex](*this);
    }
    else
    {
        PickUpToolDefault(*this);
    }

    mCursorObject->mType = SeedType::SEED_NONE;
}

// ==================== b11 SetTutorialState ====================
// FormA：e44390a6^ switch 逐字
__declspec(noinline) void Board::SetTutorialState_A(TutorialState theTutorialState)
{
    switch (theTutorialState)
    {
    case TutorialState::TUTORIAL_LEVEL_1_PICK_UP_PEASHOOTER:
        if (mPlants.mSize == 0)
        {
            float aPosX = mSeedBank->mX + mSeedBank->mSeedPackets[0].mX;
            float aPosY = mSeedBank->mY + mSeedBank->mSeedPackets[0].mY;
            TutorialArrowShow(aPosX, aPosY);
            DisplayAdvice(gStr.ADVICE_CLICK_SEED_PACKET, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
        }
        else
        {
            DisplayAdvice(gStr.ADVICE_ENOUGH_SUN, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
            mTutorialTimer = 400;
        }
        break;

    case TutorialState::TUTORIAL_LEVEL_1_PLANT_PEASHOOTER:
        mTutorialTimer = -1;
        TutorialArrowRemove();
        if (mPlants.mSize == 0)
        {
            DisplayAdvice(gStr.ADVICE_CLICK_ON_GRASS, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
        }
        else
        {
            ClearAdvice(AdviceType::ADVICE_NONE);
        }
        break;

    case TutorialState::TUTORIAL_LEVEL_1_REFRESH_PEASHOOTER:
        DisplayAdvice(gStr.ADVICE_PLANTED_PEASHOOTER, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
        mSunCountDown = 400;
        break;

    case TutorialState::TUTORIAL_LEVEL_1_COMPLETED:
        DisplayAdvice(gStr.ADVICE_ZOMBIE_ONSLAUGHT, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1, AdviceType::ADVICE_NONE);
        mZombieCountDown = 99;
        mZombieCountDownStart = mZombieCountDown;
        break;

    case TutorialState::TUTORIAL_LEVEL_2_PICK_UP_SUNFLOWER:
    case TutorialState::TUTORIAL_MORESUN_PICK_UP_SUNFLOWER:
        TutorialArrowShow(mSeedBank->mX + mSeedBank->mSeedPackets[1].mX, mSeedBank->mY + mSeedBank->mSeedPackets[1].mY);
        break;

    case TutorialState::TUTORIAL_LEVEL_2_PLANT_SUNFLOWER:
    case TutorialState::TUTORIAL_LEVEL_2_REFRESH_SUNFLOWER:
    case TutorialState::TUTORIAL_MORESUN_PLANT_SUNFLOWER:
    case TutorialState::TUTORIAL_MORESUN_REFRESH_SUNFLOWER:
        TutorialArrowRemove();
        break;

    case TutorialState::TUTORIAL_LEVEL_2_COMPLETED:
        if (mCurrentWave == 0)
        {
            mZombieCountDown = 999;
            mZombieCountDownStart = mZombieCountDown;
        }
        break;

    case TutorialState::TUTORIAL_SLOT_MACHINE_PULL:
        DisplayAdvice(gStr.ADVICE_SLOT_MACHINE_PULL, MessageStyle::MESSAGE_STYLE_SLOT_MACHINE, AdviceType::ADVICE_SLOT_MACHINE_PULL);
        break;

    case TutorialState::TUTORIAL_SLOT_MACHINE_COMPLETED:
        ClearAdvice(AdviceType::ADVICE_SLOT_MACHINE_PULL);
        break;

    case TutorialState::TUTORIAL_SHOVEL_PICKUP:
    {
        DisplayAdvice(gStr.ADVICE_CLICK_SHOVEL, MessageStyle::MESSAGE_STYLE_HINT_STAY, AdviceType::ADVICE_NONE);
        Rect aShovelButtonRect = GetShovelButtonRect();
        int aPosX = aShovelButtonRect.mX + aShovelButtonRect.mWidth / 2 - 25;
        int aPosY = aShovelButtonRect.mY + aShovelButtonRect.mHeight - 65;
        TutorialArrowShow(aPosX, aPosY);
        break;
    }

    case TutorialState::TUTORIAL_SHOVEL_DIG:
        DisplayAdvice(gStr.ADVICE_CLICK_PLANT, MessageStyle::MESSAGE_STYLE_HINT_STAY, AdviceType::ADVICE_NONE);
        TutorialArrowRemove();
        break;

    case TutorialState::TUTORIAL_SHOVEL_KEEP_DIGGING:
        DisplayAdvice(gStr.ADVICE_KEEP_DIGGING, MessageStyle::MESSAGE_STYLE_HINT_STAY, AdviceType::ADVICE_NONE);
        break;

    case TutorialState::TUTORIAL_SHOVEL_COMPLETED:
        ClearAdvice(AdviceType::ADVICE_NONE);
        mCutScene->mCutsceneTime = 1500;
        mCutScene->mCrazyDaveDialogStart = 2410;
        break;

    default:
        break;
    }

    mTutorialState = theTutorialState;
}

// FormB：HEAD lambda 表（逐字）
namespace
{
using TutorialStateCaseFn = void (*)(Board&);

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case TUTORIAL_LEVEL_2_PICK_UP_SUNFLOWER, TUTORIAL_MORESUN_PICK_UP_SUNFLOWER
void TutorialCaseTutorialLevel2PickUpSunflower(Board& b)
{
    		b.TutorialArrowShow(b.mSeedBank->mX + b.mSeedBank->mSeedPackets[1].mX, b.mSeedBank->mY + b.mSeedBank->mSeedPackets[1].mY);
}

// 标签共体
// 原 case TUTORIAL_LEVEL_2_PLANT_SUNFLOWER, TUTORIAL_LEVEL_2_REFRESH_SUNFLOWER, TUTORIAL_MORESUN_PLANT_SUNFLOWER, TUTORIAL_MORESUN_REFRESH_SUNFLOWER
void TutorialCaseTutorialLevel2PlantSunflower(Board& b)
{
    		b.TutorialArrowRemove();
}

// 原 default（无 case 的 14 型（空操作）共用）
void TutorialCaseDefault(Board& b)
{

}

constexpr TutorialStateCaseFn kTutorialStateCases[(int)TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED + 1] = {
    &TutorialCaseDefault,  // 0 TUTORIAL_OFF（原 default）
    // 原 case TUTORIAL_LEVEL_1_PICK_UP_PEASHOOTER
    [](Board& b)
    {
    		if (b.mPlants.mSize == 0)
    		{
    			float aPosX = b.mSeedBank->mX + b.mSeedBank->mSeedPackets[0].mX;
    			float aPosY = b.mSeedBank->mY + b.mSeedBank->mSeedPackets[0].mY;
    			b.TutorialArrowShow(aPosX, aPosY);
    			b.DisplayAdvice(gStr.ADVICE_CLICK_SEED_PACKET, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
    		}
    		else
    		{
    			b.DisplayAdvice(gStr.ADVICE_ENOUGH_SUN, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
    			b.mTutorialTimer = 400;
    		}
    },  // 1 TUTORIAL_LEVEL_1_PICK_UP_PEASHOOTER
    // 原 case TUTORIAL_LEVEL_1_PLANT_PEASHOOTER
    [](Board& b)
    {
    		b.mTutorialTimer = -1;
    		b.TutorialArrowRemove();
    		if (b.mPlants.mSize == 0)
    		{
    			b.DisplayAdvice(gStr.ADVICE_CLICK_ON_GRASS, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
    		}
    		else
    		{
    			b.ClearAdvice(AdviceType::ADVICE_NONE);
    		}
    },  // 2 TUTORIAL_LEVEL_1_PLANT_PEASHOOTER
    // 原 case TUTORIAL_LEVEL_1_REFRESH_PEASHOOTER
    [](Board& b)
    {
    		b.DisplayAdvice(gStr.ADVICE_PLANTED_PEASHOOTER, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1_STAY, AdviceType::ADVICE_NONE);
    		b.mSunCountDown = 400;
    },  // 3 TUTORIAL_LEVEL_1_REFRESH_PEASHOOTER
    // 原 case TUTORIAL_LEVEL_1_COMPLETED
    [](Board& b)
    {
    		b.DisplayAdvice(gStr.ADVICE_ZOMBIE_ONSLAUGHT, MessageStyle::MESSAGE_STYLE_TUTORIAL_LEVEL1, AdviceType::ADVICE_NONE);
    		b.mZombieCountDown = 99;
    		b.mZombieCountDownStart = b.mZombieCountDown;
    },  // 4 TUTORIAL_LEVEL_1_COMPLETED
    &TutorialCaseTutorialLevel2PickUpSunflower,  // 5 TUTORIAL_LEVEL_2_PICK_UP_SUNFLOWER（共体）
    &TutorialCaseTutorialLevel2PlantSunflower,  // 6 TUTORIAL_LEVEL_2_PLANT_SUNFLOWER（共体）
    &TutorialCaseTutorialLevel2PlantSunflower,  // 7 TUTORIAL_LEVEL_2_REFRESH_SUNFLOWER（共体）
    // 原 case TUTORIAL_LEVEL_2_COMPLETED
    [](Board& b)
    {
    		if (b.mCurrentWave == 0)
    		{
    			b.mZombieCountDown = 999;
    			b.mZombieCountDownStart = b.mZombieCountDown;
    		}
    },  // 8 TUTORIAL_LEVEL_2_COMPLETED
    &TutorialCaseTutorialLevel2PickUpSunflower,  // 9 TUTORIAL_MORESUN_PICK_UP_SUNFLOWER（共体）
    &TutorialCaseTutorialLevel2PlantSunflower,  // 10 TUTORIAL_MORESUN_PLANT_SUNFLOWER（共体）
    &TutorialCaseTutorialLevel2PlantSunflower,  // 11 TUTORIAL_MORESUN_REFRESH_SUNFLOWER（共体）
    &TutorialCaseDefault,  // 12 TUTORIAL_MORESUN_COMPLETED（原 default）
    // 原 case TUTORIAL_SLOT_MACHINE_PULL
    [](Board& b)
    {
    		b.DisplayAdvice(gStr.ADVICE_SLOT_MACHINE_PULL, MessageStyle::MESSAGE_STYLE_SLOT_MACHINE, AdviceType::ADVICE_SLOT_MACHINE_PULL);
    },  // 13 TUTORIAL_SLOT_MACHINE_PULL
    // 原 case TUTORIAL_SLOT_MACHINE_COMPLETED
    [](Board& b)
    {
    		b.ClearAdvice(AdviceType::ADVICE_SLOT_MACHINE_PULL);
    },  // 14 TUTORIAL_SLOT_MACHINE_COMPLETED
    // 原 case TUTORIAL_SHOVEL_PICKUP
    [](Board& b)
    {
    		b.DisplayAdvice(gStr.ADVICE_CLICK_SHOVEL, MessageStyle::MESSAGE_STYLE_HINT_STAY, AdviceType::ADVICE_NONE);
    		Rect aShovelButtonRect = b.GetShovelButtonRect();
    		int aPosX = aShovelButtonRect.mX + aShovelButtonRect.mWidth / 2 - 25;
    		int aPosY = aShovelButtonRect.mY + aShovelButtonRect.mHeight - 65;
    		b.TutorialArrowShow(aPosX, aPosY);
    },  // 15 TUTORIAL_SHOVEL_PICKUP
    // 原 case TUTORIAL_SHOVEL_DIG
    [](Board& b)
    {
    		b.DisplayAdvice(gStr.ADVICE_CLICK_PLANT, MessageStyle::MESSAGE_STYLE_HINT_STAY, AdviceType::ADVICE_NONE);
    		b.TutorialArrowRemove();
    },  // 16 TUTORIAL_SHOVEL_DIG
    // 原 case TUTORIAL_SHOVEL_KEEP_DIGGING
    [](Board& b)
    {
    		b.DisplayAdvice(gStr.ADVICE_KEEP_DIGGING, MessageStyle::MESSAGE_STYLE_HINT_STAY, AdviceType::ADVICE_NONE);
    },  // 17 TUTORIAL_SHOVEL_KEEP_DIGGING
    // 原 case TUTORIAL_SHOVEL_COMPLETED
    [](Board& b)
    {
    		b.ClearAdvice(AdviceType::ADVICE_NONE);
    		b.mCutScene->mCutsceneTime = 1500;
    		b.mCutScene->mCrazyDaveDialogStart = 2410;
    },  // 18 TUTORIAL_SHOVEL_COMPLETED
    &TutorialCaseDefault,  // 19 TUTORIAL_ZOMBIQUARIUM_BUY_SNORKEL（原 default）
    &TutorialCaseDefault,  // 20 TUTORIAL_ZOMBIQUARIUM_BOUGHT_SNORKEL（原 default）
    &TutorialCaseDefault,  // 21 TUTORIAL_ZOMBIQUARIUM_CLICK_TROPHY（原 default）
    &TutorialCaseDefault,  // 22 TUTORIAL_ZEN_GARDEN_PICKUP_WATER（原 default）
    &TutorialCaseDefault,  // 23 TUTORIAL_ZEN_GARDEN_WATER_PLANT（原 default）
    &TutorialCaseDefault,  // 24 TUTORIAL_ZEN_GARDEN_KEEP_WATERING（原 default）
    &TutorialCaseDefault,  // 25 TUTORIAL_ZEN_GARDEN_VISIT_STORE（原 default）
    &TutorialCaseDefault,  // 26 TUTORIAL_ZEN_GARDEN_FERTILIZE_PLANTS（原 default）
    &TutorialCaseDefault,  // 27 TUTORIAL_ZEN_GARDEN_COMPLETED（原 default）
    &TutorialCaseDefault,  // 28 TUTORIAL_WHACK_A_ZOMBIE_BEFORE_PICK_SEED（原 default）
    &TutorialCaseDefault,  // 29 TUTORIAL_WHACK_A_ZOMBIE_PICK_SEED（原 default）
    &TutorialCaseDefault,  // 30 TUTORIAL_WHACK_A_ZOMBIE_COMPLETED（原 default）
};
static_assert(sizeof(kTutorialStateCases) / sizeof(kTutorialStateCases[0]) ==
    (int)TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED + 1, "kTutorialStateCases 槽位数须与 TutorialState 枚举同步");
}  // namespace

__declspec(noinline) void Board::SetTutorialState_B(TutorialState theTutorialState)
{
    // C 形态 -> 匿名 lambda 函数指针表：行序 = TutorialState 枚举序（0..30）。
    // 原 default 空操作——缺槽/越界均无操作。
    const unsigned aStateIndex = static_cast<unsigned>(theTutorialState);
    if (aStateIndex <= static_cast<unsigned>(TutorialState::TUTORIAL_WHACK_A_ZOMBIE_COMPLETED))
    {
        kTutorialStateCases[aStateIndex](*this);
    }


    mTutorialState = theTutorialState;
}

// ==================== b12 MouseDownWithPlant 升级建议段（隔离对拍：只换 PLANTING_NEEDS_UPGRADE 支） ====================
// 共享前置（HEAD/原版同链）
namespace
{
struct UpgradeAdviceEntry
{
    const std::string* mStr;
    AdviceType mType;
};
constexpr UpgradeAdviceEntry kUpgradeAdvice[(int)SeedType::NUM_SEED_TYPES] = {
    {}, {}, {}, {}, {}, {}, {}, {}, {}, {},
    {}, {}, {}, {}, {}, {}, {}, {}, {}, {},
    {}, {}, {}, {}, {}, {}, {}, {}, {}, {},
    {}, {}, {}, {}, {}, {}, {}, {}, {}, {},
    { &gStr.ADVICE_ONLY_ON_REPEATERS,    AdviceType::ADVICE_PLANT_ONLY_ON_REPEATERS },     // 40 SEED_GATLINGPEA
    { &gStr.ADVICE_ONLY_ON_SUNFLOWER,    AdviceType::ADVICE_PLANT_ONLY_ON_SUNFLOWER },     // 41 SEED_TWINSUNFLOWER
    { &gStr.ADVICE_ONLY_ON_FUMESHROOM,   AdviceType::ADVICE_PLANT_ONLY_ON_FUMESHROOM },    // 42 SEED_GLOOMSHROOM
    { &gStr.ADVICE_ONLY_ON_LILYPAD,      AdviceType::ADVICE_PLANT_ONLY_ON_LILYPAD },       // 43 SEED_CATTAIL
    { &gStr.ADVICE_ONLY_ON_MELONPULT,    AdviceType::ADVICE_PLANT_ONLY_ON_MELONPULT },     // 44 SEED_WINTERMELON
    { &gStr.ADVICE_ONLY_ON_MAGNETSHROOM, AdviceType::ADVICE_PLANT_ONLY_ON_MAGNETSHROOM },  // 45 SEED_GOLD_MAGNET
    { &gStr.ADVICE_ONLY_ON_SPIKEWEED,    AdviceType::ADVICE_PLANT_ONLY_ON_SPIKEWEED },     // 46 SEED_SPIKEROCK
    { &gStr.ADVICE_ONLY_ON_KERNELPULT,   AdviceType::ADVICE_PLANT_ONLY_ON_KERNELPULT },    // 47 SEED_COBCANNON
    {}, {}, {}, {}, {},
};
static_assert(sizeof(kUpgradeAdvice) / sizeof(kUpgradeAdvice[0]) == (int)SeedType::NUM_SEED_TYPES,
    "升级建议表槽位须与 SeedType 枚举同步");
}  // namespace

// FormA：9f1cfecc^ PLANTING_NEEDS_UPGRADE 支原 switch 逐字
__declspec(noinline) void Board::MouseDownWithPlantUpgrade_A(int x, int y, int theClickCount)
{
    SeedType aPlantingSeedType = (SeedType)(g_curSeed % 53);
    PlantingReason aReason = PlantingReason::PLANTING_NEEDS_UPGRADE;
    int aGridX = 4, aGridY = 2;
    if (aReason == PlantingReason::PLANTING_ONLY_ON_GRAVES)
    {
        DisplayAdvice(gStr.ADVICE_GRAVEBUSTERS_ON_GRAVES, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_GRAVEBUSTERS_ON_GRAVES);
    }
    else if (aPlantingSeedType == SeedType::SEED_LILYPAD)
    {
        if (aReason == PlantingReason::PLANTING_ONLY_IN_POOL)
        {
            DisplayAdvice(gStr.ADVICE_LILYPAD_ON_WATER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_LILYPAD_ON_WATER);
        }
    }
    else if (aPlantingSeedType == SeedType::SEED_TANGLEKELP)
    {
        if (aReason == PlantingReason::PLANTING_ONLY_IN_POOL)
        {
            DisplayAdvice(gStr.ADVICE_TANGLEKELP_ON_WATER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_TANGLEKELP_ON_WATER);
        }
    }
    else if (aPlantingSeedType == SeedType::SEED_SEASHROOM)
    {
        if (aReason == PlantingReason::PLANTING_ONLY_IN_POOL)
        {
            DisplayAdvice(gStr.ADVICE_SEASHROOM_ON_WATER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_SEASHROOM_ON_WATER);
        }
    }
    else if (aReason == PlantingReason::PLANTING_ONLY_ON_GROUND)
    {
        DisplayAdvice(gStr.ADVICE_POTATO_MINE_ON_LILY, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_POTATOE_MINE_ON_LILY);
    }
    else if (aReason == PlantingReason::PLANTING_NOT_PASSED_LINE)
    {
        DisplayAdvice(gStr.ADVICE_NOT_PASSED_LINE, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_NOT_PASSED_LINE);
    }
    else if (aReason == PlantingReason::PLANTING_NEEDS_UPGRADE)
    {
        switch (aPlantingSeedType)
        {
        case SeedType::SEED_GATLINGPEA:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_REPEATERS, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_REPEATERS);
            break;

        case SeedType::SEED_TWINSUNFLOWER:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_SUNFLOWER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_SUNFLOWER);
            break;

        case SeedType::SEED_GLOOMSHROOM:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_FUMESHROOM, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_FUMESHROOM);
            break;

        case SeedType::SEED_CATTAIL:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_LILYPAD, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_LILYPAD);
            break;

        case SeedType::SEED_WINTERMELON:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_MELONPULT, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_MELONPULT);
            break;

        case SeedType::SEED_GOLD_MAGNET:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_MAGNETSHROOM, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_MAGNETSHROOM);
            break;

        case SeedType::SEED_SPIKEROCK:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_SPIKEWEED, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_SPIKEWEED);
            break;

        case SeedType::SEED_COBCANNON:
            DisplayAdvice(gStr.ADVICE_ONLY_ON_KERNELPULT, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_ONLY_ON_KERNELPULT);
            break;
        default:
            break;
        }
    }
}

// FormB：HEAD 同链（NEEDS_UPGRADE 支换 kUpgradeAdvice 直查，逐字）
__declspec(noinline) void Board::MouseDownWithPlantUpgrade_B(int x, int y, int theClickCount)
{
    SeedType aPlantingSeedType = (SeedType)(g_curSeed % 53);
    PlantingReason aReason = PlantingReason::PLANTING_NEEDS_UPGRADE;
    int aGridX = 4, aGridY = 2;
    if (aReason == PlantingReason::PLANTING_ONLY_ON_GRAVES)
    {
        DisplayAdvice(gStr.ADVICE_GRAVEBUSTERS_ON_GRAVES, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_GRAVEBUSTERS_ON_GRAVES);
    }
    else if (aPlantingSeedType == SeedType::SEED_LILYPAD)
    {
        if (aReason == PlantingReason::PLANTING_ONLY_IN_POOL)
        {
            DisplayAdvice(gStr.ADVICE_LILYPAD_ON_WATER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_LILYPAD_ON_WATER);
        }
    }
    else if (aPlantingSeedType == SeedType::SEED_TANGLEKELP)
    {
        if (aReason == PlantingReason::PLANTING_ONLY_IN_POOL)
        {
            DisplayAdvice(gStr.ADVICE_TANGLEKELP_ON_WATER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_TANGLEKELP_ON_WATER);
        }
    }
    else if (aPlantingSeedType == SeedType::SEED_SEASHROOM)
    {
        if (aReason == PlantingReason::PLANTING_ONLY_IN_POOL)
        {
            DisplayAdvice(gStr.ADVICE_SEASHROOM_ON_WATER, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_SEASHROOM_ON_WATER);
        }
    }
    else if (aReason == PlantingReason::PLANTING_ONLY_ON_GROUND)
    {
        DisplayAdvice(gStr.ADVICE_POTATO_MINE_ON_LILY, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_POTATOE_MINE_ON_LILY);
    }
    else if (aReason == PlantingReason::PLANTING_NOT_PASSED_LINE)
    {
        DisplayAdvice(gStr.ADVICE_NOT_PASSED_LINE, MessageStyle::MESSAGE_STYLE_HINT_FAST, AdviceType::ADVICE_PLANT_NOT_PASSED_LINE);
    }
    else if (aReason == PlantingReason::PLANTING_NEEDS_UPGRADE)
    {
        // B 形态 -> 常量表（下方 kUpgradeAdvice，SeedType 直下标；
        // nullptr = 无建议 = 原 default）
        if (kUpgradeAdvice[(int)aPlantingSeedType].mStr != nullptr)
        {
            DisplayAdvice(*kUpgradeAdvice[(int)aPlantingSeedType].mStr,
                MessageStyle::MESSAGE_STYLE_HINT_FAST, kUpgradeAdvice[(int)aPlantingSeedType].mType);
        }
    }
}

// ==================== b13 Met（kUpgradeBasisReqs） ====================
// FormA：e0f71d8a^ PlantingRequirementsMet 原 switch 逐字（真原形；表族三次重塑前）
__declspec(noinline) bool Board::Met_A(SeedType theSeedType)
{
    switch (theSeedType)
    {
    case SeedType::SEED_GATLINGPEA:			return CountPlantByType(SeedType::SEED_REPEATER);
    case SeedType::SEED_TWINSUNFLOWER:		return CountPlantByType(SeedType::SEED_SUNFLOWER);
    case SeedType::SEED_GLOOMSHROOM:		return CountPlantByType(SeedType::SEED_FUMESHROOM);
    case SeedType::SEED_CATTAIL:			return CountEmptyPotsOrLilies(SeedType::SEED_LILYPAD);
    case SeedType::SEED_WINTERMELON:		return CountPlantByType(SeedType::SEED_MELONPULT);
    case SeedType::SEED_GOLD_MAGNET:		return CountPlantByType(SeedType::SEED_MAGNETSHROOM);
    case SeedType::SEED_SPIKEROCK:			return CountPlantByType(SeedType::SEED_SPIKEWEED);
    case SeedType::SEED_COBCANNON:			return HasValidCobCannonSpot();
    default:								return true;
    }
}

// FormB：HEAD Met（逐字）
__declspec(noinline) bool Board::Met_B(SeedType theSeedType)
{
    if (theSeedType < SeedType::SEED_GATLINGPEA || theSeedType > SeedType::SEED_COBCANNON)
    {
        return true;
    }
    static constexpr bool (*kUpgradeBasisReqs[])(Board*) = {
        /* SEED_GATLINGPEA    */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_REPEATER) != 0; },
        /* SEED_TWINSUNFLOWER */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_SUNFLOWER) != 0; },
        /* SEED_GLOOMSHROOM   */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_FUMESHROOM) != 0; },
        /* SEED_CATTAIL       */ [](Board* aBoard) { return aBoard->CountEmptyPotsOrLilies(SeedType::SEED_LILYPAD) != 0; },
        /* SEED_WINTERMELON   */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_MELONPULT) != 0; },
        /* SEED_GOLD_MAGNET   */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_MAGNETSHROOM) != 0; },
        /* SEED_SPIKEROCK     */ [](Board* aBoard) { return aBoard->CountPlantByType(SeedType::SEED_SPIKEWEED) != 0; },
        /* SEED_COBCANNON     */ [](Board* aBoard) { return aBoard->HasValidCobCannonSpot(); },
    };
    static_assert(sizeof(kUpgradeBasisReqs) / sizeof(kUpgradeBasisReqs[0])
        == (int)SeedType::SEED_COBCANNON - (int)SeedType::SEED_GATLINGPEA + 1,
        "基座检查槽位须与 SeedType 升级段同步");
    return kUpgradeBasisReqs[(int)theSeedType - (int)SeedType::SEED_GATLINGPEA](this);
}

// ==================== b15 KeyChar 树智慧秘技段（kTreeWisdomCheatRecord） ====================
// FormA：403c1968^ 数字九连 else-if（逐字；f/g/b 前缀支两侧一致）
__declspec(noinline) void Board::KeyCharCheat_A(char theChar)
{
    if (theChar == ('f'))
    {
        if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] <= PURCHASE_COUNT_OFFSET)
        {
            mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] = PURCHASE_COUNT_OFFSET + 1;
        }
        mChallenge->TreeOfWisdomFertilize();
    }
    else if (theChar == ('g'))
    {
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('b'))
    {
        mChallenge->mChallengeStateCounter = 1;
    }
    else if (theChar == ('0'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 0;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('1'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 9;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('2'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 19;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('3'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 29;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('4'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 39;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('5'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 49;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('6'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 98;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('7'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 498;
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('8'))
    {
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = 998;
        mChallenge->TreeOfWisdomGrow();
    }
}

namespace
{
constexpr int kTreeWisdomCheatRecord[9] = { 0, 9, 19, 29, 39, 49, 98, 498, 998 };
static_assert(sizeof(kTreeWisdomCheatRecord) / sizeof(kTreeWisdomCheatRecord[0]) == 9,
    "树智慧秘技记录表槽位");
}

// FormB：HEAD（逐字）
__declspec(noinline) void Board::KeyCharCheat_B(char theChar)
{
    if (theChar == ('f'))
    {
        if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] <= PURCHASE_COUNT_OFFSET)
        {
            mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] = PURCHASE_COUNT_OFFSET + 1;
        }
        mChallenge->TreeOfWisdomFertilize();
    }
    else if (theChar == ('g'))
    {
        mChallenge->TreeOfWisdomGrow();
    }
    else if (theChar == ('b'))
    {
        mChallenge->mChallengeStateCounter = 1;
    }
    else if (theChar >= ('0') && theChar <= ('8'))
    {
        // B 形态 -> 常量表（上方 kTreeWisdomCheatRecord，theChar-'0' 平移下标）
        mApp->mPlayerInfo->mChallengeRecords[mApp->GetCurrentChallengeIndex()] = kTreeWisdomCheatRecord[theChar - ('0')];
        mChallenge->TreeOfWisdomGrow();
    }
}

// ============================ main ============================
static Board g_board;
static LawnApp g_app;
static CutScene g_cut;
static Challenge g_chal;
static CursorObject g_cursor;
static SeedBank g_seedBank;
static PlayerInfo g_pi;
static Graphics g_gfx;

// SetTutorialState 桩（PickUpTool 内调用；编号桩两形态同参）
__declspec(noinline) void Board::SetTutorialStateStub(TutorialState t) { ZSink(RID_Board_SetTutorialStateInner, (uint32_t)t); }

static void ResetBoard(const R3Input& in)
{
    g_board.mApp = &g_app;
    g_app.mBoard = &g_board;
    g_board.mCutScene = &g_cut;
    g_board.mChallenge = &g_chal;
    g_board.mCursorObject = &g_cursor;
    g_board.mSeedBank = &g_seedBank;
    g_app.mPlayerInfo = &g_pi;
    g_app.mGameScene = GameScenes::SCENE_PLAYING;
    g_board.mPaused = false;
    g_board.mBackground = (BackgroundType)(in.a % 7);
    g_board.mTutorialState = TutorialState::TUTORIAL_OFF;
    g_board.mPlants.mSize = (int)(in.b % 3);
    g_board.mCurrentWave = (int)(in.c % 3);
    // 全残迹清零（被写集合：tutorial 计时/阳光/僵尸倒计时/过场）——顺序两形态起点一致
    g_board.mTutorialTimer = 0;
    g_board.mSunCountDown = 0;
    g_board.mZombieCountDown = 0;
    g_board.mZombieCountDownStart = 0;
    g_cut.mCutsceneTime = 0;
    g_cut.mCrazyDaveDialogStart = 0;
    g_cursor.mCursorType = CursorType::CURSOR_TYPE_NORMAL;
    g_cursor.mType = SeedType::SEED_PEASHOOTER;
    g_chal.mChallengeStateCounter = 0;
    for (int i = 0; i < 64; i++) g_pi.mChallengeRecords[i] = -1;
    g_pi.mPurchases[(int)StoreItem::STORE_ITEM_FERTILIZER] = (int)(in.c % 2);
    g_pi.mPurchases[(int)StoreItem::STORE_ITEM_BUG_SPRAY] = (int)(in.d % 2);
    g_pi.mPurchases[(int)StoreItem::STORE_ITEM_CHOCOLATE] = (int)(in.a % 2);
    g_pi.mPurchases[(int)StoreItem::STORE_ITEM_TREE_FOOD] = (int)(in.b % 2);
}

int main()
{
    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_board.DrawHouseDoorBottom_A(&g_gfx);
                g_board.DrawHouseDoorTop_A(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_board.DrawHouseDoorBottom_B(&g_gfx);
                g_board.DrawHouseDoorTop_B(&g_gfx);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mBackground);
            }
        };
        rc |= R3BenchMain("b09_DrawHouseDoors_kDoorBottomTop", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_board.PickUpTool_A((GameObjectType)(g_inputs[i].a % 15));
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_cursor.mCursorType * 3u + (uint32_t)g_cursor.mType);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_board.PickUpTool_B((GameObjectType)(g_inputs[i].a % 15));
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_cursor.mCursorType * 3u + (uint32_t)g_cursor.mType);
            }
        };
        rc |= R3BenchMain("b10_PickUpTool_kPickUpToolCases", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_board.SetTutorialState_A((TutorialState)(g_inputs[i].a % 31));
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown));
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_board.SetTutorialState_B((TutorialState)(g_inputs[i].a % 31));
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_board.mTutorialState * 7u + (uint32_t)(g_board.mTutorialTimer * 13 + g_board.mSunCountDown));
            }
        };
        rc |= R3BenchMain("b11_SetTutorialState_kTutorialStateCases", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_curSeed = g_inputs[i].b;
                g_board.MouseDownWithPlantUpgrade_A(400, 300, 1);
                ck = ZBMixU64(ck, (uint64_t)g_curSeed);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                g_curSeed = g_inputs[i].b;
                g_board.MouseDownWithPlantUpgrade_B(400, 300, 1);
                ck = ZBMixU64(ck, (uint64_t)g_curSeed);
            }
        };
        rc |= R3BenchMain("b12_MouseDownWithPlant_kUpgradeAdvice", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                bool r = g_board.Met_A((SeedType)(g_inputs[i].b % 53));
                ck = ZBMixU64(ck, r ? 1 : 0);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                bool r = g_board.Met_B((SeedType)(g_inputs[i].b % 53));
                ck = ZBMixU64(ck, r ? 1 : 0);
            }
        };
        rc |= R3BenchMain("b13_Met_kUpgradeBasisReqs", reset, pa, pb);
    }
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                char ch = "fgb0123456789"[g_inputs[i].a % 13];
                g_board.KeyCharCheat_A(ch);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_pi.mChallengeRecords[3] * 5u + (uint32_t)g_chal.mChallengeStateCounter);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetBoard(g_inputs[i]);
                char ch = "fgb0123456789"[g_inputs[i].a % 13];
                g_board.KeyCharCheat_B(ch);
                ck = ZBMixU64(ck, (uint64_t)(uint32_t)g_pi.mChallengeRecords[3] * 5u + (uint32_t)g_chal.mChallengeStateCounter);
            }
        };
        rc |= R3BenchMain("b15_KeyChar_TreeWisdomCheatRecord", reset, pa, pb);
    }
    return rc;
}
