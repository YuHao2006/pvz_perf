#pragma once

#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>

#include <functional>

#include "../misc/Rect.h"
#include "Color.h"

namespace Sexy
{

// Screen-space vertex in the same layout the D3D9 path uses, but already
// converted for D3D11: pos.xy in pixels, color as float4, uv in 0..1.
struct D3D11Vertex
{
	float mX;
	float mY;
	float mR;
	float mG;
	float mB;
	float mA;
	float mU;
	float mV;
};

// D3D11 replacement for the game's D3D9 scene renderer. The game keeps all
// its CPU-side geometry (clipping, interpolation, texture atlases); this
// class owns the GPU objects and submits textured triangles. The scene is
// rendered into an 800x600 render target that the Magpie scaling pipeline can
// consume directly (no D3D9Ex, no desktop capture).
class D3D11Renderer
{
public:
	D3D11Renderer();
	~D3D11Renderer();

	bool Init(HWND theHWnd, int theSceneWidth, int theSceneHeight, int thePresentWidth, int thePresentHeight);
	void Shutdown();
	bool IsActive() const { return mDevice != nullptr; }

	ID3D11Device* GetDevice() const { return mDevice; }
	ID3D11DeviceContext* GetContext() const { return mContext; }
	ID3D11ShaderResourceView* GetSceneSRV() const { return mSceneSRV; }
	// Solid-color primitives explicitly bind this 1x1 texture. Image draws do
	// not use it as a fallback: a missing image SRV remains a hard error.
	ID3D11ShaderResourceView* GetWhiteSRV() const { return mWhiteSRV; }
	ID3D11Texture2D* GetSceneTexture() const { return mSceneTexture; }
	int GetPresentWidth() const { return mPresentWidth; }
	int GetPresentHeight() const { return mPresentHeight; }

	// Creates an SRV for a texture atlas piece uploaded from CPU bits.
	ID3D11ShaderResourceView* CreateTextureSRV(int theWidth, int theHeight, const void* theBits, int thePitch, bool theOpaque = false);

	// Custom-scaling presenter: given the rendered scene texture, produce a
	// target-sized output texture ready to present. No callback means scaling
	// is off; once installed, a null result is a pipeline error. The returned
	// texture is addref'd and the output size is written back.
	using ScalePresentFn = std::function<ID3D11Texture2D*(
		ID3D11Texture2D* aSceneTexture, int aSrcW, int aSrcH, int& aOutW, int& aOutH)>;
	void SetScalePresent(const ScalePresentFn& aFn) { mScalePresentFn = aFn; }

	void BeginScene();
	void EndSceneAndPresent();

	// Submits theNumVertices screen-space vertices as a triangle list.
	void SubmitTriangles(
		const D3D11Vertex* theVertices,
		int theNumVertices,
		ID3D11ShaderResourceView* theSRV,
		bool theLinearFilter,
		bool theWrap,
		int theDrawMode,
		const Rect* theClipRect,
		int theViewportWidth,
		int theViewportHeight);

	// Resizes the swapchain (window/fullscreen toggle, custom-scale change)
	// without rebuilding the device, scene target, or image textures.
	bool ResizeSwapChain(int aWidth, int aHeight);

	// Drops every context binding that can keep a back-buffer, scene target, or
	// scale intermediate alive.  This is used immediately before
	// IDXGISwapChain::ResizeBuffers and before destroying the scale runtime.
	// It is a mode-switch operation only; the next BeginScene/SubmitTriangles
	// call restores the normal pipeline state.
	void PrepareForResize();

	// Execute the installed scale callback once without presenting.  The app
	// uses this to create shaders and intermediate textures before the first
	// visible frame, so enabling custom scale cannot hitch the title screen.
	bool WarmScalePresent();

private:
	bool CreateDeviceAndSwapChain(HWND theHWnd, int thePresentWidth, int thePresentHeight);
	bool CreateShadersAndStates();
	bool CreateSceneTarget(int theSceneWidth, int theSceneHeight);
	void ApplyDrawMode(int theDrawMode);
	void ReleasePresentSRVCache();

	ID3D11Device*			mDevice;
	ID3D11DeviceContext*	mContext;
	IDXGISwapChain*			mSwapChain;

	ID3D11Texture2D*		mSceneTexture;
	ID3D11RenderTargetView*	mSceneRTV;
	ID3D11ShaderResourceView* mSceneSRV;
	ID3D11RenderTargetView*	mBackBufferRTV;

	ID3D11VertexShader*		mVertexShader;
	ID3D11PixelShader*		mPixelShader;
	ID3D11InputLayout*		mInputLayout;
	ID3D11Buffer*			mConstantBuffer;
	ID3D11Buffer*			mVertexBuffer;
	int						mVertexBufferCapacity;
		// A single 4K dynamic buffer forced the NVIDIA driver to wait whenever
		// a particle-heavy frame wrapped it.  Keep one large per-frame stream:
		// DISCARD once at the frame boundary, then append with NO_OVERWRITE.
		// Draw calls still remain separate so texture/blend semantics are exact.
	unsigned int			mVertexWriteOffset;
	int						mConstantViewportWidth;
	int						mConstantViewportHeight;
	int						mSceneWidth;
	int						mSceneHeight;
	int						mPresentWidth;
	int						mPresentHeight;

	ID3D11BlendState*		mBlendNormal;
	ID3D11BlendState*		mBlendAdditive;
	ID3D11SamplerState*		mSamplerPoint;
	ID3D11SamplerState*		mSamplerLinear;
	ID3D11SamplerState*		mSamplerPointWrap;
	ID3D11SamplerState*		mSamplerLinearWrap;
	ID3D11ShaderResourceView* mWhiteSRV;
	ID3D11RasterizerState*	mRasterizer;
	ID3D11Texture2D*		mPresentSRVTexture;
	ID3D11ShaderResourceView*	mPresentSRV;
	ID3D11ShaderResourceView*	mBoundPSRV;
	ID3D11SamplerState*		mBoundSampler;
	ID3D11BlendState*		mBoundBlend;
	bool					mScissorValid;
	D3D11_RECT			mBoundScissor;
	ScalePresentFn			mScalePresentFn;
};

}
