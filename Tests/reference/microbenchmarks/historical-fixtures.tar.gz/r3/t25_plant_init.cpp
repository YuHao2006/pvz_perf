// t25_plant_init.cpp — kPlantInitCases -> Plant::PlantInitialize（装载一次）
// FormA = cb766530^ 原 53 型 switch（逐字）；FormB = HEAD 匿名 lambda 表（逐字）。
#include "r3_entities.h"

namespace Sexy { inline int SOUND_PLANTERN = 5; }

// ==================== FormB 表群（HEAD 86-458 逐字） ====================
namespace
{
// PlantInitialize 槽位上下文：switch 外提引用（主体 reanim 指针、定义动画
// 型）经此传递。表内匿名 lambda = 原 case 体逐句迁移（生成器 + 逆变换
// token 对拍 0 差异），标签共体组与 default 具名（lambda 无法跨槽复用）。
struct PlantInitLocals
{
    Reanimation* mBodyReanim;
    ReanimationType mReanimationType;
};
using PlantInitCaseFn = void (*)(Plant&, PlantInitLocals&);

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case SEED_PEASHOOTER, SEED_SNOWPEA, SEED_REPEATER, SEED_LEFTPEATER, SEED_GATLINGPEA
void PlantInitPeashooter(Plant& p, PlantInitLocals& lc)
{
            if (lc.mBodyReanim)
            {
                lc.mBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
                Reanimation* aHeadReanim = p.mApp->AddReanimation(0.0f, 0.0f, p.mRenderOrder + 2, lc.mReanimationType);
                aHeadReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
                aHeadReanim->mAnimRate = lc.mBodyReanim->mAnimRate;
                aHeadReanim->SetFramesForLayer(ReanimTrackId::anim_head_idle);
                p.mHeadReanimID = p.mApp->ReanimationGetID(aHeadReanim);

                if (lc.mBodyReanim->TrackExists(ReanimTrackId::anim_stem))
                    aHeadReanim->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_stem);
                else if (lc.mBodyReanim->TrackExists(ReanimTrackId::anim_idle))
                    aHeadReanim->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_idle);
            }
}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case SEED_CHERRYBOMB, SEED_JALAPENO
void PlantInitCherrybomb(Plant& p, PlantInitLocals& lc)
{
            TOD_ASSERT(lc.mBodyReanim);

            if (p.IsInPlay())
            {
                p.mDoSpecialCountdown = 100;

                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_explode);
                lc.mBodyReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;

                p.mApp->PlayFoley(FoleyType::FOLEY_REVERSE_EXPLOSION);
            }
}

// 标签共体（匿名 lambda 无法跨槽复用，复用即具名）
// 原 case SEED_PUFFSHROOM, SEED_SEASHROOM
void PlantInitPuffshroom(Plant& p, PlantInitLocals& lc)
{
            if (p.IsInPlay())
            {
                p.mX += Sexy::Rand(10) - 5;
                p.mY += Sexy::Rand(6) - 3;
            }
}

// 原 default（无 case 的 15 型（空操作）共用）
void PlantInitDefault(Plant& p, PlantInitLocals& lc)
{

}

// 匿名 lambda 函数指针表，行序 = SeedType 枚举值序（0..52）。
constexpr PlantInitCaseFn kPlantInitCases[(int)SeedType::NUM_SEED_TYPES] = {
    &PlantInitPeashooter,  // 0 SEED_PEASHOOTER（共体）
    &PlantInitDefault,  // 1 SEED_SUNFLOWER（原 default）
    &PlantInitCherrybomb,  // 2 SEED_CHERRYBOMB（共体）
    // 原 case SEED_WALLNUT
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mPlantHealth = 4000;
            p.mBlinkCountdown = 1000 + Sexy::Rand(1000);
    },  // 3 SEED_WALLNUT
    // 原 case SEED_POTATOMINE
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);

            lc.mBodyReanim->mAnimRate = 12.0f;

            if (p.IsInPlay())
            {
                lc.mBodyReanim->AssignRenderGroupToTrack(ReanimTrackId::anim_glow, RENDER_GROUP_HIDDEN);
                p.mStateCountdown = 1500;
            }
            else
            {
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_armed);
                p.mState = PlantState::STATE_POTATO_ARMED;
            }
    },  // 4 SEED_POTATOMINE
    &PlantInitPeashooter,  // 5 SEED_SNOWPEA（共体）
    // 原 case SEED_CHOMPER
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mState = PlantState::STATE_READY;
    },  // 6 SEED_CHOMPER
    &PlantInitPeashooter,  // 7 SEED_REPEATER（共体）
    &PlantInitPuffshroom,  // 8 SEED_PUFFSHROOM（共体）
    // 原 case SEED_SUNSHROOM
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);

            lc.mBodyReanim->mFrameBasePose = 6;

            if (p.IsInPlay())
            {
                p.mX += Sexy::Rand(10) - 5;
                p.mY += Sexy::Rand(10) - 5;
            }
            else if (p.mIsAsleep)
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_bigsleep);
            else
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_bigidle);

            p.mState = PlantState::STATE_SUNSHROOM_SMALL;
            p.mStateCountdown = 12000;
    },  // 9 SEED_SUNSHROOM
    &PlantInitDefault,  // 10 SEED_FUMESHROOM（原 default）
    // 原 case SEED_GRAVEBUSTER
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);

            if (p.IsInPlay())
            {
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_land);
                lc.mBodyReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;

                p.mState = PlantState::STATE_GRAVEBUSTER_LANDING;
                p.mApp->PlayFoley(FoleyType::FOLEY_GRAVEBUSTERCHOMP);
            }
    },  // 11 SEED_GRAVEBUSTER
    &PlantInitDefault,  // 12 SEED_HYPNOSHROOM（原 default）
    // 原 case SEED_SCAREDYSHROOM
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mState = PlantState::STATE_READY;
    },  // 13 SEED_SCAREDYSHROOM
    &PlantInitDefault,  // 14 SEED_ICESHROOM（原 default）
    &PlantInitDefault,  // 15 SEED_DOOMSHROOM（原 default）
    // 原 case SEED_LILYPAD
    [](Plant& p, PlantInitLocals& lc)
    {
            if (p.IsInPlay())
            {
                p.mState = PlantState::STATE_LILYPAD_INVULNERABLE;
                p.mStateCountdown = 100;
            }
    },  // 16 SEED_LILYPAD
    &PlantInitDefault,  // 17 SEED_SQUASH（原 default）
    // 原 case SEED_THREEPEATER
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);

            lc.mBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
            Reanimation* aHeadReanim1 = p.mApp->AddReanimation(0.0f, 0.0f, p.mRenderOrder + 2, lc.mReanimationType);
            aHeadReanim1->mLoopType = ReanimLoopType::REANIM_LOOP;
            aHeadReanim1->mAnimRate = lc.mBodyReanim->mAnimRate;
            aHeadReanim1->SetFramesForLayer(ReanimTrackId::anim_head_idle1);
            aHeadReanim1->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_head1);
            p.mHeadReanimID = p.mApp->ReanimationGetID(aHeadReanim1);

            Reanimation* aHeadReanim2 = p.mApp->AddReanimation(0.0f, 0.0f, p.mRenderOrder + 2, lc.mReanimationType);
            aHeadReanim2->mLoopType = ReanimLoopType::REANIM_LOOP;
            aHeadReanim2->mAnimRate = lc.mBodyReanim->mAnimRate;
            aHeadReanim2->SetFramesForLayer(ReanimTrackId::anim_head_idle2);
            aHeadReanim2->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_head2);
            p.mHeadReanimID2 = p.mApp->ReanimationGetID(aHeadReanim2);

            Reanimation* aHeadReanim3 = p.mApp->AddReanimation(0.0f, 0.0f, p.mRenderOrder + 2, lc.mReanimationType);
            aHeadReanim3->mLoopType = ReanimLoopType::REANIM_LOOP;
            aHeadReanim3->mAnimRate = lc.mBodyReanim->mAnimRate;
            aHeadReanim3->SetFramesForLayer(ReanimTrackId::anim_head_idle3);
            aHeadReanim3->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_head3);
            p.mHeadReanimID3 = p.mApp->ReanimationGetID(aHeadReanim3);
    },  // 18 SEED_THREEPEATER
    // 原 case SEED_TANGLEKELP
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->SetTruncateDisappearingFramesAll(false);
    },  // 19 SEED_TANGLEKELP
    &PlantInitCherrybomb,  // 20 SEED_JALAPENO（共体）
    &PlantInitDefault,  // 21 SEED_SPIKEWEED（原 default）
    // 原 case SEED_TORCHWOOD
    [](Plant& p, PlantInitLocals& lc)
    {

    },  // 22 SEED_TORCHWOOD
    // 原 case SEED_TALLNUT
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mPlantHealth = 8000;
            p.mHeight = 80;
            p.mBlinkCountdown = 1000 + Sexy::Rand(1000);
    },  // 23 SEED_TALLNUT
    &PlantInitPuffshroom,  // 24 SEED_SEASHROOM（共体）
    // 原 case SEED_PLANTERN
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mStateCountdown = 50;

            if (!p.IsOnBoard() || p.mApp->mGameMode != GameMode::GAMEMODE_CHALLENGE_ZEN_GARDEN)
            {
                p.AddAttachedParticle(p.mX + 40, p.mY + 40, (int)RenderLayer::RENDER_LAYER_FOG + 1, ParticleEffect::PARTICLE_LANTERN_SHINE);
            }
            if (p.IsInPlay())
            {
                p.mApp->PlaySample(Sexy::SOUND_PLANTERN);
            }
    },  // 25 SEED_PLANTERN
    // 原 case SEED_CACTUS
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mState = PlantState::STATE_CACTUS_LOW;
    },  // 26 SEED_CACTUS
    // 原 case SEED_BLOVER
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mDoSpecialCountdown = 50;

            if (p.IsInPlay())
            {
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_blow);
                lc.mBodyReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;
                lc.mBodyReanim->mAnimRate = 20.0f;
            }
            else
            {
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_idle);
                lc.mBodyReanim->mAnimRate = 10.0f;
            }
    },  // 27 SEED_BLOVER
    // 原 case SEED_SPLITPEA
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);

            lc.mBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
            Reanimation* aHeadReanim1 = p.mApp->AddReanimation(0.0f, 0.0f, p.mRenderOrder + 2, lc.mReanimationType);
            aHeadReanim1->mLoopType = ReanimLoopType::REANIM_LOOP;
            aHeadReanim1->mAnimRate = lc.mBodyReanim->mAnimRate;
            aHeadReanim1->SetFramesForLayer(ReanimTrackId::anim_head_idle);
            aHeadReanim1->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_idle);
            p.mHeadReanimID = p.mApp->ReanimationGetID(aHeadReanim1);

            Reanimation* aHeadReanim2 = p.mApp->AddReanimation(0.0f, 0.0f, p.mRenderOrder + 2, lc.mReanimationType);
            aHeadReanim2->mLoopType = ReanimLoopType::REANIM_LOOP;
            aHeadReanim2->mAnimRate = lc.mBodyReanim->mAnimRate;
            aHeadReanim2->SetFramesForLayer(ReanimTrackId::anim_splitpea_idle);
            aHeadReanim2->AttachToAnotherReanimation(lc.mBodyReanim, ReanimTrackId::anim_idle);
            p.mHeadReanimID2 = p.mApp->ReanimationGetID(aHeadReanim2);
    },  // 28 SEED_SPLITPEA
    &PlantInitDefault,  // 29 SEED_STARFRUIT（原 default）
    // 原 case SEED_PUMPKINSHELL
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mPlantHealth = 4000;
            p.mWidth = 120;

            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->AssignRenderGroupToTrack(ReanimTrackId::Pumpkin_back, 1);
    },  // 30 SEED_PUMPKINSHELL
    // 原 case SEED_MAGNETSHROOM
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->SetTruncateDisappearingFramesAll(false);
    },  // 31 SEED_MAGNETSHROOM
    &PlantInitDefault,  // 32 SEED_CABBAGEPULT（原 default）
    // 原 case SEED_FLOWERPOT
    [](Plant& p, PlantInitLocals& lc)
    {
            if (p.IsInPlay())
            {
                p.mState = PlantState::STATE_FLOWERPOT_INVULNERABLE;
                p.mStateCountdown = 100;
            }
    },  // 33 SEED_FLOWERPOT
    // 原 case SEED_KERNELPULT
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Cornpult_butter, RENDER_GROUP_HIDDEN);
    },  // 34 SEED_KERNELPULT
    // 原 case SEED_INSTANT_COFFEE
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mDoSpecialCountdown = 100;
    },  // 35 SEED_INSTANT_COFFEE
    // 原 case SEED_GARLIC
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            p.mPlantHealth = 400;
            lc.mBodyReanim->SetTruncateDisappearingFramesAll(false);
    },  // 36 SEED_GARLIC
    &PlantInitDefault,  // 37 SEED_UMBRELLA（原 default）
    // 原 case SEED_MARIGOLD
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
    },  // 38 SEED_MARIGOLD
    &PlantInitDefault,  // 39 SEED_MELONPULT（原 default）
    &PlantInitPeashooter,  // 40 SEED_GATLINGPEA（共体）
    &PlantInitDefault,  // 41 SEED_TWINSUNFLOWER（原 default）
    &PlantInitDefault,  // 42 SEED_GLOOMSHROOM（原 default）
    &PlantInitDefault,  // 43 SEED_CATTAIL（原 default）
    &PlantInitDefault,  // 44 SEED_WINTERMELON（原 default）
    // 原 case SEED_GOLD_MAGNET
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->SetTruncateDisappearingFramesAll(false);
    },  // 45 SEED_GOLD_MAGNET
    // 原 case SEED_SPIKEROCK
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mPlantHealth = 450;
            TOD_ASSERT(lc.mBodyReanim);
    },  // 46 SEED_SPIKEROCK
    // 原 case SEED_COBCANNON
    [](Plant& p, PlantInitLocals& lc)
    {
            if (p.IsInPlay())
            {
                p.mState = PlantState::STATE_COBCANNON_ARMING;
                p.mStateCountdown = 500;

                TOD_ASSERT(lc.mBodyReanim);
                lc.mBodyReanim->SetFramesForLayer(ReanimTrackId::anim_unarmed_idle);
            }
    },  // 47 SEED_COBCANNON
    // 原 case SEED_IMITATER
    [](Plant& p, PlantInitLocals& lc)
    {
            TOD_ASSERT(lc.mBodyReanim);
            lc.mBodyReanim->mAnimRate = RandRangeFloat(25.0f, 30.0f);
            p.mStateCountdown = 200;
    },  // 48 SEED_IMITATER
    // 原 case SEED_EXPLODE_O_NUT
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mPlantHealth = 4000;
            p.mBlinkCountdown = 1000 + Sexy::Rand(1000);
            lc.mBodyReanim->mColorOverride = Color(255, 64, 64);
    },  // 49 SEED_EXPLODE_O_NUT
    // 原 case SEED_GIANT_WALLNUT
    [](Plant& p, PlantInitLocals& lc)
    {
            p.mPlantHealth = 4000;
            p.mBlinkCountdown = 1000 + Sexy::Rand(1000);
    },  // 50 SEED_GIANT_WALLNUT
    // 原 case SEED_SPROUT
    [](Plant& p, PlantInitLocals& lc)
    {

    },  // 51 SEED_SPROUT
    &PlantInitPeashooter,  // 52 SEED_LEFTPEATER（共体）
};
static_assert(sizeof(kPlantInitCases) / sizeof(kPlantInitCases[0]) ==
    (int)SeedType::NUM_SEED_TYPES, "kPlantInitCases 槽位数须与 SeedType 枚举同步");
}  // namespace

// ==================== FormA：cb766530^ 原 switch（逐字；仅签名加 _A 与 noinline） ====================
__declspec(noinline) void Plant::PlantInitialize_A(int theGridX, int theGridY, SeedType theSeedType, SeedType theImitaterType)
{
    mPlantCol = theGridX;
    mRow = theGridY;
    if (mBoard)
    {
        mX = mBoard->GridToPixelX(theGridX, theGridY);
        mY = mBoard->GridToPixelY(theGridX, theGridY);
    }
    mAnimCounter = 0;
    mAnimPing = true;
    mFrame = 0;
    mShootingCounter = 0;
    mShakeOffsetX = 0.0f;
    mShakeOffsetY = 0.0f;
    mFrameLength = RandRangeInt(12, 18);
    mTargetX = -1;
    mTargetY = -1;
    mStartRow = mRow;
    mNumFrames = 5;
    mState = PlantState::STATE_NOTREADY;
    mDead = false;
    mSquished = false;
    mSeedType = theSeedType;
    mImitaterType = theImitaterType;
    mPlantHealth = 300;
    mDoSpecialCountdown = 0;
    mDisappearCountdown = 200;
    mStateCountdown = 0;
    mParticleID = ParticleSystemID::PARTICLESYSTEMID_NULL;
    mBodyReanimID = ReanimationID::REANIMATIONID_NULL;
    mHeadReanimID = ReanimationID::REANIMATIONID_NULL;
    mHeadReanimID2 = ReanimationID::REANIMATIONID_NULL;
    mHeadReanimID3 = ReanimationID::REANIMATIONID_NULL;
    mBlinkReanimID = ReanimationID::REANIMATIONID_NULL;
    mLightReanimID = ReanimationID::REANIMATIONID_NULL;
    mSleepingReanimID = ReanimationID::REANIMATIONID_NULL;
    mBlinkCountdown = 0;
    mRecentlyEatenCountdown = 0;
    mEatenFlashCountdown = 0;
    mBeghouledFlashCountdown = 0;
    mWidth = 80;
    mHeight = 80;
    memset(mMagnetItems, 0, sizeof(mMagnetItems));
    const PlantDefinition& aPlantDef = GetPlantDefinition(theSeedType);
    mIsAsleep = false;
    mWakeUpCounter = 0;
    mOnBungeeState = PlantOnBungeeState::NOT_ON_BUNGEE;
    mPottedPlantIndex = -1;
    mLaunchRate = aPlantDef.mLaunchRate;
    mSubclass = aPlantDef.mSubClass;
    mRenderOrder = CalcRenderOrder();

    Reanimation* aBodyReanim = nullptr;
    if (aPlantDef.mReanimationType != ReanimationType::REANIM_NONE)
    {
        float aOffsetY = PlantDrawHeightOffset(mBoard, this, mSeedType, mPlantCol, mRow);
        aBodyReanim = mApp->AddReanimation(0.0f, aOffsetY, mRenderOrder + 1, aPlantDef.mReanimationType);
        aBodyReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aBodyReanim->mAnimRate = RandRangeFloat(10.0f, 15.0f);

        if (aBodyReanim->TrackExists(ReanimTrackId::anim_idle))
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_idle);

        if (mApp->IsWallnutBowlingLevel() && aBodyReanim->TrackExists(ReanimTrackId::_ground))
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::_ground);
            if (mSeedType == SeedType::SEED_WALLNUT || mSeedType == SeedType::SEED_EXPLODE_O_NUT)
                aBodyReanim->mAnimRate = RandRangeFloat(12.0f, 18.0f);
            else if (mSeedType == SeedType::SEED_GIANT_WALLNUT)
                aBodyReanim->mAnimRate = RandRangeFloat(6.0f, 10.0f);
        }

        aBodyReanim->mIsAttachment = true;
        mBodyReanimID = mApp->ReanimationGetID(aBodyReanim);
        mBlinkCountdown = 400 + Sexy::Rand(400);
    }

    if (IsNocturnal(mSeedType) && mBoard && !mBoard->StageIsNight())
        SetSleeping(true);

    if (mLaunchRate > 0)
    {
        if (MakesSun())
            mLaunchCounter = RandRangeInt(300, mLaunchRate / 2);
        else
            mLaunchCounter = RandRangeInt(0, mLaunchRate);
    }
    else
        mLaunchCounter = 0;

    switch (theSeedType)
    {
    case SeedType::SEED_BLOVER:
    {
        mDoSpecialCountdown = 50;

        if (IsInPlay())
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_blow);
            aBodyReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;
            aBodyReanim->mAnimRate = 20.0f;
        }
        else
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_idle);
            aBodyReanim->mAnimRate = 10.0f;
        }

        break;
    }
    case SeedType::SEED_PEASHOOTER:
    case SeedType::SEED_SNOWPEA:
    case SeedType::SEED_REPEATER:
    case SeedType::SEED_LEFTPEATER:
    case SeedType::SEED_GATLINGPEA:
        if (aBodyReanim)
        {
            aBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
            Reanimation* aHeadReanim = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder + 2, aPlantDef.mReanimationType);
            aHeadReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
            aHeadReanim->mAnimRate = aBodyReanim->mAnimRate;
            aHeadReanim->SetFramesForLayer(ReanimTrackId::anim_head_idle);
            mHeadReanimID = mApp->ReanimationGetID(aHeadReanim);

            if (aBodyReanim->TrackExists(ReanimTrackId::anim_stem))
                aHeadReanim->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_stem);
            else if (aBodyReanim->TrackExists(ReanimTrackId::anim_idle))
                aHeadReanim->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_idle);
        }
        break;
    case SeedType::SEED_SPLITPEA:
    {
        TOD_ASSERT(aBodyReanim);

        aBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
        Reanimation* aHeadReanim1 = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder + 2, aPlantDef.mReanimationType);
        aHeadReanim1->mLoopType = ReanimLoopType::REANIM_LOOP;
        aHeadReanim1->mAnimRate = aBodyReanim->mAnimRate;
        aHeadReanim1->SetFramesForLayer(ReanimTrackId::anim_head_idle);
        aHeadReanim1->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_idle);
        mHeadReanimID = mApp->ReanimationGetID(aHeadReanim1);

        Reanimation* aHeadReanim2 = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder + 2, aPlantDef.mReanimationType);
        aHeadReanim2->mLoopType = ReanimLoopType::REANIM_LOOP;
        aHeadReanim2->mAnimRate = aBodyReanim->mAnimRate;
        aHeadReanim2->SetFramesForLayer(ReanimTrackId::anim_splitpea_idle);
        aHeadReanim2->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_idle);
        mHeadReanimID2 = mApp->ReanimationGetID(aHeadReanim2);

        break;
    }
    case SeedType::SEED_THREEPEATER:
    {
        TOD_ASSERT(aBodyReanim);

        aBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
        Reanimation* aHeadReanim1 = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder + 2, aPlantDef.mReanimationType);
        aHeadReanim1->mLoopType = ReanimLoopType::REANIM_LOOP;
        aHeadReanim1->mAnimRate = aBodyReanim->mAnimRate;
        aHeadReanim1->SetFramesForLayer(ReanimTrackId::anim_head_idle1);
        aHeadReanim1->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_head1);
        mHeadReanimID = mApp->ReanimationGetID(aHeadReanim1);

        Reanimation* aHeadReanim2 = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder + 2, aPlantDef.mReanimationType);
        aHeadReanim2->mLoopType = ReanimLoopType::REANIM_LOOP;
        aHeadReanim2->mAnimRate = aBodyReanim->mAnimRate;
        aHeadReanim2->SetFramesForLayer(ReanimTrackId::anim_head_idle2);
        aHeadReanim2->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_head2);
        mHeadReanimID2 = mApp->ReanimationGetID(aHeadReanim2);

        Reanimation* aHeadReanim3 = mApp->AddReanimation(0.0f, 0.0f, mRenderOrder + 2, aPlantDef.mReanimationType);
        aHeadReanim3->mLoopType = ReanimLoopType::REANIM_LOOP;
        aHeadReanim3->mAnimRate = aBodyReanim->mAnimRate;
        aHeadReanim3->SetFramesForLayer(ReanimTrackId::anim_head_idle3);
        aHeadReanim3->AttachToAnotherReanimation(aBodyReanim, ReanimTrackId::anim_head3);
        mHeadReanimID3 = mApp->ReanimationGetID(aHeadReanim3);

        break;
    }
    case SeedType::SEED_WALLNUT:
        mPlantHealth = 4000;
        mBlinkCountdown = 1000 + Sexy::Rand(1000);
        break;
    case SeedType::SEED_EXPLODE_O_NUT:
        mPlantHealth = 4000;
        mBlinkCountdown = 1000 + Sexy::Rand(1000);
        aBodyReanim->mColorOverride = Color(255, 64, 64);
        break;
    case SeedType::SEED_GIANT_WALLNUT:
        mPlantHealth = 4000;
        mBlinkCountdown = 1000 + Sexy::Rand(1000);
        break;
    case SeedType::SEED_TALLNUT:
        mPlantHealth = 8000;
        mHeight = 80;
        mBlinkCountdown = 1000 + Sexy::Rand(1000);
        break;
    case SeedType::SEED_GARLIC:
        TOD_ASSERT(aBodyReanim);
        mPlantHealth = 400;
        aBodyReanim->SetTruncateDisappearingFramesAll(false);
        break;
    case SeedType::SEED_GOLD_MAGNET:
        TOD_ASSERT(aBodyReanim);
        aBodyReanim->SetTruncateDisappearingFramesAll(false);
        break;
    case SeedType::SEED_IMITATER:
        TOD_ASSERT(aBodyReanim);
        aBodyReanim->mAnimRate = RandRangeFloat(25.0f, 30.0f);
        mStateCountdown = 200;
        break;
    case SeedType::SEED_CHERRYBOMB:
    case SeedType::SEED_JALAPENO:
    {
        TOD_ASSERT(aBodyReanim);

        if (IsInPlay())
        {
            mDoSpecialCountdown = 100;

            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_explode);
            aBodyReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;

            mApp->PlayFoley(FoleyType::FOLEY_REVERSE_EXPLOSION);
        }

        break;
    }
    case SeedType::SEED_POTATOMINE:
    {
        TOD_ASSERT(aBodyReanim);

        aBodyReanim->mAnimRate = 12.0f;

        if (IsInPlay())
        {
            aBodyReanim->AssignRenderGroupToTrack(ReanimTrackId::anim_glow, RENDER_GROUP_HIDDEN);
            mStateCountdown = 1500;
        }
        else
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_armed);
            mState = PlantState::STATE_POTATO_ARMED;
        }

        break;
    }
    case SeedType::SEED_GRAVEBUSTER:
    {
        TOD_ASSERT(aBodyReanim);

        if (IsInPlay())
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_land);
            aBodyReanim->mLoopType = ReanimLoopType::REANIM_PLAY_ONCE_AND_HOLD;

            mState = PlantState::STATE_GRAVEBUSTER_LANDING;
            mApp->PlayFoley(FoleyType::FOLEY_GRAVEBUSTERCHOMP);
        }

        break;
    }
    case SeedType::SEED_SUNSHROOM:
    {
        TOD_ASSERT(aBodyReanim);

        aBodyReanim->mFrameBasePose = 6;

        if (IsInPlay())
        {
            mX += Sexy::Rand(10) - 5;
            mY += Sexy::Rand(10) - 5;
        }
        else if (mIsAsleep)
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_bigsleep);
        else
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_bigidle);

        mState = PlantState::STATE_SUNSHROOM_SMALL;
        mStateCountdown = 12000;

        break;
    }
    case SeedType::SEED_PUFFSHROOM:
    case SeedType::SEED_SEASHROOM:
        if (IsInPlay())
        {
            mX += Sexy::Rand(10) - 5;
            mY += Sexy::Rand(6) - 3;
        }
        break;
    case SeedType::SEED_PUMPKINSHELL:
    {
        mPlantHealth = 4000;
        mWidth = 120;

        TOD_ASSERT(aBodyReanim);
        aBodyReanim->AssignRenderGroupToTrack(ReanimTrackId::Pumpkin_back, 1);
        break;
    }
    case SeedType::SEED_CHOMPER:
        mState = PlantState::STATE_READY;
        break;
    case SeedType::SEED_PLANTERN:
    {
        mStateCountdown = 50;

        if (!IsOnBoard() || mApp->mGameMode != GameMode::GAMEMODE_CHALLENGE_ZEN_GARDEN)
        {
            AddAttachedParticle(mX + 40, mY + 40, (int)RenderLayer::RENDER_LAYER_FOG + 1, ParticleEffect::PARTICLE_LANTERN_SHINE);
        }
        if (IsInPlay())
        {
            mApp->PlaySample(Sexy::SOUND_PLANTERN);
        }
        
        break;
    }
    case SeedType::SEED_TORCHWOOD:
        break;
    case SeedType::SEED_MARIGOLD:
        TOD_ASSERT(aBodyReanim);
        aBodyReanim->mAnimRate = RandRangeFloat(15.0f, 20.0f);
        break;
    case SeedType::SEED_CACTUS:
        mState = PlantState::STATE_CACTUS_LOW;
        break;
    case SeedType::SEED_INSTANT_COFFEE:
        mDoSpecialCountdown = 100;
        break;
    case SeedType::SEED_SCAREDYSHROOM:
        mState = PlantState::STATE_READY;
        break;
    case SeedType::SEED_COBCANNON:
        if (IsInPlay())
        {
            mState = PlantState::STATE_COBCANNON_ARMING;
            mStateCountdown = 500;

            TOD_ASSERT(aBodyReanim);
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_unarmed_idle);
        }
        break;
    case SeedType::SEED_KERNELPULT:
        TOD_ASSERT(aBodyReanim);
        aBodyReanim->AssignRenderGroupToRange(ReanimTrackRanges::Cornpult_butter, RENDER_GROUP_HIDDEN);
        break;
    case SeedType::SEED_MAGNETSHROOM:
        TOD_ASSERT(aBodyReanim);
        aBodyReanim->SetTruncateDisappearingFramesAll(false);
        break;
    case SeedType::SEED_SPIKEROCK:
        mPlantHealth = 450;
        TOD_ASSERT(aBodyReanim);
        break;
    case SeedType::SEED_SPROUT:
        break;
    case SeedType::SEED_FLOWERPOT:
        if (IsInPlay())
        {
            mState = PlantState::STATE_FLOWERPOT_INVULNERABLE;
            mStateCountdown = 100;
        }
        break;
    case SeedType::SEED_LILYPAD:
        if (IsInPlay())
        {
            mState = PlantState::STATE_LILYPAD_INVULNERABLE;
            mStateCountdown = 100;
        }
        break;
    case SeedType::SEED_TANGLEKELP:
        TOD_ASSERT(aBodyReanim);
        aBodyReanim->SetTruncateDisappearingFramesAll(false);
    default:
        break;
    }
    
    if ((mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BIG_TIME) &&
        (theSeedType == SeedType::SEED_WALLNUT || theSeedType == SeedType::SEED_SUNFLOWER || theSeedType == SeedType::SEED_MARIGOLD))
    {
        mPlantHealth *= 2;
    }
    mPlantMaxHealth = mPlantHealth;

    if (mSeedType != SeedType::SEED_FLOWERPOT && IsOnBoard())
    {
        TOD_ASSERT(mBoard);
        Plant* aFlowerPot = mBoard->GetFlowerPotAt(mPlantCol, mRow);
        if (aFlowerPot)
            mApp->ReanimationGet(aFlowerPot->mBodyReanimID)->mAnimRate = 0.0f;
    }
}

// ==================== FormB 驱动（HEAD 462-580 逐字；仅签名加 _B 与 noinline） ====================
__declspec(noinline) void Plant::PlantInitialize_B(int theGridX, int theGridY, SeedType theSeedType, SeedType theImitaterType)
{
    mPlantCol = theGridX;
    mRow = theGridY;
    if (mBoard)
    {
        mX = mBoard->GridToPixelX(theGridX, theGridY);
        mY = mBoard->GridToPixelY(theGridX, theGridY);
    }
    mAnimCounter = 0;
    mAnimPing = true;
    mFrame = 0;
    mShootingCounter = 0;
    mShakeOffsetX = 0.0f;
    mShakeOffsetY = 0.0f;
    mFrameLength = RandRangeInt(12, 18);
    mTargetX = -1;
    mTargetY = -1;
    mStartRow = mRow;
    mNumFrames = 5;
    mState = PlantState::STATE_NOTREADY;
    mDead = false;
    mSquished = false;
    mSeedType = theSeedType;
    mImitaterType = theImitaterType;
    mPlantHealth = 300;
    mDoSpecialCountdown = 0;
    mDisappearCountdown = 200;
    mStateCountdown = 0;
    mParticleID = ParticleSystemID::PARTICLESYSTEMID_NULL;
    mBodyReanimID = ReanimationID::REANIMATIONID_NULL;
    mHeadReanimID = ReanimationID::REANIMATIONID_NULL;
    mHeadReanimID2 = ReanimationID::REANIMATIONID_NULL;
    mHeadReanimID3 = ReanimationID::REANIMATIONID_NULL;
    mBlinkReanimID = ReanimationID::REANIMATIONID_NULL;
    mLightReanimID = ReanimationID::REANIMATIONID_NULL;
    mSleepingReanimID = ReanimationID::REANIMATIONID_NULL;
    mBlinkCountdown = 0;
    mRecentlyEatenCountdown = 0;
    mEatenFlashCountdown = 0;
    mBeghouledFlashCountdown = 0;
    mWidth = 80;
    mHeight = 80;
    memset(mMagnetItems, 0, sizeof(mMagnetItems));
    const PlantDefinition& aPlantDef = GetPlantDefinition(theSeedType);
    mIsAsleep = false;
    mWakeUpCounter = 0;
    mOnBungeeState = PlantOnBungeeState::NOT_ON_BUNGEE;
    mPottedPlantIndex = -1;
    mLaunchRate = aPlantDef.mLaunchRate;
    mSubclass = aPlantDef.mSubClass;
    mRenderOrder = CalcRenderOrder();

    Reanimation* aBodyReanim = nullptr;
    if (aPlantDef.mReanimationType != ReanimationType::REANIM_NONE)
    {
        float aOffsetY = PlantDrawHeightOffset(mBoard, this, mSeedType, mPlantCol, mRow);
        aBodyReanim = mApp->AddReanimation(0.0f, aOffsetY, mRenderOrder + 1, aPlantDef.mReanimationType);
        aBodyReanim->mLoopType = ReanimLoopType::REANIM_LOOP;
        aBodyReanim->mAnimRate = RandRangeFloat(10.0f, 15.0f);

        if (aBodyReanim->TrackExists(ReanimTrackId::anim_idle))
            aBodyReanim->SetFramesForLayer(ReanimTrackId::anim_idle);

        if (mApp->IsWallnutBowlingLevel() && aBodyReanim->TrackExists(ReanimTrackId::_ground))
        {
            aBodyReanim->SetFramesForLayer(ReanimTrackId::_ground);
            if (mSeedType == SeedType::SEED_WALLNUT || mSeedType == SeedType::SEED_EXPLODE_O_NUT)
                aBodyReanim->mAnimRate = RandRangeFloat(12.0f, 18.0f);
            else if (mSeedType == SeedType::SEED_GIANT_WALLNUT)
                aBodyReanim->mAnimRate = RandRangeFloat(6.0f, 10.0f);
        }

        aBodyReanim->mIsAttachment = true;
        mBodyReanimID = mApp->ReanimationGetID(aBodyReanim);
        mBlinkCountdown = 400 + Sexy::Rand(400);
    }

    if (IsNocturnal(mSeedType) && mBoard && !mBoard->StageIsNight())
        SetSleeping(true);

    if (mLaunchRate > 0)
    {
        if (MakesSun())
            mLaunchCounter = RandRangeInt(300, mLaunchRate / 2);
        else
            mLaunchCounter = RandRangeInt(0, mLaunchRate);
    }
    else
        mLaunchCounter = 0;

    // C 形态 -> 匿名 lambda 函数指针表：行序 = SeedType 枚举序（0..52），
    // 越界（BEGHOULED 按钮等哨兵）落表外守卫 = 原 default 无操作。
    PlantInitLocals aInitLocals{aBodyReanim, aPlantDef.mReanimationType};
    const unsigned aSeedIndex = static_cast<unsigned>(theSeedType);
    if (aSeedIndex < static_cast<unsigned>(SeedType::NUM_SEED_TYPES))
    {
        kPlantInitCases[aSeedIndex](*this, aInitLocals);
    }

    
    if ((mApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BIG_TIME) &&
        (theSeedType == SeedType::SEED_WALLNUT || theSeedType == SeedType::SEED_SUNFLOWER || theSeedType == SeedType::SEED_MARIGOLD))
    {
        mPlantHealth *= 2;
    }
    mPlantMaxHealth = mPlantHealth;

    if (mSeedType != SeedType::SEED_FLOWERPOT && IsOnBoard())
    {
        TOD_ASSERT(mBoard);
        Plant* aFlowerPot = mBoard->GetFlowerPotAt(mPlantCol, mRow);
        if (aFlowerPot)
            mApp->ReanimationGet(aFlowerPot->mBodyReanimID)->mAnimRate = 0.0f;
    }
}


// ============================ main ============================
static Plant g_p;
static Board g_board;
static LawnApp g_app;
static CutScene g_cut;

static void ResetP(const R3Input& in)
{
    g_p.mApp = &g_app;
    g_p.mBoard = &g_board;
    g_app.mBoard = &g_board;
    g_board.mApp = &g_app;
    g_board.mCutScene = &g_cut;
    g_board.mBackground = (BackgroundType)(in.d % 10);
    g_app.mGameScene = GameScenes::SCENE_PLAYING;
    g_p.mIsAsleep = false;
    g_p.mPlantHealth = 300;
    g_p.mSeedType = SeedType::SEED_PEASHOOTER;
    g_p.mDead = false;
}

int main()
{
    R3InitPlantDefs();
    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetP(g_inputs[i]);
                SeedType t = (SeedType)(g_inputs[i].a % (int)SeedType::NUM_SEED_TYPES);
                g_p.PlantInitialize_A((int)(g_inputs[i].b % 9), (int)(g_inputs[i].c % 6), t, SeedType::SEED_NONE);
                g_p.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                ResetP(g_inputs[i]);
                SeedType t = (SeedType)(g_inputs[i].a % (int)SeedType::NUM_SEED_TYPES);
                g_p.PlantInitialize_B((int)(g_inputs[i].b % 9), (int)(g_inputs[i].c % 6), t, SeedType::SEED_NONE);
                g_p.HashFold(ck);
            }
        };
        rc |= R3BenchMain("t25_PlantInitialize_kPlantInitCases", reset, pa, pb);
    }
    return rc;
}
