// bench05 | Challenge::ScaryPotterPopulate | 10 case switch -> forbidden-col + pot-placement data tables
// FormA = ac447d19^ (verbatim switch), FormB = HEAD (two constexpr tables + ENDLESS out-of-table).
// Discriminant mGameMode uniform over {GAMEMODE_SCARY_POTTER_1..9, _ENDLESS} (values 53..62).
#include <windows.h>
#include <cstdint>
#include <cstdio>

static uint64_t g_checksum = 0;
static inline void Mix(uint64_t v) { g_checksum = g_checksum * 1315423911ULL + v + 1; }

static const int kN = 2000000;
static uint32_t g_raw[kN];

enum GameMode {
    GAMEMODE_OTHER = 0,
    GAMEMODE_SCARY_POTTER_1 = 53, GAMEMODE_SCARY_POTTER_2, GAMEMODE_SCARY_POTTER_3, GAMEMODE_SCARY_POTTER_4,
    GAMEMODE_SCARY_POTTER_5, GAMEMODE_SCARY_POTTER_6, GAMEMODE_SCARY_POTTER_7, GAMEMODE_SCARY_POTTER_8,
    GAMEMODE_SCARY_POTTER_9, GAMEMODE_SCARY_POTTER_ENDLESS
};
enum ScaryPotType { SCARYPOT_SEED = 0, SCARYPOT_ZOMBIE = 1, SCARYPOT_SUN = 2 };
enum ZombieType {
    ZOMBIE_INVALID = 0, ZOMBIE_NORMAL = 1, ZOMBIE_PAIL = 23, ZOMBIE_FOOTBALL = 24, ZOMBIE_DANCER = 25,
    ZOMBIE_JACK_IN_THE_BOX = 26, ZOMBIE_POLEVAULTER = 29, ZOMBIE_POGO = 33, ZOMBIE_GARGANTUAR = 40
};
enum SeedTypeS {
    SEED_NONE = 0, SEED_PEASHOOTER = 1, SEED_SNOWPEA = 2, SEED_SQUASH = 3, SEED_LEFTPEATER = 4,
    SEED_WALLNUT = 5, SEED_POTATOMINE = 6, SEED_HYPNOSHROOM = 7, SEED_PUFFSHROOM = 8,
    SEED_PUMPKINSHELL = 9, SEED_MAGNETSHROOM = 10, SEED_TALLNUT = 11, SEED_THREEPEATER = 12,
    SEED_TORCHWOOD = 13, SEED_SPIKEWEED = 14, SEED_PLANTERN = 15
};
const int GRIDITEM_STATE_SCARY_POT_LEAF = 30;
const int MAX_SCARY_POTS = 54;
const int MAX_GRID_SIZE_X = 9;
const int MAX_GRID_SIZE_Y = 6;

static inline void TOD_ASSERT_IMPL(bool) {}
#define TOD_ASSERT(x) TOD_ASSERT_IMPL((x))  // release no-op (game asserts compiled out)
static inline int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct TodWeightedGridArray { int mX; int mY; int mWeight; };
struct AppStub { bool IsAdventureMode() { return false; } GameMode mGameMode; void GiveAch(int id) { Mix(4); Mix((uint64_t)id); } };
struct BoardStub { int mLevel; };
static AppStub g_app;
static BoardStub g_board;

struct ChallengeStub {
    AppStub* mApp;
    BoardStub* mBoard;
    int mSurvivalStage;
    int mScaryPotterPots;

    void ScaryPotterDontPlaceInCol(int col, TodWeightedGridArray* arr, int cnt) { Mix(1); Mix((uint64_t)col + cnt * 31); (void)arr; }
    void ScaryPotterPlacePot(ScaryPotType pot, ZombieType z, SeedTypeS s, int count, TodWeightedGridArray* arr, int cnt) {
        Mix(2); Mix((uint64_t)pot * 1000003 + (uint64_t)z * 6007 + (uint64_t)s * 131 + (uint64_t)count + cnt);
        (void)arr;
    }
    void ScaryPotterChangePotType(int state, int count) { Mix(3); Mix((uint64_t)state * 97 + count); }
    int ScaryPotterCountPots() { Mix(5); return 71; }
};
static ChallengeStub g_challenge;

// ================= FormA: verbatim switch (ac447d19^) =================
static void ScaryPotterPopulateA()
{
    int aGridArrayCount = 0;
    TodWeightedGridArray aGridArray[MAX_SCARY_POTS];
    for (int aGridX = 0; aGridX < MAX_GRID_SIZE_X; aGridX++)
    {
        for (int aGridY = 0; aGridY < MAX_GRID_SIZE_Y - 1; aGridY++)
        {
            aGridArray[aGridArrayCount].mX = aGridX;
            aGridArray[aGridArrayCount].mY = aGridY;
            aGridArray[aGridArrayCount].mWeight = 1;
            aGridArrayCount++;

            TOD_ASSERT(aGridArrayCount <= MAX_SCARY_POTS);
        }
    }

    if (g_challenge.mApp->IsAdventureMode() && g_challenge.mBoard->mLevel == 35)
    {
        switch (g_challenge.mSurvivalStage)
        {
        case 0:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            break;
        case 1:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case 2:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_DANCER, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 3);
            break;
        }
    }
    else
    {
        switch (g_challenge.mApp->mGameMode)
        {
        case GAMEMODE_SCARY_POTTER_1:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_2:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(8, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 7, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_POTATOMINE, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_3:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 8, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_DANCER, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_4:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PUFFSHROOM, 11, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 8, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 7, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_5:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PUMPKINSHELL, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_MAGNETSHROOM, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_6:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 7, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_TALLNUT, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_THREEPEATER, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_TORCHWOOD, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 7, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_POLEVAULTER, SEED_NONE, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_7:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SPIKEWEED, 13, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 10, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_8:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PUFFSHROOM, 7, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 8, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_POGO, SEED_NONE, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_9:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_THREEPEATER, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_POTATOMINE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PLANTERN, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 8, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_GARGANTUAR, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case GAMEMODE_SCARY_POTTER_ENDLESS:
        {
            int aNumExtraGargantuars = ClampInt(g_challenge.mSurvivalStage / 10, 0, 8);
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_THREEPEATER, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_POTATOMINE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PLANTERN, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SUN, ZOMBIE_INVALID, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 8 - aNumExtraGargantuars, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_GARGANTUAR, SEED_NONE, 1 + aNumExtraGargantuars, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);

            if (g_challenge.mSurvivalStage == 15)
                g_challenge.mApp->GiveAch(1);

            break;
        }
        default:
            TOD_ASSERT(false);
            break;
        }
    }

    g_challenge.mScaryPotterPots = g_challenge.ScaryPotterCountPots();
}

// ================= FormB: HEAD two-table form =================
namespace {
struct ScaryPotterPot { ScaryPotType mPotType; ZombieType mZombieType; SeedTypeS mSeedType; int mCount; };
constexpr int kScaryPotterDontPlaceCols[9][4] = {
    {0, 1, 2, 3}, {0, 1, 2, 8}, {0, 1, 2, -1}, {0, 1, -1, -1}, {0, 1, -1, -1},
    {0, 1, -1, -1}, {0, 1, 2, -1}, {0, 1, -1, -1}, {0, 1, -1, -1},
};
constexpr ScaryPotterPot kScaryPotterPots[] = {
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 5},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 5},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6},
    {SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 3},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 7},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_POTATOMINE, 2},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6},
    {SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 3},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 4},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 8},
    {SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 2},
    {SCARYPOT_ZOMBIE, ZOMBIE_DANCER, SEED_NONE, 1},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PUFFSHROOM, 11},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 4},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 4},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 8},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 7},
    {SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PUMPKINSHELL, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 4},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_MAGNETSHROOM, 3},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6},
    {SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 5},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1},
    {SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 7},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_TALLNUT, 5},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_THREEPEATER, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_TORCHWOOD, 4},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 7},
    {SCARYPOT_ZOMBIE, ZOMBIE_POLEVAULTER, SEED_NONE, 5},
    {SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 2},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SPIKEWEED, 13},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 3},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 10},
    {SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PUFFSHROOM, 7},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 3},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 4},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 8},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 4},
    {SCARYPOT_ZOMBIE, ZOMBIE_POGO, SEED_NONE, 4},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_THREEPEATER, 2},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_POTATOMINE, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 1},
    {SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PLANTERN, 1},
    {SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 8},
    {SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 5},
    {SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1},
    {SCARYPOT_ZOMBIE, ZOMBIE_GARGANTUAR, SEED_NONE, 1},
};
constexpr int kScaryPotterPotBegin[10] = {0, 6, 13, 22, 28, 38, 47, 52, 59, 71};
static_assert(sizeof(kScaryPotterPots) / sizeof(kScaryPotterPots[0]) == kScaryPotterPotBegin[9], "pot slot sync");
static_assert(sizeof(kScaryPotterDontPlaceCols) / sizeof(kScaryPotterDontPlaceCols[0]) == 9, "col slot sync");
}  // namespace

static void ScaryPotterPopulateB()
{
    int aGridArrayCount = 0;
    TodWeightedGridArray aGridArray[MAX_SCARY_POTS];
    for (int aGridX = 0; aGridX < MAX_GRID_SIZE_X; aGridX++)
    {
        for (int aGridY = 0; aGridY < MAX_GRID_SIZE_Y - 1; aGridY++)
        {
            aGridArray[aGridArrayCount].mX = aGridX;
            aGridArray[aGridArrayCount].mY = aGridY;
            aGridArray[aGridArrayCount].mWeight = 1;
            aGridArrayCount++;

            TOD_ASSERT(aGridArrayCount <= MAX_SCARY_POTS);
        }
    }

    if (g_challenge.mApp->IsAdventureMode() && g_challenge.mBoard->mLevel == 35)
    {
        switch (g_challenge.mSurvivalStage)
        {
        case 0:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            break;
        case 1:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 4, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_FOOTBALL, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
            break;
        case 2:
            g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterDontPlaceInCol(3, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_HYPNOSHROOM, 5, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 6, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 2, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_DANCER, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 3);
            break;
        }
    }
    else if (g_challenge.mApp->mGameMode == GAMEMODE_SCARY_POTTER_ENDLESS)
    {
        int aNumExtraGargantuars = ClampInt(g_challenge.mSurvivalStage / 10, 0, 8);
        g_challenge.ScaryPotterDontPlaceInCol(0, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterDontPlaceInCol(1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_LEFTPEATER, 6, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SNOWPEA, 2, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PEASHOOTER, 1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_THREEPEATER, 2, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_SQUASH, 5, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_POTATOMINE, 1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_WALLNUT, 1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SEED, ZOMBIE_INVALID, SEED_PLANTERN, 1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_SUN, ZOMBIE_INVALID, SEED_NONE, 1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_NORMAL, SEED_NONE, 8 - aNumExtraGargantuars, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_PAIL, SEED_NONE, 5, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_JACK_IN_THE_BOX, SEED_NONE, 1, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterPlacePot(SCARYPOT_ZOMBIE, ZOMBIE_GARGANTUAR, SEED_NONE, 1 + aNumExtraGargantuars, aGridArray, aGridArrayCount);
        g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);

        if (g_challenge.mSurvivalStage == 15)
            g_challenge.mApp->GiveAch(1);
    }
    else
    {
        const int aLevelIndex = (int)g_challenge.mApp->mGameMode - (int)GAMEMODE_SCARY_POTTER_1;
        if (aLevelIndex < 0 || aLevelIndex > 8)
        {
            TOD_ASSERT(false);
        }
        else
        {
            for (int k = 0; k < 4 && kScaryPotterDontPlaceCols[aLevelIndex][k] != -1; k++)
            {
                g_challenge.ScaryPotterDontPlaceInCol(kScaryPotterDontPlaceCols[aLevelIndex][k], aGridArray, aGridArrayCount);
            }
            for (int k = kScaryPotterPotBegin[aLevelIndex]; k < kScaryPotterPotBegin[aLevelIndex + 1]; k++)
            {
                const ScaryPotterPot& aPot = kScaryPotterPots[k];
                g_challenge.ScaryPotterPlacePot(aPot.mPotType, aPot.mZombieType, aPot.mSeedType, aPot.mCount, aGridArray, aGridArrayCount);
            }
            g_challenge.ScaryPotterChangePotType(GRIDITEM_STATE_SCARY_POT_LEAF, 2);
        }
    }

    g_challenge.mScaryPotterPots = g_challenge.ScaryPotterCountPots();
}

// ---------------- harness ----------------
static double g_nsPerTick = 0;
static inline double QpcNs() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * g_nsPerTick; }

static void SetupState(int i)
{
    uint32_t v = g_raw[i];
    g_app.mGameMode = (GameMode)(53 + (v % 10));
    g_challenge.mApp = &g_app;
    g_challenge.mBoard = &g_board;
    g_challenge.mSurvivalStage = (int)((v >> 8) % 30);
    g_challenge.mScaryPotterPots = 0;
    g_board.mLevel = 1;
}

int main()
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_nsPerTick = 1e9 / (double)f.QuadPart;
    uint32_t x = 0x9E3779B9u;
    for (int i = 0; i < kN; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_raw[i] = x; }

    double bestA = 1e300, bestB = 1e300;
    uint64_t csA = 0, csB = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); ScaryPotterPopulateA(); Mix(g_challenge.mScaryPotterPots); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestA) bestA = ns;
    }
    csA = g_checksum; g_checksum = 0;
    for (int r = 0; r < 5; r++) {
        double t0 = QpcNs();
        for (int i = 0; i < kN; i++) { SetupState(i); ScaryPotterPopulateB(); Mix(g_challenge.mScaryPotterPots); }
        double t1 = QpcNs();
        double ns = (t1 - t0) / kN; if (ns < bestB) bestB = ns;
    }
    csB = g_checksum;

    printf("Challenge::ScaryPotterPopulate | before %.2f ns | after %.2f ns | diff %+.1f%% | csA=%llx csB=%llx %s\n",
        bestA, bestB, (bestB - bestA) / bestA * 100.0,
        (unsigned long long)csA, (unsigned long long)csB, csA == csB ? "checksum=OK" : "checksum=FAIL");
    return csA == csB ? 0 : 1;
}
