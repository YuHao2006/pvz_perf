// r3_stubs.h — 游戏对象桩（第二段）：Image 全局/PlayerInfo/Board/LawnApp/Zombie/Plant/
// CursorObject/MessageWidget/StoreScreen/Music/Coin/Almanac/输入数组/计时框架
#pragma once
#include "r3_common.h"

// ============================ Image 全局（X 宏 + __COUNTER__ 分槽） ============================
#define R3_PLAIN_IMGS(X) \
    X(IMAGE_ICETRAP) X(IMAGE_ICETRAP2) X(IMAGE_REANIM_CORNPULT_BUTTER_SPLAT) \
    X(IMAGE_SPOTLIGHT2) X(IMAGE_SPOTLIGHT) \
    X(IMAGE_REANIM_ZOMBIE_OUTERARM_HAND) X(IMAGE_REANIM_ZOMBIE_PAPER_LEFTARM_LOWER) \
    X(IMAGE_REANIM_ZOMBIE_FOOTBALL_LEFTARM_HAND) X(IMAGE_REANIM_ZOMBIE_DISCO_OUTERARM_HAND) \
    X(IMAGE_REANIM_ZOMBIE_BACKUP_INNERARM_HAND) X(IMAGE_REANIM_ZOMBIE_BOBSLED_OUTERARM_HAND) \
    X(IMAGE_ZOMBIEJACKBOXARM) X(IMAGE_ZOMBIEDIGGERARM) X(IMAGE_REANIM_ZOMBIE_IMP_ARM2) \
    X(IMAGE_REANIM_ZOMBIE_YETI_OUTERARM_HAND) \
    X(IMAGE_REANIM_ZOMBIE_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_POLEVAULTER_OUTERARM_UPPER2) \
    X(IMAGE_REANIM_ZOMBIE_PAPER_LEFTARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_FOOTBALL_LEFTARM_UPPER2) \
    X(IMAGE_REANIM_ZOMBIE_DISCO_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_BACKUP_OUTERARM_UPPER2) \
    X(IMAGE_REANIM_ZOMBIE_SNORKLE_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_BOBSLED_OUTERARM_UPPER2) \
    X(IMAGE_REANIM_ZOMBIE_DOLPHINRIDER_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_JACKBOX_OUTERARM_LOWER2) \
    X(IMAGE_REANIM_ZOMBIE_BALLOON_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_DIGGER_OUTERARM_UPPER2) \
    X(IMAGE_REANIM_ZOMBIE_POGO_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_YETI_OUTERARM_UPPER2) \
    X(IMAGE_REANIM_ZOMBIE_LADDER_OUTERARM_UPPER2) X(IMAGE_REANIM_ZOMBIE_IMP_ARM1_BONE) \
    X(IMAGE_REANIM_ZOMBIE_POGO_STICKHANDS2) X(IMAGE_REANIM_ZOMBIE_POGO_STICKDAMAGE2) \
    X(IMAGE_REANIM_ZOMBIE_POGO_STICK2DAMAGE2) X(IMAGE_REANIM_ZOMBIE_FLAG3) \
    X(IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES1) X(IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES2) \
    X(IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES3) X(IMAGE_REANIM_ZOMBIE_HEAD_SUNGLASSES4) \
    X(IMAGE_REANIM_ZOMBIE_MUSTACHE2) X(IMAGE_REANIM_ZOMBIE_MUSTACHE3) \
    X(IMAGE_REANIM_ZOMBIE_BOSS_EYEGLOW_BLUE) X(IMAGE_REANIM_ZOMBIE_BOSS_MOUTHGLOW_BLUE) \
    X(IMAGE_REANIM_ZOMBIE_GARGANTUAR_ZOMBIE) X(IMAGE_REANIM_ZOMBIE_GARGANTUAR_DUCKXING) \
    X(IMAGE_REANIM_ZOMBIE_GARGANTUAR_HEAD_REDEYE) X(IMAGE_BLANK) \
    X(IMAGE_BACKGROUND1UNSODDED) X(IMAGE_SOD1ROW) X(IMAGE_SOD3ROW) X(IMAGE_ICE) X(IMAGE_ICE_CAP) \
    X(IMAGE_SEEDS) X(IMAGE_TROPHY) X(IMAGE_SHOVEL) X(IMAGE_ALMANAC) X(IMAGE_CARKEYS) \
    X(IMAGE_SCARY_POT) X(IMAGE_WATERINGCAN) X(IMAGE_TACO) X(IMAGE_ZOMBIE_NOTE_SMALL) \
    X(IMAGE_PRESENT) X(IMAGE_MONEYBAG) X(IMAGE_SUNFLOWER_TROPHY) X(IMAGE_CHOCOLATE) \
    X(IMAGE_COBCANNON_TARGET) X(IMAGE_ZEN_GOLDTOOLRETICLE) X(IMAGE_WATERINGCANGOLD) \
    X(IMAGE_FERTILIZER) X(IMAGE_BUG_SPRAY) X(IMAGE_PHONOGRAPH) X(IMAGE_ZEN_GARDENGLOVE) \
    X(IMAGE_ZEN_MONEYSIGN) X(IMAGE_ZEN_WHEELBARROW) X(IMAGE_TREEFOOD)
#define R3_SEXY_IMGS(X) \
    X(IMAGE_BACKGROUND1) X(IMAGE_BACKGROUND2) X(IMAGE_BACKGROUND3) X(IMAGE_BACKGROUND4) \
    X(IMAGE_BACKGROUND1UNSODDED) X(IMAGE_SOD1ROW) X(IMAGE_SOD2ROW) X(IMAGE_SOD3ROW) X(IMAGE_SOD4ROW) X(IMAGE_BACKGROUND6BOSS2) \
    X(IMAGE_BACKGROUND5) X(IMAGE_BACKGROUND6BOSS) X(IMAGE_BACKGROUND_MUSHROOMGARDEN) \
    X(IMAGE_BACKGROUND_GREENHOUSE) X(IMAGE_AQUARIUM1) \
    X(IMAGE_BACKGROUND1_GAMEOVER_INTERIOR_OVERLAY) X(IMAGE_BACKGROUND2_GAMEOVER_INTERIOR_OVERLAY) \
    X(IMAGE_BACKGROUND3_GAMEOVER_INTERIOR_OVERLAY) X(IMAGE_BACKGROUND4_GAMEOVER_INTERIOR_OVERLAY) \
    X(IMAGE_BACKGROUND1_GAMEOVER_MASK) X(IMAGE_BACKGROUND2_GAMEOVER_MASK) \
    X(IMAGE_BACKGROUND3_GAMEOVER_MASK) X(IMAGE_BACKGROUND4_GAMEOVER_MASK) \
    X(IMAGE_BACKGROUND5_GAMEOVER_MASK) X(IMAGE_BACKGROUND6_GAMEOVER_MASK) \
    X(IMAGE_ALMANAC_ZOMBIEBACK) X(IMAGE_ALMANAC_ZOMBIEBLANK) X(IMAGE_ALMANAC_ZOMBIEWINDOW) \
    X(IMAGE_ALMANAC_ZOMBIEWINDOW2) X(IMAGE_ALMANAC_GROUNDICE) X(IMAGE_ALMANAC_GROUNDDAY) X(IMAGE_ALMANAC_ZOMBIECARD)

constexpr int R3_IMG_BASE = 8;   // 避开 GetImageOverride 桩用的 60..69 槽
#define R3_DECL_PLAIN(name) inline Image* name = ZBImg(R3_IMG_BASE + __COUNTER__);
R3_PLAIN_IMGS(R3_DECL_PLAIN)
namespace Sexy
{
#define R3_DECL_SEXY(name) inline Image* name = ::ZBImg(R3_IMG_BASE + 100 + __COUNTER__);
    R3_SEXY_IMGS(R3_DECL_SEXY)
}

// ============================ gStr：真值（仓库 LawnStrings.h 经 ReanimTrackId.h 引入；
// 定义在仓库 Sexy.TodLib/generated/LawnStrings.cpp，随基准一并编译） ============================
inline int sexystrlen(const SexyString& s) { return (int)s.size(); }
inline SexyString TodReplaceString(const SexyString& src, const SexyString& tok, const SexyString& rep)
{
    ZSink(RID_Msg_TodReplaceString, (uint32_t)tok.size(), (uint32_t)rep.size());
    return src + rep;
}

// ============================ 小支撑类型 ============================
struct ZombieDrawPosition
{
    float mImageOffsetX = 0, mImageOffsetY = 0, mHeadX = 0, mHeadY = 0, mBodyY = 0, mClipHeight = 0;
};
struct HitResult
{
    GameObjectType mObjectType = OBJECT_TYPE_NONE;
    void* mObject = nullptr;
    int mGridX = 0, mGridY = 0;
    bool mFlag = false;
};
struct PottedPlant
{
    SeedType mSeedType = SeedType::SEED_NONE;
    PottedPlantAge mPlantAge = PottedPlantAge::PLANTAGE_SMALL;
    int mPottedPlantIndex = 0;
    __declspec(noinline) void InitializePottedPlant(SeedType theSeedType) { ZSink(RID_PottedPlant_Init, (uint32_t)theSeedType); mSeedType = theSeedType; }
};
struct ZombieDefinition
{
    ZombieType mZombieType = ZOMBIE_NORMAL;
    ReanimationType mReanimationType = ReanimationType::REANIM_NONE;
    int mZombieValue = 0, mStartingLevel = 0, mFirstAllowedWave = 0, mPickWeight = 0;
    const char* mZombieName = "";
};
inline ZombieDefinition gZombieDefs[NUM_ZOMBIE_TYPES];
inline void R3InitZombieDefs()
{
    struct Row { ZombieType t; ReanimationType r; int v, s, w; };
    const Row rows[NUM_ZOMBIE_TYPES] = {
        { ZOMBIE_NORMAL, ReanimationType::REANIM_ZOMBIE, 1, 1, 4000 },
        { ZOMBIE_FLAG, ReanimationType::REANIM_ZOMBIE, 1, 1, 0 },
        { ZOMBIE_TRAFFIC_CONE, ReanimationType::REANIM_ZOMBIE, 2, 3, 4000 },
        { ZOMBIE_POLEVAULTER, ReanimationType::REANIM_POLEVAULTER, 2, 6, 2000 },
        { ZOMBIE_PAIL, ReanimationType::REANIM_ZOMBIE, 4, 8, 3000 },
        { ZOMBIE_NEWSPAPER, ReanimationType::REANIM_ZOMBIE_NEWSPAPER, 2, 11, 1000 },
        { ZOMBIE_DOOR, ReanimationType::REANIM_ZOMBIE, 4, 13, 3500 },
        { ZOMBIE_FOOTBALL, ReanimationType::REANIM_ZOMBIE_FOOTBALL, 7, 16, 2000 },
        { ZOMBIE_DANCER, ReanimationType::REANIM_DANCER, 5, 18, 1000 },
        { ZOMBIE_BACKUP_DANCER, ReanimationType::REANIM_BACKUP_DANCER, 1, 18, 0 },
        { ZOMBIE_DUCKY_TUBE, ReanimationType::REANIM_ZOMBIE, 1, 21, 0 },
        { ZOMBIE_SNORKEL, ReanimationType::REANIM_SNORKEL, 3, 23, 2000 },
        { ZOMBIE_ZAMBONI, ReanimationType::REANIM_ZOMBIE_ZAMBONI, 7, 26, 2000 },
        { ZOMBIE_BOBSLED, ReanimationType::REANIM_BOBSLED, 3, 26, 2000 },
        { ZOMBIE_DOLPHIN_RIDER, ReanimationType::REANIM_ZOMBIE_DOLPHINRIDER, 3, 28, 1500 },
        { ZOMBIE_JACK_IN_THE_BOX, ReanimationType::REANIM_JACKINTHEBOX, 3, 31, 1000 },
        { ZOMBIE_BALLOON, ReanimationType::REANIM_BALLOON, 2, 33, 2000 },
        { ZOMBIE_DIGGER, ReanimationType::REANIM_DIGGER, 4, 36, 1000 },
        { ZOMBIE_POGO, ReanimationType::REANIM_POGO, 4, 38, 1000 },
        { ZOMBIE_YETI, ReanimationType::REANIM_YETI, 4, 40, 1 },
        { ZOMBIE_BUNGEE, ReanimationType::REANIM_BUNGEE, 3, 41, 1000 },
        { ZOMBIE_LADDER, ReanimationType::REANIM_LADDER, 4, 43, 1000 },
        { ZOMBIE_CATAPULT, ReanimationType::REANIM_CATAPULT, 5, 46, 1500 },
        { ZOMBIE_GARGANTUAR, ReanimationType::REANIM_GARGANTUAR, 10, 48, 1500 },
        { ZOMBIE_IMP, ReanimationType::REANIM_IMP, 10, 48, 0 },
        { ZOMBIE_BOSS, ReanimationType::REANIM_BOSS, 10, 50, 0 },
        { ZOMBIE_PEA_HEAD, ReanimationType::REANIM_ZOMBIE, 1, 99, 4000 },
        { ZOMBIE_WALLNUT_HEAD, ReanimationType::REANIM_ZOMBIE, 4, 99, 3000 },
        { ZOMBIE_JALAPENO_HEAD, ReanimationType::REANIM_ZOMBIE, 3, 99, 1000 },
        { ZOMBIE_GATLING_HEAD, ReanimationType::REANIM_ZOMBIE, 3, 99, 2000 },
        { ZOMBIE_SQUASH_HEAD, ReanimationType::REANIM_ZOMBIE, 3, 99, 2000 },
        { ZOMBIE_TALLNUT_HEAD, ReanimationType::REANIM_ZOMBIE, 4, 99, 2000 },
        { ZOMBIE_REDEYE_GARGANTUAR, ReanimationType::REANIM_GARGANTUAR, 10, 48, 6000 },
        { ZOMBIE_ZOMBATAR, ReanimationType::REANIM_ZOMBIE, 1, 1, 0 },
    };
    for (int i = 0; i < NUM_ZOMBIE_TYPES; i++)
    {
        gZombieDefs[i].mZombieType = rows[i].t;
        gZombieDefs[i].mReanimationType = rows[i].r;
        gZombieDefs[i].mZombieValue = rows[i].v;
        gZombieDefs[i].mStartingLevel = rows[i].s;
        gZombieDefs[i].mPickWeight = rows[i].w;
    }
}
inline ZombieDefinition& GetZombieDefinition(ZombieType theZombieType) { return gZombieDefs[(int)theZombieType]; }

// ============================ PlayerInfo / 前向声明 ============================
struct Zombie;
struct Plant;
struct Board;
struct LawnApp;
struct Challenge;
struct ZenGarden;
struct CutScene;
struct CursorObject;
struct Music;
struct Coin;

struct PlayerInfo
{
    int mId = 7;
    int mFinishedAdventure = 1;
    int mPurchases[128] = {};
    int mNumZombatars = 0;
    int mChallengeRecords[64] = {};
    struct ZAvatar { int v = 1; } mZombatars[4];
    PottedPlant mPottedPlant[8];
};
struct WidgetManager { int mLastMouseX = 0, mLastMouseY = 0; bool mMouseIn = true; };
struct WidgetButton { bool mIsOver = false; };
struct CursorPreview { int mX, mY; bool BeginDraw(Graphics*) { ZSink(RID_Coin_BeginDraw); return true; } void Draw(Graphics*) { ZSink(RID_Coin_Draw); } void EndDraw(Graphics*) { ZSink(RID_Coin_EndDraw); } };
struct LawnMower { void Draw(Graphics*) { ZSink(RID_Coin_Draw); } };
struct GridItem { void DrawGridItem(Graphics*) { ZSink(RID_Coin_Draw); } void DrawGridItemOverlay(Graphics*) { ZSink(RID_Coin_EndDraw); } };
struct Projectile { bool BeginDraw(Graphics*) { ZSink(RID_Coin_BeginDraw); return true; } void Draw(Graphics*) { ZSink(RID_Coin_Draw); } void DrawShadow(Graphics*) { ZSink(RID_Coin_Draw); } void EndDraw(Graphics*) { ZSink(RID_Coin_EndDraw); } };

struct Challenge
{
    int mChallengeStateCounter = 0;
    int mSurvivalStage = 0;
    __declspec(noinline) bool TreeOfWisdomCanFeed() { ZSink(RID_Challenge_TreeCanFeed); return true; }
    __declspec(noinline) void TreeOfWisdomFertilize() { ZSink(RID_Challenge_TreeFertilize); }
    __declspec(noinline) void TreeOfWisdomGrow() { ZSink(RID_Challenge_TreeGrow); }
    __declspec(noinline) SeedType GetArtChallengeSeed(int x, int y) { ZSink(RID_Challenge_GetArtSeed, (uint32_t)x, (uint32_t)y); return SeedType::SEED_PEASHOOTER; }
    __declspec(noinline) void DrawWeather(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void DrawBackdrop(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void IZombieMouseDownWithZombie(int, int, int) { ZSink(RID_Coin_Draw); }
};
struct CutScene
{
    int mCutsceneTime = 0;
    int mCrazyDaveDialogStart = 0;
    __declspec(noinline) bool ShowZombieWalking() { ZSink(RID_CutScene_ShowZombieWalking); return true; }
    __declspec(noinline) bool IsInShovelTutorial() { ZSink(RID_CutScene_IsInShovelTutorial); return false; }
};
struct ZenGarden
{
    GardenType mGardenType = GardenType::GARDEN_AQUARIUM;
    __declspec(noinline) void DrawPottedPlant(Graphics* g, float x, float y, PottedPlant* p, float s, bool b)
    {
        ZSink(RID_Zen_DrawPottedPlant, (uint32_t)(int)(x * 4.0f + s * 7.0f), (uint32_t)(int)y, b);
    }
    __declspec(noinline) PottedPlant* GetPottedPlantInWheelbarrow()
    {
        ZSink(RID_Zen_GetWheelbarrow);
        static PottedPlant sPot;
        sPot.mPlantAge = PottedPlantAge::PLANTAGE_SMALL;
        return &sPot;
    }
    __declspec(noinline) SeedType PickRandomSeedType() { ZSink(RID_Zen_PickRandomSeedType); return SeedType::SEED_PEASHOOTER; }
    __declspec(noinline) void DrawPlantOverlay(Graphics* g, Plant* p) { ZSink(RID_Zen_DrawPottedPlant); }
};

// ============================ Board 桩 ============================
struct SeedPacket { int mX = 0, mY = 0; };
struct SeedBank { int mX = 10, mY = 20; SeedPacket mSeedPackets[10]; };
struct R3PlantList
{
    int mSize = 0;
    Plant* DataArrayGet(unsigned int theID);   // 定义于 r3_entities.h（Plant 完整后）
};

struct Board
{
    // 对拍目标读写字段
    LawnApp* mApp = nullptr;
    bool mPaused = false;
    int mLevel = 7;
    int mX = 0, mY = 0;
    int mMainCounter = 1234;
    int mSodPosition = 500;
    BackgroundType mBackground = BackgroundType::BACKGROUND_1_DAY;
    PlantRowType mPlantRow[MAX_GRID_SIZE_Y] = { PLANTROW_NORMAL, PLANTROW_NORMAL, PLANTROW_POOL, PLANTROW_NORMAL, PLANTROW_HIGH_GROUND, PLANTROW_DIRT };
    TutorialState mTutorialState = TutorialState::TUTORIAL_OFF;
    int mTutorialTimer = 0;
    int mSunCountDown = 100;
    int mZombieCountDown = 50;
    int mZombieCountDownStart = 50;
    int mCurrentWave = 1;
    int mNumWaves = 10;
    int mNextSurvivalStageCounter = 0;
    int mProgressMeterWidth = 100;
    int mFogBlownCountDown = 0;
    float mFogOffset = 0.0f;
    int mIceTrapCounter = 0;
    int mIceMinX[MAX_GRID_SIZE_Y] = { 0, 1, 2, 3, 4, 5 };
    int mPrevMouseX = 400, mPrevMouseY = 300;
    GameMode mGameModeHolder = GAMEMODE_ADVENTURE;
    CursorObject* mCursorObject = nullptr;
    CursorPreview* mCursorPreview = nullptr;
    Challenge* mChallenge = nullptr;
    CutScene* mCutScene = nullptr;
    R3PlantList mPlants;
    SeedBank* mSeedBank = nullptr;

    static int MakeRenderOrder(RenderLayer theLayer, int theRow, int theOffset) { return (int)theLayer + theRow * 100 + theOffset; }

    // ---- 舞台查询（纯状态：mBackground 决定，两形态共享） ----
    bool StageIsNight() const { return mBackground == BackgroundType::BACKGROUND_2_NIGHT || mBackground == BackgroundType::BACKGROUND_4_FOG; }
    bool StageHasPool() const { return mBackground == BackgroundType::BACKGROUND_3_POOL || mBackground == BackgroundType::BACKGROUND_4_FOG || mBackground == BackgroundType::BACKGROUND_ZOMBIQUARIUM; }
    bool StageHasGraveStones() const { return StageIsNight(); }
    bool StageHas6Rows() const { return StageHasPool(); }

    // ---- 查询/动作桩 ----
    __declspec(noinline) bool IsFlagWave(int theWave) { ZSink(RID_Board_IsFlagWave, (uint32_t)theWave); return (theWave % 9) == 0; }
    __declspec(noinline) ZombieID ZombieGetID(Zombie* z);
    __declspec(noinline) int PickRowForNewZombie(ZombieType t) { ZSink(RID_Board_PickRowForNewZombie, (uint32_t)t); return Rand(5); }
    __declspec(noinline) Zombie* AddZombieInRow(ZombieType t, int row, int a) { ZSink(RID_Board_AddZombieInRow, (uint32_t)t, (uint32_t)row); return nullptr; }
    __declspec(noinline) bool IteratePlants(Plant*& p)
    {
        ZSink(RID_Board_IteratePlants);
        if (p == nullptr) { p = (Plant*)1; return true; }
        if (p == (Plant*)1) { p = (Plant*)2; return true; }
        return false;
    }
    __declspec(noinline) int CountPlantByType(SeedType t) { ZSink(RID_Board_CountPlantByType, (uint32_t)t); return (int)t % 3; }
    __declspec(noinline) int CountEmptyPotsOrLilies(SeedType t) { ZSink(RID_Board_CountEmptyPots, (uint32_t)t); return (int)t % 2; }
    __declspec(noinline) bool HasValidCobCannonSpot() { ZSink(RID_Board_HasValidCobSpot); return mLevel % 2 == 1; }
    __declspec(noinline) Plant* GetTopPlantAt(int x, int y, PlantPriority) { ZSink(RID_Board_GetTopPlantAt, (uint32_t)x, (uint32_t)y); return ((x + y) % 3 == 0) ? nullptr : (Plant*)1; }
    __declspec(noinline) PlantingReason CanPlantAt(int x, int y, SeedType t) { ZSink(RID_Board_CanPlantAt, (uint32_t)(x * 7 + y), (uint32_t)t); return PlantingReason::PLANTING_OK; }
    __declspec(noinline) int PlantingPixelToGridX(int x, int y, SeedType t) { ZSink(RID_Board_PlantingPixelToGridX, (uint32_t)x); return (x / 80) % 9; }
    __declspec(noinline) int PlantingPixelToGridY(int x, int y, SeedType t) { ZSink(RID_Board_PlantingPixelToGridY, (uint32_t)y); return (y / 100) % 6; }
    __declspec(noinline) SeedType GetSeedTypeInCursor() { ZSink(RID_Board_GetSeedTypeInCursor); return SeedType::SEED_PEASHOOTER; }
    __declspec(noinline) void RefreshSeedPacketFromCursor() { ZSink(RID_Board_RefreshSeedPacket); }
    __declspec(noinline) void MouseHitTest(int x, int y, HitResult* r) { ZSink(RID_Board_MouseHitTest, (uint32_t)x, (uint32_t)y); r->mObjectType = ((x / 80) % 3 == 0) ? OBJECT_TYPE_NONE : OBJECT_TYPE_PLANT; }
    __declspec(noinline) void TutorialArrowShow(float x, float y) { ZSink(RID_Board_TutorialArrowShow, (uint32_t)(int)x, (uint32_t)(int)y); }
    __declspec(noinline) void TutorialArrowRemove() { ZSink(RID_Board_TutorialArrowRemove); }
    __declspec(noinline) void DisplayAdvice(const SexyString& s, MessageStyle st, AdviceType a) { ZSink(RID_Board_DisplayAdvice, (uint32_t)st, (uint32_t)a, (uint32_t)s.size()); }
    __declspec(noinline) void ClearAdvice(AdviceType a) { ZSink(RID_Board_ClearAdvice, (uint32_t)a); }
    __declspec(noinline) Rect GetShovelButtonRect() { ZSink(RID_Board_GetShovelButtonRect); return Rect(640, 0, 80, 80); }
    __declspec(noinline) void SetTutorialStateStub(TutorialState t);   // PickUpTool 内递调（b_board_events.cpp 定义）
    int GridToPixelX(int gx, int gy) { return 80 + gx * 80; }
    int GridToPixelY(int gx, int gy) { return 120 + gy * 100; }
    __declspec(noinline) Plant* GetFlowerPotAt(int gx, int gy);
    __declspec(noinline) int GetNumWavesPerSurvivalStage() { ZSink(RID_Coin_Draw, 41); return 10; }
    __declspec(noinline) int GetNumWavesPerFlag() { ZSink(RID_Coin_Draw, 42); return 3; }
    // 渲染项消费点（FormB 表引用）
    __declspec(noinline) void DrawIce(Graphics*, int y) { ZSink(RID_Coin_Draw, (uint32_t)y); }
    __declspec(noinline) void DrawUITop(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void DrawUIBottom(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void DrawFog(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void DrawUICoinBank(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) void DrawFadeOut(Graphics*) { ZSink(RID_Coin_Draw); }
    __declspec(noinline) Zombie* GetBossZombie();
    // t14 渲染分发循环内消费（switch 表对拍同名成员；编号桩两形态同参）
    __declspec(noinline) void DrawBackdrop(Graphics*) { ZSink(RID_Coin_Draw, 77); }
    __declspec(noinline) void DrawHouseDoorTop(Graphics*) { ZSink(RID_Coin_Draw, 78); }

    // ---- 对拍形态函数声明（各 bench.cpp 定义；未用者不链接） ----
    __declspec(noinline) void DrawBackdrop_A(Graphics* g);
    __declspec(noinline) void DrawBackdrop_B(Graphics* g);
    __declspec(noinline) void DrawHouseDoorBottom_A(Graphics* g);
    __declspec(noinline) void DrawHouseDoorBottom_B(Graphics* g);
    __declspec(noinline) void DrawHouseDoorTop_A(Graphics* g);
    __declspec(noinline) void DrawHouseDoorTop_B(Graphics* g);
    __declspec(noinline) void PickUpTool_A(GameObjectType theObjectType);
    __declspec(noinline) void PickUpTool_B(GameObjectType theObjectType);
    __declspec(noinline) void SetTutorialState_A(TutorialState theTutorialState);
    __declspec(noinline) void SetTutorialState_B(TutorialState theTutorialState);
    __declspec(noinline) bool Met_A(SeedType theSeedType);
    __declspec(noinline) bool Met_B(SeedType theSeedType);
    __declspec(noinline) void KeyCharCheat_A(char theChar);
    __declspec(noinline) void KeyCharCheat_B(char theChar);
    __declspec(noinline) void DrawGameObjectsDispatch_A(Graphics* g);
    __declspec(noinline) void DrawGameObjectsDispatch_B(Graphics* g);
    __declspec(noinline) void MouseDownWithPlantUpgrade_A(int x, int y, int theClickCount);
    __declspec(noinline) void MouseDownWithPlantUpgrade_B(int x, int y, int theClickCount);
};

// ============================ LawnApp 桩 ============================
struct PoolEffect { __declspec(noinline) void PoolEffectDraw(Graphics*, bool) { ZSink(RID_Coin_Draw); } };
struct LawnApp
{
    Board* mBoard = nullptr;
    Music* mMusic = nullptr;
    ZenGarden* mZenGarden = nullptr;
    PlayerInfo* mPlayerInfo = nullptr;
    WidgetManager* mWidgetManager = nullptr;
    GameScenes mGameScene = GameScenes::SCENE_PLAYING;
    GameMode mGameMode = GAMEMODE_ADVENTURE;
    bool mEasyPlantingCheat = false;
    int mCrazyDaveMessageIndex = -1;
    PoolEffect* mPoolEffect = nullptr;
    void* mReanimatorCache = nullptr;

    __declspec(noinline) void PlayFoley(FoleyType theFoleyType) { ZSink(RID_App_PlayFoley, (uint32_t)theFoleyType); }
    __declspec(noinline) void PlaySample(int theSound) { ZSink(RID_App_PlaySample, (uint32_t)theSound); }
    __declspec(noinline) Reanimation* ReanimationTryToGet(ReanimationID theID)
    {
        return (unsigned)theID == 0u ? nullptr : ((unsigned)theID == 2u ? &g_reanimB : &g_reanimA);
    }
    __declspec(noinline) Reanimation* ReanimationGet(ReanimationID theID)
    {
        return (unsigned)theID == 2u ? &g_reanimB : &g_reanimA;
    }
    __declspec(noinline) ReanimationID ReanimationGetID(Reanimation* theReanimation)
    {
        ZSink(RID_App_ReanimationGetID, (uint32_t)(theReanimation ? 7 : 0));
        return (ReanimationID)7;
    }
    __declspec(noinline) void RemoveReanimation(ReanimationID theID) { ZSink(RID_App_RemoveReanimation, (uint32_t)theID); }
    __declspec(noinline) Reanimation* AddReanimation(float theX, float theY, int theRenderOrder, ReanimationType theType)
    {
        ZSink(RID_App_AddReanimation, (uint32_t)theType, (uint32_t)(int)theX, (uint32_t)theRenderOrder);
        g_reanimScratch.mAnimRate = 0.0f;
        g_reanimScratch.mIsAttachment = false;
        g_reanimScratch.mLoopType = REANIM_LOOP;
        return &g_reanimScratch;
    }
    __declspec(noinline) TodParticleSystem* AddTodParticle(float theX, float theY, int theRenderOrder, ParticleEffect theEffect)
    {
        ZSink(RID_App_AddTodParticle, (uint32_t)theEffect, (uint32_t)(int)theX, (uint32_t)theRenderOrder);
        return ((uint32_t)theEffect % 3 == 0) ? nullptr : &g_particle;
    }
    __declspec(noinline) bool IsFirstTimeAdventureMode() { ZSink(RID_App_IsFirstTimeAdventure); return mGameMode == GAMEMODE_ADVENTURE; }
    __declspec(noinline) bool IsAdventureMode() { return mGameMode == GAMEMODE_ADVENTURE; }
    __declspec(noinline) bool IsIZombieLevel() { ZSink(RID_App_IsIZombie); return mGameMode == GAMEMODE_PUZZLE_I_ZOMBIE_1; }
    __declspec(noinline) bool IsFinalBossLevel() { return mGameMode == GAMEMODE_CHALLENGE_FINAL_BOSS; }
    __declspec(noinline) bool IsScaryPotterLevel() { return false; }
    __declspec(noinline) bool IsWallnutBowlingLevel() { return mGameMode == GAMEMODE_CHALLENGE_WALLNUT_BOWLING; }
    __declspec(noinline) bool IsLittleTroubleLevel() { return false; }
    __declspec(noinline) bool IsStormyNightLevel() { return false; }
    __declspec(noinline) bool IsSquirrelLevel() { return false; }
    __declspec(noinline) bool IsSlotMachineLevel() { return false; }
    __declspec(noinline) bool IsWhackAZombieLevel() { return false; }
    __declspec(noinline) bool IsSurvivalMode() { return false; }
    __declspec(noinline) bool IsContinuousChallenge() { return false; }
    __declspec(noinline) bool HasFinishedAdventure() { return mBoard && mBoard->mLevel > 10; }
    __declspec(noinline) bool IsSurvivalEndless(GameMode) { return false; }
    __declspec(noinline) bool IsEndlessIZombie(GameMode) { return false; }
    __declspec(noinline) bool IsEndlessScaryPotter(GameMode) { return false; }
    __declspec(noinline) int GetCurrentChallengeIndex() { ZSink(RID_App_GetCurrentChallengeIndex); return 3; }
    __declspec(noinline) void SetCursor(int c) { ZSink(RID_App_SetCursor, (uint32_t)c); }
    __declspec(noinline) SexyString Pluralize(int n, const char* a, const char* b) { ZSink(RID_App_Pluralize, (uint32_t)n); return n == 1 ? a : b; }
    __declspec(noinline) void DoNewOptions(bool) { ZSink(RID_App_DoNewOptions); }
    __declspec(noinline) void DoCheatDialog() { ZSink(RID_App_DoCheatDialog); }
    __declspec(noinline) void CrazyDaveEnter() { ZSink(RID_App_CrazyDaveEnter); }
    __declspec(noinline) void UpdateCrazyDave() { ZSink(RID_App_UpdateCrazyDave); }
};

inline ZombieID Board::ZombieGetID(Zombie* z) { ZSink(RID_Board_ZombieGetID, z ? (uint32_t)1 : 0u); return (ZombieID)5; }

// ============================ 输入数组 / 计时 ============================
struct R3Input { uint32_t a, b, c, d; };
constexpr uint32_t R3_N = 2u * 1024u * 1024u;
inline R3Input g_inputs[R3_N];
inline void R3InitInputs(uint32_t theSeed = 20261002u)
{
    uint32_t s = theSeed;
    for (uint32_t i = 0; i < R3_N; i++)
    {
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t a = s;
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t b = s;
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t c = s;
        s ^= s << 13; s ^= s >> 17; s ^= s << 5; uint32_t d = s;
        g_inputs[i] = { a, b, c, d };
    }
}
inline double R3NowSec()
{
    static LARGE_INTEGER freq = {};
    LARGE_INTEGER cnt;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&cnt);
    return (double)cnt.QuadPart / (double)freq.QuadPart;
}

// 计时口径：1 warmup + min-of-5，两形态交错；checksum 对拍先行。
template <class ResetFn, class PassA, class PassB>
int R3BenchMain(const char* theName, ResetFn reset, PassA passA, PassB passB)
{
    ZBInitImages();
    R3InitZombieDefs();
    R3InitInputs();

    g_sink = 0; ZBRngReset(); reset();
    uint64_t ckA = 0; passA(ckA); ckA = ZBMixU64(ckA, g_sink);
    g_sink = 0; ZBRngReset(); reset();
    uint64_t ckB = 0; passB(ckB); ckB = ZBMixU64(ckB, g_sink);

    double bestA = 1e18, bestB = 1e18;
    for (int rep = 0; rep < 6; rep++)
    {
        uint64_t dummy = 0;
        g_sink = 0; ZBRngReset(); reset();
        double t0 = R3NowSec(); passA(dummy); double t1 = R3NowSec();
        double dA = t1 - t0;
        g_sink = 0; ZBRngReset(); reset();
        double t2 = R3NowSec(); passB(dummy); double t3 = R3NowSec();
        double dB = t3 - t2;
        if (rep > 0)
        {
            if (dA < bestA) bestA = dA;
            if (dB < bestB) bestB = dB;
        }
    }
    printf("%s|%.1f|%.1f|%+06.2f%%|%016llx/%016llx%s\n",
        theName, bestA * 1e9, bestB * 1e9,
        (bestA - bestB) / bestA * 100.0,
        (unsigned long long)ckA, (unsigned long long)ckB,
        ckA == ckB ? "" : "  <<<< CHECKSUM MISMATCH");
    return ckA == ckB ? 0 : 1;
}
