
undefined4 * __thiscall FUN_0052d550(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  void *pvStack_c;
  undefined1 *puStack_8;
  int local_4;
  
  local_4 = 0xffffffff;
  puStack_8 = &LAB_006c3903;
  pvStack_c = ExceptionList;
  ExceptionList = &pvStack_c;
  FUN_0054be80();
  local_4 = 0;
  *param_2 = &PTR_FUN_006f29d8;
  param_2[0x3dc] = 0;
  param_2[0x3dd] = 0;
  param_2[0x3de] = 0;
  param_2[0x3df] = 0;
  param_2[0x28] = param_1;
  *(undefined1 *)((int)param_2 + 0xf6f) = 0;
  uVar3 = *(undefined4 *)(param_1 + 0xc4);
  uVar1 = FUN_0059aba0(uVar3);
  FUN_0054c630(0x19,0x19,uVar1,uVar3);
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3e9);
  }
  param_2[0x29] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00726754;
  *(undefined4 *)(param_2[0x29] + 0xa8) = DAT_00727108;
  *(undefined4 *)(param_2[0x29] + 0xac) = DAT_00727108;
  *(undefined4 *)(param_2[0x29] + 0xb0) = DAT_00726754;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar4 = FUN_0059abc0();
  iVar2 = param_2[0x29];
  iVar6 = param_2[0x13];
  *(undefined4 *)(iVar2 + 8) = 0x96;
  *(int *)(iVar2 + 0xc) = (iVar6 - iVar4) + -0xd7;
  *(undefined4 *)(iVar2 + 0x10) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x29] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(1000);
  }
  param_2[0x2a] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00727200;
  *(undefined4 *)(param_2[0x2a] + 0xa8) = DAT_00726614;
  *(undefined4 *)(param_2[0x2a] + 0xac) = DAT_00726614;
  *(undefined4 *)(param_2[0x2a] + 0xb0) = DAT_00727200;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar4 = FUN_0059abc0();
  iVar2 = param_2[0x13];
  iVar5 = FUN_0059aba0();
  iVar6 = param_2[0x2a];
  *(int *)(iVar6 + 8) = (param_2[0x12] - iVar5) + -0x37;
  *(int *)(iVar6 + 0xc) = (iVar2 - iVar4) + -0xd7;
  *(undefined4 *)(iVar6 + 0x10) = uVar1;
  *(undefined4 *)(iVar6 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x2a] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3ef);
  }
  param_2[0x39] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = 0;
  *(undefined4 *)(param_2[0x39] + 0xa8) = DAT_00726b14;
  *(undefined4 *)(param_2[0x39] + 0xac) = DAT_00726b14;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar2 = *(int *)(param_2[0x28] + 0xc4);
  iVar6 = param_2[0x39];
  *(undefined4 *)(iVar6 + 8) = 0xfd;
  *(int *)(iVar6 + 0xc) = iVar2 + -0x61;
  *(undefined4 *)(iVar6 + 0x10) = uVar1;
  *(undefined4 *)(iVar6 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x39] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3f0);
  }
  param_2[0x3a] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00726c48;
  *(undefined4 *)(param_2[0x3a] + 0xa8) = DAT_0072704c;
  *(undefined4 *)(param_2[0x3a] + 0xac) = DAT_0072704c;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar2 = *(int *)(param_2[0x28] + 0xc4);
  iVar6 = param_2[0x3a];
  *(undefined4 *)(iVar6 + 8) = 0xfd;
  *(int *)(iVar6 + 0xc) = iVar2 + -0x61;
  *(undefined4 *)(iVar6 + 0x10) = uVar1;
  *(undefined4 *)(iVar6 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x3a] + 4) = param_2;
  if ((*(int *)(param_2[0x28] + 0x94c) != 0) &&
     (*(int *)(*(int *)(param_2[0x28] + 0x94c) + 0x4840) < 1)) {
    *(undefined1 *)(param_2[0x3a] + 0x1a) = 1;
  }
  *(undefined1 *)(param_2[0x29] + 0x1a) = 1;
  *(undefined1 *)(param_2[0x2a] + 0x1a) = 0;
  param_2[0x3c4] = 0;
  param_2[0x3c] = 1;
  param_2[0x3d] = 1;
  param_2[0x40] = 0;
  param_2[0x3e] = 0xfffffffc;
  param_2[0x3f] = 0;
  uVar3 = FUN_0059aba0();
  iVar2 = FUN_0059abc0();
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f1);
  }
  param_2[0x2b] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_0072725c;
  *(undefined4 *)(param_2[0x2b] + 0xa8) = DAT_0072725c;
  *(undefined4 *)(param_2[0x2b] + 0xac) = DAT_00726694;
  *(undefined4 *)(param_2[0x2b] + 0xb0) = 0;
  iVar6 = param_2[0x2b];
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0xc) = 0x67;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x2b] + 4) = param_2;
  *(undefined1 *)(param_2[0x2b] + 0xff) = 1;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f2);
  }
  param_2[0x2c] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_0072687c;
  *(undefined4 *)(param_2[0x2c] + 0xa8) = DAT_00726c04;
  *(undefined4 *)(param_2[0x2c] + 0xac) = DAT_0072672c;
  *(undefined4 *)(param_2[0x2c] + 0xb0) = 0;
  iVar6 = param_2[0x2c];
  *(int *)(iVar6 + 0xc) = iVar2 + 100;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x2c] + 4) = param_2;
  iVar4 = iVar2 + 100 + iVar2 + -3;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f3);
  }
  param_2[0x2d] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_0072723c;
  *(undefined4 *)(param_2[0x2d] + 0xa8) = DAT_007265f0;
  *(undefined4 *)(param_2[0x2d] + 0xac) = DAT_007271cc;
  *(undefined4 *)(param_2[0x2d] + 0xb0) = 0;
  iVar6 = param_2[0x2d];
  *(int *)(iVar6 + 0xc) = iVar4;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x2d] + 4) = param_2;
  iVar4 = iVar4 + iVar2 + -3;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f4);
  }
  param_2[0x2e] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_00726bcc;
  *(undefined4 *)(param_2[0x2e] + 0xa8) = DAT_00726810;
  *(undefined4 *)(param_2[0x2e] + 0xac) = DAT_00727278;
  *(undefined4 *)(param_2[0x2e] + 0xb0) = 0;
  iVar6 = param_2[0x2e];
  *(int *)(iVar6 + 0xc) = iVar4;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x2e] + 4) = param_2;
  iVar4 = iVar4 + iVar2 + -3;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f5);
  }
  param_2[0x2f] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_00727030;
  *(undefined4 *)(param_2[0x2f] + 0xa8) = DAT_007266c0;
  *(undefined4 *)(param_2[0x2f] + 0xac) = DAT_00726a84;
  *(undefined4 *)(param_2[0x2f] + 0xb0) = 0;
  iVar6 = param_2[0x2f];
  *(int *)(iVar6 + 0xc) = iVar4;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x2f] + 4) = param_2;
  iVar4 = iVar4 + iVar2 + -3;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f6);
  }
  param_2[0x30] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_00726568;
  *(undefined4 *)(param_2[0x30] + 0xa8) = DAT_0072730c;
  *(undefined4 *)(param_2[0x30] + 0xac) = DAT_00726a74;
  *(undefined4 *)(param_2[0x30] + 0xb0) = 0;
  iVar6 = param_2[0x30];
  *(int *)(iVar6 + 0xc) = iVar4;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x30] + 4) = param_2;
  iVar4 = iVar4 + iVar2 + -3;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f7);
  }
  param_2[0x31] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_007265c8;
  *(undefined4 *)(param_2[0x31] + 0xa8) = DAT_00726ea0;
  *(undefined4 *)(param_2[0x31] + 0xac) = DAT_00727054;
  *(undefined4 *)(param_2[0x31] + 0xb0) = 0;
  iVar6 = param_2[0x31];
  *(int *)(iVar6 + 0xc) = iVar4;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x31] + 4) = param_2;
  iVar4 = iVar4 + iVar2 + -3;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f8);
  }
  param_2[0x32] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_00726928;
  *(undefined4 *)(param_2[0x32] + 0xa8) = DAT_00726b2c;
  *(undefined4 *)(param_2[0x32] + 0xac) = DAT_00726d58;
  *(undefined4 *)(param_2[0x32] + 0xb0) = 0;
  iVar6 = param_2[0x32];
  *(int *)(iVar6 + 0xc) = iVar4;
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x32] + 4) = param_2;
  iVar6 = FUN_00699ed2(0x138);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0044a860(0x3f9);
  }
  param_2[0x33] = iVar6;
  *(undefined4 *)(iVar6 + 0xa4) = DAT_00726640;
  *(undefined4 *)(param_2[0x33] + 0xa8) = DAT_00726aa8;
  *(undefined4 *)(param_2[0x33] + 0xac) = DAT_00726cfc;
  *(undefined4 *)(param_2[0x33] + 0xb0) = 0;
  iVar6 = param_2[0x33];
  *(undefined4 *)(iVar6 + 8) = 0x21;
  *(int *)(iVar6 + 0xc) = iVar4 + iVar2 + -3;
  *(undefined4 *)(iVar6 + 0x10) = uVar3;
  *(int *)(iVar6 + 0x14) = iVar2;
  *(undefined4 **)(param_2[0x33] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3ea);
  }
  param_2[0x34] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00726aa0;
  *(undefined4 *)(param_2[0x34] + 0xa8) = DAT_00727194;
  *(undefined4 *)(param_2[0x34] + 0xb0) = 0;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar2 = param_2[0x34];
  *(undefined4 *)(iVar2 + 8) = 0x168;
  *(undefined4 *)(iVar2 + 0xc) = 0x140;
  *(undefined4 *)(iVar2 + 0x10) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x34] + 4) = param_2;
  *(undefined1 *)(param_2[0x34] + 0x1a) = 1;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3eb);
  }
  param_2[0x35] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00726900;
  *(undefined4 *)(param_2[0x35] + 0xa8) = DAT_007267b4;
  *(undefined4 *)(param_2[0x35] + 0xac) = 0;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar2 = param_2[0x35];
  *(undefined4 *)(iVar2 + 8) = 0x1a4;
  *(undefined4 *)(iVar2 + 0xc) = 0x1bf;
  *(undefined4 *)(iVar2 + 0x10) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x35] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3eb);
  }
  param_2[0x36] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00726f34;
  *(undefined4 *)(param_2[0x36] + 0xa8) = DAT_00726784;
  *(undefined4 *)(param_2[0x36] + 0xac) = 0;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar2 = param_2[0x36];
  *(undefined4 *)(iVar2 + 8) = 0xaa;
  *(undefined4 *)(iVar2 + 0xc) = 0x172;
  *(undefined4 *)(iVar2 + 0x10) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x36] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3ed);
  }
  param_2[0x37] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00727200;
  *(undefined4 *)(param_2[0x37] + 0xa8) = DAT_00726614;
  *(undefined4 *)(param_2[0x37] + 0xac) = DAT_00726614;
  *(undefined4 *)(param_2[0x37] + 0xb0) = DAT_00727200;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar4 = FUN_0059abc0();
  iVar2 = param_2[0x13];
  iVar5 = FUN_0059aba0();
  iVar6 = param_2[0x37];
  *(int *)(iVar6 + 8) = (param_2[0x12] - iVar5) + -0x55;
  *(int *)(iVar6 + 0xc) = (iVar2 - iVar4) + -0xbd;
  *(undefined4 *)(iVar6 + 0x10) = uVar1;
  *(undefined4 *)(iVar6 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x37] + 4) = param_2;
  iVar2 = FUN_00699ed2(0x138);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0044a860(0x3ee);
  }
  param_2[0x38] = iVar2;
  *(undefined4 *)(iVar2 + 0xa4) = DAT_00726754;
  *(undefined4 *)(param_2[0x38] + 0xa8) = DAT_00727108;
  *(undefined4 *)(param_2[0x38] + 0xac) = DAT_00727108;
  *(undefined4 *)(param_2[0x38] + 0xb0) = DAT_00726754;
  uVar3 = FUN_0059abc0();
  uVar1 = FUN_0059aba0();
  iVar4 = FUN_0059abc0();
  iVar2 = param_2[0x38];
  iVar6 = param_2[0x13];
  *(undefined4 *)(iVar2 + 8) = 0x5f;
  *(int *)(iVar2 + 0xc) = (iVar6 - iVar4) + -0xbd;
  *(undefined4 *)(iVar2 + 0x10) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = uVar3;
  *(undefined4 **)(param_2[0x38] + 4) = param_2;
  iVar2 = FUN_00699ed2(0xe0);
  local_4._0_1_ = 1;
  if (iVar2 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_0052ce90(iVar2,param_2[0x28]);
  }
  local_4 = (uint)local_4._1_3_ << 8;
  param_2[0x3b] = uVar3;
  param_2[0x3c1] = 9;
  FUN_00530890();
  param_2[0x3d8] = 0;
  param_2[0x3d9] = 0;
  *(undefined1 *)(param_2 + 0x3db) = 0;
  *(undefined1 *)((int)param_2 + 0xf6d) = 0;
  *(undefined1 *)((int)param_2 + 0xf6e) = 0;
  FUN_00547c30(param_2[0x3b]);
  if ((*(int *)(param_2[0x28] + 0x94c) == 0) ||
     (*(int *)(*(int *)(param_2[0x28] + 0x94c) + 0x4840) < 1)) {
    param_2[0x3d7] = 0;
  }
  else {
    param_2[0x3d7] = 4;
  }
  FUN_00530550();
  param_2[0x3dc] = 0x141;
  param_2[0x3dd] = 0x79;
  param_2[0x3de] = 0x3c;
  param_2[0x3df] = 0x14;
  ExceptionList = pvStack_c;
  return param_2;
}

