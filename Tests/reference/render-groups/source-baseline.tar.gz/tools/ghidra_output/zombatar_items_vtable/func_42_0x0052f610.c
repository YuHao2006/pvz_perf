
void __thiscall FUN_0052f610(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0xf5c) == 0) {
    iVar1 = FUN_0052fbf0(&param_2,&param_3);
    *(int *)(param_1 + 0xf08) = iVar1;
    if (iVar1 == -1) {
      FUN_005d9d80(0);
      return;
    }
    FUN_005d9d80(1);
  }
  else if (*(int *)(param_1 + 0xf5c) == 4) {
    *(undefined1 *)(param_1 + 0xf6f) = 0;
    if ((*(int *)(param_1 + 0xf70) <= param_2) &&
       (param_2 < *(int *)(param_1 + 0xf78) + *(int *)(param_1 + 0xf70))) {
      if ((*(int *)(param_1 + 0xf74) <= param_3) &&
         (param_3 < *(int *)(param_1 + 0xf7c) + *(int *)(param_1 + 0xf74))) {
        *(undefined1 *)(param_1 + 0xf6f) = 1;
        return;
      }
    }
  }
  return;
}

