
undefined1 __thiscall FUN_0054cea0(int param_1,int param_2,int param_3)

{
  undefined1 local_c;
  
  if ((((param_2 < *(int *)(param_1 + 0x40)) ||
       (*(int *)(param_1 + 0x40) + *(int *)(param_1 + 0x48) <= param_2)) ||
      (param_3 < *(int *)(param_1 + 0x44))) ||
     (*(int *)(param_1 + 0x44) + *(int *)(param_1 + 0x4c) <= param_3)) {
    local_c = 0;
  }
  else {
    local_c = 1;
  }
  return local_c;
}

