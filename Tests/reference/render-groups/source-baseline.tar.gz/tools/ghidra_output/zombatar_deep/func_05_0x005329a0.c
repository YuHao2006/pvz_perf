
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005329a0(int param_1,int param_2,undefined1 param_3,int param_4,int param_5)

{
  float *pfVar1;
  uint uVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int *in_EAX;
  int iVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int extraout_ECX;
  float10 fVar11;
  char *pcVar12;
  undefined4 uVar13;
  int local_20;
  int local_1c;
  int local_10;
  
  *(undefined1 *)(in_EAX + 0x57) = 0;
  if (param_2 == 1) {
    iVar7 = *(int *)(*in_EAX + 0x94c);
    if ((iVar7 != 0) && (0 < *(int *)(iVar7 + 0x4840))) {
      in_EAX[9] = 0x21;
      *(undefined1 *)(in_EAX + 0x57) = 1;
      param_2 = 0x21;
      iVar7 = FUN_005ff2a0(*(undefined4 *)(*(int *)(*in_EAX + 0x94c) + 0x4840));
      in_EAX[0x58] = iVar7;
      if (*(int *)(*(int *)(*in_EAX + 0x94c) + 0x4840) <= iVar7) {
        in_EAX[0x58] = iVar7 + -1;
      }
    }
  }
  pfVar1 = (float *)(in_EAX + 0xb);
  in_EAX[7] = param_1;
  in_EAX[0x1b] = param_5;
  iVar7 = FUN_005ff2a0(0x28);
  *pfVar1 = (float)(iVar7 + 0x30c);
  fVar11 = (float10)FUN_00542240(param_1);
  in_EAX[0xc] = (int)(float)fVar11;
  in_EAX[0xd] = 0;
  in_EAX[0x48] = 0;
  in_EAX[4] = 0x78;
  in_EAX[5] = 0x78;
  in_EAX[0x12] = 0;
  in_EAX[0x13] = 0;
  in_EAX[9] = param_2;
  *(undefined1 *)(in_EAX + 0x14) = param_3;
  *(undefined1 *)((int)in_EAX + 0x51) = 0;
  in_EAX[0x15] = 0;
  in_EAX[0x16] = 0;
  in_EAX[0x17] = 0;
  in_EAX[0x2b] = 0;
  in_EAX[0x2d] = 0;
  in_EAX[0x2c] = 0;
  *(undefined1 *)(in_EAX + 0x2e) = 0;
  *(undefined1 *)((int)in_EAX + 0xb9) = 0;
  *(undefined1 *)((int)in_EAX + 0xba) = 1;
  *(undefined1 *)((int)in_EAX + 0xbb) = 1;
  *(undefined1 *)(in_EAX + 0x2f) = 0;
  *(undefined1 *)((int)in_EAX + 0xbd) = 0;
  *(undefined1 *)((int)in_EAX + 0xbe) = 0;
  in_EAX[0x31] = 0;
  in_EAX[0x36] = 0;
  *(undefined1 *)((int)in_EAX + 0xbf) = 0;
  in_EAX[0x30] = 0;
  in_EAX[0xe] = 0;
  iVar7 = FUN_005ff2a0(0x65);
  in_EAX[0x23] = 0x24;
  in_EAX[0x24] = 0;
  in_EAX[0xf] = iVar7 + 400;
  in_EAX[0x25] = 0x2a;
  in_EAX[0x10] = 0xc;
  in_EAX[0x11] = 0xc;
  in_EAX[0x27] = 0x32;
  in_EAX[0x18] = 0;
  in_EAX[0x20] = -1;
  in_EAX[10] = 0;
  in_EAX[0x19] = 0;
  in_EAX[0x1a] = 0;
  *(undefined1 *)(in_EAX + 0x22) = 0;
  *(undefined1 *)(in_EAX + 0x1c) = 0;
  in_EAX[0x3c] = 0;
  in_EAX[0x26] = 0x73;
  in_EAX[0x28] = 0;
  in_EAX[0x47] = 0x3f800000;
  in_EAX[0x29] = 0x14;
  in_EAX[0x2a] = 0x73;
  in_EAX[0x21] = 0;
  *(undefined1 *)(in_EAX + 0x41) = 0;
  in_EAX[0x49] = 0;
  in_EAX[0x1d] = -1;
  *(undefined1 *)(in_EAX + 0x1e) = 0;
  in_EAX[0x1f] = -1;
  in_EAX[0x37] = 0;
  in_EAX[0x34] = 0;
  in_EAX[0x39] = 0;
  in_EAX[0x44] = 0;
  in_EAX[0x45] = 0;
  in_EAX[0x4e] = -1;
  in_EAX[0x4d] = -1;
  in_EAX[0x4f] = -1;
  in_EAX[0x46] = 0;
  in_EAX[0x4a] = 0;
  in_EAX[0x4b] = 0;
  in_EAX[0x50] = 0;
  in_EAX[0x51] = 0;
  in_EAX[0x52] = 0;
  in_EAX[0x4c] = -1;
  in_EAX[0x53] = -1;
  *(undefined1 *)(in_EAX + 0x54) = 0;
  in_EAX[0x55] = 0;
  in_EAX[0x56] = -1;
  in_EAX[0x3d] = 0;
  in_EAX[0x3e] = 0;
  in_EAX[0x3f] = 0;
  in_EAX[0x40] = 0;
  if ((in_EAX[1] != 0) && (cVar6 = FUN_0040b9b0(in_EAX[0x1b]), cVar6 != '\0')) {
    *pfVar1 = *pfVar1 + (float)_DAT_006fdcb0;
  }
  FUN_00535110();
  in_EAX[0x32] = 0x10e;
  local_10 = 0x49f98;
  local_20 = 4;
  if ((&DAT_0071bb94)[in_EAX[9] * 7] != -1) {
    FUN_00534b60(in_EAX);
  }
  fVar3 = _DAT_006fe940;
  if (param_2 == 0) {
    FUN_00534a50();
    goto LAB_00533e4d;
  }
  if (param_2 == 10) {
    FUN_00534a50();
    goto LAB_00533e4d;
  }
  if (param_2 == 2) {
    FUN_00534a50();
    uVar2 = in_EAX[0x46];
    if ((((*(int *)(*in_EAX + 0x940) != 0) &&
         (piVar10 = *(int **)(*(int *)(*in_EAX + 0x940) + 8), uVar2 != 0)) &&
        ((uVar2 & 0xffff) < (uint)piVar10[2])) &&
       (iVar7 = (uVar2 & 0xffff) * 0xa0 + *piVar10, *(uint *)(iVar7 + 0x9c) == uVar2)) {
      FUN_00478170(iVar7,"anim_cone",0);
    }
    uVar2 = in_EAX[0x46];
    if (((*(int *)(*in_EAX + 0x940) != 0) &&
        (piVar10 = *(int **)(*(int *)(*in_EAX + 0x940) + 8), uVar2 != 0)) &&
       (((uVar2 & 0xffff) < (uint)piVar10[2] &&
        (iVar7 = (uVar2 & 0xffff) * 0xa0 + *piVar10, *(uint *)(iVar7 + 0x9c) == uVar2)))) {
      FUN_00478170(iVar7,"anim_hair",0xffffffff);
    }
    in_EAX[0x31] = 1;
    in_EAX[0x34] = 0x172;
    goto LAB_00533e4d;
  }
  if (param_2 == 4) {
    FUN_00534a50();
    FUN_00543bb0("anim_bucket",0);
    FUN_00543bb0("anim_hair",0xffffffff);
    in_EAX[0x31] = 2;
    in_EAX[0x34] = 0x44c;
    goto LAB_00533e4d;
  }
  if (param_2 == 6) {
    in_EAX[0x36] = 1;
    in_EAX[0x37] = 0x44c;
    FUN_00534a50();
    FUN_005439e0();
    goto LAB_00533e4d;
  }
  if (param_2 == 0x13) {
    in_EAX[0x32] = 0x546;
    iVar7 = FUN_005ff2a0(0x1f5);
    in_EAX[0x1a] = iVar7 + 0x5dc;
    iVar8 = 0x14;
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    iVar7 = 0x32;
LAB_00533197:
    in_EAX[0x27] = iVar8;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = iVar7;
    in_EAX[0x2a] = 0x73;
    goto LAB_00533e4d;
  }
  if (param_2 == 0x15) {
    in_EAX[0x32] = 500;
    in_EAX[0x37] = 500;
    in_EAX[0x27] = 10;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0x32;
    in_EAX[0x36] = 3;
    in_EAX[0x2a] = 0x73;
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      in_EAX[10] = 0x4c;
      FUN_0053fc60();
    }
    FUN_005439e0();
    goto LAB_00533e4d;
  }
  iVar7 = in_EAX[9];
  if (iVar7 == 0x14) {
    in_EAX[0x32] = 0x1c2;
    in_EAX[0x11] = 4;
    iVar7 = FUN_005ff2a0(0x97);
    in_EAX[0x21] = (int)(float)(iVar7 + 3000);
    in_EAX[0xd] = 0;
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      in_EAX[10] = 10;
      iVar7 = FUN_005ff2a0(0xc9);
      in_EAX[0x1a] = iVar7;
    }
    else {
      FUN_00534d90(in_EAX,0xffffffff);
      if ((char)in_EAX[0x3b] != '\0') {
        return;
      }
      in_EAX[10] = 4;
    }
    FUN_00539190("anim_drop",0,0,_DAT_006fde50);
    iVar8 = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    FUN_00478170(iVar8,"Zombie_bungi_rightarm_lower2",2);
    FUN_00478170(iVar8,"Zombie_bungi_rightarm_hand2",2);
    FUN_00478170(iVar8,"Zombie_bungi_leftarm_lower2",2);
    FUN_00478170(iVar8,"Zombie_bungi_leftarm_hand2",2);
    iVar7 = 0;
    if (0 < *(int *)(*(int *)(iVar8 + 0xc) + 4)) {
      iVar9 = 0;
      do {
        *(undefined1 *)(iVar9 + 0x5d + *(int *)(iVar8 + 0x58)) = 0;
        iVar7 = iVar7 + 1;
        iVar9 = iVar9 + 0x60;
      } while (iVar7 < *(int *)(*(int *)(iVar8 + 0xc) + 4));
    }
    in_EAX[0x23] = -0x14;
    in_EAX[0x24] = 0x16;
    in_EAX[0x25] = 0x6e;
    in_EAX[0x27] = 0;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0;
    local_10 = 0x497c8;
    local_20 = 7;
    in_EAX[0x26] = 0x5e;
    in_EAX[0x2a] = 0;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    goto LAB_00533e4d;
  }
  if (iVar7 == 7) {
    in_EAX[0x23] = 0x32;
    in_EAX[0x24] = 0;
    in_EAX[0x25] = 0x39;
    in_EAX[0x26] = 0x73;
    FUN_00543bb0("anim_hair",0xffffffff);
    in_EAX[0x31] = 3;
    in_EAX[0x34] = 0x578;
    in_EAX[0x10] = 6;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    goto LAB_00533e4d;
  }
  if (iVar7 == 0x11) {
    in_EAX[0x23] = 0x32;
    in_EAX[0x24] = 0;
    in_EAX[0x31] = 4;
    in_EAX[0x34] = 100;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    in_EAX[0x25] = 0x1c;
    in_EAX[0x26] = 0x73;
    iVar7 = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    iVar8 = 0;
    if (0 < *(int *)(*(int *)(iVar7 + 0xc) + 4)) {
      iVar9 = 0;
      do {
        *(undefined1 *)(*(int *)(iVar7 + 0x58) + 0x5d + iVar9) = 0;
        iVar8 = iVar8 + 1;
        iVar9 = iVar9 + 0x60;
      } while (iVar8 < *(int *)(*(int *)(iVar7 + 0xc) + 4));
    }
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      in_EAX[10] = 0x27;
    }
    else {
      in_EAX[10] = 0x20;
      FUN_00542ba0(0x3c,100,0x20);
      local_20 = 7;
      FUN_00539190("anim_dig",1,0,_DAT_006fdb98);
      FUN_00535110();
    }
    goto LAB_00533e4d;
  }
  if (iVar7 == 3) {
    in_EAX[0x32] = 500;
    in_EAX[0x10] = 6;
    in_EAX[10] = 0xb;
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    iVar7 = FUN_005ff2a0(10);
    *pfVar1 = (float)(iVar7 + 0x366);
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      FUN_00539190("anim_run",0,0,0);
      FUN_00535110();
    }
    cVar6 = FUN_00456d10();
    if (cVar6 == '\0') {
      iVar8 = -0x1d;
      iVar7 = 0x46;
    }
    else {
      iVar8 = -0xe5;
      iVar7 = 0x10e;
    }
    goto LAB_00533197;
  }
  if (iVar7 == 0xe) {
    in_EAX[0x32] = 500;
    in_EAX[0x10] = 6;
    in_EAX[10] = 0x33;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      FUN_00539190("anim_walkdolphin",0,0,0);
      FUN_00535110();
    }
    FUN_005478e0("Zombie_dolphinrider_whitewater");
    FUN_005478e0("Zombie_dolphinrider_dolphininwater");
    goto LAB_00533e4d;
  }
  if ((iVar7 == 0x17) || (iVar7 == 0x20)) {
    in_EAX[0x32] = 3000;
    in_EAX[0x11] = 0x18;
    in_EAX[0x10] = 8;
    in_EAX[4] = 0xb4;
    in_EAX[5] = 0xb4;
    iVar7 = FUN_005ff2a0(10);
    in_EAX[0x23] = -0x11;
    *pfVar1 = (float)(iVar7 + 0x34d);
    in_EAX[0x24] = -0x26;
    in_EAX[0x25] = 0x7d;
    in_EAX[0x27] = -0x1e;
    in_EAX[0x28] = -0x26;
    in_EAX[0x29] = 0x59;
    in_EAX[0x26] = 0x9a;
    in_EAX[0x2a] = 0x9a;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    local_20 = 9;
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    FUN_005ff2a0(100);
    cVar6 = FUN_0053b730();
    if ((cVar6 == '\0') || (*(int *)(in_EAX[1] + 0x5568) == 0x30)) {
      cVar6 = '\0';
    }
    else if (extraout_ECX < 10) {
      cVar6 = '\x02';
    }
    else {
      cVar6 = extraout_ECX < 0x23;
    }
    uVar13 = DAT_00726a54;
    if ((cVar6 == '\x02') || (uVar13 = DAT_007269e8, cVar6 == '\x01')) {
      FUN_00477bb0(uVar13);
    }
    if (in_EAX[9] == 0x20) {
      FUN_00477bb0(DAT_00726dbc);
      in_EAX[0x32] = 6000;
    }
    goto LAB_00533e4d;
  }
  if (iVar7 == 0xc) {
    in_EAX[0x32] = 0x546;
    in_EAX[0x11] = 2;
    in_EAX[0x10] = 8;
    iVar7 = FUN_005ff2a0(10);
    local_20 = 9;
    *pfVar1 = (float)(iVar7 + 800);
    FUN_00539190("anim_drive",0,0,_DAT_006fdb98);
    in_EAX[0x23] = 0;
    in_EAX[0x24] = -0xd;
    in_EAX[0x25] = 0x99;
    in_EAX[0x27] = 10;
    in_EAX[0x26] = 0x8c;
    in_EAX[0x28] = -0xd;
    in_EAX[0x29] = 0x85;
    in_EAX[0x2a] = 0x8c;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    goto LAB_00533e4d;
  }
  if (iVar7 == 0x16) {
    in_EAX[0x32] = 0x352;
    iVar7 = FUN_005ff2a0(10);
    in_EAX[0x45] = 0x14;
    *pfVar1 = (float)(iVar7 + 0x339);
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      pcVar12 = "anim_idle";
      uVar13 = _DAT_006fe0ec;
    }
    else {
      pcVar12 = "anim_walk";
      uVar13 = _DAT_006fe944;
    }
    FUN_00539190(pcVar12,0,0,uVar13);
    in_EAX[0x23] = 0;
    in_EAX[0x24] = -0xd;
    in_EAX[0x25] = 0x99;
    in_EAX[0x27] = 10;
    in_EAX[0x26] = 0x8c;
    in_EAX[0x28] = -0xd;
    in_EAX[0x29] = 0x85;
    in_EAX[0x2a] = 0x8c;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    goto LAB_00533e4d;
  }
  if (iVar7 == 0xb) {
    in_EAX[0x23] = 0xc;
    in_EAX[0x24] = 0;
    in_EAX[0x25] = 0x3e;
    in_EAX[0x27] = -5;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0x37;
    in_EAX[0x26] = 0x73;
    in_EAX[0x2a] = 0x73;
    FUN_005478e0("Zombie_snorkle_whitewater");
    FUN_005478e0("Zombie_snorkle_whitewater2");
    *(undefined1 *)(in_EAX + 0x14) = 0;
    in_EAX[10] = 0x39;
    goto LAB_00533e4d;
  }
  if (iVar7 == 0xf) {
    in_EAX[0x32] = 500;
    in_EAX[0x10] = 6;
    FUN_005ff2a0(300);
    FUN_005ff2a0(0x14);
    iVar7 = FUN_006ba960();
    in_EAX[0x1a] = iVar7 * 2;
    in_EAX[0x27] = 0x14;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0x32;
    in_EAX[0x2a] = 0x73;
    cVar6 = FUN_00456dc0();
    if (cVar6 != '\0') {
      in_EAX[0x1a] = 10;
    }
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      in_EAX[10] = 0xf;
    }
    goto LAB_00533e4d;
  }
  if (iVar7 == 0xd) {
    local_20 = 3;
    if (param_4 == 0) {
      in_EAX[0x23] = -0x32;
      *pfVar1 = fVar3;
      iVar7 = _DAT_006fdd60;
      in_EAX[0x24] = 0;
      in_EAX[0x25] = 0x113;
      in_EAX[0x31] = 7;
      in_EAX[0x34] = 300;
      in_EAX[0x26] = 0x73;
    }
    else {
      iVar8 = 0;
      piVar10 = (int *)(param_4 + 0xf4);
      do {
        if (*piVar10 == 0) break;
        iVar8 = iVar8 + 1;
        piVar10 = piVar10 + 1;
      } while (iVar8 < 3);
      *(int *)(param_4 + 0xf4 + iVar8 * 4) = in_EAX[0x59];
      in_EAX[0x3c] = *(int *)(param_4 + 0x164);
      *pfVar1 = (float)((iVar8 + 1) * 0x32) + *(float *)(param_4 + 0x2c);
      iVar7 = _DAT_006fe150;
      if (iVar8 == 0) {
        local_20 = 1;
      }
      else if (iVar8 == 1) {
        local_20 = 2;
        iVar7 = _DAT_006fe1f8;
      }
      else {
        local_20 = 0;
      }
    }
    in_EAX[0x21] = iVar7;
    iVar7 = _DAT_006fdc10;
    in_EAX[10] = 0x11;
    in_EAX[0xd] = iVar7;
    in_EAX[0x1a] = 500;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    if (param_5 == -2) {
      FUN_00539190("anim_jump",3,0,_DAT_006fdcb8);
      *(undefined4 *)
       (**(int **)(*(int *)(*in_EAX + 0x940) + 8) + 4 + (in_EAX[0x46] & 0xffffU) * 0xa0) =
           0x3f800000;
      in_EAX[0x21] = _DAT_006fddc4;
    }
    else {
      cVar6 = FUN_0053b730();
      if (cVar6 != '\0') {
        FUN_00539190("anim_push",0,0,_DAT_006e3314);
      }
    }
    goto LAB_00533e4d;
  }
  if (param_2 == 1) {
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    FUN_00534a50();
    uVar2 = in_EAX[0x46];
    iVar7 = **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    iVar8 = FUN_004570e0(0,0,0);
    FUN_00478310("Zombie_flag",0,_DAT_006fde94);
    in_EAX[0x51] = *(int *)(iVar8 + 0x9c);
    FUN_00477640("Zombie_flaghand");
    FUN_00406230(0,0);
    fVar3 = _DAT_006fe93c;
    *(undefined4 *)((uVar2 & 0xffff) * 0xa0 + iVar7 + 0x20) = 0;
    *pfVar1 = fVar3;
    goto LAB_00533e4d;
  }
  if (param_2 == 0x21) {
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    FUN_00534a50();
    iVar8 = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    iVar7 = FUN_004570e0(0,0,0);
    FUN_00478310("Zombie_flag",0,_DAT_006fde94);
    in_EAX[0x51] = *(int *)(iVar7 + 0x9c);
    FUN_00477640("Zombie_flaghand");
    FUN_00406230(0,0);
    fVar3 = _DAT_006fe93c;
    *(undefined4 *)(iVar8 + 0x20) = 0;
    *pfVar1 = fVar3;
    FUN_00543bb0("anim_hair",0xffffffff);
    FUN_00543bb0("anim_head2",0xffffffff);
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      FUN_004779a0("anim_walk2");
    }
    iVar7 = FUN_00477640("anim_head1");
    *(undefined4 *)(iVar7 * 0x60 + *(int *)(iVar8 + 0x58) + 0x44) = DAT_00726e14;
    iVar7 = FUN_004570e0(0,0,0);
    FUN_00478310("anim_head_idle",0,_DAT_006fde94);
    FUN_00478120("anim_hair",0xffffffff);
    in_EAX[0x52] = *(int *)(iVar7 + 0x9c);
    FUN_00406230(0,0);
    uVar4 = _DAT_006fdd30;
    uVar13 = _DAT_006fdb88;
    *(undefined4 *)(iVar8 + 0x20) = 0;
    FUN_0051c8c0(_DAT_006fe3a0,uVar13,uVar4,0x3f800000,0x3f800000);
    FUN_00530c90(*in_EAX);
    in_EAX[0x1a] = 0x96;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    if ((char)in_EAX[0x57] == '\x01') {
      FUN_00531250(*(int *)(*in_EAX + 0x94c) + 0x4844 + in_EAX[0x58] * 0x48);
    }
    goto LAB_00533e4d;
  }
  if (iVar7 == 0x12) {
    *(undefined1 *)(in_EAX + 0x14) = 0;
    in_EAX[10] = 0x14;
    iVar7 = FUN_005ff2a0(0x50);
    uVar13 = _DAT_006fdd9c;
    in_EAX[0x1a] = iVar7 + 1;
    in_EAX[0x27] = 10;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0x1e;
    *(undefined1 *)(in_EAX + 0x2f) = 1;
    in_EAX[0x32] = 500;
    in_EAX[0x2a] = 0x73;
    FUN_00539190("anim_pogo",3,0,uVar13);
    *(undefined4 *)(**(int **)(*(int *)(*in_EAX + 0x940) + 8) + 4 + (in_EAX[0x46] & 0xffffU) * 0xa0)
         = 0x3f800000;
    goto LAB_00533e4d;
  }
  if (param_2 == 5) {
    in_EAX[0x27] = 0x14;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0x32;
    in_EAX[0x2a] = 0x73;
    in_EAX[10] = 0x1d;
    in_EAX[0x36] = 2;
    in_EAX[0x37] = 0x96;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    FUN_005439e0();
    goto LAB_00533e4d;
  }
  if (param_2 == 0x10) {
    iVar8 = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    iVar7 = 0;
    if (0 < *(int *)(*(int *)(iVar8 + 0xc) + 4)) {
      iVar9 = 0;
      do {
        *(undefined1 *)(*(int *)(iVar8 + 0x58) + 0x5d + iVar9) = 0;
        iVar7 = iVar7 + 1;
        iVar9 = iVar9 + 0x60;
      } while (iVar7 < *(int *)(*(int *)(iVar8 + 0xc) + 4));
    }
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      fVar11 = (float10)FUN_0051bf10(_DAT_006fe0ec,_DAT_006fde90);
      FUN_0053f950((float)fVar11);
    }
    else {
      in_EAX[0x21] = _DAT_006fdde8;
      in_EAX[10] = 0x49;
      FUN_00539190("anim_idle",0,0,*(undefined4 *)(iVar8 + 8));
    }
    iVar7 = FUN_004570e0(0,0,0);
    FUN_004779a0("Propeller");
    *(undefined4 *)(iVar7 + 0x10) = 1;
    FUN_00477690();
    in_EAX[0x23] = 0x24;
    in_EAX[0x24] = 0x1e;
    in_EAX[0x25] = 0x2a;
    in_EAX[0x27] = 0x14;
    in_EAX[0x28] = 0x1e;
    in_EAX[0x29] = 0x32;
    in_EAX[0x39] = 0x14;
    in_EAX[0x26] = 0x73;
    in_EAX[0x2a] = 0x73;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    goto LAB_00533e4d;
  }
  if (param_2 == 8) {
    in_EAX[0x47] = _DAT_006fde7c;
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      pcVar12 = "anim_armraise";
      uVar13 = _DAT_006fdb98;
    }
    else {
      in_EAX[10] = 0x28;
      iVar7 = FUN_005ff2a0(0xc);
      in_EAX[0xd] = _DAT_006fdbd0;
      uVar13 = _DAT_006fde50;
      in_EAX[0x1a] = iVar7 + 300;
      pcVar12 = "anim_moonwalk";
    }
    FUN_00539190(pcVar12,0,0,uVar13);
    in_EAX[0x32] = 500;
    local_20 = 8;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    goto LAB_00533e4d;
  }
  if (param_2 == 9) {
    in_EAX[0x47] = _DAT_006fde7c;
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      FUN_00539190("anim_armraise",0,0,_DAT_006fdb98);
    }
    in_EAX[10] = 0x2c;
    *(undefined1 *)(in_EAX + 0x14) = 0;
    local_20 = 8;
    goto LAB_00533e4d;
  }
  if (iVar7 == 0x18) {
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      FUN_00539190("anim_walk",0,0,_DAT_006fdb98);
    }
    cVar6 = FUN_00456ca0();
    if (cVar6 != '\0') {
      in_EAX[0x32] = 0x46;
    }
    goto LAB_00533e4d;
  }
  if (iVar7 == 0x19) {
    *pfVar1 = 0.0;
    in_EAX[0x23] = 700;
    in_EAX[0xc] = 0;
    in_EAX[0x27] = 0;
    in_EAX[0x24] = 0x50;
    in_EAX[0x25] = 0x5a;
    in_EAX[0x28] = 0;
    in_EAX[0x29] = 0;
    in_EAX[0x26] = 0x1ae;
    in_EAX[0x2a] = 0;
    in_EAX[0x32] = (-(uint)(*(int *)(*in_EAX + 0x918) != 0) & 20000) + 40000;
    local_10 = 400000;
    cVar6 = FUN_0053b730();
    if (cVar6 == '\0') {
      FUN_00539190("anim_head_idle",0,0,_DAT_006fdb98);
      FUN_00547230();
    }
    else {
      FUN_00539190("anim_enter",3,0,_DAT_006fdb98);
      in_EAX[0x45] = 500;
      in_EAX[0x4f] = 5000;
      in_EAX[10] = 0x4e;
      FUN_00547230();
    }
    goto LAB_00533e4d;
  }
  if (param_2 == 0x1a) {
    FUN_00534a50();
    FUN_00543bb0("anim_hair",0xffffffff);
    FUN_00543bb0("anim_head2",0xffffffff);
    local_1c = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      FUN_004779a0("anim_walk2");
    }
    iVar7 = FUN_00477640("anim_head1");
    iVar7 = iVar7 * 0x60 + *(int *)(local_1c + 0x58);
LAB_00533d9d:
    *(undefined4 *)(iVar7 + 0x44) = DAT_00726e14;
    iVar7 = FUN_004570e0(0,0,0);
    FUN_00478310("anim_head_idle",0,_DAT_006fde94);
    in_EAX[0x51] = *(int *)(iVar7 + 0x9c);
    FUN_00406230(0,0);
    uVar4 = _DAT_006fdd30;
    uVar13 = _DAT_006fdb88;
    *(undefined4 *)(local_1c + 0x20) = 0;
    FUN_0051c8c0(_DAT_006fdf48,_DAT_006fe838,uVar4,uVar13,0x3f800000);
    in_EAX[0x1a] = 0x96;
  }
  else if (param_2 == 0x1b) {
    FUN_00534a50();
    FUN_00543bb0("anim_hair",0xffffffff);
    FUN_00543bb0("anim_head",0xffffffff);
    FUN_00543bb0("Zombie_tie",0xffffffff);
    uVar2 = in_EAX[0x46];
    iVar7 = **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    FUN_00477640("Zombie_body");
    iVar8 = FUN_004570e0(0,0,0);
    FUN_00478310("anim_idle",0,_DAT_006fde94);
    in_EAX[0x51] = *(int *)(iVar8 + 0x9c);
    FUN_00406230(0,0);
    uVar4 = _DAT_006fe900;
    iVar8 = _DAT_006fde7c;
    uVar13 = _DAT_006fdd30;
    *(undefined4 *)((uVar2 & 0xffff) * 0xa0 + iVar7 + 0x20) = 0;
    FUN_0051c8c0(_DAT_006fdfb8,0,uVar13,uVar4,iVar8);
    in_EAX[0x31] = 8;
    in_EAX[0x34] = 0x44c;
  }
  else if (param_2 == 0x1f) {
    FUN_00534a50();
    FUN_00543bb0("anim_hair",0xffffffff);
    FUN_00543bb0("anim_head",0xffffffff);
    FUN_00543bb0("Zombie_tie",0xffffffff);
    uVar2 = in_EAX[0x46];
    iVar7 = **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    FUN_00477640("Zombie_body");
    iVar8 = FUN_004570e0(0,0,0);
    FUN_00478310("anim_idle",0,_DAT_006fde94);
    in_EAX[0x51] = *(int *)(iVar8 + 0x9c);
    FUN_00406230(0,0);
    uVar4 = _DAT_006fe900;
    iVar8 = _DAT_006fde7c;
    uVar13 = _DAT_006fdd30;
    *(undefined4 *)((uVar2 & 0xffff) * 0xa0 + iVar7 + 0x20) = 0;
    FUN_0051c8c0(_DAT_006fe274,0,uVar13,uVar4,iVar8);
    fVar3 = (float)_DAT_006fdb20;
    in_EAX[0x31] = 9;
    in_EAX[0x34] = 0x898;
    *pfVar1 = *pfVar1 + fVar3;
  }
  else {
    if (iVar7 == 0x1c) {
      FUN_00534a50();
      FUN_00543bb0("anim_hair",0xffffffff);
      FUN_00543bb0("anim_head",0xffffffff);
      FUN_00543bb0("Zombie_tie",0xffffffff);
      uVar2 = in_EAX[0x46];
      iVar7 = **(int **)(*(int *)(*in_EAX + 0x940) + 8);
      FUN_00477640("Zombie_body");
      iVar8 = FUN_004570e0(0,0,0);
      FUN_00478310("anim_idle",0,_DAT_006fde94);
      in_EAX[0x51] = *(int *)(iVar8 + 0x9c);
      FUN_00406230(0,0);
      uVar4 = _DAT_006fdd30;
      uVar13 = _DAT_006fdb88;
      *(undefined4 *)((uVar2 & 0xffff) * 0xa0 + iVar7 + 0x20) = 0;
      FUN_0051c8c0(_DAT_006fe1e8,_DAT_006fe838,uVar4,uVar13,0x3f800000);
      *(undefined1 *)(in_EAX + 0x14) = 0;
      in_EAX[0x32] = 500;
      FUN_005ff2a0(0xaf);
      iVar7 = FUN_006ba960();
      in_EAX[0x1a] = iVar7 * 2;
      goto LAB_00533e4d;
    }
    if (param_2 == 0x1d) {
      FUN_00534a50();
      FUN_00543bb0("anim_hair",0xffffffff);
      FUN_00543bb0("anim_head2",0xffffffff);
      local_1c = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
      cVar6 = FUN_0053b730();
      if (cVar6 != '\0') {
        FUN_004779a0("anim_walk2");
      }
      iVar7 = FUN_00477640("anim_head1");
      iVar7 = iVar7 * 0x60 + *(int *)(local_1c + 0x58);
      goto LAB_00533d9d;
    }
    if (param_2 != 0x1e) goto LAB_00533e4d;
    FUN_00534a50();
    FUN_00543bb0("anim_hair",0xffffffff);
    FUN_00543bb0("anim_head2",0xffffffff);
    iVar7 = (in_EAX[0x46] & 0xffffU) * 0xa0 + **(int **)(*(int *)(*in_EAX + 0x940) + 8);
    cVar6 = FUN_0053b730();
    if (cVar6 != '\0') {
      FUN_004779a0("anim_walk2");
    }
    iVar8 = FUN_00477640("anim_head1");
    *(undefined4 *)(iVar8 * 0x60 + *(int *)(iVar7 + 0x58) + 0x44) = DAT_00726e14;
    iVar8 = FUN_004570e0(0,0,0);
    FUN_00478310("anim_idle",0,_DAT_006fde94);
    in_EAX[0x51] = *(int *)(iVar8 + 0x9c);
    FUN_00406230(0,0);
    uVar5 = _DAT_006fe938;
    uVar4 = _DAT_006fdd30;
    uVar13 = _DAT_006fdcd0;
    *(undefined4 *)(iVar7 + 0x20) = 0;
    FUN_0051c8c0(_DAT_006fe1e8,_DAT_006fe790,uVar4,uVar5,uVar13);
    in_EAX[10] = 0x5c;
  }
  *(undefined1 *)(in_EAX + 0x14) = 0;
LAB_00533e4d:
  if (((in_EAX[0x1b] != -2) && (in_EAX[0x1b] != -3)) && (*(int *)(*in_EAX + 0x918) == 0x17)) {
    fVar11 = (float10)FUN_005ff2c0(_DAT_006fdbf8);
    FUN_00539190("anim_aquarium_swim",0,0,(float)(fVar11 + (float10)_DAT_006fdab0));
    in_EAX[0x19] = 10;
    in_EAX[10] = 0x40;
    in_EAX[0x1a] = 200;
    in_EAX[0x32] = 200;
    iVar7 = FUN_005ff2a0(0xc9);
    in_EAX[0x45] = iVar7 + 200;
  }
  iVar7 = *in_EAX;
  if (((*(int *)(iVar7 + 0x868) != 0) &&
      ((*(int *)(iVar7 + 0x918) == 0x19 ||
       ((*(int *)(iVar7 + 0x918) == 0 && (*(int *)(*(int *)(iVar7 + 0x94c) + 0x4c) == 0x19)))))) &&
     (((in_EAX[0x1b] != -2 && (in_EAX[0x1b] != -3)) || (param_5 == -2)))) {
    in_EAX[0x47] = _DAT_006fdbd0;
    in_EAX[0x32] = (int)(in_EAX[0x32] + (in_EAX[0x32] >> 0x1f & 3U)) >> 2;
    in_EAX[0x34] = (int)(in_EAX[0x34] + (in_EAX[0x34] >> 0x1f & 3U)) >> 2;
    in_EAX[0x37] = (int)(in_EAX[0x37] + (in_EAX[0x37] >> 0x1f & 3U)) >> 2;
    in_EAX[0x39] = (int)(in_EAX[0x39] + (in_EAX[0x39] >> 0x1f & 3U)) >> 2;
  }
  FUN_0053f9d0();
  if ((char)in_EAX[0x14] != '\0') {
    uVar2 = in_EAX[0x46];
    if ((((*(int *)(*in_EAX + 0x940) != 0) &&
         (piVar10 = *(int **)(*(int *)(*in_EAX + 0x940) + 8), uVar2 != 0)) &&
        ((uVar2 & 0xffff) < (uint)piVar10[2])) &&
       (iVar7 = (uVar2 & 0xffff) * 0xa0 + *piVar10, *(uint *)(iVar7 + 0x9c) == uVar2)) {
      FUN_00478170(iVar7,"anim_tongue",0);
    }
  }
  in_EAX[0x35] = in_EAX[0x34];
  in_EAX[0x33] = in_EAX[0x32];
  in_EAX[0x38] = in_EAX[0x37];
  in_EAX[0x3a] = in_EAX[0x39];
  *(undefined1 *)(in_EAX + 0x3b) = 0;
  iVar7 = FUN_006ba960();
  in_EAX[2] = iVar7;
  iVar7 = FUN_006ba960();
  in_EAX[3] = iVar7;
  in_EAX[8] = in_EAX[7] * 10000 + local_20 + local_10;
  if (in_EAX[0x19] == 10) {
    in_EAX[0x33] = 300;
  }
  if ((in_EAX[0x1b] != -2) && (in_EAX[0x1b] != -3)) {
    FUN_00541000();
    FUN_00541130();
  }
  FUN_0053cc00();
  return;
}

