// b21_music.cpp — kMusicSetupCases -> Music::SetupMusicFileForTune（换曲）
//             + kMusicPlayCases -> Music::PlayMusic（换曲）
// FormA = e44390a6^ 双 switch（逐字）；FormB = HEAD 13 槽 lambda 表×2（逐字，offset 入 Locals）。
#include "r3_entities.h"

// ==================== b21 FormA：SetupMusicFileForTune switch 逐字 ====================
__declspec(noinline) void Music::SetupMusicFileForTune_A(MusicFile theMusicFile, MusicTune theMusicTune)
{
    int aTrackCount = 0;
    int aTrackStart1 = -1, aTrackEnd1 = -1, aTrackStart2 = -1, aTrackEnd2 = -1;

    switch (theMusicTune)
    {
    case MusicTune::MUSIC_TUNE_DAY_GRASSWALK:
        switch (theMusicFile) {
        case MusicFile::MUSIC_FILE_MAIN_MUSIC:		aTrackCount = 30;	aTrackStart1 = 0;	aTrackEnd1 = 23;											break;
        case MusicFile::MUSIC_FILE_HIHATS:			aTrackCount = 30;	aTrackStart1 = 27;	aTrackEnd1 = 27;											break;
        case MusicFile::MUSIC_FILE_DRUMS:			aTrackCount = 30;	aTrackStart1 = 24;	aTrackEnd1 = 26;											break;
        default: break;
        } break;
    case MusicTune::MUSIC_TUNE_POOL_WATERYGRAVES:
        switch (theMusicFile) {
        case MusicFile::MUSIC_FILE_MAIN_MUSIC:		aTrackCount = 30;	aTrackStart1 = 0;	aTrackEnd1 = 17;											break;
        case MusicFile::MUSIC_FILE_HIHATS:			aTrackCount = 30;	aTrackStart1 = 18;	aTrackEnd1 = 24;	aTrackStart2 = 29;	aTrackEnd2 = 29;	break;
        // 1073 0045E0DF: DRUMS starts at 18, overlapping the HIHATS range.
        case MusicFile::MUSIC_FILE_DRUMS:			aTrackCount = 30;	aTrackStart1 = 18;	aTrackEnd1 = 28;											break;
        default: break;
        } break;
    case MusicTune::MUSIC_TUNE_FOG_RIGORMORMIST:
        switch (theMusicFile) {
        case MusicFile::MUSIC_FILE_MAIN_MUSIC:		aTrackCount = 30;	aTrackStart1 = 0;	aTrackEnd1 = 15;											break;
        case MusicFile::MUSIC_FILE_HIHATS:			aTrackCount = 30;	aTrackStart1 = 23;	aTrackEnd1 = 23;											break;
        case MusicFile::MUSIC_FILE_DRUMS:			aTrackCount = 30;	aTrackStart1 = 16;	aTrackEnd1 = 22;											break;
        default: break;
        } break;
    case MusicTune::MUSIC_TUNE_ROOF_GRAZETHEROOF:
        switch (theMusicFile) {
        case MusicFile::MUSIC_FILE_MAIN_MUSIC:		aTrackCount = 30;	aTrackStart1 = 0;	aTrackEnd1 = 17;											break;
        case MusicFile::MUSIC_FILE_HIHATS:			aTrackCount = 30;	aTrackStart1 = 21;	aTrackEnd1 = 21;											break;
        case MusicFile::MUSIC_FILE_DRUMS:			aTrackCount = 30;	aTrackStart1 = 18;	aTrackEnd1 = 20;											break;
        default: break;
        } break;
    default:
        if (theMusicFile == MusicFile::MUSIC_FILE_MAIN_MUSIC || theMusicFile == MusicFile::MUSIC_FILE_DRUMS)
        {
            aTrackCount = 30;
            aTrackStart1 = 0;
            aTrackEnd1 = 29;
        }
        break;
    }

    HMUSIC aHMusic = GetBassMusicHandle(theMusicFile);
    for (int aTrack = 0; aTrack < aTrackCount; aTrack++)
    {
        float aVolume;
        if (aTrack >= aTrackStart1 && aTrack <= aTrackEnd1)
            aVolume = 1;
        else if (aTrack >= aTrackStart2 && aTrack <= aTrackEnd2)
            aVolume = 1;
        else
            aVolume = 0;

        gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_VOL_CHAN + aTrack, aVolume);  // 设置音乐每条轨道的音量属性（静音与否）
    }
}

// ==================== b21 FormB：HEAD kMusicSetupCases（逐字） ====================
namespace
{
// Music::SetupMusicFileForTune 槽位上下文：五常量经此传递（dispatch 前载入、后写回）。
struct MusicSetupLocals
{
    int mTrackCount;
    int mTrackStart1;
    int mTrackEnd1;
    int mTrackStart2;
    int mTrackEnd2;
};
using MusicSetupCaseFn = void (*)(Music&, MusicFile, MusicSetupLocals&);

// 原 default（无 case 的 9 型与表外哨兵共用）
void MusicSetupDefault(Music& m, MusicFile theMusicFile, MusicSetupLocals& lc)
{
    		if (theMusicFile == MusicFile::MUSIC_FILE_MAIN_MUSIC || theMusicFile == MusicFile::MUSIC_FILE_DRUMS)
    		{
    			lc.mTrackCount = 30;
    			lc.mTrackStart1 = 0;
    			lc.mTrackEnd1 = 29;
    		}
}

// 匿名 lambda 函数指针表，行序 = MusicTune 枚举值序（1..13）。
constexpr MusicSetupCaseFn kMusicSetupCases[(int)MusicTune::NUM_MUSIC_TUNES - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK] = {
    // 原 case MUSIC_TUNE_DAY_GRASSWALK
    [](Music& m, MusicFile theMusicFile, MusicSetupLocals& lc)
    {
    		switch (theMusicFile) {
    		case MusicFile::MUSIC_FILE_MAIN_MUSIC:		lc.mTrackCount = 30;	lc.mTrackStart1 = 0;	lc.mTrackEnd1 = 23;											break;
    		case MusicFile::MUSIC_FILE_HIHATS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 27;	lc.mTrackEnd1 = 27;											break;
    		case MusicFile::MUSIC_FILE_DRUMS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 24;	lc.mTrackEnd1 = 26;											break;
    		default: break;
    		}
    },  // 0 MUSIC_TUNE_DAY_GRASSWALK
    &MusicSetupDefault,  // 1 MUSIC_TUNE_NIGHT_MOONGRAINS（原 default）
    // 原 case MUSIC_TUNE_POOL_WATERYGRAVES
    [](Music& m, MusicFile theMusicFile, MusicSetupLocals& lc)
    {
    		switch (theMusicFile) {
    		case MusicFile::MUSIC_FILE_MAIN_MUSIC:		lc.mTrackCount = 30;	lc.mTrackStart1 = 0;	lc.mTrackEnd1 = 17;											break;
    		case MusicFile::MUSIC_FILE_HIHATS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 18;	lc.mTrackEnd1 = 24;	lc.mTrackStart2 = 29;	lc.mTrackEnd2 = 29;	break;
    		// 1073 0045E0DF: DRUMS starts at 18, overlapping the HIHATS range.
    		case MusicFile::MUSIC_FILE_DRUMS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 18;	lc.mTrackEnd1 = 28;											break;
    		default: break;
    		}
    },  // 2 MUSIC_TUNE_POOL_WATERYGRAVES
    // 原 case MUSIC_TUNE_FOG_RIGORMORMIST
    [](Music& m, MusicFile theMusicFile, MusicSetupLocals& lc)
    {
    		switch (theMusicFile) {
    		case MusicFile::MUSIC_FILE_MAIN_MUSIC:		lc.mTrackCount = 30;	lc.mTrackStart1 = 0;	lc.mTrackEnd1 = 15;											break;
    		case MusicFile::MUSIC_FILE_HIHATS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 23;	lc.mTrackEnd1 = 23;											break;
    		case MusicFile::MUSIC_FILE_DRUMS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 16;	lc.mTrackEnd1 = 22;											break;
    		default: break;
    		}
    },  // 3 MUSIC_TUNE_FOG_RIGORMORMIST
    // 原 case MUSIC_TUNE_ROOF_GRAZETHEROOF
    [](Music& m, MusicFile theMusicFile, MusicSetupLocals& lc)
    {
    		switch (theMusicFile) {
    		case MusicFile::MUSIC_FILE_MAIN_MUSIC:		lc.mTrackCount = 30;	lc.mTrackStart1 = 0;	lc.mTrackEnd1 = 17;											break;
    		case MusicFile::MUSIC_FILE_HIHATS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 21;	lc.mTrackEnd1 = 21;											break;
    		case MusicFile::MUSIC_FILE_DRUMS:			lc.mTrackCount = 30;	lc.mTrackStart1 = 18;	lc.mTrackEnd1 = 20;											break;
    		default: break;
    		}
    },  // 4 MUSIC_TUNE_ROOF_GRAZETHEROOF
    &MusicSetupDefault,  // 5 MUSIC_TUNE_CHOOSE_YOUR_SEEDS（原 default）
    &MusicSetupDefault,  // 6 MUSIC_TUNE_TITLE_CRAZY_DAVE_MAIN_THEME（原 default）
    &MusicSetupDefault,  // 7 MUSIC_TUNE_ZEN_GARDEN（原 default）
    &MusicSetupDefault,  // 8 MUSIC_TUNE_PUZZLE_CEREBRAWL（原 default）
    &MusicSetupDefault,  // 9 MUSIC_TUNE_MINIGAME_LOONBOON（原 default）
    &MusicSetupDefault,  // 10 MUSIC_TUNE_CONVEYER（原 default）
    &MusicSetupDefault,  // 11 MUSIC_TUNE_FINAL_BOSS_BRAINIAC_MANIAC（原 default）
    &MusicSetupDefault,  // 12 MUSIC_TUNE_CREDITS_ZOMBIES_ON_YOUR_LAWN（原 default）
};
static_assert(sizeof(kMusicSetupCases) / sizeof(kMusicSetupCases[0]) ==
    (int)MusicTune::NUM_MUSIC_TUNES - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK, "kMusicSetupCases 槽位数须与 MusicTune 枚举同步");
}  // namespace

//0x45A6C0
__declspec(noinline) void Music::SetupMusicFileForTune_B(MusicFile theMusicFile, MusicTune theMusicTune)
{
    int aTrackCount = 0;
    int aTrackStart1 = -1, aTrackEnd1 = -1, aTrackStart2 = -1, aTrackEnd2 = -1;

    // C 形态 -> 匿名 lambda 函数指针表：行序 = MusicTune 枚举值序（1..13，
    // 下标平移）。内层 MusicFile switch 随体迁移保持原样；五常量经
    // MusicSetupLocals 传递（dispatch 前载入、后写回）；default 非空
    //（MAIN/DRUMS 全曲段）具名并被缺槽与越界（NONE/0）分支复用。
    MusicSetupLocals aSetupLocals{aTrackCount, aTrackStart1, aTrackEnd1, aTrackStart2, aTrackEnd2};
    const int aTuneIndex = static_cast<int>(theMusicTune) - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK;
    if (static_cast<unsigned>(aTuneIndex) < static_cast<unsigned>((int)MusicTune::NUM_MUSIC_TUNES - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK))
    {
        kMusicSetupCases[aTuneIndex](*this, theMusicFile, aSetupLocals);
    }
    else
    {
        MusicSetupDefault(*this, theMusicFile, aSetupLocals);
    }
    aTrackCount = aSetupLocals.mTrackCount;
    aTrackStart1 = aSetupLocals.mTrackStart1;
    aTrackEnd1 = aSetupLocals.mTrackEnd1;
    aTrackStart2 = aSetupLocals.mTrackStart2;
    aTrackEnd2 = aSetupLocals.mTrackEnd2;


    HMUSIC aHMusic = GetBassMusicHandle(theMusicFile);
    for (int aTrack = 0; aTrack < aTrackCount; aTrack++)
    {
        float aVolume;
        if (aTrack >= aTrackStart1 && aTrack <= aTrackEnd1)
            aVolume = 1;
        else if (aTrack >= aTrackStart2 && aTrack <= aTrackEnd2)
            aVolume = 1;
        else
            aVolume = 0;

        gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_VOL_CHAN + aTrack, aVolume);  // 设置音乐每条轨道的音量属性（静音与否）
    }
}

// ==================== b22 FormA：PlayMusic switch 逐字 ====================
__declspec(noinline) void Music::PlayMusic_A(MusicTune theMusicTune, int theOffset, int theDrumsOffset)
{
    if (IsMusicDisabled())
        return;

    mCurMusicTune = theMusicTune;
    mCurMusicFileMain = MusicFile::MUSIC_FILE_NONE;
    mCurMusicFileDrums = MusicFile::MUSIC_FILE_NONE;
    mCurMusicFileHihats = MusicFile::MUSIC_FILE_NONE;
    bool aRestartingSong = theOffset != -1;

    switch (theMusicTune)
    {
    case MusicTune::MUSIC_TUNE_DAY_GRASSWALK:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
        mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
        if (theOffset == -1)
            theOffset = 0;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        PlayFromOffset(mCurMusicFileDrums, theOffset, 0.0);
        PlayFromOffset(mCurMusicFileHihats, theOffset, 0.0);
        break;

    case MusicTune::MUSIC_TUNE_NIGHT_MOONGRAINS:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
        if (theOffset == -1)
        {
            theOffset = 0x30;
            theDrumsOffset = 0x5C;
        }
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        PlayFromOffset(mCurMusicFileDrums, theDrumsOffset, 0.0);
        break;

    case MusicTune::MUSIC_TUNE_POOL_WATERYGRAVES:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
        mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
        if (theOffset == -1)
            theOffset = 0x5E;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        PlayFromOffset(mCurMusicFileDrums, theOffset, 0.0);
        PlayFromOffset(mCurMusicFileHihats, theOffset, 0.0);
        break;

    case MusicTune::MUSIC_TUNE_FOG_RIGORMORMIST:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
        mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
        if (theOffset == -1)
            theOffset = 0x7D;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        PlayFromOffset(mCurMusicFileDrums, theOffset, 0.0);
        PlayFromOffset(mCurMusicFileHihats, theOffset, 0.0);
        break;

    case MusicTune::MUSIC_TUNE_ROOF_GRAZETHEROOF:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
        mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
        if (theOffset == -1)
            theOffset = 0xB8;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        PlayFromOffset(mCurMusicFileDrums, theOffset, 0.0);
        PlayFromOffset(mCurMusicFileHihats, theOffset, 0.0);
        break;

    case MusicTune::MUSIC_TUNE_CHOOSE_YOUR_SEEDS:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0x7A;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_TITLE_CRAZY_DAVE_MAIN_THEME:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0x98;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_ZEN_GARDEN:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0xDD;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_PUZZLE_CEREBRAWL:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0xB1;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_MINIGAME_LOONBOON:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0xA6;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_CONVEYER:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0xD4;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_FINAL_BOSS_BRAINIAC_MANIAC:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
        if (theOffset == -1)
            theOffset = 0x9E;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    case MusicTune::MUSIC_TUNE_CREDITS_ZOMBIES_ON_YOUR_LAWN:
        mCurMusicFileMain = MusicFile::MUSIC_FILE_CREDITS_ZOMBIES_ON_YOUR_LAWN;
        if (theOffset == -1)
            theOffset = 0;
        PlayFromOffset(mCurMusicFileMain, theOffset, 1.0);
        break;

    default:
        TOD_ASSERT(false);
        break;
    }

    if (aRestartingSong)
    {
        if (mCurMusicFileMain != MusicFile::MUSIC_FILE_NONE)
        {
            HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileMain);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, (float)mBaseBPM);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, (float)mBaseModSpeed);
        }
        if (mCurMusicFileDrums != (MusicFile)-1)
        {
            HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileDrums);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, (float)mBaseBPM);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, (float)mBaseModSpeed);
        }
        if (mCurMusicFileHihats != (MusicFile)-1)
        {
            HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileHihats);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, (float)mBaseBPM);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, (float)mBaseModSpeed);
        }
    }
    else
    {
        HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileMain);
        float aBaseBPM = 0.0f;
        float aBaseModSpeed = 0.0f;
        gBass->BASS_ChannelGetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, &aBaseBPM);
        gBass->BASS_ChannelGetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, &aBaseModSpeed);
        mBaseBPM = static_cast<int>(aBaseBPM);
        mBaseModSpeed = static_cast<int>(aBaseModSpeed);
    }
}

// ==================== b22 FormB：HEAD kMusicPlayCases（逐字） ====================
namespace
{
// Music::PlayMusic 分发表：表内匿名 lambda = 原 case 体逐句迁移（生成器
// + 逆变换 token 对拍 0 差异）；default 具名并被越界分支复用。
struct MusicPlayLocals
{
    int mOffset;
    int mDrumsOffset;
};
using MusicPlayCaseFn = void (*)(Music&, MusicPlayLocals&);

// 原 default（无 case 的 0 型与表外哨兵共用）
void MusicPlayDefault(Music& m, MusicPlayLocals& lc)
{
    		TOD_ASSERT(false);
}

// 匿名 lambda 函数指针表，行序 = MusicTune 枚举值序（1..13）。
constexpr MusicPlayCaseFn kMusicPlayCases[(int)MusicTune::NUM_MUSIC_TUNES - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK] = {
    // 原 case MUSIC_TUNE_DAY_GRASSWALK
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		m.mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
    		m.mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    		m.PlayFromOffset(m.mCurMusicFileDrums, lc.mOffset, 0.0);
    		m.PlayFromOffset(m.mCurMusicFileHihats, lc.mOffset, 0.0);
    },  // 0 MUSIC_TUNE_DAY_GRASSWALK
    // 原 case MUSIC_TUNE_NIGHT_MOONGRAINS
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		m.mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
    		if (lc.mOffset == -1)
    		{
    			lc.mOffset = 0x30;
    			lc.mDrumsOffset = 0x5C;
    		}
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    		m.PlayFromOffset(m.mCurMusicFileDrums, lc.mDrumsOffset, 0.0);
    },  // 1 MUSIC_TUNE_NIGHT_MOONGRAINS
    // 原 case MUSIC_TUNE_POOL_WATERYGRAVES
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		m.mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
    		m.mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0x5E;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    		m.PlayFromOffset(m.mCurMusicFileDrums, lc.mOffset, 0.0);
    		m.PlayFromOffset(m.mCurMusicFileHihats, lc.mOffset, 0.0);
    },  // 2 MUSIC_TUNE_POOL_WATERYGRAVES
    // 原 case MUSIC_TUNE_FOG_RIGORMORMIST
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		m.mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
    		m.mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0x7D;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    		m.PlayFromOffset(m.mCurMusicFileDrums, lc.mOffset, 0.0);
    		m.PlayFromOffset(m.mCurMusicFileHihats, lc.mOffset, 0.0);
    },  // 3 MUSIC_TUNE_FOG_RIGORMORMIST
    // 原 case MUSIC_TUNE_ROOF_GRAZETHEROOF
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		m.mCurMusicFileDrums = MusicFile::MUSIC_FILE_DRUMS;
    		m.mCurMusicFileHihats = MusicFile::MUSIC_FILE_HIHATS;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0xB8;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    		m.PlayFromOffset(m.mCurMusicFileDrums, lc.mOffset, 0.0);
    		m.PlayFromOffset(m.mCurMusicFileHihats, lc.mOffset, 0.0);
    },  // 4 MUSIC_TUNE_ROOF_GRAZETHEROOF
    // 原 case MUSIC_TUNE_CHOOSE_YOUR_SEEDS
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0x7A;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 5 MUSIC_TUNE_CHOOSE_YOUR_SEEDS
    // 原 case MUSIC_TUNE_TITLE_CRAZY_DAVE_MAIN_THEME
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0x98;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 6 MUSIC_TUNE_TITLE_CRAZY_DAVE_MAIN_THEME
    // 原 case MUSIC_TUNE_ZEN_GARDEN
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0xDD;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 7 MUSIC_TUNE_ZEN_GARDEN
    // 原 case MUSIC_TUNE_PUZZLE_CEREBRAWL
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0xB1;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 8 MUSIC_TUNE_PUZZLE_CEREBRAWL
    // 原 case MUSIC_TUNE_MINIGAME_LOONBOON
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0xA6;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 9 MUSIC_TUNE_MINIGAME_LOONBOON
    // 原 case MUSIC_TUNE_CONVEYER
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0xD4;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 10 MUSIC_TUNE_CONVEYER
    // 原 case MUSIC_TUNE_FINAL_BOSS_BRAINIAC_MANIAC
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_MAIN_MUSIC;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0x9E;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 11 MUSIC_TUNE_FINAL_BOSS_BRAINIAC_MANIAC
    // 原 case MUSIC_TUNE_CREDITS_ZOMBIES_ON_YOUR_LAWN
    [](Music& m, MusicPlayLocals& lc)
    {
    		m.mCurMusicFileMain = MusicFile::MUSIC_FILE_CREDITS_ZOMBIES_ON_YOUR_LAWN;
    		if (lc.mOffset == -1)
    			lc.mOffset = 0;
    		m.PlayFromOffset(m.mCurMusicFileMain, lc.mOffset, 1.0);
    },  // 12 MUSIC_TUNE_CREDITS_ZOMBIES_ON_YOUR_LAWN
};
static_assert(sizeof(kMusicPlayCases) / sizeof(kMusicPlayCases[0]) ==
    (int)MusicTune::NUM_MUSIC_TUNES - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK, "kMusicPlayCases 槽位数须与 MusicTune 枚举同步");
}  // namespace

//0x45ADB0
__declspec(noinline) void Music::PlayMusic_B(MusicTune theMusicTune, int theOffset, int theDrumsOffset)
{
    if (IsMusicDisabled())
        return;

    mCurMusicTune = theMusicTune;
    mCurMusicFileMain = MusicFile::MUSIC_FILE_NONE;
    mCurMusicFileDrums = MusicFile::MUSIC_FILE_NONE;
    mCurMusicFileHihats = MusicFile::MUSIC_FILE_NONE;
    bool aRestartingSong = theOffset != -1;

    // C 形态 -> 匿名 lambda 函数指针表：行序 = MusicTune 枚举值序（1..13，
    // 下标平移）。theOffset/theDrumsOffset 仅被 case 读写，经 MusicPlayLocals
    // 传递；default（TOD_ASSERT）具名并被越界分支复用（1..13 全覆盖无缺槽）。
    MusicPlayLocals aPlayLocals{theOffset, theDrumsOffset};
    const int aTuneIndex = static_cast<int>(theMusicTune) - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK;
    if (static_cast<unsigned>(aTuneIndex) < static_cast<unsigned>((int)MusicTune::NUM_MUSIC_TUNES - (int)MusicTune::MUSIC_TUNE_DAY_GRASSWALK))
    {
        kMusicPlayCases[aTuneIndex](*this, aPlayLocals);
    }
    else
    {
        MusicPlayDefault(*this, aPlayLocals);
    }


    if (aRestartingSong)
    {
        if (mCurMusicFileMain != MusicFile::MUSIC_FILE_NONE)
        {
            HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileMain);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, (float)mBaseBPM);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, (float)mBaseModSpeed);
        }
        if (mCurMusicFileDrums != (MusicFile)-1)
        {
            HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileDrums);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, (float)mBaseBPM);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, (float)mBaseModSpeed);
        }
        if (mCurMusicFileHihats != (MusicFile)-1)
        {
            HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileHihats);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, (float)mBaseBPM);
            gBass->BASS_ChannelSetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, (float)mBaseModSpeed);
        }
    }
    else
    {
        HMUSIC aHMusic = GetBassMusicHandle(mCurMusicFileMain);
        float aBaseBPM = 0.0f;
        float aBaseModSpeed = 0.0f;
        gBass->BASS_ChannelGetAttribute(aHMusic, BASS_ATTRIB_MUSIC_BPM, &aBaseBPM);
        gBass->BASS_ChannelGetAttribute(aHMusic, BASS_ATTRIB_MUSIC_SPEED, &aBaseModSpeed);
        mBaseBPM = static_cast<int>(aBaseBPM);
        mBaseModSpeed = static_cast<int>(aBaseModSpeed);
    }
}

// ============================ main ============================
static Music g_music;

int main()
{
    int rc = 0;
    {
        auto reset = []() {};
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                MusicFile f = (MusicFile)(1 + g_inputs[i].b % 4);            // MAIN/DRUMS/HIHATS/CREDITS
                MusicTune t = (MusicTune)(1 + g_inputs[i].a % 13);           // 1..13
                g_music.SetupMusicFileForTune_A(f, t);
                g_music.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                MusicFile f = (MusicFile)(1 + g_inputs[i].b % 4);
                MusicTune t = (MusicTune)(1 + g_inputs[i].a % 13);
                g_music.SetupMusicFileForTune_B(f, t);
                g_music.HashFold(ck);
            }
        };
        rc |= R3BenchMain("b21_SetupMusicFileForTune_kMusicSetupCases", reset, pa, pb);
    }
    {
        auto reset = []() { g_music.mBaseBPM = 0; g_music.mBaseModSpeed = 0; };
        auto pa = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                MusicTune t = (MusicTune)(1 + g_inputs[i].a % 13);
                int off = (g_inputs[i].c % 4 == 0) ? -1 : (int)(g_inputs[i].c % 300);
                int dr = (int)(g_inputs[i].d % 200);
                g_music.PlayMusic_A(t, off, dr);
                g_music.HashFold(ck);
            }
        };
        auto pb = [&](uint64_t& ck)
        {
            for (uint32_t i = 0; i < R3_N; i++)
            {
                MusicTune t = (MusicTune)(1 + g_inputs[i].a % 13);
                int off = (g_inputs[i].c % 4 == 0) ? -1 : (int)(g_inputs[i].c % 300);
                int dr = (int)(g_inputs[i].d % 200);
                g_music.PlayMusic_B(t, off, dr);
                g_music.HashFold(ck);
            }
        };
        rc |= R3BenchMain("b22_PlayMusic_kMusicPlayCases", reset, pa, pb);
    }
    return rc;
}
