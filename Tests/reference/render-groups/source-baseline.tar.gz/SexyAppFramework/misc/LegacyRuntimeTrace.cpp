#include "LegacyRuntimeTrace.h"

#include <windows.h>

#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <share.h>

namespace Sexy
{
namespace
{
struct LegacyRuntimeTraceState
{
	bool			mEnabled = false;
	FILE*			mFile = nullptr;
	std::uint64_t	mFrequency = 0;
	std::uint64_t	mOrigin = 0;
	double			mStallThresholdMilliseconds = 20.0;
	char			mBuffer[16 * 1024 * 1024] = {};

	LegacyRuntimeTraceState()
	{
		char aPath[MAX_PATH] = {};
		const DWORD aPathLength = GetEnvironmentVariableA("PVZ_RUNTIME_TRACE", aPath, MAX_PATH);
		if (aPathLength == 0 || aPathLength >= MAX_PATH)
			return;

		LARGE_INTEGER aFrequency = {};
		LARGE_INTEGER anOrigin = {};
		if (!QueryPerformanceFrequency(&aFrequency) || !QueryPerformanceCounter(&anOrigin))
			return;

		char aThreshold[64] = {};
		if (GetEnvironmentVariableA("PVZ_STALL_THRESHOLD_MS", aThreshold, sizeof(aThreshold)) > 0)
		{
			char* anEnd = nullptr;
			const double aValue = std::strtod(aThreshold, &anEnd);
			if (anEnd != aThreshold && aValue > 0.0)
				mStallThresholdMilliseconds = aValue;
		}

		mFile = _fsopen(aPath, "w", _SH_DENYNO);
		if (mFile == nullptr)
			return;

		mFrequency = static_cast<std::uint64_t>(aFrequency.QuadPart);
		mOrigin = static_cast<std::uint64_t>(anOrigin.QuadPart);
		setvbuf(mFile, mBuffer, _IOFBF, sizeof(mBuffer));
		std::fprintf(mFile, "time_ms,update,event,duration_ms,detail\n");
		std::fprintf(
			mFile,
			"0.000,0,trace-start,0.000,stall-threshold-ms=%.3f\n",
			mStallThresholdMilliseconds);
		std::fflush(mFile);
		mEnabled = true;
	}

	~LegacyRuntimeTraceState()
	{
		if (mFile != nullptr)
			std::fclose(mFile);
	}

	std::uint64_t NowMicroseconds() const
	{
		LARGE_INTEGER aCounter = {};
		QueryPerformanceCounter(&aCounter);
		const std::uint64_t aDelta = static_cast<std::uint64_t>(aCounter.QuadPart) - mOrigin;
		return aDelta * 1000000ULL / mFrequency;
	}

	void Write(
		const char* theEvent,
		int theUpdateCount,
		double theDurationMilliseconds,
		const char* theDetail,
		bool theFlush)
	{
		if (!mEnabled)
			return;

		const double aTimeMilliseconds = NowMicroseconds() / 1000.0;
		std::fprintf(
			mFile,
			"%.3f,%d,%s,%.3f,%s\n",
			aTimeMilliseconds,
			theUpdateCount,
			theEvent,
			theDurationMilliseconds,
			theDetail == nullptr ? "" : theDetail);
		if (theFlush)
			std::fflush(mFile);
	}
};

LegacyRuntimeTraceState& GetTraceState()
{
	static LegacyRuntimeTraceState aState;
	return aState;
}
}

bool LegacyRuntimeTraceEnabled()
{
	return GetTraceState().mEnabled;
}

std::uint64_t LegacyRuntimeTraceNowMicroseconds()
{
	LegacyRuntimeTraceState& aState = GetTraceState();
	return aState.mEnabled ? aState.NowMicroseconds() : 0;
}

void LegacyRuntimeTraceInstant(const char* theEvent, int theUpdateCount, const char* theFormat, ...)
{
	LegacyRuntimeTraceState& aState = GetTraceState();
	if (!aState.mEnabled)
		return;

	char aDetail[512] = {};
	if (theFormat != nullptr)
	{
		va_list anArguments;
		va_start(anArguments, theFormat);
		vsnprintf_s(aDetail, sizeof(aDetail), _TRUNCATE, theFormat, anArguments);
		va_end(anArguments);
		for (char* aChar = aDetail; *aChar != '\0'; ++aChar)
		{
			if (*aChar == ',' || *aChar == '\r' || *aChar == '\n')
				*aChar = ';';
		}
	}

	aState.Write(theEvent, theUpdateCount, 0.0, aDetail, true);
}

void LegacyRuntimeTraceDuration(
	const char* theEvent,
	int theUpdateCount,
	std::uint64_t theStartMicroseconds,
	std::uint64_t theEndMicroseconds)
{
	LegacyRuntimeTraceState& aState = GetTraceState();
	if (!aState.mEnabled || theStartMicroseconds == 0 || theEndMicroseconds < theStartMicroseconds)
		return;

	const double aDurationMilliseconds = (theEndMicroseconds - theStartMicroseconds) / 1000.0;
	if (aDurationMilliseconds < aState.mStallThresholdMilliseconds)
		return;

	aState.Write(theEvent, theUpdateCount, aDurationMilliseconds, nullptr, false);
}

LegacyRuntimeTraceScope::LegacyRuntimeTraceScope(const char* theEvent, int theUpdateCount) :
	mEvent(theEvent),
	mUpdateCount(theUpdateCount),
	mStartMicroseconds(LegacyRuntimeTraceNowMicroseconds())
{
}

LegacyRuntimeTraceScope::~LegacyRuntimeTraceScope()
{
	if (mStartMicroseconds == 0)
		return;
	LegacyRuntimeTraceDuration(
		mEvent,
		mUpdateCount,
		mStartMicroseconds,
		LegacyRuntimeTraceNowMicroseconds());
}

}
