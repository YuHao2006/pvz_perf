// bench10_getcost.cpp - 目标10: Plant::GetCost beghouled 5 支 -> kBeghouledCostOverrides 键值对查表
// 计时区 = beghouled 覆盖块（原链 vs 键值对循环）；其余（尾段覆盖价表/植物定义表）两形态逐字相同，不计入
#include "bench_common.h"

enum SeedType
{
    SEED_PEASHOOTER = 0, SEED_SUNFLOWER, SEED_CHERRYBOMB, SEED_WALLNUT, SEED_POTATOMINE,
    SEED_SNOWPEA, SEED_CHOMPER, SEED_REPEATER, SEED_PUFFSHROOM, SEED_SUNSHROOM,
    SEED_FUMESHROOM, SEED_GRAVEBUSTER, SEED_HYPNOSHROOM, SEED_SCAREDYSHROOM, SEED_ICESHROOM,
    SEED_DOOMSHROOM, SEED_LILYPAD, SEED_SQUASH, SEED_THREEPEATER, SEED_TANGLEKELP,
    SEED_JALAPENO, SEED_SPIKEWEED, SEED_TORCHWOOD, SEED_TALLNUT, SEED_SEASHROOM,
    SEED_PLANTERN, SEED_CACTUS, SEED_BLOVER, SEED_SPLITPEA, SEED_STARFRUIT,
    SEED_PUMPKINSHELL, SEED_MAGNETSHROOM, SEED_CABBAGEPULT, SEED_FLOWERPOT, SEED_KERNELPULT,
    SEED_INSTANT_COFFEE, SEED_GARLIC, SEED_UMBRELLA, SEED_MARIGOLD, SEED_MELONPULT,
    SEED_GATLINGPEA, SEED_TWINSUNFLOWER, SEED_GLOOMSHROOM, SEED_CATTAIL, SEED_WINTERMELON,
    SEED_GOLD_MAGNET, SEED_SPIKEROCK, SEED_COBCANNON, SEED_IMITATER, SEED_EXPLODE_O_NUT,
    SEED_GIANT_WALLNUT, SEED_SPROUT, SEED_LEFTPEATER,
    NUM_SEED_TYPES,
    SEED_BEGHOULED_BUTTON_SHUFFLE,
    SEED_BEGHOULED_BUTTON_CRATER,
    SEED_NONE = -1
};
enum GameMode { GAMEMODE_ADVENTURE = 0, GAMEMODE_CHALLENGE_BEGHOULED, GAMEMODE_CHALLENGE_BEGHOULED_TWIST };

struct LawnAppStub { GameMode mGameMode; };
static LawnAppStub gLawnAppStorage;
static LawnAppStub* gLawnApp = &gLawnAppStorage;

// ---------------- FormA：原 5 支链（逐字） ----------------
// 返回 -1 = 块内未命中（落回函数其余部分，两形态同路径）
__declspec(noinline) int OneA(uint32_t inp)
{
    SeedType theSeedType = (SeedType)(inp % 55u);   // 0..54：含按钮 53/54
    SeedType theImitaterType = SeedType::SEED_NONE;
    gLawnApp->mGameMode = GAMEMODE_CHALLENGE_BEGHOULED;

    if (gLawnApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED || gLawnApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST)
    {
        if (theSeedType == SeedType::SEED_REPEATER)
        {
            return 1000;
        }
        else if (theSeedType == SeedType::SEED_FUMESHROOM)
        {
            return 500;
        }
        else if (theSeedType == SeedType::SEED_TALLNUT)
        {
            return 250;
        }
        else if (theSeedType == SeedType::SEED_BEGHOULED_BUTTON_SHUFFLE)
        {
            return 100;
        }
        else if (theSeedType == SeedType::SEED_BEGHOULED_BUTTON_CRATER)
        {
            return 200;
        }
    }

    (void)theImitaterType;
    return -1;
}

// ---------------- FormB：当前键值对表形态（逐字） ----------------
__declspec(noinline) int OneB(uint32_t inp)
{
    SeedType theSeedType = (SeedType)(inp % 55u);
    SeedType theImitaterType = SeedType::SEED_NONE;
    gLawnApp->mGameMode = GAMEMODE_CHALLENGE_BEGHOULED;

    if (gLawnApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED || gLawnApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST)
    {
        constexpr struct { SeedType mSeed; int mCost; } kBeghouledCostOverrides[] = {
            { SeedType::SEED_REPEATER,                 1000 },
            { SeedType::SEED_FUMESHROOM,                500 },
            { SeedType::SEED_TALLNUT,                   250 },
            { SeedType::SEED_BEGHOULED_BUTTON_SHUFFLE,  100 },
            { SeedType::SEED_BEGHOULED_BUTTON_CRATER,   200 },
        };
        for (const auto& aOverride : kBeghouledCostOverrides)
        {
            if (theSeedType == aOverride.mSeed)
            {
                return aOverride.mCost;
            }
        }
    }

    (void)theImitaterType;
    return -1;
}

// ---------------- FormC：FormB 逐字 + static constexpr（诊断：免每次调用栈物化） ----------------
__declspec(noinline) int OneC(uint32_t inp)
{
    SeedType theSeedType = (SeedType)(inp % 55u);
    SeedType theImitaterType = SeedType::SEED_NONE;
    gLawnApp->mGameMode = GAMEMODE_CHALLENGE_BEGHOULED;

    if (gLawnApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED || gLawnApp->mGameMode == GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST)
    {
        constexpr struct { SeedType mSeed; int mCost; } kBeghouledCostOverrides[] = {
            { SeedType::SEED_REPEATER,                 1000 },
            { SeedType::SEED_FUMESHROOM,                500 },
            { SeedType::SEED_TALLNUT,                   250 },
            { SeedType::SEED_BEGHOULED_BUTTON_SHUFFLE,  100 },
            { SeedType::SEED_BEGHOULED_BUTTON_CRATER,   200 },
        };
        for (const auto& aOverride : kBeghouledCostOverrides)
        {
            if (theSeedType == aOverride.mSeed)
            {
                return aOverride.mCost;
            }
        }
    }

    (void)theImitaterType;
    return -1;
}

static void RunA() { for (int i = 0; i < kN; i++) MixI(OneA(gInput[i])); }
static void RunB() { for (int i = 0; i < kN; i++) MixI(OneB(gInput[i])); }
static void RunC() { for (int i = 0; i < kN; i++) MixI(OneC(gInput[i])); }

int main()
{
    GenInput();
    uint64_t ca = CheckOnly(RunA);
    uint64_t cb = CheckOnly(RunB);
    uint64_t cc = CheckOnly(RunC);
    double a = TimePerIterNs(RunA, kN);
    double b = TimePerIterNs(RunB, kN);
    double c = TimePerIterNs(RunC, kN);
    printf("bench10 GetCostBeghouled | before %.2f ns | after %.2f ns | diff %.1f%% | C(static) %.2f ns | checksum=%s (A=%016llX B=%016llX C=%016llX)\n",
        a, b, (a - b) / a * 100.0, c, ca == cb && cb == cc ? "OK" : "MISMATCH", (unsigned long long)ca, (unsigned long long)cb, (unsigned long long)cc);
    return (ca == cb && cb == cc) ? 0 : 1;
}
