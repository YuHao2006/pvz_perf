#include "r3_entities.h"
class RenderItem { public: int mT; };
struct B2 {
    __declspec(noinline) void Dumb(Graphics*) {}
    __declspec(noinline) void f(Graphics* g)
    {
        static_assert(1 == 1, "x");
        static constexpr void (*tbl[])(B2*, Graphics*, RenderItem&) = {
            [](B2* b, Graphics* g, RenderItem&) { b->Dumb(g); },
            [](B2*, Graphics*, RenderItem& r) { (void)r.mT; },
        };
        static_assert(sizeof(tbl) / sizeof(tbl[0]) == 2, "n");
        static constexpr int cnt = (int)(sizeof(tbl) / sizeof(tbl[0]));
        (void)cnt;
        RenderItem r; tbl[r.mT & 1](this, g, r);
    }
};
int main(){ Graphics g; B2 b; RenderItem r; r.mT=0; b.f(&g); printf("repro ok\n"); return 0; }
