void CursorObject::Draw(Graphics* g)
{
    switch (mCursorType)
    {
    case CursorType::CURSOR_TYPE_SHOVEL:
        g->DrawImage(IMAGE_SHOVEL, 10, -30);
        break;

    case CursorType::CURSOR_TYPE_WATERING_CAN:
        if (mApp->mPlayerInfo->mPurchases[(int)StoreItem::STORE_ITEM_GOLD_WATERINGCAN])
        {
            g->DrawImage(IMAGE_ZEN_GOLDTOOLRETICLE, -62, -37);
            g->DrawImage(IMAGE_WATERINGCANGOLD, -3, 12);
        }
        else
        {
            g->DrawImage(IMAGE_WATERINGCAN, -3, 12);
        }
        break;

    case CursorType::CURSOR_TYPE_FERTILIZER:
        g->DrawImage(IMAGE_FERTILIZER, -15, 0);
        break;

    case CursorType::CURSOR_TYPE_BUG_SPRAY:
        g->DrawImage(IMAGE_BUG_SPRAY, -9, -1);
        break;

    case CursorType::CURSOR_TYPE_PHONOGRAPH:
        g->DrawImage(IMAGE_PHONOGRAPH, -17, 10);
        break;

    case CursorType::CURSOR_TYPE_CHOCOLATE:
        g->DrawImage(IMAGE_CHOCOLATE, -2, -8);
        break;

    case CursorType::CURSOR_TYPE_GLOVE:
        g->DrawImage(IMAGE_ZEN_GARDENGLOVE, -17, 15);
        break;

    case CursorType::CURSOR_TYPE_MONEY_SIGN:
        g->DrawImage(IMAGE_ZEN_MONEYSIGN, -17, -10);
        break;

    case CursorType::CURSOR_TYPE_TREE_FOOD:
        g->DrawImage(IMAGE_TREEFOOD, -15, 0);
        break;

    case CursorType::CURSOR_TYPE_WHEEELBARROW:
    {
        PottedPlant* aPottedPlant = mApp->mZenGarden->GetPottedPlantInWheelbarrow();
        if (aPottedPlant)
        {
            g->DrawImage(IMAGE_ZEN_WHEELBARROW, -20, -23);
            if (aPottedPlant->mPlantAge == PottedPlantAge::PLANTAGE_SMALL)
            {
                mApp->mZenGarden->DrawPottedPlant(g, 10.0f, -35.0f, aPottedPlant, 0.6f, true);
            }
            else if (aPottedPlant->mPlantAge == PottedPlantAge::PLANTAGE_MEDIUM)
            {
                mApp->mZenGarden->DrawPottedPlant(g, 15.0f, -25.0f, aPottedPlant, 0.5f, true);
            }
            else
            {
                mApp->mZenGarden->DrawPottedPlant(g, 21.0f, -15.0f, aPottedPlant, 0.4f, true);
            }
        }
        else
        {
            g->DrawImage(IMAGE_ZEN_WHEELBARROW, -20, -30);
        }

        break;
