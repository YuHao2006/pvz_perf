
void __thiscall FUN_0052ee40(int param_1,undefined4 param_2)

{
  int iVar1;
  
  switch(param_2) {
  case 1000:
    *(undefined4 *)(param_1 + 0xf08) = 0xffffffff;
    *(undefined4 *)(param_1 + 0xf0c) = 0xffffffff;
    *(int *)(param_1 + 0xf0) = *(int *)(param_1 + 0xf0) + 1;
    if (*(int *)(param_1 + 0xf4) <= *(int *)(param_1 + 0xf0)) {
      *(undefined1 *)(*(int *)(param_1 + 0xa8) + 0x1a) = 1;
      *(undefined4 *)(param_1 + 0xf0) = *(undefined4 *)(param_1 + 0xf4);
      *(undefined1 *)(*(int *)(param_1 + 0xa4) + 0x1a) = 0;
      return;
    }
    *(undefined1 *)(*(int *)(param_1 + 0xa8) + 0x1a) = 0;
    *(undefined1 *)(*(int *)(param_1 + 0xa4) + 0x1a) = 0;
    return;
  case 0x3e9:
    *(int *)(param_1 + 0xf0) = *(int *)(param_1 + 0xf0) + -1;
    *(undefined4 *)(param_1 + 0xf08) = 0xffffffff;
    *(undefined4 *)(param_1 + 0xf0c) = 0xffffffff;
    if (*(int *)(param_1 + 0xf0) < 2) {
      *(undefined1 *)(*(int *)(param_1 + 0xa4) + 0x1a) = 1;
      *(undefined4 *)(param_1 + 0xf0) = 1;
      *(undefined1 *)(*(int *)(param_1 + 0xa8) + 0x1a) = 0;
      return;
    }
    *(undefined1 *)(*(int *)(param_1 + 0xa4) + 0x1a) = 0;
    *(undefined1 *)(*(int *)(param_1 + 0xa8) + 0x1a) = 0;
    return;
  case 0x3ea:
    *(undefined4 *)(param_1 + 0xf5c) = 2;
    FUN_00530550();
    return;
  case 0x3eb:
    if (*(int *)(param_1 + 0xf5c) == 0) {
      *(undefined4 *)(param_1 + 0xf5c) = 1;
      FUN_00530550();
      return;
    }
    if (*(int *)(param_1 + 0xf5c) != 3) {
      return;
    }
    *(undefined1 *)(param_1 + 0xf6e) = 1;
    FUN_0046dd00();
    break;
  case 0x3ec:
    FUN_00530890();
    *(undefined4 *)(param_1 + 0xf5c) = 0;
    FUN_00530550();
    return;
  case 0x3ed:
    *(int *)(param_1 + 0xf64) = *(int *)(param_1 + 0xf64) + 1;
    iVar1 = *(int *)(*(int *)(*(int *)(param_1 + 0xa0) + 0x94c) + 0x4840) + -1;
    if (iVar1 <= *(int *)(param_1 + 0xf64)) {
      *(int *)(param_1 + 0xf64) = iVar1;
      *(undefined1 *)(*(int *)(param_1 + 0xdc) + 0x1a) = 1;
    }
    *(undefined1 *)(*(int *)(param_1 + 0xe0) + 0x1a) = 0;
    return;
  case 0x3ee:
    *(int *)(param_1 + 0xf64) = *(int *)(param_1 + 0xf64) + -1;
    if (*(int *)(param_1 + 0xf64) < 1) {
      *(undefined4 *)(param_1 + 0xf64) = 0;
      *(undefined1 *)(*(int *)(param_1 + 0xe0) + 0x1a) = 1;
    }
    *(undefined1 *)(*(int *)(param_1 + 0xdc) + 0x1a) = 0;
    return;
  case 0x3ef:
    FUN_00530890();
    FUN_004501c0();
    return;
  case 0x3f0:
    FUN_00530890();
    break;
  case 0x3f1:
    *(undefined4 *)(param_1 + 0xf08) = 0xffffffff;
    *(undefined4 *)(param_1 + 0xf0c) = 0xffffffff;
    *(undefined4 *)(param_1 + 0xf0) = 1;
    *(undefined4 *)(param_1 + 0xf4) = 1;
    *(undefined4 *)(param_1 + 0xf10) = 0;
    *(undefined4 *)(param_1 + 0xfc) = 0;
    FUN_0052fda0();
    *(undefined4 *)(param_1 + 0x100) = 0;
    return;
  case 0x3f2:
    *(undefined4 *)(param_1 + 0xfc) = 0x10;
    *(undefined4 *)(param_1 + 0xf10) = 5;
    FUN_0052f6a0(&PTR_DAT_0071bf78);
    return;
  case 0x3f3:
    *(undefined4 *)(param_1 + 0xfc) = 0x18;
    *(undefined4 *)(param_1 + 0xf10) = 4;
    FUN_0052f6a0(&PTR_DAT_0071c1f8);
    return;
  case 0x3f4:
    *(undefined4 *)(param_1 + 0xfc) = 0xe;
    *(undefined4 *)(param_1 + 0xf10) = 2;
    FUN_0052f6a0(&PTR_DAT_0071c5b8);
    return;
  case 0x3f5:
    *(undefined4 *)(param_1 + 0xfc) = 0x10;
    *(undefined4 *)(param_1 + 0xf10) = 6;
    FUN_0052f6a0(&PTR_DAT_0071c7e8);
    return;
  case 0x3f6:
    *(undefined4 *)(param_1 + 0xfc) = 0xc;
    *(undefined4 *)(param_1 + 0xf10) = 1;
    FUN_0052f6a0(&PTR_DAT_0071ca68);
    return;
  case 0x3f7:
    *(undefined4 *)(param_1 + 0xfc) = 0xf;
    *(undefined4 *)(param_1 + 0xf10) = 3;
    FUN_0052f6a0(&PTR_DAT_0071cc48);
    return;
  case 0x3f8:
    *(undefined4 *)(param_1 + 0xfc) = 0xe;
    *(undefined4 *)(param_1 + 0xf10) = 7;
    FUN_0052f6a0(&PTR_DAT_0071cea0);
    return;
  case 0x3f9:
    *(undefined4 *)(param_1 + 0xfc) = 5;
    *(undefined4 *)(param_1 + 0xf10) = 8;
    FUN_0052f6a0(&PTR_DAT_0071d0d0);
    return;
  default:
    goto switchD_0052ee56_default;
  }
  *(undefined4 *)(param_1 + 0xf5c) = 4;
  FUN_00530550();
switchD_0052ee56_default:
  return;
}

