#include "pvz/assets/pak_archive.hpp"

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string_view>
#include <vector>

namespace {

constexpr std::uint8_t kEncryptionKey = 0xF7;

void require(const bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void append_u32(std::vector<std::uint8_t>& bytes, const std::uint32_t value)
{
    for (unsigned shift = 0; shift < 32; shift += 8)
        bytes.push_back(static_cast<std::uint8_t>(value >> shift));
}

void append_u64(std::vector<std::uint8_t>& bytes, const std::uint64_t value)
{
    for (unsigned shift = 0; shift < 64; shift += 8)
        bytes.push_back(static_cast<std::uint8_t>(value >> shift));
}

void append_entry(
    std::vector<std::uint8_t>& bytes,
    const std::string_view path,
    const std::uint32_t size,
    const std::uint64_t file_time)
{
    bytes.push_back(0);
    bytes.push_back(static_cast<std::uint8_t>(path.size()));
    bytes.insert(bytes.end(), path.begin(), path.end());
    append_u32(bytes, size);
    append_u64(bytes, file_time);
}

std::filesystem::path write_test_archive()
{
    std::vector<std::uint8_t> bytes;
    append_u32(bytes, 0xBAC04AC0);
    append_u32(bytes, 0);
    append_entry(bytes, "compiled\\images\\test.bin", 4, 11);
    append_entry(bytes, "properties\\sample.txt", 3, 22);
    bytes.push_back(0x80);
    bytes.insert(bytes.end(), {1, 2, 3, 4, 'p', 'v', 'z'});

    for (auto& value : bytes)
        value ^= kEncryptionKey;

    const auto unique = std::chrono::steady_clock::now().time_since_epoch().count();
    const auto path = std::filesystem::temp_directory_path() /
                      ("modern_pvz_pak_test_" + std::to_string(unique) + ".pak");
    std::ofstream output{path, std::ios::binary};
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!output)
        throw std::runtime_error("unable to create test PAK");
    return path;
}

void test_archive_index_and_reads()
{
    const auto path = write_test_archive();
    const auto archive = pvz::assets::PakArchive::open(path);

    require(archive.entries().size() == 2, "archive must contain both synthetic entries");
    const auto first = archive.find("COMPILED/images/TEST.bin");
    require(first.has_value(), "path lookup must ignore case and slash direction");
    require(first->get().windows_file_time == 11, "file time must be parsed as little endian");

    const auto first_data = archive.read(first->get());
    require(first_data == std::vector<std::uint8_t>({1, 2, 3, 4}), "entry data must be decrypted");

    const auto second = archive.find("properties\\sample.txt");
    require(second.has_value(), "second entry must be indexed");
    const auto partial = archive.read(second->get(), 1, 2);
    require(partial == std::vector<std::uint8_t>({'v', 'z'}), "partial entry reads must work");

    bool rejected = false;
    try {
        [[maybe_unused]] const auto invalid = archive.read(second->get(), 2, 2);
    } catch (const std::out_of_range&) {
        rejected = true;
    }
    require(rejected, "out-of-range entry reads must be rejected");

    std::filesystem::remove(path);
}

} // namespace

int main()
{
    test_archive_index_and_reads();
    return EXIT_SUCCESS;
}
