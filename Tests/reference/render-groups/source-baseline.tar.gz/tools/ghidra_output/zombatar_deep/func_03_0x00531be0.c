
void __fastcall FUN_00531be0(int *param_1)

{
  int iVar1;
  
  FUN_0054c870();
  (**(code **)(*(int *)param_1[0x65] + 0x58))();
  iVar1 = param_1[0x65];
  if ((*(char *)(iVar1 + 0xf6d) != '\0') || (*(char *)(*(int *)(iVar1 + 0xec) + 0xdd) != '\0')) {
    FUN_00531250(iVar1 + 0xf14);
  }
  if (param_1[0x62] != 0) {
    FUN_0053b750();
  }
                    /* WARNING: Could not recover jumptable at 0x00531c44. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x44))();
  return;
}

