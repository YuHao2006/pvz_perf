
void __thiscall FUN_00532460(int *param_1,undefined4 param_2)

{
  FUN_00555ff0(param_2);
  (**(code **)(*param_1 + 0xc))(param_1[100]);
  (**(code **)(*param_1 + 0xc))(param_1[0x69]);
  return;
}

