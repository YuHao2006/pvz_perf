
undefined4 __thiscall FUN_005490c0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined1 *puVar2;
  undefined1 local_14 [16];
  
  if (*(int *)(param_1 + 0x24) == 0) {
    FUN_00401af0();
  }
  else {
    puVar2 = local_14;
    uVar1 = (**(code **)(**(int **)(param_1 + 0x24) + 0x3c))(puVar2);
    FUN_00401af0(puVar2,param_1,uVar1);
    FUN_00401af0();
  }
  return param_2;
}

