
void FUN_0054cd70(undefined4 param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,
                 int param_6)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int local_14;
  int local_10;
  int local_c;
  
  local_10 = 1;
  for (local_c = 10; local_c <= param_2; local_c = local_c * 10) {
    local_10 = local_10 + 1;
  }
  if (param_2 == 0) {
    local_c = 10;
  }
  iVar1 = FUN_0059aba0();
  iVar1 = iVar1 / 10;
  for (local_14 = 0; local_14 < local_10; local_14 = local_14 + 1) {
    local_c = local_c / 10;
    puVar2 = (undefined4 *)FUN_00598290();
    uVar3 = FUN_0059abc0();
    FUN_005994c0((iVar1 + param_6) * local_14 + param_3,param_4,iVar1,uVar3);
    FUN_00598a60(param_5,((iVar1 + param_6) * local_14 + param_3) -
                         ((param_2 / local_c) % 10) * iVar1,param_4);
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  return;
}

