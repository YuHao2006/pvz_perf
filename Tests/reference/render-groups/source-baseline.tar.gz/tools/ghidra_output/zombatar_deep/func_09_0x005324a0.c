
void __thiscall FUN_005324a0(int *param_1,undefined4 param_2)

{
  FUN_00556050(param_2);
  (**(code **)(*param_1 + 0x10))(param_1[100]);
  (**(code **)(*param_1 + 0x10))(param_1[0x69]);
  return;
}

