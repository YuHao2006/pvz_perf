#include "DataSync.h"
#include "PlayerInfo.h"
#include "../LawnCommon.h"
#include "../Widget/ChallengeScreen.h"
#include "../../Sexy.TodLib/TodDebug.h"
#include "../../Sexy.TodLib/TodCommon.h"
#include "misc/Buffer.h"
#include "../../SexyAppFramework/SexyAppBase.h"

static int gUserVersion = 12;

namespace
{
constexpr size_t kGOTYFixedCoreSize = 820;
constexpr size_t kGOTYFixedTailSize = 66;
constexpr size_t kPottedPlantSize = 88;
constexpr size_t kZombatarSize = 72;
constexpr size_t kPottedPlantCountOffset = kGOTYFixedCoreSize - sizeof(int);

static_assert(sizeof(int) == 4, "GOTY save integers must remain 32-bit");
static_assert(sizeof(PottedPlant) == kPottedPlantSize, "PottedPlant no longer matches the GOTY save layout");
static_assert(sizeof(Zombatar) == kZombatarSize, "Zombatar no longer matches the GOTY save layout");

bool ReadSaveInt(const Buffer& theBuffer, size_t theOffset, int& theValue)
{
	if (theOffset + sizeof(theValue) > static_cast<size_t>(theBuffer.GetDataLen()))
		return false;

	memcpy(&theValue, static_cast<const unsigned char*>(theBuffer.GetDataPtr()) + theOffset, sizeof(theValue));
	return true;
}

bool IsNativeGOTYDetailsBuffer(const Buffer& theBuffer)
{
	const size_t aDataLen = static_cast<size_t>(theBuffer.GetDataLen());
	if (aDataLen < kGOTYFixedCoreSize + kGOTYFixedTailSize)
		return false;

	int aNumPottedPlants = 0;
	if (!ReadSaveInt(theBuffer, kPottedPlantCountOffset, aNumPottedPlants) ||
		aNumPottedPlants < 0 || aNumPottedPlants > MAX_POTTED_PLANTS)
	{
		return false;
	}

	const size_t aZombatarCountOffset = kGOTYFixedCoreSize +
		static_cast<size_t>(aNumPottedPlants) * kPottedPlantSize + 41;
	int aNumZombatars = 0;
	if (!ReadSaveInt(theBuffer, aZombatarCountOffset, aNumZombatars) ||
		aNumZombatars < 0 || aNumZombatars > MAX_NUM_ZOMBATARS)
	{
		return false;
	}

	const size_t anExpectedSize = kGOTYFixedCoreSize +
		static_cast<size_t>(aNumPottedPlants) * kPottedPlantSize +
		kGOTYFixedTailSize + static_cast<size_t>(aNumZombatars) * kZombatarSize;
	return aDataLen == anExpectedSize;
}
}

PlayerInfo::PlayerInfo()
{
	Reset();
}

//0x468310
void PlayerInfo::SyncSummary(DataSync& theSync)
{
	theSync.SyncString(mName);
	theSync.SyncLong(mUseSeq);
	theSync.SyncLong(mId);
}

//0x468390
// GOTY @Patoke: 0x46BE80
bool PlayerInfo::SyncDetails(DataSync& theSync)
{
	if (theSync.GetReader())
	{
		Reset();
	}

	int aVersion = gUserVersion;
	theSync.SyncLong(aVersion);
	theSync.SetVersion(aVersion);
	if (aVersion != gUserVersion)
	{
		return false;
	}

	theSync.SyncLong(mLevel);
	theSync.SyncLong(mCoins);
	theSync.SyncLong(mFinishedAdventure);
	for (int i = 0; i < 100; i++)
	{
		theSync.SyncLong(mChallengeRecords[i]);
	}
	for (int i = 0; i < 80; i++)
	{
		theSync.SyncLong(mPurchases[i]);
	}
	theSync.SyncLong(mPlayTimeActivePlayer);
	theSync.SyncLong(mPlayTimeInactivePlayer);
	theSync.SyncLong(mHasUsedCheatKeys);
	theSync.SyncLong(mHasWokenStinky);
	theSync.SyncLong(mDidntPurchasePacketUpgrade);
	theSync.SyncLong(mLastStinkyChocolateTime);
	theSync.SyncLong(mStinkyPosX);
	theSync.SyncLong(mStinkyPosY);
	theSync.SyncLong(mHasUnlockedMinigames);
	theSync.SyncLong(mHasUnlockedPuzzleMode);
	theSync.SyncLong(mHasNewMiniGame);
	theSync.SyncLong(mHasNewScaryPotter);
	theSync.SyncLong(mHasNewIZombie);
	theSync.SyncLong(mHasNewSurvival);
	theSync.SyncLong(mHasUnlockedSurvivalMode);
	theSync.SyncLong(mNeedsMessageOnGameSelector);
	theSync.SyncLong(mNeedsMagicTacoReward);
	theSync.SyncLong(mHasSeenStinky);
	theSync.SyncLong(mHasSeenUpsell);
	theSync.SyncLong(mPlaceHolderPlayerStats);
	theSync.SyncLong(mNumPottedPlants);

	if (mNumPottedPlants < 0 || mNumPottedPlants > MAX_POTTED_PLANTS)
	{
		return false;
	}
	for (int i = 0; i < mNumPottedPlants; i++)
	{
		theSync.SyncBytes(&mPottedPlant[i], sizeof(PottedPlant));
	}

	// @Patoke: implemented
	for (int i = 0; i < 20; i++)
	{
		theSync.SyncBool(mEarnedAchievements[i]);
	}

	for (int i = 0; i < 20; i++)
	{
		theSync.SyncBool(mShownAchievements[i]);
	}

	theSync.SyncBool(mAcceptedZombatarULA);
	theSync.SyncLong(mNumZombatars);
	if (mNumZombatars < 0 || mNumZombatars > MAX_NUM_ZOMBATARS)
	{
		return false;
	}
	for (int i = 0; i < mNumZombatars; i++)
	{
		theSync.SyncBytes(&mZombatars[i], sizeof(Zombatar));
	}

	for (int i = 0; i < 20; i++)
	{
		theSync.SyncBool(mMiniGamesCompleted[i]);
	}

	theSync.SyncBool(mShownZombatarDesktopMessage);
	return true;
}

//0x469400
bool PlayerInfo::LoadDetails()
{
	Buffer aBuffer;
	std::string aFileName = GetAppDataFolder() + StrFormat("user%d.dat", mId);
	if (!gSexyAppBase->ReadBufferFromFile(aFileName, &aBuffer, false))
	{
		return true;
	}

	if (!IsNativeGOTYDetailsBuffer(aBuffer))
	{
		mDetailsLoadRejected = true;
		TodTrace("Rejected unsupported player data without modifying it\n");
		return false;
	}

	try
	{
		PlayerInfo aLoadedPlayer;
		DataReader aReader;
		aReader.OpenMemory(aBuffer.GetDataPtr(), aBuffer.GetDataLen(), false);
		DataSync aSync(aReader);
		if (!aLoadedPlayer.SyncDetails(aSync))
		{
			mDetailsLoadRejected = true;
			TodTrace("Rejected unsupported player data without modifying it\n");
			return false;
		}

		aLoadedPlayer.mName = mName;
		aLoadedPlayer.mUseSeq = mUseSeq;
		aLoadedPlayer.mId = mId;
		// 1073's new-avatar path starts the skin swatch at palette entry 0.
		// Preserve the rest of the native record verbatim, but repair a torn or
		// pre-release record whose skin index is -1/out of range; otherwise the
		// renderer intentionally uses its white fallback palette.
		for (int i = 0; i < aLoadedPlayer.mNumZombatars; ++i)
		{
			int& aSkinColor = aLoadedPlayer.mZombatars[i].mColors[ZOMBATAR_CUSTOM_SKIN];
			if (aSkinColor < 0 || aSkinColor >= 12)
				aSkinColor = 0;
		}
		*this = aLoadedPlayer;
		return true;
	}
	catch (DataReaderException&)
	{
		mDetailsLoadRejected = true;
		TodTrace("Rejected unsupported player data without modifying it\n");
		return false;
	}
}

//0x4695F0
// GOTY @Patoke: 0x46D750
void PlayerInfo::SaveDetails()
{
	if (mDetailsLoadRejected)
	{
		TodTrace("Refusing to overwrite unsupported player data\n");
		return;
	}

	DataWriter aWriter;
	aWriter.OpenMemory();
	DataSync aSync(aWriter);
	if (!SyncDetails(aSync))
	{
		TodTrace("Refusing to save out-of-range player data\n");
		return;
	}

	MkDir(GetAppDataFolder());
	std::string aFileName = GetAppDataFolder() + StrFormat("user%d.dat", mId);
	gSexyAppBase->WriteBytesToFile(aFileName, aWriter.GetDataPtr(), aWriter.GetDataLen());
}

//0x469810
void PlayerInfo::DeleteUserFiles()
{
	if (!LoadDetails())
	{
		return;
	}

	std::string aFilename = GetAppDataFolder() + StrFormat("user%d.dat", mId);
	gSexyAppBase->EraseFile(aFilename);

	for (int i = 0; i < (int)GameMode::NUM_GAME_MODES; i++)
	{
		std::string aFileName = GetSavedGameName((GameMode)i, mId);
		gSexyAppBase->EraseFile(aFileName);
	}
}

//0x469940
// GOTY @Patoke: 0x46DBF0
void PlayerInfo::Reset()
{
	mLevel = 1;
	mCoins = 0;
	mFinishedAdventure = 0;
	memset(mChallengeRecords, 0, sizeof(mChallengeRecords));
	memset(mPurchases, 0, sizeof(mPurchases));
	mPlayTimeActivePlayer = 0;
	mPlayTimeInactivePlayer = 0;
	mHasUsedCheatKeys = 0;
	mHasWokenStinky = 0;
	mDidntPurchasePacketUpgrade = 0;
	mLastStinkyChocolateTime = 0;
	mStinkyPosX = 0;
	mStinkyPosY = 0;
	mHasUnlockedMinigames = 0;
	mHasUnlockedPuzzleMode = 0;
	mHasNewMiniGame = 0;
	mHasNewScaryPotter = 0;
	mHasNewIZombie = 0;
	mHasNewSurvival = 0;
	mHasUnlockedSurvivalMode = 0;
	mNeedsMessageOnGameSelector = 0;
	mNeedsMagicTacoReward = 0;
	mHasSeenStinky = 0;
	mHasSeenUpsell = 0;
	mAcceptedZombatarULA = false;
	mPlaceHolderPlayerStats = 0;

	for (int i = 0; i < 20; i++)
	{
		mEarnedAchievements[i] = false;
		mShownAchievements[i] = false;
	}

	mNumZombatars = 0;

	memset(mPottedPlant, 0, sizeof(mPottedPlant));
	mNumPottedPlants = 0;
	memset(mMiniGamesCompleted, 0, sizeof(mMiniGamesCompleted));
	mShownZombatarDesktopMessage = false;
	mDetailsLoadRejected = false;
}

void PlayerInfo::AddCoins(int theAmount)
{
	mCoins += theAmount;
	if (mCoins > 99999)
	{
		mCoins = 99999;
	}
	else if (mCoins < 0)
	{
		mCoins = 0;
	}
}

void PlayerInfo::ResetChallengeRecord(GameMode theGameMode)
{
	int aGameMode = (int)theGameMode - (int)GameMode::GAMEMODE_SURVIVAL_NORMAL_STAGE_1;
	TOD_ASSERT(aGameMode >= 0 && aGameMode <= NUM_CHALLENGE_MODES);
	mChallengeRecords[aGameMode] = 0;
}

//0x469A00
void PottedPlant::InitializePottedPlant(SeedType theSeedType)
{
	memset(this, 0, sizeof(PottedPlant));
	mSeedType = theSeedType;
	mDrawVariation = DrawVariation::VARIATION_NORMAL;
	mLastWateredTime = 0;
	mFacing = (FacingDirection)RandRangeInt((int)FacingDirection::FACING_RIGHT, (int)FacingDirection::FACING_LEFT);
	mPlantAge = PottedPlantAge::PLANTAGE_SPROUT;
	mTimesFed = 0;
	mWhichZenGarden = GardenType::GARDEN_MAIN;
	mFeedingsPerGrow = RandRangeInt(3, 5);
	mPlantNeed = PottedPlantNeed::PLANTNEED_NONE;
	mLastNeedFulfilledTime = 0;
	mLastFertilizedTime = 0;
	mLastChocolateTime = 0;
}

void PlayerInfo::DeleteZombatarFromIndex(int* theIndex)
{
	if (!theIndex || *theIndex < 0 || *theIndex >= mNumZombatars)
	{
		TodTraceAndLog("Attempting to delete invalid Zombatar at index %d", theIndex ? *theIndex : -1);
		return;
	}

	const int aNumToMove = mNumZombatars - *theIndex - 1;
	if (aNumToMove > 0)
	{
		memmove(
			&mZombatars[*theIndex],
			&mZombatars[*theIndex + 1],
			static_cast<size_t>(aNumToMove) * sizeof(Zombatar));
	}

	--mNumZombatars;
	memset(&mZombatars[mNumZombatars], 0, sizeof(Zombatar));
}
